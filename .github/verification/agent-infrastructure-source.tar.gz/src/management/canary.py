"""Local-only v1 integration runner.

The runner composes the command journal with the fixture's independently owned
effect receipt.  It does not invoke Prefect, Paperclip, Hermes, a model, a
shell, or a network endpoint.  ``runtime_kind`` is deliberately ``fixture``.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
from typing import Any

from .fixture import ArtifactIntegrityError, FixtureError, FixtureService, lookup_fixture
from .journal import CommandJournal, RequestConflict, StaleTransition
from .workflow import WorkflowEdge, WorkflowNode, WorkflowSpec


class ReconciliationRequired(RuntimeError):
    """An outcome is ambiguous and must be reconciled, never replayed blindly."""


_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


def _validate_request_input(project_id: object, value: object) -> tuple[str, int]:
    """Reject impossible fixture work before creating a durable command record."""
    if not isinstance(project_id, str) or not _IDENTIFIER.fullmatch(project_id):
        raise ValueError("project_id must be a safe fixture identifier")
    if isinstance(value, bool) or not isinstance(value, int) or abs(value) > 1_000_000:
        raise ValueError("value must be a bounded fixture integer")
    return project_id, value


def _scope(project_id: str) -> dict[str, str]:
    return {"project_id": project_id, "runtime_kind": "fixture", "workflow": "agent-stack.canary.v1"}


def default_workflow_spec() -> WorkflowSpec:
    """The only v1 operation: typed fixture payload -> sum -> artifact."""
    return WorkflowSpec(
        nodes=(
            WorkflowNode("input", "input", output_type="fixture_payload"),
            WorkflowNode("tool", "tool", input_type="fixture_payload", output_type="fixture_result", config={"operation": "sum"}),
            WorkflowNode("artifact", "artifact", input_type="fixture_result"),
        ),
        edges=(
            WorkflowEdge("input", "tool", "fixture_payload"),
            WorkflowEdge("tool", "artifact", "fixture_result"),
        ),
    )


def _evidence(result: dict[str, object], graph_hash: str) -> dict[str, str]:
    return {
        "artifact_reference": str(result["artifact_reference"]),
        "artifact_sha256": str(result["artifact_sha256"]),
        "runtime_kind": "fixture",
        "workflow_version_hash": graph_hash,
    }


def _lookup(root: Path, project_id: str, request_id: str, fixture_payload: dict[str, int]) -> dict[str, object]:
    result = lookup_fixture(root / "fixture", project_id, request_id, fixture_payload)
    if result is None:
        raise ReconciliationRequired("fixture receipt is absent; effect outcome remains pending reconciliation")
    return result


def run_canary(state_dir: str | Path, request_id: str, project_id: str, value: int) -> dict[str, Any]:
    """Run or safely replay the one deterministic local effect.

    A dispatching/submitted/unknown record is intentionally not re-executed: a
    real native receipt lookup belongs in an explicit future reconciliation
    adapter.  The fixture can prove durable duplicate effects once a receipt is
    known, but this runner never uses ``execute`` as an ambiguity probe.
    """
    project_id, value = _validate_request_input(project_id, value)
    spec = default_workflow_spec()
    spec.validate()
    graph_hash = spec.version_hash
    root = Path(state_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    fixture_payload = {"value": value}
    payload = {"value": value, "workflow_version_hash": graph_hash}
    journal = CommandJournal(root / "command-journal.sqlite3")
    submission = journal.accept(request_id, _scope(project_id), payload)
    record = submission.record
    if record.state == "completed":
        # Read-only lookup prevents a restore with a missing receipt from
        # recreating an effect solely because the journal says completed.
        result = _lookup(root, project_id, request_id, fixture_payload)
        expected_evidence = _evidence(result, graph_hash)
        if record.detail != expected_evidence or record.native_run_id != "fixture:" + request_id:
            raise ArtifactIntegrityError("completed journal evidence does not match the fixture receipt")
        return {
            "evidence": {"artifact_sha256": result["artifact_sha256"], "artifact_reference": result["artifact_reference"]},
            "journal_state": "completed", "replayed": True, "request_id": request_id,
            "runtime_kind": "fixture", "result": result,
        }
    if record.state in {"dispatching", "submitted", "unknown"}:
        raise ReconciliationRequired("request has an ambiguous or in-flight outcome; reconcile it before another execution")
    if record.state == "failed":
        return {"detail": record.detail, "journal_state": "failed", "replayed": True,
                "request_id": request_id, "runtime_kind": "fixture"}
    claim = journal.claim_dispatch(request_id, "canary-local-v1")
    if claim is None:
        raise ReconciliationRequired("another dispatcher owns this request; reconcile before retrying")
    try:
        result = FixtureService(root / "fixture").execute(project_id, request_id, fixture_payload)
        journal.mark_submitted(request_id, claim.claimant, claim.generation, "fixture:" + request_id)
        journal.reconcile_outcome(request_id, "completed", _evidence(result, graph_hash))
    except Exception as error:
        # Never infer that an owned effect failed merely because the caller did
        # not receive a result.  This also preserves corrupt-artifact evidence.
        try:
            journal.mark_unknown(request_id, claim.claimant, claim.generation, {"error": type(error).__name__})
        except StaleTransition:
            pass
        raise
    return {
        "evidence": _evidence(result, graph_hash),
        "journal_state": "completed", "replayed": not submission.created, "request_id": request_id,
        "runtime_kind": "fixture", "result": result,
    }


def reconcile_canary(state_dir: str | Path, request_id: str, project_id: str, value: int) -> dict[str, Any]:
    """Resolve an already-recorded uncertain fixture attempt through read-only proof.

    This does not create a journal record or a fixture receipt.  A current,
    positive claim generation lets it bind a receipt after a hard dispatcher
    crash; a stale or legacy (unfenced) claim remains untouched.
    """
    project_id, value = _validate_request_input(project_id, value)
    spec = default_workflow_spec()
    spec.validate()
    graph_hash = spec.version_hash
    root = Path(state_dir).resolve()
    journal_path = root / "command-journal.sqlite3"
    if not journal_path.is_file():
        raise ValueError("journal is absent; reconciliation never initializes a command store")
    journal = CommandJournal(journal_path)
    record = journal.get(request_id)
    expected_payload = {"value": value, "workflow_version_hash": graph_hash}
    if record is None:
        raise ValueError("request is absent; reconciliation never creates a command")
    if record.scope != _scope(project_id) or record.payload != expected_payload:
        raise RequestConflict("request is bound to a different scope, input, or workflow version")
    result = _lookup(root, project_id, request_id, {"value": value})
    evidence = _evidence(result, graph_hash)
    native_run_id = "fixture:" + request_id
    if record.state in {"dispatching", "unknown"}:
        if record.dispatch_claimant is None or record.dispatch_generation < 1:
            raise ReconciliationRequired("request has no fenced dispatch claim; retain it for trusted operator reconciliation")
        record = journal.reconcile_dispatch_receipt(
            request_id, record.dispatch_claimant, record.dispatch_generation, native_run_id, {"receipt": evidence},
        )
    if record.state == "submitted":
        record = journal.reconcile_outcome(request_id, "completed", evidence)
    if record.state != "completed" or record.native_run_id != native_run_id or record.detail != evidence:
        raise ArtifactIntegrityError("journal does not agree with the proven fixture receipt")
    return {"evidence": evidence, "journal_state": "completed", "reconciled": True,
            "request_id": request_id, "result": result, "runtime_kind": "fixture"}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the local agent-stack fixture canary")
    parser.add_argument("--state-dir", required=True)
    parser.add_argument("--request-id", required=True)
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--value", required=True, type=int)
    parser.add_argument("--reconcile", action="store_true", help="read-only fixture receipt reconciliation; never executes an effect")
    args = parser.parse_args(argv)
    try:
        operation = reconcile_canary if args.reconcile else run_canary
        print(json.dumps(operation(args.state_dir, args.request_id, args.project_id, args.value), sort_keys=True))
    except ReconciliationRequired as error:
        # Pending is not failure: an operator/adapter must reconcile a receipt
        # before it can determine whether an owned effect occurred.
        print(json.dumps({"error": type(error).__name__, "message": str(error),
                          "request_id": args.request_id, "runtime_kind": "fixture",
                          "state": "pending_reconciliation"}, sort_keys=True))
        return 3
    except (RequestConflict, FixtureError, StaleTransition, ValueError) as error:
        print(json.dumps({"error": type(error).__name__, "message": str(error),
                          "request_id": args.request_id, "runtime_kind": "fixture",
                          "state": "error"}, sort_keys=True))
        return 2
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
