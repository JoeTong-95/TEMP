"""Deterministic, local-only fixture with durable idempotency receipts.

This module deliberately has no transport, shell, or network surface.  It is a
small stand-in for an owned tool so workflow integration can exercise durable
effect handling before a real external action is introduced.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import tempfile
from pathlib import Path
from typing import Any, Mapping


_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_MAX_ABS_VALUE = 1_000_000
_MAX_LIST_LENGTH = 64


class FixtureError(Exception):
    """Base class for safe fixture failures."""


class InputValidationError(FixtureError):
    """The supplied scope, effect id, or payload is not within fixture bounds."""


class EffectConflictError(FixtureError):
    """An effect id was previously used with another scope or payload."""


class ArtifactIntegrityError(FixtureError):
    """A referenced immutable artifact no longer matches its receipt."""


def _canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _validate_identifier(value: object, field: str) -> str:
    if not isinstance(value, str) or not _IDENTIFIER.fullmatch(value):
        raise InputValidationError(f"{field} must be a 1-64 character safe identifier")
    return value


def _validate_payload(payload: object) -> dict[str, object]:
    """Return a canonical, bounded payload shape; bool is never treated as int."""
    if not isinstance(payload, Mapping) or set(payload) not in ({"value"}, {"values"}):
        raise InputValidationError("payload must be exactly {'value': int} or {'values': [int, ...]}")
    if "value" in payload:
        value = payload["value"]
        if isinstance(value, bool) or not isinstance(value, int) or abs(value) > _MAX_ABS_VALUE:
            raise InputValidationError("value must be an integer within fixture bounds")
        return {"value": value}

    values = payload["values"]
    if not isinstance(values, list) or not values or len(values) > _MAX_LIST_LENGTH:
        raise InputValidationError("values must be a non-empty list of at most 64 integers")
    if any(isinstance(item, bool) or not isinstance(item, int) or abs(item) > _MAX_ABS_VALUE for item in values):
        raise InputValidationError("every values item must be an integer within fixture bounds")
    return {"values": list(values)}


class FixtureService:
    """Owns a SQLite receipt store and content-addressed JSON artifact directory."""

    def __init__(self, storage_root: str | Path) -> None:
        self.root = Path(storage_root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.artifacts = self.root / "artifacts"
        self.artifacts.mkdir(exist_ok=True)
        self._validate_artifact_directory()
        self.database = self.root / "fixture-receipts.sqlite3"
        self._initialize_database()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database, timeout=15, isolation_level=None)
        connection.execute("PRAGMA busy_timeout = 15000")
        # This pragma is connection-scoped, so set it for every effect writer,
        # not only while creating the schema.
        connection.execute("PRAGMA synchronous = FULL")
        return connection

    def _readonly_connection(self) -> sqlite3.Connection:
        """Open an existing receipt DB without creating or modifying storage."""
        connection = sqlite3.connect(self.database.resolve().as_uri() + "?mode=ro", uri=True, timeout=15)
        connection.execute("PRAGMA query_only = ON")
        return connection

    def _initialize_database(self) -> None:
        connection = self._connect()
        try:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("PRAGMA synchronous = FULL")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS effect_receipts (
                    effect_id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL,
                    payload_sha256 TEXT NOT NULL,
                    artifact_sha256 TEXT NOT NULL,
                    artifact_reference TEXT NOT NULL,
                    result_json TEXT NOT NULL
                )
                """
            )
        finally:
            connection.close()

    def execute(self, project_id: object, effect_id: object, payload: object) -> dict[str, object]:
        """Apply one deterministic effect or return its verified durable receipt.

        The effect id is global to this service: reuse in another project, or with
        other input, is rejected rather than silently creating a second effect.
        """
        project = _validate_identifier(project_id, "project_id")
        effect = _validate_identifier(effect_id, "effect_id")
        clean_payload = _validate_payload(payload)
        payload_hash = _sha256(_canonical_json(clean_payload))

        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")  # serializes independent callers
            row = connection.execute(
                "SELECT project_id, payload_sha256, artifact_sha256, artifact_reference, result_json "
                "FROM effect_receipts WHERE effect_id = ?",
                (effect,),
            ).fetchone()
            if row is not None:
                if row[0] != project or row[1] != payload_hash:
                    connection.execute("ROLLBACK")
                    raise EffectConflictError("effect_id is already bound to a different project or payload")
                result = self._decode_result_json(row[4])
                self._verify_receipt_artifact(
                    result,
                    row[2],
                    row[3],
                    project,
                    effect,
                    clean_payload,
                )
                connection.execute("COMMIT")
                return result

            output = self._evaluate(clean_payload)
            document = {
                "effect_id": effect,
                "output": output,
                "payload": clean_payload,
                "project_id": project,
                "schema": "agent-stack.fixture-artifact.v1",
            }
            artifact_bytes = _canonical_json(document)
            artifact_hash = _sha256(artifact_bytes)
            reference = f"artifacts/{artifact_hash}.json"
            self._write_immutable(artifact_hash, artifact_bytes)
            result: dict[str, object] = {
                "artifact_reference": reference,
                "artifact_sha256": artifact_hash,
                "effect_id": effect,
                "output": output,
                "project_id": project,
            }
            connection.execute(
                "INSERT INTO effect_receipts "
                "(effect_id, project_id, payload_sha256, artifact_sha256, artifact_reference, result_json) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (effect, project, payload_hash, artifact_hash, reference, _canonical_json(result).decode("ascii")),
            )
            connection.execute("COMMIT")
            return result
        except Exception:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        finally:
            connection.close()

    @classmethod
    def lookup(cls, storage_root: str | Path, project_id: object, effect_id: object, payload: object) -> dict[str, object] | None:
        """Read an existing verified receipt without executing an effect or creating state.

        ``None`` means no receipt database or matching effect exists.  A matching
        effect under another scope/payload, or any corrupted evidence, is an
        explicit error and must be reconciled rather than retried blindly.
        """
        project = _validate_identifier(project_id, "project_id")
        effect = _validate_identifier(effect_id, "effect_id")
        clean_payload = _validate_payload(payload)
        payload_hash = _sha256(_canonical_json(clean_payload))
        root = Path(storage_root).resolve()
        database = root / "fixture-receipts.sqlite3"
        if not root.is_dir() or not database.is_file():
            return None

        # Bypass __init__: it creates service storage, which lookup must never do.
        service = cls.__new__(cls)
        service.root = root
        service.artifacts = root / "artifacts"
        service.database = database
        connection = service._readonly_connection()
        try:
            row = connection.execute(
                "SELECT project_id, payload_sha256, artifact_sha256, artifact_reference, result_json "
                "FROM effect_receipts WHERE effect_id = ?",
                (effect,),
            ).fetchone()
        finally:
            connection.close()
        if row is None:
            return None
        if row[0] != project or row[1] != payload_hash:
            raise EffectConflictError("effect_id is already bound to a different project or payload")
        result = service._decode_result_json(row[4])
        service._verify_receipt_artifact(result, row[2], row[3], project, effect, clean_payload)
        return result

    @staticmethod
    def _decode_result_json(value: object) -> object:
        try:
            return json.loads(value)  # type: ignore[arg-type]
        except (TypeError, json.JSONDecodeError) as error:
            raise ArtifactIntegrityError("receipt result is not valid JSON") from error

    @staticmethod
    def _evaluate(payload: Mapping[str, object]) -> dict[str, int]:
        values = [payload["value"]] if "value" in payload else payload["values"]
        # Values have already been type-checked and bounded above.
        return {"sum": sum(values), "count": len(values)}  # type: ignore[arg-type]

    def _artifact_path(self, reference: str) -> Path:
        if not re.fullmatch(r"artifacts/[0-9a-f]{64}\.json", reference):
            raise ArtifactIntegrityError("receipt contains an unsafe artifact reference")
        self._validate_artifact_directory()
        path = (self.root / reference).resolve()
        if path.parent != self.artifacts:
            raise ArtifactIntegrityError("artifact reference escapes the artifact directory")
        return path

    def _validate_artifact_directory(self) -> None:
        """Ensure this service-owned directory is not an external link/junction."""
        resolved = self.artifacts.resolve()
        if self.artifacts.is_symlink() or resolved.parent != self.root:
            raise ArtifactIntegrityError("artifact directory must not resolve outside the service root")

    def _write_immutable(self, artifact_hash: str, content: bytes) -> None:
        target = self._artifact_path(f"artifacts/{artifact_hash}.json")
        if target.exists():
            if target.read_bytes() != content:
                raise ArtifactIntegrityError("existing content-addressed artifact was modified")
            return
        descriptor, temporary_name = tempfile.mkstemp(prefix=".pending-", dir=self.artifacts)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            # The SQLite write lock means other fixture instances cannot race this
            # target.  Never replace an already-present artifact.
            if target.exists():
                if target.read_bytes() != content:
                    raise ArtifactIntegrityError("existing content-addressed artifact was modified")
            else:
                os.replace(temporary_name, target)
                temporary_name = ""
                self._sync_artifact_directory()
        finally:
            if temporary_name:
                try:
                    os.unlink(temporary_name)
                except FileNotFoundError:
                    pass

    def _sync_artifact_directory(self) -> None:
        """Persist the rename before its SQLite receipt commits where supported.

        POSIX permits fsync on a directory, which makes the rename durable.  The
        Windows standard-library API does not expose a supported directory handle
        for fsync; the already-fsynced file plus atomic ReplaceFile behavior is
        the explicit fallback there.
        """
        if os.name != "posix":
            return
        flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        descriptor = os.open(self.artifacts, flags)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _verify_receipt_artifact(
        self,
        result: object,
        expected_hash: str,
        expected_reference: str,
        project: str,
        effect: str,
        payload: Mapping[str, object],
    ) -> None:
        if not isinstance(result, dict):
            raise ArtifactIntegrityError("receipt result is not a JSON object")
        if not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            raise ArtifactIntegrityError("receipt contains an invalid artifact hash")
        if expected_reference != f"artifacts/{expected_hash}.json":
            raise ArtifactIntegrityError("artifact reference does not name its content hash")
        path = self._artifact_path(expected_reference)
        try:
            actual = path.read_bytes()
        except FileNotFoundError as error:
            raise ArtifactIntegrityError("receipt artifact is missing") from error
        if _sha256(actual) != expected_hash:
            raise ArtifactIntegrityError("artifact hash mismatch; evidence is corrupted")
        try:
            document = json.loads(actual)
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ArtifactIntegrityError("hashed artifact is not valid JSON") from error
        expected_output = self._evaluate(payload)
        expected_document = {
            "effect_id": effect,
            "output": expected_output,
            "payload": dict(payload),
            "project_id": project,
            "schema": "agent-stack.fixture-artifact.v1",
        }
        if document != expected_document or actual != _canonical_json(expected_document):
            raise ArtifactIntegrityError("artifact does not match the canonical deterministic effect")
        expected_result = {
            "artifact_reference": expected_reference,
            "artifact_sha256": expected_hash,
            "effect_id": effect,
            "output": expected_output,
            "project_id": project,
        }
        if result != expected_result:
            raise ArtifactIntegrityError("receipt result does not match its canonical artifact")


def execute_fixture(storage_root: str | Path, project_id: object, effect_id: object, payload: object) -> dict[str, object]:
    """Convenience API for a short-lived worker process."""
    return FixtureService(storage_root).execute(project_id, effect_id, payload)


def lookup_fixture(storage_root: str | Path, project_id: object, effect_id: object, payload: object) -> dict[str, object] | None:
    """Read-only convenience API for reconciliation and completed-result replay."""
    return FixtureService.lookup(storage_root, project_id, effect_id, payload)
