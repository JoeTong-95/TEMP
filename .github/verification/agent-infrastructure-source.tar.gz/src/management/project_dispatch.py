"""Durable, explicit dispatch of accepted project-start intents.

This module is deliberately execution-engine agnostic.  It consumes the
immutable ``ProjectControl.outbox()`` journal and invokes an injected submitter
with the journal's stable intent id as the idempotency key.  A crashed or
ambiguous submission is never retried automatically: it is reconciled through
the submitter's lookup operation first.
"""
from __future__ import annotations

import json
import math
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator, Mapping, Protocol

from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


class StartIntentSource(Protocol):
    def outbox(self) -> list[dict[str, Any]]: ...


class ExecutionSubmitter(Protocol):
    def submit(self, intent_id: str, body: Mapping[str, Any]) -> Mapping[str, Any]: ...
    def lookup(self, intent_id: str) -> Mapping[str, Any] | None: ...


AuthoritativeValidator = Callable[[str, Mapping[str, Any]], bool]
_STATES = {"pending", "submitting", "submitted", "rejected", "needs_reconciliation"}


def _canonical(value: Mapping[str, Any]) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


class ProjectIntentDispatcher:
    """One explicit ``tick`` claims at most one eligible start intent."""

    def __init__(
        self,
        database: str | Path,
        intents: StartIntentSource,
        validator: AuthoritativeValidator,
        submitter: ExecutionSubmitter,
        *,
        clock: Callable[[], float] = time.time,
        claim_lease_seconds: float = 30.0,
        state_root: str | Path | None = None,
    ) -> None:
        try:
            self.database = validate_durable_leaf(
                Path(database),
                validate_state_root(state_root if state_root is not None else Path(database).parent, "Management dispatch state root"),
                label="Management dispatch database",
            )
        except (ManagementStateBoundaryError, TypeError) as error:
            raise ValueError("dispatcher database is unsafe") from error
        self.intents = intents
        self.validator = validator
        self.submitter = submitter
        if isinstance(claim_lease_seconds, bool) or not isinstance(claim_lease_seconds, (int, float)) or not math.isfinite(claim_lease_seconds) or claim_lease_seconds <= 0:
            raise ValueError("claim lease must be positive")
        self.clock = clock
        self.claim_lease_seconds = claim_lease_seconds
        with self._connection() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS project_dispatches(
                    intent_id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    body TEXT NOT NULL,
                    state TEXT NOT NULL CHECK(state IN ('pending','submitting','submitted','rejected','needs_reconciliation')),
                    claimant TEXT,
                    generation INTEGER NOT NULL DEFAULT 0,
                    lease_until REAL,
                    receipt TEXT,
                    detail TEXT
                )
                """
            )

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.database)
        connection.row_factory = sqlite3.Row
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def records(self) -> list[dict[str, Any]]:
        with self._connection() as connection:
            rows = connection.execute("SELECT * FROM project_dispatches ORDER BY intent_id").fetchall()
        return [
            {**dict(row), "body": json.loads(row["body"]), "receipt": json.loads(row["receipt"]) if row["receipt"] else None}
            for row in rows
        ]

    def _sync(self) -> None:
        for entry in self.intents.outbox():
            intent_id = entry.get("intent_id")
            project_id = entry.get("project_id")
            revision = entry.get("revision")
            body = entry.get("body")
            if not isinstance(intent_id, str) or not intent_id or not isinstance(project_id, str) or not project_id or type(revision) is not int or revision < 1 or not isinstance(body, Mapping):
                raise ValueError("project outbox entry has an invalid start intent shape")
            canonical_body = _canonical(body)
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                existing = connection.execute("SELECT project_id,revision,body FROM project_dispatches WHERE intent_id=?", (intent_id,)).fetchone()
                if existing is None:
                    connection.execute("INSERT INTO project_dispatches(intent_id,project_id,revision,body,state) VALUES(?,?,?,?, 'pending')", (intent_id, project_id, revision, canonical_body))
                elif existing["project_id"] != project_id or existing["revision"] != revision or existing["body"] != canonical_body:
                    raise ValueError("project outbox reused an intent_id with conflicting content")

    def _claim_pending(self, claimant: str) -> dict[str, Any] | None:
        if not isinstance(claimant, str) or not claimant:
            raise ValueError("claimant is required")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM project_dispatches WHERE state='pending' ORDER BY intent_id LIMIT 1").fetchone()
            if row is None:
                return None
            generation = row["generation"] + 1
            lease_until = self.clock() + self.claim_lease_seconds
            changed = connection.execute(
                "UPDATE project_dispatches SET state='submitting',claimant=?,generation=?,lease_until=?,detail=NULL WHERE intent_id=? AND state='pending'",
                (claimant, generation, lease_until, row["intent_id"]),
            ).rowcount
            if changed != 1:
                return None
            return {**dict(row), "generation": generation, "claimant": claimant, "lease_until": lease_until, "body": json.loads(row["body"])}

    def _set_state(self, intent_id: str, generation: int, state: str, *, receipt: Mapping[str, Any] | None = None, detail: str | None = None) -> bool:
        if state not in _STATES:
            raise ValueError("invalid dispatch state")
        receipt_text = _canonical(receipt) if receipt is not None else None
        with self._connection() as connection:
            changed = connection.execute(
                "UPDATE project_dispatches SET state=?,receipt=COALESCE(?,receipt),detail=?,lease_until=NULL WHERE intent_id=? AND generation=? AND state='submitting'",
                (state, receipt_text, detail, intent_id, generation),
            ).rowcount
        return changed == 1

    @staticmethod
    def _valid_receipt(intent_id: str, receipt: Mapping[str, Any] | None) -> bool:
        return isinstance(receipt, Mapping) and receipt.get("intent_id") == intent_id and isinstance(receipt.get("execution_id"), str) and bool(receipt["execution_id"])

    def _reconcile(self) -> int:
        now = self.clock()
        with self._connection() as connection:
            rows = connection.execute("SELECT intent_id,generation,state FROM project_dispatches WHERE state='needs_reconciliation' OR (state='submitting' AND lease_until<=?) ORDER BY intent_id", (now,)).fetchall()
        reconciled = 0
        for row in rows:
            try:
                receipt = self.submitter.lookup(row["intent_id"])
            except Exception as error:
                if row["state"] == "submitting":
                    self._set_state(row["intent_id"], row["generation"], "needs_reconciliation", detail=f"lookup failed: {type(error).__name__}")
                continue
            if not self._valid_receipt(row["intent_id"], receipt):
                if row["state"] == "submitting":
                    self._set_state(row["intent_id"], row["generation"], "needs_reconciliation", detail="lookup did not return a matching durable execution receipt")
                continue
            with self._connection() as connection:
                changed = connection.execute(
                    "UPDATE project_dispatches SET state='submitted',receipt=?,detail=NULL,lease_until=NULL WHERE intent_id=? AND generation=? AND state IN ('submitting','needs_reconciliation')",
                    (_canonical(receipt), row["intent_id"], row["generation"]),
                ).rowcount
            reconciled += changed
        return reconciled

    def tick(self, claimant: str) -> dict[str, int]:
        """Synchronize intents, reconcile uncertainty, then submit at most one claim."""
        self._sync()
        reconciled = self._reconcile()
        claim = self._claim_pending(claimant)
        if claim is None:
            return {"submitted": 0, "rejected": 0, "reconciled": reconciled}
        body = claim["body"]
        payload = body.get("payload")
        if not isinstance(payload, Mapping):
            self._set_state(claim["intent_id"], claim["generation"], "rejected", detail="start intent payload is malformed")
            return {"submitted": 0, "rejected": 1, "reconciled": reconciled}
        try:
            allowed = self.validator(claim["project_id"], json.loads(_canonical(payload)))
        except Exception as error:
            allowed = False
            detail = f"authoritative validation failed: {type(error).__name__}"
        else:
            if isinstance(allowed, Mapping):
                detail = allowed.get("detail")
                if not detail:
                    dependency = allowed.get("unavailable_dependency")
                    reason = allowed.get("reason")
                    detail = "authoritative grants or providers rejected the current intent"
                    if dependency:
                        detail += f": {dependency}"
                    if reason:
                        detail += f" ({reason})"
                detail = str(detail)
                allowed = allowed.get("eligible") is True
            else:
                detail = "authoritative grants or providers rejected the current intent"
        if allowed is not True:
            self._set_state(claim["intent_id"], claim["generation"], "rejected", detail=detail)
            return {"submitted": 0, "rejected": 1, "reconciled": reconciled}
        try:
            receipt = self.submitter.submit(claim["intent_id"], body)
        except Exception as error:
            self._set_state(claim["intent_id"], claim["generation"], "needs_reconciliation", detail=f"submission result unknown: {type(error).__name__}")
            return {"submitted": 0, "rejected": 0, "reconciled": reconciled}
        if not self._valid_receipt(claim["intent_id"], receipt):
            self._set_state(claim["intent_id"], claim["generation"], "needs_reconciliation", detail="submission did not return a matching durable execution receipt")
            return {"submitted": 0, "rejected": 0, "reconciled": reconciled}
        submitted = self._set_state(claim["intent_id"], claim["generation"], "submitted", receipt=receipt)
        return {"submitted": int(submitted), "rejected": 0, "reconciled": reconciled}
