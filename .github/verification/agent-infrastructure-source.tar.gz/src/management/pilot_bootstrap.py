"""Apply reviewed local pilot bindings without editing a graph definition."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import Any

from .pilot_store import PilotStore

_PROJECTS={'platform-canary-a','platform-canary-b'}


def apply_bindings(state_dir: str | Path, definition_hash: str, bindings_path: str | Path) -> list[str]:
    document: Any = json.loads(Path(bindings_path).read_text(encoding='utf-8'))
    if not isinstance(document, dict) or set(document) != {'schema', 'bindings'} or document['schema'] != 'agent-stack.pilot-bindings.v1' or not isinstance(document['bindings'], list):
        raise ValueError('invalid pilot bindings document')
    store = PilotStore(Path(state_dir) / 'pilot-control.sqlite3')
    definition = store.definition(definition_hash)
    agent = next(node for node in definition['nodes'] if node['kind'] == 'agent')
    written: list[str] = []
    for binding in document['bindings']:
        if not isinstance(binding, dict) or set(binding) != {'project_id', 'model_ref', 'memory_ref'} or not all(isinstance(binding[key], str) and binding[key] for key in binding):
            raise ValueError('invalid pilot binding')
        if binding['project_id'] not in _PROJECTS:
            raise ValueError('unknown pilot project')
        if binding['model_ref'] != agent['config']['model_ref'] or binding['memory_ref'] != agent['config']['memory_ref']:
            raise ValueError('binding references must match immutable definition')
        store.bind(binding['project_id'], definition_hash, binding['model_ref'], binding['memory_ref'])
        written.append(binding['project_id'])
    return written


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--state-dir', required=True)
    parser.add_argument('--definition-hash', required=True)
    parser.add_argument('--bindings', required=True)
    args = parser.parse_args()
    print(json.dumps({'bound_projects': apply_bindings(args.state_dir, args.definition_hash, args.bindings)}, sort_keys=True))


if __name__ == '__main__':
    main()
