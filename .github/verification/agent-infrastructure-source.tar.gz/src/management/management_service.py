"""Fail-closed composition for the Management control-plane foundations.

This module constructs durable registries and the loopback management API.  It
does not run a scheduler or execute project work: a successful project ``start``
is only a durable intent that a future executor must consume explicitly.

Credential-bearing JSON is supplied by an operator-selected external file.  It
is deliberately not searched for, generated, logged, or stored by this module.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from datetime import datetime, timezone
import http.client
import json
import math
import os
import re
from pathlib import Path
from typing import Any, Callable, Mapping
from urllib.parse import urlsplit

from .hardware_registry import HardwareRegistry
from .management_api import ManagementApiConfig, ManagementApiServer, Principal, serve
from .project_control import ProjectControl
from .provider_registry import ProviderRegistry
from .resource_grants import ResourceGrants
from .management_execution_plan import ManagementExecutionPlanner
from .orchestrator_management import ProjectOrchestratorRegistry
from .model_capability_catalog import ModelCapabilityCatalog
from .catalog_admission import CatalogAdmission
from .inference_lifecycle import InferenceLifecycleCoordinator, InferenceProvider, InferenceProviderClient
from .usage_reporting import UsageReportingStore
from shared.contracts.storage_merge import MergeAuthorityClientConfiguration, MergeAuthorityClientError, build_merge_submitter
from shared.contracts.credentials import SecretValidationError, read_bounded_secret
from .management_runtime_control import ManagementRuntimeControl
from shared.contracts.agent_runtime import RuntimeBinding, RuntimeClient, RuntimeClientError
from .software_node_lifecycle import SoftwareNodeLifecycleJournal
from .github_frontier import GitHubFrontier, GitHubFrontierError, GitHubFrontierStore, GitHubFrontierUnavailable, GitHubFrontierService, HttpGitHubFrontierAdapter, _is_reparse_point
from .state_boundary import (
    MANAGEMENT_ROLE,
    MANAGEMENT_SERVICE_PRINCIPAL,
    ManagementStateBoundary,
    ManagementStateBoundaryError,
    validate_durable_directory,
    validate_durable_leaf,
    validate_state_root,
)
from shared.contracts.project_reference import validate_project_infrastructure_references


class ManagementServiceError(ValueError):
    """Raised when durable service composition or live validation is unsafe."""


Clock = Callable[[], datetime]
_MAX_TOKEN_BYTES = 4096


def _read_bounded_token(path: Path, label: str) -> str:
    """Read and validate one token without retaining an oversized secret."""
    try:
        return read_bounded_secret(path, max_bytes=_MAX_TOKEN_BYTES)
    except OSError as error:
        raise ManagementServiceError(f"{label} is unavailable") from error
    except (UnicodeDecodeError, SecretValidationError) as error:
        raise ManagementServiceError(f"{label} is invalid") from error


@dataclass(frozen=True)
class ManagementRoleIdentity:
    """The dedicated process identity and declared state roots for Management."""

    role: str
    service_principal: str
    state_root: Path
    state_roots: tuple[Path, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.role, str) or self.role != MANAGEMENT_ROLE:
            raise ManagementServiceError("configuration role is not Management")
        try:
            boundary = ManagementStateBoundary(self.service_principal, Path(self.state_root), tuple(Path(value) for value in self.state_roots))
        except (TypeError, ManagementStateBoundaryError) as error:
            raise ManagementServiceError(str(error)) from error
        object.__setattr__(self, "state_root", boundary.state_root)
        object.__setattr__(self, "state_roots", boundary.state_roots)

    @property
    def boundary(self) -> ManagementStateBoundary:
        return ManagementStateBoundary(self.service_principal, self.state_root, self.state_roots)

    def owns(self, path: Path, *, directory: bool = False, allow_missing: bool = True) -> bool:
        """Return whether a durable path belongs to one declared state root."""
        return self.boundary.owns(path, directory=directory, allow_missing=allow_missing)


def _private_file(path: Path, label: str) -> Path:
    """Return one explicit file, rejecting indirection and public POSIX modes."""
    if not path.is_absolute() or path.is_symlink() or _is_reparse_point(path) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in path.parents) or not path.is_file():
        raise ManagementServiceError(f"{label} is unsafe")
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise ManagementServiceError(f"{label} must not be group or world readable")
    return path.resolve(strict=True)


@dataclass(frozen=True)
class DatabaseLocations:
    """Explicit, local durable database files; their parent directories pre-exist."""

    hardware: Path
    providers: Path
    grants: Path
    projects: Path
    catalog: Path | None = None
    reporting: Path | None = None
    lifecycle: Path | None = None

    def __post_init__(self) -> None:
        paths = (self.hardware, self.providers, self.grants, self.projects) + ((self.catalog,) if self.catalog is not None else ()) + ((self.reporting,) if self.reporting is not None else ()) + ((self.lifecycle,) if self.lifecycle is not None else ())
        if any(not isinstance(path, Path) or not path.is_absolute() or path.name == "" for path in paths):
            raise ManagementServiceError("durable database locations must be explicit absolute file paths")
        try:
            normalized = tuple(validate_durable_leaf(path, validate_state_root(path.parent, "Management database state root"), label="Management database") for path in paths)
        except ManagementStateBoundaryError as error:
            raise ManagementServiceError(str(error)) from error
        if len(set(normalized)) != len(normalized):
            raise ManagementServiceError("each control core requires its own database file")
        names = ("hardware", "providers", "grants", "projects") + (("catalog",) if self.catalog is not None else ()) + (("reporting",) if self.reporting is not None else ()) + (("lifecycle",) if self.lifecycle is not None else ())
        for name, path in zip(names, normalized):
            object.__setattr__(self, name, path)


@dataclass(frozen=True)
class VerificationClientConfiguration:
    """One explicit, bounded capability to submit verification evidence.

    The bearer value is read only from the operator-selected file while the
    service is composed.  It is intentionally not an environment lookup.
    """

    host: str
    port: int
    bearer_token_file: Path
    timeout_seconds: float = 2.0
    max_response_bytes: int = 64 * 1024

    def __post_init__(self) -> None:
        token_file = Path(self.bearer_token_file)
        if self.host != "127.0.0.1" or type(self.port) is not int or not 1 <= self.port <= 65535:
            raise ManagementServiceError("verification client must use an explicit loopback endpoint")
        if isinstance(self.timeout_seconds, bool) or not isinstance(self.timeout_seconds, (int, float)) or not math.isfinite(self.timeout_seconds) or not 0 < self.timeout_seconds <= 30:
            raise ManagementServiceError("verification client timeout is invalid")
        if type(self.max_response_bytes) is not int or not 1 <= self.max_response_bytes <= 64 * 1024:
            raise ManagementServiceError("verification client response bound is invalid")
        object.__setattr__(self, "bearer_token_file", _private_file(token_file, "verification bearer token file"))


@dataclass(frozen=True)
class GitHubFrontierConfiguration:
    """Explicit local cache and scoped GitHub read credentials for issue reads."""

    database: Path
    bearer_token_files: Mapping[str, Path]
    api_origin: str = "https://api.github.com"
    timeout_seconds: float = 10.0
    max_response_bytes: int = 512 * 1024

    def __post_init__(self) -> None:
        database = Path(self.database)
        if not database.is_absolute() or database.is_symlink() or _is_reparse_point(database) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in database.parents) or not database.parent.is_dir():
            raise ManagementServiceError("GitHub frontier database location is unsafe")
        parsed = urlsplit(self.api_origin)
        try:
            port = parsed.port
        except ValueError as error:
            raise ManagementServiceError("GitHub frontier origin is invalid") from error
        if parsed.scheme != "https" or parsed.hostname is None or parsed.hostname.casefold() != "api.github.com" or port not in {None, 443} or parsed.username or parsed.password or parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
            raise ManagementServiceError("GitHub frontier origin is invalid")
        if isinstance(self.timeout_seconds, bool) or not isinstance(self.timeout_seconds, (int, float)) or not math.isfinite(self.timeout_seconds) or not 0 < self.timeout_seconds <= 30:
            raise ManagementServiceError("GitHub frontier timeout is invalid")
        if type(self.max_response_bytes) is not int or not 1 <= self.max_response_bytes <= 2 * 1024 * 1024:
            raise ManagementServiceError("GitHub frontier response bound is invalid")
        if not isinstance(self.bearer_token_files, Mapping) or not self.bearer_token_files:
            raise ManagementServiceError("GitHub frontier identities are required")
        tokens: dict[str, Path] = {}
        for identity, token_file in self.bearer_token_files.items():
            if not isinstance(identity, str) or not identity or len(identity) > 128 or any(character.isspace() for character in identity):
                raise ManagementServiceError("GitHub frontier identity is invalid")
            tokens[identity] = _private_file(Path(token_file), "GitHub frontier token file")
        object.__setattr__(self, "database", database.resolve(strict=False))
        object.__setattr__(self, "bearer_token_files", tokens)
        object.__setattr__(self, "api_origin", self.api_origin.rstrip("/"))


def build_github_frontier_service(projects: ProjectControl, configuration: GitHubFrontierConfiguration, *, clock: Clock | None = None) -> GitHubFrontierService:
    """Build a bounded GET-only GitHub adapter without persisting credentials."""
    tokens: dict[str, str] = {}
    for identity, token_file in configuration.bearer_token_files.items():
        try:
            token = token_file.read_text(encoding="utf-8").strip()
        except (OSError, UnicodeDecodeError) as error:
            raise ManagementServiceError("GitHub frontier token is unavailable") from error
        if not token or len(token) > 4096 or not token.isascii() or any(character.isspace() for character in token):
            raise ManagementServiceError("GitHub frontier token is invalid")
        tokens[identity] = token

    origin = urlsplit(configuration.api_origin)

    def adapter_factory(binding: Mapping[str, Any]) -> HttpGitHubFrontierAdapter:
        identity = binding.get("identity")
        token = tokens.get(identity) if isinstance(identity, str) else None
        if token is None:
            raise GitHubFrontierError("accepted GitHub binding identity is unavailable")
        repository = binding.get("repository_url")

        def request(path: str) -> tuple[int, Any]:
            parsed = urlsplit(path)
            if parsed.scheme or parsed.netloc or not parsed.path.startswith("/repos/") or parsed.fragment:
                raise GitHubFrontierUnavailable("GitHub frontier request is invalid")
            connection = http.client.HTTPSConnection(origin.hostname, origin.port or 443, timeout=configuration.timeout_seconds)
            try:
                connection.request("GET", path, headers={"Authorization": "Bearer " + token, "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "agent-stack-github-frontier/1"})
                response = connection.getresponse()
                raw = response.read(configuration.max_response_bytes + 1)
                if len(raw) > configuration.max_response_bytes:
                    raise GitHubFrontierUnavailable("GitHub frontier response exceeds bound")
                try:
                    return response.status, json.loads(raw.decode("utf-8")) if raw else None
                except (UnicodeDecodeError, json.JSONDecodeError) as error:
                    raise GitHubFrontierUnavailable("GitHub frontier response is invalid") from error
            except OSError as error:
                raise GitHubFrontierUnavailable("GitHub frontier transport is unavailable") from error
            finally:
                connection.close()

        return HttpGitHubFrontierAdapter(repository, request)

    return GitHubFrontierService(projects, GitHubFrontier(GitHubFrontierStore(configuration.database, clock=clock)), adapter_factory)


@dataclass(frozen=True)
class RuntimeControlConfiguration:
    """Explicit runtime routes and journal for attended operator actions."""

    database: Path
    runtime: RuntimeClient
    sessions: Mapping[str, Mapping[str, str]]
    state_root: Path | None = None

    def __post_init__(self) -> None:
        database = Path(self.database)
        try:
            state_root = validate_state_root(self.state_root if self.state_root is not None else database.parent, "runtime control state root")
            database = validate_durable_leaf(database, state_root, label="runtime control database")
        except ManagementStateBoundaryError as error:
            raise ManagementServiceError(str(error)) from error
        if not isinstance(self.runtime, RuntimeClient) or not isinstance(self.sessions, Mapping) or not self.sessions:
            raise ManagementServiceError("runtime control configuration is invalid")
        copied = {project: dict(rows) for project, rows in self.sessions.items()}
        if any(not isinstance(project, str) or not project or not isinstance(rows, Mapping) or not rows or any(not isinstance(session, str) or not session or not isinstance(binding, str) or not binding for session, binding in rows.items()) for project, rows in copied.items()):
            raise ManagementServiceError("runtime control session routes are invalid")
        object.__setattr__(self, "database", database); object.__setattr__(self, "state_root", state_root); object.__setattr__(self, "sessions", copied)


@dataclass(frozen=True)
class ManagementServiceConfig:
    databases: DatabaseLocations
    api: ManagementApiConfig
    hardware_stale_after_seconds: int = 60
    grant_capacity_age_seconds: int = 60
    runtime_bindings: Mapping[str, str] = field(default_factory=dict)
    verification_actions: Mapping[str, Mapping[str, str]] = field(default_factory=dict)
    # These integrations remain absent unless an operator deliberately names
    # them in the external configuration.  No discovery or implicit roots.
    orchestrator_loop_root: Path | None = None
    verification_client: VerificationClientConfiguration | None = None
    merge_client: MergeAuthorityClientConfiguration | None = None
    runtime_control: RuntimeControlConfiguration | None = None
    github_frontier: GitHubFrontierConfiguration | None = None
    # Appended to preserve the positional constructor contract of the legacy
    # freshness and integration fields above.
    role_identity: ManagementRoleIdentity | None = None
    inference_provider_token_files: Mapping[str, Path] = field(default_factory=dict)

    def __post_init__(self) -> None:
        legacy_compatibility = self.role_identity is None
        if not legacy_compatibility and not isinstance(self.role_identity, ManagementRoleIdentity):
            raise ManagementServiceError("Management role identity is invalid")
        for value in (self.hardware_stale_after_seconds, self.grant_capacity_age_seconds):
            if type(value) is not int or value < 1:
                raise ManagementServiceError("freshness windows must be positive integers")
        if not isinstance(self.runtime_bindings, Mapping) or any(not isinstance(key, str) or not key or not isinstance(value, str) or not value for key, value in self.runtime_bindings.items()):
            raise ManagementServiceError("runtime binding allowlist must be a string map")
        if not isinstance(self.verification_actions, Mapping) or any(not isinstance(project, str) or not project or not isinstance(action, Mapping) or set(action) != {"workspace_id", "command_id"} or any(not isinstance(value, str) or not value for value in action.values()) for project, action in self.verification_actions.items()):
            raise ManagementServiceError("verification action allowlist must be a string map")
        if self.orchestrator_loop_root is not None:
            root = Path(self.orchestrator_loop_root)
            try:
                object.__setattr__(self, "orchestrator_loop_root", validate_durable_directory(root, validate_state_root(root, "orchestrator loop state root"), label="orchestrator loop root"))
            except ManagementStateBoundaryError as error:
                raise ManagementServiceError(str(error)) from error
        if self.verification_client is not None and not isinstance(self.verification_client, VerificationClientConfiguration):
            raise ManagementServiceError("verification client configuration is invalid")
        if self.merge_client is not None and not isinstance(self.merge_client, MergeAuthorityClientConfiguration):
            raise ManagementServiceError("merge client configuration is invalid")
        if self.runtime_control is not None and not isinstance(self.runtime_control, RuntimeControlConfiguration):
            raise ManagementServiceError("runtime control configuration is invalid")
        if self.github_frontier is not None and not isinstance(self.github_frontier, GitHubFrontierConfiguration):
            raise ManagementServiceError("GitHub frontier configuration is invalid")
        if legacy_compatibility:
            # Role-omitted files predate a single Management state root.  Keep
            # those files loadable by deriving the compatibility boundary from
            # every configured durable location, including optional journals
            # and worker roots.  The explicit-role path below remains strict.
            roots: list[Path] = [
                path.parent
                for path in (
                    self.databases.hardware,
                    self.databases.providers,
                    self.databases.grants,
                    self.databases.projects,
                    self.databases.catalog,
                    self.databases.reporting,
                    self.databases.lifecycle,
                )
                if path is not None
            ]
            if self.runtime_control is not None:
                roots.extend((self.runtime_control.database.parent, self.runtime_control.state_root))
            if self.orchestrator_loop_root is not None:
                roots.append(self.orchestrator_loop_root)
            unique_roots: list[Path] = []
            for root in roots:
                resolved = root.resolve(strict=True)
                if resolved not in unique_roots:
                    unique_roots.append(resolved)
            object.__setattr__(
                self,
                "role_identity",
                ManagementRoleIdentity(MANAGEMENT_ROLE, MANAGEMENT_SERVICE_PRINCIPAL, unique_roots[0], tuple(unique_roots[1:])),
            )
        durable_paths = (
            self.databases.hardware,
            self.databases.providers,
            self.databases.grants,
            self.databases.projects,
            self.databases.catalog,
            self.databases.reporting,
            self.databases.lifecycle,
            self.runtime_control.database if self.runtime_control is not None else None,
        )
        if any(path is not None and not self.role_identity.owns(path) for path in durable_paths):
            raise ManagementServiceError("Management durable state must remain under its owned state root")
        if self.runtime_control is not None and self.runtime_control.state_root is not None and not self.role_identity.owns(self.runtime_control.state_root, directory=True):
            raise ManagementServiceError("Management runtime control state must remain under its owned state root")
        if self.orchestrator_loop_root is not None and not self.role_identity.owns(self.orchestrator_loop_root, directory=True):
            raise ManagementServiceError("Management orchestrator state must remain under its owned state root")


@dataclass
class ManagementService:
    hardware: HardwareRegistry
    providers: ProviderRegistry
    grants: ResourceGrants
    projects: ProjectControl
    api_server: ManagementApiServer
    orchestrators: ProjectOrchestratorRegistry | None = None
    reporting: UsageReportingStore | None = None
    runtime_control: ManagementRuntimeControl | None = None
    lifecycle: SoftwareNodeLifecycleJournal | None = None
    role_identity: ManagementRoleIdentity | None = None


def build_verification_submitter(configuration: VerificationClientConfiguration) -> Callable[[Mapping[str, str]], Mapping[str, Any]]:
    """Return an authenticated, one-request loopback submitter with hard bounds.

    It exposes neither the token nor transport failure details to API callers.
    The Management API independently validates the returned evidence schema.
    """
    try:
        token = configuration.bearer_token_file.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError) as error:
        raise ManagementServiceError("verification bearer token is unavailable") from error
    if not token or len(token) > 4096 or not token.isascii() or any(character.isspace() for character in token):
        raise ManagementServiceError("verification bearer token is invalid")

    def submit(action: Mapping[str, str]) -> Mapping[str, Any]:
        required = {"operation_id", "project_id", "workspace_id", "command_id", "expected_input_tree_sha256", "kind"}
        digest = action.get("expected_input_tree_sha256") if isinstance(action, Mapping) else None
        if not isinstance(action, Mapping) or set(action) != required or action.get("kind") != "project_verification_evidence" or any(not isinstance(action.get(key), str) or not action[key] for key in required) or not isinstance(digest, str) or len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
            raise ManagementServiceError("verification action is invalid")
        payload = json.dumps({key: action[key] for key in action if key != "kind"}, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
        if len(payload) > 64 * 1024:
            raise ManagementServiceError("verification action exceeds bounds")
        connection = http.client.HTTPConnection(configuration.host, configuration.port, timeout=configuration.timeout_seconds)
        try:
            connection.request("POST", "/operations", payload, {"Authorization": "Bearer " + token, "Content-Type": "application/json", "Content-Length": str(len(payload))})
            response = connection.getresponse()
            raw = response.read(configuration.max_response_bytes + 1)
            if response.status not in {200, 202} or len(raw) > configuration.max_response_bytes:
                raise ManagementServiceError("verification submit was rejected")
            value = json.loads(raw.decode("utf-8"))
            if not isinstance(value, Mapping):
                raise ManagementServiceError("verification submit returned invalid evidence")
            return dict(value)
        except (OSError, ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
            if isinstance(error, ManagementServiceError):
                raise
            raise ManagementServiceError("verification submit is unavailable") from error
        finally:
            connection.close()

    return submit


def build_live_project_admission(grants: ResourceGrants, providers: ProviderRegistry) -> Callable[[str, dict[str, Any]], dict[str, Any]]:
    """Build the shared composite readiness and admission projection."""
    def admit(project_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            validate_project_infrastructure_references(payload)
        except (TypeError, ValueError) as error:
            return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "project_reference", "reason": str(error)}
        dependencies: list[dict[str, Any]] = []
        pool_id = payload.get("resource_pool_id")
        quantities = payload.get("resource_requested_envelope")
        if not isinstance(pool_id, str) or not pool_id or not isinstance(quantities, Mapping):
            return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "resource_grant"}
        try:
            pool = grants.pool_projection(pool_id)
        except ValueError:
            pool = None
        if pool is None or pool.get("fresh") is not True:
            return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": f"resource_pool:{pool_id}", "reason": "resource capacity evidence is stale or missing"}
        if not grants.can_start(project_id, {"pool_id": pool_id, "quantities": quantities}):
            return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": f"resource_grant:{project_id}", "reason": "resource grant is unavailable"}

        selected_provider_id = pool.get("provider_id")
        selected_node_id = pool.get("hardware_node_id")
        if not isinstance(selected_provider_id, str) or not isinstance(selected_node_id, str):
            return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": f"resource_pool:{pool_id}"}
        explicit_provider_id = payload.get("provider_reference")
        explicit_hardware_id = payload.get("hardware_reference")
        if explicit_provider_id is not None:
            provider = providers.get(explicit_provider_id) if isinstance(explicit_provider_id, str) else None
            if provider is None:
                return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "provider_reference", "reason": "provider is not registered"}
            if provider.get("provider_id") != selected_provider_id:
                return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "provider_reference", "reason": "provider does not back the selected resource pool"}
        if explicit_hardware_id is not None:
            node = providers.hardware.get_snapshot(explicit_hardware_id) if isinstance(explicit_hardware_id, str) else None
            if node is None:
                return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "hardware_reference", "reason": "hardware node is not registered"}
            if explicit_hardware_id != selected_node_id:
                return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "hardware_reference", "reason": "hardware node does not back the selected resource pool"}

        agents = payload.get("agents")
        if not isinstance(agents, list) or not agents:
            return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "agent_bindings"}
        logical_bindings: list[str] = []
        for agent in agents:
            bindings = agent.get("capability_bindings") if isinstance(agent, Mapping) else None
            if not isinstance(bindings, list) or not bindings or not all(isinstance(binding, str) and binding for binding in bindings):
                return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "agent_bindings"}
            logical_bindings.extend(bindings)
        declared_references = payload.get("binding_references")
        if isinstance(declared_references, list):
            logical_bindings.extend(binding for binding in declared_references if isinstance(binding, str) and binding)
        explicit_storage = payload.get("storage_binding")
        if isinstance(explicit_storage, str) and explicit_storage:
            logical_bindings.append(explicit_storage)
        logical_bindings = list(dict.fromkeys(logical_bindings))

        pool_backs_inference = False
        for logical_binding in logical_bindings:
            row = next((item for item in providers.list_bindings() if item["logical_binding"] == logical_binding), None)
            if row is None:
                dependencies.append({"dependency": logical_binding, "eligible": False, "reasons": ["binding_not_registered"]})
                continue
            provider = providers.get(row["provider_id"])
            if not isinstance(provider, Mapping) or provider.get("generation") != row.get("provider_generation"):
                dependencies.append({"dependency": logical_binding, "capability": row["capability"], "provider_id": row["provider_id"], "eligible": False, "reasons": ["binding_provider_generation_stale"]})
                continue
            report = providers.readiness(row["provider_id"], [row["capability"]])
            dependency = {"dependency": logical_binding, "capability": row["capability"], "provider_id": row["provider_id"], "eligible": report["eligible"], "checks": report["checks"], "reasons": report["reasons"]}
            expected_role = ("agent-runtime" if row["capability"].startswith("runtime.") or logical_binding.startswith("runtime.") else
                             "storage" if row["capability"].startswith("storage.") or logical_binding.startswith("storage.") else
                             "inference" if row["capability"].startswith("inference.") or logical_binding.startswith("inference.") else None)
            if expected_role is not None and provider.get("role") != expected_role:
                dependency["eligible"] = False
                dependency["expected_role"] = expected_role
                dependency["actual_role"] = provider.get("role")
                dependency["reasons"] = ["provider_role_mismatch"]
            dependencies.append(dependency)
            if isinstance(provider, Mapping) and provider.get("role") == "inference" and expected_role != "agent-runtime":
                if provider.get("provider_id") == selected_provider_id and provider.get("hardware_node_id") == selected_node_id and report["eligible"]:
                    pool_backs_inference = True
                elif provider.get("provider_id") != selected_provider_id or provider.get("hardware_node_id") != selected_node_id:
                    dependency["eligible"] = False
                    dependency["reasons"] = ["inference_provider_does_not_back_grant"]

        storage_policy = payload.get("storage_policy")
        forge_binding = payload.get("forge_binding")
        gitea_declared = ((isinstance(storage_policy, Mapping) and storage_policy.get("repository") == "gitea") or
                          (isinstance(forge_binding, Mapping) and forge_binding.get("provider") == "gitea"))
        if gitea_declared and not any(item.get("capability") == "storage.git" for item in dependencies):
            dependencies.append({"dependency": "storage.git", "capability": "storage.git", "eligible": False, "reasons": ["optional_capability_declared_without_binding"]})

        failed = next((item for item in dependencies if item.get("eligible") is not True), None)
        if not pool_backs_inference:
            failed = failed or {"dependency": "inference", "reasons": ["inference_binding_does_not_back_grant"]}
        if failed is not None:
            return {"schema": "agent-stack.project-admission", "eligible": False, "status": "unavailable", "dependencies": dependencies, "unavailable_dependency": failed.get("dependency"), "reason": "; ".join(failed.get("reasons", []))}
        return {"schema": "agent-stack.project-admission", "eligible": True, "status": "ready", "dependencies": dependencies, "unavailable_dependency": None, "resource_pool": pool_id}

    return admit


def build_live_project_validator(grants: ResourceGrants, providers: ProviderRegistry) -> Callable[[str, dict[str, Any]], bool]:
    admission = build_live_project_admission(grants, providers)
    return lambda project_id, payload: admission(project_id, payload).get("eligible") is True


def build_project_reference_validator(hardware: HardwareRegistry, providers: ProviderRegistry) -> Callable[[Mapping[str, Any]], None]:
    """Build the fail-closed registration check shared by save and orchestration."""
    def validate(payload: Mapping[str, Any]) -> None:
        provider_id = payload.get("provider_reference")
        hardware_id = payload.get("hardware_reference")
        provider = None
        if provider_id is not None:
            provider = providers.get(provider_id) if isinstance(provider_id, str) else None
            if provider is None:
                raise ValueError("provider_reference must name a registered provider")
        if hardware_id is not None:
            node = hardware.get_snapshot(hardware_id) if isinstance(hardware_id, str) else None
            if node is None:
                raise ValueError("hardware_reference must name a registered hardware node")
        if provider is not None and hardware_id is not None and provider.get("hardware_node_id") != hardware_id:
            raise ValueError("provider_reference and hardware_reference must identify the same registered host")
    return validate


def build_project_configuration_validator(grants: ResourceGrants, providers: ProviderRegistry) -> Callable[[str, dict[str, Any]], bool]:
    """Validate static project configuration without probing live services."""
    def validate(project_id: str, payload: dict[str, Any]) -> bool:
        if (not isinstance(project_id, str) or not project_id or
                not isinstance(payload.get("resource_pool_id"), str) or not payload["resource_pool_id"]):
            return False
        pool_id = payload["resource_pool_id"]
        try:
            pool = grants.pool_projection(pool_id)
            project_grants = grants.project_grants(project_id)
        except ValueError:
            return False
        grant = next((item for item in project_grants if item.get("pool_id") == pool_id and item.get("active") is True), None)
        quantities = payload.get("resource_requested_envelope")
        if (pool is None or grant is None or not isinstance(quantities, Mapping) or
                any(not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0 or value > grant.get("quantities", {}).get(name, 0) for name, value in quantities.items())):
            return False
        provider_reference = payload.get("provider_reference")
        hardware_reference = payload.get("hardware_reference")
        selected_provider_id = pool.get("provider_id") if isinstance(pool, Mapping) else None
        selected_hardware_id = pool.get("hardware_node_id") if isinstance(pool, Mapping) else None
        if provider_reference is not None:
            provider = providers.get(provider_reference) if isinstance(provider_reference, str) else None
            if provider is None or provider.get("provider_id") != selected_provider_id:
                return False
            if hardware_reference is not None and provider.get("hardware_node_id") != hardware_reference:
                return False
        if hardware_reference is not None:
            if not isinstance(hardware_reference, str) or providers.hardware.get_snapshot(hardware_reference) is None or hardware_reference != selected_hardware_id:
                return False
        bindings = []
        for agent in payload.get("agents", []):
            if isinstance(agent, Mapping):
                bindings.extend(agent.get("capability_bindings", []))
        declared = payload.get("binding_references")
        if isinstance(declared, list):
            bindings.extend(declared)
        if isinstance(payload.get("storage_binding"), str):
            bindings.append(payload["storage_binding"])
        rows = {row["logical_binding"]: row for row in providers.list_bindings()}
        for logical_binding in dict.fromkeys(bindings):
            row = rows.get(logical_binding)
            if row is None:
                return False
            provider = providers.get(row["provider_id"])
            if not isinstance(provider, Mapping):
                return False
            capability = row.get("capability", "")
            expected_role = ("agent-runtime" if capability.startswith("runtime.") or logical_binding.startswith("runtime.") else
                             "storage" if capability.startswith("storage.") or logical_binding.startswith("storage.") else
                             "inference" if capability.startswith("inference.") or logical_binding.startswith("inference.") else None)
            if expected_role is not None and provider.get("role") != expected_role:
                return False
            if expected_role == "inference" and (provider.get("provider_id") != pool.get("provider_id") or provider.get("hardware_node_id") != pool.get("hardware_node_id")):
                return False
        return True
    return validate


def build_management_service(config: ManagementServiceConfig, *, clock: Clock | None = None, inference_provider: InferenceProvider | None = None) -> ManagementService:
    """Construct, but never start, a loopback service with a real live validator."""
    current_time = clock or (lambda: datetime.now(timezone.utc))
    hardware = HardwareRegistry(
        config.databases.hardware,
        clock=current_time,
        stale_after_seconds=config.hardware_stale_after_seconds,
    )
    providers = ProviderRegistry(config.databases.providers, hardware, clock=current_time)
    grants = ResourceGrants(
        config.databases.grants,
        clock=current_time,
        max_capacity_age_seconds=config.grant_capacity_age_seconds,
    )

    admission = build_live_project_admission(grants, providers)
    reference_validator = build_project_reference_validator(hardware, providers)
    validator = lambda project_id, payload: admission(project_id, payload).get("eligible") is True
    projects = ProjectControl(config.databases.projects, validate_project=validator, validate_configuration=build_project_configuration_validator(grants, providers), project_admission=admission, validate_project_references=reference_validator)
    planner = ManagementExecutionPlanner(projects, providers, validator, config.runtime_bindings, config.verification_actions, admission=admission)
    orchestrators = ProjectOrchestratorRegistry(config.orchestrator_loop_root, validate_project_references=reference_validator) if config.orchestrator_loop_root is not None else None
    verification_submitter = build_verification_submitter(config.verification_client) if config.verification_client is not None else None
    merge_submitter = build_merge_submitter(config.merge_client) if config.merge_client is not None else None
    catalog_admission = CatalogAdmission(ModelCapabilityCatalog(config.databases.catalog), grants, providers) if config.databases.catalog is not None else None
    reporting = UsageReportingStore(config.databases.reporting) if config.databases.reporting is not None else None
    lifecycle = SoftwareNodeLifecycleJournal(config.databases.lifecycle) if config.databases.lifecycle is not None else None
    runtime_control = ManagementRuntimeControl(config.runtime_control.database, config.runtime_control.runtime, config.runtime_control.sessions, state_root=config.runtime_control.state_root) if config.runtime_control is not None else None
    frontier_service = build_github_frontier_service(projects, config.github_frontier, clock=current_time) if config.github_frontier is not None else None
    tokens = {}
    for provider_id, token_file in config.inference_provider_token_files.items():
        tokens[provider_id] = _read_bounded_token(Path(token_file), "inference provider credential")
    inference_lifecycle = InferenceLifecycleCoordinator(catalog_admission, inference_provider or InferenceProviderClient(providers, provider_tokens=tokens)) if catalog_admission is not None and (inference_provider is not None or tokens) else None
    api_server = serve(projects, providers, config.api, clock=current_time, planner=planner, verification_submitter=verification_submitter, orchestrator_registry=orchestrators, catalog_admission=catalog_admission, merge_submitter=merge_submitter, usage_reporting=reporting, runtime_control=runtime_control, grants=grants, software_lifecycle=lifecycle, frontier_service=frontier_service, inference_lifecycle=inference_lifecycle)
    return ManagementService(hardware, providers, grants, projects, api_server, orchestrators, reporting, runtime_control, lifecycle, config.role_identity)


_UTC_RFC3339 = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$")
def _timestamp(value: Any) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ManagementServiceError("principal expiry must be RFC3339 or null")
    if not _UTC_RFC3339.fullmatch(value):
        raise ManagementServiceError("principal expiry must be RFC3339 or null")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise ManagementServiceError("principal expiry must be RFC3339 or null") from error
    if parsed.tzinfo is None:
        raise ManagementServiceError("principal expiry must include a timezone")
    return parsed.astimezone(timezone.utc)


def _string_set(value: Any, name: str) -> frozenset[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) and item for item in value):
        raise ManagementServiceError(f"{name} must be a list of non-empty strings")
    return frozenset(value)


def load_service_config(path: str | Path) -> ManagementServiceConfig:
    """Load explicit paths and bearer principals from an external JSON file."""
    config_path = Path(path)
    try:
        config_path = _private_file(config_path, "external configuration file")
    except ManagementServiceError as error:
        raise ManagementServiceError("external configuration file is required") from error
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ManagementServiceError("external configuration must be valid UTF-8 JSON") from error
    if not isinstance(raw, Mapping):
        raise ManagementServiceError("external configuration must be an object")
    databases = raw.get("databases")
    api = raw.get("api")
    principals = raw.get("principals")
    if not isinstance(databases, Mapping) or not isinstance(api, Mapping) or not isinstance(principals, list) or not principals:
        raise ManagementServiceError("databases, api, and non-empty principals are required")
    try:
        locations = DatabaseLocations(**{name: Path(databases[name]) for name in ("hardware", "providers", "grants", "projects")},
                                      **({"catalog": Path(databases["catalog"])} if "catalog" in databases else {}), **({"reporting": Path(databases["reporting"])} if "reporting" in databases else {}), **({"lifecycle": Path(databases["lifecycle"])} if "lifecycle" in databases else {}))
    except (KeyError, TypeError) as error:
        raise ManagementServiceError("all four durable database locations are required") from error
    tokens: dict[str, Principal] = {}
    for item in principals:
        if not isinstance(item, Mapping):
            raise ManagementServiceError("each principal must be an object")
        token_file = item.get("token_file")
        if not isinstance(token_file, str) or not token_file:
            raise ManagementServiceError("each principal requires an external token file")
        try:
            token = _private_file(Path(token_file), "principal token file").read_text(encoding="utf-8").strip()
        except (OSError, UnicodeDecodeError) as error:
            raise ManagementServiceError("principal token is unavailable") from error
        if not token or not token.isascii() or len(token) > 4096 or any(character.isspace() for character in token) or token in tokens:
            raise ManagementServiceError("principal tokens must be unique private values")
        try:
            tokens[token] = Principal(
                actor_id=item["actor_id"],
                role=item["role"],
                projects=_string_set(item.get("projects", []), "projects"),
                providers=_string_set(item.get("providers", []), "providers"),
                expires_at=_timestamp(item.get("expires_at")),
                create_projects=item.get("create_projects", False),
            )
        except (KeyError, ValueError) as error:
            raise ManagementServiceError("principal declaration is invalid") from error
    role = raw.get("role")
    try:
        if role is None:
            # Existing operator files remain loadable during the compatibility
            # transition; ManagementServiceConfig derives all durable roots.
            role_identity = None
        elif not isinstance(role, Mapping) or not {"name", "service_principal", "state_root"}.issubset(role) or set(role) - {"name", "service_principal", "state_root", "state_roots"}:
            raise ManagementServiceError("Management role declaration is invalid")
        else:
            extra_roots = role.get("state_roots", [])
            if not isinstance(extra_roots, list) or not all(isinstance(value, str) and value for value in extra_roots):
                raise ManagementServiceError("Management role state roots are invalid")
            role_identity = ManagementRoleIdentity(role["name"], role["service_principal"], role["state_root"], tuple(Path(value) for value in extra_roots))
        for root_name in ("project_document_root", "project_files_root"):
            if root_name in api and (not isinstance(api[root_name], str) or not api[root_name]):
                raise ManagementServiceError(f"{root_name} must be a non-empty path")
        api_config = ManagementApiConfig(
            tokens=tokens,
            host=api.get("host", "127.0.0.1"),
            port=api.get("port", 14320),
            max_body_bytes=api.get("max_body_bytes", 64 * 1024),
            request_timeout_seconds=api.get("request_timeout_seconds", 2.0),
            project_document_root=Path(api["project_document_root"]) if "project_document_root" in api else None,
            project_files_root=Path(api["project_files_root"]) if "project_files_root" in api else None,
            max_prd_bytes=api.get("max_prd_bytes", 512 * 1024),
        )
        loop_root = raw.get("orchestrator_loop_root")
        verification_client_path = raw.get("verification_client_config_file")
        merge_client_path = raw.get("merge_client_config_file")
        runtime_control_path = raw.get("runtime_control_config_file")
        github_frontier_path = raw.get("github_frontier_config_file")
        if loop_root is not None and (not isinstance(loop_root, str) or not loop_root):
            raise ManagementServiceError("orchestrator loop root is invalid")
        if verification_client_path is not None and (not isinstance(verification_client_path, str) or not verification_client_path):
            raise ManagementServiceError("verification client configuration path is invalid")
        if merge_client_path is not None and (not isinstance(merge_client_path, str) or not merge_client_path):
            raise ManagementServiceError("merge client configuration path is invalid")
        if runtime_control_path is not None and (not isinstance(runtime_control_path, str) or not runtime_control_path):
            raise ManagementServiceError("runtime control configuration path is invalid")
        if github_frontier_path is not None and (not isinstance(github_frontier_path, str) or not github_frontier_path):
            raise ManagementServiceError("GitHub frontier configuration path is invalid")
        verification_client = _load_verification_client_config(verification_client_path) if verification_client_path is not None else None
        merge_client = _load_merge_client_config(merge_client_path) if merge_client_path is not None else None
        runtime_control = _load_runtime_control_config(runtime_control_path) if runtime_control_path is not None else None
        github_frontier = _load_github_frontier_config(github_frontier_path) if github_frontier_path is not None else None
        inference_token_files = raw.get("inference_provider_token_files", {})
        if not isinstance(inference_token_files, Mapping) or any(not isinstance(k, str) or not k or not isinstance(v, str) or not v for k, v in inference_token_files.items()):
            raise ManagementServiceError("inference provider token files are invalid")
        result = ManagementServiceConfig(
            databases=locations,
            api=api_config,
            hardware_stale_after_seconds=raw.get("hardware_stale_after_seconds", 60),
            grant_capacity_age_seconds=raw.get("grant_capacity_age_seconds", 60),
            runtime_bindings=raw.get("runtime_bindings", {}),
            verification_actions=raw.get("verification_actions", {}),
            role_identity=role_identity,
            orchestrator_loop_root=Path(loop_root) if loop_root is not None else None,
            verification_client=verification_client,
            merge_client=merge_client,
            runtime_control=runtime_control,
            github_frontier=github_frontier,
            inference_provider_token_files={k: _private_file(Path(v), "inference provider token file") for k, v in inference_token_files.items()},
        )
        if any(not location.parent.is_dir() for location in (locations.hardware, locations.providers, locations.grants, locations.projects, *(() if locations.reporting is None else (locations.reporting,)), *(() if locations.lifecycle is None else (locations.lifecycle,)))):
            raise ManagementServiceError("durable database parent directories must already exist")
        return result
    except ValueError as error:
        raise ManagementServiceError("service configuration is invalid") from error


def _load_verification_client_config(path: str | Path) -> VerificationClientConfiguration:
    """Load the separate, operator-owned client declaration; never use env vars."""
    config_path = Path(path)
    config_path = _private_file(config_path, "verification client configuration file")
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ManagementServiceError("verification client configuration is invalid") from error
    required = {"host", "port", "bearer_token_file"}
    allowed = required | {"timeout_seconds", "max_response_bytes"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or not set(raw).issubset(allowed):
        raise ManagementServiceError("verification client configuration fields are invalid")
    try:
        return VerificationClientConfiguration(
            host=raw["host"], port=raw["port"], bearer_token_file=Path(raw["bearer_token_file"]),
            timeout_seconds=raw.get("timeout_seconds", 2.0), max_response_bytes=raw.get("max_response_bytes", 64 * 1024),
        )
    except (KeyError, TypeError, ValueError) as error:
        raise ManagementServiceError("verification client configuration is invalid") from error


def _load_github_frontier_config(path: str | Path) -> GitHubFrontierConfiguration:
    config_path = _private_file(Path(path), "GitHub frontier configuration file")
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ManagementServiceError("GitHub frontier configuration is invalid") from error
    required = {"database", "bearer_token_files"}
    allowed = required | {"api_origin", "timeout_seconds", "max_response_bytes"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or not set(raw).issubset(allowed) or not isinstance(raw["database"], str) or not isinstance(raw["bearer_token_files"], Mapping) or any(not isinstance(identity, str) or not isinstance(token_file, str) for identity, token_file in raw["bearer_token_files"].items()):
        raise ManagementServiceError("GitHub frontier configuration fields are invalid")
    try:
        return GitHubFrontierConfiguration(
            Path(raw["database"]),
            {identity: Path(token_file) for identity, token_file in raw["bearer_token_files"].items()},
            api_origin=raw.get("api_origin", "https://api.github.com"),
            timeout_seconds=raw.get("timeout_seconds", 10.0),
            max_response_bytes=raw.get("max_response_bytes", 512 * 1024),
        )
    except (TypeError, ValueError) as error:
        raise ManagementServiceError("GitHub frontier configuration is invalid") from error


def _load_merge_client_config(path: str | Path) -> MergeAuthorityClientConfiguration:
    config_path = _private_file(Path(path), "merge client configuration file")
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ManagementServiceError("merge client configuration is invalid") from error
    required = {"host", "port", "bearer_token_file"}
    allowed = required | {"timeout_seconds"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or not set(raw).issubset(allowed):
        raise ManagementServiceError("merge client configuration fields are invalid")
    try:
        return MergeAuthorityClientConfiguration(host=raw["host"], port=raw["port"], bearer_token_file=Path(raw["bearer_token_file"]), timeout_seconds=raw.get("timeout_seconds", 2.0))
    except (KeyError, TypeError, ValueError, MergeAuthorityClientError) as error:
        raise ManagementServiceError("merge client configuration is invalid") from error


def _load_runtime_control_config(path: str | Path) -> RuntimeControlConfiguration:
    config_path = _private_file(Path(path), "runtime control configuration file")
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ManagementServiceError("runtime control configuration is invalid") from error
    if not isinstance(raw, Mapping) or not {"database", "bindings", "sessions"}.issubset(raw) or set(raw) - {"database", "bindings", "sessions", "state_root"} or not isinstance(raw["database"], str) or not isinstance(raw["bindings"], Mapping) or not isinstance(raw["sessions"], Mapping) or ("state_root" in raw and (not isinstance(raw["state_root"], str) or not raw["state_root"])):
        raise ManagementServiceError("runtime control configuration fields are invalid")
    bindings: dict[str, RuntimeBinding] = {}
    try:
        for binding_id, value in raw["bindings"].items():
            if not isinstance(binding_id, str) or not isinstance(value, Mapping) or set(value) - {"base_url", "session_id", "token_file", "timeout_seconds"} or not {"base_url", "session_id", "token_file"}.issubset(value) or not isinstance(value["token_file"], str):
                raise ManagementServiceError("runtime control binding is invalid")
            token = _private_file(Path(value["token_file"]), "runtime control token file").read_text(encoding="utf-8").strip()
            if not token or not token.isascii() or any(character.isspace() for character in token):
                raise ManagementServiceError("runtime control token is invalid")
            bindings[binding_id] = RuntimeBinding(binding_id, value["base_url"], value["session_id"], token, value.get("timeout_seconds", 5.0))
        sessions = {project: dict(rows) for project, rows in raw["sessions"].items()}
        if any(binding not in bindings for rows in sessions.values() if isinstance(rows, Mapping) for binding in rows.values()):
            raise ManagementServiceError("runtime control session names an unknown binding")
        return RuntimeControlConfiguration(Path(raw["database"]), RuntimeClient(bindings), sessions, Path(raw["state_root"]) if "state_root" in raw else None)
    except (KeyError, TypeError, ValueError, RuntimeClientError) as error:
        if isinstance(error, ManagementServiceError): raise
        raise ManagementServiceError("runtime control configuration is invalid") from error


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Construct the local Management control-plane service.")
    parser.add_argument("--config", required=True, help="External JSON configuration containing scoped credentials; never place it in this repository.")
    parser.add_argument("--check", action="store_true", help="Validate and construct durable cores without starting the HTTP listener.")
    args = parser.parse_args(argv)
    config = load_service_config(args.config)
    if args.check:
        print("configuration validated; listener was not started")
        return 0
    service = build_management_service(config)
    try:
        service.api_server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        service.api_server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
