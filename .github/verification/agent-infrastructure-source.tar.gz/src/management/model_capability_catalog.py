"""Storage-backed v1 model capability catalog and explicit admission decisions."""
from __future__ import annotations
import json,sqlite3,math,re,hashlib,uuid
from datetime import datetime,timezone
from pathlib import Path
from contextlib import contextmanager
from typing import Any,Mapping
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root
_SAFE=re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_UTC_RFC3339=re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$")
_OUTCOME_KEYS=frozenset({'request_id','effect_id','state','reason','detail','message','error','error_code','retryable','result'})
def _safe_outcome(value, depth=0):
 if depth>3:return '[redacted]'
 if isinstance(value,str):return value[:512]
 if value is None or isinstance(value,bool) or isinstance(value,int) or (isinstance(value,float) and math.isfinite(value)):return value
 if isinstance(value,list):return [_safe_outcome(v,depth+1) for v in value[:32]]
 if isinstance(value,Mapping):
  result={k:_safe_outcome(v,depth+1) for k,v in value.items() if isinstance(k,str) and k in _OUTCOME_KEYS}
  return {k:v for k,v in result.items() if v != {}}
 return '[redacted]'
def _sanitize_outcome(value):
 sanitized=_safe_outcome(value)
 try:
  encoded=_canon(sanitized).encode('utf-8')
 except (TypeError,ValueError):
  sanitized = None
 if sanitized is None or len(encoded)>4096:
  # Identity is the durable idempotency boundary.  Optional provider data is
  # disposable when it cannot fit the envelope, but request/effect/state must
  # remain available for status, restart, and replay.
  identity = {key: value.get(key) for key in ('request_id', 'effect_id', 'state')
              if isinstance(value, Mapping) and isinstance(value.get(key), str)}
  identity['reason'] = 'provider_outcome_redacted'
  return identity
 return sanitized
class CatalogError(ValueError):pass
class CatalogConflict(CatalogError):pass
def _canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
class ModelCapabilityCatalog:
 def __init__(self,database:str|Path,*,clock=None):
  database_path=Path(database)
  self.clock=clock or (lambda:datetime.now(timezone.utc))
  try:
   state_root=validate_state_root(database_path.parent,'catalog state root')
   self.path=validate_durable_leaf(database_path,state_root,label='catalog database')
  except ManagementStateBoundaryError as error: raise CatalogError(str(error)) from error
  with self._db() as c:
   c.executescript('CREATE TABLE IF NOT EXISTS model_catalog(model_id TEXT,revision TEXT,entry TEXT,state TEXT,availability TEXT,PRIMARY KEY(model_id,revision));CREATE TABLE IF NOT EXISTS deployment_profiles(model_id TEXT,revision TEXT,provider_id TEXT,generation INTEGER,evidence TEXT,PRIMARY KEY(model_id,revision,provider_id,generation));CREATE TABLE IF NOT EXISTS catalog_actions(project_id TEXT,key TEXT,fingerprint TEXT,response TEXT,command TEXT,owner_hash TEXT,PRIMARY KEY(project_id,key));CREATE TABLE IF NOT EXISTS catalog_action_owners(project_id TEXT,key TEXT,owner_hash TEXT UNIQUE,PRIMARY KEY(project_id,key));CREATE TABLE IF NOT EXISTS catalog_schema_metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);CREATE TABLE IF NOT EXISTS model_consumers(model_id TEXT,revision TEXT,project_id TEXT,state TEXT,residency_id TEXT,PRIMARY KEY(model_id,revision,project_id));CREATE TABLE IF NOT EXISTS unload_requests(model_id TEXT,revision TEXT,state TEXT,operation_id TEXT,provider_id TEXT,provider_generation INTEGER,receipt TEXT,retired_operation_id TEXT,PRIMARY KEY(model_id,revision));CREATE TABLE IF NOT EXISTS release_intents(model_id TEXT,revision TEXT,project_id TEXT,orchestrator_id TEXT,intent_id TEXT NOT NULL,operation_id TEXT NOT NULL,state TEXT NOT NULL,acknowledgement TEXT,PRIMARY KEY(model_id,revision,project_id));CREATE UNIQUE INDEX IF NOT EXISTS release_intents_intent_id ON release_intents(intent_id);CREATE TABLE IF NOT EXISTS attended_admission_ops(project_id TEXT,session_id TEXT,operation_id TEXT,fingerprint TEXT,fingerprint_version TEXT,model_id TEXT,revision TEXT,provider_id TEXT,provider_generation INTEGER,state TEXT,admission TEXT,response TEXT,runtime_binding_id TEXT,runtime_base_url TEXT,runtime_session_id TEXT,PRIMARY KEY(project_id,session_id,operation_id));CREATE TABLE IF NOT EXISTS inference_requests(request_id TEXT PRIMARY KEY,effect_id TEXT NOT NULL,project_id TEXT NOT NULL,model_id TEXT NOT NULL,revision TEXT NOT NULL,state TEXT NOT NULL,provider_id TEXT,provider_generation INTEGER,outcome TEXT,updated_at TEXT NOT NULL)')
   consumer_columns={row['name'] for row in c.execute('PRAGMA table_info(model_consumers)')}
   if 'residency_id' not in consumer_columns:
    # Legacy rows remain unbound and therefore cannot authorize a release.  A
    # later admission always writes a fresh identity before it can be released.
    c.execute('ALTER TABLE model_consumers ADD COLUMN residency_id TEXT')
   unload_columns={row['name'] for row in c.execute('PRAGMA table_info(unload_requests)')}
   for column, definition in (('project_id','TEXT'),('residency_id','TEXT'),('operation_id','TEXT'),('provider_id','TEXT'),('provider_generation','INTEGER'),('receipt','TEXT'),('retired_operation_id','TEXT')):
    if column not in unload_columns:c.execute(f'ALTER TABLE unload_requests ADD COLUMN {column} {definition}')
   action_columns={row["name"] for row in c.execute("PRAGMA table_info(catalog_actions)")}
   if "command" not in action_columns:c.execute("ALTER TABLE catalog_actions ADD COLUMN command TEXT")
   if "owner_hash" not in action_columns:c.execute("ALTER TABLE catalog_actions ADD COLUMN owner_hash TEXT")
   operation_columns={row["name"] for row in c.execute("PRAGMA table_info(attended_admission_ops)")}
   if "fingerprint_version" not in operation_columns:c.execute("ALTER TABLE attended_admission_ops ADD COLUMN fingerprint_version TEXT")
   for column in ("runtime_binding_id","runtime_base_url","runtime_session_id"):
    if column not in operation_columns:c.execute(f"ALTER TABLE attended_admission_ops ADD COLUMN {column} TEXT")
   migrated=c.execute("SELECT value FROM catalog_schema_metadata WHERE key='action_owner_v1'").fetchone()
   if migrated is None:
    # Bind legacy actions to immutable owners once.  The marker is durable so
    # a later owner deletion is treated as tampering, not migrated again.
    for row in c.execute("SELECT project_id,key,owner_hash FROM catalog_actions").fetchall():
     owner_hash=row["owner_hash"] or self._identity_hash(row["project_id"],row["key"])
     c.execute("UPDATE catalog_actions SET owner_hash=? WHERE project_id=? AND key=?",(owner_hash,row["project_id"],row["key"]))
     try:c.execute("INSERT INTO catalog_action_owners(project_id,key,owner_hash) VALUES(?,?,?)",(row["project_id"],row["key"],owner_hash))
     except sqlite3.IntegrityError:
      # Keep the original owner authoritative.  The moved row is quarantined
      # by _validate_action_identity when the caller attempts replay.
      pass
    c.execute("INSERT INTO catalog_schema_metadata(key,value) VALUES('action_owner_v1','complete')")
  try:self._initialize_attended_authority()
  except sqlite3.IntegrityError as error:raise CatalogConflict('attended admission authority migration conflicts') from error
 def _initialize_attended_authority(self):
  with self._db() as c:
   c.execute("CREATE TABLE IF NOT EXISTS attended_admission_authority(authority_nonce TEXT PRIMARY KEY NOT NULL,project_id TEXT NOT NULL,session_id TEXT NOT NULL,operation_id TEXT NOT NULL,model_id TEXT NOT NULL,revision TEXT NOT NULL,provider_id TEXT,runtime_binding_id TEXT,runtime_base_url TEXT,runtime_session_id TEXT,authority_version TEXT NOT NULL,migration_state TEXT NOT NULL,canonical_digest TEXT NOT NULL,UNIQUE(project_id,session_id,operation_id))")
   columns={row['name'] for row in c.execute('PRAGMA table_info(attended_admission_ops)')}
   if 'authority_nonce' not in columns:c.execute('ALTER TABLE attended_admission_ops ADD COLUMN authority_nonce TEXT')
   if not c.execute('PRAGMA foreign_key_list(attended_admission_ops)').fetchall():
    c.execute('ALTER TABLE attended_admission_ops RENAME TO attended_admission_ops_legacy')
    c.execute("CREATE TABLE attended_admission_ops(project_id TEXT,session_id TEXT,operation_id TEXT,fingerprint TEXT,fingerprint_version TEXT,model_id TEXT,revision TEXT,provider_id TEXT,provider_generation INTEGER,state TEXT,admission TEXT,response TEXT,runtime_binding_id TEXT,runtime_base_url TEXT,runtime_session_id TEXT,authority_nonce TEXT,PRIMARY KEY(project_id,session_id,operation_id),UNIQUE(authority_nonce),FOREIGN KEY(authority_nonce) REFERENCES attended_admission_authority(authority_nonce) ON UPDATE RESTRICT ON DELETE RESTRICT)")
    c.execute("INSERT INTO attended_admission_ops(project_id,session_id,operation_id,fingerprint,fingerprint_version,model_id,revision,provider_id,provider_generation,state,admission,response,runtime_binding_id,runtime_base_url,runtime_session_id,authority_nonce) SELECT project_id,session_id,operation_id,fingerprint,fingerprint_version,model_id,revision,provider_id,provider_generation,state,admission,response,runtime_binding_id,runtime_base_url,runtime_session_id,authority_nonce FROM attended_admission_ops_legacy")
    c.execute('DROP TABLE attended_admission_ops_legacy')
   c.execute('CREATE UNIQUE INDEX IF NOT EXISTS attended_admission_authority_nonce ON attended_admission_authority(authority_nonce)')
   c.execute("CREATE TRIGGER IF NOT EXISTS attended_admission_authority_no_delete BEFORE DELETE ON attended_admission_authority BEGIN SELECT RAISE(ABORT,'attended admission authority is write-once'); END")
   c.execute("CREATE TRIGGER IF NOT EXISTS attended_admission_authority_guard BEFORE UPDATE ON attended_admission_authority WHEN NOT (OLD.authority_nonce=NEW.authority_nonce AND OLD.project_id=NEW.project_id AND OLD.session_id=NEW.session_id AND OLD.operation_id=NEW.operation_id AND OLD.model_id=NEW.model_id AND OLD.revision=NEW.revision AND OLD.provider_id IS NEW.provider_id AND OLD.migration_state='legacy_route_pending' AND NEW.migration_state='canonical' AND OLD.runtime_binding_id IS NULL AND OLD.runtime_base_url IS NULL AND OLD.runtime_session_id IS NULL AND NEW.runtime_binding_id IS NOT NULL AND NEW.runtime_base_url IS NOT NULL AND NEW.runtime_session_id IS NOT NULL) BEGIN SELECT RAISE(ABORT,'attended admission authority is immutable'); END")
   c.execute("CREATE TRIGGER IF NOT EXISTS attended_admission_ops_no_delete BEFORE DELETE ON attended_admission_ops BEGIN SELECT RAISE(ABORT,'attended admission operation is write-once'); END")
   c.execute("CREATE TRIGGER IF NOT EXISTS attended_admission_ops_identity_guard BEFORE UPDATE ON attended_admission_ops WHEN ((OLD.project_id IS NOT NEW.project_id OR OLD.session_id IS NOT NEW.session_id OR OLD.operation_id IS NOT NEW.operation_id OR OLD.model_id IS NOT NEW.model_id OR OLD.revision IS NOT NEW.revision OR OLD.provider_id IS NOT NEW.provider_id OR OLD.authority_nonce IS NOT NEW.authority_nonce) AND NOT (OLD.authority_nonce IS NULL AND NEW.authority_nonce IS NOT NULL AND NOT EXISTS(SELECT 1 FROM catalog_schema_metadata WHERE key='attended_authority_v1' AND value='complete') AND OLD.project_id=NEW.project_id AND OLD.session_id=NEW.session_id AND OLD.operation_id=NEW.operation_id AND OLD.model_id=NEW.model_id AND OLD.revision=NEW.revision AND OLD.provider_id IS NEW.provider_id)) OR ((OLD.runtime_binding_id IS NOT NEW.runtime_binding_id OR OLD.runtime_base_url IS NOT NEW.runtime_base_url OR OLD.runtime_session_id IS NOT NEW.runtime_session_id) AND NOT (OLD.runtime_binding_id IS NULL AND OLD.runtime_base_url IS NULL AND OLD.runtime_session_id IS NULL AND NEW.runtime_binding_id IS NOT NULL AND NEW.runtime_base_url IS NOT NULL AND NEW.runtime_session_id IS NOT NULL AND OLD.state='prepared' AND EXISTS(SELECT 1 FROM attended_admission_authority WHERE authority_nonce=NEW.authority_nonce AND migration_state='canonical'))) BEGIN SELECT RAISE(ABORT,'attended admission operation identity is immutable'); END")
   c.execute("CREATE TRIGGER IF NOT EXISTS attended_admission_ops_lifecycle_guard BEFORE UPDATE OF state ON attended_admission_ops WHEN NOT ((OLD.state='prepared' AND NEW.state IN ('admitted','rejected')) OR OLD.state=NEW.state) BEGIN SELECT RAISE(ABORT,'attended admission lifecycle transition is invalid'); END")
   marker=c.execute("SELECT value FROM catalog_schema_metadata WHERE key='attended_authority_v1'").fetchone()
   if marker is None:
    if c.execute('SELECT 1 FROM attended_admission_authority LIMIT 1').fetchone() or c.execute('SELECT 1 FROM attended_admission_ops WHERE authority_nonce IS NOT NULL LIMIT 1').fetchone():raise CatalogConflict('attended admission authority migration is partial')
    rows=c.execute('SELECT * FROM attended_admission_ops ORDER BY project_id,session_id,operation_id').fetchall()
    legacy=[self._validate_legacy_attended_row(row) for row in rows]
    for row,route,state in legacy:
     nonce=uuid.uuid4().hex
     migration_state='legacy_route_pending' if route is None else 'canonical'
     digest=self._attended_authority_digest(nonce,row['project_id'],row['session_id'],row['operation_id'],row['model_id'],row['revision'],row['provider_id'],route,migration_state)
     c.execute('INSERT INTO attended_admission_authority(authority_nonce,project_id,session_id,operation_id,model_id,revision,provider_id,runtime_binding_id,runtime_base_url,runtime_session_id,authority_version,migration_state,canonical_digest) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(nonce,row['project_id'],row['session_id'],row['operation_id'],row['model_id'],row['revision'],row['provider_id'],route.get('binding_id') if route else None,route.get('base_url') if route else None,route.get('session_id') if route else None,'1',migration_state,digest))
     fingerprint=self._attended_fingerprint(row['project_id'],row['session_id'],row['operation_id'],row['model_id'],row['revision'],row['provider_id'],json.loads(row['admission']),route,'prepared' if state=='prepared' else 'recorded')
     c.execute("UPDATE attended_admission_ops SET authority_nonce=?,fingerprint=?,fingerprint_version='2' WHERE project_id=? AND session_id=? AND operation_id=?",(nonce,fingerprint,row['project_id'],row['session_id'],row['operation_id']))
    c.execute("INSERT INTO catalog_schema_metadata(key,value) VALUES('attended_authority_v1','complete')")
 def _validate_legacy_attended_row(self,row):
  if not all(isinstance(row[key],str) and _SAFE.fullmatch(row[key]) for key in ('project_id','session_id','operation_id','model_id','revision')):raise CatalogConflict('attended admission identity is corrupt')
  if row['provider_id'] is not None and (not isinstance(row['provider_id'],str) or not _SAFE.fullmatch(row['provider_id'])):raise CatalogConflict('attended admission provider is corrupt')
  route=self._attended_route(row)
  if row['state'] not in {'prepared','admitted','rejected'}:raise CatalogConflict('attended admission state is corrupt')
  try:admission=json.loads(row['admission']);response=json.loads(row['response'])
  except (TypeError,json.JSONDecodeError) as error:raise CatalogConflict('attended admission payload is corrupt') from error
  if not isinstance(admission,Mapping) or not isinstance(response,Mapping):raise CatalogConflict('attended admission payload is corrupt')
  if row['state']=='prepared' and (admission!={'state':'prepared'} or response!={'state':'prepared','operation_id':row['operation_id'],'session_id':row['session_id']}):raise CatalogConflict('attended admission payload is corrupt')
  if row['state'] in {'admitted','rejected'} and (admission.get('state')!=row['state'] or response!=admission):raise CatalogConflict('attended admission payload is corrupt')
  if row['provider_generation'] is not None and (type(row['provider_generation']) is not int or row['provider_generation']<1):raise CatalogConflict('attended admission provider generation is corrupt')
  version=row['fingerprint_version']
  if version in (2,'2'):
   expected=self._attended_fingerprint(row['project_id'],row['session_id'],row['operation_id'],row['model_id'],row['revision'],row['provider_id'],admission,route,'prepared' if row['state']=='prepared' else 'recorded')
  elif version in (None,'','1'):
   if row['state']=='prepared':expected=hashlib.sha256(_canon({'model_id':row['model_id'],'revision':row['revision'],'provider_id':row['provider_id'],'runtime_route':route}).encode()).hexdigest()
   else:expected=hashlib.sha256(_canon({'model_id':row['model_id'],'revision':row['revision'],'admission':admission,'runtime_route':route}).encode()).hexdigest()
  else:raise CatalogConflict('attended admission fingerprint version is unknown')
  if not isinstance(row['fingerprint'],str) or row['fingerprint']!=expected:raise CatalogConflict('attended admission fingerprint is corrupt')
  return row,route,row['state']
 @staticmethod
 def _attended_authority_digest(nonce,project_id,session_id,operation_id,model_id,revision,provider_id,route,migration_state):
  return hashlib.sha256(_canon({'authority_version':1,'authority_nonce':nonce,'project_id':project_id,'session_id':session_id,'operation_id':operation_id,'model_id':model_id,'revision':revision,'provider_id':provider_id,'runtime_route':route,'migration_state':migration_state}).encode()).hexdigest()
 @staticmethod
 def _attended_route(row):
  values=tuple(row[key] for key in ('runtime_binding_id','runtime_base_url','runtime_session_id'))
  if all(value is None for value in values):return None
  if not all(isinstance(value,str) and value for value in values):raise CatalogConflict('attended runtime route is corrupt')
  return dict(zip(('binding_id','base_url','session_id'),values))
 @staticmethod
 def _attended_fingerprint(project_id,session_id,operation_id,model_id,revision,provider_id,admission,route,phase):
  return hashlib.sha256(_canon({'fingerprint_version':2,'phase':phase,'project_id':project_id,'session_id':session_id,'operation_id':operation_id,'model_id':model_id,'revision':revision,'provider_id':provider_id,'admission':admission,'runtime_route':route}).encode()).hexdigest()
 @contextmanager
 def _db(self):
  c=sqlite3.connect(self.path);c.row_factory=sqlite3.Row
  c.execute('PRAGMA foreign_keys=ON')
  if c.execute('PRAGMA foreign_keys').fetchone()[0] != 1:
   c.close()
   raise CatalogError('catalog foreign-key enforcement is unavailable')
  c.execute('BEGIN IMMEDIATE')
  try:
   yield c;c.commit()
  except Exception:
   c.rollback()
   raise
  finally:c.close()
 def register(self,entry:Mapping[str,Any]):
  self.validate_entry(entry)
  with self._db() as c:
   metadata={key:value for key,value in entry.items() if key!='availability'};existing=c.execute('SELECT entry FROM model_catalog WHERE model_id=? AND revision=?',(entry['model_id'],entry['revision'])).fetchone()
   if existing:
    if existing['entry']!=_canon(metadata):raise CatalogConflict('catalog revisions are immutable')
   else:c.execute('INSERT INTO model_catalog VALUES(?,?,?,?,?)',(entry['model_id'],entry['revision'],_canon(metadata),entry['rollout_state'],'{}'))
   a=entry['availability'];c.execute('INSERT INTO deployment_profiles VALUES(?,?,?,?,?) ON CONFLICT(model_id,revision,provider_id,generation) DO UPDATE SET evidence=excluded.evidence',(entry['model_id'],entry['revision'],a['provider_id'],a['generation'],_canon(a)))
 @staticmethod
 def validate_entry(entry:Mapping[str,Any]):
  required={'model_id','revision','modalities','function_classes','artifact','compatibility','evidence','envelope','availability','rollout_state','task_rankings'}
  permitted=required|{'source_evidence'}
  source=entry.get('source_evidence')
  valid_source=source is None or (isinstance(source,Mapping) and set(source)=={'reviewed_profile_canonical_json_sha256','model_lock_canonical_json_sha256'} and all(isinstance(v,str) and re.fullmatch(r'[0-9a-f]{64}',v) for v in source.values()))
  if not isinstance(entry,Mapping) or set(entry)-permitted or not required.issubset(entry) or not valid_source or not all(isinstance(entry.get(k),str) and _SAFE.fullmatch(entry[k]) for k in ('model_id','revision','artifact','compatibility')) or not isinstance(entry['modalities'],list) or not entry['modalities'] or not isinstance(entry['function_classes'],list) or not entry['function_classes'] or not isinstance(entry['evidence'],Mapping) or set(entry['evidence'])!={'advertised','tested'} or type(entry['evidence']['advertised']) is not bool or type(entry['evidence']['tested']) is not bool or not isinstance(entry['envelope'],Mapping) or not isinstance(entry['task_rankings'],Mapping) or entry['rollout_state'] not in {'current','trial','rollback','retired'} or not ModelCapabilityCatalog._availability(None,entry['availability'],entry,False):raise CatalogError('model entry is invalid')
  if any(not isinstance(k,str) or not _SAFE.fullmatch(k) or type(v) not in {int,float} or not math.isfinite(v) or v<0 for k,v in entry['envelope'].items()) or any(not isinstance(k,str) or not _SAFE.fullmatch(k) or type(v) not in {int,float} or not math.isfinite(v) for k,v in entry['task_rankings'].items()):raise CatalogError('model entry is invalid')
 def list_current(self,project_id:str,grant:Mapping[str,float]):
  if not isinstance(project_id,str) or not _SAFE.fullmatch(project_id) or not isinstance(grant,Mapping):raise CatalogError('admission scope is invalid')
  with self._db() as c:rows=c.execute("SELECT entry,model_id,revision FROM model_catalog WHERE state='current'").fetchall();profiles=c.execute('SELECT model_id,revision,evidence FROM deployment_profiles').fetchall()
  result=[]
  for row in rows:
   metadata=json.loads(row['entry']);available=[json.loads(p['evidence']) for p in profiles if p['model_id']==row['model_id'] and p['revision']==row['revision']]
   for availability in available:
    entry={**metadata,'availability':availability}
    if self._availability(availability,entry) and entry['evidence']['tested'] and all(grant.get(k,0)>=v for k,v in entry['envelope'].items()):result.append(entry)
  return result
 def replay_admission(self,project_id,key,model_id,revision,grant):
  with self._db() as c:
   self._validate_action_identity(c,project_id,key)
   old=c.execute('SELECT fingerprint,response,command FROM catalog_actions WHERE project_id=? AND key=?',(project_id,key)).fetchone()
  if old is None:return None
  response=json.loads(old['response'])
  command={'model_id':model_id,'revision':revision,'grant':grant}
  stored_command=None
  if old['command']:
   try:stored_command=json.loads(old['command'])
   except (TypeError,json.JSONDecodeError):stored_command=None
  if isinstance(stored_command,Mapping):
   stored_base={key:stored_command.get(key) for key in ('model_id','revision','grant')}
  else:
   if isinstance(response,Mapping) and isinstance(response.get('provider_id'),str):command.update({'selected_provider_id':response['provider_id'],'selected_generation':response.get('provider_generation')})
  fingerprint=hashlib.sha256(_canon(command).encode()).hexdigest()
  if (isinstance(stored_command,Mapping) and _canon(stored_base)!=_canon(command)) or (not isinstance(stored_command,Mapping) and old['fingerprint']!=fingerprint):raise CatalogConflict('idempotency conflict')
  return response
 def record_admission(self,project_id,key,model_id,revision,grant,response):
  command={'model_id':model_id,'revision':revision,'grant':grant}
  fp=hashlib.sha256(_canon(command).encode()).hexdigest()
  with self._db() as c:
   self._prepare_action_identity(c,project_id,key)
   old=c.execute('SELECT fingerprint,response FROM catalog_actions WHERE project_id=? AND key=?',(project_id,key)).fetchone()
   if old:
    if old['fingerprint']!=fp:raise CatalogConflict('idempotency conflict')
    return json.loads(old['response'])
   c.execute('INSERT INTO catalog_actions(project_id,key,fingerprint,response,command,owner_hash) VALUES(?,?,?,?,?,?)',(project_id,key,fp,_canon(response),_canon(command),self._identity_hash(project_id,key)))
  return dict(response)
 def admit(self,project_id,key,model_id,revision,grant,*,selected_provider_id=None,selected_generation=None,provider_generation_check=None):
  command={'model_id':model_id,'revision':revision,'grant':grant}
  if selected_provider_id is not None:command.update({'selected_provider_id':selected_provider_id,'selected_generation':selected_generation})
  fp=hashlib.sha256(_canon(command).encode()).hexdigest()
  with self._db() as c:
   self._prepare_action_identity(c,project_id,key)
   old=c.execute('SELECT fingerprint,response,command FROM catalog_actions WHERE project_id=? AND key=?',(project_id,key)).fetchone()
   if old:
    if old['fingerprint']!=fp:raise CatalogConflict('idempotency conflict')
    return json.loads(old['response'])
   row=c.execute('SELECT entry,state FROM model_catalog WHERE model_id=? AND revision=?',(model_id,revision)).fetchone();profiles=c.execute('SELECT evidence FROM deployment_profiles WHERE model_id=? AND revision=?',(model_id,revision)).fetchall()
   available=[json.loads(x['evidence']) for x in profiles]
   if row: available=[value for value in available if self._availability(value,{**json.loads(row['entry']),'availability':value})]
   if selected_provider_id is not None:
    available=[value for value in available if value.get('provider_id')==selected_provider_id and value.get('generation')==selected_generation]
   if not row or row['state']!='current' or not available or not json.loads(row['entry'])['evidence']['tested']:result={'state':'requires_additional_resources','reason':'not_current_available'}
   else:
    entry=json.loads(row['entry']);result={'state':'admitted','model_id':model_id,'revision':revision} if all(grant.get(k,0)>=v for k,v in entry['envelope'].items()) else {'state':'requires_additional_resources','reason':'over_budget'}
    if result['state']=='admitted' and available:
     result.update({'provider_id':available[0]['provider_id'],'provider_generation':available[0]['generation']})
    if result['state']=='admitted':
     # An active provider effect owns this lifecycle epoch.  A genuinely
     # new admission must wait until its outcome is reconciled; otherwise a
     # late op1 receipt could unload the newly admitted residency.
     prior=c.execute('SELECT state FROM unload_requests WHERE model_id=? AND revision=?',(model_id,revision)).fetchone()
     if prior and prior['state']=='unloading':
      raise CatalogConflict('admission requires unload reconciliation')
     residency_id=uuid.uuid4().hex
     c.execute('INSERT INTO model_consumers(model_id,revision,project_id,state,residency_id) VALUES(?,?,?,?,?) ON CONFLICT(model_id,revision,project_id) DO UPDATE SET state=excluded.state,residency_id=excluded.residency_id',(model_id,revision,project_id,'consuming',residency_id))
     result['residency_id']=residency_id
     # A completed unload belongs to the prior residency.  Every genuinely
     # new admission starts a fresh lifecycle and must not inherit its claim,
     # even when provider identity and generation are unchanged.
     prior=c.execute('SELECT state,operation_id,provider_id,provider_generation FROM unload_requests WHERE model_id=? AND revision=?',(model_id,revision)).fetchone()
     if prior and prior['state'] in {'waiting_release','ready_for_physical_unload','unloaded'} and result.get('provider_id') is not None:
      c.execute("UPDATE unload_requests SET state='waiting_release',project_id=NULL,residency_id=NULL,retired_operation_id=?,operation_id=NULL,provider_id=NULL,provider_generation=NULL,receipt=NULL WHERE model_id=? AND revision=?",(prior['operation_id'],model_id,revision))
   c.execute('INSERT INTO catalog_actions(project_id,key,fingerprint,response,command,owner_hash) VALUES(?,?,?,?,?,?)',(project_id,key,fp,_canon(result),_canon(command),self._identity_hash(project_id,key)))
   if result.get('state')=='admitted' and provider_generation_check is not None and not provider_generation_check(result.get('provider_id'),result.get('provider_generation')):
    raise CatalogConflict('provider generation changed during admission')
   return result
 def _identity_hash(self,project_id,key):
  return hashlib.sha256(_canon({"project_id":project_id,"key":key}).encode()).hexdigest()
 def _validate_action_identity(self,c,project_id,key):
  """Reject moved, duplicated, or ownerless operations before replay/insert."""
  expected=self._identity_hash(project_id,key)
  owner=c.execute("SELECT project_id,key,owner_hash FROM catalog_action_owners WHERE project_id=? AND key=?",(project_id,key)).fetchall()
  action=c.execute("SELECT owner_hash FROM catalog_actions WHERE project_id=? AND key=?",(project_id,key)).fetchone()
  if len(owner)>1 or (owner and (owner[0]["owner_hash"]!=expected or owner[0]["project_id"]!=project_id or owner[0]["key"]!=key)):
   raise CatalogConflict("catalog action owner requires reconciliation")
  if action is not None and action["owner_hash"]!=expected:raise CatalogConflict("catalog action identity requires reconciliation")
  if action is not None and not owner:raise CatalogConflict("catalog action owner is missing; reconciliation required")
  moved=c.execute("SELECT project_id,key FROM catalog_actions WHERE owner_hash=?",(expected,)).fetchall()
  if len(moved)>1 or (moved and (moved[0]["project_id"]!=project_id or moved[0]["key"]!=key)):
   raise CatalogConflict("catalog action primary-key identity requires reconciliation")
  if owner and action is None:raise CatalogConflict("catalog action is missing; reconciliation required")
 def _prepare_action_identity(self,c,project_id,key):
  self._validate_action_identity(c,project_id,key)
  if c.execute("SELECT 1 FROM catalog_action_owners WHERE project_id=? AND key=?",(project_id,key)).fetchone() is None:
   try:c.execute("INSERT INTO catalog_action_owners(project_id,key,owner_hash) VALUES(?,?,?)",(project_id,key,self._identity_hash(project_id,key)))
   except sqlite3.IntegrityError:self._validate_action_identity(c,project_id,key)
 def _attended_validate_operation(self,authority,row):
  if authority['authority_version'] not in (1,'1'):raise CatalogConflict('attended admission authority version is unknown')
  authority_route=self._attended_route(authority)
  if authority['migration_state']=='legacy_route_pending':
   if authority_route is not None:raise CatalogConflict('attended admission legacy route state is corrupt')
  elif authority['migration_state']=='canonical':
   if authority_route is None:raise CatalogConflict('attended admission route state is corrupt')
  else:raise CatalogConflict('attended admission migration state is corrupt')
  expected_digest=self._attended_authority_digest(authority['authority_nonce'],authority['project_id'],authority['session_id'],authority['operation_id'],authority['model_id'],authority['revision'],authority['provider_id'],authority_route,authority['migration_state'])
  if authority['canonical_digest']!=expected_digest:raise CatalogConflict('attended admission authority digest is corrupt')
  if row['authority_nonce']!=authority['authority_nonce'] or any(row[key]!=authority[key] for key in ('project_id','session_id','operation_id','model_id','revision')) or row['provider_id']!=authority['provider_id'] or self._attended_route(row)!=authority_route:raise CatalogConflict('attended admission authority binding conflicts')
  if row['state'] not in {'prepared','admitted','rejected'}:raise CatalogConflict('attended admission state is corrupt')
  if row['provider_generation'] is not None and (type(row['provider_generation']) is not int or row['provider_generation']<1):raise CatalogConflict('attended admission provider generation is corrupt')
  try:admission=json.loads(row['admission']);response=json.loads(row['response'])
  except (TypeError,json.JSONDecodeError) as error:raise CatalogConflict('attended admission payload is corrupt') from error
  if not isinstance(admission,Mapping) or not isinstance(response,Mapping):raise CatalogConflict('attended admission payload is corrupt')
  if row['state']=='prepared':
   if admission!={'state':'prepared'} or response!={'state':'prepared','operation_id':row['operation_id'],'session_id':row['session_id']} or row['provider_generation'] is not None:raise CatalogConflict('attended admission prepared state is corrupt')
   phase='prepared'
  else:
   if admission.get('state')!=row['state'] or response!=admission or admission.get('provider_id')!=authority['provider_id'] or admission.get('provider_generation')!=row['provider_generation']:raise CatalogConflict('attended admission terminal state is corrupt')
   phase='recorded'
  if row['fingerprint_version'] in (2,'2'):
   expected=self._attended_fingerprint(row['project_id'],row['session_id'],row['operation_id'],row['model_id'],row['revision'],row['provider_id'],admission,authority_route,phase)
  elif row['fingerprint_version'] in (None,'','1'):
   if phase=='prepared':expected=hashlib.sha256(_canon({'model_id':row['model_id'],'revision':row['revision'],'provider_id':row['provider_id'],'runtime_route':authority_route}).encode()).hexdigest()
   else:expected=hashlib.sha256(_canon({'model_id':row['model_id'],'revision':row['revision'],'admission':admission,'runtime_route':authority_route}).encode()).hexdigest()
  else:raise CatalogConflict('attended admission fingerprint version is unknown')
  if row['fingerprint']!=expected:raise CatalogConflict('attended admission fingerprint is corrupt')
  return admission,response,authority_route,row['fingerprint_version'] not in (2,'2')
 def _attended_classify(self,c,project_id,session_id,operation_id):
  operation_rows=c.execute('SELECT * FROM attended_admission_ops WHERE project_id=? AND session_id=? AND operation_id=?',(project_id,session_id,operation_id)).fetchall()
  authority_rows=c.execute('SELECT * FROM attended_admission_authority WHERE project_id=? AND session_id=? AND operation_id=?',(project_id,session_id,operation_id)).fetchall()
  if len(operation_rows)>1 or len(authority_rows)>1:raise CatalogConflict('attended admission identity is duplicated')
  operation=operation_rows[0] if operation_rows else None;authority=authority_rows[0] if authority_rows else None
  if operation is None and authority is None:
   return None,None,None
  if operation is None or authority is None:raise CatalogConflict('attended admission authority pair is partial')
  nonce_rows=c.execute('SELECT * FROM attended_admission_authority WHERE authority_nonce=?',(operation['authority_nonce'],)).fetchall()
  bound_rows=c.execute('SELECT * FROM attended_admission_ops WHERE authority_nonce=?',(authority['authority_nonce'],)).fetchall()
  if len(nonce_rows)!=1 or len(bound_rows)!=1 or nonce_rows[0]['authority_nonce']!=authority['authority_nonce']:raise CatalogConflict('attended admission authority association is corrupt')
  self._attended_validate_operation(authority,operation)
  return authority,operation,True
 @staticmethod
 def _attended_public(row,admission,response,route):
  result=dict(row);result['admission']=admission;result['response']=response;result['runtime_route']=route
  for key in ('runtime_binding_id','runtime_base_url','runtime_session_id','authority_nonce'):result.pop(key,None)
  return result
 def _attended_validate_identity(self,project_id,session_id,operation_id,model_id,revision,provider_id):
  values=(project_id,session_id,operation_id,model_id,revision)
  if not all(isinstance(value,str) and _SAFE.fullmatch(value) for value in values) or provider_id is not None and (not isinstance(provider_id,str) or not _SAFE.fullmatch(provider_id)):raise CatalogError('attended admission identity is invalid')
 def _attended_validate_route(self,runtime_route):
  if runtime_route is not None and not isinstance(runtime_route,Mapping):raise CatalogError('runtime route identity is invalid')
  route=dict(runtime_route) if isinstance(runtime_route,Mapping) else None
  if route is not None and (set(route)!={'binding_id','base_url','session_id'} or not all(isinstance(route.get(key),str) and route[key] for key in route)):raise CatalogError('runtime route identity is invalid')
  return route
 def _attended_complete_route(self,c,authority,operation,route):
  if route is None:return
  current=self._attended_route(authority)
  if current is not None and current!=route:raise CatalogConflict('attended runtime route conflicts')
  if current is not None:return
  if authority['migration_state']!='legacy_route_pending' or operation['state']!='prepared':raise CatalogConflict('attended runtime route is immutable')
  digest=self._attended_authority_digest(authority['authority_nonce'],authority['project_id'],authority['session_id'],authority['operation_id'],authority['model_id'],authority['revision'],authority['provider_id'],route,'canonical')
  c.execute("UPDATE attended_admission_authority SET runtime_binding_id=?,runtime_base_url=?,runtime_session_id=?,migration_state='canonical',canonical_digest=? WHERE authority_nonce=?",(route['binding_id'],route['base_url'],route['session_id'],digest,authority['authority_nonce']))
  fingerprint=self._attended_fingerprint(operation['project_id'],operation['session_id'],operation['operation_id'],operation['model_id'],operation['revision'],operation['provider_id'],{'state':'prepared'},route,'prepared')
  c.execute("UPDATE attended_admission_ops SET runtime_binding_id=?,runtime_base_url=?,runtime_session_id=?,fingerprint=?,fingerprint_version='2' WHERE authority_nonce=?",(route['binding_id'],route['base_url'],route['session_id'],fingerprint,authority['authority_nonce']))
 def record_attended_admission(self,project_id,session_id,operation_id,model_id,revision,admission):
  self._attended_validate_identity(project_id,session_id,operation_id,model_id,revision,None)
  if not isinstance(admission,Mapping) or admission.get('state') not in {'admitted','rejected'}:raise CatalogError('attended admission result is invalid')
  response=dict(admission);provider_id=admission.get('provider_id');generation=admission.get('provider_generation')
  self._attended_validate_identity(project_id,session_id,operation_id,model_id,revision,provider_id)
  if generation is not None and (type(generation) is not int or generation<1):raise CatalogError('attended admission provider generation is invalid')
  try:
   with self._db() as c:
    authority,operation,_=self._attended_classify(c,project_id,session_id,operation_id)
    if authority is None:raise CatalogConflict('attended admission operation is not prepared')
    if any(authority[key]!=value for key,value in {'project_id':project_id,'session_id':session_id,'operation_id':operation_id,'model_id':model_id,'revision':revision,'provider_id':provider_id}.items()):raise CatalogConflict('attended admission operation conflicts')
    stored_admission,existing,route,legacy=self._attended_validate_operation(authority,operation)
    if operation['state'] in {'admitted','rejected'}:
     if stored_admission!=admission:raise CatalogConflict('attended admission terminal replay conflicts')
     return existing
    fingerprint=self._attended_fingerprint(project_id,session_id,operation_id,model_id,revision,provider_id,admission,route,'recorded')
    c.execute('UPDATE attended_admission_ops SET fingerprint=?,fingerprint_version=?,provider_generation=?,state=?,admission=?,response=? WHERE authority_nonce=?',(fingerprint,'2',generation,admission['state'],_canon(admission),_canon(response),authority['authority_nonce']))
    return response
  except sqlite3.IntegrityError as error:raise CatalogConflict('attended admission persistence conflicts') from error
 def prepare_attended_admission(self,project_id,session_id,operation_id,model_id,revision,provider_id=None,runtime_route=None):
  self._attended_validate_identity(project_id,session_id,operation_id,model_id,revision,provider_id);route=self._attended_validate_route(runtime_route)
  try:
   with self._db() as c:
    authority,operation,_=self._attended_classify(c,project_id,session_id,operation_id)
    if authority is None:
     nonce=uuid.uuid4().hex;state='canonical' if route is not None else 'legacy_route_pending'
     digest=self._attended_authority_digest(nonce,project_id,session_id,operation_id,model_id,revision,provider_id,route,state)
     c.execute('INSERT INTO attended_admission_authority(authority_nonce,project_id,session_id,operation_id,model_id,revision,provider_id,runtime_binding_id,runtime_base_url,runtime_session_id,authority_version,migration_state,canonical_digest) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(nonce,project_id,session_id,operation_id,model_id,revision,provider_id,route.get('binding_id') if route else None,route.get('base_url') if route else None,route.get('session_id') if route else None,'1',state,digest))
     prepared={'state':'prepared'};response={'state':'prepared','operation_id':operation_id,'session_id':session_id};fingerprint=self._attended_fingerprint(project_id,session_id,operation_id,model_id,revision,provider_id,prepared,route,'prepared')
     c.execute('INSERT INTO attended_admission_ops(project_id,session_id,operation_id,fingerprint,fingerprint_version,model_id,revision,provider_id,provider_generation,state,admission,response,runtime_binding_id,runtime_base_url,runtime_session_id,authority_nonce) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(project_id,session_id,operation_id,fingerprint,'2',model_id,revision,provider_id,None,'prepared',_canon(prepared),_canon(response),route.get('binding_id') if route else None,route.get('base_url') if route else None,route.get('session_id') if route else None,nonce))
     return self._attended_public(c.execute('SELECT * FROM attended_admission_ops WHERE authority_nonce=?',(nonce,)).fetchone(),prepared,response,route)
    if any(authority[key]!=value for key,value in {'project_id':project_id,'session_id':session_id,'operation_id':operation_id,'model_id':model_id,'revision':revision,'provider_id':provider_id}.items()):raise CatalogConflict('attended admission operation conflicts')
    stored_admission,response,persisted_route,legacy=self._attended_validate_operation(authority,operation)
    if route is not None and persisted_route is not None and route!=persisted_route:raise CatalogConflict('attended runtime route conflicts')
    self._attended_complete_route(c,authority,operation,route)
    if legacy and operation['state'] in {'prepared','admitted','rejected'} and not (route is not None and persisted_route is None):
     canonical_route=persisted_route
     fingerprint=self._attended_fingerprint(project_id,session_id,operation_id,model_id,revision,provider_id,stored_admission,canonical_route,'prepared' if operation['state']=='prepared' else 'recorded')
     c.execute("UPDATE attended_admission_ops SET fingerprint=?,fingerprint_version='2' WHERE authority_nonce=?",(fingerprint,authority['authority_nonce']))
    current=c.execute('SELECT * FROM attended_admission_ops WHERE authority_nonce=?',(authority['authority_nonce'],)).fetchone();parsed=json.loads(current['admission']);payload=json.loads(current['response'])
    return self._attended_public(current,parsed,payload,self._attended_route(current))
  except sqlite3.IntegrityError as error:raise CatalogConflict('attended admission persistence conflicts') from error
 def attended_admission(self,project_id,session_id,operation_id):
  self._attended_validate_identity(project_id,session_id,operation_id,'placeholder','placeholder',None)
  try:
   with self._db() as c:
    authority,operation,_=self._attended_classify(c,project_id,session_id,operation_id)
    if authority is None:return None
    admission,response,route,_=self._attended_validate_operation(authority,operation)
    return self._attended_public(operation,admission,response,route)
  except sqlite3.IntegrityError as error:raise CatalogConflict('attended admission persistence conflicts') from error
 def observe_idle(self,model_id,revision,project_id,orchestrator_id,operation_id):
  """Record an idle consumer's durable request for orchestrator release.

  This is deliberately an observation-only operation: it never evicts a
  provider residency or changes a project reservation.
  """
  values=(model_id,revision,project_id,orchestrator_id,operation_id)
  if not all(isinstance(v,str) and _SAFE.fullmatch(v) for v in values): raise CatalogError('idle observation identity is invalid')
  with self._db() as c:
   existing=c.execute('SELECT * FROM release_intents WHERE model_id=? AND revision=? AND project_id=?',(model_id,revision,project_id)).fetchone()
   if existing:
    if existing['orchestrator_id']!=orchestrator_id: raise CatalogConflict('release intent identity conflicts')
    # A restarted or concurrently duplicated authenticated owner may have a
    # fresh operation id. The durable tuple is the reconciliation key; keep
    # the original intent id authoritative and replay it to the same owner.
    return self._release_intent_row(existing)
   consumer=c.execute("SELECT state FROM model_consumers WHERE model_id=? AND revision=? AND project_id=?",(model_id,revision,project_id)).fetchone()
   if not consumer or consumer['state']!='consuming': return {'state':'retained','reason':'consumer_not_active','model_id':model_id,'revision':revision,'project_id':project_id}
   other=c.execute("SELECT 1 FROM model_consumers WHERE model_id=? AND revision=? AND project_id<>? AND state='consuming' LIMIT 1",(model_id,revision,project_id)).fetchone()
   pending=c.execute("SELECT 1 FROM inference_requests WHERE model_id=? AND revision=? AND state IN ('submitting','queued','active','unknown') LIMIT 1",(model_id,revision)).fetchone()
   if other or pending: return {'state':'retained','reason':'other_consumer_or_request_active','model_id':model_id,'revision':revision,'project_id':project_id}
   c.execute('INSERT INTO release_intents(model_id,revision,project_id,orchestrator_id,intent_id,operation_id,state,acknowledgement) VALUES(?,?,?,?,?,?,?,NULL)',(model_id,revision,project_id,orchestrator_id,operation_id,operation_id,'release_requested'))
   return {'model_id':model_id,'revision':revision,'project_id':project_id,'orchestrator_id':orchestrator_id,'intent_id':operation_id,'operation_id':operation_id,'state':'release_requested','acknowledgement':None}
 def release_intent(self,intent_id,project_id,orchestrator_id):
  if not all(isinstance(v,str) and _SAFE.fullmatch(v) for v in (intent_id,project_id,orchestrator_id)): raise CatalogError('release intent identity is invalid')
  with self._db() as c:
   row=c.execute('SELECT * FROM release_intents WHERE intent_id=? AND project_id=?',(intent_id,project_id)).fetchone()
  if not row or row['orchestrator_id']!=orchestrator_id: raise CatalogConflict('release intent is not owned by orchestrator')
  return self._release_intent_row(row)
 def release_intent_status(self,intent_id,project_id):
  if not all(isinstance(v,str) and _SAFE.fullmatch(v) for v in (intent_id,project_id)): raise CatalogError('release intent identity is invalid')
  with self._db() as c: row=c.execute('SELECT * FROM release_intents WHERE intent_id=? AND project_id=?',(intent_id,project_id)).fetchone()
  if not row: raise CatalogConflict('unknown release intent')
  return self._release_intent_row(row)
 def acknowledge_release(self,intent_id,project_id,orchestrator_id,acknowledgement):
  if not isinstance(acknowledgement,Mapping) or acknowledgement.get('state') not in {'acknowledged','rejected'}: raise CatalogError('release acknowledgement is invalid')
  with self._db() as c:
   row=c.execute('SELECT * FROM release_intents WHERE intent_id=? AND project_id=?',(intent_id,project_id)).fetchone()
   if not row or row['orchestrator_id']!=orchestrator_id: raise CatalogConflict('release intent is not owned by orchestrator')
   if row['state'] not in {'release_requested','acknowledged','rejected'}: raise CatalogConflict('release intent requires reconciliation')
   if row['state'] in {'acknowledged','rejected'}:
    if json.loads(row['acknowledgement'])!=dict(acknowledgement): raise CatalogConflict('release acknowledgement conflicts')
   else:c.execute('UPDATE release_intents SET state=?,acknowledgement=? WHERE intent_id=?',(acknowledgement['state'],_canon(dict(acknowledgement)),intent_id));row=c.execute('SELECT * FROM release_intents WHERE intent_id=?',(intent_id,)).fetchone()
  return self._release_intent_row(row)
 def _release_intent_row(self,row):
  return {key:row[key] for key in ('model_id','revision','project_id','orchestrator_id','intent_id','operation_id','state')} | {'acknowledgement':json.loads(row['acknowledgement']) if row['acknowledgement'] else None}
 acknowledge_release_intent=acknowledge_release
 def request_unload(self,model_id,revision,key='unload'):
  with self._db() as c:
   consumers=c.execute("SELECT project_id FROM model_consumers WHERE model_id=? AND revision=? AND state='consuming'",(model_id,revision)).fetchall()
   row=c.execute('SELECT * FROM unload_requests WHERE model_id=? AND revision=?',(model_id,revision)).fetchone()
   if row is None:
    c.execute('INSERT INTO unload_requests(model_id,revision,state) VALUES(?,?,?)',(model_id,revision,'waiting_release'))
    state='waiting_release'; operation_id=None; provider_id=None; generation=None; receipt=None
   else:
    # Retries must not erase the active claim or its reconciliation receipt.
    state=row['state']; operation_id=row['operation_id']; provider_id=row['provider_id']; generation=row['provider_generation']; receipt=json.loads(row['receipt']) if row['receipt'] else None
   return {'state':state,'projects':[r['project_id'] for r in consumers],'idempotency_key':key,**({'operation_id':operation_id} if operation_id is not None else {}),**({'provider_id':provider_id,'generation':generation} if provider_id is not None else {}),**({'receipt':receipt} if receipt is not None else {})}
 def release(self,model_id,revision,project_id,provider_receipt,key='release'):
  if not isinstance(provider_receipt,Mapping) or set(provider_receipt)!={'model_id','revision','provider_id','generation','state','residency_id'} or provider_receipt.get('model_id')!=model_id or provider_receipt.get('revision')!=revision or not isinstance(provider_receipt.get('provider_id'),str) or not _SAFE.fullmatch(provider_receipt['provider_id']) or type(provider_receipt.get('generation')) is not int or provider_receipt['generation']<1 or not isinstance(provider_receipt.get('residency_id'),str) or not _SAFE.fullmatch(provider_receipt['residency_id']) or provider_receipt.get('state')!='released':raise CatalogError('provider release receipt is invalid')
  with self._db() as c:
   consumer=c.execute("SELECT state,residency_id FROM model_consumers WHERE model_id=? AND revision=? AND project_id=?",(model_id,revision,project_id)).fetchone()
   if consumer is None: raise CatalogConflict('release requires an existing consumer')
   if consumer['residency_id'] is None or consumer['residency_id']!=provider_receipt['residency_id']: raise CatalogConflict('release residency identity does not match current admission')
   request=c.execute("SELECT * FROM unload_requests WHERE model_id=? AND revision=?",(model_id,revision)).fetchone()
   def bind_request(request):
    if request is None:return
    if request['provider_id'] is not None and (request['provider_id']!=provider_receipt['provider_id'] or request['provider_generation']!=provider_receipt['generation']): raise CatalogConflict('provider generation changed during release')
   bind_request(request)
   if consumer['state']!='consuming':
    # A valid replay is allowed to reconcile a release already accepted for
    # this durable consumer, but a released/unknown key cannot create state.
    if consumer['state']!='released' or not request or request['state'] not in {'waiting_release','ready_for_physical_unload','unloading','unloaded'} or (request['provider_id'] is not None and (request['provider_id']!=provider_receipt['provider_id'] or request['provider_generation']!=provider_receipt['generation'])):
     raise CatalogConflict('release requires a consuming consumer or valid replay')
    if request['state'] in {'ready_for_physical_unload','unloading','unloaded'}:
     return {'state':request['state'],'release_receipt':dict(provider_receipt)}
   c.execute("UPDATE model_consumers SET state='released' WHERE model_id=? AND revision=? AND project_id=?",(model_id,revision,project_id));active=c.execute("SELECT 1 FROM model_consumers WHERE model_id=? AND revision=? AND state='consuming'",(model_id,revision)).fetchone()
   if not active:
    pending=c.execute("SELECT 1 FROM inference_requests WHERE model_id=? AND revision=? AND state IN ('submitting','queued','active','unknown') LIMIT 1",(model_id,revision)).fetchone()
    if pending:
     if request is None:
      c.execute("INSERT INTO unload_requests(model_id,revision,state,project_id,residency_id,provider_id,provider_generation,receipt) VALUES(?,?,?,?,?,?,?,?)",(model_id,revision,'waiting_release',project_id,consumer['residency_id'],provider_receipt['provider_id'],provider_receipt['generation'],_canon(dict(provider_receipt))))
     elif request['state'] not in {'unloading','unloaded'} and request['project_id'] is None:
      c.execute("UPDATE unload_requests SET project_id=?,residency_id=?,provider_id=?,provider_generation=?,receipt=? WHERE model_id=? AND revision=?",(project_id,consumer['residency_id'],provider_receipt['provider_id'],provider_receipt['generation'],_canon(dict(provider_receipt)),model_id,revision))
     return {'state':'waiting_release','reason':'request_not_resolved','release_receipt':dict(provider_receipt)}
    request=c.execute("SELECT state,provider_id,provider_generation FROM unload_requests WHERE model_id=? AND revision=?",(model_id,revision)).fetchone()
    if request and request['state'] not in {'unloaded','unloading'}:
     if request['provider_id'] is not None and (request['provider_id']!=provider_receipt['provider_id'] or request['provider_generation']!=provider_receipt['generation']): raise CatalogConflict('provider generation changed during release')
     c.execute("UPDATE unload_requests SET state='ready_for_physical_unload',project_id=COALESCE(project_id,?),residency_id=COALESCE(residency_id,?),provider_id=?,provider_generation=?,receipt=? WHERE model_id=? AND revision=?",(project_id,consumer['residency_id'],provider_receipt['provider_id'],provider_receipt['generation'],_canon(dict(provider_receipt)),model_id,revision))
     return {'state':'ready_for_physical_unload','release_receipt':dict(provider_receipt)}
    if request and request['state']=='unloading':
     if request['provider_id']!=provider_receipt['provider_id'] or request['provider_generation']!=provider_receipt['generation']: raise CatalogConflict('provider generation changed during release')
     return {'state':'unloading','release_receipt':dict(provider_receipt)}
    if request and request['state']=='unloaded':
     if request['provider_id']!=provider_receipt['provider_id'] or request['provider_generation']!=provider_receipt['generation']: raise CatalogConflict('provider generation changed during release')
     return {'state':'unloaded','release_receipt':dict(provider_receipt)}
    c.execute("INSERT INTO unload_requests(model_id,revision,state,project_id,residency_id,provider_id,provider_generation,receipt) VALUES(?,?,?,?,?,?,?,?)",(model_id,revision,'ready_for_physical_unload',project_id,consumer['residency_id'],provider_receipt['provider_id'],provider_receipt['generation'],_canon(dict(provider_receipt))))
    return {'state':'ready_for_physical_unload','release_receipt':dict(provider_receipt)}
   return {'state':'waiting_release','release_receipt':dict(provider_receipt)}
 def claim_physical_unload(self,model_id,revision,operation_id,provider_id,generation):
  """Durably claim the single provider effect before calling the provider."""
  if not all(isinstance(v,str) and _SAFE.fullmatch(v) for v in (model_id,revision,operation_id,provider_id)) or type(generation) is not int or generation<1: raise CatalogError('physical unload operation identity is invalid')
  with self._db() as c:
   row=c.execute('SELECT * FROM unload_requests WHERE model_id=? AND revision=?',(model_id,revision)).fetchone()
   if not row or row['state'] not in {'ready_for_physical_unload','unloading','unloaded'}: raise CatalogConflict('physical unload is not authorized')
   if row['state'] in {'unloading','unloaded'}:
    if row['operation_id']!=operation_id or row['provider_id']!=provider_id or row['provider_generation']!=generation: raise CatalogConflict('physical unload operation conflicts')
    return {'state':row['state'],'operation_id':operation_id,'claimed':False}
   if row['retired_operation_id']==operation_id: raise CatalogConflict('physical unload operation conflicts')
   if c.execute("SELECT 1 FROM model_consumers WHERE model_id=? AND revision=? AND state='consuming'",(model_id,revision)).fetchone(): raise CatalogConflict('physical unload is not authorized')
   if c.execute("SELECT 1 FROM inference_requests WHERE model_id=? AND revision=? AND state IN ('submitting','queued','active','unknown') LIMIT 1",(model_id,revision)).fetchone(): raise CatalogConflict('physical unload requires resolved requests')
   if row['provider_id']!=provider_id or row['provider_generation']!=generation: raise CatalogConflict('provider generation changed during unload')
   c.execute("UPDATE unload_requests SET state='unloading',operation_id=?,retired_operation_id=NULL WHERE model_id=? AND revision=?",(operation_id,model_id,revision))
   return {'state':'unloading','operation_id':operation_id,'claimed':True,'provider_id':provider_id,'generation':generation}
  begin_physical_unload=claim_physical_unload
 def physical_unload(self,model_id,revision,receipt):
  if (not isinstance(receipt,Mapping) or set(receipt)!={'model_id','revision','provider_id','generation','state','operation_id'} or receipt.get('model_id')!=model_id or receipt.get('revision')!=revision or receipt.get('state')!='unloaded' or not isinstance(receipt.get('provider_id'),str) or type(receipt.get('generation')) is not int or receipt.get('generation')<1 or not isinstance(receipt.get('operation_id'),str) or not _SAFE.fullmatch(receipt['operation_id'])):raise CatalogError('physical unload receipt invalid')
  with self._db() as c:
   active=c.execute("SELECT 1 FROM model_consumers WHERE model_id=? AND revision=? AND state='consuming'",(model_id,revision)).fetchone();request=c.execute('SELECT * FROM unload_requests WHERE model_id=? AND revision=?',(model_id,revision)).fetchone()
   if active or not request or request['state'] not in {'unloading','unloaded'}:raise CatalogConflict('physical unload requires a durable claim')
   if request['provider_id'] is not None and (request['provider_id']!=receipt['provider_id'] or request['provider_generation']!=receipt['generation']):raise CatalogConflict('provider generation changed during unload')
   if request['operation_id']!=receipt['operation_id']:raise CatalogConflict('physical unload operation is unknown')
   if request['state']=='unloaded': return {'state':'unloaded','operation_id':request['operation_id'],'physical_unload_receipt':json.loads(request['receipt']) if request['receipt'] else dict(receipt)}
   c.execute("UPDATE unload_requests SET state='unloaded',provider_id=?,provider_generation=?,receipt=? WHERE model_id=? AND revision=?",(receipt['provider_id'],receipt['generation'],_canon(dict(receipt)),model_id,revision));return {'state':'unloaded','operation_id':receipt['operation_id'],'physical_unload_receipt':dict(receipt)}
 def request_record(self,request_id):
  with self._db() as c: row=c.execute('SELECT * FROM inference_requests WHERE request_id=?',(request_id,)).fetchone()
  if row is None:return None
  result=dict(row)
  if result.get('outcome') is not None:
   try:result['outcome']=_sanitize_outcome(json.loads(result['outcome']))
   except (TypeError,json.JSONDecodeError): raise CatalogConflict('inference request outcome is corrupt')
  self._validate_request_record(result)
  return result
 def _validate_request_record(self,result):
  if not isinstance(result,Mapping) or not all(isinstance(result.get(k),str) and _SAFE.fullmatch(result[k]) for k in ('request_id','effect_id','project_id','model_id','revision')) or result.get('effect_id') != result.get('request_id'):
   raise CatalogConflict('inference request identity is corrupt')
  if result.get('state') not in {'submitting','queued','active','completed','failed','unknown'}: raise CatalogConflict('inference request state is corrupt')
  provider_id,generation=result.get('provider_id'),result.get('provider_generation')
  if provider_id is not None and (not isinstance(provider_id,str) or not _SAFE.fullmatch(provider_id)): raise CatalogConflict('inference request provider is corrupt')
  if generation is not None and (type(generation) is not int or generation<1): raise CatalogConflict('inference request provider generation is corrupt')
  updated_at=result.get('updated_at')
  if not isinstance(updated_at,str) or not updated_at: raise CatalogConflict('inference request timestamp is corrupt')
  if not _UTC_RFC3339.fullmatch(updated_at): raise CatalogConflict('inference request timestamp is corrupt')
  try: parsed=datetime.fromisoformat(updated_at.replace('Z','+00:00'))
  except (TypeError,ValueError): raise CatalogConflict('inference request timestamp is corrupt') from None
  if parsed.tzinfo is None or parsed.utcoffset() != timezone.utc.utcoffset(parsed): raise CatalogConflict('inference request timestamp is corrupt')
  outcome=result.get('outcome')
  if outcome is not None and (not isinstance(outcome,Mapping) or outcome.get('request_id')!=result['request_id'] or outcome.get('effect_id')!=result['effect_id'] or outcome.get('state')!=result['state']): raise CatalogConflict('inference request outcome identity is corrupt')
 def request_records(self,project_ids=None, limit=200):
  if type(limit) is not int or not 1 <= limit <= 200: raise CatalogError('inference request limit is invalid')
  with self._db() as c:
   if project_ids is None:
    rows=c.execute('SELECT request_id FROM inference_requests ORDER BY updated_at, request_id LIMIT ?', (limit,)).fetchall()
   else:
    if not isinstance(project_ids, (frozenset, set, tuple, list)) or not all(isinstance(project_id, str) for project_id in project_ids): raise CatalogError('inference request projects are invalid')
    if not project_ids: return []
    marks=','.join('?' for _ in project_ids)
    rows=c.execute(f'SELECT request_id FROM inference_requests WHERE project_id IN ({marks}) ORDER BY updated_at, request_id LIMIT ?', (*sorted(project_ids), limit)).fetchall()
  records=[]
  for row in rows:
   record=self.request_record(row['request_id'])
   records.append(record)
  return records
 def record_request(self,request_id,project_id,model_id,revision,state,*,provider_id=None,provider_generation=None,outcome=None,effect_id=None):
  effect_id=effect_id or request_id
  if not all(isinstance(v,str) and _SAFE.fullmatch(v) for v in (request_id,project_id,model_id,revision,effect_id)) or effect_id!=request_id or state not in {'submitting','queued','active','completed','failed','unknown'}: raise CatalogError('inference request is invalid')
  with self._db() as c:
   old=c.execute('SELECT project_id,model_id,revision,effect_id FROM inference_requests WHERE request_id=?',(request_id,)).fetchone()
   if old:
    if any(old[k]!=v for k,v in {'project_id':project_id,'model_id':model_id,'revision':revision,'effect_id':effect_id}.items()):raise CatalogConflict('idempotency conflict')
    return self.request_record(request_id)
   now=self.clock().astimezone(timezone.utc).isoformat().replace('+00:00','Z')
   c.execute('INSERT INTO inference_requests VALUES(?,?,?,?,?,?,?,?,?,?)',(request_id,effect_id,project_id,model_id,revision,state,provider_id,provider_generation,_canon(_sanitize_outcome(outcome)) if outcome is not None else None,now))
  return self.request_record(request_id)
 def claim_request(self,request_id,project_id,model_id,revision,provider_id,provider_generation):
  if type(provider_generation) is not int or provider_generation<1:raise CatalogError('inference request claim is invalid')
  with self._db() as c:
   old=c.execute('SELECT * FROM inference_requests WHERE request_id=?',(request_id,)).fetchone()
   if old:
    if any(old[k]!=v for k,v in {'project_id':project_id,'model_id':model_id,'revision':revision,'provider_id':provider_id,'provider_generation':provider_generation,'effect_id':request_id}.items()):raise CatalogConflict('idempotency conflict')
    return dict(old),False
   now=self.clock().astimezone(timezone.utc).isoformat().replace('+00:00','Z')
   c.execute('INSERT INTO inference_requests VALUES(?,?,?,?,?,?,?,?,?,?)',(request_id,request_id,project_id,model_id,revision,'submitting',provider_id,provider_generation,None,now))
   row=c.execute('SELECT * FROM inference_requests WHERE request_id=?',(request_id,)).fetchone()
  return dict(row),True
 def update_request(self,request_id,state,*,outcome):
  if state not in {'submitting','queued','active','completed','failed','unknown'} or not isinstance(outcome,Mapping) or outcome.get('request_id')!=request_id or outcome.get('effect_id')!=request_id or outcome.get('state')!=state:raise CatalogError('inference outcome identities must match request')
  with self._db() as c:
   old=c.execute('SELECT * FROM inference_requests WHERE request_id=?',(request_id,)).fetchone()
   if old is None:raise CatalogError('unknown inference request')
   if old['state'] in {'completed','failed'}:return dict(old)
   safe_outcome=_sanitize_outcome(outcome)
   now=self.clock().astimezone(timezone.utc).isoformat().replace('+00:00','Z');c.execute('UPDATE inference_requests SET state=?,outcome=?,updated_at=? WHERE request_id=?',(state,_canon(safe_outcome),now,request_id));row=c.execute('SELECT * FROM inference_requests WHERE request_id=?',(request_id,)).fetchone()
  return dict(row)|{'outcome':safe_outcome}
 def _availability(self,value,entry,fresh=True):
  capability=value.get('capability') if isinstance(value,Mapping) else None
  capability_declared=isinstance(value,Mapping) and 'capability' in value
  if not isinstance(value,Mapping) or set(value)-{'provider_id','generation','model_id','revision','tested','lease_expires_at','capability'} or not {'provider_id','generation','model_id','revision','tested','lease_expires_at'} <= set(value) or value.get('model_id')!=entry['model_id'] or value.get('revision')!=entry['revision'] or not isinstance(value.get('provider_id'),str) or not _SAFE.fullmatch(value['provider_id']) or type(value.get('generation')) is not int or value['generation']<1 or value.get('tested') is not True or (capability_declared and (not isinstance(capability,str) or not _SAFE.fullmatch(capability) or not capability.startswith('inference.'))):return False
  try:return not fresh or datetime.fromisoformat(value['lease_expires_at'].replace('Z','+00:00')).astimezone(timezone.utc)>self.clock()
  except (AttributeError,ValueError):return False
