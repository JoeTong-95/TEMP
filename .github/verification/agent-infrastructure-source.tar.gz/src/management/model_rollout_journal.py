"""Durable, human-gated model-watch policy; it never downloads or loads models."""
from __future__ import annotations
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import json, sqlite3, math, uuid
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol
from .feishu_transport import OperationalNotice
from .model_capability_catalog import ModelCapabilityCatalog, CatalogError
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root

class ModelRolloutError(ValueError): pass
class NoticeQueue(Protocol):
    def queue(self, route: str, notice: OperationalNotice) -> dict[str, Any]: ...
def _stamp(value: datetime) -> str: return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z")
def _parse(value: str) -> datetime: return datetime.fromisoformat(value.replace("Z","+00:00")).astimezone(timezone.utc)
def _text(value: object, name: str) -> str:
    if not isinstance(value,str) or not value or len(value)>128: raise ModelRolloutError(f"{name} is invalid")
    return value

class ModelRolloutJournal:
    _CLAIM_LEASE = timedelta(minutes=5)
    def __init__(self, database: Path, catalog: ModelCapabilityCatalog, *, clock: Callable[[],datetime] | None=None, canary_observation_seconds: int=86400):
        database_path=Path(database);self.catalog=catalog;self.clock=clock or (lambda:datetime.now(timezone.utc));self.canary_observation_seconds=canary_observation_seconds
        if type(canary_observation_seconds) is not int or not 300 <= canary_observation_seconds <= 604800: raise ModelRolloutError("canary observation duration is invalid")
        try:
            state_root = validate_state_root(database_path.parent, "model rollout state root")
            self.path = validate_durable_leaf(database_path, state_root, label="model rollout database")
        except ManagementStateBoundaryError as error: raise ModelRolloutError(str(error)) from error
        with self._db() as c:
            c.executescript("CREATE TABLE IF NOT EXISTS model_watches(model_id TEXT,revision TEXT,entry_json TEXT,reviewer TEXT,route TEXT,notice_at TEXT,rejected_at TEXT,complaint_json TEXT,canary_json TEXT,promotion_json TEXT,rollback_json TEXT,proposal_json TEXT,budgets_json TEXT,previous_version TEXT,notification_receipt_json TEXT,blocked_at TEXT,PRIMARY KEY(model_id,revision));")
            columns={row["name"] for row in c.execute("PRAGMA table_info(model_watches)")}
            for name, declaration in (("proposal_json", "TEXT"), ("budgets_json", "TEXT"),
                                      ("previous_version", "TEXT"),
                                      ("notification_receipt_json", "TEXT"), ("blocked_at", "TEXT"),
                                      ("notice_claim_json", "TEXT"), ("promotion_claim_json", "TEXT")):
                if name not in columns:c.execute(f"ALTER TABLE model_watches ADD COLUMN {name} {declaration}")
    @contextmanager
    def _db(self):
        c=sqlite3.connect(self.path);c.row_factory=sqlite3.Row
        try:yield c;c.commit()
        finally:c.close()
    def review_candidate(self, entry: Mapping[str,Any], reviewer: str, route: str, *,
                         proposal: Mapping[str, Any] | None = None,
                         budgets: Mapping[str, Any] | None = None,
                         previous_working_version: str | None = None) -> dict[str,Any]:
        _text(reviewer,"reviewer");_text(route,"route")
        if not isinstance(entry,Mapping) or entry.get("rollout_state")!="trial":raise ModelRolloutError("candidate must be a reviewed trial catalog entry")
        try:self.catalog.register(entry)
        except CatalogError as error:raise ModelRolloutError("candidate violates immutable catalog") from error
        model_id,revision=_text(entry.get("model_id"),"model_id"),_text(entry.get("revision"),"revision");encoded=json.dumps(dict(entry),sort_keys=True,separators=(",",":"),allow_nan=False)
        if proposal is not None and not isinstance(proposal, Mapping): raise ModelRolloutError("reviewed proposal is invalid")
        if budgets is not None and not isinstance(budgets, Mapping): raise ModelRolloutError("budgets are invalid")
        proposal = dict(entry) if proposal is None else dict(proposal)
        budgets = dict(entry.get("envelope", {})) if budgets is None else dict(budgets)
        if not proposal or not budgets or any(not isinstance(k, str) for k in budgets) or any(type(v) not in (int,float) or not math.isfinite(v) or v < 0 for v in budgets.values()):
            raise ModelRolloutError("reviewed proposal or budgets are invalid")
        if previous_working_version is None: previous_working_version = entry.get("previous_working_version")
        if previous_working_version is None: raise ModelRolloutError("previous_working_version is required")
        _text(previous_working_version, "previous_working_version")
        proposal_encoded=json.dumps(proposal,sort_keys=True,separators=(",",":"),allow_nan=False)
        budgets_encoded=json.dumps(budgets,sort_keys=True,separators=(",",":"),allow_nan=False)
        with self._db() as c:
            row=c.execute("SELECT entry_json,reviewer,route,proposal_json,budgets_json,previous_version FROM model_watches WHERE model_id=? AND revision=?",(model_id,revision)).fetchone()
            if row:
                if tuple(row)!=(encoded,reviewer,route,proposal_encoded,budgets_encoded,previous_working_version):raise ModelRolloutError("candidate watch is immutable")
                return {"model_id":model_id,"revision":revision,"state":"reviewed","duplicate":True}
            c.execute("INSERT INTO model_watches(model_id,revision,entry_json,reviewer,route,notice_at,rejected_at,complaint_json,canary_json,promotion_json,rollback_json,proposal_json,budgets_json,previous_version,notification_receipt_json,blocked_at) VALUES(?,?,?,?,?,NULL,NULL,NULL,NULL,NULL,NULL,?,?,?,NULL,NULL)",(model_id,revision,encoded,reviewer,route,proposal_encoded,budgets_encoded,previous_working_version))
        return {"model_id":model_id,"revision":revision,"state":"reviewed","duplicate":False}
    def queue_notice(self, model_id: str, revision: str, notifier: NoticeQueue) -> dict[str,Any]:
        row=self._row(model_id,revision)
        if row["notice_at"] is not None:return {"state":"noticed","duplicate":True,"noticed_at":row["notice_at"]}
        if row["blocked_at"] is not None: raise ModelRolloutError("candidate is blocked")
        # A durable claim closes the check/call/write race.  A stale claim is
        # deliberately retryable after restart; an in-flight claim is not.
        owner=uuid.uuid4().hex
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            fresh=c.execute("SELECT notice_at,notice_claim_json,blocked_at FROM model_watches WHERE model_id=? AND revision=?",(model_id,revision)).fetchone()
            if fresh["notice_at"] is not None:return {"state":"noticed","duplicate":True,"noticed_at":fresh["notice_at"]}
            if fresh["blocked_at"] is not None: raise ModelRolloutError("candidate is blocked")
            claim=json.loads(fresh["notice_claim_json"] or "null")
            if claim and claim.get("state")=="sending" and claim.get("owner")!=owner:
                if not self._claim_stale(claim):
                    return {"state":"queued","duplicate":True,"noticed_at":None}
                c.execute("UPDATE model_watches SET notice_claim_json=NULL WHERE model_id=? AND revision=?",(model_id,revision))
            c.execute("UPDATE model_watches SET notice_claim_json=? WHERE model_id=? AND revision=?",(json.dumps({"state":"sending","owner":owner,"claimed_at":_stamp(self.clock())}),model_id,revision))
        notice=OperationalNotice("model_rollout",model_id+":"+revision,"Codex-reviewed candidate awaiting rejection window", "model-rollout:"+model_id+":"+revision)
        try: receipt=notifier.queue(row["route"],notice)
        except Exception:
            with self._db() as c:c.execute("UPDATE model_watches SET notice_claim_json=NULL WHERE model_id=? AND revision=?",(model_id,revision))
            raise
        if isinstance(receipt, Mapping) and receipt.get("state") in {"pending", "queued"}:
            with self._db() as c:c.execute("UPDATE model_watches SET notice_claim_json=NULL WHERE model_id=? AND revision=?",(model_id,revision))
            return {"state":"queued","duplicate":False,"noticed_at":None}
        if not self._valid_delivery(row, receipt, expected_correlation="model-rollout:" + model_id + ":" + revision):
            with self._db() as c:c.execute("UPDATE model_watches SET notice_claim_json=NULL,blocked_at=? WHERE model_id=? AND revision=?",(_stamp(self.clock()),model_id,revision))
            raise ModelRolloutError("notification delivery failed")
        return self.record_notification_delivery(model_id, revision, receipt)

    def record_notification_delivery(self, model_id: str, revision: str, receipt: Mapping[str, Any]) -> dict[str, Any]:
        """Persist transport-confirmed delivery; queueing is never a receipt."""
        row=self._row(model_id,revision)
        if not self._valid_delivery(row, receipt, expected_correlation="model-rollout:" + model_id + ":" + revision):
            with self._db() as c:c.execute("UPDATE model_watches SET blocked_at=? WHERE model_id=? AND revision=?",(_stamp(self.clock()),model_id,revision))
            raise ModelRolloutError("notification delivery receipt is unsuccessful")
        encoded=json.dumps(dict(receipt),sort_keys=True,separators=(",",":"),allow_nan=False);now=_stamp(self.clock())
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            fresh=c.execute("SELECT notice_at,notification_receipt_json FROM model_watches WHERE model_id=? AND revision=?",(model_id,revision)).fetchone()
            stored_json=fresh["notification_receipt_json"]
            if stored_json is not None:
                stored=json.loads(stored_json)
                if stored_json != encoded:
                    raise ModelRolloutError("notification delivery receipt conflicts with stored receipt")
                return {"state":"noticed","duplicate":True,"noticed_at":fresh["notice_at"],"receipt":stored}
            c.execute("UPDATE model_watches SET notice_at=COALESCE(notice_at,?),notification_receipt_json=?,notice_claim_json=NULL WHERE model_id=? AND revision=?",(now,encoded,model_id,revision))
            noticed_at=fresh["notice_at"] or now
        return {"state":"noticed","duplicate":row["notice_at"] is not None,"noticed_at":noticed_at,"receipt":dict(receipt)}
    def complaint(self, model_id: str, revision: str, complaint_id: str, content: str, *, reject: bool=False) -> dict[str,Any]:
        row=self._row(model_id,revision);_text(complaint_id,"complaint_id");_text(content,"complaint")
        if type(reject) is not bool:raise ModelRolloutError("reject flag is invalid")
        value={"complaint_id":complaint_id,"content":content,"rejected":reject}
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            fresh=c.execute("SELECT complaint_json,rejected_at,promotion_json,promotion_claim_json FROM model_watches WHERE model_id=? AND revision=?",(model_id,revision)).fetchone()
            if fresh["promotion_json"] is not None or fresh["promotion_claim_json"] is not None:
                raise ModelRolloutError("promotion is already claimed or decided")
            complaints=json.loads(fresh["complaint_json"] or "[]")
            if value not in complaints:complaints.append(value)
            now=_stamp(self.clock()) if reject else fresh["rejected_at"]
            c.execute("UPDATE model_watches SET complaint_json=?,rejected_at=? WHERE model_id=? AND revision=?",(json.dumps(complaints,sort_keys=True),now,model_id,revision))
        return {"state":"rejected" if reject else "complaint_recorded","complaints":len(complaints)}
    def request_canary(self, model_id: str, revision: str, *,
                      provider_id: str | None = None,
                      budgets: Mapping[str, Any] | None = None,
                      configured_provider: str | None = None) -> dict[str,Any]:
        row=self._row(model_id,revision)
        if row["rejected_at"] is not None or row["blocked_at"] is not None or row["complaint_json"] not in (None, "", "[]"):raise ModelRolloutError("candidate is not eligible")
        entry=json.loads(row["entry_json"]); availability=entry["availability"]
        selected_provider = configured_provider if configured_provider is not None else provider_id
        if selected_provider is not None and selected_provider != availability.get("provider_id"): raise ModelRolloutError("configured provider is unavailable")
        if not isinstance(selected_provider, str) or not selected_provider or selected_provider != availability.get("provider_id"):
            raise ModelRolloutError("configured provider is required and unavailable")
        if not isinstance(budgets, Mapping) or any(type(v) not in (int,float) or not math.isfinite(v) or v < 0 for v in budgets.values()): raise ModelRolloutError("configured budgets are invalid")
        required=json.loads(row["budgets_json"] or "{}")
        if any(k not in budgets or float(budgets[k]) < float(v) for k,v in required.items()): raise ModelRolloutError("configured budgets are insufficient")
        if not row["budgets_json"] or not json.loads(row["budgets_json"]): raise ModelRolloutError("configured budgets are absent")
        notice_receipt=json.loads(row["notification_receipt_json"] or "null")
        if not self._valid_delivery(row, notice_receipt, expected_correlation="model-rollout:" + model_id + ":" + revision):
            raise ModelRolloutError("authenticated initial notice delivery is required")
        notice_at=row["notice_at"]
        if notice_at is None or self.clock()< _parse(notice_at)+timedelta(hours=24):raise ModelRolloutError("24 hour not_rejected boundary has not elapsed")
        if row["canary_json"] is not None:return json.loads(row["canary_json"])
        result={"state":"canary_requested","model_id":model_id,"revision":revision,"measured_only":True,"no_download":True}
        with self._db() as c:c.execute("UPDATE model_watches SET canary_json=? WHERE model_id=? AND revision=?",(json.dumps(result,sort_keys=True),model_id,revision))
        return result
    def verify_canary(self, model_id: str, revision: str, receipt: Mapping[str,Any]) -> dict[str,Any]:
        row=self._row(model_id,revision);current=json.loads(row["canary_json"] or "{}")
        if current.get("state") not in {"canary_requested","canary_verified"}:raise ModelRolloutError("canary was not requested")
        required={"model_id","revision","provider_id","generation","state","measured_at"}
        if not isinstance(receipt,Mapping) or set(receipt)!=required or receipt.get("model_id")!=model_id or receipt.get("revision")!=revision or receipt.get("state")!="verified" or type(receipt.get("generation")) is not int or receipt["generation"]<1:
            raise ModelRolloutError("canary receipt is invalid")
        entry=json.loads(row["entry_json"]);availability=entry["availability"]
        if receipt["provider_id"]!=availability["provider_id"] or receipt["generation"]!=availability["generation"] or not self.catalog._availability(availability,entry):raise ModelRolloutError("provider/model evidence is not fresh")
        try: observed=_parse(receipt["measured_at"])
        except (TypeError, ValueError): raise ModelRolloutError("canary receipt timestamp is invalid") from None
        result={"state":"canary_verified","receipt":dict(receipt),"observation_ends_at":_stamp(observed+timedelta(seconds=self.canary_observation_seconds))}
        with self._db() as c:c.execute("UPDATE model_watches SET canary_json=? WHERE model_id=? AND revision=?",(json.dumps(result,sort_keys=True),model_id,revision))
        return result
    def finish_observation(self, model_id: str, revision: str, notifier: NoticeQueue) -> dict[str,Any]:
        row=self._row(model_id,revision);canary=json.loads(row["canary_json"] or "{}")
        if row["promotion_json"] is not None:return {**json.loads(row["promotion_json"]),"duplicate":True}
        if row["blocked_at"] is not None or row["rejected_at"] is not None or json.loads(row["complaint_json"] or "[]") or canary.get("state")!="canary_verified" or self.clock()<_parse(canary["observation_ends_at"]):raise ModelRolloutError("canary observation is incomplete or rejected")
        entry=json.loads(row["entry_json"]);availability=entry["availability"]
        if not self.catalog._availability(availability,entry):raise ModelRolloutError("provider/model evidence is no longer fresh")
        owner=uuid.uuid4().hex
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            fresh=c.execute("SELECT promotion_json,promotion_claim_json,notification_receipt_json,blocked_at,rejected_at,complaint_json FROM model_watches WHERE model_id=? AND revision=?",(model_id,revision)).fetchone()
            if fresh["promotion_json"] is not None:return {**json.loads(fresh["promotion_json"]),"duplicate":True}
            if fresh["blocked_at"] is not None or fresh["rejected_at"] is not None or json.loads(fresh["complaint_json"] or "[]"):
                raise ModelRolloutError("canary observation is incomplete or rejected")
            claim=json.loads(fresh["promotion_claim_json"] or "null")
            if claim and claim.get("state")=="sending" and claim.get("owner")!=owner:
                if not self._claim_stale(claim):return {"state":"promotion_pending","duplicate":True}
                c.execute("UPDATE model_watches SET promotion_claim_json=NULL WHERE model_id=? AND revision=?",(model_id,revision))
            if fresh["notification_receipt_json"] is None: raise ModelRolloutError("notification delivery is not confirmed")
            c.execute("UPDATE model_watches SET promotion_claim_json=? WHERE model_id=? AND revision=?",(json.dumps({"state":"sending","owner":owner,"claimed_at":_stamp(self.clock())}),model_id,revision))
        try: promotion_receipt=notifier.queue(row["route"],OperationalNotice("model_rollout",model_id+":"+revision,"Canary observation completed without complaint or failure; promoted current", "model-promoted:"+model_id+":"+revision))
        except Exception:
            with self._db() as c:c.execute("UPDATE model_watches SET promotion_claim_json=NULL WHERE model_id=? AND revision=?",(model_id,revision))
            raise
        if not self._valid_delivery(row, promotion_receipt, expected_correlation="model-promoted:" + model_id + ":" + revision):
            with self._db() as c:c.execute("UPDATE model_watches SET promotion_claim_json=NULL,blocked_at=? WHERE model_id=? AND revision=?",(_stamp(self.clock()),model_id,revision))
            raise ModelRolloutError("promotion notification delivery failed")
        result={"state":"promotion_decided","decision":"promote_current","actor":"automatic_after_observation","receipt":canary["receipt"],"notification_receipt":dict(promotion_receipt),"observation_ends_at":canary["observation_ends_at"]}
        with self._db() as c:
            changed=c.execute("UPDATE model_watches SET promotion_json=?,promotion_claim_json=NULL WHERE model_id=? AND revision=? AND blocked_at IS NULL",(json.dumps(result,sort_keys=True),model_id,revision)).rowcount
            if changed != 1:
                raise ModelRolloutError("canary observation is incomplete or rejected")
        return result
    def rollback(self, model_id: str, revision: str, actor: str, reason: str) -> dict[str,Any]:
        _text(actor,"actor");_text(reason,"reason");self._row(model_id,revision)
        if actor not in {"human","codex"}:raise ModelRolloutError("human or Codex rollback is required")
        result={"state":"rollback_decided","actor":actor,"reason":reason}
        with self._db() as c:c.execute("UPDATE model_watches SET rollback_json=? WHERE model_id=? AND revision=?",(json.dumps(result,sort_keys=True),model_id,revision))
        return result
    def _row(self, model_id: str, revision: str):
        with self._db() as c:row=c.execute("SELECT * FROM model_watches WHERE model_id=? AND revision=?",(_text(model_id,"model_id"),_text(revision,"revision"))).fetchone()
        if row is None:raise ModelRolloutError("candidate watch is absent")
        return row

    def _valid_delivery(self, row, receipt: Mapping[str, Any], *, expected_correlation: str | None = None) -> bool:
        if not isinstance(receipt, Mapping) or receipt.get("state") not in {"delivered", "success", "succeeded"}: return False
        message=receipt.get("message_id") or receipt.get("external_message_id") or receipt.get("external_id")
        correlation=receipt.get("correlation_id") or receipt.get("external_correlation_id")
        provenance=receipt.get("provenance") or receipt.get("authenticated_by") or receipt.get("authenticated_sender") or receipt.get("sender_id") or receipt.get("source")
        accepted_correlations = {"model-rollout:" + row["model_id"] + ":" + row["revision"], "model-promoted:" + row["model_id"] + ":" + row["revision"]}
        if expected_correlation is not None:
            accepted_correlations = {expected_correlation}
        return (isinstance(message,str) and bool(message) and isinstance(correlation,str) and correlation in accepted_correlations and isinstance(receipt.get("route"),str) and receipt["route"]==row["route"] and isinstance(provenance,str) and bool(provenance))

    def _claim_stale(self, claim: Mapping[str, Any]) -> bool:
        try:return self.clock() >= _parse(claim["claimed_at"]) + self._CLAIM_LEASE
        except (KeyError, TypeError, ValueError):return True

    def status(self, model_id: str, revision: str) -> dict[str, Any]:
        row=self._row(model_id,revision)
        lifecycle = "blocked" if row["blocked_at"] else "rolled_back" if row["rollback_json"] else "promoted" if row["promotion_json"] else "canary_verified" if json.loads(row["canary_json"] or "{}").get("state")=="canary_verified" else "canary_requested" if row["canary_json"] else "rejected" if row["rejected_at"] else "noticed" if row["notice_at"] else "reviewed"
        return {"model_id": row["model_id"], "revision": row["revision"], "state": lifecycle, "reviewer": row["reviewer"],
                "route": row["route"], "proposal": json.loads(row["proposal_json"] or row["entry_json"]),
                "budgets": json.loads(row["budgets_json"] or "{}"), "previous_working_version": row["previous_version"],
                "noticed_at": row["notice_at"], "notification_receipt": json.loads(row["notification_receipt_json"] or "null"),
                "blocked_at": row["blocked_at"], "complaints": json.loads(row["complaint_json"] or "[]"),
                "rejected_at": row["rejected_at"], "canary": json.loads(row["canary_json"] or "null"),
                "promotion": json.loads(row["promotion_json"] or "null"), "rollback": json.loads(row["rollback_json"] or "null")}
