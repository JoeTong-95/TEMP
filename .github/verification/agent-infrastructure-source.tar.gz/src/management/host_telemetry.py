"""Read-only, dependency-free host telemetry collection.

This collector emits a projection sample only; it neither registers a node nor
decides admission.  It reads named disks/interfaces only and never walks files.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any, Callable, Mapping, Sequence


Clock = Callable[[], datetime]
Runner = Callable[[Sequence[str], float], str]


def parse_proc_meminfo(text: str) -> tuple[int, int] | None:
    values: dict[str, int] = {}
    for line in text.splitlines():
        name, _, raw = line.partition(":")
        fields = raw.split()
        if len(fields) == 2 and fields[1] == "kB" and fields[0].isdigit():
            values[name] = int(fields[0]) * 1024
    if "MemTotal" not in values or "MemAvailable" not in values:
        return None
    return values["MemTotal"], values["MemAvailable"]


def parse_proc_net_dev(text: str) -> dict[str, tuple[int, int]]:
    result: dict[str, tuple[int, int]] = {}
    for line in text.splitlines():
        name, separator, values = line.partition(":")
        fields = values.split()
        if not separator or len(fields) < 9 or not fields[0].isdigit() or not fields[8].isdigit():
            continue
        result[name.strip()] = (int(fields[0]), int(fields[8]))
    return result


def parse_nvidia_smi(text: str) -> list[dict[str, int | str | None]]:
    """Parse the fixed no-header CSV query used below; reject malformed rows."""
    devices: list[dict[str, int | str | None]] = []
    for line in text.splitlines():
        fields = [field.strip() for field in line.split(",")]
        if not line.strip() or len(fields) != 6 or not fields[1] or not all(field.isdigit() for field in (fields[0], fields[2], fields[3], fields[4])):
            continue
        power = fields[5]
        power_mw: int | None = None
        if power.lower() in {"n/a", "[not supported]"}:
            pass
        else:
            try:
                watts = float(power)
                if math.isfinite(watts) and watts >= 0:
                    power_mw = int(round(watts * 1000))
            except (ValueError, OverflowError):
                pass
        devices.append({"index": int(fields[0]), "uuid": fields[1], "memory_total_mib": int(fields[2]), "memory_used_mib": int(fields[3]), "temperature_c": int(fields[4]), "power_mw": power_mw})
    return devices


def counter_rate(current: int, previous: int | None, elapsed_seconds: float | None) -> float | None:
    """Return bytes/second only for a non-reset counter pair; first sample is unknown."""
    if previous is None or elapsed_seconds is None or elapsed_seconds <= 0 or current < previous:
        return None
    return (current - previous) / elapsed_seconds


def collect_sample(
    *,
    hardware_node_id: str,
    host_boot_id: str,
    sequence: int,
    selected_disk_roots: Sequence[str | Path] = (),
    selected_interfaces: Sequence[str] = (),
    previous_counters: Mapping[str, tuple[int, datetime]] | None = None,
    clock: Clock | None = None,
    runner: Runner | None = None,
    platform_name: str | None = None,
    cadence_seconds: int = 10,
) -> dict[str, Any]:
    """Collect a canonical sample without secrets, writes, or directory enumeration."""
    if not hardware_node_id or not host_boot_id or type(sequence) is not int or sequence < 0 or cadence_seconds < 1:
        raise ValueError("node identity, non-negative sequence, and positive cadence are required")
    now = (clock or (lambda: datetime.now(timezone.utc)))()
    if now.tzinfo is None:
        raise ValueError("clock must return a timezone-aware datetime")
    now = now.astimezone(timezone.utc)
    platform_name = (platform_name or sys.platform).lower()
    runner = runner or _run_read_only
    metrics: list[dict[str, Any]] = []
    host = {"kind": "host", "id": hardware_node_id}
    memory = _memory(platform_name, runner)
    _append(metrics, "memory.total_bytes", "bytes", memory[0] if memory else None, host, "unsupported" if memory is None else "reported", None if memory else "memory collector unavailable")
    _append(metrics, "memory.available_bytes", "bytes", memory[1] if memory else None, host, "unsupported" if memory is None else "reported", None if memory else "memory collector unavailable")
    _append(metrics, "cpu.utilization", "percent", None, host, "unsupported", "two comparable CPU samples are not collected by this source")
    for root in selected_disk_roots:
        root_text = str(root)
        device = {"kind": "mount", "id": root_text}
        try:
            usage = shutil.disk_usage(root_text)
            _append(metrics, "disk.total_bytes", "bytes", usage.total, device, "reported")
            _append(metrics, "disk.free_bytes", "bytes", usage.free, device, "reported")
        except OSError as error:
            _append(metrics, "disk.total_bytes", "bytes", None, device, "collector-error", type(error).__name__)
            _append(metrics, "disk.free_bytes", "bytes", None, device, "collector-error", type(error).__name__)
    counters = _network_counters(platform_name, runner)
    for interface in selected_interfaces:
        device = {"kind": "interface", "id": interface}
        pair = counters.get(interface)
        for direction, index in (("rx", 0), ("tx", 1)):
            key = f"{interface}.{direction}_bytes"
            if pair is None:
                _append(metrics, f"network.{direction}_bytes", "bytes", None, device, "unsupported", "selected interface unavailable")
                _append(metrics, f"network.{direction}_bytes_per_second", "bytes_per_second", None, device, "no-sample", "counter unavailable")
                continue
            value = pair[index]
            _append(metrics, f"network.{direction}_bytes", "bytes", value, device, "reported")
            previous = (previous_counters or {}).get(key)
            elapsed = (now - previous[1]).total_seconds() if previous else None
            rate = counter_rate(value, previous[0] if previous else None, elapsed)
            _append(metrics, f"network.{direction}_bytes_per_second", "bytes_per_second", rate, device, "reported" if rate is not None else "no-sample", None if rate is not None else "first sample, reset, or invalid interval")
    _append_gpu(metrics, runner)
    observed_at = _utc(now)
    return {"sample_id": f"host-telemetry:{host_boot_id}:{sequence}", "hardware_node_id": hardware_node_id, "host_boot_id": host_boot_id, "sequence": sequence, "observed_at": observed_at, "received_at": observed_at, "collector": {"id": "host-telemetry", "version": "1"}, "source": "node-runtime", "cadence_seconds": cadence_seconds, "freshness": {"state": "fresh", "valid_until": _utc(now + timedelta(seconds=cadence_seconds))}, "metrics": metrics}


def _append(metrics: list[dict[str, Any]], name: str, unit: str, value: Any, device: dict[str, str], state: str, reason: str | None = None) -> None:
    metrics.append({"name": name, "unit": unit, "value": value, "availability": {"state": state, "reason": reason}, "device": device})


def _memory(platform_name: str, runner: Runner) -> tuple[int, int] | None:
    try:
        if platform_name.startswith("linux"):
            return parse_proc_meminfo(Path("/proc/meminfo").read_text(encoding="utf-8"))
        if platform_name.startswith("win"):
            raw = runner(("powershell", "-NoProfile", "-NonInteractive", "-Command", "Get-CimInstance Win32_OperatingSystem | Select-Object TotalVisibleMemorySize,FreePhysicalMemory | ConvertTo-Json -Compress"), 2.0)
            data = json.loads(raw)
            return int(data["TotalVisibleMemorySize"]) * 1024, int(data["FreePhysicalMemory"]) * 1024
    except (OSError, ValueError, KeyError, json.JSONDecodeError, subprocess.SubprocessError):
        return None
    return None


def _network_counters(platform_name: str, runner: Runner) -> dict[str, tuple[int, int]]:
    try:
        if platform_name.startswith("linux"):
            return parse_proc_net_dev(Path("/proc/net/dev").read_text(encoding="utf-8"))
    except OSError:
        pass
    return {}


def _append_gpu(metrics: list[dict[str, Any]], runner: Runner) -> None:
    try:
        rows = parse_nvidia_smi(runner(("nvidia-smi", "--query-gpu=index,uuid,memory.total,memory.used,temperature.gpu,power.draw", "--format=csv,noheader,nounits"), 2.0))
    except (OSError, subprocess.SubprocessError):
        rows = []
    if not rows:
        _append(metrics, "gpu.memory_total_mib", "MiB", None, {"kind": "gpu", "id": "gpu-unavailable"}, "unsupported", "nvidia-smi unavailable or malformed")
        return
    for row in rows:
        device = {"kind": "gpu", "id": str(row["uuid"])}
        _append(metrics, "gpu.memory_total_mib", "MiB", row["memory_total_mib"], device, "reported")
        _append(metrics, "gpu.memory_used_mib", "MiB", row["memory_used_mib"], device, "reported")
        _append(metrics, "gpu.temperature_c", "celsius", row["temperature_c"], device, "reported")
        power = row["power_mw"]
        _append(metrics, "gpu.power_mw", "mW", power, device, "reported" if power is not None else "unsupported", None if power is not None else "nvidia-smi power unavailable")


def _run_read_only(args: Sequence[str], timeout: float) -> str:
    return subprocess.run(args, check=True, capture_output=True, text=True, timeout=timeout, shell=False).stdout


def _utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def main() -> int:
    parser = argparse.ArgumentParser(description="Print one read-only local host telemetry sample")
    parser.add_argument("--hardware-node-id", required=True)
    parser.add_argument("--host-boot-id", required=True)
    parser.add_argument("--sequence", required=True, type=int)
    parser.add_argument("--disk-root", action="append", default=[])
    parser.add_argument("--interface", action="append", default=[])
    args = parser.parse_args()
    print(json.dumps(collect_sample(hardware_node_id=args.hardware_node_id, host_boot_id=args.host_boot_id, sequence=args.sequence, selected_disk_roots=args.disk_root, selected_interfaces=args.interface), sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
