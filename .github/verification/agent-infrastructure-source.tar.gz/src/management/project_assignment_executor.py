"""Bounded dependency-aware assignment dispatch.

Management remains the scheduler of record. This worker consumes a
Management snapshot, admits a deterministic set of ready assignments, and
reports receipts back through the Management adapter.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import threading
import time
from typing import Any, Mapping, Protocol

from .project_orchestrator_driver import UnknownOutcome
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root
from shared.contracts.project_verification import MAX_VERIFICATION_OUTPUT_BYTES
from shared.contracts.agent_runtime import RuntimeClientError, validate_submission_fence

_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_MAX_PARALLELISM = 32
_MAX_DEPENDENCIES = 64
_MAX_VERIFICATION_OUTPUT = MAX_VERIFICATION_OUTPUT_BYTES


class AssignmentExecutorError(ValueError):
    pass


class AssignmentManagement(Protocol):
    def snapshot(self, project_id: str, revision: int) -> Mapping[str, Any]: ...

    def progress(self, project_id: str, revision: int, *, idempotency_key: str, agent_id: str, assignment_id: str, progress: Mapping[str, Any]) -> Mapping[str, Any]: ...


class AssignmentRuntime(Protocol):
    def prepare(self, *, binding_id: str, session_id: str, assignment_id: str, immutable_revision: str, submission_fence: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def reconcile(self, request_id: str, *, binding_id: str, session_id: str, message: str, attempt_id: str | None = None, immutable_revision: str | None = None, submission_fence: Mapping[str, Any] | None = None) -> Mapping[str, Any] | None: ...

    def submit(self, request_id: str, *, session_id: str, binding_id: str, message: str, attempt_id: str | None = None, immutable_revision: str | None = None, submission_fence: Mapping[str, Any] | None = None) -> Mapping[str, Any]: ...


class AssignmentVerification(Protocol):
    """Independent verifier for a completed agent effect."""

    def verify(self, assignment: Mapping[str, Any], *, project_id: str, revision: int, request_id: str, effect_receipt: str, message: str) -> Mapping[str, Any]: ...


@dataclass(frozen=True)
class AgentBinding:
    agent_id: str
    binding_id: str
    session_id: str

    def __post_init__(self) -> None:
        if not all(isinstance(value, str) and _SAFE.fullmatch(value) for value in (self.agent_id, self.binding_id, self.session_id)):
            raise AssignmentExecutorError("agent binding is invalid")


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _receipt_id(value: Any, *, prefix: str, forbidden: set[str]) -> str:
    if isinstance(value, Mapping):
        for key in ("receipt_id", "effect_receipt", "verification_receipt", "operation_id"):
            candidate = value.get(key)
            if isinstance(candidate, str) and _SAFE.fullmatch(candidate) and candidate not in forbidden:
                return candidate
    return prefix + hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()[:48]


class AssignmentExecutor:
    def __init__(self, database: str | Path, project_id: str, revision: int, bindings: Mapping[str, AgentBinding], management: AssignmentManagement, runtime: AssignmentRuntime, *, max_parallelism: int | None = None, claim_lease_seconds: float = 30.0, verification: AssignmentVerification | None = None, verification_required: bool = False, resource_bounds: Mapping[str, int | float] | None = None, state_root: str | Path | None = None) -> None:
        try:
            database_path = Path(database)
            self.path = validate_durable_leaf(database_path, validate_state_root(state_root if state_root is not None else database_path.parent, "assignment state root"), label="assignment journal database")
        except (ManagementStateBoundaryError, TypeError) as error:
            raise AssignmentExecutorError("assignment journal database is unsafe") from error
        self.project_id = project_id
        self.revision = revision
        self.bindings = dict(bindings)
        self.management = management
        self.runtime = runtime
        self.verification = verification
        if max_parallelism is None:
            max_parallelism = min(max(1, len(self.bindings)), 8)
        if not isinstance(verification_required, bool) or (verification_required and verification is None) or not self.path.is_absolute() or not self.path.parent.is_dir() or self.path.is_symlink() or not isinstance(project_id, str) or _SAFE.fullmatch(project_id) is None or type(revision) is not int or revision < 1 or not self.bindings or any(key != value.agent_id for key, value in self.bindings.items()) or type(max_parallelism) is not int or not 1 <= max_parallelism <= _MAX_PARALLELISM or isinstance(claim_lease_seconds, bool) or not isinstance(claim_lease_seconds, (int, float)) or not math.isfinite(claim_lease_seconds) or claim_lease_seconds <= 0:
            raise AssignmentExecutorError("executor configuration is invalid")
        self.max_parallelism = max_parallelism
        self.claim_lease_seconds = float(claim_lease_seconds)
        self.verification_required = verification_required
        if resource_bounds is not None and (not isinstance(resource_bounds, Mapping) or len(resource_bounds) > 64 or any(not isinstance(key, str) or _SAFE.fullmatch(key) is None or isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0 for key, value in resource_bounds.items())):
            raise AssignmentExecutorError("resource bounds are invalid")
        self.resource_bounds = {key: float(value) for key, value in (resource_bounds or {}).items()}
        self._admission_lock = threading.Lock()
        with self._db() as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS assignment_operations(project_id TEXT,revision INTEGER,assignment_id TEXT,request_id TEXT,state TEXT,receipt TEXT,claimed_at REAL,PRIMARY KEY(project_id,revision,assignment_id))")
            columns = {row[1] for row in connection.execute("PRAGMA table_info(assignment_operations)")}
            if "claimed_at" not in columns:
                connection.execute("ALTER TABLE assignment_operations ADD COLUMN claimed_at REAL")

    @contextmanager
    def _db(self):
        connection = sqlite3.connect(self.path, timeout=30)
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    @staticmethod
    def _dependencies(assignment: Mapping[str, Any]) -> tuple[str, ...]:
        value = assignment.get("depends_on", ())
        if value is None:
            return ()
        if not isinstance(value, (list, tuple)) or len(value) > _MAX_DEPENDENCIES:
            raise AssignmentExecutorError("assignment dependencies are malformed")
        dependencies = tuple(value)
        if any(not isinstance(item, str) or _SAFE.fullmatch(item) is None for item in dependencies) or len(set(dependencies)) != len(dependencies):
            raise AssignmentExecutorError("assignment dependencies are malformed")
        return dependencies

    @staticmethod
    def _resources(assignment: Mapping[str, Any]) -> dict[str, float]:
        value = assignment.get("resource_request", {})
        if value is None:
            return {}
        if not isinstance(value, Mapping) or len(value) > 64:
            raise AssignmentExecutorError("assignment resource request is malformed")
        result: dict[str, float] = {}
        for key, amount in value.items():
            if not isinstance(key, str) or _SAFE.fullmatch(key) is None or isinstance(amount, bool) or not isinstance(amount, (int, float)) or not math.isfinite(amount) or amount < 0:
                raise AssignmentExecutorError("assignment resource request is malformed")
            result[key] = float(amount)
        return result

    def tick(self) -> dict[str, Any]:
        snapshot = self.management.snapshot(self.project_id, self.revision)
        if not isinstance(snapshot, Mapping) or snapshot.get("project_id") != self.project_id or snapshot.get("revision") != self.revision or not isinstance(snapshot.get("assignments"), list):
            return {"state": "not_runnable"}
        assignments = [self._validate_assignment(value) for value in snapshot["assignments"]]
        by_id = {assignment["assignment_id"]: assignment for assignment in assignments}
        if len(by_id) != len(assignments):
            raise AssignmentExecutorError("assignment IDs are duplicated")
        for assignment in assignments:
            if any(dependency not in by_id for dependency in self._dependencies(assignment)):
                raise AssignmentExecutorError("assignment dependency is unknown")
        visiting: set[str] = set()
        visited: set[str] = set()
        def visit(assignment_id: str) -> None:
            if assignment_id in visiting:
                raise AssignmentExecutorError("assignment dependency cycle")
            if assignment_id in visited:
                return
            visiting.add(assignment_id)
            for dependency in self._dependencies(by_id[assignment_id]):
                visit(dependency)
            visiting.remove(assignment_id)
            visited.add(assignment_id)
        for assignment_id in by_id:
            visit(assignment_id)
        if snapshot.get("state") not in {"waiting", "turn_ready"}:
            return {"state": "not_runnable"}
        ready: list[Mapping[str, Any]] = []
        dependency_blocked: list[Mapping[str, Any]] = []
        for assignment in sorted(assignments, key=lambda value: value["assignment_id"]):
            if assignment["state"] not in {"assigned", "running"}:
                continue
            dependencies = self._dependencies(assignment)
            states = [by_id[dependency]["state"] for dependency in dependencies]
            if any(state == "blocked" for state in states):
                dependency_blocked.append(assignment)
            elif all(state in {"succeeded", "waived"} for state in states):
                ready.append(assignment)
        outcomes = [self._report_dependency_block(assignment) for assignment in dependency_blocked]
        capacity = snapshot.get("resources")
        if capacity is not None and (not isinstance(capacity, Mapping) or len(capacity) > 64 or any(not isinstance(key, str) or _SAFE.fullmatch(key) is None or isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0 for key, value in capacity.items())):
            raise AssignmentExecutorError("management resource allocation is malformed")
        if capacity is None and self.resource_bounds:
            capacity = self.resource_bounds
        elif isinstance(capacity, Mapping) and self.resource_bounds:
            capacity = {key: min(float(value), self.resource_bounds[key]) if key in self.resource_bounds else float(value) for key, value in capacity.items()}
        admitted: list[Mapping[str, Any]] = []
        used: dict[str, float] = {}
        sessions: set[str] = set()
        for assignment in ready:
            binding = self.bindings.get(assignment["agent_id"])
            if binding is None or binding.binding_id != assignment["binding_id"]:
                raise AssignmentExecutorError("assignment binding is not approved")
            requested = self._resources(assignment)
            if isinstance(capacity, Mapping) and any(used.get(key, 0.0) + amount > float(capacity.get(key, 0.0)) for key, amount in requested.items()):
                continue
            if binding.session_id in sessions:
                continue
            admitted.append(assignment)
            sessions.add(binding.session_id)
            for key, amount in requested.items():
                used[key] = used.get(key, 0.0) + amount
            if len(admitted) >= self.max_parallelism:
                break
        with self._admission_lock:
            current = self.management.snapshot(self.project_id, self.revision)
            if not isinstance(current, Mapping) or current.get("state") not in {"waiting", "turn_ready"}:
                return {"state": "not_runnable"}
        if len(admitted) == 1:
            outcomes.append(self._run(admitted[0]))
        elif admitted:
            with ThreadPoolExecutor(max_workers=min(self.max_parallelism, len(admitted)), thread_name_prefix="assignment") as pool:
                futures = {assignment["assignment_id"]: pool.submit(self._run, assignment) for assignment in admitted}
                outcomes.extend(futures[assignment["assignment_id"]].result() for assignment in admitted)
        outcomes.sort(key=lambda value: value["assignment_id"])
        return {"state": "ticked", "assignments": outcomes}

    def _validate_assignment(self, assignment: Any) -> Mapping[str, Any]:
        required = {"assignment_id", "agent_id", "binding_id", "task_ref", "objective", "state", "receipt", "events", "events_truncated"}
        if not isinstance(assignment, Mapping) or not required.issubset(assignment) or set(assignment) - required - {"depends_on", "resource_request", "verification_input_tree_sha256", "attempt_id", "immutable_revision", "submission_fence"}:
            raise AssignmentExecutorError("assignment is malformed")
        if assignment.get("state") not in {"assigned", "running", "paused", "succeeded", "blocked", "waived"} or not all(isinstance(assignment.get(key), str) and _SAFE.fullmatch(assignment[key]) for key in ("assignment_id", "agent_id", "binding_id", "task_ref")) or not isinstance(assignment.get("objective"), str) or not 1 <= len(assignment["objective"].encode()) <= 4096:
            raise AssignmentExecutorError("assignment is malformed")
        if assignment.get("receipt") is not None and not self._bounded_json(assignment.get("receipt")):
            raise AssignmentExecutorError("assignment receipt is malformed")
        if not isinstance(assignment.get("events"), list) or len(assignment["events"]) > 100 or not all(self._bounded_json(event) for event in assignment["events"]) or type(assignment.get("events_truncated")) is not bool:
            raise AssignmentExecutorError("assignment event history is malformed")
        configured = self.bindings.get(assignment["agent_id"])
        if configured is None or configured.binding_id != assignment["binding_id"]:
            raise AssignmentExecutorError("assignment binding is not approved")
        digest = assignment.get("verification_input_tree_sha256")
        if digest is not None and (not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest)):
            raise AssignmentExecutorError("assignment verification digest is malformed")
        self._dependencies(assignment)
        self._resources(assignment)
        attempt_id, immutable = assignment.get("attempt_id"), assignment.get("immutable_revision")
        if (attempt_id is not None and (not isinstance(attempt_id, str) or _SAFE.fullmatch(attempt_id) is None or not isinstance(immutable, str) or re.fullmatch(r"[0-9a-f]{40,64}", immutable) is None)) or (attempt_id is None and immutable is not None and (not isinstance(immutable, str) or re.fullmatch(r"[0-9a-f]{40,64}", immutable) is None)):
            raise AssignmentExecutorError("assignment prepared source identity is malformed")
        fence = assignment.get("submission_fence")
        if immutable is None and fence is not None:
            raise AssignmentExecutorError("legacy assignment cannot carry a submission fence")
        if immutable is not None:
            try: normalized = validate_submission_fence(fence)
            except RuntimeClientError as error: raise AssignmentExecutorError("assignment submission fence is malformed") from error
            if normalized["assignment_id"] != assignment["assignment_id"] or normalized["immutable_revision"] != immutable or normalized["project_revision"] != self.revision:
                raise AssignmentExecutorError("assignment submission fence does not match assignment")
        return assignment

    @staticmethod
    def _bounded_json(value: Any, depth: int = 0, max_string: int = 4096) -> bool:
        if depth > 6:
            return False
        if value is None or type(value) is bool:
            return True
        if type(value) in {int, float}:
            return type(value) is int or math.isfinite(value)
        if isinstance(value, str):
            return len(value.encode()) <= max_string
        if isinstance(value, list):
            return len(value) <= 128 and all(AssignmentExecutor._bounded_json(item, depth + 1, max_string) for item in value)
        if isinstance(value, Mapping):
            return len(value) <= 128 and all(isinstance(key, str) and _SAFE.fullmatch(key) and AssignmentExecutor._bounded_json(item, depth + 1, max_string) for key, item in value.items())
        return False

    def _message_and_request(self, assignment: Mapping[str, Any], prepared: Mapping[str, str]) -> tuple[str, str]:
        payload: dict[str, Any] = {"project_id": self.project_id, "revision": self.revision, "assignment_id": assignment["assignment_id"], "task_ref": assignment["task_ref"], "objective": assignment["objective"]}
        # Preserve the legacy request identity for assignments that omit the
        # newer contract fields, while binding every populated field into the
        # runtime effect identity.
        for key in ("depends_on", "resource_request", "verification_input_tree_sha256"):
            if key in assignment and assignment[key] is not None:
                payload[key] = assignment[key]
        payload.update(prepared)
        message = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return message, "assignment-" + hashlib.sha256(message.encode()).hexdigest()[:48]

    def _claim(self, assignment_id: str, request_id: str) -> str:
        now = time.time()
        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT request_id,state,claimed_at FROM assignment_operations WHERE project_id=? AND revision=? AND assignment_id=?", (self.project_id, self.revision, assignment_id)).fetchone()
            if row and row[0] != request_id:
                raise AssignmentExecutorError("journal conflict")
            if row and row[1] == "reported":
                return "reported"
            if row and row[1] == "claimed" and row[2] is not None and now - row[2] < self.claim_lease_seconds:
                return "in_progress"
            if row:
                connection.execute("UPDATE assignment_operations SET state='claimed',claimed_at=? WHERE project_id=? AND revision=? AND assignment_id=?", (now, self.project_id, self.revision, assignment_id))
            else:
                connection.execute("INSERT INTO assignment_operations(project_id,revision,assignment_id,request_id,state,receipt,claimed_at) VALUES(?,?,?,?,?,?,?)", (self.project_id, self.revision, assignment_id, request_id, "claimed", None, now))
            return "claimed"

    def _run(self, assignment: Mapping[str, Any]) -> dict[str, Any]:
        configured = self.bindings.get(assignment["agent_id"])
        if configured is None or configured.binding_id != assignment["binding_id"]:
            raise AssignmentExecutorError("assignment binding is not approved")
        prepared = self._prepare_assignment(assignment, configured)
        message, request_id = self._message_and_request(assignment, prepared)
        claim = self._claim(assignment["assignment_id"], request_id)
        if claim == "reported":
            return {"assignment_id": assignment["assignment_id"], "state": "already_reported"}
        if claim == "in_progress":
            return {"assignment_id": assignment["assignment_id"], "state": "in_progress", "request_id": request_id}
        self._post(assignment, "running", request_id)
        source_identity = {key: prepared[key] for key in ("attempt_id", "immutable_revision") if key in prepared}
        submission_fence = prepared.get("submission_fence")
        if submission_fence is not None:
            admission_reason = self._admission_block_reason(assignment, submission_fence)
            if admission_reason is not None:
                evidence = "evidence-" + hashlib.sha256((request_id + ":" + admission_reason).encode()).hexdigest()[:48]
                self._post(assignment, "blocked", request_id, reason=admission_reason, evidence_receipt=evidence)
                return {"assignment_id": assignment["assignment_id"], "state": "blocked", "request_id": request_id, "diagnostic": admission_reason}
        runtime_kwargs = {**source_identity, **({"submission_fence": submission_fence} if submission_fence is not None else {})}
        try:
            operation = self.runtime.reconcile(request_id, binding_id=configured.binding_id, session_id=configured.session_id, message=message, **runtime_kwargs)
            if operation is None:
                try:
                    operation = self.runtime.submit(request_id, session_id=configured.session_id, binding_id=configured.binding_id, message=message, **runtime_kwargs)
                except UnknownOutcome:
                    operation = self.runtime.reconcile(request_id, binding_id=configured.binding_id, session_id=configured.session_id, message=message, **runtime_kwargs)
                    if operation is None:
                        raise
        except AssignmentExecutorError as error:
            reason = self._runtime_rejection_reason(error)
            evidence = "evidence-" + hashlib.sha256((request_id + ":" + reason).encode()).hexdigest()[:48]
            self._post(assignment, "blocked", request_id, reason=reason, evidence_receipt=evidence)
            return {"assignment_id": assignment["assignment_id"], "state": "blocked", "request_id": request_id, "diagnostic": str(error)}
        expected_hash = hashlib.sha256(message.encode()).hexdigest()
        if not isinstance(operation, Mapping) or operation.get("state") != "completed" or operation.get("request_id") != request_id or operation.get("project_id") != self.project_id or operation.get("revision_id") != str(self.revision) or operation.get("session_id") != configured.session_id or operation.get("message_sha256") != expected_hash:
            evidence = "evidence-" + hashlib.sha256(_canonical(operation).encode()).hexdigest()[:48]
            self._post(assignment, "blocked", request_id, evidence_receipt=evidence)
            return {"assignment_id": assignment["assignment_id"], "state": "blocked", "request_id": request_id}
        if source_identity:
            source = operation.get("source_identity")
            effects = operation.get("effect_receipts")
            if source != source_identity or not isinstance(effects, list) or len(effects) != 1 or not isinstance(effects[0], Mapping) or effects[0].get("state") != "completed" or not isinstance(effects[0].get("tool_id"), str) or _SAFE.fullmatch(effects[0]["tool_id"]) is None:
                evidence = "evidence-" + hashlib.sha256(_canonical({"source": source, "effects": effects}).encode()).hexdigest()[:48]
                self._post(assignment, "blocked", request_id, evidence_receipt=evidence)
                return {"assignment_id": assignment["assignment_id"], "state": "blocked", "request_id": request_id, "diagnostic": "runtime_effects_not_single_completed"}
            effect_receipt = effects[0]["tool_id"]
        else:
            effect_receipt = _receipt_id(operation, prefix="effect-", forbidden={request_id})
        verification_receipt = self._verify(assignment, request_id, effect_receipt, message)
        self._post(assignment, "succeeded", request_id, effect_receipt=effect_receipt, verification_receipt=verification_receipt)
        return {"assignment_id": assignment["assignment_id"], "state": "succeeded", "request_id": request_id, "effect_receipt": effect_receipt, "verification_receipt": verification_receipt}

    def _admission_block_reason(self, assignment: Mapping[str, Any], expected_fence: Mapping[str, Any]) -> str | None:
        """Reconcile the authoritative Management frontier after running is acknowledged."""
        try:
            current = self.management.snapshot(self.project_id, self.revision)
        except Exception:
            return "frontier_unavailable"
        if not isinstance(current, Mapping) or current.get("project_id") != self.project_id or current.get("revision") != self.revision:
            return "frontier_changed"
        if current.get("state") not in {"waiting", "turn_ready"}:
            return "assignment_not_eligible"
        current_item = next((item for item in current.get("assignments", ()) if isinstance(item, Mapping) and item.get("assignment_id") == assignment["assignment_id"]), None)
        if current_item is None or current_item.get("state") != "running":
            return "assignment_not_eligible"
        contract_keys = ("assignment_id", "agent_id", "binding_id", "task_ref", "objective", "depends_on", "resource_request", "verification_input_tree_sha256", "attempt_id", "immutable_revision")
        if any(current_item.get(key) != assignment.get(key) for key in contract_keys):
            return "assignment_changed"
        try:
            expected = validate_submission_fence(expected_fence)
            observed = validate_submission_fence(current_item.get("submission_fence"))
        except RuntimeClientError:
            return "frontier_unavailable"
        if observed != expected:
            return "frontier_changed"
        return None

    def _prepare_assignment(self, assignment: Mapping[str, Any], configured: AgentBinding) -> dict[str, Any]:
        immutable = assignment.get("immutable_revision")
        attempt = assignment.get("attempt_id")
        if immutable is None:
            return {}
        fence = assignment.get("submission_fence")
        if not isinstance(fence, Mapping):
            raise AssignmentExecutorError("prepared assignment submission fence is missing")
        if isinstance(attempt, str):
            return {"attempt_id": attempt, "immutable_revision": immutable, "submission_fence": dict(fence)}
        receipt = self.runtime.prepare(binding_id=configured.binding_id, session_id=configured.session_id, assignment_id=assignment["assignment_id"], immutable_revision=immutable, submission_fence=fence)
        if not isinstance(receipt, Mapping) or receipt.get("assignment_id") != assignment["assignment_id"] or receipt.get("immutable_revision") != immutable or receipt.get("state") != "prepared" or not isinstance(receipt.get("attempt_id"), str) or _SAFE.fullmatch(receipt["attempt_id"]) is None or not isinstance(receipt.get("receipt_id"), str) or _SAFE.fullmatch(receipt["receipt_id"]) is None:
            raise AssignmentExecutorError("runtime preparation receipt is invalid")
        if receipt.get("submission_fence") != dict(fence):
            raise AssignmentExecutorError("runtime preparation fence is invalid")
        return {"attempt_id": receipt["attempt_id"], "immutable_revision": immutable, "preparation_receipt": receipt["receipt_id"], "submission_fence": dict(fence)}

    def _verify(self, assignment: Mapping[str, Any], request_id: str, effect_receipt: str, message: str) -> str:
        if self.verification is None:
            if self.verification_required:
                raise AssignmentExecutorError("independent verification is required")
            # Legacy runtime adapters get a distinct transition marker. It is
            # never the runtime request ID or presented as the effect receipt.
            return "verification-" + hashlib.sha256((request_id + effect_receipt).encode()).hexdigest()[:48]
        evidence = self.verification.verify(assignment, project_id=self.project_id, revision=self.revision, request_id=request_id, effect_receipt=effect_receipt, message=message)
        if self.verification_required:
            if not isinstance(evidence, Mapping) or not self._bounded_json(evidence, max_string=_MAX_VERIFICATION_OUTPUT):
                raise AssignmentExecutorError("independent verification evidence is malformed")
            receipt = evidence.get("verification_receipt", evidence.get("receipt_id"))
            identity = evidence.get("verification_identity", evidence.get("verification_id", evidence.get("operation_id")))
            if not isinstance(receipt, str) or _SAFE.fullmatch(receipt) is None:
                raise AssignmentExecutorError("independent verification receipt is missing or malformed")
            if not isinstance(identity, str) or _SAFE.fullmatch(identity) is None:
                raise AssignmentExecutorError("independent verification identity is missing or malformed")
            if receipt in {request_id, effect_receipt} or identity in {request_id, effect_receipt}:
                raise AssignmentExecutorError("independent verification identity is not independent")
            return receipt
        receipt = _receipt_id(evidence, prefix="verification-", forbidden={request_id, effect_receipt})
        if receipt in {request_id, effect_receipt}:
            raise AssignmentExecutorError("verification receipt is not independent")
        return receipt

    def _report_dependency_block(self, assignment: Mapping[str, Any]) -> dict[str, Any]:
        dependencies = self._dependencies(assignment)
        evidence = "dependency-" + hashlib.sha256(_canonical(dependencies).encode()).hexdigest()[:48]
        self._post(assignment, "blocked", "dependency-" + assignment["assignment_id"], evidence_receipt=evidence)
        return {"assignment_id": assignment["assignment_id"], "state": "blocked", "evidence_receipt": evidence}

    @staticmethod
    def _runtime_rejection_reason(error: AssignmentExecutorError) -> str:
        value = str(error)
        prefix = "runtime admission blocked: "
        if value.startswith(prefix) and value[len(prefix):]:
            return value[len(prefix):]
        return value if value else "runtime_rejected"

    def _post(self, assignment: Mapping[str, Any], state: str, request_id: str, *, reason: str | None = None, effect_receipt: str | None = None, verification_receipt: str | None = None, evidence_receipt: str | None = None) -> None:
        if state == "running":
            progress: dict[str, Any] = {"state": "running"}
        elif state == "succeeded":
            if not effect_receipt or not verification_receipt or effect_receipt == verification_receipt or request_id in {effect_receipt, verification_receipt}:
                raise AssignmentExecutorError("effect and verification receipts must be independent")
            progress = {"state": "succeeded", "effect_receipt": effect_receipt, "verification_receipt": verification_receipt}
        else:
            progress = {"state": "blocked", "reason": reason or ("dependency_failed" if request_id.startswith("dependency-") else "runtime_receipt_invalid"), "evidence_receipt": evidence_receipt or ("evidence-" + hashlib.sha256(request_id.encode()).hexdigest()[:48])}
        key = "assignment-progress-" + hashlib.sha256((request_id + state).encode()).hexdigest()[:48]
        try:
            self.management.progress(self.project_id, self.revision, idempotency_key=key, agent_id=assignment["agent_id"], assignment_id=assignment["assignment_id"], progress=progress)
        except UnknownOutcome:
            now = self.management.snapshot(self.project_id, self.revision)
            item = next((value for value in now.get("assignments", []) if isinstance(value, Mapping) and value.get("assignment_id") == assignment["assignment_id"]), None)
            valid = isinstance(item, Mapping) and ((state == "running" and item.get("state") in {"running", "succeeded"}) or (state == "succeeded" and item.get("state") == "succeeded") or (state == "blocked" and item.get("state") == "blocked"))
            if not valid:
                raise
        if state in {"succeeded", "blocked"}:
            with self._db() as connection:
                connection.execute("UPDATE assignment_operations SET state='reported',receipt=? WHERE project_id=? AND revision=? AND assignment_id=?", (_canonical({"request_id": request_id, "effect_receipt": effect_receipt, "verification_receipt": verification_receipt, "evidence_receipt": evidence_receipt}), self.project_id, self.revision, assignment["assignment_id"]))


def prefect_tick(executor: AssignmentExecutor) -> dict[str, Any]:
    return executor.tick()
