"""Configured one-tick pipeline: decision bridge followed by assignment bridge."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from typing import Any
from .project_orchestrator_worker import _safe_file,WorkerConfigError,prefect_run_one
from .project_assignment_worker import prefect_assignment_tick

def load_pipeline_configuration(path:str|Path)->dict[str,str]:
 file=_safe_file(str(path))
 try:value=json.loads(file.read_text(encoding='utf-8'))
 except (OSError,ValueError,json.JSONDecodeError) as error:raise WorkerConfigError('pipeline configuration is invalid') from error
 if not isinstance(value,dict) or set(value)!={'orchestrator_config','project_id','assignment_config'} or not all(isinstance(value.get(k),str) and value[k] for k in value):raise WorkerConfigError('pipeline configuration is invalid')
 # Validate paths now; child loaders revalidate their exact contents.
 _safe_file(value['orchestrator_config']);_safe_file(value['assignment_config'])
 return dict(value)
def run_pipeline_tick(config:dict[str,str])->dict[str,Any]:
 orchestrator=prefect_run_one(config['orchestrator_config'],config['project_id'])
 assignments=prefect_assignment_tick(config['assignment_config'])
 return {'kind':'project_pipeline_tick','orchestrator':orchestrator,'assignments':assignments,'scheduler_state':'management_authoritative'}
def prefect_pipeline_tick(config_path:str)->dict[str,Any]:return run_pipeline_tick(load_pipeline_configuration(config_path))
def main(argv=None):
 parser=argparse.ArgumentParser();parser.add_argument('--config',required=True);args=parser.parse_args(argv);print(json.dumps(prefect_pipeline_tick(args.config),sort_keys=True,separators=(',',':')));return 0
if __name__=='__main__':raise SystemExit(main())
