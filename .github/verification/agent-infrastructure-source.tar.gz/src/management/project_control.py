"""Durable project-proposal control journal; it records intent and never executes it.

External authentication maps principals to ``human``, ``codex`` or
``orchestrator`` before this core is called. Capacity/binding validation is an
injected, fail-closed observation, not an allocator or provider/model guesser.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator, Mapping
from shared.contracts.forge import normalize_project_forge_binding, validate_project_forge_binding
from shared.contracts.project_reference import validate_agent_definition, validate_identifier, validate_project_infrastructure_references, validate_reference, validate_secret_free, validate_storage_policy
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


class ProjectControlError(ValueError): pass
class ProjectConflictError(ProjectControlError): pass
Validation = Callable[[dict[str, Any]], bool]
ProjectValidation = Callable[[str, dict[str, Any]], bool]
ProjectConfigurationValidation = Callable[[str, dict[str, Any]], bool]
ProjectAdmission = Callable[[str, dict[str, Any]], Mapping[str, Any]]
ProjectReferenceValidation = Callable[[Mapping[str, Any]], None]


def _canon(value: Any) -> str: return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
def _hash(value: Any) -> str: return hashlib.sha256(_canon(value).encode()).hexdigest()


class ProjectControl:
    def __init__(self, database: str | Path, *, validate_capacity_bindings: Validation | None = None, validate_project: ProjectValidation | None = None, validate_configuration: ProjectConfigurationValidation | None = None, project_admission: ProjectAdmission | None = None, validate_project_references: ProjectReferenceValidation | None = None):
        database_path = Path(database)
        try:
            state_root = validate_state_root(database_path.parent, "project control state root")
            self.path = str(validate_durable_leaf(database_path, state_root, label="project control database"))
        except ManagementStateBoundaryError as error:
            raise ProjectControlError(str(error)) from error
        self.validate_capacity_bindings = validate_capacity_bindings; self.validate_project = validate_project; self.validate_configuration = validate_configuration; self.project_admission = project_admission; self.validate_project_references = validate_project_references
        with self._db() as c:
            c.executescript("""
          CREATE TABLE IF NOT EXISTS project_drafts(project_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, payload TEXT NOT NULL, confirmed_revision INTEGER, confirmed_by_id TEXT, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS project_owners(project_id TEXT PRIMARY KEY, actor_id TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS project_requests(idempotency_key TEXT PRIMARY KEY, project_id TEXT NOT NULL, action TEXT NOT NULL, actor_id TEXT NOT NULL, actor_role TEXT NOT NULL, command TEXT NOT NULL, payload_hash TEXT NOT NULL, response TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
          CREATE INDEX IF NOT EXISTS project_requests_by_project ON project_requests(project_id,created_at);
          CREATE TABLE IF NOT EXISTS project_outbox(intent_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, revision INTEGER NOT NULL, started_by_id TEXT NOT NULL, started_by_role TEXT NOT NULL, payload_hash TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS project_confirmations(project_id TEXT NOT NULL, revision INTEGER NOT NULL, actor_id TEXT NOT NULL, actor_role TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(project_id,revision));
          CREATE UNIQUE INDEX IF NOT EXISTS one_start_intent_per_revision ON project_outbox(project_id,revision);
          CREATE TABLE IF NOT EXISTS project_lifecycle(project_id TEXT PRIMARY KEY, state TEXT NOT NULL, generation INTEGER NOT NULL DEFAULT 0, operation_id TEXT, reason TEXT, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS project_tombstones(idempotency_key TEXT PRIMARY KEY, project_id TEXT NOT NULL, scope TEXT NOT NULL, actor_id TEXT NOT NULL DEFAULT '', payload_hash TEXT NOT NULL DEFAULT '', response TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS management_auth_events(action_id TEXT PRIMARY KEY, action TEXT NOT NULL, outcome TEXT NOT NULL, actor_id TEXT, actor_role TEXT, subject TEXT NOT NULL, occurred_at TEXT NOT NULL);
          CREATE INDEX IF NOT EXISTS management_auth_events_order ON management_auth_events(occurred_at, action_id);
            """)
            # The lifecycle/delete tables were introduced after the original
            # journal.  Keep existing SQLite files usable when the new columns
            # are added without silently dropping their idempotency history.
            columns = {row["name"] for row in c.execute("PRAGMA table_info(project_tombstones)")}
            for name, definition in (("actor_id", "TEXT NOT NULL DEFAULT ''"), ("payload_hash", "TEXT NOT NULL DEFAULT ''")):
                if name not in columns:
                    c.execute(f"ALTER TABLE project_tombstones ADD COLUMN {name} {definition}")

    @contextmanager
    def _db(self) -> Iterator[sqlite3.Connection]:
        c = sqlite3.connect(self.path); c.row_factory = sqlite3.Row
        try:
            with c: yield c
        finally: c.close()

    @staticmethod
    def _role(actor_role: str, allowed: set[str]) -> None:
        if actor_role not in allowed: raise ProjectControlError("actor role is not permitted for this operation")

    def _shape(self, payload: dict[str, Any]) -> None:
        try:
            validate_secret_free(payload)
            validate_reference(payload.get("prd_reference"), "prd_reference")
            if "resource_pool_id" in payload:
                validate_identifier(payload.get("resource_pool_id"), "resource_pool_id")
        except ValueError as error:
            raise ProjectControlError(str(error)) from error
        try:
            validate_project_infrastructure_references(payload)
            if ("provider_reference" in payload or "hardware_reference" in payload) and self.validate_project_references is None:
                raise ValueError("registered infrastructure reference validation is unavailable")
            if self.validate_project_references is not None:
                self.validate_project_references(payload)
        except (TypeError, ValueError) as error:
            raise ProjectControlError(str(error)) from error
        agents = payload.get("agents")
        if not isinstance(agents, list) or not agents: raise ProjectControlError("agents must be a non-empty list")
        ids: set[str] = set(); orchestrators = 0
        for agent in agents:
            try:
                validate_agent_definition(agent)
            except ValueError as error:
                raise ProjectControlError(str(error)) from error
            if agent["id"] in ids: raise ProjectControlError("agent ids must be unique")
            ids.add(agent["id"]); orchestrators += agent.get("role") == "project_orchestrator"
        if orchestrators != 1: raise ProjectControlError("exactly one project_orchestrator is required")
        envelope = payload.get("resource_requested_envelope")
        if not isinstance(envelope, Mapping) or not envelope: raise ProjectControlError("resource_requested_envelope is required")
        for value in envelope.values():
            if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0 or value != value or value in (float("inf"), float("-inf")): raise ProjectControlError("resource_requested_envelope values must be finite non-negative numbers")
        if "forge_binding" in payload:
            try:
                validate_project_forge_binding(payload["forge_binding"])
            except ValueError as error:
                raise ProjectControlError(str(error)) from error
        if "github_frontier" in payload:
            frontier = payload["github_frontier"]
            if (not isinstance(frontier, Mapping) or set(frontier) != {"parent_issue_number"} or
                    type(frontier.get("parent_issue_number")) is not int or frontier["parent_issue_number"] < 1):
                raise ProjectControlError("github_frontier requires an exact positive parent_issue_number")
            binding = payload.get("forge_binding")
            if not isinstance(binding, Mapping) or normalize_project_forge_binding(binding).get("provider") != "github":
                raise ProjectControlError("github_frontier requires an explicit GitHub forge_binding")
        if "storage_binding" in payload:
            storage_binding = payload["storage_binding"]
            if (not isinstance(storage_binding, str) or not storage_binding.strip() or storage_binding == "storage." or
                    not storage_binding.startswith("storage.")):
                raise ProjectControlError("storage_binding must be an explicit storage capability binding")
            try: validate_identifier(storage_binding, "storage_binding")
            except ValueError as error: raise ProjectControlError(str(error)) from error
            declared = payload.get("binding_references")
            if declared is not None and (not isinstance(declared, list) or storage_binding not in declared):
                raise ProjectControlError("storage_binding must be declared in binding_references")
        if "binding_references" in payload:
            declared = payload["binding_references"]
            if not isinstance(declared, list):
                raise ProjectControlError("binding_references must be a list")
            for binding in declared:
                try: validate_identifier(binding, "binding reference")
                except ValueError as error: raise ProjectControlError(str(error)) from error
            if len(set(declared)) != len(declared):
                raise ProjectControlError("binding_references must be unique")
            consumed = {binding for agent in agents for binding in agent["capability_bindings"]}
            if not consumed.issubset(set(declared)): raise ProjectControlError("binding_references must declare every agent capability binding")
        if "storage_policy" in payload:
            try: validate_storage_policy(payload["storage_policy"])
            except ValueError as error: raise ProjectControlError(str(error)) from error

    def _validate_configuration(self, project_id: str, payload: dict[str, Any]) -> None:
        """Validate the revision's shape and configured grants for confirmation.

        Confirmation records the human's acceptance of this exact draft.  It
        must remain possible while a provider is temporarily unavailable;
        live composite readiness is checked by ``start`` and dispatch.
        """
        self._shape(payload)
        validator: Callable[..., bool] | None = self.validate_configuration or self.validate_project or self.validate_capacity_bindings
        if validator is None:
            raise ProjectControlError("capacity/binding validation unavailable")
        snapshot = json.loads(_canon(payload))
        try:
            accepted = validator(project_id, snapshot) if self.validate_configuration is not None or self.validate_project is not None else validator(snapshot)
        except Exception as exc:
            raise ProjectControlError("capacity/binding validation unavailable") from exc
        if accepted is not True:
            raise ProjectControlError("capacity/binding validation rejected or unknown")

    def _live_validate(self, project_id: str, payload: dict[str, Any]) -> None:
        self._shape(payload)
        if self.project_admission is not None:
            try:
                report = self.project_admission(project_id, json.loads(_canon(payload)))
            except Exception as exc:
                raise ProjectControlError("project admission is unavailable") from exc
            if not isinstance(report, Mapping) or report.get("eligible") is not True:
                dependency = report.get("unavailable_dependency") if isinstance(report, Mapping) else None
                reason = report.get("reason") if isinstance(report, Mapping) else None
                detail = f"{dependency}: {reason}" if dependency and reason else dependency or reason or "declared dependency is unavailable"
                raise ProjectControlError(f"project admission unavailable: {detail}")
            return
        raise ProjectControlError("composite project admission is unavailable")

    def admission_status(self, project_id: str) -> dict[str, Any]:
        """Return current admission evidence without mutating project state."""
        draft = self.draft(project_id)
        if self.project_admission is None:
            return {"project_id": project_id, "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "composite_readiness", "reason": "composite project admission is unavailable"}
        try:
            result = self.project_admission(project_id, json.loads(_canon(draft["payload"])))
        except Exception as exc:
            return {"project_id": project_id, "eligible": False, "status": "unavailable", "dependencies": [], "unavailable_dependency": "admission", "reason": str(exc)}
        return {"project_id": project_id, **dict(result)}

    def propose(self, project_id: str, payload: Mapping[str, Any], *, actor_role: str, actor_id: str, idempotency_key: str, expected_revision: int | None = None, owner_actor_id: str | None = None) -> dict[str, Any]:
        self._role(actor_role, {"human", "codex", "orchestrator"})
        try: validate_identifier(project_id, "project_id")
        except ValueError as error: raise ProjectControlError(str(error)) from error
        if not isinstance(idempotency_key, str) or not idempotency_key: raise ProjectControlError("project_id and idempotency_key are required")
        if not isinstance(actor_id, str) or not actor_id: raise ProjectControlError("actor_id is required")
        if owner_actor_id is not None and (not isinstance(owner_actor_id, str) or not owner_actor_id or owner_actor_id != actor_id): raise ProjectControlError("owner_actor_id must name the proposing actor or be null")
        if expected_revision is not None and (isinstance(expected_revision, bool) or not isinstance(expected_revision, int) or expected_revision < 1): raise ProjectControlError("expected_revision must be a positive integer or null")
        draft = json.loads(_canon(payload)); self._shape(draft)
        if "forge_binding" in draft:
            draft["forge_binding"] = normalize_project_forge_binding(draft["forge_binding"])
        command = {"action":"propose","project_id":project_id,"payload":draft,"expected_revision":expected_revision,"actor_id":actor_id,"actor_role":actor_role,"owner_actor_id":owner_actor_id}; fingerprint = _hash(command)
        with self._db() as c:
            old = c.execute("SELECT payload_hash,response FROM project_requests WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if old:
                if old["payload_hash"] != fingerprint: raise ProjectConflictError("idempotency key conflicts with a different payload")
                return json.loads(old["response"])
            c.execute("BEGIN IMMEDIATE")
            locked = c.execute("SELECT payload_hash,response FROM project_requests WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if locked:
                if locked["payload_hash"] != fingerprint: raise ProjectConflictError("idempotency key conflicts with a different payload")
                return json.loads(locked["response"])
            row = c.execute("SELECT revision FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
            actual = row["revision"] if row else None
            if actual != expected_revision: raise ProjectConflictError("stale or missing expected revision")
            if actual is None and owner_actor_id is not None:
                c.execute("INSERT INTO project_owners(project_id,actor_id) VALUES(?,?)", (project_id, owner_actor_id))
            revision = 1 if actual is None else actual + 1
            c.execute("INSERT INTO project_drafts(project_id,revision,payload,confirmed_revision,confirmed_by_id) VALUES(?,?,?,NULL,NULL) ON CONFLICT(project_id) DO UPDATE SET revision=excluded.revision,payload=excluded.payload,confirmed_revision=NULL,confirmed_by_id=NULL,updated_at=CURRENT_TIMESTAMP", (project_id, revision, _canon(draft)))
            # A new draft revision supersedes any lifecycle request attached to
            # the previous started revision.  Keep the request in the audit
            # journal, but never project it as the state of this new draft.
            c.execute("DELETE FROM project_lifecycle WHERE project_id=?", (project_id,))
            response = {"project_id": project_id, "revision": revision, "status": "draft", "validation_status": "not_checked"}
            c.execute("INSERT INTO project_requests(idempotency_key,project_id,action,actor_id,actor_role,command,payload_hash,response) VALUES(?,?,?,?,?,?,?,?)", (idempotency_key, project_id, "propose", actor_id, actor_role, _canon(command), fingerprint, _canon(response)))
            return response

    def confirm(self, project_id: str, revision: int, *, actor_role: str, actor_id: str) -> dict[str, Any]:
        self._role(actor_role, {"human"})
        if isinstance(revision, bool) or not isinstance(revision, int) or revision < 1 or not isinstance(actor_id, str) or not actor_id: raise ProjectControlError("revision and actor_id are required")
        with self._db() as c: row = c.execute("SELECT revision,payload FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
        if not row or row["revision"] != revision: raise ProjectConflictError("confirmation must name the current exact revision")
        payload = json.loads(row["payload"]); fingerprint = _hash(payload); self._validate_configuration(project_id, payload)
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT revision,payload FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
            if not row or row["revision"] != revision or _hash(json.loads(row["payload"])) != fingerprint: raise ProjectConflictError("draft changed during confirmation")
            c.execute("UPDATE project_drafts SET confirmed_revision=?,confirmed_by_id=? WHERE project_id=?", (revision, actor_id, project_id))
            c.execute("INSERT INTO project_confirmations(project_id,revision,actor_id,actor_role) VALUES(?,?,?,?)", (project_id, revision, actor_id, actor_role))
        return {"project_id": project_id, "revision": revision, "status": "confirmed"}

    def start(self, project_id: str, *, expected_revision: int, actor_role: str, actor_id: str, idempotency_key: str) -> dict[str, Any]:
        self._role(actor_role, {"human"})
        if isinstance(expected_revision, bool) or not isinstance(expected_revision, int) or expected_revision < 1 or not isinstance(actor_id, str) or not actor_id or not isinstance(idempotency_key, str) or not idempotency_key: raise ProjectControlError("expected_revision, actor_id and idempotency_key are required")
        command = {"action": "start", "project_id": project_id, "expected_revision": expected_revision, "actor_id": actor_id, "actor_role": actor_role}; command_hash = _hash(command)
        with self._db() as c:
            old = c.execute("SELECT action,payload_hash,response FROM project_requests WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if old:
                if old["action"] != "start" or old["payload_hash"] != command_hash: raise ProjectConflictError("idempotency key conflicts with a different command")
                return json.loads(old["response"])
            row = c.execute("SELECT revision,payload,confirmed_revision FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
        if not row or row["revision"] != expected_revision or row["confirmed_revision"] != expected_revision: raise ProjectConflictError("current exact revision requires human confirmation before start")
        payload = json.loads(row["payload"]); fingerprint_payload = _hash(payload); self._live_validate(project_id, payload)
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            locked = c.execute("SELECT action,payload_hash,response FROM project_requests WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if locked:
                if locked["action"] != "start" or locked["payload_hash"] != command_hash: raise ProjectConflictError("idempotency key conflicts with a different command")
                return json.loads(locked["response"])
            row = c.execute("SELECT revision,payload,confirmed_revision FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
            if not row or row["revision"] != expected_revision or row["confirmed_revision"] != expected_revision or _hash(json.loads(row["payload"])) != fingerprint_payload: raise ProjectConflictError("draft changed during start")
            # The initial admission check above only establishes that the
            # request was eligible when it was read.  Re-evaluate while this
            # authority holds the final project transaction so a lease,
            # binding generation, or gateway/authentication state change
            # cannot turn into a durable start intent.
            self._live_validate(project_id, json.loads(row["payload"]))
            body = {"project_id": project_id, "revision": expected_revision, "kind": "project_start_intent", "payload": payload}; fingerprint = _hash(body)
            existing = c.execute("SELECT intent_id FROM project_outbox WHERE project_id=? AND revision=?", (project_id, expected_revision)).fetchone()
            if existing:
                response = {"intent_id": existing["intent_id"], "project_id": project_id, "revision": expected_revision, "status": "start_intent_accepted"}
                c.execute("INSERT INTO project_requests(idempotency_key,project_id,action,actor_id,actor_role,command,payload_hash,response) VALUES(?,?,?,?,?,?,?,?)", (idempotency_key, project_id, "start", actor_id, actor_role, _canon(command), command_hash, _canon(response)))
                return response
            intent_id = _hash({"idempotency_key": idempotency_key, "payload_hash": fingerprint})
            c.execute("INSERT INTO project_outbox(intent_id,project_id,revision,started_by_id,started_by_role,payload_hash,body) VALUES(?,?,?,?,?,?,?)", (intent_id, project_id, row["revision"], actor_id, actor_role, fingerprint, _canon(body)))
            response = {"intent_id": intent_id, "project_id": project_id, "revision": row["revision"], "status": "start_intent_accepted"}
            c.execute("INSERT INTO project_requests(idempotency_key,project_id,action,actor_id,actor_role,command,payload_hash,response) VALUES(?,?,?,?,?,?,?,?)", (idempotency_key, project_id, "start", actor_id, actor_role, _canon(command), command_hash, _canon(response)))
            return response

    def _project_lifecycle_request(self, project_id: str, *, action: str, expected_revision: int,
                                   actor_role: str, actor_id: str, idempotency_key: str,
                                   reason: str) -> dict[str, Any]:
        """Record a safe project pause/end request without claiming execution.

        Runtime/orchestrator workers are separate authorities.  This journal is
        intentionally limited to durable Management intent and state; it never
        sends a signal, drains a worker, or deletes project data.
        """
        self._role(actor_role, {"human"})
        if action not in {"pause", "end"}:
            raise ProjectControlError("unsupported project lifecycle action")
        if (not isinstance(project_id, str) or not project_id or
                type(expected_revision) is not int or expected_revision < 1 or
                not isinstance(actor_id, str) or not actor_id or
                not isinstance(idempotency_key, str) or not idempotency_key or
                not isinstance(reason, str) or not reason.strip() or len(reason) > 512):
            raise ProjectControlError("project lifecycle request fields are invalid")
        command = {"action": action, "project_id": project_id,
                   "expected_revision": expected_revision, "actor_id": actor_id,
                   "actor_role": actor_role, "reason": reason.strip()}
        command_hash = _hash(command)
        with self._db() as c:
            old = c.execute("SELECT action,payload_hash,response FROM project_requests WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if old:
                if old["action"] != action or old["payload_hash"] != command_hash:
                    raise ProjectConflictError("idempotency key conflicts with a different command")
                return json.loads(old["response"])
            draft = c.execute("SELECT revision FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
            started = c.execute("SELECT 1 FROM project_outbox WHERE project_id=? AND revision=?", (project_id, expected_revision)).fetchone()
            current = c.execute("SELECT state,generation FROM project_lifecycle WHERE project_id=?", (project_id,)).fetchone()
            if draft is None or draft["revision"] != expected_revision or started is None:
                raise ProjectConflictError("project lifecycle requires the current started revision")
            current_state = current["state"] if current else "active"
            if action == "pause" and current_state in {"end_requested", "ended"}:
                raise ProjectConflictError("project is already ending or ended")
            if action == "end" and current_state == "ended":
                raise ProjectConflictError("project is already ended")
            generation = (int(current["generation"]) if current else 0) + 1
            state = "pause_requested" if action == "pause" else "end_requested"
            operation_id = _hash({"project_id": project_id, "revision": expected_revision,
                                  "action": action, "generation": generation})
            response = {"project_id": project_id, "revision": expected_revision,
                        "operation_id": operation_id, "state": state,
                        "generation": generation, "status": state,
                        "execution": "pending_runtime_ack",
                        "remote_repository_action": "not_requested"}
            c.execute("INSERT INTO project_lifecycle(project_id,state,generation,operation_id,reason) VALUES(?,?,?,?,?) ON CONFLICT(project_id) DO UPDATE SET state=excluded.state,generation=excluded.generation,operation_id=excluded.operation_id,reason=excluded.reason,updated_at=CURRENT_TIMESTAMP",
                      (project_id, state, generation, operation_id, reason.strip()))
            c.execute("INSERT INTO project_requests(idempotency_key,project_id,action,actor_id,actor_role,command,payload_hash,response) VALUES(?,?,?,?,?,?,?,?)",
                      (idempotency_key, project_id, action, actor_id, actor_role, _canon(command), command_hash, _canon(response)))
            return response

    def pause(self, project_id: str, *, expected_revision: int, actor_role: str,
              actor_id: str, idempotency_key: str, reason: str) -> dict[str, Any]:
        return self._project_lifecycle_request(project_id, action="pause", expected_revision=expected_revision,
                                               actor_role=actor_role, actor_id=actor_id,
                                               idempotency_key=idempotency_key, reason=reason)

    def end(self, project_id: str, *, expected_revision: int, actor_role: str,
            actor_id: str, idempotency_key: str, reason: str) -> dict[str, Any]:
        return self._project_lifecycle_request(project_id, action="end", expected_revision=expected_revision,
                                               actor_role=actor_role, actor_id=actor_id,
                                               idempotency_key=idempotency_key, reason=reason)

    def lifecycle(self, project_id: str) -> dict[str, Any]:
        """Return durable project state plus truthful control capabilities."""
        draft = self.draft(project_id)
        with self._db() as c:
            row = c.execute("SELECT state,generation,operation_id,reason,updated_at FROM project_lifecycle WHERE project_id=?", (project_id,)).fetchone()
            started = c.execute("SELECT 1 FROM project_outbox WHERE project_id=?", (project_id,)).fetchone() is not None
        state = row["state"] if row else ("active" if started else "draft")
        deletion_available = not started or state == "ended"
        deletion_reason = None if deletion_available else "requires_runtime_acknowledged_end"
        return {"project_id": project_id, "revision": draft["revision"], "state": state,
                "generation": row["generation"] if row else 0,
                "operation_id": row["operation_id"] if row else None,
                "reason": row["reason"] if row else None,
                "updated_at": row["updated_at"] if row else None,
                "capabilities": {
                    "start": {"available": draft["confirmed_revision"] == draft["revision"], "requires_human_confirmation": True},
                    "pause": {"available": started and state not in {"end_requested", "ended"}, "requires_human": True, "execution": "runtime_ack_required"},
                    "end": {"available": started and state != "ended", "requires_human": True, "execution": "runtime_ack_required"},
                    "delete": {"management_record": {"available": deletion_available, "requires_human": True, "reason": deletion_reason}, "local_project_files": {"available": deletion_available, "requires_human": True, "reason": deletion_reason, "remote_repository_deletion": "never_implicit"}},
                },
                "remote_repository_action": "not_requested"}

    @staticmethod
    def _require_deletion_state(c: sqlite3.Connection, project_id: str) -> None:
        """Prevent orphaning an execution until its owner acknowledges End."""
        started = c.execute("SELECT 1 FROM project_outbox WHERE project_id=?", (project_id,)).fetchone()
        if started is None:
            return
        lifecycle = c.execute("SELECT state FROM project_lifecycle WHERE project_id=?", (project_id,)).fetchone()
        if lifecycle is None or lifecycle["state"] != "ended":
            raise ProjectConflictError("project deletion requires a runtime-acknowledged ended state")

    def delete_management_record(self, project_id: str, *, expected_revision: int,
                                 actor_role: str, actor_id: str, idempotency_key: str,
                                 confirmation: Mapping[str, Any]) -> dict[str, Any]:
        """Delete only Management-owned records after an exact human confirmation."""
        self._role(actor_role, {"human"})
        expected_confirmation = {"scope": "management_record", "project_id": project_id, "revision": expected_revision}
        if confirmation != expected_confirmation:
            raise ProjectControlError("management record deletion requires exact confirmation scope, project_id, and revision")
        command = {"action": "delete", "scope": "management_record", "project_id": project_id,
                   "expected_revision": expected_revision, "actor_id": actor_id, "actor_role": actor_role}
        command_hash = _hash(command)
        with self._db() as c:
            tombstone = c.execute("SELECT project_id,scope,response FROM project_tombstones WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if tombstone:
                if tombstone["project_id"] != project_id or tombstone["scope"] != "management_record":
                    raise ProjectConflictError("idempotency key conflicts with a different deletion")
                stored = c.execute("SELECT payload_hash FROM project_tombstones WHERE idempotency_key=?", (idempotency_key,)).fetchone()
                if stored["payload_hash"] and stored["payload_hash"] != command_hash:
                    raise ProjectConflictError("idempotency key conflicts with a different deletion")
                return json.loads(tombstone["response"])
            row = c.execute("SELECT revision FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
            if row is None or row["revision"] != expected_revision:
                raise ProjectConflictError("deletion requires the current exact project revision")
            self._require_deletion_state(c, project_id)
            response = {"project_id": project_id, "revision": expected_revision, "scope": "management_record",
                        "state": "deleted", "status": "deleted", "remote_repository_action": "not_requested"}
            c.execute("INSERT INTO project_tombstones(idempotency_key,project_id,scope,actor_id,payload_hash,response) VALUES(?,?,?,?,?,?)",
                      (idempotency_key, project_id, "management_record", actor_id, command_hash, _canon(response)))
            c.execute("DELETE FROM project_lifecycle WHERE project_id=?", (project_id,))
            c.execute("DELETE FROM project_outbox WHERE project_id=?", (project_id,))
            c.execute("DELETE FROM project_confirmations WHERE project_id=?", (project_id,))
            c.execute("DELETE FROM project_requests WHERE project_id=?", (project_id,))
            c.execute("DELETE FROM project_owners WHERE project_id=?", (project_id,))
            c.execute("DELETE FROM project_drafts WHERE project_id=?", (project_id,))
            return response

    def can_replay_deletion(self, project_id: str, idempotency_key: str, actor_id: str) -> bool:
        """Authorize only the actor that already completed a record deletion.

        Deleting the Management record removes its owner row, so an owner-only
        human token must still be able to receive its idempotent cached receipt
        without granting that token access to a different project.
        """
        if not all(isinstance(value, str) and value for value in (project_id, idempotency_key, actor_id)):
            return False
        with self._db() as c:
            row = c.execute("SELECT actor_id,scope FROM project_tombstones WHERE idempotency_key=? AND project_id=?", (idempotency_key, project_id)).fetchone()
        return bool(row and row["scope"] == "management_record" and row["actor_id"] == actor_id)

    def check_local_files_deletion(self, project_id: str, *, expected_revision: int,
                                   actor_role: str, actor_id: str, idempotency_key: str,
                                   confirmation: Mapping[str, Any], relative_path: str) -> dict[str, Any] | None:
        """Preflight a local-files deletion before the adapter mutates disk.

        A conflicting replay must be rejected before the filesystem operation;
        otherwise a reused idempotency key could delete files and only then
        discover that its command was not the original command.
        """
        self._role(actor_role, {"human"})
        expected_confirmation = {"scope": "local_project_files", "project_id": project_id,
                                 "revision": expected_revision, "relative_path": relative_path}
        if confirmation != expected_confirmation:
            raise ProjectControlError("local file deletion requires exact confirmation scope, project_id, revision, and relative_path")
        command = {"action": "delete", "scope": "local_project_files", "project_id": project_id,
                   "expected_revision": expected_revision, "relative_path": relative_path,
                   "actor_id": actor_id, "actor_role": actor_role}
        command_hash = _hash(command)
        with self._db() as c:
            old = c.execute("SELECT action,payload_hash,response FROM project_requests WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if old:
                if old["action"] != "delete" or old["payload_hash"] != command_hash:
                    raise ProjectConflictError("idempotency key conflicts with a different deletion")
                return json.loads(old["response"])
            row = c.execute("SELECT revision FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
            if row is None or row["revision"] != expected_revision:
                raise ProjectConflictError("local file deletion requires the current exact project revision")
            self._require_deletion_state(c, project_id)
        return None

    def record_local_files_deletion(self, project_id: str, *, expected_revision: int,
                                    actor_role: str, actor_id: str, idempotency_key: str,
                                    confirmation: Mapping[str, Any], relative_path: str) -> dict[str, Any]:
        """Record a local-files deletion after the API has removed the safe path.

        This journal method never knows a forge URL and therefore cannot delete a
        remote repository.  The HTTP adapter validates/removes the configured
        local path before calling it.
        """
        self._role(actor_role, {"human"})
        expected_confirmation = {"scope": "local_project_files", "project_id": project_id,
                                 "revision": expected_revision, "relative_path": relative_path}
        if confirmation != expected_confirmation:
            raise ProjectControlError("local file deletion requires exact confirmation scope, project_id, revision, and relative_path")
        command = {"action": "delete", "scope": "local_project_files", "project_id": project_id,
                   "expected_revision": expected_revision, "relative_path": relative_path,
                   "actor_id": actor_id, "actor_role": actor_role}
        command_hash = _hash(command)
        with self._db() as c:
            old = c.execute("SELECT action,payload_hash,response FROM project_requests WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if old:
                if old["action"] != "delete" or old["payload_hash"] != command_hash:
                    raise ProjectConflictError("idempotency key conflicts with a different deletion")
                return json.loads(old["response"])
            row = c.execute("SELECT revision FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
            if row is None or row["revision"] != expected_revision:
                raise ProjectConflictError("local file deletion requires the current exact project revision")
            self._require_deletion_state(c, project_id)
            response = {"project_id": project_id, "revision": expected_revision, "scope": "local_project_files",
                        "state": "deleted", "status": "deleted", "relative_path": relative_path,
                        "remote_repository_action": "not_requested"}
            c.execute("INSERT INTO project_requests(idempotency_key,project_id,action,actor_id,actor_role,command,payload_hash,response) VALUES(?,?,?,?,?,?,?,?)",
                      (idempotency_key, project_id, "delete", actor_id, actor_role, _canon(command), command_hash, _canon(response)))
            return response

    def draft(self, project_id: str) -> dict[str, Any]:
        with self._db() as c: row = c.execute("SELECT project_id,revision,payload,confirmed_revision,confirmed_by_id FROM project_drafts WHERE project_id=?", (project_id,)).fetchone()
        if not row: raise KeyError("unknown project")
        return {**dict(row), "payload": json.loads(row["payload"])}

    def has_project(self, project_id: str) -> bool:
        if not isinstance(project_id, str) or not project_id:
            raise ProjectControlError("project_id is required")
        with self._db() as c:
            return c.execute("SELECT 1 FROM project_drafts WHERE project_id=?", (project_id,)).fetchone() is not None

    def is_owner(self, project_id: str, actor_id: str) -> bool:
        if not isinstance(project_id, str) or not project_id or not isinstance(actor_id, str) or not actor_id:
            raise ProjectControlError("project_id and actor_id are required")
        with self._db() as c:
            return c.execute("SELECT 1 FROM project_owners WHERE project_id=? AND actor_id=?", (project_id, actor_id)).fetchone() is not None

    def owned_project_ids(self, actor_id: str) -> frozenset[str]:
        if not isinstance(actor_id, str) or not actor_id:
            raise ProjectControlError("actor_id is required")
        with self._db() as c:
            rows = c.execute("SELECT project_id FROM project_owners WHERE actor_id=? ORDER BY project_id", (actor_id,)).fetchall()
        return frozenset(row["project_id"] for row in rows)

    def list_owned_projects(self, actor_id: str) -> list[dict[str, Any]]:
        return self.list_projects(self.owned_project_ids(actor_id))

    def list_projects(self, project_ids: frozenset[str] | None = None) -> list[dict[str, Any]]:
        if project_ids is not None and (not isinstance(project_ids, frozenset) or any(not isinstance(project_id, str) or not project_id for project_id in project_ids)):
            raise ProjectControlError("project_ids must be a frozenset of non-empty project identifiers")
        if project_ids is not None and not project_ids:
            return []
        with self._db() as c:
            if project_ids is None:
                rows = c.execute("SELECT project_id,revision,confirmed_revision FROM project_drafts ORDER BY project_id").fetchall()
            else:
                marks = ",".join("?" for _ in project_ids)
                rows = c.execute(f"SELECT project_id,revision,confirmed_revision FROM project_drafts WHERE project_id IN ({marks}) ORDER BY project_id", tuple(sorted(project_ids))).fetchall()
            started = {(row["project_id"], row["revision"]) for row in c.execute("SELECT project_id,revision FROM project_outbox")}
            lifecycle = {row["project_id"]: row["state"] for row in c.execute("SELECT project_id,state FROM project_lifecycle")}
        result = []
        for row in rows:
            base = "start_intent_accepted" if (row["project_id"], row["revision"]) in started else "confirmed" if row["confirmed_revision"] == row["revision"] else "draft"
            state = lifecycle.get(row["project_id"])
            result.append({**dict(row), "status": state if state and base == "start_intent_accepted" else base})
        return result

    def outbox(self) -> list[dict[str, Any]]:
        with self._db() as c: rows = c.execute("SELECT intent_id,project_id,revision,started_by_id,started_by_role,payload_hash,body FROM project_outbox ORDER BY created_at").fetchall()
        return [{**dict(row), "body": json.loads(row["body"])} for row in rows]

    def audit(self, project_id: str) -> dict[str, Any]:
        draft = self.draft(project_id)
        with self._db() as c:
            rows = c.execute("SELECT idempotency_key,action,actor_id,actor_role,command,response,created_at FROM project_requests WHERE project_id=? ORDER BY created_at", (project_id,)).fetchall()
            confirmations = c.execute("SELECT revision,actor_id,actor_role,created_at FROM project_confirmations WHERE project_id=? ORDER BY revision", (project_id,)).fetchall()
        return {"project_id": project_id, "confirmation": {"revision": draft["confirmed_revision"], "actor_id": draft.get("confirmed_by_id"), "actor_role": "human" if draft.get("confirmed_by_id") else None}, "confirmation_history": [dict(row) for row in confirmations], "requests": [{**dict(row), "action_id": row["idempotency_key"], "command": json.loads(row["command"]), "response": json.loads(row["response"])} for row in rows]}

    def record_auth_event(self, event: Mapping[str, Any]) -> None:
        """Persist one sanitized public-boundary authentication outcome.

        The caller supplies only already-normalized metadata.  The action ID is
        the idempotency key, so retries of the same boundary observation do not
        duplicate the durable event.
        """
        required = {"action_id", "action", "outcome", "subject", "occurred_at"}
        if set(event) - (required | {"actor_id", "actor_role"}) or not required.issubset(event):
            raise ProjectControlError("authentication event is malformed")
        values = {key: event.get(key) for key in required | {"actor_id", "actor_role"}}
        if any(not isinstance(values[key], str) or not values[key] for key in required) or any(values[key] is not None and (not isinstance(values[key], str) or not values[key]) for key in ("actor_id", "actor_role")):
            raise ProjectControlError("authentication event is malformed")
        with self._db() as c:
            c.execute("INSERT OR IGNORE INTO management_auth_events(action_id,action,outcome,actor_id,actor_role,subject,occurred_at) VALUES(?,?,?,?,?,?,?)", tuple(values[key] for key in ("action_id", "action", "outcome", "actor_id", "actor_role", "subject", "occurred_at")))

    def auth_events(self) -> list[dict[str, Any]]:
        with self._db() as c:
            rows = c.execute("SELECT action_id,action,outcome,actor_id,actor_role,subject,occurred_at FROM management_auth_events ORDER BY occurred_at,action_id").fetchall()
        return [dict(row) for row in rows]
