"""Stable, loopback node-control boundary over the durable HardwareRegistry.

This intentionally coexists with the older ``/hardware`` adapter.  Its public
wire paths are unversioned and its node credentials are read only from explicit
private token files at process construction.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import hmac
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import threading
from typing import Any, Callable, Mapping
from urllib.parse import unquote, urlsplit

from .hardware_registry import HardwareRegistry, HardwareRegistryError

MAX_BODY_BYTES = 64 * 1024
_ID = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.")


class NodeControlError(ValueError): pass


def _identifier(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 128 or any(char not in _ID for char in value):
        raise NodeControlError(f"{name} is invalid")
    return value


def _token(path: Path) -> str:
    if not path.is_absolute() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents) or not path.is_file():
        raise NodeControlError("node token file is unsafe")
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise NodeControlError("node token file must be private")
    value = path.read_text(encoding="utf-8").strip()
    if not value or not value.isascii() or len(value) > 4096 or any(char.isspace() for char in value):
        raise NodeControlError("node token file is invalid")
    return value


@dataclass(frozen=True)
class NodeControlConfig:
    token_files: Mapping[Path, str]
    host: str = "127.0.0.1"
    port: int = 0
    max_body_bytes: int = MAX_BODY_BYTES

    def __post_init__(self) -> None:
        if self.host != "127.0.0.1" or type(self.port) is not int or not 0 <= self.port <= 65535 or type(self.max_body_bytes) is not int or not 1 <= self.max_body_bytes <= MAX_BODY_BYTES:
            raise NodeControlError("loopback listener bounds are invalid")
        tokens: dict[str, str] = {}
        for path, node in self.token_files.items():
            node_id = _identifier(node, "node scope")
            token = _token(Path(path))
            if token in tokens: raise NodeControlError("node token values must be unique")
            tokens[token] = node_id
        if not tokens: raise NodeControlError("at least one scoped node token file is required")
        object.__setattr__(self, "token_files", {Path(path).resolve(strict=True): node for path, node in self.token_files.items()})
        object.__setattr__(self, "_tokens", tokens)


class NodeControlServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, registry: HardwareRegistry, config: NodeControlConfig, command_provider: Callable[[str, Mapping[str, Any]], str] | None = None):
        self.registry, self.config, self.command_provider = registry, config, command_provider or (lambda _node, _telemetry: "continue")
        self._control_lock = threading.Lock()
        super().__init__((config.host, config.port), NodeControlHandler)
        with registry._connection() as connection:  # durable sidecar journal in the same registry database
            connection.execute("CREATE TABLE IF NOT EXISTS node_control_operations(operation_id TEXT PRIMARY KEY,node_id TEXT NOT NULL,boot_id TEXT NOT NULL,sequence INTEGER NOT NULL,kind TEXT NOT NULL,fingerprint TEXT NOT NULL,state TEXT NOT NULL,response TEXT)")
            connection.execute("CREATE TABLE IF NOT EXISTS node_control_state(node_id TEXT PRIMARY KEY,boot_id TEXT NOT NULL,sequence INTEGER NOT NULL,status TEXT NOT NULL)")

    def _stored(self, operation_id: str, fingerprint: str) -> dict[str, Any] | None:
        with self.registry._connection() as connection:
            row = connection.execute("SELECT fingerprint,state,response FROM node_control_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None: return None
        if not hmac.compare_digest(row["fingerprint"], fingerprint): raise NodeControlError("operation_id replay conflicts")
        if row["state"] == "prepared": return {"_prepared": True}
        return json.loads(row["response"])

    def execute(self, kind: str, node_id: str, body: Mapping[str, Any]) -> dict[str, Any]:
        operation_id, boot_id = _identifier(body.get("operation_id"), "operation_id"), _identifier(body.get("boot_id"), "boot_id")
        if body.get("hardware_node_id") != node_id or type(body.get("sequence")) is not int or isinstance(body.get("sequence"), bool) or body["sequence"] < 0:
            raise NodeControlError("node identity or sequence is invalid")
        fingerprint = hashlib.sha256(json.dumps(dict(body), sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
        old = self._stored(operation_id, fingerprint)
        if old is not None:
            if old.get("_prepared"):
                reconciled = self._reconcile_prepared(kind, node_id, body)
                if reconciled is None: raise NodeControlError("operation outcome is unknown; reconcile required")
                with self.registry._connection() as connection: connection.execute("UPDATE node_control_operations SET state='completed',response=? WHERE operation_id=? AND state='prepared'", (json.dumps(reconciled,separators=(",",":")),operation_id))
                return reconciled
            return old
        # HardwareRegistry owns its own SQLite transactions. Serialize this
        # adapter's read/registry-write/receipt sequence so a duplicate local
        # request cannot effect registration or telemetry twice before its
        # operation receipt is committed.
        with self._control_lock:
          # Persist intent before touching HardwareRegistry. A process loss now
          # leaves a durable prepared record, so replay cannot repeat an
          # uncertain effect under a new implicit attempt.
          with self.registry._connection() as prepare:
            prepare.execute("INSERT INTO node_control_operations(operation_id,node_id,boot_id,sequence,kind,fingerprint,state,response) VALUES(?,?,?,?,?,?,?,NULL)", (operation_id,node_id,boot_id,body["sequence"],kind,fingerprint,"prepared"))
          with self.registry._connection() as connection:
            row = connection.execute("SELECT boot_id,sequence,status FROM node_control_state WHERE node_id=?", (node_id,)).fetchone()
            if kind == "register":
                registration = body.get("registration")
                identity = registration.get("node_identity") if isinstance(registration, Mapping) else None
                if set(body) != {"hardware_node_id", "boot_id", "timestamp", "sequence", "operation_id", "registration"} or not isinstance(body.get("timestamp"),str) or not isinstance(registration, Mapping) or registration.get("node_id") != node_id or not isinstance(identity, Mapping) or identity.get("host_boot_id") != boot_id:
                    raise NodeControlError("register schema is invalid")
                if row is not None and row["boot_id"] == boot_id and body["sequence"] < row["sequence"]: raise NodeControlError("register sequence is stale")
                connection.commit(); self.registry.register(node_id, registration)
                status = "registered"; command = None
            elif kind == "heartbeat":
                telemetry = body.get("telemetry")
                if set(body) != {"hardware_node_id", "boot_id", "timestamp", "sequence", "operation_id", "telemetry"} or not isinstance(body.get("timestamp"),str) or not isinstance(telemetry, Mapping):
                    raise NodeControlError("heartbeat schema is invalid")
                if telemetry.get("hardware_node_id") != node_id:
                    # Node Runtime's bounded component map is normalized into
                    # the HardwareRegistry's durable collector envelope.
                    if not telemetry or any(not isinstance(value,Mapping) for value in telemetry.values()): raise NodeControlError("heartbeat telemetry is invalid")
                    metrics=[]
                    for component,value in telemetry.items():
                        if set(value)!={"available","freshness_seconds","metrics"} or type(value.get("available")) is not bool or not isinstance(value.get("metrics"),Mapping): raise NodeControlError("heartbeat telemetry is invalid")
                        for metric,number in value["metrics"].items(): metrics.append({"name":component+"."+metric,"unit":"unit","value":number if value["available"] else None,"availability":{"state":"reported" if value["available"] else "no-sample"},"device":{"kind":"host","id":node_id}})
                    if not metrics: metrics=[{"name":"runtime.heartbeat","unit":"count","value":1,"availability":{"state":"reported"},"device":{"kind":"host","id":node_id}}]
                    telemetry={"sample_id":operation_id,"hardware_node_id":node_id,"host_boot_id":boot_id,"sequence":body["sequence"],"observed_at":body["timestamp"],"collector":{"id":"node-runtime","version":"stable"},"source":"node-runtime","cadence_seconds":10,"freshness":{"state":"fresh"},"metrics":metrics}
                if telemetry.get("host_boot_id") != boot_id: raise NodeControlError("heartbeat schema is invalid")
                if row is None or row["boot_id"] != boot_id or row["status"] == "withdrawn" or body["sequence"] < row["sequence"] or (body["sequence"] == row["sequence"] and row["status"] != "registered"): raise NodeControlError("heartbeat is stale or node is unavailable")
                command = self.command_provider(node_id, telemetry)
                if command not in {"continue", "pause"}: raise NodeControlError("configured command is invalid")
                # Persist the pure decision before the registry effect. A
                # prepared replay can return precisely this command after it
                # proves the telemetry projection, without invoking policy again.
                with self.registry._connection() as planned: planned.execute("UPDATE node_control_operations SET response=? WHERE operation_id=? AND state='prepared'", (json.dumps({"command":command}),operation_id))
                connection.commit(); self.registry.ingest_telemetry(node_id, telemetry)
                status = "healthy"
            else:
                receipt = body.get("receipt")
                if set(body) != {"hardware_node_id", "boot_id", "timestamp", "sequence", "operation_id", "receipt"} or not isinstance(receipt, Mapping) or set(receipt) != {"kind", "receipt_id", "timestamp"} or receipt.get("kind") not in {"checkpoint", "no_work"} or not isinstance(receipt.get("timestamp"), str) or len(receipt["timestamp"]) > 64:
                    raise NodeControlError("withdraw schema is invalid")
                _identifier(receipt.get("receipt_id"), "receipt_id")
                if row is None or row["boot_id"] != boot_id or body["sequence"] < row["sequence"]: raise NodeControlError("withdraw is stale or node is unavailable")
                status = "withdrawn"; command = None
            response: dict[str, Any] = {"hardware_node_id": node_id, "boot_id": boot_id, "operation_id": operation_id, "sequence": body["sequence"], "state": status, "management_timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")}
            if command is not None: response["command"] = command
            encoded = json.dumps(response, separators=(",", ":"))
            with self.registry._connection() as write:
                write.execute("UPDATE node_control_operations SET state=?,response=? WHERE operation_id=? AND state='prepared'", ("completed",encoded,operation_id))
                write.execute("INSERT INTO node_control_state VALUES(?,?,?,?) ON CONFLICT(node_id) DO UPDATE SET boot_id=excluded.boot_id,sequence=excluded.sequence,status=excluded.status", (node_id, boot_id, body["sequence"], status))
        return response

    def _reconcile_prepared(self, kind: str, node_id: str, body: Mapping[str, Any]) -> dict[str, Any] | None:
        """Prove a prepared effect from the durable HardwareRegistry, never resend."""
        snapshot = self.registry.get_snapshot(node_id)
        if snapshot is None: return None
        if kind == "register":
            if snapshot.get("registration") != body.get("registration"): return None
            state = "registered"
        elif kind == "heartbeat":
            telemetry = body.get("telemetry")
            collector = telemetry.get("collector",{}).get("id") if isinstance(telemetry,Mapping) else "node-runtime"
            current = snapshot.get("telemetry",{}).get(collector)
            if not isinstance(current,Mapping) or current.get("host_boot_id") != body.get("boot_id") or current.get("sequence") != body.get("sequence"): return None
            with self.registry._connection() as connection: row=connection.execute("SELECT response FROM node_control_operations WHERE operation_id=?",(body["operation_id"],)).fetchone()
            if row is None or not row["response"]: return None
            planned=json.loads(row["response"]); command=planned.get("command") if isinstance(planned,Mapping) else None
            if command not in {"continue","pause"}: return None
            return {"hardware_node_id":node_id,"boot_id":body["boot_id"],"operation_id":body["operation_id"],"sequence":body["sequence"],"state":"healthy","command":command,"management_timestamp":datetime.now(timezone.utc).isoformat().replace("+00:00","Z")}
        else: return None
        return {"hardware_node_id":node_id,"boot_id":body["boot_id"],"operation_id":body["operation_id"],"sequence":body["sequence"],"state":state,"management_timestamp":datetime.now(timezone.utc).isoformat().replace("+00:00","Z")}

    def withdraw(self, node_id: str, operation_id: str) -> dict[str, Any] | None:
        with self.registry._connection() as connection:
            row = connection.execute("SELECT node_id,kind,response FROM node_control_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None or row["node_id"] != node_id or row["kind"] != "withdraw": return None
        return json.loads(row["response"])


class NodeControlHandler(BaseHTTPRequestHandler):
    server: NodeControlServer
    protocol_version = "HTTP/1.1"
    def log_message(self, *_: object) -> None: pass
    def _node(self) -> str | None:
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer "): return None
        supplied = header[7:]
        for token, node in self.server.config._tokens.items():
            if hmac.compare_digest(supplied, token): return node
        return None
    def _send(self, status: int, body: Mapping[str, Any]) -> None:
        raw = json.dumps(dict(body), separators=(",", ":"), allow_nan=False).encode(); self.send_response(status); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(raw))); self.send_header("Connection", "close"); self.end_headers(); self.wfile.write(raw)
    def _body(self) -> dict[str, Any] | None:
        try:
            length=int(self.headers.get("Content-Length", "-1")); raw=self.rfile.read(length)
            value=json.loads(raw.decode("utf-8"), parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        except (ValueError, UnicodeDecodeError, OSError): return None
        return value if 0 <= length <= self.server.config.max_body_bytes and isinstance(value, dict) else None
    def do_POST(self) -> None:  # noqa: N802
        node=self._node(); path=urlsplit(self.path).path
        if node is None: self._send(401,{"error":"unauthorized"}); return
        kind={"/nodes/register":"register","/nodes/heartbeat":"heartbeat","/nodes/withdraw":"withdraw"}.get(path)
        if kind is None: self._send(404,{"error":"not_found"}); return
        if self.headers.get("Content-Type", "").split(";",1)[0].lower() != "application/json" or (body:=self._body()) is None: self._send(400,{"error":"invalid_request"}); return
        try: self._send(200 if kind != "heartbeat" else 202, self.server.execute(kind,node,body))
        except (NodeControlError, HardwareRegistryError): self._send(409,{"error":"rejected"})
    def do_GET(self) -> None:  # noqa: N802
        node=self._node(); parts=[unquote(x) for x in urlsplit(self.path).path.split("/") if x]
        if node is None: self._send(401,{"error":"unauthorized"}); return
        if len(parts)==3 and parts[:2]==["nodes","withdraw"]:
            result=self.server.withdraw(node,parts[2]); self._send(200,result) if result else self._send(404,{"error":"not_found"}); return
        self._send(404,{"error":"not_found"})


def serve(registry: HardwareRegistry, config: NodeControlConfig, command_provider: Callable[[str, Mapping[str, Any]], str] | None = None) -> NodeControlServer:
    return NodeControlServer(registry, config, command_provider)
