"""Explicit composition for dispatching confirmed Management start intents.

This is not an agent loop or scheduler.  An embedding service supplies the
authenticated Prefect client and the authoritative grants/bindings validator,
then calls :meth:`ManagementProjectExecutor.tick` deliberately.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path
import ssl
from typing import Any, Callable, Mapping
from urllib.parse import urlsplit
from uuid import UUID

from .prefect_project_submitter import PrefectClient, PrefectProjectSubmitter
from .project_control import ProjectControl
from .project_dispatch import AuthoritativeValidator, ProjectIntentDispatcher
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


class ManagementExecutorError(ValueError):
    """Raised when explicit executor configuration or composition is unsafe."""


@dataclass(frozen=True)
class ManagementExecutorConfig:
    """External executor settings, including an optional credential.

    The API key belongs only in an operator-controlled external file.  Client
    construction remains explicit and never selects ambient Prefect profiles,
    cloud credentials, or an unconfigured endpoint.
    """

    dispatch_database: Path
    management_config: Path
    deployment_id: UUID
    prefect_url: str
    prefect_api_key: str | None
    claimant: str
    claim_lease_seconds: float = 30.0
    state_root: Path | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.dispatch_database, Path) or not isinstance(self.management_config, Path) or not self.dispatch_database.is_absolute() or not self.management_config.is_absolute():
            raise ManagementExecutorError("executor and management configuration paths must be explicit absolute paths")
        try:
            state_root = validate_state_root(self.state_root if self.state_root is not None else self.dispatch_database.parent, "Management executor state root")
            dispatch_database = validate_durable_leaf(self.dispatch_database, state_root, label="Management dispatch database")
        except (ManagementStateBoundaryError, TypeError) as error:
            raise ManagementExecutorError("Management dispatch database is unsafe") from error
        object.__setattr__(self, "state_root", state_root)
        object.__setattr__(self, "dispatch_database", dispatch_database)
        if not isinstance(self.claimant, str) or not self.claimant:
            raise ManagementExecutorError("claimant is required")
        if isinstance(self.claim_lease_seconds, bool) or not isinstance(self.claim_lease_seconds, (int, float)) or not math.isfinite(self.claim_lease_seconds) or self.claim_lease_seconds <= 0:
            raise ManagementExecutorError("claim lease must be positive")
        parsed = urlsplit(self.prefect_url) if isinstance(self.prefect_url, str) else None
        loopback = parsed is not None and parsed.hostname in {"127.0.0.1", "::1", "localhost"}
        if parsed is None or parsed.username or parsed.password or parsed.query or parsed.fragment or not parsed.netloc or not (parsed.scheme == "https" or parsed.scheme == "http" and loopback):
            raise ManagementExecutorError("Prefect URL must use HTTPS or loopback HTTP without embedded credentials or redirects")
        if self.prefect_api_key is not None and (not isinstance(self.prefect_api_key, str) or not self.prefect_api_key):
            raise ManagementExecutorError("Prefect API key must be a non-empty string or null")


def load_executor_config(path: str | Path) -> ManagementExecutorConfig:
    """Load non-secret deployment and journal settings from external JSON."""
    config_path = Path(path)
    if not config_path.is_file():
        raise ManagementExecutorError("external executor configuration file is required")
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ManagementExecutorError("external executor configuration must be valid UTF-8 JSON") from error
    if not isinstance(raw, Mapping):
        raise ManagementExecutorError("external executor configuration must be an object")
    try:
        return ManagementExecutorConfig(
            dispatch_database=Path(raw["dispatch_database"]),
            management_config=Path(raw["management_config"]),
            deployment_id=UUID(str(raw["deployment_id"])),
            prefect_url=raw["prefect_url"],
            prefect_api_key=raw.get("prefect_api_key"),
            claimant=raw["claimant"],
            claim_lease_seconds=raw.get("claim_lease_seconds", 30.0),
            state_root=Path(raw["state_root"]) if "state_root" in raw else None,
        )
    except (KeyError, TypeError, ValueError) as error:
        raise ManagementExecutorError("executor deployment configuration is invalid") from error


class ManagementProjectExecutor:
    """Compose ProjectControl, one Prefect deployment, and the durable dispatcher."""

    def __init__(
        self,
        config: ManagementExecutorConfig,
        projects: ProjectControl,
        validate_project: AuthoritativeValidator,
        prefect_client: PrefectClient,
    ) -> None:
        if not isinstance(projects, ProjectControl) or not callable(validate_project):
            raise ManagementExecutorError("ProjectControl and an authoritative validator are required")
        self.config = config
        self.projects = projects
        self.validate_project = validate_project
        self._intent_revisions: dict[tuple[str, str], set[int]] = {}
        self.dispatcher = ProjectIntentDispatcher(
            config.dispatch_database,
            projects,
            self._validate_current_intent,
            PrefectProjectSubmitter(config.deployment_id, prefect_client),
            claim_lease_seconds=config.claim_lease_seconds,
            state_root=config.state_root,
        )

    @staticmethod
    def _canonical_payload(payload: Mapping[str, Any]) -> str:
        return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)

    def _refresh_intent_revisions(self) -> None:
        revisions: dict[tuple[str, str], set[int]] = {}
        for entry in self.projects.outbox():
            project_id = entry.get("project_id")
            revision = entry.get("revision")
            body = entry.get("body")
            payload = body.get("payload") if isinstance(body, Mapping) else None
            if not isinstance(project_id, str) or not project_id or type(revision) is not int or revision < 1 or not isinstance(payload, Mapping):
                raise ManagementExecutorError("project outbox has an invalid start intent")
            key = (project_id, self._canonical_payload(payload))
            revisions.setdefault(key, set()).add(revision)
        self._intent_revisions = revisions

    def _validate_current_intent(self, project_id: str, payload: Mapping[str, Any]) -> bool | Mapping[str, Any]:
        """Require the intended exact revision to remain approved before submit.

        If two accepted intents share a payload, revision identity cannot be
        recovered from the dispatcher's payload-only validation callback.  That
        ambiguity is rejected instead of allowing either external effect.
        """
        if not isinstance(project_id, str) or not project_id or not isinstance(payload, Mapping):
            return False
        try:
            revisions = self._intent_revisions[(project_id, self._canonical_payload(payload))]
            if len(revisions) != 1:
                return False
            revision = next(iter(revisions))
            draft = self.projects.draft(project_id)
            if draft.get("revision") != revision or draft.get("confirmed_revision") != revision:
                return False
            current_payload = draft.get("payload")
            if not isinstance(current_payload, Mapping) or self._canonical_payload(current_payload) != self._canonical_payload(payload):
                return False
            admission = self.projects.admission_status(project_id)
            if not isinstance(admission, Mapping) or admission.get("eligible") is not True:
                dependency = admission.get("unavailable_dependency") if isinstance(admission, Mapping) else None
                reason = admission.get("reason") if isinstance(admission, Mapping) else None
                detail = "project admission is unavailable"
                if dependency:
                    detail += f": {dependency}"
                if reason:
                    detail += f" ({reason})"
                return {"eligible": False, "detail": detail}
            return self.validate_project(project_id, json.loads(self._canonical_payload(payload))) is True
        except (KeyError, ValueError, TypeError):
            return False

    def tick(self) -> dict[str, int]:
        """Revalidate current approval and authority, then dispatch at most one intent."""
        self._refresh_intent_revisions()
        return self.dispatcher.tick(self.config.claimant)

    def status_projection(self, project_id: str | None = None) -> list[dict[str, Any]]:
        """Return durable execution references suitable for a future management route."""
        if project_id is not None and (not isinstance(project_id, str) or not project_id):
            raise ManagementExecutorError("project_id must be a non-empty string or null")
        rows: list[dict[str, Any]] = []
        for record in self.dispatcher.records():
            if project_id is not None and record["project_id"] != project_id:
                continue
            receipt = record.get("receipt")
            execution_id = receipt.get("execution_id") if isinstance(receipt, Mapping) else None
            rows.append(
                {
                    "intent_id": record["intent_id"],
                    "project_id": record["project_id"],
                    "revision": record["revision"],
                    "dispatch_status": record["state"],
                    "execution_id": execution_id,
                    "detail": record.get("detail"),
                }
            )
        return rows


def main(argv: list[str] | None = None) -> int:
    """Run one explicit, authenticated executor tick from external configuration."""
    parser = argparse.ArgumentParser(description="Dispatch one explicitly configured Management start intent.")
    parser.add_argument("--config", required=True, help="External JSON with management, journal, and Prefect settings.")
    parser.add_argument("--check", action="store_true", help="Validate configuration without constructing clients or dispatching.")
    args = parser.parse_args(argv)
    config = load_executor_config(args.config)
    if args.check:
        print(f"executor configuration validated for deployment {config.deployment_id}")
        return 0
    from .management_service import build_live_project_admission, build_live_project_validator, build_project_configuration_validator, load_service_config

    service_config = load_service_config(config.management_config)
    from .hardware_registry import HardwareRegistry
    from .provider_registry import ProviderRegistry
    from .resource_grants import ResourceGrants

    hardware = HardwareRegistry(service_config.databases.hardware, stale_after_seconds=service_config.hardware_stale_after_seconds)
    providers = ProviderRegistry(service_config.databases.providers, hardware)
    grants = ResourceGrants(service_config.databases.grants, max_capacity_age_seconds=service_config.grant_capacity_age_seconds)
    admission = build_live_project_admission(grants, providers)
    validator = build_live_project_validator(grants, providers)
    projects = ProjectControl(service_config.databases.projects, validate_project=validator, validate_configuration=build_project_configuration_validator(grants, providers), project_admission=admission)
    with _explicit_sync_prefect_client(config) as client:
        result = ManagementProjectExecutor(config, projects, validator, client).tick()
    print(json.dumps(result, separators=(",", ":"), allow_nan=False))
    return 0


def _explicit_sync_prefect_client(config: ManagementExecutorConfig, *, client_type: Callable[..., Any] | None = None, server_type: Any = None, timeout_factory: Callable[[float], Any] | None = None) -> Any:
    """Construct Prefect's sync client without ambient proxy, TLS, or timeout settings."""
    if client_type is None or server_type is None or timeout_factory is None:
        from prefect.client.orchestration import ServerType, SyncPrefectClient
        import httpx

        client_type = SyncPrefectClient
        server_type = ServerType.SERVER
        timeout_factory = httpx.Timeout
    return client_type(
        api=config.prefect_url,
        api_key=config.prefect_api_key,
        server_type=server_type,
        httpx_settings={
            "verify": ssl.create_default_context(),
            "trust_env": False,
            "follow_redirects": False,
            "timeout": timeout_factory(10.0),
        },
    )


if __name__ == "__main__":
    main()
