"""Durable role-instance registry and logical capability bindings.

This pure control-plane core has no HTTP server, process control, scheduling, or
physical lifecycle effects. Authentication is supplied by the caller identity
argument; a transport must authenticate that identity before calling this API.
"""
from __future__ import annotations

import json
import ipaddress
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterator, Mapping
from urllib.parse import urlparse

from .hardware_registry import HardwareRegistry
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


class ProviderRegistryError(ValueError):
    pass


Clock = Callable[[], datetime]
ROLES = {"management", "agent-runtime", "inference", "storage"}
HEALTH = {"healthy", "unhealthy", "unknown", "draining"}


def _time(value: str) -> datetime:
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, ValueError) as error:
        raise ProviderRegistryError("timestamp must be RFC3339 with timezone") from error
    if result.tzinfo is None:
        raise ProviderRegistryError("timestamp must include timezone")
    return result.astimezone(timezone.utc)


def _text(value: datetime) -> str:
    if value.tzinfo is None:
        raise ProviderRegistryError("clock must return a timezone-aware datetime")
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


class ProviderRegistry:
    def __init__(self, database: str | Path, hardware: HardwareRegistry, *, clock: Clock | None = None, default_lease_seconds: int = 60, max_lease_seconds: int = 300):
        database_path = Path(database)
        try:
            state_root = validate_state_root(database_path.parent, "provider registry state root")
            self.database = validate_durable_leaf(database_path, state_root, label="provider registry database")
        except ManagementStateBoundaryError as error:
            raise ProviderRegistryError(str(error)) from error
        if not self._strict_positive_int(default_lease_seconds) or not self._strict_positive_int(max_lease_seconds) or default_lease_seconds > max_lease_seconds:
            raise ProviderRegistryError("lease configuration must be bounded positive integers")
        self.hardware, self.clock, self.default_lease_seconds, self.max_lease_seconds = hardware, clock or (lambda: datetime.now(timezone.utc)), default_lease_seconds, max_lease_seconds
        self._initialize()

    def register(self, caller_provider_id: str, manifest: Mapping[str, Any], *, expected_generation: int | None = None) -> dict[str, Any]:
        if not isinstance(manifest, Mapping) or manifest.get("provider_id") != caller_provider_id:
            raise ProviderRegistryError("caller_provider_id must match manifest provider_id")
        if expected_generation is not None and not self._strict_positive_int(expected_generation):
            raise ProviderRegistryError("expected_generation must be a positive integer")
        self._validate_manifest(manifest)
        node_id = manifest["hardware_node_id"]
        if self.hardware.get_snapshot(node_id) is None:
            raise ProviderRegistryError("provider hardware node must be registered")
        canonical = json.dumps(dict(manifest), sort_keys=True, separators=(",", ":"))
        now = _text(self.clock())
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT manifest,generation,revoked FROM role_instances WHERE provider_id=?", (caller_provider_id,)).fetchone()
            if row is None:
                if expected_generation is not None:
                    raise ProviderRegistryError("new provider cannot supply expected_generation")
                connection.execute("INSERT INTO role_instances(provider_id,hardware_node_id,role,manifest,generation,revoked,created_at,updated_at) VALUES(?,?,?,?,1,0,?,?)", (caller_provider_id, node_id, manifest["role"], canonical, now, now))
            else:
                old = json.loads(row["manifest"])
                if row["revoked"]:
                    raise ProviderRegistryError("revoked provider identity cannot be reactivated")
                if any(old[name] != manifest[name] for name in ("provider_id", "hardware_node_id", "role")):
                    raise ProviderRegistryError("provider identity, hardware node, and role are immutable")
                if expected_generation is not None and expected_generation != row["generation"]:
                    raise ProviderRegistryError("provider generation is stale")
                if canonical != row["manifest"]:
                    if expected_generation is None:
                        raise ProviderRegistryError("provider update requires expected_generation")
                    self._clear_expired_reservations(connection)
                    if connection.execute("SELECT 1 FROM provider_generation_reservations WHERE provider_id=? AND generation=?", (caller_provider_id, row["generation"])).fetchone() is not None:
                        raise ProviderRegistryError("provider generation is reserved")
                    connection.execute("UPDATE role_instances SET manifest=?,generation=generation+1,updated_at=? WHERE provider_id=?", (canonical, now, caller_provider_id))
        return self.get(caller_provider_id)  # type: ignore[return-value]

    def observe_health(self, caller_provider_id: str, status: str, observed_at: str, *, expected_generation: int, host_boot_id: str, lease_seconds: int | None = None, readiness: Mapping[str, Any] | None = None) -> dict[str, Any]:
        if status not in HEALTH or not self._strict_positive_int(expected_generation) or not isinstance(host_boot_id, str) or not host_boot_id:
            raise ProviderRegistryError("health status and expected_generation are invalid")
        duration = self.default_lease_seconds if lease_seconds is None else lease_seconds
        if not self._strict_positive_int(duration) or duration > self.max_lease_seconds:
            raise ProviderRegistryError("lease_seconds must be a bounded positive integer")
        observed = _time(observed_at)
        readiness_record = self._validate_readiness(readiness, status=status)
        now = self.clock().astimezone(timezone.utc)
        if observed > now:
            raise ProviderRegistryError("future health observation is rejected")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT generation,revoked,hardware_node_id FROM role_instances WHERE provider_id=?", (caller_provider_id,)).fetchone()
            if row is None:
                raise ProviderRegistryError("unknown provider")
            if row["revoked"] or row["generation"] != expected_generation:
                raise ProviderRegistryError("provider generation is stale or revoked")
            previous = connection.execute("SELECT observed_at FROM role_health WHERE provider_id=?", (caller_provider_id,)).fetchone()
            if previous and observed <= _time(previous["observed_at"]):
                raise ProviderRegistryError("health observation is stale or duplicate")
            node = self.hardware.get_snapshot(row["hardware_node_id"])
            if node is None:
                raise ProviderRegistryError("provider hardware node is no longer registered")
            boot_id = node["registration"]["node_identity"]["host_boot_id"]
            if host_boot_id != boot_id or host_boot_id != json.loads(connection.execute("SELECT manifest FROM role_instances WHERE provider_id=?", (caller_provider_id,)).fetchone()["manifest"])["host_boot_id"]:
                raise ProviderRegistryError("health host_boot_id must match current registered hardware and provider manifest")
            connection.execute("INSERT INTO role_health(provider_id,provider_generation,hardware_boot_id,status,observed_at,lease_expires_at,readiness_json) VALUES(?,?,?,?,?,?,?) ON CONFLICT(provider_id) DO UPDATE SET provider_generation=excluded.provider_generation,hardware_boot_id=excluded.hardware_boot_id,status=excluded.status,observed_at=excluded.observed_at,lease_expires_at=excluded.lease_expires_at,readiness_json=excluded.readiness_json", (caller_provider_id, expected_generation, boot_id, status, _text(observed), _text(observed + timedelta(seconds=duration)), json.dumps(readiness_record, sort_keys=True, separators=(",", ":")) if readiness_record is not None else None))
        return self.get(caller_provider_id)  # type: ignore[return-value]

    def revoke(self, caller_provider_id: str, *, expected_generation: int) -> dict[str, Any]:
        if not self._strict_positive_int(expected_generation): raise ProviderRegistryError("expected_generation must be a positive integer")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            self._clear_expired_reservations(connection)
            if connection.execute("SELECT 1 FROM provider_generation_reservations WHERE provider_id=? AND generation=?", (caller_provider_id, expected_generation)).fetchone() is not None:
                raise ProviderRegistryError("provider generation is reserved")
            result = connection.execute("UPDATE role_instances SET revoked=1,generation=generation+1,updated_at=? WHERE provider_id=? AND generation=? AND revoked=0", (_text(self.clock()), caller_provider_id, expected_generation))
            if result.rowcount != 1:
                raise ProviderRegistryError("provider generation is stale or revoked")
        return self.get(caller_provider_id)  # type: ignore[return-value]

    def reserve_generation(self, provider_id: str, generation: int, *, lease_seconds: int | None = None) -> str:
        if not isinstance(provider_id, str) or not provider_id or not self._strict_positive_int(generation):
            raise ProviderRegistryError("provider generation reservation is invalid")
        duration = self.max_lease_seconds if lease_seconds is None else lease_seconds
        if not self._strict_positive_int(duration) or duration > self.max_lease_seconds:
            raise ProviderRegistryError("provider generation reservation lease is invalid")
        reservation_id = uuid.uuid4().hex
        now = self.clock().astimezone(timezone.utc)
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            self._clear_expired_reservations(connection)
            row = connection.execute("SELECT generation,revoked FROM role_instances WHERE provider_id=?", (provider_id,)).fetchone()
            if row is None or row["revoked"] or row["generation"] != generation:
                raise ProviderRegistryError("provider generation is stale or revoked")
            connection.execute("INSERT INTO provider_generation_reservations(provider_id,generation,reservation_id,lease_expires_at) VALUES(?,?,?,?)", (provider_id, generation, reservation_id, _text(now + timedelta(seconds=duration))))
        return reservation_id

    def release_generation(self, reservation_id: str) -> None:
        if not isinstance(reservation_id, str) or not reservation_id:
            raise ProviderRegistryError("provider generation reservation is invalid")
        with self._connection() as connection:
            connection.execute("DELETE FROM provider_generation_reservations WHERE reservation_id=?", (reservation_id,))

    def bind(self, logical_binding: str, capability: str, compatibility_fingerprint: str, *, expected_binding_generation: int | None = None) -> dict[str, Any]:
        """Privileged controller-only binding update; transport auth is external."""
        if not all(isinstance(value, str) and value for value in (logical_binding, capability, compatibility_fingerprint)):
            raise ProviderRegistryError("logical binding, capability, and compatibility fingerprint are required")
        now = _text(self.clock())
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            selected = self._resolve_in_connection(connection, capability, compatibility_fingerprint)
            if selected is None: raise ProviderRegistryError("no eligible compatible provider")
            row = connection.execute("SELECT generation FROM logical_bindings WHERE logical_binding=?", (logical_binding,)).fetchone()
            if row is None:
                if expected_binding_generation is not None:
                    raise ProviderRegistryError("new binding cannot supply expected generation")
                connection.execute("INSERT INTO logical_bindings(logical_binding,capability,compatibility_fingerprint,provider_id,provider_generation,generation,updated_at) VALUES(?,?,?,?,?,1,?)", (logical_binding, capability, compatibility_fingerprint, selected["provider_id"], selected["generation"], now))
            else:
                if expected_binding_generation != row["generation"]:
                    raise ProviderRegistryError("binding generation is stale")
                connection.execute("UPDATE logical_bindings SET capability=?,compatibility_fingerprint=?,provider_id=?,provider_generation=?,generation=generation+1,updated_at=? WHERE logical_binding=?", (capability, compatibility_fingerprint, selected["provider_id"], selected["generation"], now, logical_binding))
        return self.binding(logical_binding)  # type: ignore[return-value]

    def resolve(self, capability: str, compatibility_fingerprint: str) -> dict[str, Any] | None:
        with self._connection() as connection:
            return self._resolve_in_connection(connection, capability, compatibility_fingerprint)

    def _resolve_in_connection(self, connection: sqlite3.Connection, capability: str, compatibility_fingerprint: str) -> dict[str, Any] | None:
        now = self.clock().astimezone(timezone.utc)
        rows = connection.execute("SELECT r.*,h.provider_generation AS health_generation,h.hardware_boot_id,h.status,h.observed_at,h.lease_expires_at,h.readiness_json FROM role_instances r LEFT JOIN role_health h ON h.provider_id=r.provider_id WHERE r.revoked=0 ORDER BY r.provider_id").fetchall()
        for row in rows:
            manifest = json.loads(row["manifest"])
            provider = self._snapshot(row, manifest)
            if (self._composite_row_ready(provider, capability) and capability in manifest["capabilities"] and compatibility_fingerprint == manifest["compatibility_fingerprint"]):
                return provider
        return None

    def binding(self, logical_binding: str) -> dict[str, Any] | None:
        with self._connection() as connection:
            binding = connection.execute("SELECT * FROM logical_bindings WHERE logical_binding=?", (logical_binding,)).fetchone()
        if binding is None:
            return None
        provider = self.get(binding["provider_id"])
        if provider is None or provider["generation"] != binding["provider_generation"] or self.readiness(provider["provider_id"], [binding["capability"]]).get("eligible") is not True:
            return None
        return {**dict(binding), "provider": provider}

    def get(self, provider_id: str) -> dict[str, Any] | None:
        with self._connection() as connection:
            row = connection.execute("SELECT r.*,h.provider_generation AS health_generation,h.hardware_boot_id,h.status,h.observed_at,h.lease_expires_at,h.readiness_json FROM role_instances r LEFT JOIN role_health h ON h.provider_id=r.provider_id WHERE r.provider_id=?", (provider_id,)).fetchone()
        return self._snapshot(row, json.loads(row["manifest"])) if row else None

    def list(self) -> list[dict[str, Any]]:
        """List every registered provider as a non-secret projection."""
        with self._connection() as connection:
            rows = connection.execute("SELECT provider_id FROM role_instances ORDER BY provider_id").fetchall()
        return [provider for row in rows if (provider := self.get(row["provider_id"])) is not None]

    def list_bindings(self) -> list[dict[str, Any]]:
        with self._connection() as connection:
            rows = connection.execute("SELECT logical_binding,capability,compatibility_fingerprint,provider_id,provider_generation,generation,updated_at FROM logical_bindings ORDER BY logical_binding").fetchall()
        return [dict(row) for row in rows]

    def is_eligible(self, provider_id: str) -> bool:
        """Public fail-closed eligibility observation for integration clients."""
        if not isinstance(provider_id, str) or not provider_id:
            return False
        provider = self.get(provider_id)
        return provider is not None and self._eligible(provider)

    def readiness(self, provider_id: str, required_capabilities: list[str] | tuple[str, ...] | None = None) -> dict[str, Any]:
        """Return the public composite readiness decision for one provider."""
        required = list(required_capabilities or [])
        provider = self.get(provider_id) if isinstance(provider_id, str) else None
        if provider is None:
            return {"provider_id": provider_id, "eligible": False, "status": "unavailable", "checks": {"registered_identity": {"ok": False, "reason": "provider_not_registered"}}, "reasons": ["provider_not_registered"], "unavailable_dependency": provider_id}

        manifest = provider.get("manifest", {})
        node = self.hardware.get_snapshot(provider["hardware_node_id"])
        health = provider.get("health")
        identity_ok = (not provider.get("revoked") and node is not None and
                       manifest.get("host_boot_id") == node.get("registration", {}).get("node_identity", {}).get("host_boot_id") and
                       isinstance(health, Mapping) and health.get("provider_generation") == provider.get("generation") and
                       health.get("hardware_boot_id") == manifest.get("host_boot_id"))
        checks: dict[str, Any] = {"registered_identity": {"ok": identity_ok, "provider_id": provider["provider_id"], "generation": provider["generation"], "hardware_node_id": provider["hardware_node_id"]}}
        reasons: list[str] = []
        if not identity_ok:
            reasons.append("registered_identity_unavailable")

        declared = manifest.get("capabilities", []) if isinstance(manifest, Mapping) else []
        capabilities_ok = isinstance(declared, list) and all(capability in declared for capability in required)
        checks["declared_capabilities"] = {"ok": capabilities_ok, "required": required, "declared": declared}
        if not capabilities_ok:
            reasons.append("declared_capabilities_missing")
        role_compatible = isinstance(declared, list) and all(self._capability_role_compatible(provider.get("role"), capability) for capability in declared) and all(self._capability_role_compatible(provider.get("role"), capability) for capability in required)
        checks["capability_roles"] = {"ok": role_compatible, "required": required, "declared": declared, "role": provider.get("role")}
        if not role_compatible:
            reasons.append("capability_role_mismatch")

        evidence = health.get("readiness") if isinstance(health, Mapping) else None
        evidence = evidence if isinstance(evidence, Mapping) else {}
        # Composite readiness is deliberately stricter than the historical
        # ``is_eligible`` compatibility predicate.  A healthy lease alone is
        # not proof that the owner authenticated and its advertised endpoint
        # can actually serve requests.
        authenticated = evidence.get("authenticated")
        reachable = evidence.get("service_reachable")
        auth_ok = authenticated is True
        reachable_ok = reachable is True
        checks["authentication"] = {"ok": auth_ok}
        checks["service_reachability"] = {"ok": reachable_ok, "endpoint": manifest.get("private_endpoint")}
        if not auth_ok:
            reasons.append("authentication_unavailable")
        if not reachable_ok:
            reasons.append("service_unreachable")

        now = self.clock().astimezone(timezone.utc)
        freshness_ok = (isinstance(health, Mapping) and health.get("status") == "healthy" and
                        isinstance(health.get("observed_at"), str) and isinstance(health.get("lease_expires_at"), str) and
                        _time(health["observed_at"]) <= now < _time(health["lease_expires_at"]))
        checks["freshness"] = {"ok": freshness_ok, "observed_at": health.get("observed_at") if isinstance(health, Mapping) else None, "lease_expires_at": health.get("lease_expires_at") if isinstance(health, Mapping) else None}
        if not freshness_ok:
            reasons.append("readiness_stale")
        eligible = not reasons
        return {"provider_id": provider_id, "role": provider.get("role"), "eligible": eligible, "status": "ready" if eligible else "unavailable", "checks": checks, "reasons": reasons, "unavailable_dependency": None if eligible else provider_id}

    def readiness_for_capability(self, capability: str, *, required_capabilities: list[str] | None = None) -> dict[str, Any]:
        """Resolve and report the current owner of a logical capability."""
        binding = next((row for row in self.list_bindings() if row["capability"] == capability), None)
        if binding is None:
            return {"capability": capability, "eligible": False, "status": "unavailable", "reasons": ["binding_not_registered"], "unavailable_dependency": capability}
        provider = self.get(binding["provider_id"])
        if provider is None or provider.get("generation") != binding["provider_generation"]:
            return {"capability": capability, "logical_binding": binding["logical_binding"], "eligible": False, "status": "unavailable", "reasons": ["binding_provider_generation_stale"], "unavailable_dependency": binding["provider_id"]}
        result = self.readiness(binding["provider_id"], required_capabilities=required_capabilities or [capability])
        return {"capability": capability, "logical_binding": binding["logical_binding"], **result}

    def _eligible(self, provider: Mapping[str, Any]) -> bool:
        provider_id = provider.get("provider_id")
        return isinstance(provider_id, str) and self.readiness(provider_id).get("eligible") is True

    def _composite_row_ready(self, provider: Mapping[str, Any], capability: str) -> bool:
        manifest = provider.get("manifest") if isinstance(provider.get("manifest"), Mapping) else {}
        if not self._capability_role_compatible(provider.get("role"), capability):
            return False
        health = provider.get("health")
        node = self.hardware.get_snapshot(provider.get("hardware_node_id"))
        if provider.get("revoked") or node is None or manifest.get("host_boot_id") != node.get("registration", {}).get("node_identity", {}).get("host_boot_id"):
            return False
        if not isinstance(health, Mapping) or health.get("provider_generation") != provider.get("generation") or health.get("hardware_boot_id") != manifest.get("host_boot_id") or health.get("status") != "healthy":
            return False
        evidence = health.get("readiness")
        if not isinstance(evidence, Mapping) or evidence.get("authenticated") is not True or evidence.get("service_reachable") is not True:
            return False
        try:
            now = self.clock().astimezone(timezone.utc)
            return _time(health["observed_at"]) <= now < _time(health["lease_expires_at"]) and capability in manifest.get("capabilities", [])
        except (KeyError, TypeError, ProviderRegistryError):
            return False

    @staticmethod
    def _capability_role_compatible(role: Any, capability: Any) -> bool:
        if not isinstance(role, str) or not isinstance(capability, str):
            return False
        family = capability.split(".", 1)[0]
        expected = {"inference": "inference", "storage": "storage", "runtime": "agent-runtime", "management": "management"}.get(family)
        return expected is None or role == expected

    def _eligible_row(self, row: sqlite3.Row, now: datetime) -> bool:
        if row["status"] != "healthy" or row["health_generation"] != row["generation"] or _time(row["observed_at"]) > now or _time(row["lease_expires_at"]) <= now: return False
        node = self.hardware.get_snapshot(row["hardware_node_id"])
        return node is not None and row["hardware_boot_id"] == node["registration"]["node_identity"]["host_boot_id"]

    @staticmethod
    def _snapshot(row: sqlite3.Row, manifest: dict[str, Any]) -> dict[str, Any]:
        readiness = None
        if row["status"] is not None and "readiness_json" in row.keys() and row["readiness_json"]:
            try:
                candidate = json.loads(row["readiness_json"])
                readiness = candidate if isinstance(candidate, dict) else None
            except (TypeError, json.JSONDecodeError):
                readiness = None
        health = None if row["status"] is None else {"provider_generation": row["health_generation"], "hardware_boot_id": row["hardware_boot_id"], "status": row["status"], "observed_at": row["observed_at"], "lease_expires_at": row["lease_expires_at"], "readiness": readiness}
        return {"provider_id": row["provider_id"], "hardware_node_id": row["hardware_node_id"], "role": row["role"], "generation": row["generation"], "revoked": bool(row["revoked"]), "manifest": manifest, "health": health}

    def _validate_manifest(self, manifest: Mapping[str, Any]) -> None:
        if not all(isinstance(manifest.get(name), str) and manifest[name] for name in ("provider_id", "hardware_node_id", "host_boot_id", "build_digest", "configuration_hash", "compatibility_fingerprint")):
            raise ProviderRegistryError("provider identity and provenance fields are required")
        if manifest.get("role") not in ROLES:
            raise ProviderRegistryError("role must be one of the four registered roles")
        capabilities = manifest.get("capabilities")
        if not isinstance(capabilities, list) or not capabilities or not all(isinstance(item, str) and item for item in capabilities):
            raise ProviderRegistryError("capabilities must be a non-empty string list")
        endpoint = manifest.get("private_endpoint")
        parsed = urlparse(endpoint if isinstance(endpoint, str) else "")
        loopback_http = parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "::1"}
        if (parsed.scheme not in {"https", "grpcs"} and not loopback_http) or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or (not loopback_http and not self._private_host(parsed.hostname)):
            raise ProviderRegistryError("private_endpoint must be an authenticated private https/grpcs URI")
        node = self.hardware.get_snapshot(manifest["hardware_node_id"])
        if node is not None and manifest["host_boot_id"] != node["registration"]["node_identity"]["host_boot_id"]:
            raise ProviderRegistryError("provider host_boot_id must match current registered hardware")

    @staticmethod
    def _private_host(host: str) -> bool:
        try:
            address = ipaddress.ip_address(host)
            return address.is_private or address.is_loopback or address in ipaddress.ip_network("100.64.0.0/10")
        except ValueError:
            lowered = host.lower().rstrip(".")
            return "." not in lowered or lowered.endswith((".internal", ".local", ".ts.net"))

    @staticmethod
    def _strict_positive_int(value: Any) -> bool:
        return isinstance(value, int) and not isinstance(value, bool) and value > 0

    @staticmethod
    def _validate_readiness(value: Mapping[str, Any] | None, *, status: str) -> dict[str, Any] | None:
        if value is None:
            return None
        if not isinstance(value, Mapping) or set(value) - {"authenticated", "service_reachable", "checked_at", "endpoint"}:
            raise ProviderRegistryError("readiness evidence is invalid")
        for field in ("authenticated", "service_reachable"):
            if field in value and type(value[field]) is not bool:
                raise ProviderRegistryError("readiness evidence is invalid")
        for field in ("checked_at", "endpoint"):
            if field in value and (not isinstance(value[field], str) or not value[field]):
                raise ProviderRegistryError("readiness evidence is invalid")
        if status == "healthy" and any(value.get(field) is False for field in ("authenticated", "service_reachable")):
            raise ProviderRegistryError("healthy readiness cannot report an unavailable dependency")
        return dict(value)

    def _initialize(self) -> None:
        with self._connection() as connection:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS role_instances(provider_id TEXT PRIMARY KEY,hardware_node_id TEXT NOT NULL,role TEXT NOT NULL,manifest TEXT NOT NULL,generation INTEGER NOT NULL,revoked INTEGER NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS role_health(provider_id TEXT PRIMARY KEY,provider_generation INTEGER NOT NULL,hardware_boot_id TEXT NOT NULL,status TEXT NOT NULL,observed_at TEXT NOT NULL,lease_expires_at TEXT NOT NULL,readiness_json TEXT);
                CREATE TABLE IF NOT EXISTS logical_bindings(logical_binding TEXT PRIMARY KEY,capability TEXT NOT NULL,compatibility_fingerprint TEXT NOT NULL,provider_id TEXT NOT NULL,provider_generation INTEGER NOT NULL,generation INTEGER NOT NULL,updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS provider_generation_reservations(provider_id TEXT NOT NULL,generation INTEGER NOT NULL,reservation_id TEXT PRIMARY KEY,lease_expires_at TEXT NOT NULL);
            """)
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(role_health)")}
            if "readiness_json" not in columns:
                connection.execute("ALTER TABLE role_health ADD COLUMN readiness_json TEXT")

    def _clear_expired_reservations(self, connection: sqlite3.Connection) -> None:
        connection.execute("DELETE FROM provider_generation_reservations WHERE lease_expires_at<=?", (_text(self.clock().astimezone(timezone.utc)),))

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.database, timeout=10.0)
        connection.row_factory = sqlite3.Row
        try:
            with connection:
                yield connection
        finally:
            connection.close()
