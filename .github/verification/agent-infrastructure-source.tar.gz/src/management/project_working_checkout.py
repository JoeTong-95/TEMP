"""Provider-neutral isolated working checkouts for accepted project bindings."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import hashlib
import os
import re
import shutil
import subprocess
import tempfile
import weakref
from pathlib import Path, PurePosixPath
from typing import Any, Mapping
from urllib.parse import urlsplit


class CheckoutError(ValueError):
    pass


class _GitOperationError(CheckoutError):
    """A Git failure with a safe phase for the public setup receipt."""

    def __init__(self, message: str, *, phase: str, outcome_unknown: bool = False, authentication_failure: bool = False) -> None:
        super().__init__(message)
        self.phase = phase
        self.outcome_unknown = outcome_unknown
        self.authentication_failure = authentication_failure


_SAFE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_COMMIT = re.compile(r"[0-9a-f]{40,64}\Z")
_SAFE_BRANCH = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,199}\Z")
_REPARSE_POINT = 0x400


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _is_reparse_point(path: Path) -> bool:
    if os.name != "nt":
        return False
    try:
        return bool(getattr(path.stat(follow_symlinks=False), "st_file_attributes", 0) & _REPARSE_POINT)
    except (FileNotFoundError, NotADirectoryError):
        return False
    except OSError:
        # A configured boundary must fail closed when Windows cannot tell us
        # whether it is a reparse point. Missing paths are handled above so
        # callers can still create their intended child paths.
        return True


def receipt_attempt_digest(*, project_id: Any, revision: Any, intent_id: Any, repository_url: Any, baseline_ref: Any, credential_selector: Any, checkout_path: Any, publication_branch: Any, phase: Any, error_code: Any, recovery_action: Any = None) -> str:
    """Build a deterministic nonsecret identity for one setup attempt."""
    identity = {
        "project_id": project_id,
        "revision": revision,
        "intent_id": intent_id,
        "repository_url": repository_url,
        "baseline_ref": baseline_ref,
        "credential_selector": credential_selector,
        "checkout_path": checkout_path,
        "publication_branch": publication_branch,
        "phase": phase,
        "error_code": error_code,
        "recovery_action": recovery_action,
    }
    return hashlib.sha256(_canonical(identity).encode()).hexdigest()[:16]


def _origin(value: str) -> str:
    """Extract an allowlist origin; repository paths are intentionally ignored."""
    parsed = urlsplit(value)
    if parsed.scheme == "file" and not parsed.username and not parsed.password and not parsed.query and not parsed.fragment:
        return "file://"
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise CheckoutError("repository URL origin is invalid")
    try:
        port = parsed.port
    except ValueError as error:
        raise CheckoutError("repository URL origin is invalid") from error
    return f"{parsed.scheme}://{parsed.hostname.lower()}" + (f":{port}" if port else "")


def _github_repository_identity(value: Any) -> tuple[str, str] | None:
    """Return the case-insensitive GitHub owner/repository identity.

    Receipts may predate URL canonicalization, and Git accepts both HTTPS and
    SSH spellings for the same repository.  Only the two standard GitHub
    transports are accepted here; arbitrary hosts, ports, credentials, and
    paths are never treated as equivalent.
    """
    if not isinstance(value, str) or not value:
        return None
    parsed = urlsplit(value)
    path: str | None = None
    if parsed.scheme == "https":
        if parsed.hostname is None or parsed.hostname.casefold() != "github.com" or parsed.username or parsed.password or parsed.query or parsed.fragment:
            return None
        try:
            port = parsed.port
        except ValueError:
            return None
        if port not in {None, 443}:
            return None
        path = parsed.path
    else:
        return None
    parts = (path or "").strip("/").split("/")
    if len(parts) != 2 or any(not part for part in parts):
        return None
    owner, repository = parts
    if repository.casefold().endswith(".git"):
        repository = repository[:-4]
    if _SAFE_ID.fullmatch(owner) is None or _SAFE_ID.fullmatch(repository) is None:
        return None
    return owner.casefold(), repository.casefold()


def _repository_urls_match(actual: Any, expected: Any) -> bool:
    if actual == expected:
        return True
    actual_identity = _github_repository_identity(actual)
    expected_identity = _github_repository_identity(expected)
    return actual_identity is not None and actual_identity == expected_identity


def _safe_directory(path: Path, label: str) -> None:
    if not path.is_absolute() or path.is_symlink() or _is_reparse_point(path) or not path.is_dir() or any(parent.is_symlink() or _is_reparse_point(parent) for parent in path.parents):
        raise CheckoutError(f"{label} is unsafe")


def _ensure_directory(path: Path, label: str) -> None:
    """Create a configured directory without crossing a symlink boundary."""
    if not path.is_absolute() or path.is_symlink() or _is_reparse_point(path) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in path.parents):
        raise CheckoutError(f"{label} is unsafe")
    if path.exists() and not path.is_dir():
        raise CheckoutError(f"{label} is unsafe")
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        raise CheckoutError(f"{label} could not be created") from error
    _safe_directory(path, label)


def _validate_git_metadata(destination: Path, *, allow_missing_head: bool = False, allow_missing_index: bool = False) -> Path:
    """Require ordinary in-checkout Git metadata before invoking Git."""
    dotgit = destination / ".git"
    if dotgit.is_symlink() or _is_reparse_point(dotgit) or not dotgit.is_dir():
        raise CheckoutError("working checkout has no safe Git metadata")
    try:
        destination_root = destination.resolve(strict=True)
        git_root = dotgit.resolve(strict=True)
        git_root.relative_to(destination_root)
        if git_root == destination_root:
            raise ValueError("Git metadata points at the checkout root")
    except (OSError, RuntimeError, ValueError) as error:
        raise CheckoutError("working checkout Git metadata escapes the checkout") from error
    for name, required in (("HEAD", not allow_missing_head), ("config", True), ("index", not allow_missing_index)):
        path = dotgit / name
        if path.is_symlink() or _is_reparse_point(path):
            raise CheckoutError(f"working checkout Git {name} is unsafe")
        if path.exists() and not path.is_file():
            raise CheckoutError(f"working checkout Git {name} is unsafe")
        if required and not path.is_file():
            raise CheckoutError(f"working checkout Git {name} is missing")
        if path.exists():
            try:
                path.resolve(strict=True).relative_to(git_root)
            except (OSError, RuntimeError, ValueError) as error:
                raise CheckoutError(f"working checkout Git {name} escapes metadata") from error
    worktree_config = dotgit / "config.worktree"
    if worktree_config.exists() or worktree_config.is_symlink() or _is_reparse_point(worktree_config):
        raise CheckoutError("working checkout Git worktree config is unsafe")
    for redirect in (dotgit / "commondir", dotgit / "objects" / "info" / "alternates", dotgit / "objects" / "info" / "http-alternates"):
        if redirect.exists() or redirect.is_symlink() or _is_reparse_point(redirect):
            raise CheckoutError("working checkout Git metadata redirect is unsafe")
    for root, directories, files in os.walk(dotgit, followlinks=False):
        for name in [*directories, *files]:
            entry = Path(root) / name
            if entry.is_symlink() or _is_reparse_point(entry):
                raise CheckoutError("working checkout Git metadata contains an unsafe link")
            try:
                entry.resolve(strict=True).relative_to(git_root)
            except (OSError, RuntimeError, ValueError) as error:
                raise CheckoutError("working checkout Git metadata escapes metadata") from error
    hooks = dotgit / "hooks"
    if hooks.exists() and (hooks.is_symlink() or _is_reparse_point(hooks) or not hooks.is_dir()):
        raise CheckoutError("working checkout Git hooks path is unsafe")
    if hooks.is_dir():
        try:
            hooks.resolve(strict=True).relative_to(git_root)
        except (OSError, RuntimeError, ValueError) as error:
            raise CheckoutError("working checkout Git hooks path is unsafe") from error
        for entry in hooks.iterdir():
            if entry.is_symlink() or _is_reparse_point(entry):
                raise CheckoutError("working checkout Git hooks path is unsafe")
    try:
        config_lines = (dotgit / "config").read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        raise CheckoutError("working checkout Git config is unavailable") from error
    section = ""
    for line in config_lines:
        stripped = line.strip().casefold()
        if stripped.startswith("[") and stripped.endswith("]"):
            section = stripped[1:-1].strip()
            continue
        if "=" not in stripped:
            continue
        key, _value = (part.strip() for part in stripped.split("=", 1))
        if key in {"pushurl", "insteadof", "pushinsteadof", "worktreeconfig", "hookspath", "sshcommand", "fsmonitor", "gitproxy", "worktree", "gitdir", "index", "askpass", "helper", "uploadpack", "receivepack", "proxy", "external", "textconv", "driver", "clean", "smudge", "process", "gpgprogram", "program", "gpgsign", "commitsign", "commitgpgsign", "taggpgsign", "signingkey"} or section.startswith(("url ", "filter ", "diff ", "merge ", "alias ", "include", "gpg ")):
            raise CheckoutError("working checkout Git config contains an unsafe path or remote")
    return dotgit


def resolve_prd_reference(project_document_root: Path, prd_reference: str, max_bytes: int = 512 * 1024) -> tuple[Path, bytes]:
    """Resolve one accepted Management PRD without allowing path escape or links."""
    if not isinstance(project_document_root, Path) or not project_document_root.is_absolute():
        raise CheckoutError("project document root is unsafe")
    _safe_directory(project_document_root, "project document root")
    if not isinstance(prd_reference, str) or "\\" in prd_reference:
        raise CheckoutError("PRD reference is invalid")
    parts = PurePosixPath(prd_reference).parts
    if not parts or PurePosixPath(prd_reference).is_absolute() or any(part in {"", ".", ".."} for part in parts) or any(part == "" for part in prd_reference.split("/")) or not prd_reference.lower().endswith((".md", ".markdown")):
        raise CheckoutError("PRD reference is invalid")
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or not 1 <= max_bytes <= 1024 * 1024:
        raise CheckoutError("PRD size limit is invalid")
    candidate = project_document_root.joinpath(*parts)
    if candidate.is_symlink() or _is_reparse_point(candidate) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in candidate.parents):
        raise CheckoutError("PRD reference is unsafe")
    try:
        resolved = candidate.resolve(strict=True)
    except OSError as error:
        raise CheckoutError("PRD reference is unavailable") from error
    try:
        resolved.relative_to(project_document_root.resolve(strict=True))
    except ValueError as error:
        raise CheckoutError("PRD reference escapes the document root") from error
    if not resolved.is_file() or resolved.is_symlink() or _is_reparse_point(resolved):
        raise CheckoutError("PRD reference must be a regular file")
    try:
        if resolved.stat().st_size > max_bytes:
            raise CheckoutError("PRD exceeds the configured size limit")
        content = resolved.read_bytes()
    except OSError as error:
        raise CheckoutError("PRD reference is unavailable") from error
    return Path(*parts), content


@dataclass(frozen=True)
class WorkingCheckoutRequest:
    project_id: str
    revision: int
    intent_id: str
    repository_url: str
    working_root: Path
    receipt_file: Path
    allowed_origins: tuple[str, ...] = ("https://github.com",)
    prd_reference: str | None = None
    project_document_root: Path | None = None
    max_prd_bytes: int = 512 * 1024
    # A setup branch is deliberately explicit at the public deployment seam.
    # ``None`` retains the historical file-url test fixture behaviour; attended
    # deployments always supply the reviewed branch through github_project_deploy.
    publication_branch: str | None = None
    baseline_ref: str | None = None
    credential_selector: str | None = None

    def __post_init__(self) -> None:
        for name in ("project_id", "intent_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or _SAFE_ID.fullmatch(value) is None:
                raise CheckoutError(f"{name} is invalid")
        if type(self.revision) is not int or self.revision < 1:
            raise CheckoutError("revision is invalid")
        if not isinstance(self.repository_url, str) or not self.repository_url:
            raise CheckoutError("repository URL is invalid")
        if not isinstance(self.working_root, Path) or not isinstance(self.receipt_file, Path):
            raise CheckoutError("checkout paths are invalid")
        if not isinstance(self.allowed_origins, tuple) or not self.allowed_origins:
            raise CheckoutError("allowed repository origins are required")
        object.__setattr__(self, "allowed_origins", tuple(_origin(item) for item in self.allowed_origins))
        if (self.prd_reference is None) != (self.project_document_root is None):
            raise CheckoutError("PRD reference and document root must be supplied together")
        if self.project_document_root is not None and (not isinstance(self.project_document_root, Path) or not self.project_document_root.is_absolute()):
            raise CheckoutError("project document root is unsafe")
        if isinstance(self.max_prd_bytes, bool) or not isinstance(self.max_prd_bytes, int) or not 1 <= self.max_prd_bytes <= 1024 * 1024:
            raise CheckoutError("PRD size limit is invalid")
        if self.publication_branch is not None:
            if not isinstance(self.publication_branch, str) or _SAFE_BRANCH.fullmatch(self.publication_branch) is None or ".." in self.publication_branch or "//" in self.publication_branch:
                raise CheckoutError("publication branch is invalid")
        if self.baseline_ref is not None and (_COMMIT.fullmatch(self.baseline_ref) is None):
            raise CheckoutError("baseline_ref must be an immutable commit")
        if self.credential_selector is not None and (not isinstance(self.credential_selector, str) or _SAFE_ID.fullmatch(self.credential_selector) is None):
            raise CheckoutError("credential selector is invalid")


class ProjectWorkingCheckout:
    """Clone, initialize, and receipt one project checkout."""

    def __init__(self, *, git_binary: str = "git", credential_helper: str | None = None, credential_environment: Mapping[str, str] | None = None, allow_file_url_for_test: bool = False, timeout_seconds: float = 120.0):
        if not isinstance(git_binary, str) or not git_binary or any(char in git_binary for char in "\r\n"):
            raise CheckoutError("git binary is invalid")
        if credential_helper is not None and (not isinstance(credential_helper, str) or not credential_helper or len(credential_helper) > 512 or any(char in credential_helper for char in "\r\n")):
            raise CheckoutError("credential helper is invalid")
        if credential_environment is not None and (not isinstance(credential_environment, Mapping) or any(key != "AGENT_STACK_FORGE_TOKEN_FILE" or not isinstance(value, str) or "\r" in value or "\n" in value for key, value in credential_environment.items())):
            raise CheckoutError("credential environment is invalid")
        if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float)) or not 0 < timeout_seconds <= 600:
            raise CheckoutError("checkout timeout is invalid")
        self.git_binary = git_binary
        self.credential_helper = credential_helper
        self.credential_environment = dict(credential_environment or {})
        self.allow_file_url_for_test = allow_file_url_for_test
        self.timeout_seconds = float(timeout_seconds)
        self._hooks_path = Path(tempfile.mkdtemp(prefix="agent-stack-hooks-"))
        self._hooks_finalizer = weakref.finalize(self, shutil.rmtree, self._hooks_path, True)

    def _validate_url(self, request: WorkingCheckoutRequest) -> None:
        parsed = urlsplit(request.repository_url)
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise CheckoutError("repository URL must not contain credentials or query data")
        if parsed.scheme != "file" and request.publication_branch in {"main", "master"}:
            raise CheckoutError("protected default publication branch is not allowed")
        if parsed.scheme == "file" and self.allow_file_url_for_test:
            if "file://" not in request.allowed_origins:
                raise CheckoutError("repository URL origin is not allowlisted")
            return
        try:
            origin = _origin(request.repository_url)
        except CheckoutError as error:
            raise CheckoutError("repository URL is unsafe") from error
        if origin not in request.allowed_origins:
            raise CheckoutError("repository URL origin is not allowlisted")

    def _publication_branch(self, request: WorkingCheckoutRequest) -> str:
        """Return the branch used for setup publication.

        The file-url path exists only for the historical local unit fixtures.
        Every real attended deployment passes an explicit review branch and
        therefore cannot fall back to a default-branch push.
        """
        if request.publication_branch:
            return request.publication_branch
        parsed = urlsplit(request.repository_url)
        if self.allow_file_url_for_test and parsed.scheme == "file":
            return "main"
        return f"agent-stack/setup/{request.project_id}/r{request.revision}"

    def _remote_default_info(self, request: WorkingCheckoutRequest, destination: Path) -> tuple[str, str] | None:
        try:
            symbolic = self._git(request, destination, "ls-remote", "--symref", "origin", "HEAD")
        except _GitOperationError as error:
            # Do not turn a credential or transport uncertainty at the final
            # authority boundary into a generic "default branch unavailable"
            # result. The public receipt must retain the typed outcome.
            if error.authentication_failure or error.outcome_unknown:
                raise
            return None
        except CheckoutError:
            return None
        branch = None
        head = None
        for line in symbolic.splitlines():
            match = re.fullmatch(r"ref:\s+refs/heads/([^\s]+)\s+HEAD", line.strip())
            if match:
                branch = match.group(1)
            match = re.fullmatch(r"([0-9a-f]{40,64})\s+HEAD", line.strip())
            if match:
                head = match.group(1)
        return (branch, head) if branch is not None and head is not None else None

    def _remote_default_branch(self, request: WorkingCheckoutRequest, destination: Path) -> str | None:
        info = self._remote_default_info(request, destination)
        return None if info is None else info[0]

    def _verify_remote_binding(self, request: WorkingCheckoutRequest, destination: Path) -> None:
        fetch = [line for line in self._git(request, destination, "remote", "get-url", "--all", "origin").splitlines() if line]
        push = [line for line in self._git(request, destination, "remote", "get-url", "--push", "--all", "origin").splitlines() if line]
        if len(fetch) != 1 or len(push) != 1 or not _repository_urls_match(fetch[0], request.repository_url) or not _repository_urls_match(push[0], request.repository_url):
            raise CheckoutError("checkout origin remotes do not match the recorded binding")

    def _reconciliation_receipt_id(self, request: WorkingCheckoutRequest, *, phase: str, error_code: str) -> str:
        return "checkout-" + receipt_attempt_digest(project_id=request.project_id, revision=request.revision, intent_id=request.intent_id, repository_url=request.repository_url, baseline_ref=request.baseline_ref, credential_selector=request.credential_selector, checkout_path=str(self._destination(request)), publication_branch=self._publication_branch(request), phase=phase, error_code=error_code, recovery_action="reconcile_remote_publication")

    def _remote_publication_ref(self, request: WorkingCheckoutRequest, destination: Path) -> str | None:
        branch_ref = f"refs/heads/{self._publication_branch(request)}"
        output = self._git(request, destination, "ls-remote", "origin", branch_ref)
        lines = [line.split() for line in output.splitlines() if line.strip()]
        if not lines:
            return None
        if len(lines) != 1 or len(lines[0]) != 2 or lines[0][1] != branch_ref or _COMMIT.fullmatch(lines[0][0]) is None:
            raise CheckoutError("remote publication ref could not be reconciled")
        return lines[0][0]

    def _is_local_setup_commit(self, request: WorkingCheckoutRequest, destination: Path, head: str, baseline: str) -> bool:
        if request.prd_reference is None or self._publication_branch(request) != self._git(request, destination, "branch", "--show-current"):
            return False
        try:
            self._verify_prd(request, destination)
            self._git(request, destination, "merge-base", "--is-ancestor", baseline, head)
            changed = [line for line in self._git(request, destination, "diff", "--name-only", baseline, head, "--").splitlines() if line]
            subject = self._git(request, destination, "log", "-1", "--format=%s", head)
        except CheckoutError:
            return False
        return changed == [request.prd_reference] and subject == f"Initialize accepted PRD for {request.project_id}"

    def _preserved_local_commit_ref(self, request: WorkingCheckoutRequest) -> str:
        return f"refs/agent-stack/recovery/{request.project_id}/r{request.revision}"

    def _preserve_local_commit(self, request: WorkingCheckoutRequest, destination: Path, head: str) -> None:
        """Keep an ordinary interrupted operator commit reachable across retry."""
        recovery_ref = self._preserved_local_commit_ref(request)
        try:
            existing = self._git(request, destination, "rev-parse", "--verify", f"{recovery_ref}^{{commit}}")
        except CheckoutError:
            existing = None
        if existing is not None:
            if existing != head:
                raise CheckoutError("partial checkout local recovery ref diverged")
            return
        self._git(request, destination, "update-ref", recovery_ref, head)
        try:
            preserved = self._git(request, destination, "rev-parse", "--verify", f"{recovery_ref}^{{commit}}")
        except CheckoutError as error:
            raise CheckoutError("partial checkout local recovery ref could not be verified") from error
        if preserved != head:
            raise CheckoutError("partial checkout local recovery ref diverged")

    def _assert_publication_branch(self, request: WorkingCheckoutRequest, destination: Path) -> None:
        remote_default = self._remote_default_branch(request, destination)
        parsed = urlsplit(request.repository_url)
        legacy_file = self.allow_file_url_for_test and parsed.scheme == "file" and request.baseline_ref is None
        if remote_default is None and not legacy_file:
            raise CheckoutError("remote default branch could not be verified")
        if remote_default == self._publication_branch(request) and not legacy_file:
            raise CheckoutError("publication branch must differ from the remote default branch")

    @staticmethod
    def _destination(request: WorkingCheckoutRequest) -> Path:
        _safe_directory(request.working_root, "working root")
        destination = request.working_root / request.project_id
        if destination.is_symlink() or _is_reparse_point(destination) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in destination.parents):
            raise CheckoutError("working checkout path is unsafe")
        return destination

    def _receipt_matches(self, path: Path, request: WorkingCheckoutRequest, destination: Path) -> dict[str, Any] | None:
        if not path.exists():
            return None
        if path.is_symlink() or _is_reparse_point(path) or not path.is_file():
            raise CheckoutError("ready receipt path is unsafe")
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise CheckoutError("ready receipt is invalid") from error
        expected = {"schema", "project_id", "revision", "intent_id", "repository_url", "checkout_path", "head", "created_at", "publication_branch", "publication_state", "baseline_ref", "credential_selector"}
        if not isinstance(value, Mapping) or set(value) != expected or value.get("schema") != "agent-stack.working-checkout-ready.v1" or value.get("publication_state") != "ready_for_review":
            # A failed attempt is durable evidence, but it is also an explicit
            # invitation to retry.  It must never be mistaken for readiness.
            if isinstance(value, Mapping) and value.get("schema") == "agent-stack.working-checkout-status.v1":
                failure_keys = {"schema", "state", "project_id", "revision", "intent_id", "repository_url", "checkout_path", "publication_branch", "baseline_ref", "credential_selector", "phase", "error_code", "created_at"}
                allowed_failure_keys = (failure_keys, failure_keys | {"recovery_action"}, failure_keys | {"reconciliation_receipt_id"}, failure_keys | {"recovery_action", "reconciliation_receipt_id"})
                if set(value) not in allowed_failure_keys or any(value.get(key) != expected_value for key, expected_value in (("project_id", request.project_id), ("revision", request.revision), ("intent_id", request.intent_id), ("checkout_path", str(destination)), ("publication_branch", self._publication_branch(request)), ("baseline_ref", request.baseline_ref), ("credential_selector", request.credential_selector))) or not _repository_urls_match(value.get("repository_url"), request.repository_url):
                    raise CheckoutError("ready receipt does not match the requested binding")
                return None
            raise CheckoutError("ready receipt is invalid")
        if any(value.get(key) != expected_value for key, expected_value in (("project_id", request.project_id), ("revision", request.revision), ("intent_id", request.intent_id), ("checkout_path", str(destination)), ("publication_branch", self._publication_branch(request)), ("baseline_ref", request.baseline_ref), ("credential_selector", request.credential_selector))) or not _repository_urls_match(value.get("repository_url"), request.repository_url):
            raise CheckoutError("ready receipt does not match the requested binding")
        head = value.get("head")
        if not isinstance(head, str) or _COMMIT.fullmatch(head) is None or not isinstance(value.get("created_at"), str):
            raise CheckoutError("ready receipt is invalid")
        if not destination.is_dir() or destination.is_symlink() or _is_reparse_point(destination):
            raise CheckoutError("ready receipt points to a missing checkout")
        self._verify_checkout(request, destination, expected_head=head)
        self._verify_prd(request, destination)
        receipt = dict(value)
        if receipt["repository_url"] != request.repository_url:
            # The checkout and its origin were verified above before changing
            # the durable receipt to the current canonical binding spelling.
            receipt["repository_url"] = request.repository_url
            self._write_receipt(request, receipt, replace=True)
        return receipt

    def _git(self, request: WorkingCheckoutRequest, cwd: Path, *args: str) -> str:
        env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_") and not key.startswith("SSH_")}
        env.update({"GIT_TERMINAL_PROMPT": "0", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull, "GIT_ASKPASS": "NUL" if os.name == "nt" else "/bin/false"})
        env.update(self.credential_environment)
        command = [self.git_binary]
        command.extend(["-c", "credential.helper="])
        if self.credential_helper is not None:
            command.extend(["-c", f"credential.helper={self.credential_helper}"])
        command.extend(["-c", f"core.hooksPath={self._hooks_path}", "-c", "core.fsmonitor=false", "-c", "commit.gpgSign=false", "-c", "tag.gpgSign=false"])
        phase = "publication" if args and args[0] == "push" else "authentication" if args and args[0] in {"clone", "fetch", "pull", "ls-remote"} else "checkout"
        try:
            result = subprocess.run([*command, *args], cwd=cwd, env=env, capture_output=True, text=True, timeout=self.timeout_seconds, check=False)
        except (OSError, subprocess.TimeoutExpired) as error:
            raise _GitOperationError("controlled git checkout outcome is unknown", phase=phase, outcome_unknown=True) from error
        if result.returncode:
            # A rejected credential is a known failure.  A generic push error
            # remains retry-required because the remote may have accepted the
            # ref before the client observed the failure.
            # Git may echo remote diagnostics, so inspect only a small bounded
            # lower-cased slice and persist only a fixed classification.
            detail = (result.stderr or "")[:4096].lower()
            auth_markers = ("authentication", "permission denied", "could not read username", "http 401", "http 403", "401 unauthorized", "403 forbidden", "access denied", "invalid username or password")
            permission_to_denied = re.search(r"permission\s+to\s+.{0,512}\s+denied", detail) is not None
            bounded_http_error = re.search(r"requested\s+url\s+returned\s+error:\s*(?:http\s*)?(?:401|403)\b", detail) is not None
            if phase in {"authentication", "publication"} and (any(marker in detail for marker in auth_markers) or permission_to_denied or bounded_http_error):
                raise _GitOperationError("controlled git authentication failed", phase="authentication", authentication_failure=True)
            raise _GitOperationError("controlled git checkout failed", phase=phase, outcome_unknown=phase == "publication")
        return result.stdout.strip()

    def _verify_checkout(self, request: WorkingCheckoutRequest, destination: Path, *, expected_head: str | None = None) -> str:
        _validate_git_metadata(destination)
        self._verify_remote_binding(request, destination)
        branch = self._git(request, destination, "branch", "--show-current")
        if branch != self._publication_branch(request):
            raise CheckoutError("checkout branch does not match the reviewed publication branch")
        self._verify_baseline(request, destination)
        head = self._git(request, destination, "rev-parse", "HEAD")
        if _COMMIT.fullmatch(head) is None or (expected_head is not None and head != expected_head):
            raise CheckoutError("checkout HEAD does not match the ready receipt")
        return head

    def _verify_baseline(self, request: WorkingCheckoutRequest, destination: Path) -> str | None:
        """Resolve the reviewed baseline as an actual commit object."""
        if request.baseline_ref is None:
            return None
        try:
            resolved = self._git(request, destination, "rev-parse", "--verify", f"{request.baseline_ref}^{{commit}}")
        except CheckoutError as error:
            raise CheckoutError("checkout does not contain the immutable baseline") from error
        if resolved != request.baseline_ref:
            raise CheckoutError("checkout does not contain the immutable baseline")
        return resolved

    def _ensure_publication_branch(self, request: WorkingCheckoutRequest, destination: Path, *, anchor_baseline: bool = False) -> None:
        _validate_git_metadata(destination)
        branch = self._publication_branch(request)
        baseline = self._verify_baseline(request, destination)
        current = self._git(request, destination, "branch", "--show-current")
        if current == branch:
            if anchor_baseline:
                self._assert_publication_branch(request, destination)
                if baseline is not None:
                    head = self._git(request, destination, "rev-parse", "HEAD")
                    if head != baseline:
                        raise CheckoutError("fresh checkout publication branch is not anchored to the immutable baseline")
            return
        # ``switch -c`` only creates a name at the current commit and leaves
        # dirty files and local commits untouched.  Switching to an existing
        # branch is allowed only when Git itself can preserve those changes.
        if anchor_baseline and baseline is not None:
            self._git(request, destination, "switch", "-c", branch, baseline)
            return
        try:
            self._git(request, destination, "switch", "-c", branch)
        except CheckoutError:
            self._git(request, destination, "switch", branch)

    def _verify_prd(self, request: WorkingCheckoutRequest, destination: Path) -> None:
        if request.prd_reference is None:
            return
        relative, content = resolve_prd_reference(request.project_document_root, request.prd_reference, request.max_prd_bytes)
        target = destination.joinpath(*relative.parts)
        if target.is_symlink() or _is_reparse_point(target) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in target.parents):
            raise CheckoutError("checkout PRD path is unsafe")
        if not target.is_file() or target.read_bytes() != content:
            raise CheckoutError("checkout PRD does not match the accepted document")

    def _materialize_prd(self, request: WorkingCheckoutRequest, destination: Path) -> None:
        if request.prd_reference is None:
            return
        relative, content = resolve_prd_reference(request.project_document_root, request.prd_reference, request.max_prd_bytes)
        target = destination.joinpath(*relative.parts)
        if target.is_symlink() or _is_reparse_point(target) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in target.parents):
            raise CheckoutError("checkout PRD path is unsafe")
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if not target.is_file() or target.read_bytes() != content:
                raise CheckoutError("checkout PRD path already contains different content")
        else:
            with target.open("xb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())

    def _bootstrap(self, request: WorkingCheckoutRequest, destination: Path) -> None:
        if request.prd_reference is None:
            return
        self._verify_remote_binding(request, destination)
        self._assert_publication_branch(request, destination)
        self._ensure_publication_branch(request, destination)
        self._materialize_prd(request, destination)
        status = self._git(request, destination, "status", "--porcelain", "--untracked-files=all")
        if status:
            self._git(request, destination, "add", "--", request.prd_reference)
            staged_prd = self._git(request, destination, "diff", "--cached", "--name-only", "--", request.prd_reference)
            if staged_prd:
                self._git(request, destination, "-c", "user.name=Agent Infrastructure Bootstrap", "-c", "user.email=agent-stack-bootstrap@localhost", "commit", "--only", "-m", f"Initialize accepted PRD for {request.project_id}", "--", request.prd_reference)
        self._verify_remote_binding(request, destination)
        self._assert_publication_branch(request, destination)
        local_head = self._git(request, destination, "rev-parse", "HEAD")
        remote_head = self._remote_publication_ref(request, destination)
        legacy_file = self.allow_file_url_for_test and urlsplit(request.repository_url).scheme == "file" and request.baseline_ref is None
        if remote_head is not None and remote_head != local_head and not legacy_file and not (
            remote_head == request.baseline_ref
            and request.baseline_ref is not None
            and self._is_local_setup_commit(request, destination, local_head, request.baseline_ref)
        ):
            raise CheckoutError("remote publication ref diverged from the local setup commit")
        self._git(request, destination, "push", "origin", f"HEAD:refs/heads/{self._publication_branch(request)}")

    def _recover_partial_clone(self, request: WorkingCheckoutRequest, destination: Path) -> None:
        """Complete a clone interrupted after Git created its metadata."""
        dotgit = _validate_git_metadata(destination, allow_missing_head=True, allow_missing_index=True)
        head_file = dotgit / "HEAD"
        if head_file.is_symlink() or (head_file.exists() and not head_file.is_file()):
            raise CheckoutError("partial checkout has unsafe Git metadata")
        if head_file.exists():
            self._verify_remote_binding(request, destination)
        if not head_file.exists():
            # Git treats a repository with no HEAD as nonexistent, including
            # for remote and fetch commands. Restore only the symbolic HEAD
            # metadata so the normal, non-destructive recovery can continue.
            try:
                config_file = dotgit / "config"
                if config_file.is_symlink() or not config_file.is_file():
                    raise CheckoutError("partial checkout has unsafe Git metadata")
                configured_remote = self._git(request, destination, "config", "--file", ".git/config", "--get", "remote.origin.url")
                if not _repository_urls_match(configured_remote, request.repository_url):
                    raise CheckoutError("partial checkout origin does not match the recorded binding")
                with head_file.open("x", encoding="ascii", newline="\n") as stream:
                    stream.write(f"ref: refs/heads/{self._publication_branch(request)}\n")
                    stream.flush()
                    os.fsync(stream.fileno())
            except OSError as error:
                raise CheckoutError("partial checkout HEAD could not be restored") from error
        self._verify_remote_binding(request, destination)
        try:
            self._verify_checkout(request, destination)
            if request.baseline_ref is None or self._git(request, destination, "rev-parse", "HEAD") == request.baseline_ref:
                return
        except CheckoutError:
            pass
        self._verify_remote_binding(request, destination)
        baseline = request.baseline_ref
        if baseline is not None:
            try:
                self._verify_baseline(request, destination)
            except CheckoutError:
                # A clone interrupted before its object transfer may have the
                # remote configured but not the reviewed commit. Fetch only
                # the configured origin; never reset or overwrite the tree.
                self._git(request, destination, "fetch", "--no-tags", "origin")
                self._verify_baseline(request, destination)
        current = self._git(request, destination, "branch", "--show-current")
        head = None
        try:
            head = self._git(request, destination, "rev-parse", "--verify", "HEAD^{commit}")
        except CheckoutError:
            pass
        if head is None:
            if baseline is None:
                self._git(request, destination, "fetch", "--no-tags", "origin")
                try:
                    baseline = self._git(request, destination, "rev-parse", "--verify", "origin/HEAD^{commit}")
                except CheckoutError as error:
                    raise CheckoutError("partial checkout has no recoverable baseline") from error
            branch_ref = f"refs/heads/{self._publication_branch(request)}"
            self._verify_remote_binding(request, destination)
            self._assert_publication_branch(request, destination)
            try:
                self._git(request, destination, "rev-parse", "--verify", f"{branch_ref}^{{commit}}")
            except CheckoutError:
                # Recheck the authoritative remote immediately before
                # creating the recovery ref. A cached origin/HEAD or an
                # earlier check must not authorize a local mutation.
                self._verify_remote_binding(request, destination)
                self._assert_publication_branch(request, destination)
                try:
                    self._git(request, destination, "show-ref", "--verify", "--quiet", branch_ref)
                except CheckoutError:
                    self._git(request, destination, "update-ref", branch_ref, baseline)
                else:
                    raise CheckoutError("partial checkout review branch is invalid")
            # symbolic-ref is also a recovery ref mutation; keep the final
            # authority check adjacent to the effect even when update-ref
            # above was not needed.
            self._verify_remote_binding(request, destination)
            self._assert_publication_branch(request, destination)
            self._git(request, destination, "symbolic-ref", "HEAD", branch_ref)
            current = self._publication_branch(request)
            head = baseline
        if not (dotgit / "index").exists():
            index_source = head or baseline
            if index_source is None:
                raise CheckoutError("partial checkout has no recoverable baseline for index reconstruction")
            try:
                # Rebuild only the index from a verified commit.  Omitting
                # ``-u`` leaves operator files and local edits untouched.
                self._git(request, destination, "read-tree", "--reset", index_source)
            except CheckoutError as error:
                raise CheckoutError("partial checkout index could not be reconstructed") from error
            _validate_git_metadata(destination)
        if baseline is not None:
            preserved_local_commit = False
            if head != baseline:
                remote_publication = self._remote_publication_ref(request, destination)
                if remote_publication in {None, head} and self._is_local_setup_commit(request, destination, head, baseline):
                    return
                if remote_publication not in {None, head, baseline}:
                    raise CheckoutError("remote publication ref diverged from the local setup commit")
                remote_info = self._remote_default_info(request, destination)
                remote_default = None if remote_info is None else remote_info[1]
                if remote_default != head:
                    remote_default_branch = None if remote_info is None else remote_info[0]
                    if current == remote_default_branch and not self._is_local_setup_commit(request, destination, head, baseline):
                        self._preserve_local_commit(request, destination, head)
                        preserved_local_commit = True
                    else:
                        raise CheckoutError("partial checkout local commits require reconciliation before anchoring review branch")
            branch = self._publication_branch(request)
            branch_ref = f"refs/heads/{branch}"
            try:
                existing_branch = self._git(request, destination, "rev-parse", "--verify", f"{branch_ref}^{{commit}}")
            except CheckoutError:
                existing_branch = None
            if existing_branch is not None and existing_branch != baseline:
                raise CheckoutError("partial checkout review branch is not anchored to the immutable baseline")
            stash_created = False
            tracked_dirty_paths: tuple[str, ...] = ()
            staged_dirty_paths: tuple[str, ...] = ()
            untracked_dirty_paths: tuple[str, ...] = ()
            if head != baseline:
                dirty = self._git(request, destination, "status", "--porcelain", "--untracked-files=all")
                if dirty:
                    tracked_dirty_paths = tuple(sorted(set(
                        path for output in (
                            self._git(request, destination, "diff", "--name-only", "-z"),
                            self._git(request, destination, "diff", "--cached", "--name-only", "-z"),
                        )
                        for path in output.split("\0") if path
                    )))
                    staged_dirty_paths = tuple(sorted(path for path in self._git(
                        request, destination, "diff", "--cached", "--name-only", "-z"
                    ).split("\0") if path))
                    untracked_dirty_paths = tuple(sorted(path for path in self._git(
                        request, destination, "ls-files", "--others", "--exclude-standard", "-z"
                    ).split("\0") if path))
                    stash_result = self._git(request, destination, "stash", "push", "--include-untracked", "-m", "agent-stack recovery preserve local work")
                    stash_created = "No local changes" not in stash_result
            try:
                self._verify_remote_binding(request, destination)
                self._assert_publication_branch(request, destination)
                if preserved_local_commit:
                    local_paths = set(self._git(request, destination, "diff", "--name-only", baseline, head, "--").splitlines())
                    baseline_paths = set(self._git(request, destination, "ls-tree", "-r", "--name-only", baseline).splitlines())
                    self._git(request, destination, "restore", "--source", baseline, "--staged", "--worktree", "--", ".")
                    for path in sorted(local_paths - baseline_paths):
                        target = destination.joinpath(*PurePosixPath(path).parts)
                        try:
                            target.relative_to(destination)
                        except ValueError as error:
                            raise CheckoutError("partial checkout local commit path is unsafe") from error
                        if target.is_symlink() or _is_reparse_point(target) or (target.exists() and not target.is_file()):
                            raise CheckoutError("partial checkout local commit path is unsafe")
                        if target.exists():
                            target.unlink()
                if existing_branch is None:
                    self._git(request, destination, "switch", "-c", branch, baseline)
                elif current != branch:
                    self._git(request, destination, "switch", branch)
            except CheckoutError as error:
                if stash_created:
                    try:
                        self._git(request, destination, "stash", "pop")
                    except CheckoutError as restore_error:
                        raise CheckoutError("partial checkout review branch could not be anchored; local work requires reconciliation") from restore_error
                raise CheckoutError("partial checkout review branch could not be anchored to immutable baseline") from error
            if stash_created:
                try:
                    self._git(request, destination, "stash", "pop")
                except CheckoutError as error:
                    try:
                        if tracked_dirty_paths:
                            self._git(request, destination, "restore", "--source=HEAD", "--staged", "--", *tracked_dirty_paths)
                            if staged_dirty_paths:
                                self._git(request, destination, "restore", "--source=stash@{0}^2", "--staged", "--", *staged_dirty_paths)
                            self._git(request, destination, "restore", "--source=stash@{0}", "--worktree", "--", *tracked_dirty_paths)
                        if untracked_dirty_paths:
                            self._git(request, destination, "restore", "--source=stash@{0}^3", "--worktree", "--", *untracked_dirty_paths)
                        self._git(request, destination, "stash", "drop")
                    except CheckoutError as restore_error:
                        raise CheckoutError("partial checkout local work requires reconciliation after baseline anchoring") from restore_error
            return
        # Without an explicit baseline, preserve the historical non-destructive
        # branch recovery for legacy local fixtures.
        self._ensure_publication_branch(request, destination)

    def _write_receipt(self, request: WorkingCheckoutRequest, receipt: Mapping[str, Any], *, replace: bool = False, target: Path | None = None) -> None:
        receipt_target = request.receipt_file if target is None else target
        if receipt_target.parent != request.receipt_file.parent or receipt_target.is_symlink() or _is_reparse_point(receipt_target) or _is_reparse_point(receipt_target.parent):
            raise CheckoutError("ready receipt path is unsafe")
        temporary: Path | None = None
        try:
            fd, temporary_name = tempfile.mkstemp(prefix=f".{receipt_target.name}.", suffix=".tmp", dir=receipt_target.parent)
            temporary = Path(temporary_name)
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                stream.write(_canonical(receipt) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            if (receipt_target.exists() or receipt_target.is_symlink() or _is_reparse_point(receipt_target)) and not replace:
                raise OSError("ready receipt path is already occupied")
            os.replace(temporary, receipt_target)
            try:
                directory_fd = os.open(receipt_target.parent, os.O_RDONLY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
            except OSError:
                # Windows does not expose a fsync-able directory handle; the
                # file itself was flushed before the atomic replace. Other
                # platforms must prove the directory entry was flushed.
                if os.name != "nt":
                    raise
        except OSError as error:
            try:
                if temporary is not None:
                    temporary.unlink(missing_ok=True)
            except OSError:
                pass
            raise CheckoutError("ready receipt could not be recorded") from error

    def _write_replay_failure(self, request: WorkingCheckoutRequest, status: Mapping[str, Any]) -> None:
        """Write replay verification evidence without replacing a ready receipt."""
        path = request.receipt_file
        target = path
        try:
            current = json.loads(path.read_text(encoding="utf-8")) if path.exists() and not path.is_symlink() and not _is_reparse_point(path) else None
        except (OSError, UnicodeError, json.JSONDecodeError):
            current = None
        same_attempt = isinstance(current, Mapping) and current.get("schema") == "agent-stack.working-checkout-status.v1" and all(current.get(key) == expected for key, expected in (("project_id", request.project_id), ("revision", request.revision), ("intent_id", request.intent_id), ("checkout_path", str(self._destination(request))), ("publication_branch", self._publication_branch(request)), ("baseline_ref", request.baseline_ref), ("credential_selector", request.credential_selector))) and _repository_urls_match(current.get("repository_url"), request.repository_url)
        if same_attempt:
            replace = True
        else:
            digest = receipt_attempt_digest(project_id=request.project_id, revision=request.revision, intent_id=request.intent_id, repository_url=request.repository_url, baseline_ref=request.baseline_ref, credential_selector=request.credential_selector, checkout_path=str(self._destination(request)), publication_branch=self._publication_branch(request), phase=status.get("phase"), error_code=status.get("error_code"), recovery_action=status.get("recovery_action"))
            target = path.with_name(f"{path.name}.failure-{digest}")
            replace = True
        self._write_receipt(request, status, replace=replace, target=target)

    def _replay_failure_status(self, request: WorkingCheckoutRequest, destination: Path, error: CheckoutError) -> dict[str, Any]:
        phase = getattr(error, "phase", "verification")
        unknown = bool(getattr(error, "outcome_unknown", False))
        if bool(getattr(error, "authentication_failure", False)):
            error_code = "authentication_failed"
        elif "does not match the requested binding" in str(error):
            error_code = "binding_mismatch"
        elif "ready receipt is invalid" in str(error):
            error_code = "receipt_invalid"
        else:
            error_code = "remote_outcome_unknown" if unknown else "checkout_verification_failed"
        status = {"schema": "agent-stack.working-checkout-status.v1", "state": "retry_required" if unknown else "failed", "project_id": request.project_id, "revision": request.revision, "intent_id": request.intent_id, "repository_url": request.repository_url, "checkout_path": str(destination), "publication_branch": self._publication_branch(request), "baseline_ref": request.baseline_ref, "credential_selector": request.credential_selector, "phase": phase, "error_code": error_code, "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")}
        if unknown:
            status["reconciliation_receipt_id"] = self._reconciliation_receipt_id(request, phase=phase, error_code=error_code)
            status["recovery_action"] = "reconcile_remote_publication"
        return status

    def checkout(self, request: WorkingCheckoutRequest) -> dict[str, Any]:
        if not isinstance(request, WorkingCheckoutRequest):
            raise CheckoutError("checkout request is invalid")
        self._validate_url(request)
        destination = self._destination(request)
        _ensure_directory(request.receipt_file.parent, "ready receipt parent")
        try:
            existing = self._receipt_matches(request.receipt_file, request, destination)
        except CheckoutError as error:
            status = self._replay_failure_status(request, destination, error)
            try:
                self._write_replay_failure(request, status)
            except CheckoutError as receipt_error:
                raise CheckoutError("ready receipt verification failed and durable status receipt could not be recorded") from receipt_error
            raise
        if existing is not None:
            return existing
        has_retry_receipt = False
        prior_reconciliation_id: str | None = None
        if request.receipt_file.exists() or request.receipt_file.is_symlink() or _is_reparse_point(request.receipt_file):
            try:
                prior = json.loads(request.receipt_file.read_text(encoding="utf-8"))
                has_retry_receipt = isinstance(prior, Mapping) and prior.get("schema") == "agent-stack.working-checkout-status.v1"
                if has_retry_receipt and isinstance(prior.get("reconciliation_receipt_id"), str):
                    prior_reconciliation_id = prior["reconciliation_receipt_id"]
            except (OSError, UnicodeError, json.JSONDecodeError):
                raise CheckoutError("ready receipt path is unavailable")
            if not has_retry_receipt:
                raise CheckoutError("ready receipt path is unavailable")
        if destination.exists() and (not destination.is_dir() or destination.is_symlink() or _is_reparse_point(destination)):
            raise CheckoutError("working checkout destination is unsafe")
        try:
            fresh_clone = False
            if destination.exists() and any(destination.iterdir()):
                if not (destination / ".git").exists() or (destination / ".git").is_symlink() or _is_reparse_point(destination / ".git"):
                    raise CheckoutError("working checkout destination must be absent or a valid partial clone; unsafe non-empty destination")
                self._recover_partial_clone(request, destination)
            else:
                fresh_clone = True
                destination.mkdir(exist_ok=True)
                self._git(request, request.working_root, "clone", "--", request.repository_url, str(destination))
            _validate_git_metadata(destination)
            self._verify_remote_binding(request, destination)
            self._ensure_publication_branch(request, destination, anchor_baseline=fresh_clone)
            self._verify_checkout(request, destination)
            self._bootstrap(request, destination)
            head = self._verify_checkout(request, destination)
            receipt = {"schema": "agent-stack.working-checkout-ready.v1", "project_id": request.project_id, "revision": request.revision, "intent_id": request.intent_id, "repository_url": request.repository_url, "checkout_path": str(destination), "head": head, "publication_branch": self._publication_branch(request), "publication_state": "ready_for_review", "baseline_ref": request.baseline_ref, "credential_selector": request.credential_selector, "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")}
            self._write_receipt(request, receipt, replace=has_retry_receipt)
            return receipt
        except CheckoutError as error:
            phase = getattr(error, "phase", "checkout")
            unknown = bool(getattr(error, "outcome_unknown", False))
            error_code = "remote_outcome_unknown" if unknown else ("authentication_failed" if bool(getattr(error, "authentication_failure", False)) else "setup_failed")
            status = {"schema": "agent-stack.working-checkout-status.v1", "state": "retry_required" if unknown else "failed", "project_id": request.project_id, "revision": request.revision, "intent_id": request.intent_id, "repository_url": request.repository_url, "checkout_path": str(destination), "publication_branch": self._publication_branch(request), "baseline_ref": request.baseline_ref, "credential_selector": request.credential_selector, "phase": phase, "error_code": error_code, "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")}
            if unknown:
                status["reconciliation_receipt_id"] = self._reconciliation_receipt_id(request, phase=phase, error_code=error_code)
                status["recovery_action"] = "reconcile_remote_publication"
            elif prior_reconciliation_id is not None:
                status["reconciliation_receipt_id"] = prior_reconciliation_id
            try:
                self._write_receipt(request, status, replace=has_retry_receipt)
            except CheckoutError as receipt_error:
                raise CheckoutError("setup failed and durable status receipt could not be recorded") from receipt_error
            raise
