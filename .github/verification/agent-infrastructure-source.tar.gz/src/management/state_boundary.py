"""Shared filesystem boundary for Management-owned durable state.

Management has several independently launched entrypoints.  They all need the
same fail-closed path rules so that a configuration cannot redirect a SQLite
writer through a symlink or a pre-existing hard link.  This module deliberately
contains no service-specific policy; callers provide the declared state roots
and ask it to validate one durable leaf or directory before opening it.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import stat
from typing import Iterable


MANAGEMENT_SERVICE_PRINCIPAL = "stack-management-os"
MANAGEMENT_ROLE = "management"


class ManagementStateBoundaryError(ValueError):
    """A durable path is outside Management ownership or uses indirection."""


def _reparse_point(path: Path) -> bool:
    """Return whether *path* is a symlink or Windows reparse point."""
    try:
        if path.is_symlink():
            return True
        metadata = path.lstat()
    except (FileNotFoundError, OSError):
        return False
    attributes = getattr(metadata, "st_file_attributes", 0)
    return bool(attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))


def _contains_reparse_point(path: Path) -> bool:
    """Check existing components without resolving through them."""
    candidate = path.absolute()
    for component in (candidate, *candidate.parents):
        if _reparse_point(component):
            return True
    return False


def _link_count(path: Path) -> int:
    try:
        return int(path.lstat().st_nlink)
    except (FileNotFoundError, OSError) as error:
        raise ManagementStateBoundaryError("durable path metadata is unavailable") from error


def _assert_single_link(path: Path, label: str) -> None:
    """Reject files that have another directory entry (hard-link escape)."""
    if _link_count(path) != 1:
        raise ManagementStateBoundaryError(f"{label} must not be hard-linked")


def _reject_parent_traversal(path: Path) -> None:
    if any(part == ".." for part in path.parts):
        raise ManagementStateBoundaryError("durable path traversal is not allowed")


def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=True))
    except (OSError, RuntimeError, ValueError):
        return False
    return True


def _validate_root(root: Path, label: str) -> Path:
    if not isinstance(root, Path) or not root.is_absolute() or _contains_reparse_point(root) or not root.is_dir():
        raise ManagementStateBoundaryError(f"{label} must be an existing absolute non-symlink directory")
    try:
        return root.resolve(strict=True)
    except (OSError, RuntimeError) as error:
        raise ManagementStateBoundaryError(f"{label} cannot be resolved") from error


def validate_state_root(root: str | Path, label: str = "Management state root") -> Path:
    """Validate and return one declared state root."""
    return _validate_root(Path(root), label)


def validate_durable_directory(
    path: str | Path,
    root: str | Path,
    *,
    label: str = "durable directory",
    allow_missing: bool = False,
) -> Path:
    """Validate one owned directory before a worker writes below it."""
    candidate = Path(path)
    boundary = _validate_root(Path(root), "Management state root")
    if not candidate.is_absolute() or _contains_reparse_point(candidate):
        raise ManagementStateBoundaryError(f"{label} must be an absolute non-symlink directory")
    _reject_parent_traversal(candidate)
    if not _within(candidate, boundary):
        raise ManagementStateBoundaryError(f"{label} is outside the declared Management state root")
    if not candidate.exists():
        if allow_missing:
            return candidate.resolve(strict=False)
        raise ManagementStateBoundaryError(f"{label} must already exist")
    if not candidate.is_dir():
        raise ManagementStateBoundaryError(f"{label} must be a directory")
    return candidate.resolve(strict=True)


def validate_durable_leaf(
    path: str | Path,
    root: str | Path,
    *,
    label: str = "durable file",
    allow_missing: bool = True,
) -> Path:
    """Validate one SQLite/file leaf and all existing SQLite sidecars.

    ``resolve`` protects containment while ``lstat``/link-count checks protect
    the actual directory entry.  A hard link resolves inside the root even
    though it aliases an outside file, so containment alone is insufficient.
    """
    candidate = Path(path)
    boundary = _validate_root(Path(root), "Management state root")
    if not candidate.is_absolute() or candidate.name in {"", ".", ".."} or _contains_reparse_point(candidate):
        raise ManagementStateBoundaryError(f"{label} must be an absolute non-symlink file")
    _reject_parent_traversal(candidate)
    if not _within(candidate, boundary):
        raise ManagementStateBoundaryError(f"{label} is outside the declared Management state root")
    if candidate.exists():
        if not candidate.is_file():
            raise ManagementStateBoundaryError(f"{label} must be a regular file")
        _assert_single_link(candidate, label)
    elif not allow_missing:
        raise ManagementStateBoundaryError(f"{label} must already exist")

    # SQLite may write any of these sidecars.  Validate them before opening the
    # main database so a pre-existing redirected sidecar cannot be modified.
    for sidecar in (
        Path(str(candidate) + "-wal"),
        Path(str(candidate) + "-shm"),
        Path(str(candidate) + "-journal"),
    ):
        if _reparse_point(sidecar):
            raise ManagementStateBoundaryError(f"{label} sidecar is a reparse point")
        if sidecar.exists():
            if _contains_reparse_point(sidecar) or not sidecar.is_file():
                raise ManagementStateBoundaryError(f"{label} sidecar is not a regular file")
            _assert_single_link(sidecar, f"{label} sidecar")
    return candidate.resolve(strict=False)


def validate_durable_leaf_with_missing_parents(
    path: str | Path,
    *,
    label: str = "durable file",
) -> tuple[Path, Path]:
    """Validate a leaf beneath the nearest existing ancestor.

    A few legacy journals create a nested working directory on first launch.
    The existing ancestor is still the ownership boundary; callers may create
    only the validated missing descendants before opening the leaf.
    """
    candidate = Path(path)
    if not candidate.is_absolute():
        raise ManagementStateBoundaryError(f"{label} must be an absolute non-symlink file")
    root = candidate.parent
    while not root.exists():
        parent = root.parent
        if parent == root:
            raise ManagementStateBoundaryError(f"{label} has no existing Management state root")
        root = parent
    boundary = validate_state_root(root, "Management state root")
    return validate_durable_leaf(candidate, boundary, label=label), boundary


def validate_durable_path(path: str | Path, roots: Iterable[str | Path], *, label: str = "durable path", directory: bool = False, allow_missing: bool = True) -> Path:
    """Validate a path against one of several declared Management roots."""
    candidate = Path(path)
    errors: list[str] = []
    for root in roots:
        try:
            return (validate_durable_directory if directory else validate_durable_leaf)(candidate, root, label=label, allow_missing=allow_missing)
        except ManagementStateBoundaryError as error:
            errors.append(str(error))
    raise ManagementStateBoundaryError(errors[-1] if errors else f"{label} has no declared Management state root")


@dataclass(frozen=True)
class ManagementStateBoundary:
    """One Management identity and its declared owned state roots."""

    service_principal: str
    state_root: Path
    state_roots: tuple[Path, ...] = ()

    def __post_init__(self) -> None:
        if self.service_principal != MANAGEMENT_SERVICE_PRINCIPAL:
            raise ManagementStateBoundaryError("configuration principal is not the dedicated Management principal")
        roots = tuple(validate_state_root(value, "Management state root") for value in (self.state_root, *self.state_roots))
        if len(set(roots)) != len(roots):
            raise ManagementStateBoundaryError("Management state roots must be unique")
        object.__setattr__(self, "state_root", roots[0])
        object.__setattr__(self, "state_roots", roots[1:])

    @property
    def roots(self) -> tuple[Path, ...]:
        return (self.state_root, *self.state_roots)

    def owns(self, path: str | Path, *, directory: bool = False, allow_missing: bool = True) -> bool:
        try:
            validate_durable_path(path, self.roots, label="Management durable state", directory=directory, allow_missing=allow_missing)
        except ManagementStateBoundaryError:
            return False
        return True

    def require_leaf(self, path: str | Path, *, label: str = "Management durable state", allow_missing: bool = True) -> Path:
        return validate_durable_path(path, self.roots, label=label, allow_missing=allow_missing)

    def require_directory(self, path: str | Path, *, label: str = "Management durable state", allow_missing: bool = False) -> Path:
        return validate_durable_path(path, self.roots, label=label, directory=True, allow_missing=allow_missing)
