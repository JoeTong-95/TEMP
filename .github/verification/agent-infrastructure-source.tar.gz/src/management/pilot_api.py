"""Loopback FastAPI control surface for the local pilot."""
from __future__ import annotations
import os, json, hashlib, re
from pathlib import Path
from typing import Any
from uuid import UUID
from .pilot_spec import PilotDefinition, PilotSpecError
from .pilot_store import PilotStore
from shared.contracts.pilot_artifact import AudioJobRequest, ImageJobRequest, PilotAudioArtifactStore, PilotThreeDArtifactStore, PilotVideoArtifactStore, ThreeDJobRequest, VideoJobRequest

try:
 from fastapi import FastAPI, Header, HTTPException, Request
 from fastapi.staticfiles import StaticFiles
 from fastapi.responses import Response
 from pydantic import BaseModel, StrictInt, StrictStr
 class ImageJobPayload(BaseModel):
  project_id: StrictStr
  request_id: StrictStr
  modality: StrictStr
  format: StrictStr
  mode: StrictStr
  prompt: StrictStr
  width: StrictInt
  height: StrictInt
  class Config:
   extra='forbid'
 class AudioJobPayload(BaseModel):
  project_id: StrictStr
  request_id: StrictStr
  modality: StrictStr
  format: StrictStr
  mode: StrictStr
  prompt: StrictStr
  duration_seconds: StrictInt
  class Config:
   extra='forbid'
 class VideoJobPayload(BaseModel):
  project_id: StrictStr
  request_id: StrictStr
  modality: StrictStr
  format: StrictStr
  mode: StrictStr
  prompt: StrictStr
  width: StrictInt
  height: StrictInt
  duration_seconds: StrictInt
  class Config:
   extra='forbid'
 class ThreeDJobPayload(BaseModel):
  project_id: StrictStr
  request_id: StrictStr
  modality: StrictStr
  format: StrictStr
  mode: StrictStr
  prompt: StrictStr
  lifecycle: StrictStr|None = None
  statuses: list[StrictStr]|None = None
  class Config:
   extra='forbid'
except ImportError: FastAPI=None

class PilotApiUnavailable(RuntimeError): pass
_RUNTIME_PROJECTS={'platform-canary-a','platform-canary-b'}
_REQUEST_ID=re.compile(r'^[A-Za-z0-9._-]{1,80}$')

def _token(value:str|None, expected:str)->None:
 if not expected or value != 'Bearer '+expected: raise HTTPException(401,'operator capability required')

def create_app(state_dir:str|Path, operator_token:str|None=None, *, audio_store:PilotAudioArtifactStore, video_store:PilotVideoArtifactStore, three_d_store:PilotThreeDArtifactStore|None=None):
 if FastAPI is None: raise PilotApiUnavailable('FastAPI is required by the pinned Prefect environment')
 token=operator_token if operator_token is not None else os.environ.get('PILOT_OPERATOR_TOKEN','')
 store=PilotStore(Path(state_dir)/'pilot-control.sqlite3',audio_store,three_d_store)
 app=FastAPI(title='Agent Stack Pilot',docs_url=None,redoc_url=None)
 @app.middleware('http')
 async def bound_body(request:Request,call_next):
  if request.method in {'POST','PUT','PATCH'}:
   total=0; parts=[]
   async for part in request.stream():
    total+=len(part)
    if total>65_536: return __import__('fastapi').responses.JSONResponse({'detail':'request body exceeds 65536 bytes'},status_code=413)
    parts.append(part)
   request._body=b''.join(parts)
   async def replay(): return {'type':'http.request','body':request._body,'more_body':False}
   request._receive=replay
  return await call_next(request)
 def auth(authorization:str|None): _token(authorization,token)
 @app.post('/v1/definitions')
 def publish(body:dict[str,Any],authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   parent=body.get('parent_hash'); document={k:v for k,v in body.items() if k!='parent_hash'}
   definition=PilotDefinition.parse(document); return {'version_hash':store.publish(definition,parent),'layout':definition.layout}
  except (PilotSpecError,ValueError) as e: raise HTTPException(422,str(e))
 @app.get('/v1/definitions')
 def list_definitions(authorization:str|None=Header(default=None)): auth(authorization); return {'definitions':store.definitions()}
 @app.get('/v1/definitions/{version_hash}/diff')
 def diff(version_hash:str,against:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try: return {'from':against,'to':version_hash,'changed':store.definition(against)!=store.definition(version_hash)}
  except KeyError as e: raise HTTPException(404,str(e))
 @app.post('/v1/runs')
 def submit(body:dict[str,Any],authorization:str|None=Header(default=None)):
  """Submit one native Prefect flow; this endpoint never runs graph code itself."""
  auth(authorization)
  try:
   definition=PilotDefinition.parse(store.definition(body['definition_hash']))
   nodes={n['node_id']:n for n in definition.semantic['nodes']}; agent=next(n for n in nodes.values() if n['kind']=='agent'); approval=next(n for n in nodes.values() if n['kind']=='approval')
   value=body['value']; project=body['project_id']; request=body['request_id']
   if project not in _RUNTIME_PROJECTS or not isinstance(request,str) or not _REQUEST_ID.fullmatch(request): raise ValueError('invalid project or request id')
   if isinstance(value,bool) or not isinstance(value,int) or abs(value)>1_000_000: raise ValueError('value must be bounded integer')
   binding=store.binding(project)
   if binding['definition_hash'] != definition.version_hash: raise ValueError('project binding is for a different definition version')
   if binding['model_ref'] != agent['config']['model_ref'] or binding['memory_ref'] != agent['config']['memory_ref']: raise ValueError('project binding does not match agent logical references')
   fingerprint=hashlib.sha256(json.dumps({'project':project,'request':request,'definition':definition.version_hash,'value':value},sort_keys=True,separators=(',',':')).encode()).hexdigest()
   claimed=store.claim_submission(request,fingerprint)
   if claimed:
    try: store.projection(claimed)
    except KeyError: store.project(claimed,request,definition.version_hash,'submitted',{'runtime_kind':'prefect','project_id':project,'recovered_projection':True})
    return {'prefect_flow_run_id':claimed,'status':'submitted','runtime_kind':'prefect','replayed':True}
   from prefect.deployments import run_deployment
   deployment='agent-stack-pilot-v1/local-v1'
   key=hashlib.sha256((project+'\0'+request+'\0'+definition.version_hash).encode()).hexdigest()
   flow_run=run_deployment(deployment,parameters={'root':str(Path(state_dir)),'control_db':store.path,'project_id':project,'request_id':request,'model_ref':agent['config']['model_ref'],'memory_ref':agent['config']['memory_ref'],'value':value,'approval_scope':approval['config']['scope']},idempotency_key=key,timeout=0,as_subflow=False)
   native=str(flow_run.id)
   UUID(native)
   store.record_submission_native(request,fingerprint,native)
   store.project(native,request,definition.version_hash,'submitted',{'runtime_kind':'prefect','project_id':project})
   return {'prefect_flow_run_id':native,'status':'submitted','runtime_kind':'prefect'}
  except (KeyError,ValueError,PilotSpecError) as e: raise HTTPException(422,str(e))
  except Exception as e:
   if e.__class__.__name__ in {'PilotFlowUnavailable','ObjectNotFound'}: raise HTTPException(503,str(e))
   raise
 @app.post('/v1/image-jobs')
 def image_job(body:ImageJobPayload,authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   payload=body.model_dump() if hasattr(body,'model_dump') else body.dict()
   request=ImageJobRequest.from_values(**payload)
   if request.project_id not in _RUNTIME_PROJECTS: raise ValueError('invalid project or request id')
   return store.create_image_job(request)
  except (KeyError,ValueError) as e: raise HTTPException(422,str(e))
 @app.get('/v1/image-jobs/{job_id}')
 def image_status(job_id:str,project_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try: return store.image_job(job_id,project_id)
  except PermissionError as e: raise HTTPException(403,str(e))
  except KeyError as e: raise HTTPException(404,str(e))
 @app.get('/v1/projects/{project_id}/artifacts/{job_id}')
 def image_artifact(project_id:str,job_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   try:
    content,digest=store.image_artifact(project_id,job_id); media_type='image/svg+xml'
   except KeyError:
     try:
      content,digest=store.audio_artifact(project_id,job_id); media_type='audio/wav'
     except KeyError:
      try:
       content,digest=video_store.read_video(project_id,job_id); media_type='video/mp4'
      except KeyError:
       if three_d_store is None: raise KeyError('unknown artifact')
       content,digest=store.three_d_artifact(project_id,job_id); media_type='model/gltf-binary'
   return Response(content=content,media_type=media_type,headers={'ETag':digest,'Cache-Control':'no-store'})
  except PermissionError as e: raise HTTPException(403,str(e))
  except KeyError as e: raise HTTPException(404,str(e))
  except ValueError as e: raise HTTPException(500,str(e))
 @app.post('/v1/audio-jobs')
 def audio_job(body:AudioJobPayload,authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   payload=body.model_dump() if hasattr(body,'model_dump') else body.dict()
   request=AudioJobRequest.from_values(**payload)
   if request.project_id not in _RUNTIME_PROJECTS: raise ValueError('invalid project or request id')
   return store.create_audio_job(request)
  except (KeyError,ValueError) as e: raise HTTPException(422,str(e))
 @app.get('/v1/audio-jobs/{job_id}')
 def audio_status(job_id:str,project_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try: return store.audio_job(job_id,project_id)
  except PermissionError as e: raise HTTPException(403,str(e))
  except KeyError as e: raise HTTPException(404,str(e))
 @app.post('/v1/video-jobs')
 def video_job(body:VideoJobPayload,authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   payload=body.model_dump() if hasattr(body,'model_dump') else body.dict()
   from .pilot_provider import ControlledVideoProvider
   provider=ControlledVideoProvider()
   request=VideoJobRequest.from_values(**payload,capability=provider.capability)
   if request.project_id not in _RUNTIME_PROJECTS: raise ValueError('invalid project or request id')
   return video_store.submit_video(request, provider.render(request)).as_dict()
  except (KeyError,ValueError) as e: raise HTTPException(422,str(e))
 @app.get('/v1/video-jobs/{job_id}')
 def video_status(job_id:str,project_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try: return video_store.video_job(job_id,project_id).as_dict()
  except PermissionError as e: raise HTTPException(403,str(e))
  except KeyError as e: raise HTTPException(404,str(e))
 @app.post('/v1/3d-jobs')
 def three_d_job(body:ThreeDJobPayload,authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   payload=body.model_dump() if hasattr(body,'model_dump') else body.dict()
   request=ThreeDJobRequest.from_values(**payload)
   if request.project_id not in _RUNTIME_PROJECTS: raise ValueError('invalid project or request id')
   return store.create_3d_job(request)
  except (KeyError,ValueError,RuntimeError) as e: raise HTTPException(422,str(e))
 @app.get('/v1/3d-jobs/{job_id}')
 def three_d_status(job_id:str,project_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try: return store.three_d_job(job_id,project_id)
  except PermissionError as e: raise HTTPException(403,str(e))
  except KeyError as e: raise HTTPException(404,str(e))
 @app.post('/v1/definitions/{version_hash}/rollback')
 def rollback(version_hash:str,body:dict[str,str],authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   if body['project_id'] not in _RUNTIME_PROJECTS: raise ValueError('unknown pilot project')
   definition=PilotDefinition.parse(store.definition(version_hash)); agent=next(node for node in definition.semantic['nodes'] if node['kind']=='agent')
   binding=store.binding(body['project_id'])
   if binding['model_ref'] != agent['config']['model_ref'] or binding['memory_ref'] != agent['config']['memory_ref']: raise ValueError('rollback definition does not match project logical references')
   store.bind(body['project_id'],version_hash,binding['model_ref'],binding['memory_ref'])
   return {'project_id':body['project_id'],'rolled_back_to':version_hash}
  except KeyError as e: raise HTTPException(404,str(e))
  except ValueError as e: raise HTTPException(422,str(e))
 @app.post('/v1/grants')
 def grant(body:dict[str,str],authorization:str|None=Header(default=None)):
  auth(authorization)
  try:return {'grant_id':store.grant(body['scope'],body['actor'],body['mode'])}
  except (KeyError,ValueError) as e:raise HTTPException(422,str(e))
 @app.post('/v1/bindings')
 def bind(body:dict[str,str],authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   if body['project_id'] not in _RUNTIME_PROJECTS: raise ValueError('unknown pilot project')
   definition=PilotDefinition.parse(store.definition(body['definition_hash'])); agent=next(node for node in definition.semantic['nodes'] if node['kind']=='agent')
   if body['model_ref'] != agent['config']['model_ref'] or body['memory_ref'] != agent['config']['memory_ref']: raise ValueError('binding does not match immutable logical references')
   store.bind(body['project_id'],body['definition_hash'],body['model_ref'],body['memory_ref'])
   return {'project_id':body['project_id'],'binding':'saved'}
  except (KeyError,ValueError) as e: raise HTTPException(422,str(e))
 @app.post('/v1/grants/{grant_id}/revoke')
 def revoke(grant_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try: store.revoke(grant_id); return {'revoked':grant_id}
  except KeyError as e: raise HTTPException(404,str(e))
 @app.get('/v1/runs/{prefect_flow_run_id}')
 def status(prefect_flow_run_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   UUID(prefect_flow_run_id)
  except ValueError: raise HTTPException(422,'Prefect flow id must be UUID')
  try:
   projection=store.projection(prefect_flow_run_id)
   from .pilot_prefect import status as native_status
   native=native_status(prefect_flow_run_id)
   from .pilot_prefect import completed_result
   result=completed_result(prefect_flow_run_id) if native['state']=='StateType.COMPLETED' else None
   return {**projection,'native':native,**({'result':result} if result is not None else {})}
  except KeyError as e: raise HTTPException(404,str(e))
  except Exception as e:
   if e.__class__.__name__ == 'NativePrefectUnavailable': raise HTTPException(503,str(e))
   raise
 @app.post('/v1/runs/{prefect_flow_run_id}/approve')
 def approve(prefect_flow_run_id:str,body:dict[str,str],authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   p=store.projection(prefect_flow_run_id)
   from .pilot_prefect import status as native_status
   before=native_status(prefect_flow_run_id)
   if before['state']!='StateType.PAUSED': raise HTTPException(409,'native run is not paused')
   definition=PilotDefinition.parse(store.definition(p['definition_hash']))
   expected=next(n['config']['scope'] for n in definition.semantic['nodes'] if n['kind']=='approval')
   if body['scope'] != expected: raise HTTPException(403,'approval scope does not match this definition')
   if not store.authorize_and_record(prefect_flow_run_id,body['grant_id'],expected,body['actor']): raise HTTPException(403,'approval denied or revoked')
   # Persist before native resume so the resumed flow can verify the exact scope.
   from .pilot_prefect import resume
   native=resume(prefect_flow_run_id)
   actual=native_status(prefect_flow_run_id)
   store.project(prefect_flow_run_id,p['request_id'],p['definition_hash'],'resumed',{'scope':expected,'actor':body['actor'],'native':actual})
   return {'prefect_flow_run_id':prefect_flow_run_id,'approval':'accepted','native':actual}
  except KeyError as e: raise HTTPException(404,str(e))
 @app.post('/v1/runs/{prefect_flow_run_id}/cancel')
 def cancel(prefect_flow_run_id:str,authorization:str|None=Header(default=None)):
  auth(authorization)
  try:
   p=store.projection(prefect_flow_run_id)
   from .pilot_prefect import cancel as native_cancel
   native=native_cancel(prefect_flow_run_id)
   from .pilot_prefect import status as native_status
   actual=native_status(prefect_flow_run_id)
   store.project(prefect_flow_run_id,p['request_id'],p['definition_hash'],actual['state'].lower(),{'native':actual})
   return {'prefect_flow_run_id':prefect_flow_run_id,'native':actual,'state':actual['state']}
  except KeyError as e: raise HTTPException(404,str(e))
 dist=Path(__file__).resolve().parents[2]/'ui'/'workflow-studio'/'dist'
 if dist.is_dir(): app.mount('/',StaticFiles(directory=str(dist),html=True),name='workflow-studio')
 return app
