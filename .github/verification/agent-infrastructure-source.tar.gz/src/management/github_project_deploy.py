"""Attended GitHub repository-provisioning and working-checkout composition."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import re
import sys
import tempfile
from typing import Any, Mapping

from .hardware_registry import HardwareRegistry
from .project_repository_provisioning import GitHubProjectRepositoryProvisioner, RemoteOutcomeUnknown, RepositoryAuthenticationError, RepositoryProvisioningError, _json, load_request
from .project_working_checkout import CheckoutError, ProjectWorkingCheckout, WorkingCheckoutRequest, _is_reparse_point, _repository_urls_match, receipt_attempt_digest, resolve_prd_reference
from .provider_registry import ProviderRegistry
from .project_control import ProjectControl


class DeployConfigError(ValueError):
    pass


class ManagementConfigError(DeployConfigError):
    """The Management document configuration is malformed or unusable."""


class AcceptedPRDError(DeployConfigError):
    """The accepted project payload does not name a usable PRD reference."""


@dataclass(frozen=True)
class _FailureRequest:
    project_id: str = "unknown-project"
    revision: int = 0
    intent_id: str = "unknown-intent"
    url: str = "https://github.com/unknown/unknown.git"
    baseline_ref: str | None = None


@dataclass(frozen=True)
class _FailureIdentity:
    credential_selector: str | None = None


_SAFE_CONTEXT_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_SAFE_CONTEXT_COMMIT = re.compile(r"[0-9a-f]{40,64}\Z")


def _credential_helper_command(path: Path) -> str:
    """Format the reviewed helper path for Git's shell-backed config value."""
    shell_path = str(path).replace("\\", "/")
    return f'!sh "{shell_path}"'


def _failure_context(config: DeployConfig) -> tuple[Any, Any]:
    """Recover only safe, nonsecret identifiers when setup cannot load fully."""
    values: Mapping[str, Any] = {}
    try:
        raw = json.loads(config.provisioning_config.read_text(encoding="utf-8"))
        if isinstance(raw, Mapping):
            values = raw
    except (OSError, UnicodeError, json.JSONDecodeError):
        pass
    project_id = values.get("project_id")
    if not isinstance(project_id, str) or _SAFE_CONTEXT_ID.fullmatch(project_id) is None:
        project_id = "unknown-project"
    intent_id = values.get("intent_id")
    if not isinstance(intent_id, str) or _SAFE_CONTEXT_ID.fullmatch(intent_id) is None:
        intent_id = "unknown-intent"
    revision = values.get("revision")
    if type(revision) is not int or revision < 1:
        revision = 0
    baseline_ref = values.get("baseline_ref")
    if not isinstance(baseline_ref, str) or _SAFE_CONTEXT_COMMIT.fullmatch(baseline_ref) is None:
        baseline_ref = None
    identity = values.get("bootstrap_identity")
    selector = identity.get("credential_selector") if isinstance(identity, Mapping) else None
    if not isinstance(selector, str) or _SAFE_CONTEXT_ID.fullmatch(selector) is None:
        selector = None
    binding = values.get("forge_binding")
    url = binding.get("repository_url") if isinstance(binding, Mapping) else values.get("repository_url")
    if not isinstance(url, str) or not url.startswith("https://github.com/") or "@" in url or "?" in url or "#" in url:
        url = "https://github.com/unknown/unknown.git"
    return _FailureRequest(project_id, revision, intent_id, url, baseline_ref), _FailureIdentity(selector)


@dataclass(frozen=True)
class DeployConfig:
    provisioning_config: Path
    management_config: Path
    working_root: Path
    ready_receipt_file: Path
    credential_helper_path: Path
    allowed_origins: tuple[str, ...]
    git_binary: str = "git"
    timeout_seconds: float = 120.0


def _operator_file(value: Any, name: str) -> Path:
    path = Path(value) if isinstance(value, (str, Path)) else None
    if path is None or not path.is_absolute() or path.is_symlink() or _is_reparse_point(path) or not path.is_file() or any(parent.is_symlink() or _is_reparse_point(parent) for parent in path.parents):
        raise DeployConfigError(f"{name} must be an absolute non-symlink file")
    return path.resolve(strict=True)


def _operator_path(value: Any, name: str) -> Path:
    path = Path(value) if isinstance(value, (str, Path)) else None
    if path is None or not path.is_absolute() or path.is_symlink() or _is_reparse_point(path) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in path.parents):
        raise DeployConfigError(f"{name} must be an absolute non-symlink path")
    return path


def load_deploy_config(path: str | Path) -> DeployConfig:
    config_file = _operator_file(path, "deployment configuration")
    try:
        raw = json.loads(config_file.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise DeployConfigError("deployment configuration is invalid") from error
    required = {"provisioning_config", "management_config", "working_root", "ready_receipt_file", "credential_helper_path", "allowed_origins"}
    allowed = required | {"git_binary", "timeout_seconds"}
    if not isinstance(raw, Mapping) or set(raw) - allowed or not required <= set(raw):
        raise DeployConfigError("deployment configuration shape is invalid")
    helper = raw["credential_helper_path"]
    origins = raw["allowed_origins"]
    if not isinstance(origins, list) or not origins or any(not isinstance(origin, str) or not origin for origin in origins):
        raise DeployConfigError("deployment credential/origin configuration is invalid")
    helper_path = _operator_file(helper, "credential helper")
    if helper_path.name != "github-credential-helper.sh" or re.fullmatch(r"[A-Za-z0-9_./:\\ -]+", str(helper_path)) is None:
        raise DeployConfigError("credential helper must be the reviewed GitHub helper")
    git_binary = raw.get("git_binary", "git")
    timeout = raw.get("timeout_seconds", 120.0)
    if not isinstance(git_binary, str) or not git_binary or "\r" in git_binary or "\n" in git_binary or isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 0 < timeout <= 600:
        raise DeployConfigError("deployment runtime configuration is invalid")
    return DeployConfig(
        _operator_file(raw["provisioning_config"], "provisioning configuration"),
        _operator_file(raw["management_config"], "Management configuration"),
        _operator_path(raw["working_root"], "working root"),
        _operator_path(raw["ready_receipt_file"], "ready receipt file"),
        helper_path,
        tuple(origins),
        git_binary,
        float(timeout),
    )


def _management_document_config(path: Path) -> tuple[Path, int]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ManagementConfigError("Management configuration is invalid") from error
    if not isinstance(raw, Mapping):
        raise ManagementConfigError("Management configuration must be an object")
    api = raw.get("api")
    if not isinstance(api, Mapping) or not isinstance(api.get("project_document_root"), str):
        raise ManagementConfigError("Management configuration must name project_document_root")
    try:
        root = _operator_path(api["project_document_root"], "project document root")
    except DeployConfigError as error:
        raise ManagementConfigError(str(error)) from error
    if not root.is_dir():
        raise ManagementConfigError("project document root must be an existing directory")
    maximum = api.get("max_prd_bytes", 512 * 1024)
    if isinstance(maximum, bool) or not isinstance(maximum, int) or not 1 <= maximum <= 1024 * 1024:
        raise ManagementConfigError("Management PRD size limit is invalid")
    return root.resolve(strict=True), maximum


def _provisioner(config: DeployConfig):
    request, identity, projects_db, providers_db, hardware_db, _ca, timeout, origin = load_request(config.provisioning_config)
    if request.forge_provider != "github":
        raise RepositoryProvisioningError("attended GitHub deployment requires forge_provider=github")
    if request.baseline_ref is None:
        raise RepositoryProvisioningError("current attended setup requires an explicit immutable baseline_ref")
    if identity.credential_selector is None:
        raise RepositoryProvisioningError("current attended setup requires an explicit credential selector")
    projects = ProjectControl(projects_db)
    providers = ProviderRegistry(providers_db, HardwareRegistry(hardware_db))
    return request, identity, GitHubProjectRepositoryProvisioner(projects, providers, request, bootstrap_identity=identity, origin=origin, timeout_seconds=timeout)


def _write_failure_receipt(config: DeployConfig, request: Any, identity: Any, *, phase: str, error_code: str, recovery_action: str, state: str = "failed", reconciliation_receipt_id: str | None = None) -> None:
    """Persist non-secret pre-checkout evidence for one failed attempt."""
    label = "authentication failure" if error_code == "authentication_failed" else "setup failure"
    path = config.ready_receipt_file
    if not path.is_absolute() or path.is_symlink() or _is_reparse_point(path) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in path.parents):
        raise RepositoryProvisioningError(f"{label} receipt path is unsafe")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        raise RepositoryProvisioningError(f"{label} receipt parent could not be created") from error
    if path.parent.is_symlink() or _is_reparse_point(path.parent) or not path.parent.is_dir():
        raise RepositoryProvisioningError(f"{label} receipt parent is unsafe")
    receipt = {
        "schema": "agent-stack.working-checkout-status.v1",
        "state": state,
        "project_id": request.project_id,
        "revision": request.revision,
        "intent_id": request.intent_id,
        "repository_url": request.url,
        "checkout_path": str(config.working_root / request.project_id),
        "publication_branch": f"agent-stack/setup/{request.project_id}/r{request.revision}",
        "baseline_ref": request.baseline_ref,
        "credential_selector": identity.credential_selector,
        "phase": phase,
        "error_code": error_code,
        "recovery_action": recovery_action,
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    if reconciliation_receipt_id is not None:
        receipt["reconciliation_receipt_id"] = reconciliation_receipt_id
    target = path
    if path.exists() or path.is_symlink() or _is_reparse_point(path):
        # Preserve a valid receipt for another attempt. The sidecar name is
        # deterministic for this nonsecret attempt identity, so retries do not
        # create an unbounded set of duplicate records.
        digest = receipt_attempt_digest(project_id=request.project_id, revision=request.revision, intent_id=request.intent_id, repository_url=request.url, baseline_ref=request.baseline_ref, credential_selector=identity.credential_selector, checkout_path=str(config.working_root / request.project_id), publication_branch=f"agent-stack/setup/{request.project_id}/r{request.revision}", phase=phase, error_code=error_code, recovery_action=recovery_action)
        target = path.with_name(f"{path.name}.failure-{digest}")
        if target.is_symlink() or _is_reparse_point(target):
            raise RepositoryProvisioningError(f"{label} receipt path is unsafe")
    temporary: Path | None = None
    try:
        fd, name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
        temporary = Path(name)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(_json(receipt) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
        try:
            directory_fd = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError:
            if os.name != "nt":
                raise
    except OSError as error:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        raise RepositoryProvisioningError(f"{label} receipt could not be recorded") from error


def _write_auth_failure_receipt(config: DeployConfig, request: Any, identity: Any) -> None:
    _write_failure_receipt(config, request, identity, phase="authentication", error_code="authentication_failed", recovery_action="refresh_or_select_credentials")


def _checkout_status_matches(config: DeployConfig, request: Any, identity: Any, *, error_code: str, reconciliation_receipt_id: str | None = None) -> bool:
    """Avoid duplicating the checkout's already durable status projection."""
    path = config.ready_receipt_file
    try:
        if not path.is_file() or path.is_symlink() or _is_reparse_point(path):
            return False
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False
    return isinstance(value, Mapping) and value.get("schema") == "agent-stack.working-checkout-status.v1" and value.get("project_id") == request.project_id and value.get("revision") == request.revision and value.get("intent_id") == request.intent_id and _repository_urls_match(value.get("repository_url"), request.url) and value.get("baseline_ref") == request.baseline_ref and value.get("credential_selector") == identity.credential_selector and value.get("error_code") == error_code and (reconciliation_receipt_id is None or value.get("reconciliation_receipt_id") == reconciliation_receipt_id)


def _provisioning_failure_evidence(error: RepositoryProvisioningError) -> tuple[str, str, str]:
    """Map known setup failures to truthful, non-authentication evidence."""
    if isinstance(error, RemoteOutcomeUnknown):
        return "remote_outcome_unknown", "provisioning", "reconcile_remote_repository_outcome"
    detail = str(error).casefold().strip()
    # These are the only provisioning errors caused by reading the private
    # bootstrap token.  RepositoryAuthenticationError handles provider 401/403
    # responses; message substrings must not turn identity/scope failures into
    # authentication receipts.
    if detail in {"bootstrap token is unavailable", "bootstrap token is invalid"}:
        return "authentication_failed", "authentication", "repair_token_reference"
    if "current human-confirmed project revision" in detail or "exact current accepted start intent" in detail:
        return "stale_revision", "provisioning", "reconfirm_current_project_revision"
    if any(marker in detail for marker in ("configuration", "credential selector", "forge binding", "forge_provider", "baseline", "provider is not eligible")):
        return "configuration_invalid", "configuration", "correct_reviewed_setup_configuration"
    if any(marker in detail for marker in ("identity", "owner", "organization", "scope")):
        return "identity_scope_mismatch", "provisioning", "review_bootstrap_identity_scope"
    return "provisioning_failed", "provisioning", "review_setup_and_retry"


def run(config: DeployConfig, *, apply: bool) -> dict[str, Any]:
    request, identity = _failure_context(config)
    try:
        request, identity, provisioner = _provisioner(config)
        plan = provisioner.plan()
        if not apply:
            return {**plan, "state": "planned", "checkout_path": str(config.working_root / request.project_id), "ready_receipt_file": str(config.ready_receipt_file)}
        document_root, max_prd_bytes = _management_document_config(config.management_config)
        draft = provisioner.projects.draft(request.project_id)
        prd_reference = draft.get("payload", {}).get("prd_reference")
        if not isinstance(prd_reference, str):
            raise AcceptedPRDError("accepted project payload must contain prd_reference")
        # Resolve the accepted Management document before any remote repository
        # mutation, so a bad reference cannot leave an orphaned GitHub repository.
        resolve_prd_reference(document_root, prd_reference, max_prd_bytes)
        binding = provisioner.provision()
    except RepositoryAuthenticationError:
        _write_auth_failure_receipt(config, request, identity)
        raise
    except RepositoryProvisioningError as error:
        # verify_identity runs before any checkout exists. Keep the failure
        # visible at the same operator receipt boundary as checkout failures.
        # Only typed provider auth and exact token-read failures are auth;
        # identity, scope, and configuration problems get distinct evidence.
        error_code, phase, recovery_action = _provisioning_failure_evidence(error)
        if isinstance(error, RemoteOutcomeUnknown):
            reconciliation_id = error.receipt_id or "unreconciled-" + receipt_attempt_digest(project_id=request.project_id, revision=request.revision, intent_id=request.intent_id, repository_url=request.url, baseline_ref=request.baseline_ref, credential_selector=identity.credential_selector, checkout_path=str(config.working_root / request.project_id), publication_branch=f"agent-stack/setup/{request.project_id}/r{request.revision}", phase=phase, error_code=error_code, recovery_action=recovery_action)
            _write_failure_receipt(config, request, identity, phase=phase, error_code=error_code, recovery_action=recovery_action, state="retry_required", reconciliation_receipt_id=reconciliation_id)
        else:
            _write_failure_receipt(config, request, identity, phase=phase, error_code=error_code, recovery_action=recovery_action)
        raise
    except CheckoutError:
        _write_failure_receipt(config, request, identity, phase="configuration", error_code="invalid_prd", recovery_action="repair_accepted_prd_reference")
        raise
    except AcceptedPRDError:
        _write_failure_receipt(config, request, identity, phase="configuration", error_code="invalid_prd", recovery_action="repair_accepted_prd_reference")
        raise
    except ManagementConfigError:
        _write_failure_receipt(config, request, identity, phase="configuration", error_code="configuration_failed", recovery_action="correct_management_configuration")
        raise
    except DeployConfigError as error:
        _write_failure_receipt(config, request, identity, phase="configuration", error_code="configuration_failed", recovery_action="correct_management_configuration")
        raise
    checkout_request = WorkingCheckoutRequest(
        request.project_id,
        request.revision,
        request.intent_id,
        binding["canonical_git_url"],
        config.working_root,
        config.ready_receipt_file,
        config.allowed_origins,
        prd_reference,
        document_root,
        max_prd_bytes,
        publication_branch=f"agent-stack/setup/{request.project_id}/r{request.revision}",
        baseline_ref=request.baseline_ref,
        credential_selector=identity.credential_selector,
    )
    helper = _credential_helper_command(config.credential_helper_path)
    try:
        receipt = ProjectWorkingCheckout(git_binary=config.git_binary, credential_helper=helper, credential_environment={"AGENT_STACK_FORGE_TOKEN_FILE": str(identity.token_file)}, timeout_seconds=config.timeout_seconds).checkout(checkout_request)
    except CheckoutError as error:
        phase = getattr(error, "phase", "checkout")
        unknown = bool(getattr(error, "outcome_unknown", False))
        authentication = bool(getattr(error, "authentication_failure", False))
        if unknown:
            error_code = "remote_outcome_unknown"
            recovery_action = "reconcile_remote_publication"
            reconciliation_id = "checkout-" + receipt_attempt_digest(project_id=request.project_id, revision=request.revision, intent_id=request.intent_id, repository_url=request.url, baseline_ref=request.baseline_ref, credential_selector=identity.credential_selector, checkout_path=str(config.working_root / request.project_id), publication_branch=f"agent-stack/setup/{request.project_id}/r{request.revision}", phase=phase, error_code=error_code, recovery_action=recovery_action)
            if not _checkout_status_matches(config, request, identity, error_code=error_code, reconciliation_receipt_id=reconciliation_id):
                _write_failure_receipt(config, request, identity, phase=phase, error_code=error_code, recovery_action=recovery_action, state="retry_required", reconciliation_receipt_id=reconciliation_id)
        elif authentication:
            if not _checkout_status_matches(config, request, identity, error_code="authentication_failed"):
                _write_failure_receipt(config, request, identity, phase=phase, error_code="authentication_failed", recovery_action="refresh_or_select_credentials")
        else:
            if not _checkout_status_matches(config, request, identity, error_code="setup_failed"):
                _write_failure_receipt(config, request, identity, phase=phase, error_code="setup_failed", recovery_action="review_checkout_and_retry")
        raise
    return {"state": "ready", "repository": binding, "checkout": receipt}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Attended GitHub repository + isolated checkout deployment")
    parser.add_argument("--config", required=True)
    parser.add_argument("--apply", action="store_true", help="create/recover the private repository and clone its isolated checkout")
    args = parser.parse_args(argv)
    try:
        print(_json(run(load_deploy_config(args.config), apply=args.apply)))
        return 0
    except (CheckoutError, DeployConfigError, RepositoryProvisioningError, ValueError, KeyError) as error:
        print("GitHub project deployment blocked: " + str(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
