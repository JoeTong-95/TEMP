"""Reviewed CPU-only deployment. No caller-selected paths, code or model URLs."""
import json
import re
from pathlib import Path
from prefect import flow, runtime
from management.prefect_flow import (
    default_prefect_workflow_spec, execute_fixture_effect, verify_fixture_evidence,
)

STATE = Path('/srv/agent-stack/state/prefect/neutral-fixture')
PROJECTS = {'platform-canary-a', 'platform-canary-b'}


@flow(name='agent-stack-neutral-v1', retries=0, persist_result=True,
      result_serializer='json', validate_parameters=False)
def neutral_flow(request_id: str, project_id: str, value: int) -> dict:
    if type(request_id) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}', request_id):
        raise ValueError('Invalid logical request identifier')
    if project_id not in PROJECTS or type(value) is not int or abs(value) > 1_000_000:
        raise ValueError('Project or fixture value outside the reviewed contract')
    graph = default_prefect_workflow_spec()
    graph.validate()
    root = str(STATE / project_id)
    payload = json.dumps({'value': value})
    produced = execute_fixture_effect(root, project_id, request_id, payload)
    verified = verify_fixture_evidence(root, project_id, request_id, payload, produced,
                                       json.dumps({'sum': value, 'count': 1}))
    return {'request_id': request_id, 'project_id': project_id,
            'prefect_flow_run_id': str(runtime.flow_run.id),
            'runtime_kind': 'prefect', 'workflow_version_hash': graph.version_hash,
            'result': json.loads(verified)}


if __name__ == '__main__':
    neutral_flow.serve(name='neutral-tool-v1', limit=1, global_limit=1,
                       tags=['synthetic', 'agent-stack'], webserver=False,
                       description='Reviewed CPU fixture only; no arbitrary generated code or private tools')
