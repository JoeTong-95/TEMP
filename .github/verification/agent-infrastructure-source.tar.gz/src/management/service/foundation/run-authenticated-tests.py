"""Operator entry point: execute regression suite as service user, not root."""
import os
from pathlib import Path
import subprocess
from datetime import datetime, timezone
from uuid import uuid4

if os.geteuid() != 0:
    raise SystemExit('root operator needed')
root = Path('/srv/agent-stack')
env = dict(line.split('=', 1) for line in (root / 'secrets/prefect/service.env').read_text().splitlines() if '=' in line)
env.update(PATH='/usr/bin:/bin', PYTHONPATH=str(root / 'source/agent-infrastructure/src'),
           HOME=str(root / 'state/prefect'), PREFECT_HOME=str(root / 'state/prefect'),
           PREFECT_RESULTS_LOCAL_STORAGE_PATH=str(root / 'state/prefect/results'),
           PREFECT_SERVER_ANALYTICS_ENABLED='false', PREFECT_SERVER_ALLOW_EPHEMERAL_MODE='false',
           AGENT_STACK_PREFECT_API_URL='http://127.0.0.1:14200/api')
generation = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid4().hex[:8]
report = root / 'state/prefect' / f'tests-authenticated-postgres-{generation}.json'
result = subprocess.run(['/usr/sbin/runuser', '-m', '-u', 'stack-prefect', '--',
                         str(root / 'cache/prefect-3.8.5-venv/bin/python'),
                         str(root / 'source/agent-infrastructure/agent/codex/run_product_tests.py'),
                         '--report', str(report)], env=env,
                        cwd=root / 'state/prefect', timeout=90)
if report.exists():
    import shutil
    destination = root / 'artifacts' / report.name
    shutil.copyfile(report, destination)
    os.chmod(destination, 0o644)
    print(f'Fresh authenticated test evidence: {destination}')
else:
    raise SystemExit('No report from this exact test generation; prior reports are not evidence of this run.')
raise SystemExit(result.returncode)
