"""Fixed-scope CPU service control, not a workflow or inference scheduler.

Start/stop require distro root. Stop is maintenance, not graceful job drain;
explicit acknowledgement is required until native-run reconciliation is wired.
"""
import argparse
import json
import os
import subprocess

SERVICES = ('postgresql@16-agentstack.service', 'agent-stack-prefect.service',
            'stack-paperclip.service', 'agent-stack-canary-worker.service',
            'stack-prefect-bridge.service')
parser = argparse.ArgumentParser()
parser.add_argument('action', choices=('status', 'start', 'stop'))
parser.add_argument('--maintenance-confirmed', action='store_true')
args = parser.parse_args()
if args.action != 'status' and os.geteuid() != 0:
    raise SystemExit('Distro-root operator required; not an agent tool')
if args.action == 'stop' and not args.maintenance_confirmed:
    raise SystemExit('Drain is not implemented. Stop only after reviewing owned active runs; supply --maintenance-confirmed')
if args.action == 'status':
    rows = []
    for service in SERVICES:
        output = subprocess.run(['systemctl', 'show', service,
            '--property=Id,ActiveState,SubState,User,MemoryCurrent,MemoryMax,NRestarts'],
            check=True, capture_output=True, text=True, timeout=10).stdout
        rows.append(dict(line.split('=', 1) for line in output.splitlines() if '=' in line))
    print(json.dumps({'cpu_services': rows,
        'inference': 'separate Windows owner; do not infer readiness from CPU services',
        'memory': 'connection approval pending; not started',
        'unattended_host_boot': 'not proven'}, indent=2))
else:
    for service in SERVICES if args.action == 'start' else reversed(SERVICES):
        subprocess.run(['systemctl', args.action, service], check=True, timeout=90)
    print('CPU service action completed; verify API readiness separately')
