"""Bounded authenticated readiness gate; systemd ordering alone is insufficient."""
import base64
import json
import os
import time
import urllib.error
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def wait_ready(timeout=60):
    endpoint = os.environ.get('PREFECT_API_URL', '')
    if endpoint != 'http://127.0.0.1:14200/api':
        raise RuntimeError('readiness endpoint is not the approved local service')
    credential = os.environ.get('PREFECT_API_AUTH_STRING', '')
    if not credential:
        raise RuntimeError('readiness credential is absent')
    encoded = base64.b64encode(credential.encode()).decode('ascii')
    request = urllib.request.Request(endpoint + '/health', headers={'Authorization': 'Basic ' + encoded})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with opener.open(request, timeout=min(2, max(0.05, deadline - time.monotonic()))) as response:
                if response.status == 200 and json.loads(response.read(256)) is True:
                    print('Authenticated Prefect health ready')
                    return
        except (OSError, ValueError, urllib.error.URLError):
            pass
        time.sleep(min(1, max(0, deadline - time.monotonic())))
    raise RuntimeError('authenticated Prefect health not ready within deadline')


if __name__ == '__main__':
    wait_ready()
