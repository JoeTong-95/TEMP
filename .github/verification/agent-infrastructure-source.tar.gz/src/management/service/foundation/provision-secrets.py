"""Root-only initial synthetic service credentials, never emitted to stdout.

Creates new app roles/databases only. Existing roles are not reset; recovery or
rotation is an explicit operation. Secrets stay outside source and evidence.
"""
import os
from pathlib import Path
import secrets
import subprocess


def sql(statement):
    return subprocess.run(
        ['runuser', '-u', 'postgres', '--', 'psql', '-p', '15432',
         '-v', 'ON_ERROR_STOP=1', '-At', '-d', 'postgres'],
        input=statement, text=True, capture_output=True, check=True).stdout.strip()


def write_new(path, text):
    with open(path, 'x', encoding='utf-8') as target:
        os.chmod(path, 0o600)
        target.write(text)


if os.geteuid() != 0:
    raise SystemExit('Operator root required')
for app in ('prefect', 'paperclip'):
    folder = Path('/srv/agent-stack/secrets') / app
    credential = folder / 'service.env'
    if credential.exists():
        print(f'{app}: existing secret preserved')
        continue
    if sql(f"SELECT 1 FROM pg_roles WHERE rolname='{app}';"):
        raise SystemExit(f'{app}: existing role without credential; reconcile manually')
    password = secrets.token_hex(32)
    # Generate secret first so interrupted provisioning retains a recovery record.
    pending = folder / 'pending-password'
    if pending.exists():
        raise SystemExit(f'{app}: pending provisioning exists; reconcile manually')
    write_new(pending, password)
    sql(f"CREATE ROLE {app} LOGIN PASSWORD '{password}' NOSUPERUSER NOCREATEDB NOCREATEROLE;")
    sql(f'CREATE DATABASE {app} OWNER {app};')
    sql(f'REVOKE CONNECT ON DATABASE {app} FROM PUBLIC; GRANT CONNECT ON DATABASE {app} TO {app};')
    url = f'postgresql://{app}:{password}@127.0.0.1:15432/{app}'
    if app == 'prefect':
        auth = 'operator:' + secrets.token_hex(32)
        write_new(credential,
            'PREFECT_API_DATABASE_CONNECTION_URL=' + url.replace('postgresql:', 'postgresql+asyncpg:') + '\n'
            'PREFECT_SERVER_API_AUTH_STRING=' + auth + '\n'
            'PREFECT_API_AUTH_STRING=' + auth + '\n')
    else:
        write_new(credential, 'DATABASE_URL=' + url + '\n'
            'BETTER_AUTH_SECRET=' + secrets.token_hex(32) + '\n')
    # Keep generated pending password as restricted recovery evidence, not in Git.
    print(f'{app}: role/database and root-only service credentials created')
