"""Root operator starts a real bounded deployment check as stack-prefect."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/srv/agent-stack')
if os.geteuid() == 0:
    env = dict(line.split('=', 1) for line in (ROOT / 'secrets/prefect/service.env').read_text().splitlines() if '=' in line)
    env.update(PATH='/usr/bin:/bin', HOME=str(ROOT / 'state/prefect'),
               PREFECT_HOME=str(ROOT / 'state/prefect'),
               PREFECT_API_URL='http://127.0.0.1:14200/api',
               PREFECT_SERVER_ALLOW_EPHEMERAL_MODE='false',
               PREFECT_SERVER_ANALYTICS_ENABLED='false',
               PYTHONPATH=str(ROOT / 'source/agent-infrastructure/src'))
    result = subprocess.run(['/usr/sbin/runuser', '-m', '-u', 'stack-prefect', '--',
                             str(ROOT / 'cache/prefect-3.8.5-venv/bin/python'), __file__],
                            env=env, cwd=ROOT / 'state/prefect', timeout=75)
    source = ROOT / 'state/prefect/served-flow-check.json'
    if source.exists():
        import shutil
        dest = ROOT / 'artifacts/served-flow-check-2026-09-04.json'
        shutil.copyfile(source, dest)
        os.chmod(dest, 0o644)
    raise SystemExit(result.returncode)

from prefect.deployments import run_deployment
from management.fixture import lookup_fixture

request = 'served-canary-20260904-1'
parameters = {'request_id': request, 'project_id': 'platform-canary-a', 'value': 7}
run = run_deployment('agent-stack-neutral-v1/neutral-tool-v1', parameters=parameters,
                     timeout=45, poll_interval=1, idempotency_key=request, as_subflow=False)
assert run.state and run.state.is_completed(), 'Native deployment did not complete'
replay = run_deployment('agent-stack-neutral-v1/neutral-tool-v1', parameters=parameters,
                        timeout=0, idempotency_key=request, as_subflow=False)
assert replay.id == run.id, 'Native idempotency did not retain run identity'
receipt = lookup_fixture(ROOT / 'state/prefect/neutral-fixture/platform-canary-a',
                         'platform-canary-a', request, {'value': 7})
assert receipt and receipt['output'] == {'sum': 7, 'count': 1}, 'Fixture evidence mismatch'
report = {'schema': 'agent-stack.served-flow-check.v1',
          'observed_at_utc': datetime.now(timezone.utc).isoformat(),
          'deployment': 'agent-stack-neutral-v1/neutral-tool-v1',
          'prefect_flow_run_id': str(run.id), 'native_state': run.state.type.value,
          'native_run_count': run.run_count, 'duplicate_returned_same_run': True,
          'receipt': receipt, 'limitations': ['CPU fixture, not LLM or Paperclip dispatch']}
(ROOT / 'state/prefect/served-flow-check.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
