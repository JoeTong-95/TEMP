"""Quiesced local synthetic recovery proof, never a remote/disaster-backup claim.

Stops only named active stack services, restarts them even on export failure.
Uses fresh generation directories and isolated NEW restore databases. No drops,
overwrites, migrations, scheduled jobs or private external connections.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

BASE = Path('/srv/agent-stack')
STAMP = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
UNIT = BASE / 'recovery-staging' / ('foundation-' + STAMP)
SERVICES = ('stack-prefect-bridge.service', 'agent-stack-canary-worker.service',
            'stack-paperclip.service', 'agent-stack-prefect.service')


def command(args, **kwargs):
    return subprocess.run(args, check=True, timeout=90, **kwargs)


def postgres(args, **kwargs):
    return command(['/usr/sbin/runuser', '-u', 'postgres', '--', *args], **kwargs)


def query(database, sql):
    return postgres(['psql', '-p', '15432', '-d', database, '-At', '-v', 'ON_ERROR_STOP=1'],
                    input=sql, text=True, capture_output=True).stdout.strip()


def counts(database):
    names = query(database, "SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename;").splitlines()
    result = {}
    for name in names:
        escaped = name.replace('"', '""')
        result[name] = int(query(database, f'SELECT count(*) FROM public."{escaped}";'))
    return result


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


if os.geteuid() != 0:
    raise SystemExit('root operator required')
UNIT.mkdir(mode=0o700)
active = []
manifest = {'schema': 'agent-stack.foundation-recovery.v1', 'generation': STAMP,
            'status': 'incomplete', 'databases': {}, 'files': {},
            'limitations': ['synthetic PostgreSQL + service state only',
                            'same-disk staging is not disaster recovery',
                            'secrets require separate custody; not included in source evidence',
                            'restored tables counted, not full cross-service semantic validation']}
try:
    for service in SERVICES:
        observed = subprocess.run(['systemctl', 'is-active', '--quiet', service])
        if observed.returncode == 0:
            active.append(service)
    for service in active:
        command(['systemctl', 'stop', service])
    for app in ('prefect', 'paperclip'):
        dump = UNIT / (app + '.pgdump')
        with dump.open('wb') as output:
            postgres(['pg_dump', '-p', '15432', '-Fc', '-d', app], stdout=output, stderr=subprocess.PIPE)
        before = counts(app)
        restore_db = app + '_restore_' + STAMP.lower()
        query('postgres', f'CREATE DATABASE {restore_db} OWNER {app};')
        query('postgres', f'REVOKE CONNECT ON DATABASE {restore_db} FROM PUBLIC;')
        with dump.open('rb') as source:
            postgres(['pg_restore', '-p', '15432', '-d', restore_db, '--exit-on-error'],
                     stdin=source, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        after = counts(restore_db)
        if before != after:
            raise RuntimeError(f'{app}: restored table counts differ')
        manifest['databases'][app] = {'restored_database': restore_db,
                                      'table_count': len(before), 'row_counts_match': True}
    state = UNIT / 'service-state.tar.gz'
    with tarfile.open(state, 'w:gz') as archive:
        for app in ('prefect', 'paperclip'):
            archive.add(BASE / 'state' / app, arcname=app, recursive=True)
    for path in UNIT.iterdir():
        if path.is_file():
            os.chmod(path, 0o600)
            manifest['files'][path.name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    manifest['status'] = 'local_database_restore_passed'
finally:
    restart_failures = []
    for service in reversed(active):
        result = subprocess.run(['systemctl', 'start', service], timeout=90)
        if result.returncode:
            restart_failures.append(service)
    manifest['restart_failures'] = restart_failures
    if restart_failures:
        manifest['status'] = 'restart_failed'
    (UNIT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    destination = BASE / 'artifacts' / ('foundation-recovery-' + STAMP + '.json')
    destination.write_text(json.dumps(manifest, indent=2) + '\n')
    os.chmod(destination, 0o644)
print(json.dumps(manifest, indent=2))
if manifest['status'] != 'local_database_restore_passed':
    raise SystemExit(1)
