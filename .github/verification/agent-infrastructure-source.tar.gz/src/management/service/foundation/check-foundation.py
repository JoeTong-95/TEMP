"""Root-run deployment checks; secret values never leave child environments.

Only synthetic services are queried. Evidence is a partial gate observation,
not automatic acceptance of T02/T04/T05/T35 or the entire stack.
"""
from datetime import datetime, timezone
import base64
import json
import os
from pathlib import Path
import subprocess
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path('/srv/agent-stack')


def env_file(app):
    return dict(line.split('=', 1) for line in
                (ROOT / 'secrets' / app / 'service.env').read_text().splitlines() if '=' in line)


def status(path, auth=None):
    headers = {} if auth is None else {'Authorization': 'Basic ' + base64.b64encode(auth.encode()).decode()}
    try:
        with urlopen(Request('http://127.0.0.1:14200' + path, headers=headers), timeout=10) as response:
            return response.status
    except HTTPError as error:
        return error.code


def run(command, env=None):
    return subprocess.run(command, capture_output=True, text=True, env=env, timeout=30)


if os.geteuid() != 0:
    raise SystemExit('Root operator needed for credential references; never print them')
checks = {}
auth = env_file('prefect')['PREFECT_API_AUTH_STRING']
checks['prefect_unauthenticated_api_denied'] = status('/api/flow_runs/count') == 401
checks['prefect_wrong_auth_denied'] = status('/api/flow_runs/count', 'wrong:wrong') == 401
checks['prefect_authenticated_api_accessible'] = status('/api/health', auth) == 200
checks['prefect_ui_available'] = status('/') == 200
for app in ('prefect', 'paperclip'):
    from urllib.parse import urlsplit
    key = 'PREFECT_API_DATABASE_CONNECTION_URL' if app == 'prefect' else 'DATABASE_URL'
    parsed = urlsplit(env_file(app)[key].replace('postgresql+asyncpg:', 'postgresql:'))
    child_env = {'PATH': '/usr/bin:/bin', 'PGPASSWORD': parsed.password}
    other = 'paperclip' if app == 'prefect' else 'prefect'
    for database, expected in ((app, True), (other, False)):
        result = run(['psql', '-h', '127.0.0.1', '-p', '15432', '-U', app,
                      '-d', database, '-At', '-c', 'SELECT current_database();'], env=child_env)
        checks[f'{app}_database_{database}_access_expected'] = (result.returncode == 0) == expected
for identity in ('stack-agent-a', 'stack-agent-b'):
    for target in ('secrets/prefect/service.env', 'state/postgresql/PG_VERSION', 'state/prefect'):
        result = run(['runuser', '-u', identity, '--', 'test', '-r', str(ROOT / target)])
        checks[f'{identity}_cannot_read_{target}'] = result.returncode != 0
report = {'schema': 'agent-stack.foundation-observations.v1',
          'observed_at_utc': datetime.now(timezone.utc).isoformat(),
          'checks': checks, 'all_observations_passed': all(checks.values()),
          'acceptance': 'partial only; no host reboot, full isolation or multi-service recovery proof'}
destination = ROOT / 'artifacts/foundation-checks-2026-09-04.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
os.chmod(destination, 0o644)
print(json.dumps(report, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
