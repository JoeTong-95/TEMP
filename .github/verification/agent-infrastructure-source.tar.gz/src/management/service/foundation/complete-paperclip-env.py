"""Add missing synthetic signing secret only; never output credential values."""
import os
from pathlib import Path
import secrets

if os.geteuid() != 0:
    raise SystemExit('root required')
path = Path('/srv/agent-stack/secrets/paperclip/service.env')
text = path.read_text()
if 'PAPERCLIP_TOOL_ACTION_SIGNING_SECRET=' not in text:
    with path.open('a') as stream:
        stream.write('PAPERCLIP_TOOL_ACTION_SIGNING_SECRET=' + secrets.token_hex(32) + '\n')
print('Paperclip signing credential present; value withheld')
