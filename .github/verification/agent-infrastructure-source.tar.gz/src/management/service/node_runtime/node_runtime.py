"""Portable source-only Node Runtime contract skeleton; no live transport."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import argparse, json, math
from pathlib import Path
import sys
from typing import Any, Callable, Mapping, Protocol
from urllib.parse import urlsplit
import http.client, ssl

MAX_TELEMETRY_BYTES=32768; MAX_PROBE_AGE_SECONDS=60.0
ROUTES={"register":"/nodes/register","heartbeat":"/nodes/heartbeat","withdraw":"/nodes/withdraw"}
COMPONENTS={"cpu","ram","disk","network","gpu"}; METRICS={"utilization","used_bytes","free_bytes","read_bytes_per_second","write_bytes_per_second","temperature_celsius","power_watts"}
class NodeRuntimeError(ValueError): pass
class ManagementClient(Protocol):
 def post(self,endpoint:str,route:str,payload:Mapping[str,Any],*,token_reference:Mapping[str,str])->Mapping[str,Any]: ...
 def get(self,endpoint:str,route:str,*,token_reference:Mapping[str,str])->Mapping[str,Any]: ...
class NodeRuntimeHttpClient:
 """One-shot injected-auth transport; redirects are never followed."""
 def __init__(self,*,timeout_seconds:float=5.0,ssl_context:ssl.SSLContext|None=None):
  if not isinstance(timeout_seconds,(int,float)) or isinstance(timeout_seconds,bool) or not math.isfinite(timeout_seconds) or not 0<timeout_seconds<=30: raise NodeRuntimeError("HTTP timeout invalid")
  self.timeout=float(timeout_seconds);self.context=ssl_context
 def _token(self,ref:Mapping[str,str])->str:
  if set(ref)!={"token_file"} or not isinstance(ref["token_file"],str): raise NodeRuntimeError("only injected token_file authentication is supported")
  path=Path(ref["token_file"])
  if not path.is_absolute() or not safe_chain(path) or not path.is_file(): raise NodeRuntimeError("token file reference unsafe")
  value=path.read_text(encoding="utf-8").strip()
  if not value or not value.isascii() or len(value)>4096 or any(c.isspace() for c in value): raise NodeRuntimeError("token file invalid")
  return value
 def _request(self,method,endpoint,route,body,ref):
  parsed=urlsplit(endpoint)
  if not isinstance(route,str) or not route.startswith("/") or "?" in route or "#" in route: raise NodeRuntimeError("control route invalid")
  loopback=parsed.hostname in {"127.0.0.1","localhost","::1"}
  if parsed.scheme not in ({"https","http"} if loopback else {"https"}) or not parsed.hostname or parsed.path not in {"","/"} or parsed.username or parsed.password or parsed.query or parsed.fragment: raise NodeRuntimeError("endpoint must be HTTPS or loopback HTTP origin")
  token=self._token(ref); raw=None if body is None else json.dumps(dict(body),separators=(",",":"),allow_nan=False).encode()
  if raw is not None and len(raw)>MAX_TELEMETRY_BYTES*2: raise NodeRuntimeError("control request exceeds bound")
  connection=http.client.HTTPSConnection(parsed.hostname,parsed.port,timeout=self.timeout,context=self.context) if parsed.scheme=="https" else http.client.HTTPConnection(parsed.hostname,parsed.port,timeout=self.timeout)
  try:
   headers={"Authorization":"Bearer "+token,"Accept":"application/json"}
   if raw is not None: headers|={"Content-Type":"application/json","Content-Length":str(len(raw))}
   connection.request(method,route,raw,headers);response=connection.getresponse();data=response.read(MAX_TELEMETRY_BYTES*2+1)
   if response.status not in {200,202} or len(data)>MAX_TELEMETRY_BYTES*2: raise NodeRuntimeError("Management control request was not accepted")
   value=json.loads(data.decode("utf-8"))
   if not isinstance(value,Mapping): raise NodeRuntimeError("Management control response invalid")
   return dict(value)
  except (OSError,ValueError,UnicodeDecodeError,json.JSONDecodeError) as error:
   if isinstance(error,NodeRuntimeError): raise
   raise NodeRuntimeError("Management control transport unavailable") from error
  finally: connection.close()
 def post(self,endpoint,route,payload,*,token_reference): return self._request("POST",endpoint,route,payload,token_reference)
 def get(self,endpoint,route,*,token_reference): return self._request("GET",endpoint,route,None,token_reference)
def ident(value:object,name:str)->str:
 if not isinstance(value,str) or not value or len(value)>128 or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_." for c in value): raise NodeRuntimeError(f"{name} is invalid")
 return value
def parse_time(value:object,now:datetime)->tuple[str,datetime]:
 if not isinstance(value,str) or len(value)>64: raise NodeRuntimeError("timestamp must be RFC3339 UTC")
 try: point=datetime.fromisoformat(value.replace("Z","+00:00"))
 except ValueError as error: raise NodeRuntimeError("timestamp must be RFC3339 UTC") from error
 if point.tzinfo is None or point.utcoffset()!=timezone.utc.utcoffset(point) or point>now: raise NodeRuntimeError("timestamp must be UTC and not future")
 return value,point
def safe_chain(path:Path)->bool:
 p=path.absolute()
 while True:
  if p.is_symlink(): return False
  if p==p.parent: return True
  p=p.parent
@dataclass(frozen=True)
class NodeRuntimeConfig:
 hardware_node_id:str; boot_id:str; workspace_root:Path; endpoints:tuple[Mapping[str,Any],...]; advertised_capabilities:tuple[str,...]; heartbeat_interval_seconds:int; token_file:Path|None=None; registration:Mapping[str,Any]|None=None; provider_endpoint:str|None=None; provider_token_file:Path|None=None; provider_manifest:Mapping[str,Any]|None=None
 @classmethod
 def from_mapping(cls,v:Mapping[str,Any])->"NodeRuntimeConfig":
  keys={"hardware_node_id","boot_id","local_workspace_root","management_endpoints","advertised_capabilities","heartbeat_interval_seconds","management_credential","registration","provider_management_endpoint","provider_management_credential","provider_manifest"}
  required={"hardware_node_id","boot_id","local_workspace_root","management_endpoints","advertised_capabilities","heartbeat_interval_seconds","management_credential"}
  if not isinstance(v,Mapping) or not required.issubset(v) or not set(v).issubset(keys): raise NodeRuntimeError("config keys must exactly match schema")
  eps,caps,cred=v["management_endpoints"],v["advertised_capabilities"],v["management_credential"]
  if not isinstance(eps,list) or not eps or not isinstance(caps,list) or not caps or not isinstance(cred,Mapping) or set(cred)!={"token_file"} or not isinstance(cred.get("token_file"),str): raise NodeRuntimeError("config collections are invalid")
  f=cred["token_file"]; provider=(v.get("provider_management_endpoint"),v.get("provider_management_credential"),v.get("provider_manifest"))
  if any(x is not None for x in provider) and (not all(x is not None for x in provider) or not isinstance(provider[0],str) or not isinstance(provider[1],Mapping) or set(provider[1])!={"token_file"} or not isinstance(provider[1].get("token_file"),str) or not isinstance(provider[2],Mapping)): raise NodeRuntimeError("provider enrollment configuration is incomplete")
  return cls(ident(v["hardware_node_id"],"hardware_node_id"),ident(v["boot_id"],"boot_id"),Path(v["local_workspace_root"]),tuple(eps),tuple(ident(x,"capability") for x in caps),v["heartbeat_interval_seconds"],Path(f),v.get("registration"),provider[0],Path(provider[1]["token_file"]) if provider[1] else None,provider[2])
 def __post_init__(self):
  if type(self.heartbeat_interval_seconds) is not int or not 1<=self.heartbeat_interval_seconds<=3600: raise NodeRuntimeError("heartbeat interval invalid")
  if not self.workspace_root.is_absolute() or not safe_chain(self.workspace_root) or not self.workspace_root.is_dir() or str(self.workspace_root).startswith("\\\\"): raise NodeRuntimeError("workspace root must be absolute local existing non-symlink")
  if self.token_file and (not self.token_file.is_absolute() or not safe_chain(self.token_file) or not self.token_file.is_file()): raise NodeRuntimeError("token file reference unsafe")
  if self.provider_endpoint is not None:
   parsed=urlsplit(self.provider_endpoint); loopback=parsed.hostname in {"127.0.0.1","localhost","::1"}
   if not parsed.hostname or parsed.path not in {"","/"} or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.scheme not in ({"https","http"} if loopback else {"https"}) or self.provider_token_file is None or not self.provider_token_file.is_absolute() or not safe_chain(self.provider_token_file) or not self.provider_token_file.is_file() or not isinstance(self.provider_manifest,Mapping) or self.provider_manifest.get("hardware_node_id")!=self.hardware_node_id or self.provider_manifest.get("host_boot_id")!=self.boot_id: raise NodeRuntimeError("provider enrollment configuration is unsafe")
  prior=-1; urls=set(); kinds=[]
  for x in self.endpoints:
   if not isinstance(x,Mapping) or set(x)!={"kind","priority","url"} or x["kind"] not in {"lan","tailnet"} or type(x["priority"]) is not int or x["priority"]<=prior: raise NodeRuntimeError("endpoint priority invalid")
   p=urlsplit(x["url"]) if isinstance(x["url"],str) else None
   if not p or p.scheme!="https" or not p.hostname or p.path not in {"","/"} or p.username or p.password or p.query or p.fragment: raise NodeRuntimeError("endpoint must be HTTPS origin")
   if x["url"] in urls: raise NodeRuntimeError("endpoint URLs must be unique")
   urls.add(x["url"]); kinds.append(x["kind"])
   prior=x["priority"]
  if "lan" in kinds and "tailnet" in kinds and any(kinds[index]=="tailnet" and "lan" in kinds[index+1:] for index in range(len(kinds))): raise NodeRuntimeError("all LAN endpoints must precede tailnet")
 @property
 def token_reference(self): return {"token_file":str(self.token_file)}
class NodeRuntime:
 def __init__(self,c:NodeRuntimeConfig,client:ManagementClient,*,clock:Callable[[],datetime]=lambda:datetime.now(timezone.utc)):
  self.config,self.client,self.clock=c,client,clock; self.sequence=0; self.state="NEW"; self.endpoint=None; self.route_evidence={}; self.last_local=None; self.last_management=None; self.uncertain=None
 def select_route(self,probe,reselect=False):
  if self.uncertain or (reselect and self.state in {"WITHDRAW_PENDING","WITHDRAW_UNKNOWN"}): raise NodeRuntimeError("reselection forbidden during uncertain effect")
  choices=[]
  for x in self.config.endpoints:
   r=probe(x)
   if not isinstance(r,Mapping) or r.get("endpoint")!=x["url"] or r.get("healthy") is not True or not isinstance(r.get("latency_ms"),(int,float)) or isinstance(r["latency_ms"],bool) or not math.isfinite(r["latency_ms"]) or r["latency_ms"]<0: continue
   try: _,point=parse_time(r.get("management_timestamp"),self.clock())
   except NodeRuntimeError: continue
   age=(self.clock()-point).total_seconds()
   if 0<=age<=MAX_PROBE_AGE_SECONDS: choices.append((x["priority"],r["latency_ms"],str(x["url"]).rstrip("/"),x["kind"],age))
  if not choices: raise NodeRuntimeError("no fresh healthy Management route")
  p,l,u,k,f=sorted(choices)[0]; self.endpoint=u; self.route_evidence={"endpoint":u,"kind":k,"priority":p,"latency_ms":l,"freshness_seconds":f}; return dict(self.route_evidence)
 def _time(self,x):
  text,point=parse_time(x,self.clock())
  if self.last_local and point<self.last_local: raise NodeRuntimeError("local timestamp regressed")
  self.last_local=point; return text
 def _management_time(self,x):
  # Remote acknowledgements may lead the node clock slightly; this must not
  # poison the local request clock.  Bound the tolerated skew independently.
  text,point=parse_time(x,self.clock()+timedelta(seconds=300))
  if self.last_management and point<self.last_management: raise NodeRuntimeError("Management timestamp regressed")
  self.last_management=point; return text
 def _post(self,op,t,oid,extra):
  if not self.endpoint: raise NodeRuntimeError("select a read-only healthy route first")
  payload={"hardware_node_id":self.config.hardware_node_id,"boot_id":self.config.boot_id,"timestamp":self._time(t),"sequence":self.sequence,"operation_id":ident(oid,"operation_id")}|extra
  r=self.client.post(self.endpoint,ROUTES[op],payload,token_reference=self.config.token_reference)
  if not isinstance(r,Mapping): raise NodeRuntimeError("Management response invalid")
  return r
 def _ack(self,r,oid,state=None):
  if r.get("hardware_node_id")!=self.config.hardware_node_id or r.get("boot_id")!=self.config.boot_id or r.get("operation_id")!=oid or r.get("sequence")!=self.sequence or "management_timestamp" not in r: raise NodeRuntimeError("ack binding invalid")
  self._management_time(r["management_timestamp"])
  if state and r.get("state")!=state: raise NodeRuntimeError("ack state invalid")
 def register(self,t,oid):
  extra={"registration":dict(self.config.registration)} if isinstance(self.config.registration,Mapping) else {"capabilities":list(self.config.advertised_capabilities),"heartbeat_interval_seconds":self.config.heartbeat_interval_seconds}
  r=self._post("register",t,oid,extra); self._ack(r,oid,"registered"); self.state="REGISTERED"; return r
 def enroll_provider(self):
  if self.state!="REGISTERED" or self.config.provider_endpoint is None or self.config.provider_token_file is None or not isinstance(self.config.provider_manifest,Mapping): raise NodeRuntimeError("provider enrollment requires completed node registration")
  response=self.client.post(self.config.provider_endpoint,"/providers/register",{"manifest":dict(self.config.provider_manifest)},token_reference={"token_file":str(self.config.provider_token_file)})
  if not isinstance(response,Mapping) or response.get("provider_id")!=self.config.provider_manifest.get("provider_id") or type(response.get("generation")) is not int: raise NodeRuntimeError("provider enrollment acknowledgement invalid")
  return dict(response)
 def telemetry(self,v):
  if not isinstance(v,Mapping) or not v or set(v)-COMPONENTS: raise NodeRuntimeError("telemetry unsupported")
  for c in v.values():
   if not isinstance(c,Mapping) or set(c)!={"available","freshness_seconds","metrics"} or type(c["available"]) is not bool or not isinstance(c["freshness_seconds"],(int,float)) or isinstance(c["freshness_seconds"],bool) or not math.isfinite(c["freshness_seconds"]) or c["freshness_seconds"]<0 or not isinstance(c["metrics"],Mapping) or set(c["metrics"])-METRICS: raise NodeRuntimeError("telemetry invalid")
   for n in c["metrics"].values():
    if not isinstance(n,(int,float)) or isinstance(n,bool) or not math.isfinite(n) or n<0: raise NodeRuntimeError("telemetry metric invalid")
  if len(json.dumps(v,sort_keys=True,separators=(",",":"),allow_nan=False).encode())>MAX_TELEMETRY_BYTES: raise NodeRuntimeError("telemetry exceeds bound")
 def heartbeat(self,t,oid,v):
  if self.state not in {"REGISTERED","HEALTHY","PAUSE_REQUESTED"}: raise NodeRuntimeError("heartbeat requires registration")
  self.telemetry(v); r=self._post("heartbeat",t,oid,{"telemetry":dict(v)}); self._ack(r,oid); self.sequence+=1; cmd=r.get("command","continue")
  if cmd=="pause": self.state="PAUSE_REQUESTED"
  elif cmd=="continue": self.state="HEALTHY"
  else: raise NodeRuntimeError("heartbeat command invalid")
  return r
 def withdraw(self,t,oid,receipt):
  if self.state!="PAUSE_REQUESTED" or not isinstance(receipt,Mapping) or set(receipt)!={"kind","receipt_id","timestamp"} or receipt["kind"] not in {"checkpoint","no_work"}: raise NodeRuntimeError("withdraw requires pause and checkpoint/no-work receipt")
  # A checkpoint receipt is evidence from another producer, not a local
  # request timestamp; validate it without moving the local request clock.
  ident(receipt["receipt_id"],"receipt_id"); parse_time(receipt["timestamp"],self.clock()); self.state="WITHDRAW_PENDING"
  try: r=self._post("withdraw",t,oid,{"receipt":dict(receipt)}); self._ack(r,oid,"withdrawn")
  except Exception: self.state="WITHDRAW_UNKNOWN"; self.uncertain=oid; raise
  self.state="WITHDRAWN"; return r
 def reconcile_withdraw(self,oid):
  if self.state!="WITHDRAW_UNKNOWN" or oid!=self.uncertain or not self.endpoint: raise NodeRuntimeError("only original uncertain withdrawal reconciles")
  r=self.client.get(self.endpoint,ROUTES["withdraw"]+"/"+oid,token_reference=self.config.token_reference); self._ack(r,oid,"withdrawn"); self.state="WITHDRAWN"; self.uncertain=None; return r
def main(argv=None):
 p=argparse.ArgumentParser(); p.add_argument("--config",type=Path,required=True); p.add_argument("--operation",choices=("install","configure","register","health","withdraw"),required=True); p.add_argument("--apply",action="store_true"); a=p.parse_args(argv)
 try:
  if not safe_chain(a.config) or not a.config.is_file(): raise NodeRuntimeError("config path unsafe")
  c=NodeRuntimeConfig.from_mapping(json.loads(a.config.read_text()))
 except (OSError,json.JSONDecodeError,NodeRuntimeError) as e: print(f"node-runtime configuration rejected: {e}",file=sys.stderr); return 1
 print(json.dumps({"dry_run":not a.apply,"operation":a.operation,"hardware_node_id":c.hardware_node_id,"routes":ROUTES,"credential_reference":"token_file" if c.token_file else "token_env"},sort_keys=True))
 if a.apply: print("apply is intentionally unavailable: inject a reviewed authenticated Management client; no service was started.",file=sys.stderr); return 2
 return 0
if __name__=="__main__": raise SystemExit(main())
