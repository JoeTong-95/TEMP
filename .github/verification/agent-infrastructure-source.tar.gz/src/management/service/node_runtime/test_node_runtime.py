import importlib.util, sys, tempfile, threading, unittest, subprocess, os, shutil
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).parent; s=importlib.util.spec_from_file_location("nr",ROOT/"node_runtime.py"); nr=importlib.util.module_from_spec(s); sys.modules["nr"]=nr; s.loader.exec_module(nr)
NOW=datetime(2026,9,5,tzinfo=timezone.utc)
def cfg(root,eps=None):
 token=root/"node.token";token.write_text("node-token\n")
 return nr.NodeRuntimeConfig.from_mapping({"hardware_node_id":"node-a","boot_id":"boot-a","local_workspace_root":str(root),"management_endpoints":eps or [{"kind":"lan","priority":1,"url":"https://lan.example"},{"kind":"tailnet","priority":2,"url":"https://tail.example"}],"advertised_capabilities":["agent-runtime"],"heartbeat_interval_seconds":10,"management_credential":{"token_file":str(token)}})
def ack(oid,seq,state=None,command=None):
 r={"hardware_node_id":"node-a","boot_id":"boot-a","operation_id":oid,"sequence":seq,"management_timestamp":"2026-09-05T00:00:00Z"}
 if state:r["state"]=state
 if command:r["command"]=command
 return r
class C:
 def __init__(self,replies):self.replies=list(replies);self.posts=[];self.gets=[]
 def post(self,*a,**k):self.posts.append((a,k));r=self.replies.pop(0);return (_ for _ in ()).throw(r) if isinstance(r,Exception) else (r() if callable(r) else r)
 def get(self,*a,**k):self.gets.append((a,k));return self.replies.pop(0)
class T(unittest.TestCase):
 def test_tailnet_only_and_lan_selection_evidence(self):
  with tempfile.TemporaryDirectory() as d:
   probe=lambda e:{"endpoint":e["url"],"healthy":True,"latency_ms":2,"management_timestamp":"2026-09-05T00:00:00Z"}
   r=nr.NodeRuntime(cfg(Path(d),[{"kind":"tailnet","priority":1,"url":"https://tail.example"}]),C([]),clock=lambda:NOW); self.assertEqual("tailnet",r.select_route(probe)["kind"])
   r=nr.NodeRuntime(cfg(Path(d)),C([]),clock=lambda:NOW); self.assertEqual("https://lan.example",r.select_route(lambda e:{"endpoint":e["url"],"healthy":True,"latency_ms":50 if e["kind"]=="lan" else 1,"management_timestamp":"2026-09-05T00:00:00Z"})["endpoint"])
 def test_ack_pause_checkpoint_withdraw_and_reconcile_no_duplicate_post(self):
  with tempfile.TemporaryDirectory() as d:
   c=C([ack("reg",0,"registered"),ack("hb",0,command="pause"),OSError("lost"),ack("wd",1,"withdrawn")]); r=nr.NodeRuntime(cfg(Path(d)),c,clock=lambda:NOW); r.select_route(lambda e:{"endpoint":e["url"],"healthy":True,"latency_ms":1,"management_timestamp":"2026-09-05T00:00:00Z"});r.register("2026-09-05T00:00:00Z","reg");r.heartbeat("2026-09-05T00:00:00Z","hb",{"cpu":{"available":False,"freshness_seconds":0,"metrics":{}}})
   with self.assertRaises(OSError):r.withdraw("2026-09-05T00:00:00Z","wd",{"kind":"checkpoint","receipt_id":"r1","timestamp":"2026-09-05T00:00:00Z"})
   self.assertEqual("WITHDRAW_UNKNOWN",r.state);r.reconcile_withdraw("wd");self.assertEqual(3,len(c.posts));self.assertEqual(1,len(c.gets))
 def test_negative_config_timestamps_and_telemetry(self):
  with tempfile.TemporaryDirectory() as d:
   bad={"hardware_node_id":"n","boot_id":"b","local_workspace_root":d,"management_endpoints":[{"kind":"lan","priority":1,"url":"http://bad"}],"advertised_capabilities":["x"],"heartbeat_interval_seconds":1,"management_credential":{"token_env":"X"},"extra":1}
   with self.assertRaises(nr.NodeRuntimeError):nr.NodeRuntimeConfig.from_mapping(bad)
   r=nr.NodeRuntime(cfg(Path(d)),C([ack("r",0,"registered")]),clock=lambda:NOW);r.select_route(lambda e:{"endpoint":e["url"],"healthy":True,"latency_ms":1,"management_timestamp":"2026-09-05T00:00:00Z"});r.register("2026-09-05T00:00:00Z","r")
   with self.assertRaises(nr.NodeRuntimeError):r.heartbeat("2026-09-05T01:00:00Z","h",{"cpu":{"available":True,"freshness_seconds":0,"metrics":{"utilization":float("nan")}}})
   with self.assertRaises(nr.NodeRuntimeError):r.heartbeat("2026-09-05T00:00:00Z","h2",{"cpu":{"available":False,"freshness_seconds":True,"metrics":{}}})
   with self.assertRaises(nr.NodeRuntimeError):r.withdraw("2026-09-05T00:00:00Z","w",{"kind":"checkpoint","receipt_id":"r","timestamp":"bad"})
 def test_management_clock_skew_does_not_reject_next_local_request(self):
  with tempfile.TemporaryDirectory() as d:
   later="2026-09-05T00:00:10Z"; client=C([{**ack("register",0,"registered"),"management_timestamp":later},{**ack("heartbeat",0,command="continue"),"management_timestamp":"2026-09-05T00:00:11Z"}]);runtime=nr.NodeRuntime(cfg(Path(d)),client,clock=lambda:NOW+__import__('datetime').timedelta(seconds=11))
   runtime.select_route(lambda e:{"endpoint":e["url"],"healthy":True,"latency_ms":1,"management_timestamp":"2026-09-05T00:00:00Z"});runtime.register("2026-09-05T00:00:00Z","register")
   runtime.heartbeat("2026-09-05T00:00:01Z","heartbeat",{"cpu":{"available":False,"freshness_seconds":0,"metrics":{}}})
 def test_isolated_second_node_enrolls_against_loopback_management(self):
  from management.management_api import ManagementApiConfig,Principal
  from management.management_service import DatabaseLocations,ManagementServiceConfig,build_management_service
  from management.node_control_api import NodeControlConfig,serve
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); node_token=root/'node.token'; provider_token=root/'provider.token';node_token.write_text('node-token');provider_token.write_text('provider-token');node_token.chmod(0o600);provider_token.chmod(0o600)
   service=build_management_service(ManagementServiceConfig(DatabaseLocations(*[root/(x+'.sqlite') for x in ('hardware','providers','grants','projects')]),ManagementApiConfig({'provider-token':Principal('provider-a','provider',providers=frozenset({'provider-a'}))})))
   control=serve(service.hardware,NodeControlConfig({node_token:'node-a'}));control_thread=threading.Thread(target=control.serve_forever);control_thread.start()
   api_thread=threading.Thread(target=service.api_server.serve_forever);api_thread.start()
   try:
    registration={'node_id':'node-a','node_identity':{'public_key_fingerprint':'key-a','host_boot_id':'boot-a','platform':'linux','architecture':'x86_64'},'capabilities':['inference.text'],'working_root':{'path':'/synthetic/node-a','persistent':True,'isolated_task_directories':True},'private_endpoints':[{'service':'runtime','uri':'https://node-a.internal','authentication_required':True}],'resource_limits':{'cpu_cores':2,'memory_bytes':2048,'storage_bytes':2048},'observed_at':'2026-09-05T00:00:00Z'}
    manifest={'provider_id':'provider-a','hardware_node_id':'node-a','host_boot_id':'boot-a','role':'inference','capabilities':['inference.text'],'build_digest':'build-a','configuration_hash':'config-a','compatibility_fingerprint':'contract-a','private_endpoint':'https://provider-a.internal'}
    config=nr.NodeRuntimeConfig.from_mapping({'hardware_node_id':'node-a','boot_id':'boot-a','local_workspace_root':str(root),'management_endpoints':[{'kind':'lan','priority':1,'url':'https://management.invalid'}],'advertised_capabilities':['inference.text'],'heartbeat_interval_seconds':10,'management_credential':{'token_file':str(node_token)},'registration':registration,'provider_management_endpoint':'http://127.0.0.1:'+str(service.api_server.server_address[1]),'provider_management_credential':{'token_file':str(provider_token)},'provider_manifest':manifest})
    runtime=nr.NodeRuntime(config,nr.NodeRuntimeHttpClient());runtime.endpoint='http://127.0.0.1:'+str(control.server_address[1]);runtime.register('2026-09-05T00:00:00Z','enroll-node');provider=runtime.enroll_provider()
    self.assertEqual('provider-a',provider['provider_id']);self.assertEqual('node-a',service.hardware.get_snapshot('node-a')['node_id'])
   finally:
    control.shutdown();service.api_server.shutdown();control_thread.join(2);api_thread.join(2);control.server_close();service.api_server.server_close()
 @unittest.skipUnless(shutil.which('sh'), 'POSIX shell unavailable on this host')
 def test_bootstrap_check_apply_and_rollback_metadata(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); env={**os.environ,'NODE_RUNTIME_PACKAGE_DIR':str(ROOT),'NODE_RUNTIME_INSTALL_ROOT':str(root/'install'),'NODE_RUNTIME_DATA_ROOT':str(root/'data')}; script=str(ROOT/'bootstrap.sh')
   self.assertIn('dry-run',subprocess.run(['sh',script,'check'],env=env,text=True,capture_output=True,check=True).stdout)
   self.assertIn('not started',subprocess.run(['sh',script,'install','--apply'],env=env,text=True,capture_output=True,check=True).stdout)
   self.assertNotEqual(0,subprocess.run(['sh',script,'rollback','--apply'],env=env,text=True,capture_output=True).returncode)
if __name__=="__main__":unittest.main()
