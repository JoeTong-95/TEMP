"""Validation-first composed-stack launcher/checker.

This module never discovers secrets, roots, or services.  It composes only
operator-named external configuration files and deliberately does not stop,
replace, or inspect the historical pilot.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from management.management_service import load_service_config
from storage.storage_runtime_bundle_service import load_configuration as load_storage_config
from storage.shared_memory_service import load_config as load_memory_config
from management.project_assignment_worker import load_assignment_configuration
from storage.merge_authority_http_service import load_http_scopes
from storage.merge_authority_service import build_from_config
from management.node_control_service import load_config as load_node_config
from agent_runtime.hermes_runtime_service import load_configuration as load_hermes_config
from storage.verification_service import load_configuration as load_verification_config
from management.project_pipeline_worker import load_pipeline_configuration
from storage.code_review_issuer_service import load_issuer_configuration
from agent_runtime.attended_chat_service import load_configuration as load_attended_chat_config
from management.static_ui_host import load_configuration as load_ui_host_config
from management.weekly_report_worker import load_job_config as load_reporting_job_config
from management.management_executor import load_executor_config


class CompositionError(ValueError):
    pass


_REQUIRED = {
    "schema", "management_config", "storage_config", "shared_memory_config",
    "assignment_executor_config", "merge_authority_config", "merge_http_config",
    "node_control_config", "hermes_runtime_config", "verification_service_config",
    "review_issuer_config", "project_pipeline_config", "attended_chat_config",
    "ui_host_config", "reporting_worker_config", "hermes_port", "verification_port",
    "attended_chat_port", "ui_port", "management_executor_config", "prefect_api_origin", "prefect_health_path",
}

# These names are the composition-owned installation plan.  They deliberately
# do not replace similarly named historical or component-local service units.
_UNIT_PLAN = {
    "management": "agent-stack-composed-management.service",
    "storage": "agent-stack-composed-storage.service",
    "shared_memory": "agent-stack-composed-shared-memory.service",
    "merge_review": "agent-stack-composed-merge-review.service",
    "node_control": "agent-stack-composed-node-control.service",
    "hermes_runtime": "agent-stack-composed-hermes-runtime.service",
    "verification": "agent-stack-composed-verification.service",
    "review_issuer": "agent-stack-composed-review-issuer.service",
    "assignment_execution": "agent-stack-composed-assignment-executor.service",
    "project_pipeline": "agent-stack-composed-project-pipeline.service",
    "attended_chat": "agent-stack-attended-chat.service",
    "ui": "agent-stack-ui.service",
    "reporting": "agent-stack-reporting.service",
    "management_executor": "agent-stack-management-executor.service",
}

@dataclass(frozen=True)
class CompositionConfig:
    files: Mapping[str, Path]
    ports: Mapping[str, int]
    prefect_api_origin: str
    prefect_health_path: str


def _external_file(value: Any, label: str) -> Path:
    path = Path(value) if isinstance(value, str) else Path("")
    if not path.is_absolute() or not path.is_file() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise CompositionError(f"{label} must be an existing absolute non-symlink file")
    return path


def load_composition(path: str | Path) -> CompositionConfig:
    source = _external_file(path, "composition configuration")
    try:
        raw = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise CompositionError("composition configuration is invalid JSON") from error
    if not isinstance(raw, Mapping) or set(raw) != _REQUIRED or raw.get("schema") != "agent-stack.composition":
        raise CompositionError("composition configuration schema is invalid")
    files={key: _external_file(raw[key], key) for key in _REQUIRED - {"schema","hermes_port","verification_port","attended_chat_port","ui_port","prefect_api_origin","prefect_health_path"}}
    ports: dict[str,int]={}
    for key in ("hermes_port","verification_port","attended_chat_port","ui_port"):
        if type(raw[key]) is not int or not 1<=raw[key]<=65535: raise CompositionError(f"{key} is invalid")
        ports[key]=raw[key]
    origin, health=raw["prefect_api_origin"],raw["prefect_health_path"]
    if not isinstance(origin,str) or not origin.startswith(("https://","http://")) or not isinstance(health,str) or not health.startswith("/") or "?" in health or "#" in health: raise CompositionError("Prefect API binding is invalid")
    return CompositionConfig(files,ports,origin,health)


def _port_from_json(path: Path, field: str) -> int:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping) or type(raw.get(field)) is not int or not 1 <= raw[field] <= 65535:
        raise CompositionError(f"{path.name} has no valid {field}")
    return raw[field]


def validate(config_path: str | Path) -> tuple[dict[str, Path], dict[str, int]]:
    composition = load_composition(config_path); files = composition.files
    management = load_service_config(files["management_config"])
    if management.databases.catalog is None:
        raise CompositionError("management configuration must provide a separate catalog database")
    if management.runtime_control is None:
        raise CompositionError("management configuration must provide runtime control")
    load_storage_config(files["storage_config"])
    load_memory_config(files["shared_memory_config"])
    load_assignment_configuration(files["assignment_executor_config"])
    build_from_config(files["merge_authority_config"])
    load_http_scopes(files["merge_http_config"])
    _, node = load_node_config(files["node_control_config"])
    load_hermes_config(files["hermes_runtime_config"])
    load_verification_config(files["verification_service_config"])
    load_pipeline_configuration(files["project_pipeline_config"])
    attended = load_attended_chat_config(files["attended_chat_config"])
    ui = load_ui_host_config(files["ui_host_config"])
    load_reporting_job_config(files["reporting_worker_config"])
    load_executor_config(files["management_executor_config"])
    if attended.port != composition.ports["attended_chat_port"] or ui.host != "127.0.0.1" or ui.port != composition.ports["ui_port"]:
        raise CompositionError("attended and UI listener contracts must match composition ports")
    if ui.management_origin != f"http://127.0.0.1:{management.api.port}" or ui.attended_origin != f"http://127.0.0.1:{attended.port}":
        raise CompositionError("UI gateway upstreams must match configured loopback services")
    _, review_port=load_issuer_configuration(files["verification_service_config"],files["review_issuer_config"])
    ports = {
        "management": management.api.port,
        "storage": _port_from_json(files["storage_config"], "port"),
        "shared_memory": _port_from_json(files["shared_memory_config"], "listen_port"),
        "merge_review": _port_from_json(files["merge_http_config"], "listen_port"),
        "node_control": node.port,
        "hermes_runtime": composition.ports["hermes_port"], "verification":composition.ports["verification_port"],
        "attended_chat":composition.ports["attended_chat_port"], "ui":composition.ports["ui_port"],
        "review_issuer":review_port,
    }
    if len(set(ports.values())) != len(ports):
        raise CompositionError("component ports must be unique and isolated")
    return files, ports


def _reachable(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def readiness(config_path: str | Path, *, probe: Callable[[int], bool] = _reachable) -> dict[str, Any]:
    files, ports = validate(config_path)
    components = {name: {"configured": True, "live_proven": probe(port), "port": port} for name, port in ports.items()}
    components["assignment_execution"] = {"configured": True, "live_proven": False, "reason": "one-tick executor is intentionally not run by readiness"}
    components["catalog_provider_registry"] = {"configured": True, "live_proven": False, "reason": "requires registered node/provider and fresh grant evidence"}
    components["prefect"] = {"configured": True, "live_proven": False, "origin": load_composition(config_path).prefect_api_origin, "health_path": load_composition(config_path).prefect_health_path, "reason": "dedicated external Prefect service is not probed by loopback readiness"}
    listener_state = "listeners-reachable-not-accepted" if all(components[name]["live_proven"] for name in ports) else "configured-not-live-proven"
    return {"schema": "agent-stack.composition-readiness", "configured": True,
            # Do not inherit a historical pilot's status.  This launcher has no
            # authority to stop, replace, or certify that independent process.
            "historical_pilot_status": "not_inspected",
            "composed_replacement_status": listener_state,
            "components": components,
            "unit_plan": dict(_UNIT_PLAN),
            "launch_commands": [
                ["python", "-m", "management.management_service", "--config", str(files["management_config"])],
                ["python", "-m", "storage.storage_runtime_bundle_service", "--config", str(files["storage_config"])],
                ["python", "-m", "storage.shared_memory_service", "--config", str(files["shared_memory_config"])],
                ["python", "-m", "storage.merge_authority_http_service", "--authority-config", str(files["merge_authority_config"]), "--http-config", str(files["merge_http_config"])],
                ["python", "-m", "management.node_control_service", "--config", str(files["node_control_config"])],
                ["python", "-m", "agent_runtime.hermes_runtime_service", "--config", str(files["hermes_runtime_config"]), "--port", str(ports["hermes_runtime"])],
                ["python", "-m", "storage.verification_service", "--config", str(files["verification_service_config"]), "--port", str(ports["verification"])],
                ["python", "-m", "agent_runtime.attended_chat_service", "--config", str(files["attended_chat_config"])],
                ["python", "-m", "management.static_ui_host", "--config", str(files["ui_host_config"])],
                ["python", "-m", "management.project_pipeline_worker", "--config", str(files["project_pipeline_config"])],
                ["python", "-m", "storage.code_review_issuer_service", "--verification-config", str(files["verification_service_config"]), "--issuer-config", str(files["review_issuer_config"])],
                ["python", "-m", "management.weekly_report_worker", "--config", str(files["reporting_worker_config"])],
                ["python", "-m", "management.management_executor", "--config", str(files["management_executor_config"])],
            ],
            "gaps": ["TCP reachability proves only a listener accepted a connection, not authenticated endpoint semantics.", "No assignment, merge, provider registration, or historical-pilot mutation is performed by this checker."]}


def _write_report_once(destination: Path, report: Mapping[str, Any]) -> None:
    """Publish a complete report without replacing an existing evidence file."""
    if not destination.is_absolute() or not destination.parent.is_dir() or destination.is_symlink():
        raise CompositionError("report destination must be under an existing absolute directory")
    descriptor, temporary = tempfile.mkstemp(prefix=".pending-composition-report-", dir=destination.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(report, handle, sort_keys=True, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        try:
            # link() fails when destination already exists, unlike replace().
            os.link(temporary, destination)
        except FileExistsError as error:
            raise CompositionError("report destination already exists") from error
        except OSError as error:
            raise CompositionError("report could not be published atomically") from error
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="validate and report isolated Agent Stack composition")
    parser.add_argument("--config", required=True)
    parser.add_argument("--report", help="optional JSON report output; parent must already exist")
    parser.add_argument("--print-launch", action="store_true", help="print operator-reviewed component commands; never start them")
    args = parser.parse_args(argv)
    report = readiness(args.config)
    if args.report:
        destination = Path(args.report)
        _write_report_once(destination, report)
    print(json.dumps(report["launch_commands"] if args.print_launch else report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
