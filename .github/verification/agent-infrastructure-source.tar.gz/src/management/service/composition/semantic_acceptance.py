"""Bounded composed-stack acceptance reporter; live effects require --live."""
from __future__ import annotations
import argparse, hashlib, http.client, json
from pathlib import Path
from typing import Any, Mapping

STEPS=("management_auth","storage","shared_memory","node_provider_health","catalog_admission","project_orchestrator_assignment","hermes_execution","verification_review_merge")

def _call(step: Mapping[str,Any]) -> dict[str,Any]:
    required={"base_url","token_file","path","payload"}
    if set(step)!=required or not isinstance(step["base_url"],str) or not isinstance(step["token_file"],str) or not isinstance(step["path"],str) or not isinstance(step["payload"],Mapping): raise ValueError("live step schema is invalid")
    token_path=Path(step["token_file"])
    if not token_path.is_absolute() or not token_path.is_file() or token_path.is_symlink(): raise ValueError("live step token file is unsafe")
    token=token_path.read_text(encoding="utf-8").strip()
    if not token or not token.isascii() or any(c.isspace() for c in token): raise ValueError("live step token is invalid")
    from urllib.parse import urlsplit
    parsed=urlsplit(step["base_url"]); loopback=parsed.hostname in {"127.0.0.1","localhost","::1"}
    if not parsed.hostname or parsed.path not in {"","/"} or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.scheme not in ({"http","https"} if loopback else {"https"}) or not step["path"].startswith("/"): raise ValueError("live step endpoint is unsafe")
    body=json.dumps(dict(step["payload"]),sort_keys=True,separators=(",",":"),allow_nan=False).encode(); connection=(http.client.HTTPSConnection if parsed.scheme=="https" else http.client.HTTPConnection)(parsed.hostname,parsed.port,timeout=5)
    try:
        connection.request("POST",step["path"],body,{"Authorization":"Bearer "+token,"Content-Type":"application/json","Content-Length":str(len(body))}); response=connection.getresponse();raw=response.read(65537)
    finally: connection.close()
    if len(raw)>65536 or response.status not in {200,202}: raise ValueError("live step was not accepted")
    decoded=json.loads(raw.decode("utf-8"));
    if not isinstance(decoded,Mapping): raise ValueError("live step receipt is invalid")
    return {"state":"passed","request_sha256":hashlib.sha256(body).hexdigest(),"receipt_sha256":hashlib.sha256(raw).hexdigest(),"http_status":response.status}

def report(config: Path, *, live: bool) -> dict[str, Any]:
    if not config.is_absolute() or not config.is_file() or config.is_symlink(): raise ValueError("external composition config is required")
    raw=json.loads(config.read_text(encoding="utf-8"))
    if not isinstance(raw,Mapping) or raw.get("schema")!="agent-stack.composition": raise ValueError("composition schema is invalid")
    required={"management_config","storage_config","shared_memory_config","assignment_executor_config","merge_authority_config","merge_http_config","node_control_config"}
    if not required.issubset(raw) or any(not isinstance(raw[key],str) or not Path(raw[key]).is_absolute() or not Path(raw[key]).is_file() for key in required): raise ValueError("all explicit component configurations are required")
    declared=raw.get("live_steps",{})
    if not isinstance(declared,Mapping): raise ValueError("live_steps must be an object")
    rows=[]
    for name in STEPS:
        if not live: rows.append({"name":name,"state":"not_run","reason":"rerun with --live after operator starts reviewed disabled units"})
        elif name not in declared: rows.append({"name":name,"state":"blocked","reason":"missing explicit HTTP endpoint/token-file/payload declaration"})
        else:
            try: rows.append({"name":name}|_call(declared[name]))
            except (OSError,ValueError,UnicodeDecodeError,json.JSONDecodeError) as error: rows.append({"name":name,"state":"blocked","reason":str(error)})
    return {"schema":"agent-stack.composed-acceptance","historical_pilot_status":"not_inspected","composed_replacement_status":"ready-for-human-qc" if all(row["state"]=="passed" for row in rows) else "not_accepted","steps":rows,"gaps":["No service was installed, started, enabled, or stopped by this runner.","Missing HTTP endpoints: shared-memory health/readiness and catalog admission are not currently standardized; owner: Storage/Management API contracts."]}

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument("--config",required=True);p.add_argument("--live",action="store_true");p.add_argument("--report",required=True);a=p.parse_args(argv)
    result=report(Path(a.config),live=a.live); output=Path(a.report)
    if not output.is_absolute() or output.exists() or not output.parent.is_dir(): raise ValueError("report must be an absent file under an existing external directory")
    output.write_text(json.dumps(result,sort_keys=True,indent=2)+"\n",encoding="utf-8"); print(json.dumps(result,sort_keys=True));return 0
if __name__=="__main__": raise SystemExit(main())
