import importlib.util,json,tempfile,unittest,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).parent;spec=importlib.util.spec_from_file_location('acceptance',ROOT/'semantic_acceptance.py');acceptance=importlib.util.module_from_spec(spec);spec.loader.exec_module(acceptance)
class AcceptanceTests(unittest.TestCase):
 def test_configured_stack_is_not_misreported_as_accepted(self):
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory); keys=['management_config','storage_config','shared_memory_config','assignment_executor_config','merge_authority_config','merge_http_config','node_control_config']; raw={'schema':'agent-stack.composition'}
   for key in keys: path=root/(key+'.json');path.write_text('{}');raw[key]=str(path)
   config=root/'composition.json';config.write_text(json.dumps(raw));report=acceptance.report(config,live=False)
   self.assertEqual('not_accepted',report['composed_replacement_status']);self.assertEqual('not_inspected',report['historical_pilot_status']);self.assertTrue(all(item['state']=='not_run' for item in report['steps']))
 def test_live_http_sequence_hashes_receipts_without_tokens(self):
  class Handler(BaseHTTPRequestHandler):
   def do_POST(self):
    self.rfile.read(int(self.headers['Content-Length'])); raw=b'{"receipt":"synthetic"}';self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
   def log_message(self,*_):pass
  server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever);thread.start()
  try:
   with tempfile.TemporaryDirectory() as directory:
    root=Path(directory); token=root/'token';token.write_text('external-token');keys=['management_config','storage_config','shared_memory_config','assignment_executor_config','merge_authority_config','merge_http_config','node_control_config'];raw={'schema':'agent-stack.composition'}
    for key in keys: path=root/(key+'.json');path.write_text('{}');raw[key]=str(path)
    step={'base_url':'http://127.0.0.1:'+str(server.server_address[1]),'token_file':str(token),'path':'/synthetic','payload':{'fixture':True}};raw['live_steps']={name:step for name in acceptance.STEPS};config=root/'composition.json';config.write_text(json.dumps(raw));report=acceptance.report(config,live=True)
    self.assertEqual('ready-for-human-qc',report['composed_replacement_status']);self.assertTrue(all('receipt_sha256' in item and 'external-token' not in json.dumps(item) for item in report['steps']))
  finally: server.shutdown();thread.join(2);server.server_close()
