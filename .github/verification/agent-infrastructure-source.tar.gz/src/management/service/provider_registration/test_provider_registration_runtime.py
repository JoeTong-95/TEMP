from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("provider_registration_runtime", ROOT / "provider_registration_runtime.py")
runtime = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(runtime)


def manifest(role: str = "inference") -> dict[str, object]:
    return {
        "provider_id": "qwen-gateway-steven" if role == "inference" else "hermes-runtime-steven",
        "hardware_node_id": "steven",
        "host_boot_id": "boot-2026-09-05",
        "role": role,
        "capabilities": ["inference.chat"] if role == "inference" else ["runtime.control"],
        "build_digest": "sha256:build",
        "configuration_hash": "sha256:config",
        "compatibility_fingerprint": "qwen3_default_no_thinking" if role == "inference" else "hermes-runtime-contract",
        "private_endpoint": "http://127.0.0.1:18100/v1" if role == "inference" else "http://127.0.0.1:18425",
    }


class FakeClient:
    def __init__(self):
        self.calls: list[tuple[str, str, dict[str, object] | None]] = []

    def request(self, endpoint, method, token_file=None, ca_file=None, body=None):
        self.calls.append((method, endpoint, dict(body) if body else None))
        if endpoint.endswith("/providers/register"):
            return 200, {"provider_id": body["manifest"]["provider_id"], "generation": 3}
        if endpoint.endswith("/capacity"):
            return 200, {"accepted": True}
        if endpoint.endswith("/health"):
            return 200, {"accepted": True}
        return 200, {"status": "ok"}


class ProviderRegistrationRuntimeTests(unittest.TestCase):
    def config(self, root: Path, *, capacity: object = None, role: str = "inference") -> dict[str, object]:
        token = root / "management.token"
        token.write_text("management-secret", encoding="utf-8")
        health_token = root / "health.token"
        health_token.write_text("gateway-secret", encoding="utf-8")
        if os.name == "posix":
            token.chmod(0o600)
            health_token.chmod(0o600)
        result: dict[str, object] = {
            "management_endpoint": "http://127.0.0.1:18420",
            "management_token_file": str(token),
            "provider_manifest": manifest(role),
            "health": {"url": "http://127.0.0.1:18100/v1/models", "token_file": str(health_token), "expected_statuses": [200]},
            "capacity": capacity,
            "heartbeat_interval_seconds": 10,
            "lease_seconds": 30,
        }
        return result

    def test_config_requires_private_separate_token_and_restricts_role(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "provider.json"
            config_path.write_text(json.dumps(self.config(root)), encoding="utf-8")
            value = runtime.load_config(config_path)
            self.assertEqual("qwen-gateway-steven", value["provider_manifest"]["provider_id"])
            self.assertNotIn("management-secret", repr(value))
            bad = self.config(root, role="storage")
            config_path.write_text(json.dumps(bad), encoding="utf-8")
            with self.assertRaises(runtime.ProviderRegistrationError):
                runtime.load_config(config_path)

    def test_once_registers_reports_measured_capacity_then_renews_health(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            capacity_token = root / "capacity.token"
            capacity_token.write_text("capacity-secret", encoding="utf-8")
            if os.name == "posix":
                capacity_token.chmod(0o600)
            config = self.config(root, capacity={"url": "http://127.0.0.1:18101/capacity", "pool_id": "gpu0", "token_file": str(capacity_token)})
            client = FakeClient()
            original = runtime._capacity
            runtime._capacity = lambda _client, _config: {"pool_id": "gpu0", "quantities": {"gpu0.vram_bytes": 5_000_000_000}, "observed_at": "2026-09-05T12:00:00Z"}
            try:
                runtime.run(config, once=True, client=client)
            finally:
                runtime._capacity = original
            self.assertTrue(client.calls[0][1].endswith("/providers/register"))
            self.assertTrue(any(call[1].endswith("/providers/qwen-gateway-steven/capacity") for call in client.calls))
            health = [call for call in client.calls if call[1].endswith("/providers/qwen-gateway-steven/health")][0]
            self.assertEqual("healthy", health[2]["status"])
            self.assertEqual(3, health[2]["expected_generation"])
            self.assertNotIn("management-secret", repr(client.calls))

    def test_invalid_capacity_quantities_fail_closed(self):
        with self.assertRaises(runtime.ProviderRegistrationError):
            runtime._finite_quantities({"gpu": float("nan")})
        with self.assertRaises(runtime.ProviderRegistrationError):
            runtime._finite_quantities({"gpu": -1})

    def test_credential_rejects_all_ascii_controls_without_echoing_them(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for control in ("\x00", "\x01", "\x1f", "\x7f"):
                token = root / "token"
                token.write_text("valid" + control + "secret", encoding="utf-8")
                with self.assertRaises(runtime.ProviderRegistrationError) as raised:
                    runtime.HttpClient().request("http://127.0.0.1:1", "GET", token)
                self.assertNotIn(control, str(raised.exception))

    def test_credential_keeps_exact_4096_byte_boundary(self):
        with tempfile.TemporaryDirectory() as directory:
            token = Path(directory) / "token"
            token.write_text("a" * runtime.MAX_TOKEN_BYTES, encoding="ascii")
            self.assertEqual("a" * runtime.MAX_TOKEN_BYTES, runtime._read_token(token))

    def test_credential_rejects_oversized_and_multibyte_files_without_echoing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for raw in (b"a" * (runtime.MAX_TOKEN_BYTES + 1), "é".encode("utf-8")):
                token = root / "token"
                token.write_bytes(raw)
                with self.assertRaises(runtime.ProviderRegistrationError) as raised:
                    runtime._read_token(token)
                self.assertNotIn(raw[:16].decode("utf-8", errors="ignore"), str(raised.exception))

    @unittest.skipUnless(os.name == "posix", "POSIX mode checks are not applicable on Windows")
    def test_permissive_management_token_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "provider.json"
            config_path.write_text(json.dumps(self.config(root)), encoding="utf-8")
            (root / "management.token").chmod(0o644)
            with self.assertRaises(runtime.ProviderRegistrationError):
                runtime.load_config(config_path)


if __name__ == "__main__":
    unittest.main()
