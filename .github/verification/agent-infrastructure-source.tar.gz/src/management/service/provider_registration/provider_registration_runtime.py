"""Config-driven provider enrollment and Management lease worker.

This process is deliberately a transport adapter.  It never opens a
Management database, starts a provider, or invents capacity.  A provider-local
health endpoint proves readiness; an optional provider-local capacity endpoint
supplies measured quantities which are then submitted through the authenticated
provider-scoped Management API.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import http.client
import json
import math
import os
from pathlib import Path
import ssl
import sys
import time
from typing import Any, Callable, Mapping
from urllib.parse import urlsplit

from shared.contracts.credentials import MAX_SECRET_BYTES, SecretValidationError, read_bounded_secret

MAX_BODY_BYTES = 64 * 1024
MAX_TOKEN_BYTES = MAX_SECRET_BYTES
_ROLES = {"inference", "agent-runtime"}


class ProviderRegistrationError(ValueError):
    pass


def safe_chain(path: Path) -> bool:
    candidate = path.absolute()
    while True:
        if candidate.is_symlink():
            return False
        if candidate == candidate.parent:
            return True
        candidate = candidate.parent


def _origin(value: object, *, loopback_http: bool) -> tuple[str, str, int | None, str]:
    parsed = urlsplit(value if isinstance(value, str) else "")
    loopback = parsed.hostname in {"127.0.0.1", "localhost", "::1"}
    allowed = {"https"} | ({"http"} if loopback_http and loopback else set())
    if (
        parsed.scheme not in allowed
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or (parsed.path and not parsed.path.startswith("/"))
    ):
        raise ProviderRegistrationError("endpoint must be HTTPS or loopback HTTP without credentials or query")
    if parsed.scheme != "http" and not _private_host(parsed.hostname):
        raise ProviderRegistrationError("non-loopback endpoint must use a private host")
    return parsed.scheme, parsed.hostname, parsed.port, parsed.path or "/"


def _private_host(host: str) -> bool:
    import ipaddress

    try:
        address = ipaddress.ip_address(host)
        return address.is_private or address.is_loopback or address in ipaddress.ip_network("100.64.0.0/10")
    except ValueError:
        lowered = host.lower().rstrip(".")
        return "." not in lowered or lowered.endswith((".internal", ".local", ".ts.net"))


def _private_file(path: object, label: str, *, required: bool = True) -> Path | None:
    if not isinstance(path, str) or not path:
        if not required and path is None:
            return None
        raise ProviderRegistrationError(f"{label} is required")
    candidate = Path(path)
    if not candidate.is_absolute() or not safe_chain(candidate) or not candidate.is_file():
        raise ProviderRegistrationError(f"{label} is unsafe")
    if os.name == "posix" and candidate.stat().st_mode & 0o077:
        raise ProviderRegistrationError(f"{label} must be owner-only")
    return candidate.resolve(strict=True)


def _read_token(path: Path) -> str:
    try:
        return read_bounded_secret(path, max_bytes=MAX_TOKEN_BYTES)
    except OSError as error:
        raise ProviderRegistrationError("credential file is unavailable") from error
    except (UnicodeDecodeError, SecretValidationError) as error:
        raise ProviderRegistrationError("credential file is invalid") from error


def _identifier(value: object, label: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 128 or any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_." for char in value):
        raise ProviderRegistrationError(f"{label} is invalid")
    return value


def _timestamp(value: object, *, now: datetime | None = None) -> str:
    if not isinstance(value, str) or len(value) > 64:
        raise ProviderRegistrationError("timestamp must be RFC3339 with timezone")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise ProviderRegistrationError("timestamp must be RFC3339 with timezone") from error
    if parsed.tzinfo is None:
        raise ProviderRegistrationError("timestamp must include timezone")
    if parsed > (now or datetime.now(timezone.utc)):
        raise ProviderRegistrationError("timestamp cannot be in the future")
    return parsed.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _finite_quantities(value: object) -> dict[str, int | float]:
    if not isinstance(value, Mapping) or not value or len(value) > 64:
        raise ProviderRegistrationError("capacity quantities must be a non-empty object")
    result: dict[str, int | float] = {}
    for name, quantity in value.items():
        if not isinstance(name, str) or not name or len(name) > 128 or isinstance(quantity, bool) or not isinstance(quantity, (int, float)) or not math.isfinite(quantity) or quantity < 0:
            raise ProviderRegistrationError("capacity quantities must be finite non-negative numbers")
        result[name] = quantity
    return result


def load_config(path: Path, token_override: Path | None = None) -> dict[str, Any]:
    if not path.is_absolute() or not safe_chain(path) or not path.is_file():
        raise ProviderRegistrationError("configuration file is unsafe")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ProviderRegistrationError("configuration must be UTF-8 JSON") from error
    allowed = {"management_endpoint", "management_token_file", "provider_manifest", "health", "capacity", "heartbeat_interval_seconds", "lease_seconds", "expected_generation", "timeout_seconds"}
    required = {"management_endpoint", "management_token_file", "provider_manifest", "health", "heartbeat_interval_seconds", "lease_seconds"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or set(raw) - allowed:
        raise ProviderRegistrationError("configuration keys are invalid")
    _origin(raw["management_endpoint"], loopback_http=True)
    manifest = raw["provider_manifest"]
    if not isinstance(manifest, Mapping) or manifest.get("role") not in _ROLES:
        raise ProviderRegistrationError("provider manifest role must be inference or agent-runtime")
    for field in ("provider_id", "hardware_node_id", "host_boot_id", "build_digest", "configuration_hash", "compatibility_fingerprint", "private_endpoint"):
        if not isinstance(manifest.get(field), str) or not manifest[field]:
            raise ProviderRegistrationError("provider manifest identity/provenance is incomplete")
    _identifier(manifest["provider_id"], "provider_id")
    capabilities = manifest.get("capabilities")
    if not isinstance(capabilities, list) or not capabilities or not all(isinstance(item, str) and item for item in capabilities):
        raise ProviderRegistrationError("provider capabilities must be a non-empty string list")
    _origin(manifest["private_endpoint"], loopback_http=True)
    management_token = _private_file(str(token_override), "Management token file") if token_override is not None else _private_file(raw["management_token_file"], "Management token file")
    assert management_token is not None
    _read_token(management_token)
    health = raw["health"]
    if not isinstance(health, Mapping) or not {"url"}.issubset(health) or set(health) - {"url", "token_file", "ca_file", "expected_statuses"}:
        raise ProviderRegistrationError("health configuration is invalid")
    _origin(health["url"], loopback_http=True)
    health_token = _private_file(health.get("token_file"), "health token file", required=False)
    ca_file = _private_file(health.get("ca_file"), "health CA file", required=False)
    if health_token is None and health.get("token_file") is not None:
        raise ProviderRegistrationError("health token file is invalid")
    if ca_file is None and health.get("ca_file") is not None:
        raise ProviderRegistrationError("health CA file is invalid")
    statuses = health.get("expected_statuses", [200])
    if not isinstance(statuses, list) or not statuses or not all(type(item) is int and 100 <= item <= 599 for item in statuses):
        raise ProviderRegistrationError("health expected_statuses is invalid")
    capacity = raw.get("capacity")
    if capacity is not None:
        if not isinstance(capacity, Mapping) or set(capacity) - {"url", "pool_id", "token_file", "ca_file"} or not {"url", "pool_id"}.issubset(capacity):
            raise ProviderRegistrationError("capacity configuration is invalid")
        _origin(capacity["url"], loopback_http=True)
        _identifier(capacity["pool_id"], "capacity pool_id")
        if capacity.get("token_file") is not None:
            _read_token(_private_file(capacity["token_file"], "capacity token file") or Path(""))
        if capacity.get("ca_file") is not None:
            _private_file(capacity["ca_file"], "capacity CA file")
    for name, minimum, maximum in (("heartbeat_interval_seconds", 1, 300), ("lease_seconds", 5, 300)):
        if type(raw[name]) is not int or not minimum <= raw[name] <= maximum:
            raise ProviderRegistrationError(f"{name} is invalid")
    if raw["heartbeat_interval_seconds"] >= raw["lease_seconds"]:
        raise ProviderRegistrationError("heartbeat interval must be less than lease")
    timeout = raw.get("timeout_seconds", 5.0)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 30:
        raise ProviderRegistrationError("timeout_seconds is invalid")
    if "expected_generation" in raw and (type(raw["expected_generation"]) is not int or raw["expected_generation"] <= 0):
        raise ProviderRegistrationError("expected_generation is invalid")
    value = dict(raw)
    value["management_token_file"] = str(management_token)
    value["health"] = {**dict(health), "token_file": str(health_token) if health_token else None, "ca_file": str(ca_file) if ca_file else None, "expected_statuses": statuses}
    return value


class HttpClient:
    def __init__(self, timeout_seconds: float = 5.0):
        self.timeout = timeout_seconds

    def request(self, endpoint: str, method: str, token_file: Path | None = None, ca_file: Path | None = None, body: Mapping[str, Any] | None = None) -> tuple[int, dict[str, Any] | None]:
        scheme, host, port, path = _origin(endpoint, loopback_http=True)
        raw = None if body is None else json.dumps(dict(body), separators=(",", ":"), allow_nan=False).encode("utf-8")
        if raw is not None and len(raw) > MAX_BODY_BYTES:
            raise ProviderRegistrationError("request body exceeds bound")
        headers = {"Accept": "application/json"}
        if token_file is not None:
            headers["Authorization"] = "Bearer " + _read_token(token_file)
        if raw is not None:
            headers.update({"Content-Type": "application/json", "Content-Length": str(len(raw))})
        context = ssl.create_default_context(cafile=str(ca_file)) if scheme == "https" else None
        connection = http.client.HTTPSConnection(host, port, timeout=self.timeout, context=context) if scheme == "https" else http.client.HTTPConnection(host, port, timeout=self.timeout)
        try:
            connection.request(method, path, raw, headers)
            response = connection.getresponse()
            payload = response.read(MAX_BODY_BYTES + 1)
            if len(payload) > MAX_BODY_BYTES:
                raise ProviderRegistrationError("endpoint response exceeds bound")
            if not payload:
                return response.status, None
            value = json.loads(payload.decode("utf-8"))
            if not isinstance(value, Mapping):
                raise ProviderRegistrationError("endpoint response is not an object")
            return response.status, dict(value)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ssl.SSLError) as error:
            raise ProviderRegistrationError("provider or Management transport is unavailable") from error
        finally:
            connection.close()


def _capacity(client: HttpClient, config: Mapping[str, Any]) -> dict[str, Any] | None:
    declaration = config.get("capacity")
    if declaration is None:
        return None
    status, payload = client.request(declaration["url"], "GET", _path_or_none(declaration.get("token_file")), _path_or_none(declaration.get("ca_file")))
    if status != 200 or not isinstance(payload, Mapping):
        raise ProviderRegistrationError("capacity endpoint is not ready")
    quantities = _finite_quantities(payload.get("quantities"))
    pool_id = payload.get("pool_id", declaration["pool_id"])
    if pool_id != declaration["pool_id"]:
        raise ProviderRegistrationError("capacity endpoint returned the wrong pool")
    observed_at = payload.get("observed_at", utc_now())
    return {"pool_id": pool_id, "quantities": quantities, "observed_at": _timestamp(observed_at)}


def _path_or_none(value: object) -> Path | None:
    return Path(value) if isinstance(value, str) and value else None


def run(config: Mapping[str, Any], *, once: bool = False, client: HttpClient | None = None, sleep: Callable[[float], None] = time.sleep) -> None:
    transport = client or HttpClient(float(config.get("timeout_seconds", 5.0)))
    manifest = dict(config["provider_manifest"])
    provider_id = manifest["provider_id"]
    management_token = Path(config["management_token_file"])
    management = str(config["management_endpoint"]).rstrip("/")
    registration = {"manifest": manifest}
    if "expected_generation" in config:
        registration["expected_generation"] = config["expected_generation"]
    status, enrolled = transport.request(management + "/providers/register", "POST", management_token, body=registration)
    if status != 200 or not isinstance(enrolled, Mapping) or enrolled.get("provider_id") != provider_id or type(enrolled.get("generation")) is not int:
        raise ProviderRegistrationError("provider registration was rejected")
    generation = enrolled["generation"]
    health = config["health"]
    while True:
        healthy = False
        try:
            health_status, _ = transport.request(health["url"], "GET", _path_or_none(health.get("token_file")), _path_or_none(health.get("ca_file")))
            measured = _capacity(transport, config) if health_status in health["expected_statuses"] else None
            healthy = health_status in health["expected_statuses"] and (config.get("capacity") is None or measured is not None)
        except ProviderRegistrationError:
            measured = None
        if healthy and measured is not None:
            cap_status, _ = transport.request(management + f"/providers/{provider_id}/capacity", "POST", management_token, body=measured)
            healthy = cap_status == 200
        health_body = {"status": "healthy" if healthy else "unhealthy", "observed_at": utc_now(), "expected_generation": generation, "host_boot_id": manifest["host_boot_id"], "lease_seconds": config["lease_seconds"]}
        health_status, _ = transport.request(management + f"/providers/{provider_id}/health", "POST", management_token, body=health_body)
        if health_status != 200:
            raise ProviderRegistrationError("Management health lease was rejected")
        if once:
            return
        sleep(config["heartbeat_interval_seconds"])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Register one provider and renew its Management health lease.")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--management-token-file", type=Path, help="Optional explicit token-file override for reviewed deployment.")
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args(argv)
    try:
        run(load_config(args.config, args.management_token_file), once=args.once)
    except ProviderRegistrationError as error:
        print(f"provider registration worker failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
