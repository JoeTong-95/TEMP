"""Loopback-only Paperclip-to-Prefect dispatch boundary.

This deliberately accepts a pre-authorized immutable command envelope, not a
Paperclip webhook directly. The Paperclip adapter/auth binding and Prefect
deployment UUID are injected only by the root-owned service environment.
"""
from __future__ import annotations

import os
import hmac
import hashlib
import json
import logging
from pathlib import Path
from uuid import UUID

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, StrictInt
from prefect.deployments import run_deployment
from starlette.responses import Response
import httpx

from management.journal import CommandJournal, RequestConflict

_MAX_BODY_BYTES = 8 * 1024
_MAX_CAPABILITY_BYTES = 128
_UUID = r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
_LOG = logging.getLogger("agent_stack.paperclip_bridge")

class Dispatch(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    company_id: str = Field(min_length=36, max_length=36, pattern=_UUID)
    project_id: str = Field(min_length=36, max_length=36, pattern=_UUID)
    work_item_id: str = Field(min_length=36, max_length=36, pattern=_UUID)
    value: StrictInt = Field(ge=-1_000_000, le=1_000_000)

class PaperclipContext(BaseModel):
    # Paperclip's HTTP adapter supplies a full run context.  This boundary
    # admits only the bound taskId from it; rejecting its unrelated, evolving
    # status fields would make a valid native wake fail before dispatch.
    model_config = ConfigDict(extra="ignore", frozen=True)
    taskId: str = Field(min_length=36, max_length=36, pattern=_UUID)

class PaperclipDispatch(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    companyId: str = Field(min_length=36, max_length=36, pattern=_UUID)
    projectId: str = Field(min_length=36, max_length=36, pattern=_UUID)
    agentId: str = Field(min_length=36, max_length=36, pattern=_UUID)
    runId: str = Field(min_length=36, max_length=36, pattern=_UUID)
    context: PaperclipContext

def _env(name: str) -> str:
    value = os.environ.get(name, "")
    if not value: raise RuntimeError(f"missing {name}")
    return value

def _journal() -> CommandJournal:
    return CommandJournal(Path(_env("BRIDGE_JOURNAL_PATH")))

def _capability_matches(value: str) -> bool:
    supplied = value.encode("utf-8")
    expected = _env("BRIDGE_DISPATCH_CAPABILITY").encode("utf-8")
    return len(supplied) <= _MAX_CAPABILITY_BYTES and hmac.compare_digest(supplied, expected)

@app.middleware("http")
async def reject_untrusted_or_oversize(request: Request, call_next):
    """Authenticate before JSON parsing and bound request buffering."""
    if request.url.path not in {"/v1/dispatch", "/v1/paperclip-dispatch", "/v1/pilot-paperclip-dispatch"}:
        return Response(status_code=404)
    if not _capability_matches(request.headers.get("x-dispatch-capability", "")):
        return Response(status_code=401, content='{"detail":"invalid dispatch capability"}', media_type="application/json")
    declared_length = request.headers.get("content-length")
    if declared_length and (not declared_length.isdecimal() or int(declared_length) > _MAX_BODY_BYTES):
        return Response(status_code=413)
    chunks: list[bytes] = []
    size = 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > _MAX_BODY_BYTES:
            return Response(status_code=413)
        chunks.append(chunk)
    # ``call_next`` receives the same ASGI request; cache only the already
    # bounded bytes so FastAPI can parse them without a second unbounded read.
    request._body = b"".join(chunks)  # type: ignore[attr-defined]
    return await call_next(request)

async def _submit(company_id: str, project_id: str, work_item_id: str, value: int):
    workflow_hash = _env("BRIDGE_WORKFLOW_VERSION_HASH"); logical_project_id = _env("BRIDGE_LOGICAL_PROJECT_ID")
    material = f"{company_id}\n{project_id}\n{work_item_id}\n{logical_project_id}\n{workflow_hash}".encode()
    request_id = "pcp-" + hashlib.sha256(material).hexdigest()[:59]
    payload = {"paperclip_project_id": project_id, "project_id": logical_project_id, "value": value, "workflow_version_hash": workflow_hash}
    try: accepted = _journal().accept(request_id, {"company_id": company_id, "work_item_id": work_item_id}, payload)
    except RequestConflict as exc: raise HTTPException(409, str(exc)) from exc
    record = accepted.record
    if record.native_run_id: return {"request_id": record.request_id, "state": record.state, "prefect_flow_run_id": record.native_run_id, "replayed": True}
    claimant = "paperclip-prefect-bridge"
    claim = _journal().claim_dispatch(request_id, claimant)
    if not claim:
        record = _journal().get(request_id); return {"request_id": request_id, "state": record.state if record else "unknown", "replayed": True}
    try:
        flow_run = await run_deployment(name=_env("PREFECT_DEPLOYMENT_NAME"), parameters={"request_id": request_id, "project_id": logical_project_id, "value": value}, timeout=0, idempotency_key=request_id, as_subflow=False)
        run_id = str(flow_run.id); UUID(run_id); _journal().mark_submitted(request_id, claimant, claim.generation, run_id)
    except Exception as exc:
        _journal().mark_unknown(request_id, claimant, claim.generation, {"reason": type(exc).__name__}); raise HTTPException(503, "dispatch acknowledgement uncertain; reconcile request_id") from exc
    return {"request_id": request_id, "state": "submitted", "prefect_flow_run_id": run_id, "replayed": False}

@app.post("/v1/dispatch", status_code=202)
async def dispatch(body: Dispatch):
    if body.company_id != _env("BRIDGE_COMPANY_ID") or body.project_id != _env("BRIDGE_PROJECT_ID") or body.work_item_id != _env("BRIDGE_WORK_ITEM_ID"):
        raise HTTPException(403, "binding is not authorized")
    if body.value != int(_env("BRIDGE_VALUE")):
        raise HTTPException(409, "payload is not the published immutable fixture input")
    return await _submit(body.company_id, body.project_id, body.work_item_id, body.value)

@app.post("/v1/paperclip-dispatch", status_code=202)
async def paperclip_dispatch(body: PaperclipDispatch):
    if body.companyId != _env("BRIDGE_COMPANY_ID") or body.projectId != _env("BRIDGE_PROJECT_ID") or body.agentId != _env("BRIDGE_AGENT_ID") or body.context.taskId != _env("BRIDGE_WORK_ITEM_ID"):
        raise HTTPException(403, "native Paperclip binding is not authorized")
    return await _submit(body.companyId, body.projectId, body.context.taskId, int(_env("BRIDGE_VALUE")))

def _pilot_operator_token() -> str:
    path = Path(_env("BRIDGE_PILOT_OPERATOR_TOKEN_FILE"))
    try: value = path.read_text(encoding="utf-8").strip()
    except OSError as exc: raise RuntimeError("pilot operator token file unavailable") from exc
    if not value or len(value) > _MAX_CAPABILITY_BYTES: raise RuntimeError("pilot operator token invalid")
    return value

async def _pilot_submit(request_id: str, project_id: str, value: int, definition_hash: str) -> str:
    """Service-only call; no endpoint/token enters the durable journal payload."""
    url = _env("BRIDGE_PILOT_CONTROL_URL").rstrip("/") + "/v1/runs"
    async with httpx.AsyncClient(timeout=15.0, trust_env=False) as client:
        response = await client.post(url, headers={"Authorization":"Bearer " + _pilot_operator_token()}, json={"definition_hash":definition_hash,"project_id":project_id,"request_id":request_id,"value":value})
    if response.status_code >= 500: raise RuntimeError("pilot acknowledgement uncertain")
    if response.status_code != 200: raise HTTPException(409, "pilot submission rejected")
    result = response.json(); run_id = str(result.get("prefect_flow_run_id", "")); UUID(run_id)
    return run_id

async def _submit_pilot(company_id: str, project_id: str, work_item_id: str, value: int):
    definition_hash = _env("BRIDGE_PILOT_DEFINITION_HASH"); logical_project = _env("BRIDGE_PILOT_LOGICAL_PROJECT_ID")
    if value != int(_env("BRIDGE_PILOT_VALUE")): raise HTTPException(409, "payload is not the published immutable pilot input")
    material = f"pilot\n{company_id}\n{project_id}\n{work_item_id}\n{logical_project}\n{definition_hash}".encode()
    request_id = "pcp-pilot-" + hashlib.sha256(material).hexdigest()[:53]
    payload = {"paperclip_project_id":project_id,"project_id":logical_project,"value":value,"definition_hash":definition_hash}
    try: accepted = _journal().accept(request_id,{"company_id":company_id,"work_item_id":work_item_id},payload)
    except RequestConflict as exc: raise HTTPException(409,str(exc)) from exc
    record=accepted.record
    if record.native_run_id: return {"request_id":request_id,"state":record.state,"prefect_flow_run_id":record.native_run_id,"replayed":True,"pilot_status_path":"/v1/runs/"+record.native_run_id}
    claimant="paperclip-pilot-bridge"; claim=_journal().claim_dispatch(request_id,claimant)
    if not claim:
        record=_journal().get(request_id); return {"request_id":request_id,"state":record.state if record else "unknown","replayed":True}
    try:
        run_id=await _pilot_submit(request_id,logical_project,value,definition_hash)
        _journal().mark_submitted(request_id,claimant,claim.generation,run_id)
    except HTTPException: raise
    except Exception as exc:
        _journal().mark_unknown(request_id,claimant,claim.generation,{"reason":type(exc).__name__})
        raise HTTPException(503,"pilot dispatch acknowledgement uncertain; reconcile request_id") from exc
    return {"request_id":request_id,"state":"submitted","prefect_flow_run_id":run_id,"replayed":False,"pilot_status_path":"/v1/runs/"+run_id}

@app.post("/v1/pilot-paperclip-dispatch", status_code=202)
async def pilot_paperclip_dispatch(body: PaperclipDispatch):
    matches={"company":body.companyId == _env("BRIDGE_COMPANY_ID"),"project":body.projectId == _env("BRIDGE_PROJECT_ID"),"agent":body.agentId == _env("BRIDGE_PILOT_AGENT_ID"),"task":body.context.taskId == _env("BRIDGE_PILOT_WORK_ITEM_ID")}
    if not all(matches.values()):
        _LOG.warning("pilot Paperclip binding rejected matches=%s agent_sha12=%s",matches,hashlib.sha256(body.agentId.encode()).hexdigest()[:12])
        raise HTTPException(403,"native Paperclip binding is not authorized")
    return await _submit_pilot(body.companyId,body.projectId,body.context.taskId,int(_env("BRIDGE_PILOT_VALUE")))
