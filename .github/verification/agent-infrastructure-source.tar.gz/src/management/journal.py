"""Durable, bounded command correlation for workflow dispatch.

This module deliberately is *not* a workflow runner or scheduler.  Prefect (or
another selected workflow engine) remains authoritative for execution and retry.
The journal only makes a logical submission durable, binds it to a native run,
and records enough state to reconcile an acknowledgement that was lost in flight.

Callers must use a stable, server-created ``request_id``.  Reusing that id is
safe only with exactly the same scope and immutable JSON payload.  A deliberate
re-execution needs a new request id (and its own authority in the caller).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from contextlib import contextmanager
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import time
from typing import Any, Literal

from .state_boundary import ManagementStateBoundaryError, validate_durable_directory, validate_durable_leaf_with_missing_parents


State = Literal["accepted", "dispatching", "submitted", "unknown", "completed", "failed"]
_STATES = {"accepted", "dispatching", "submitted", "unknown", "completed", "failed"}
_TERMINAL = {"completed", "failed"}
_MAX_IDENTIFIER_BYTES = 200
_MAX_JSON_BYTES = 64 * 1024
_MAX_JSON_DEPTH = 32
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]*\Z")


class JournalError(RuntimeError):
    """Base error for journal misuse or a rejected state change."""


class RequestConflict(JournalError):
    """A request id was reused with another scope or immutable payload."""


class StaleTransition(JournalError):
    """A caller no longer owns the requested transition, or it is no longer valid."""


class CorruptJournal(JournalError):
    """Stored command data is malformed, noncanonical, or fails its integrity hash."""


@dataclass(frozen=True)
class CommandRecord:
    request_id: str
    scope: Any
    payload: Any
    payload_hash: str
    state: State
    native_run_id: str | None
    dispatch_claimant: str | None
    dispatch_generation: int
    created_at: str
    updated_at: str
    detail: Any | None


@dataclass(frozen=True)
class Submission:
    """The outcome of accepting a logical command."""

    record: CommandRecord
    created: bool


@dataclass(frozen=True)
class DispatchClaim:
    """A fenced, durable right to submit one native run.

    A claimant name alone is not a fence: a restarted dispatcher can reuse the
    same configured name.  The monotonically increasing generation is therefore
    required for every post-claim state change.
    """

    request_id: str
    claimant: str
    generation: int


def _identifier(value: str, name: str) -> str:
    if type(value) is not str or not value or len(value.encode("utf-8")) > _MAX_IDENTIFIER_BYTES or not _IDENTIFIER.fullmatch(value):
        raise ValueError(f"{name} must be a non-empty ASCII-safe identifier of at most {_MAX_IDENTIFIER_BYTES} bytes")
    return value


def _validate_json(value: Any, depth: int = 0) -> None:
    """Reject lossy JSON conversions before hashing or persisting a command."""
    if depth > _MAX_JSON_DEPTH:
        raise ValueError(f"JSON nesting exceeds {_MAX_JSON_DEPTH}")
    value_type = type(value)
    if value is None or value_type in (str, bool, int):
        return
    if value_type is float:
        if not math.isfinite(value):
            raise ValueError("JSON floats must be finite")
        return
    if value_type is list:
        for item in value:
            _validate_json(item, depth + 1)
        return
    if value_type is dict:
        for key, item in value.items():
            if type(key) is not str:
                raise ValueError("JSON object keys must be strings")
            _validate_json(item, depth + 1)
        return
    raise ValueError(f"unsupported JSON value type: {value_type.__name__}")


def _json(value: Any) -> str:
    """Return bounded, canonical, non-lossy JSON for durable command data."""
    _validate_json(value)
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    if len(encoded.encode("utf-8")) > _MAX_JSON_BYTES:
        raise ValueError(f"JSON value exceeds {_MAX_JSON_BYTES} bytes")
    return encoded


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class CommandJournal:
    """A SQLite-backed logical-command journal.

    Each public operation opens a short SQLite transaction, making it safe for
    independent dispatcher processes sharing the same database.  ``claim_dispatch``
    is compare-and-set: only the process changing ``accepted`` to ``dispatching``
    may submit the native run.  If acknowledgement is ambiguous, call
    ``mark_unknown`` and reconcile through the owning service; never claim again
    as a retry.
    """

    def __init__(self, database: str | Path) -> None:
        try:
            database_path = Path(database)
            validated, boundary = validate_durable_leaf_with_missing_parents(database_path, label="Management command journal database")
            validated.parent.mkdir(parents=True, exist_ok=True)
            validate_durable_directory(validated.parent, boundary, label="Management journal state directory")
            self.database = str(validated)
        except (ManagementStateBoundaryError, TypeError) as error:
            raise JournalError("command journal database is unsafe") from error
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database, timeout=10.0, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout = 10000")
        connection.execute("PRAGMA synchronous = FULL")
        return connection

    @contextmanager
    def _connection(self):
        """Close connections explicitly (important for temp DB cleanup on Windows)."""
        connection = self._connect()
        try:
            yield connection
        finally:
            connection.close()

    def _initialize(self) -> None:
        deadline = time.monotonic() + 10.0
        while True:
            try:
                with self._connection() as conn:
                    conn.execute("PRAGMA journal_mode = WAL")
                    # journal_mode is database-wide; explicitly retain FULL for this connection.
                    conn.execute("PRAGMA synchronous = FULL")
                    conn.execute("""
                        CREATE TABLE IF NOT EXISTS command_requests (
                            request_id TEXT PRIMARY KEY,
                            scope_json TEXT NOT NULL,
                            payload_json TEXT NOT NULL,
                            payload_hash TEXT NOT NULL,
                            state TEXT NOT NULL CHECK(state IN
                              ('accepted','dispatching','submitted','unknown','completed','failed')),
                            native_run_id TEXT UNIQUE,
                            dispatch_claimant TEXT,
                            dispatch_generation INTEGER NOT NULL DEFAULT 0,
                            created_at TEXT NOT NULL,
                            updated_at TEXT NOT NULL,
                            detail_json TEXT
                        )
                    """)
                    conn.execute("""
                        CREATE TABLE IF NOT EXISTS command_events (
                            sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                            request_id TEXT NOT NULL REFERENCES command_requests(request_id),
                            at TEXT NOT NULL,
                            event TEXT NOT NULL,
                            detail_json TEXT
                        )
                    """)
                    # Existing synthetic journals predate dispatch fencing.  A
                    # default preserves every historical row; only new claims
                    # receive a positive generation.  No live database is
                    # migrated by this source-only change.
                    columns = {row["name"] for row in conn.execute("PRAGMA table_info(command_requests)")}
                    if "dispatch_generation" not in columns:
                        conn.execute("ALTER TABLE command_requests ADD COLUMN dispatch_generation INTEGER NOT NULL DEFAULT 0")
                return
            except sqlite3.OperationalError as error:
                if "locked" not in str(error).lower() or time.monotonic() >= deadline:
                    raise
                time.sleep(0.05)

    @staticmethod
    def _record(row: sqlite3.Row) -> CommandRecord:
        """Decode and verify persisted immutable command input before exposing it."""
        try:
            scope = json.loads(row["scope_json"])
            payload = json.loads(row["payload_json"])
            scope_json, payload_json = _json(scope), _json(payload)
        except (TypeError, ValueError, json.JSONDecodeError) as error:
            raise CorruptJournal("stored scope or payload is malformed") from error
        if scope_json != row["scope_json"] or payload_json != row["payload_json"]:
            raise CorruptJournal("stored scope or payload is not canonical")
        calculated_hash = hashlib.sha256((scope_json + "\n" + payload_json).encode()).hexdigest()
        if row["payload_hash"] != calculated_hash:
            raise CorruptJournal("stored scope/payload hash does not verify")
        return CommandRecord(
            request_id=row["request_id"], scope=scope,
            payload=payload, payload_hash=calculated_hash,
            state=row["state"], native_run_id=row["native_run_id"],
            dispatch_claimant=row["dispatch_claimant"], dispatch_generation=row["dispatch_generation"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            detail=json.loads(row["detail_json"]) if row["detail_json"] is not None else None,
        )

    @staticmethod
    def _event(conn: sqlite3.Connection, request_id: str, event: str, detail: Any | None) -> None:
        conn.execute("INSERT INTO command_events(request_id, at, event, detail_json) VALUES (?, ?, ?, ?)",
                     (request_id, _utc_now(), event, _json(detail) if detail is not None else None))

    def accept(self, request_id: str, scope: Any, payload: Any) -> Submission:
        """Durably accept a command, or return its identical earlier submission."""
        _identifier(request_id, "request_id")
        scope_json, payload_json = _json(scope), _json(payload)
        payload_hash = hashlib.sha256((scope_json + "\n" + payload_json).encode()).hexdigest()
        now = _utc_now()
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM command_requests WHERE request_id = ?", (request_id,)).fetchone()
            if row is None:
                conn.execute("""INSERT INTO command_requests
                    (request_id, scope_json, payload_json, payload_hash, state, created_at, updated_at)
                    VALUES (?, ?, ?, ?, 'accepted', ?, ?)""",
                    (request_id, scope_json, payload_json, payload_hash, now, now))
                self._event(conn, request_id, "accepted", {"payload_hash": payload_hash})
                row = conn.execute("SELECT * FROM command_requests WHERE request_id = ?", (request_id,)).fetchone()
                conn.execute("COMMIT")
                return Submission(self._record(row), True)
            # Validate first: a corrupt duplicate must never be returned as a trusted replay.
            record = self._record(row)
            if row["scope_json"] != scope_json or row["payload_json"] != payload_json:
                conn.execute("ROLLBACK")
                raise RequestConflict("request_id is already bound to a different scope or payload")
            conn.execute("COMMIT")
            return Submission(record, False)

    def get(self, request_id: str) -> CommandRecord | None:
        _identifier(request_id, "request_id")
        with self._connection() as conn:
            row = conn.execute("SELECT * FROM command_requests WHERE request_id = ?", (request_id,)).fetchone()
            return self._record(row) if row else None

    def claim_dispatch(self, request_id: str, claimant: str) -> DispatchClaim | None:
        """Atomically acquire an accepted command and return its fence.

        ``None`` means another claimant owns the request or it is no longer
        accepted.  Claim expiry/reset is intentionally absent: a hard crash is
        resolved only by a trusted native receipt reconciliation.
        """
        _identifier(request_id, "request_id")
        _identifier(claimant, "claimant")
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            now = _utc_now()
            row = conn.execute("SELECT dispatch_generation FROM command_requests WHERE request_id=? AND state='accepted'",
                               (request_id,)).fetchone()
            generation = (int(row["dispatch_generation"]) + 1) if row is not None else None
            changed = conn.execute("""UPDATE command_requests
                SET state='dispatching', dispatch_claimant=?, dispatch_generation=?, updated_at=?
                WHERE request_id=? AND state='accepted'""", (claimant, generation, now, request_id)).rowcount
            if changed:
                self._event(conn, request_id, "dispatch_claimed", {"claimant": claimant, "generation": generation})
            conn.execute("COMMIT")
            return DispatchClaim(request_id, claimant, generation) if changed else None

    def mark_submitted(self, request_id: str, claimant: str, generation: int, native_run_id: str) -> CommandRecord:
        """Bind the claimant's dispatch to the authoritative native run id."""
        _identifier(request_id, "request_id")
        _identifier(claimant, "claimant")
        self._generation(generation)
        _identifier(native_run_id, "native_run_id")
        return self._transition(request_id, "submitted", claimant=claimant, generation=generation, native_run_id=native_run_id,
                                expected={"dispatching"}, event="submitted")

    def mark_unknown(self, request_id: str, claimant: str, generation: int, detail: Any) -> CommandRecord:
        """Record an ambiguous send.  This intentionally cannot be retried via claim_dispatch."""
        _identifier(request_id, "request_id")
        _identifier(claimant, "claimant")
        self._generation(generation)
        return self._transition(request_id, "unknown", claimant=claimant, generation=generation,
                                expected={"dispatching", "submitted"}, detail=detail, event="unknown")

    def reconcile_dispatch_receipt(self, request_id: str, claimant: str, generation: int,
                                   native_run_id: str, detail: Any | None = None) -> CommandRecord:
        """Bind an in-flight/unknown claim to a trusted native receipt.

        The caller must obtain the receipt from the native owner using the
        original request id as its idempotency key.  This journal deliberately
        cannot look up, create, retry, reset, or expire a native run.  Requiring
        the persisted claimant and generation prevents a stale dispatcher or a
        concurrent recovery worker from attaching a receipt to another claim.
        """
        _identifier(request_id, "request_id")
        _identifier(claimant, "claimant")
        self._generation(generation)
        _identifier(native_run_id, "native_run_id")
        return self._transition(request_id, "submitted", claimant=claimant, generation=generation,
                                expected={"dispatching", "unknown"}, native_run_id=native_run_id,
                                detail=detail, event="dispatch_receipt_reconciled")

    def reconcile_submission(self, request_id: str, native_run_id: str, detail: Any | None = None) -> CommandRecord:
        """Legacy reconciliation for pre-fence synthetic records only.

        New records must use :meth:`reconcile_dispatch_receipt`, which carries
        the persisted claimant/generation fence.  Retaining this narrow legacy
        path avoids changing historical synthetic journal rows during migration.
        """
        _identifier(request_id, "request_id")
        _identifier(native_run_id, "native_run_id")
        if self._is_fenced(request_id):
            raise StaleTransition("fenced dispatch requires claimant/generation receipt reconciliation")
        return self._transition(request_id, "submitted", expected={"unknown"}, native_run_id=native_run_id,
                                detail=detail, event="reconciled_submitted")

    def reconcile_outcome(self, request_id: str, state: Literal["completed", "failed"], detail: Any | None = None) -> CommandRecord:
        """Record an authoritative native outcome, including one found after uncertainty."""
        if state not in _TERMINAL:
            raise ValueError("reconciled outcome must be completed or failed")
        _identifier(request_id, "request_id")
        if self._is_fenced_unknown(request_id):
            raise StaleTransition("fenced unknown dispatch requires a native receipt before outcome reconciliation")
        return self._transition(request_id, state, expected={"submitted", "unknown"}, detail=detail, event="reconciled_" + state)

    def _is_fenced(self, request_id: str) -> bool:
        with self._connection() as conn:
            row = conn.execute("SELECT dispatch_generation FROM command_requests WHERE request_id=?", (request_id,)).fetchone()
            return row is not None and int(row["dispatch_generation"]) > 0

    def _is_fenced_unknown(self, request_id: str) -> bool:
        with self._connection() as conn:
            row = conn.execute("SELECT state, dispatch_generation FROM command_requests WHERE request_id=?", (request_id,)).fetchone()
            return row is not None and row["state"] == "unknown" and int(row["dispatch_generation"]) > 0

    def _transition(self, request_id: str, state: State, *, expected: set[str], event: str,
                    claimant: str | None = None, generation: int | None = None, native_run_id: str | None = None,
                    detail: Any | None = None) -> CommandRecord:
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM command_requests WHERE request_id = ?", (request_id,)).fetchone()
            if (row is None or row["state"] not in expected
                    or (claimant is not None and row["dispatch_claimant"] != claimant)
                    or (generation is not None and row["dispatch_generation"] != generation)):
                conn.execute("ROLLBACK")
                raise StaleTransition("request is absent, no longer in the expected state, or has another claimant")
            if native_run_id is not None and row["native_run_id"] not in (None, native_run_id):
                conn.execute("ROLLBACK")
                raise StaleTransition("native run id is immutable once bound")
            now = _utc_now()
            detail_json = _json(detail) if detail is not None else row["detail_json"]
            conn.execute("""UPDATE command_requests SET state=?, native_run_id=COALESCE(?, native_run_id),
                updated_at=?, detail_json=? WHERE request_id=?""",
                (state, native_run_id, now, detail_json, request_id))
            self._event(conn, request_id, event, detail)
            updated = conn.execute("SELECT * FROM command_requests WHERE request_id = ?", (request_id,)).fetchone()
            conn.execute("COMMIT")
            return self._record(updated)

    @staticmethod
    def _generation(value: int) -> int:
        if type(value) is not int or value < 1:
            raise ValueError("dispatch generation must be a positive integer")
        return value

    def events(self, request_id: str) -> list[tuple[str, str, Any | None]]:
        with self._connection() as conn:
            rows = conn.execute("SELECT at, event, detail_json FROM command_events WHERE request_id=? ORDER BY sequence", (request_id,)).fetchall()
        return [(r["at"], r["event"], json.loads(r["detail_json"]) if r["detail_json"] else None) for r in rows]
