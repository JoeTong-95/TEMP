"""Config-owned one-turn worker; Prefect may invoke it but never decides work."""
from __future__ import annotations
from dataclasses import dataclass
import argparse, json, math, re, os, stat
from pathlib import Path
from typing import Any, Mapping

from .project_orchestrator_driver import (AgentRuntimeAdapter, DriverConfiguration,
    HttpManagementAdapter, ProjectOrchestratorDriver, OrchestratorDriverError)
from shared.contracts.agent_runtime import RuntimeBinding, RuntimeClient

_SAFE=re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
class WorkerConfigError(ValueError): pass

def _safe_file(value: str) -> Path:
    path=Path(value)
    if not path.is_absolute() or any(part.is_symlink() for part in (path,*path.parents)) or not path.is_file(): raise WorkerConfigError("configured file is unavailable")
    if os.name == "posix":
        details=path.stat()
        if details.st_uid != os.getuid() or stat.S_IMODE(details.st_mode) & 0o077: raise WorkerConfigError("configured file is not private")
    return path
def _token(value: str) -> str:
    token=_safe_file(value).read_text(encoding="utf-8")
    if not token or token != token.strip() or len(token)>4096 or not token.isascii() or any(character.isspace() for character in token): raise WorkerConfigError("configured token is invalid")
    return token
def _origin(value: Any) -> str:
    from urllib.parse import urlsplit
    if not isinstance(value,str): raise WorkerConfigError("configured URL is invalid")
    parsed=urlsplit(value);loopback=parsed.hostname in {"127.0.0.1","::1","localhost"}
    if parsed.scheme not in {"https","http"} or (parsed.scheme=="http" and not loopback) or parsed.username or parsed.password or parsed.path.rstrip("/") or parsed.query or parsed.fragment: raise WorkerConfigError("configured URL is invalid")
    return value

@dataclass(frozen=True)
class WorkerProject:
    project_id:str; revision:int; intent_id:str; runtime:RuntimeBinding; agent_bindings:Mapping[str,frozenset[str]]; project_definition:Mapping[str,Any]
    def __post_init__(self)->None:
        if not isinstance(self.project_id,str) or _SAFE.fullmatch(self.project_id) is None or type(self.revision) is not int or self.revision<1 or not isinstance(self.intent_id,str) or _SAFE.fullmatch(self.intent_id) is None: raise WorkerConfigError("project worker configuration is invalid")
        try: DriverConfiguration(self.project_id,self.revision,self.runtime.session_id,self.runtime.binding_id,self.agent_bindings,self.project_definition)
        except (AttributeError,OrchestratorDriverError) as error: raise WorkerConfigError("project allowlists are invalid") from error

@dataclass(frozen=True)
class WorkerConfiguration:
    management_base_url:str; management_token_file:Path; projects:Mapping[str,WorkerProject]; timeout_seconds:float=5.0
    def __post_init__(self)->None:
        if _origin(self.management_base_url)!=self.management_base_url or _safe_file(str(self.management_token_file))!=self.management_token_file or not isinstance(self.projects,Mapping) or not self.projects or any(key!=value.project_id for key,value in self.projects.items()) or type(self.timeout_seconds) not in {int,float} or not math.isfinite(self.timeout_seconds) or not 0<self.timeout_seconds<=30: raise WorkerConfigError("worker configuration is invalid")

def load_configuration(path: str|Path) -> WorkerConfiguration:
    config_path=_safe_file(str(path))
    try: raw=json.loads(config_path.read_text(encoding="utf-8"),parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
    except (OSError,ValueError,json.JSONDecodeError) as error: raise WorkerConfigError("worker configuration is invalid") from error
    if not isinstance(raw,Mapping) or set(raw)!={"management_base_url","management_token_file","projects","timeout_seconds"} or not isinstance(raw.get("projects"),list) or not 1<=len(raw["projects"])<=128 or type(raw.get("timeout_seconds")) not in {int,float} or not math.isfinite(raw["timeout_seconds"]) or not 0<raw["timeout_seconds"]<=30: raise WorkerConfigError("worker configuration is invalid")
    projects={}
    for item in raw["projects"]:
        if not isinstance(item,Mapping) or set(item)!={"project_id","revision","intent_id","runtime","agent_bindings","project_definition"} or not isinstance(item.get("runtime"),Mapping) or set(item["runtime"])!={"binding_id","base_url","session_id","token_file"} or not isinstance(item.get("agent_bindings"),Mapping): raise WorkerConfigError("project worker configuration is invalid")
        runtime_raw=item["runtime"]
        try: runtime=RuntimeBinding(runtime_raw["binding_id"],_origin(runtime_raw["base_url"]),runtime_raw["session_id"],_token(runtime_raw["token_file"]),raw["timeout_seconds"])
        except (KeyError,ValueError) as error: raise WorkerConfigError("project runtime configuration is invalid") from error
        bindings={agent:frozenset(value) for agent,value in item["agent_bindings"].items() if isinstance(value,list)}
        if len(bindings)!=len(item["agent_bindings"]): raise WorkerConfigError("agent binding allowlist is invalid")
        project=WorkerProject(item["project_id"],item["revision"],item["intent_id"],runtime,bindings,item["project_definition"])
        if project.project_id in projects: raise WorkerConfigError("project ids must be unique")
        projects[project.project_id]=project
    return WorkerConfiguration(_origin(raw["management_base_url"]),_safe_file(raw["management_token_file"]),projects,raw["timeout_seconds"])

def run_one(configuration: WorkerConfiguration, project_id: str) -> dict[str,Any]:
    if not isinstance(project_id,str) or project_id not in configuration.projects: raise WorkerConfigError("configured project is required")
    project=configuration.projects[project_id]
    management=HttpManagementAdapter(configuration.management_base_url,_token(str(configuration.management_token_file)),project.intent_id,timeout_seconds=configuration.timeout_seconds)
    client=RuntimeClient({project.runtime.binding_id:project.runtime})
    runtime=AgentRuntimeAdapter(client,project_id=project.project_id,revision=project.revision,runtime_binding_id=project.runtime.binding_id)
    driver=ProjectOrchestratorDriver(DriverConfiguration(project.project_id,project.revision,project.runtime.session_id,project.runtime.binding_id,project.agent_bindings,project.project_definition),management,runtime)
    result=driver.step()
    # Assignment execution is intentionally not implied: assignments remain durable
    # Management records until an approved assignment-executor bridge reports progress.
    assignments=result.get("decision",{}).get("assignments",[]) if isinstance(result.get("decision"),Mapping) else []
    return {"project_id":project.project_id,"result":result,"recorded_assignments":assignments,"assignment_execution":"not_implemented"}

def prefect_run_one(config_path: str, project_id: str) -> dict[str,Any]:
    """Prefect-compatible callable: execution/run tracking only, no decision authority."""
    return run_one(load_configuration(config_path),project_id)

def main(argv: list[str]|None=None) -> int:
    parser=argparse.ArgumentParser();parser.add_argument("--config",required=True);parser.add_argument("--project",required=True);args=parser.parse_args(argv)
    print(json.dumps(prefect_run_one(args.config,args.project),sort_keys=True,separators=(",",":"),allow_nan=False));return 0
if __name__=="__main__":raise SystemExit(main())
