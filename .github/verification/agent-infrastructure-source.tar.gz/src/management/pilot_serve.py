"""Dedicated native Prefect deployment worker for the local pilot."""
from __future__ import annotations
from .pilot_flow import PREFECT_AVAILABLE, PilotFlowUnavailable, pilot_flow

def main() -> None:
    if not PREFECT_AVAILABLE:
        raise PilotFlowUnavailable('prefect==3.8.5 is required')
    pilot_flow.serve(name='local-v1', pause_on_shutdown=False, print_starting_message=True)

if __name__ == '__main__':
    main()
