"""Management layer: desired state, policy, orchestration, and projections.

The deliberately small public construction seam is the service configuration
loader plus the service object.  Other modules are private implementation or
process entrypoints even though compatibility imports remain available.
"""

__all__ = ("ManagementRoleIdentity", "ManagementService", "ManagementServiceConfig", "load_service_config")


def __getattr__(name: str):
    if name not in __all__:
        raise AttributeError(name)
    from . import management_service
    return getattr(management_service, name)
