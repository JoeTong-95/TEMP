"""Bounded, read-only GitHub issue-frontier ingestion."""
from __future__ import annotations
from datetime import datetime, timezone
import json, os, sqlite3
from pathlib import Path
from threading import RLock
from typing import Any, Callable, Iterable, Mapping, Protocol
from urllib.parse import quote, urlsplit

MAX_ISSUES=5000; MAX_TEXT=8192; MAX_BODY_BYTES=64*1024; MAX_SNAPSHOT=2*1024*1024
FRONTIER_SCHEMA="agent-stack.github-frontier"
_REPARSE_POINT=0x400
class GitHubFrontierError(ValueError): pass
class GitHubFrontierUnavailable(GitHubFrontierError): pass
class GitHubFrontierRateLimited(GitHubFrontierUnavailable): pass
class FrontierAdapter(Protocol):
 repository:str
 def pages(self)->Iterable[Iterable[Mapping[str,Any]]]:...
def _repo(value:Any)->str:
 if not isinstance(value,str): raise GitHubFrontierError("repository must be a GitHub HTTPS or SSH URL")
 p=urlsplit(value); bits=p.path.strip("/").removesuffix(".git").split("/")
 if p.scheme not in {"https","ssh"} or p.hostname!="github.com" or p.username or p.password or p.query or p.fragment or len(bits)!=2 or any(not x or len(x)>100 for x in bits): raise GitHubFrontierError("repository must be a GitHub HTTPS or SSH URL")
 return "https://github.com/"+"/".join(bits)
def _is_reparse_point(path:Path)->bool:
 if os.name!="nt":return False
 try:return bool(getattr(path.stat(follow_symlinks=False),"st_file_attributes",0)&_REPARSE_POINT)
 except (FileNotFoundError,NotADirectoryError):return False
 except OSError:return True
def _stamp(v:datetime)->str:return v.replace(tzinfo=v.tzinfo or timezone.utc).astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z")
def _text(v:Any,name:str,required:bool=False,maximum:int=MAX_TEXT)->str:
 if v is None and not required:return ""
 if not isinstance(v,str) or (required and not v.strip()) or len(v.encode())>maximum:raise GitHubFrontierError(f"issue {name} is invalid")
 return v
def _numbers(v:Any,name:str)->list[int]:
 if not isinstance(v,list) or len(v)>100 or any(type(x)is not int or x<1 for x in v):raise GitHubFrontierError(f"{name} references are invalid")
 return sorted(set(v))
def _labels(v:Any)->list[str]:
 if not isinstance(v,list):raise GitHubFrontierError("issue labels are invalid")
 out=[x.get("name") if isinstance(x,Mapping) else x for x in v]
 if any(not isinstance(x,str) or not x or len(x)>128 for x in out):raise GitHubFrontierError("issue labels are invalid")
 return sorted(set(out))
def _login(v:Any)->str|None:
 v=v.get("login") if isinstance(v,Mapping) else v
 if v is None:return None
 if not isinstance(v,str) or not v or len(v)>256:raise GitHubFrontierError("issue owner is invalid")
 return v
def _logins(v:Any)->list[str]:
 if not isinstance(v,list) or len(v)>100:raise GitHubFrontierError("issue owners are invalid")
 out=[]
 for item in v:
  login=_login(item)
  if login is None:raise GitHubFrontierError("issue owner is invalid")
  out.append(login)
 return sorted(set(out))
def _safe_json(value:Any,depth:int=0)->None:
 if depth>12:raise GitHubFrontierError("persisted frontier snapshot exceeds nesting bound")
 if isinstance(value,str):
  if len(value.encode())>MAX_BODY_BYTES:raise GitHubFrontierError("persisted frontier snapshot has oversized text")
 elif isinstance(value,list):
  if len(value)>MAX_ISSUES:raise GitHubFrontierError("persisted frontier snapshot has too many entries")
  for item in value:_safe_json(item,depth+1)
 elif isinstance(value,dict):
  if len(value)>100:raise GitHubFrontierError("persisted frontier snapshot has too many fields")
  for key,item in value.items():
   if not isinstance(key,str) or len(key)>128:raise GitHubFrontierError("persisted frontier snapshot has invalid keys")
   _safe_json(item,depth+1)
 elif value is not None and type(value) not in {int,float,bool}:raise GitHubFrontierError("persisted frontier snapshot has invalid values")

class HttpGitHubFrontierAdapter:
 def __init__(self,repository:str,request:Callable[[str],tuple[int,Any]],*,page_size:int=100,max_pages:int=10)->None:
  self.repository=_repo(repository);self.request=request
  if type(page_size)is not int or not 1<=page_size<=100 or type(max_pages)is not int or not 1<=max_pages<=20:raise GitHubFrontierError("pagination bounds are invalid")
  self.page_size,self.max_pages=page_size,max_pages; bits=urlsplit(self.repository).path.strip("/").split("/");self.base="/repos/{}/{}".format(*(quote(x,safe="") for x in bits))
 def read(self,path:str)->Any:
  try:status,body=self.request(path)
  except Exception as e:raise GitHubFrontierUnavailable("GitHub frontier transport is unavailable") from e
  if status in {429,403} and isinstance(body,Mapping) and "rate limit" in str(body.get("message","")).lower():raise GitHubFrontierRateLimited("GitHub rate limit reached")
  if status in {401,403}:raise GitHubFrontierUnavailable("GitHub authentication or access is unavailable")
  if not isinstance(status,int) or not 200<=status<300:raise GitHubFrontierUnavailable("GitHub frontier request failed")
  return body
 def refs(self,path:str)->list[int]:
  result=[]
  for page in range(1,self.max_pages+1):
   v=self.read(f"{path}?per_page={self.page_size}&page={page}")
   if not isinstance(v,list) or any(not isinstance(x,Mapping) or type(x.get("number"))is not int or x["number"]<1 for x in v):raise GitHubFrontierError("GitHub relationship response is invalid")
   result.extend(x["number"] for x in v)
   if len(v)<self.page_size:return result
  raise GitHubFrontierError("GitHub relationship pagination exceeded bound")
 def pages(self)->Iterable[Iterable[Mapping[str,Any]]]:
  for page in range(1,self.max_pages+1):
   raw=self.read(f"{self.base}/issues?state=all&per_page={self.page_size}&page={page}")
   if not isinstance(raw,list) or any(not isinstance(x,Mapping) for x in raw):raise GitHubFrontierError("GitHub issues response is invalid")
   rows=[]
   for issue in raw:
    if issue.get("pull_request") is not None:continue
    n=issue.get("number")
    if type(n)is not int or n<1:raise GitHubFrontierError("GitHub issue number is invalid")
    item=dict(issue);item["blocked_by"]=self.refs(f"{self.base}/issues/{n}/dependencies/blocked_by");item["sub_issue_numbers"]=self.refs(f"{self.base}/issues/{n}/sub_issues");rows.append(item)
   yield rows
   if len(raw)<self.page_size:return
  raise GitHubFrontierError("GitHub issue pagination exceeded bound")

class GitHubFrontierStore:
 def __init__(self,path:str|Path,*,clock:Callable[[],datetime]|None=None,max_age_seconds:float=300)->None:
  if isinstance(max_age_seconds,bool) or not isinstance(max_age_seconds,(int,float)) or max_age_seconds<=0:raise ValueError("max_age_seconds must be positive")
  self.path,self.clock,self.max_age_seconds=Path(path),clock or (lambda:datetime.now(timezone.utc)),float(max_age_seconds)
  if not self.path.is_absolute() or not self.path.parent.is_dir() or self.path.is_symlink() or _is_reparse_point(self.path) or any(parent.is_symlink() or _is_reparse_point(parent) for parent in self.path.parents):raise ValueError("frontier database must use an existing absolute non-symlink path")
  db=sqlite3.connect(self.path)
  try:
   db.execute("BEGIN IMMEDIATE")
   db.execute("CREATE TABLE IF NOT EXISTS github_frontier (project_id TEXT PRIMARY KEY, repository TEXT NOT NULL, snapshot TEXT NOT NULL, observed_at TEXT NOT NULL, failure_reason TEXT, attempted_at TEXT, version INTEGER NOT NULL DEFAULT 0)")
   columns={x[1] for x in db.execute("PRAGMA table_info(github_frontier)")}
   if "failure_reason" not in columns:db.execute("ALTER TABLE github_frontier ADD COLUMN failure_reason TEXT")
   if "attempted_at" not in columns:db.execute("ALTER TABLE github_frontier ADD COLUMN attempted_at TEXT")
   if "version" not in columns:db.execute("ALTER TABLE github_frontier ADD COLUMN version INTEGER NOT NULL DEFAULT 0")
   db.execute("UPDATE github_frontier SET version=1 WHERE version=0")
   db.commit()
  finally:db.close()
 def save(self,project_id:str,repository:str,snapshot:Mapping[str,Any])->None:
  raw=json.dumps(dict(snapshot),sort_keys=True,separators=(",",":"),allow_nan=False)
  if len(raw.encode())>MAX_SNAPSHOT:raise GitHubFrontierError("frontier snapshot exceeds bound")
  db=sqlite3.connect(self.path)
  now=_stamp(self.clock())
  try:
   db.execute("BEGIN IMMEDIATE")
   prior=db.execute("SELECT repository,snapshot,version FROM github_frontier WHERE project_id=?",(project_id,)).fetchone()
   version=int(prior[2]) if prior and prior[0] == repository and prior[1] == raw else (int(prior[2]) if prior else 0)+1
   db.execute("INSERT INTO github_frontier(project_id,repository,snapshot,observed_at,failure_reason,attempted_at,version) VALUES(?,?,?,?,NULL,?,?) ON CONFLICT(project_id) DO UPDATE SET repository=excluded.repository,snapshot=excluded.snapshot,observed_at=excluded.observed_at,failure_reason=NULL,attempted_at=excluded.attempted_at,version=excluded.version",(project_id,repository,raw,now,now,version));db.commit()
  finally:db.close()
 def fail(self,project_id:str,repository:str,reason:str)->None:
  db=sqlite3.connect(self.path)
  now=_stamp(self.clock()); reason=reason[:512] or "frontier refresh failed"
  try:
   db.execute("BEGIN IMMEDIATE")
   prior=db.execute("SELECT version FROM github_frontier WHERE project_id=?",(project_id,)).fetchone()
   version=(int(prior[0]) if prior else 0)+1
   db.execute("INSERT INTO github_frontier(project_id,repository,snapshot,observed_at,failure_reason,attempted_at,version) VALUES(?,?,?,?,?,?,?) ON CONFLICT(project_id) DO UPDATE SET failure_reason=excluded.failure_reason,attempted_at=excluded.attempted_at,version=excluded.version",(project_id,repository,"{}","",reason,now,version));db.commit()
  finally:db.close()
 def read(self,project_id:str)->dict[str,Any]|None:
  db=sqlite3.connect(self.path)
  try:row=db.execute("SELECT repository,snapshot,observed_at,failure_reason,attempted_at,version FROM github_frontier WHERE project_id=?",(project_id,)).fetchone()
  finally:db.close()
  if row is None:return None
  if row[2] == "":
   return {"schema":FRONTIER_SCHEMA,"project_id":project_id,"repository":row[0],"version":row[5],"actionable":[],"blocked":[],"active_task":None,"active_context":[],"freshness":{"state":"unavailable","observed_at":None,"attempted_at":row[4],"reason":row[3]},"status":"unavailable"}
  try:v=json.loads(row[1]); observed=datetime.fromisoformat(row[2].replace("Z","+00:00"));assert isinstance(v,dict) and len(row[1].encode())<=MAX_SNAPSHOT;_safe_json(v)
  except Exception as e:raise GitHubFrontierError("persisted frontier snapshot is invalid") from e
  age=max(0.,(self.clock().astimezone(timezone.utc)-observed.astimezone(timezone.utc)).total_seconds());state="stale" if row[3] or age>self.max_age_seconds else "fresh"
  v["repository"]=row[0];v["version"]=row[5];v["freshness"]={"state":state,"observed_at":row[2],"attempted_at":row[4] or row[2],"age_seconds":age,"reason":row[3]};return v

class GitHubFrontier:
 def __init__(self,store:GitHubFrontierStore,*_,**__)->None:self.store=store
 def norm(self,r:Mapping[str,Any])->dict[str,Any]:
  n=r.get("number");title=_text(r.get("title"),"title",True)
  if type(n)is not int or n<1:raise GitHubFrontierError("issue identity is invalid")
  parent=r.get("parent_number");parent=r.get("parent_issue",{}).get("number") if parent is None and isinstance(r.get("parent_issue"),Mapping) else parent
  if parent is not None and (type(parent)is not int or parent<1):raise GitHubFrontierError("issue parent is invalid")
  claim=r.get("active_claim");owner=_login(claim.get("owner")) if isinstance(claim,Mapping) else None
  if claim is not None and (not isinstance(claim,Mapping) or claim.get("status")!="active" or not owner):raise GitHubFrontierError("active claim is invalid")
  if "assignees" in r:assignees=_logins(r["assignees"])
  elif "assignee" in r:
   singular=_login(r.get("assignee"));assignees=[] if singular is None else [singular]
  else:assignees=[]
  return {"number":n,"title":title,"body":_text(r.get("body"),"body",maximum=MAX_BODY_BYTES),"state":r.get("state"),"labels":_labels(r.get("labels",[])),"assignees":assignees,"active_claim_owner":owner,"parent_number":parent,"sub_issue_numbers":_numbers(r.get("sub_issue_numbers",[]),"sub-issue"),"blocked_by":_numbers(r.get("blocked_by",r.get("blocked_by_numbers",[])),"blocked-by"),"url":r.get("html_url",r.get("url"))}
 def refresh(self,project_id:str,*,repository:str,parent_issue_number:int,pages:Iterable[Iterable[Mapping[str,Any]]],project_revision:int|None=None)->dict[str,Any]:
  if not isinstance(project_id,str) or not project_id or len(project_id)>128 or type(parent_issue_number)is not int or parent_issue_number<1:raise GitHubFrontierError("project or parent issue is invalid")
  rows=[self.norm(x) for page in pages for x in page]; repository=_repo(repository)
  if not rows or len(rows)>MAX_ISSUES:raise GitHubFrontierError("GitHub issue count is invalid")
  issues={x["number"]:x for x in rows}
  if len(issues)!=len(rows) or parent_issue_number not in issues:raise GitHubFrontierError("parent specification is missing or duplicated")
  parent=issues[parent_issue_number]
  if parent["state"]!="open" or "specification" not in parent["labels"]:raise GitHubFrontierError("parent specification is not open and native")
  children={x["number"]:set(x["sub_issue_numbers"]) for x in rows}
  for p in rows:
   for child in p["sub_issue_numbers"]:
    if child not in issues:raise GitHubFrontierError("frontier has missing sub-issue references")
    if child == p["number"]:raise GitHubFrontierError("frontier ancestry cycle")
    if issues[child]["parent_number"] not in (None,p["number"]):raise GitHubFrontierError("frontier parent relationship is ambiguous")
    issues[child]["parent_number"]=p["number"]
  if parent["parent_number"] is not None:raise GitHubFrontierError("frontier parent relationship is ambiguous")
  reachable:set[int]=set(); active_ancestry:set[int]=set(); ancestry_stack=[(parent_issue_number,False)]
  while ancestry_stack:
   n,leaving=ancestry_stack.pop()
   if leaving:
    active_ancestry.remove(n)
    continue
   if n in active_ancestry:raise GitHubFrontierError("frontier ancestry cycle")
   if n in reachable:continue
   reachable.add(n);active_ancestry.add(n);ancestry_stack.append((n,True))
   for child in sorted(children[n],reverse=True):ancestry_stack.append((child,False))
  for n in reachable:
   if n == parent_issue_number:continue
   issue=issues[n];ancestor=issue["parent_number"]
   if ancestor is None or ancestor not in reachable:raise GitHubFrontierError("frontier has missing ancestry")
   if n not in children[ancestor]:raise GitHubFrontierError("frontier parent/sub-issue relationships disagree")
  for issue in rows:
   ancestor=issue["parent_number"]
   if ancestor in reachable and issue["number"] not in children[ancestor]:raise GitHubFrontierError("frontier parent/sub-issue relationships disagree")
  descendants=reachable-{parent_issue_number}
  relevant=[issues[n] for n in descendants if not children[n]]
  def ancestry(n:int)->list[int]:
   result=[];seen:set[int]=set()
   while True:
    if n in seen:raise GitHubFrontierError("frontier ancestry cycle")
    seen.add(n);result.append(n)
    if n == parent_issue_number:return list(reversed(result))
    ancestor=issues[n]["parent_number"]
    if ancestor is None or ancestor not in issues:raise GitHubFrontierError("frontier has missing ancestry")
    n=ancestor
  seen:set[int]=set()
  for x in relevant:
   root=x["number"];vis:set[int]=set();dependency_stack=[(root,False)]
   while dependency_stack:
    n,leaving=dependency_stack.pop()
    if leaving:
     vis.remove(n);seen.add(n)
     continue
    if n in vis:raise GitHubFrontierError("frontier dependency cycle")
    if n in seen:continue
    vis.add(n);dependency_stack.append((n,True))
    for b in reversed(issues[n]["blocked_by"]):
     if b not in issues:raise GitHubFrontierError("frontier has missing blocker references")
     dependency_stack.append((b,False))
  action=[];blocked=[];excluded={"specification","acceptance-group","ready-for-human","needs-triage","needs-info","superseded","wontfix","in-progress"}
  for x in sorted(relevant,key=lambda y:y["number"]):
   lab=set(x["labels"]);stages={y for y in lab if y.startswith("stage:")};open_blockers=[issues[n] for n in x["blocked_by"] if issues[n]["state"]!="closed"];why=[]
   if x["state"]!="open":why.append("closed")
   if "ready-for-agent" not in lab:why.append("not_ready_for_agent")
   if lab&excluded:why.append("excluded_label")
   if stages!={"stage:v1.1"}:why.append("wrong_or_mixed_stage")
   if x["assignees"] or x["active_claim_owner"]:why.append("owned")
   if "in-progress" in lab and not x["active_claim_owner"]:why.append("unverified_active_claim")
   if "acceptance criteria" not in x["body"].lower():why.append("missing_acceptance_criteria")
   if open_blockers:why.append("native_blocker_open")
   value={key:value for key,value in x.items() if key!="body"}|{"ancestry":ancestry(x["number"]),"blockers":[{"number":b["number"],"state":b["state"],"title":b["title"]} for b in open_blockers],"status":"blocked" if why else "actionable","reasons":why};(blocked if why else action).append(value)
  active=action[0] if action else None; active_with_body=({**active,"body":issues[active["number"]]["body"]} if active else None);wanted:set[int]=set()
  if active:
   dependency_stack=[active["number"]]
   while dependency_stack:
    n=dependency_stack.pop()
    for b in reversed(issues[n]["blocked_by"]):
     if b not in wanted:wanted.add(b);dependency_stack.append(b)
  parent_context={key:value for key,value in parent.items() if key!="body"};context=[{key:value for key,value in issues[n].items() if key!="body"} for n in sorted(wanted)]
  snap={"schema":FRONTIER_SCHEMA,"project_id":project_id,"project_revision":project_revision,"parent_issue_number":parent_issue_number,"parent_context":parent_context,"actionable":action,"blocked":blocked,"active_task":active_with_body,"active_context":context};self.store.save(project_id,repository,snap);return self.view(project_id)
 def refresh_adapter(self,project_id:str,*,parent_issue_number:int,adapter:FrontierAdapter,project_revision:int|None=None)->dict[str,Any]:return self.refresh(project_id,repository=adapter.repository,parent_issue_number=parent_issue_number,pages=adapter.pages(),project_revision=project_revision)
 def refresh_with_recovery(self,project_id:str,*,parent_issue_number:int,adapter:FrontierAdapter,project_revision:int|None=None)->dict[str,Any]:
  try:return self.refresh_adapter(project_id,parent_issue_number=parent_issue_number,adapter=adapter,project_revision=project_revision)
  except GitHubFrontierUnavailable as e:self.store.fail(project_id,adapter.repository,str(e));return self.view(project_id)
 def view(self,project_id:str)->dict[str,Any]:
  v=self.store.read(project_id)
  if v is None:return {"schema":FRONTIER_SCHEMA,"project_id":project_id,"actionable":[],"blocked":[],"active_task":None,"active_context":[],"freshness":{"state":"unavailable","observed_at":None,"attempted_at":None,"reason":"frontier has not been loaded"},"status":"unavailable"}
  if v["freshness"]["state"]=="unavailable":return v
  v["status"]="available" if v["freshness"]["state"]=="fresh" else "stale";return v

class GitHubFrontierService:
 def __init__(self,projects:Any,frontier:GitHubFrontier,adapter_factory:Callable[[Mapping[str,Any]],FrontierAdapter])->None:self.projects,self.frontier,self.adapter_factory,self._refresh_lock=projects,frontier,adapter_factory,RLock()
 def _binding(self,draft:Mapping[str,Any])->tuple[Mapping[str,Any],Mapping[str,Any]]:
  if draft.get("confirmed_revision") != draft.get("revision"):raise GitHubFrontierError("current exact project revision requires human confirmation before frontier refresh")
  payload=draft.get("payload");binding=payload.get("forge_binding") if isinstance(payload,Mapping) else None;tracker=payload.get("github_frontier") if isinstance(payload,Mapping) else None
  if not isinstance(binding,Mapping) or binding.get("provider")!="github" or not isinstance(tracker,Mapping) or set(tracker)!={"parent_issue_number"} or type(tracker.get("parent_issue_number"))is not int:raise GitHubFrontierError("accepted project requires a GitHub binding and parent issue identity")
  return binding,tracker
 def _validated_view(self,project_id:str,draft:Mapping[str,Any],value:Mapping[str,Any])->dict[str,Any]:
  try:binding,tracker=self._binding(draft);matches=value.get("project_revision")==draft.get("revision") and value.get("repository")==_repo(binding.get("repository_url")) and value.get("parent_issue_number")==tracker.get("parent_issue_number")
  except GitHubFrontierError:matches=False
  if not matches:return {"schema":FRONTIER_SCHEMA,"project_id":project_id,"actionable":[],"blocked":[],"active_task":None,"active_context":[],"freshness":{"state":"unavailable","observed_at":None,"attempted_at":value.get("freshness",{}).get("attempted_at"),"reason":"frontier cache does not match the current confirmed project binding"},"status":"unavailable"}
  return dict(value)
 def refresh(self,project_id:str)->dict[str,Any]:
  with self._refresh_lock:
   draft=self.projects.draft(project_id);binding,tracker=self._binding(draft);adapter=self.adapter_factory(binding)
   if _repo(adapter.repository)!=_repo(binding.get("repository_url")):raise GitHubFrontierError("frontier adapter does not match accepted repository binding")
   value=self.frontier.refresh_with_recovery(project_id,parent_issue_number=tracker["parent_issue_number"],adapter=adapter,project_revision=draft["revision"])
   return self._validated_view(project_id,self.projects.draft(project_id),value)
 def view(self,project_id:str)->dict[str,Any]:
  return self._validated_view(project_id,self.projects.draft(project_id),self.frontier.view(project_id))
