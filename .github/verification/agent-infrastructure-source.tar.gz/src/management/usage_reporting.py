"""Durable usage facts and deterministic weekly report projections."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from contextlib import contextmanager
import json, math, re, sqlite3
from pathlib import Path
from typing import Any, Mapping
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root

class UsageReportingError(ValueError): pass

_SAFE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

def _id(value: object, name: str) -> str:
    if not isinstance(value, str) or _SAFE_ID.fullmatch(value) is None: raise UsageReportingError(f"{name} is invalid")
    return value
def _time(value: str) -> datetime:
    try: result=datetime.fromisoformat(value.replace("Z","+00:00"))
    except (AttributeError, ValueError): raise UsageReportingError("timestamp must be RFC3339") from None
    if result.tzinfo is None: raise UsageReportingError("timestamp must include an offset")
    return result.astimezone(timezone.utc)
def _utc(value: datetime) -> str: return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z")

class UsageReportingStore:
    """Stores immutable, provenance-carrying observations; never runtime truth."""
    def __init__(self, database: Path) -> None:
        database = Path(database)
        try:
            state_root = validate_state_root(database.parent, "usage reporting state root")
            self.database = validate_durable_leaf(database, state_root, label="usage reporting database")
        except ManagementStateBoundaryError as error:
            raise UsageReportingError(str(error)) from error
        with self._connection() as c: c.executescript("""CREATE TABLE IF NOT EXISTS usage_records (idempotency_key TEXT PRIMARY KEY, project_id TEXT NOT NULL, observed_at TEXT NOT NULL, record_json TEXT NOT NULL); CREATE INDEX IF NOT EXISTS usage_by_project_time ON usage_records(project_id,observed_at); CREATE TABLE IF NOT EXISTS reporting_policy (project_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, policy_json TEXT NOT NULL); CREATE TABLE IF NOT EXISTS report_decisions (project_id TEXT NOT NULL, week_start TEXT NOT NULL, decision_id TEXT NOT NULL, decision_json TEXT NOT NULL, PRIMARY KEY(project_id,week_start,decision_id));""")
    @contextmanager
    def _connection(self):
        c=sqlite3.connect(self.database);c.row_factory=sqlite3.Row
        try:
            yield c
            c.commit()
        except BaseException:
            c.rollback()
            raise
        finally:
            c.close()
    def record_usage(self, project_id: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        _id(project_id,"project_id")
        if not isinstance(payload,Mapping) or set(payload)!={"idempotency_key","agent_id","observed_at","tokens","resources","provenance"}: raise UsageReportingError("exact usage record fields are required")
        key,agent=_id(payload["idempotency_key"],"idempotency_key"),_id(payload["agent_id"],"agent_id"); observed=_utc(_time(payload["observed_at"]));tokens=payload["tokens"]
        if not isinstance(tokens,Mapping) or set(tokens)!={"input","output"} or any(type(tokens[x]) is not int or not 0<=tokens[x]<=10**12 for x in tokens): raise UsageReportingError("tokens must be bounded non-negative integers")
        resources=payload["resources"]
        if not isinstance(resources,list) or len(resources)>64: raise UsageReportingError("resources must be a bounded list")
        clean=[]
        for item in resources:
            if not isinstance(item,Mapping) or set(item)!={"name","unit","value","availability"} or not isinstance(item["name"],str) or not item["name"] or not isinstance(item["unit"],str) or not item["unit"] or type(item["value"]) not in {int,float} or isinstance(item["value"],bool) or not math.isfinite(item["value"]) or item["value"]<0 or item["availability"] not in {"reported","estimated"}: raise UsageReportingError("resource measurement is invalid")
            clean.append(dict(item))
        provenance=payload["provenance"]
        if not isinstance(provenance,Mapping) or set(provenance)!={"source","version","measurement_id"} or any(not isinstance(provenance[x],str) or not provenance[x] or len(provenance[x])>256 for x in provenance): raise UsageReportingError("provenance source, version, and measurement_id are required")
        result={"idempotency_key":key,"project_id":project_id,"agent_id":agent,"observed_at":observed,"tokens":{"input":tokens["input"],"output":tokens["output"]},"resources":clean,"provenance":dict(provenance)}; encoded=json.dumps(result,sort_keys=True,separators=(",",":"),allow_nan=False)
        with self._connection() as c:
            old=c.execute("SELECT record_json FROM usage_records WHERE idempotency_key=?",(key,)).fetchone()
            if old:
                if old["record_json"]!=encoded: raise UsageReportingError("idempotency key already names a different usage record")
                return json.loads(old["record_json"])
            c.execute("INSERT INTO usage_records VALUES(?,?,?,?)",(key,project_id,observed,encoded))
        return result
    def set_policy(self, project_id: str, payload: Mapping[str,Any]) -> dict[str,Any]:
        _id(project_id,"project_id")
        if not isinstance(payload,Mapping) or set(payload)!={"expected_revision","cadence","timezone","weekly_token_budget","project_report_interval_seconds","allocation_target_min_percent","allocation_target_max_percent"}: raise UsageReportingError("exact reporting policy fields are required")
        expected=payload["expected_revision"]
        if expected is not None and (type(expected) is not int or expected<1): raise UsageReportingError("expected_revision must be a positive integer or null")
        interval=payload["project_report_interval_seconds"]; lower=payload["allocation_target_min_percent"]; upper=payload["allocation_target_max_percent"]
        if payload["cadence"]!="weekly" or payload["timezone"]!="UTC" or type(payload["weekly_token_budget"]) is not int or not 1<=payload["weekly_token_budget"]<=10**15 or type(interval) is not int or not 300<=interval<=604800 or type(lower) not in {int,float} or type(upper) not in {int,float} or isinstance(lower,bool) or isinstance(upper,bool) or not 0<=lower<upper<=100: raise UsageReportingError("reporting policy is invalid")
        with self._connection() as c:
            old=c.execute("SELECT revision,policy_json FROM reporting_policy WHERE project_id=?",(project_id,)).fetchone()
            if old is None:
                if expected is not None: raise UsageReportingError("reporting policy revision does not exist")
                revision=1
            else:
                if expected!=old["revision"]: raise UsageReportingError("reporting policy revision conflicts")
                candidate={"project_id":project_id,"revision":old["revision"],"cadence":"weekly","timezone":"UTC","weekly_token_budget":payload["weekly_token_budget"],"project_report_interval_seconds":interval,"allocation_target_min_percent":lower,"allocation_target_max_percent":upper}
                if json.loads(old["policy_json"])==candidate:return candidate
                revision=old["revision"]+1
            result={"project_id":project_id,"revision":revision,"cadence":"weekly","timezone":"UTC","weekly_token_budget":payload["weekly_token_budget"],"project_report_interval_seconds":interval,"allocation_target_min_percent":lower,"allocation_target_max_percent":upper};c.execute("INSERT INTO reporting_policy VALUES(?,?,?) ON CONFLICT(project_id) DO UPDATE SET revision=excluded.revision,policy_json=excluded.policy_json",(project_id,revision,json.dumps(result,sort_keys=True)))
        return result
    def policy(self, project_id: str) -> dict[str,Any]:
        with self._connection() as c:row=c.execute("SELECT policy_json FROM reporting_policy WHERE project_id=?",(_id(project_id,"project_id"),)).fetchone()
        if row is None: raise KeyError(project_id)
        return json.loads(row["policy_json"])
    def token_totals(self, project_id: str) -> dict[str, int] | None:
        _id(project_id,"project_id")
        with self._connection() as c: rows=c.execute("SELECT record_json FROM usage_records WHERE project_id=? ORDER BY observed_at,idempotency_key",(project_id,)).fetchall()
        if not rows:return None
        input_tokens=output_tokens=0
        for row in rows:
            record=json.loads(row["record_json"]);input_tokens+=record["tokens"]["input"];output_tokens+=record["tokens"]["output"]
        return {"input":input_tokens,"output":output_tokens,"total":input_tokens+output_tokens}
    def time_series(self, project_id: str, start: str | None, end: str | None) -> dict[str,Any]:
        """Actual observations only; no interpolation or invented zero samples."""
        _id(project_id,"project_id"); start_time=_utc(_time(start)) if start is not None else None;end_time=_utc(_time(end)) if end is not None else None
        if start_time is not None and end_time is not None and start_time>=end_time:raise UsageReportingError("time range must be ascending")
        query="SELECT record_json FROM usage_records WHERE project_id=?";args:list[Any]=[project_id]
        if start_time is not None:query+=" AND observed_at>=?";args.append(start_time)
        if end_time is not None:query+=" AND observed_at<?";args.append(end_time)
        with self._connection() as c:rows=c.execute(query+" ORDER BY observed_at,idempotency_key",args).fetchall()
        grouped:dict[tuple[str,str],list[dict[str,Any]]]={}
        for row in rows:
            record=json.loads(row["record_json"]); provenance=record["provenance"];at=record["observed_at"]
            grouped.setdefault(("tokens.input","tokens"),[]).append({"observed_at":at,"value":record["tokens"]["input"],"availability":"reported","provenance":provenance})
            grouped.setdefault(("tokens.output","tokens"),[]).append({"observed_at":at,"value":record["tokens"]["output"],"availability":"reported","provenance":provenance})
            for metric in record["resources"]:grouped.setdefault((metric["name"],metric["unit"]),[]).append({"observed_at":at,"value":metric["value"],"availability":metric["availability"],"provenance":provenance})
        series=[{"name":name,"unit":unit,"samples":samples} for (name,unit),samples in sorted(grouped.items())]
        return {"project_id":project_id,"from":start_time,"to":end_time,"series":series,"missing_data":[] if series else [{"subject_id":project_id,"field":"series","reason":"no_usage_records_in_range"}]}
    def weekly_reports(self, project_id: str) -> list[dict[str,Any]]:
        _id(project_id,"project_id")
        with self._connection() as c:rows=c.execute("SELECT DISTINCT week_start FROM report_decisions WHERE project_id=? ORDER BY week_start DESC",(project_id,)).fetchall()
        return [{"week_start":row["week_start"],"decision_records":self.decision_records(project_id,row["week_start"])} for row in rows]
    def record_decisions(self, project_id: str, week_start: str, decisions: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
        _id(project_id,"project_id"); start=_utc(_time(week_start))
        if not isinstance(decisions,list): raise UsageReportingError("decisions must be a list")
        recorded=[]
        with self._connection() as c:
            for decision in decisions:
                if not isinstance(decision,Mapping): raise UsageReportingError("decision is invalid")
                value=dict(decision); encoded=json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False); decision_id=__import__("hashlib").sha256(encoded.encode("utf-8")).hexdigest()
                c.execute("INSERT OR IGNORE INTO report_decisions VALUES(?,?,?,?)",(project_id,start,decision_id,encoded));recorded.append({"decision_id":decision_id,**value})
        return recorded
    def decision_records(self, project_id: str, week_start: str) -> list[dict[str, Any]]:
        with self._connection() as c: rows=c.execute("SELECT decision_id,decision_json FROM report_decisions WHERE project_id=? AND week_start=? ORDER BY decision_id",(_id(project_id,"project_id"),_utc(_time(week_start)))).fetchall()
        return [{"decision_id":row["decision_id"],**json.loads(row["decision_json"])} for row in rows]
    def weekly_report(self, project_id: str, week_start: str) -> dict[str,Any]:
        policy=self.policy(project_id);start=_time(week_start)
        if start.weekday()!=0 or start.time()!=datetime.min.time():raise UsageReportingError("week_start must be Monday 00:00:00Z")
        end=start+timedelta(days=7)
        with self._connection() as c: rows=c.execute("SELECT record_json FROM usage_records WHERE project_id=? AND observed_at>=? AND observed_at<? ORDER BY observed_at,idempotency_key",(project_id,_utc(start),_utc(end))).fetchall()
        agents={}; measurements={}
        for row in rows:
            record=json.loads(row["record_json"]);agent=agents.setdefault(record["agent_id"],{"input":0,"output":0});agent["input"]+=record["tokens"]["input"];agent["output"]+=record["tokens"]["output"]
            for metric in record["resources"]:measurements.setdefault((metric["name"],metric["unit"]),[]).append(metric["value"])
        total=sum(v["input"]+v["output"] for v in agents.values());budget=policy["weekly_token_budget"]; utilization=measurements.get(("allocation.utilization","percent"),[]); average_utilization=(sum(utilization)/len(utilization)) if utilization else None
        decisions=[{"kind":"within_weekly_token_budget" if total<=budget else "review_weekly_token_budget","automated":True,"basis":{"total_tokens":total,"weekly_token_budget":budget},"action":"none" if total<=budget else "human_review_required","requires_human_confirmation":total>budget}]
        if average_utilization is None: decisions.append({"kind":"allocation_evidence_missing","automated":True,"basis":{"metric":"allocation.utilization","unit":"percent"},"action":"collect_evidence","requires_human_confirmation":False})
        else:
            kind,action=("suggest_shrink_allocation","human_review_required") if average_utilization<policy["allocation_target_min_percent"] else (("suggest_escalate_allocation","human_review_required") if average_utilization>policy["allocation_target_max_percent"] else ("keep_allocation_target_band","none"))
            decisions.append({"kind":kind,"automated":True,"basis":{"average_utilization_percent":average_utilization,"target_min_percent":policy["allocation_target_min_percent"],"target_max_percent":policy["allocation_target_max_percent"],"sample_count":len(utilization)},"action":action,"requires_human_confirmation":action!="none"})
        return {"project_id":project_id,"week_start":_utc(start),"week_end":_utc(end),"policy_revision":policy["revision"],"project_reporting_cadence":{"interval_seconds":policy["project_report_interval_seconds"],"timezone":"UTC"},"record_count":len(rows),"tokens":{"input":sum(v["input"] for v in agents.values()),"output":sum(v["output"] for v in agents.values()),"total":total,"by_agent":[{"agent_id":name,**agents[name]} for name in sorted(agents)]},"resources":[{"name":name,"unit":unit,"sample_count":len(values),"average":sum(values)/len(values),"maximum":max(values)} for (name,unit),values in sorted(measurements.items())],"automated_decisions":decisions}
