"""One explicit, typed project-orchestrator turn bridge.

This module deliberately knows neither Management nor Hermes URLs or credentials.
Those are supplied by authenticated adapters; a model response is only a candidate
JSON decision and never an authority grant.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
import re
from typing import Any, Mapping, Protocol
from urllib.parse import quote, urlsplit
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from shared.contracts.agent_runtime import RuntimeOutcomeUnknown, RuntimeClientError, validate_submission_fence
from shared.contracts.forge import normalize_project_forge_binding, validate_project_forge_binding
from shared.contracts.project_reference import validate_secret_free


_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_MAX_PROMPT = 64 * 1024
_MAX_ASSIGNMENTS = 64
_MAX_RESOURCES = 64
_ASSIGNMENT_OPTIONAL = {"depends_on", "resource_request", "verification_input_tree_sha256","attempt_id","immutable_revision","submission_fence"}


class OrchestratorDriverError(ValueError): pass
class UnknownOutcome(OrchestratorDriverError): pass


class ManagementLoopClient(Protocol):
    def snapshot(self, project_id: str, revision: int) -> Mapping[str, Any]: ...
    def post_decision(self, project_id: str, revision: int, *, idempotency_key: str, expected_version: int, decision: Mapping[str, Any]) -> Mapping[str, Any]: ...


class RuntimeClient(Protocol):
    def reconcile(self, request_id: str, *, prompt: str) -> Mapping[str, Any] | None: ...
    def turn(self, *, request_id: str, session_id: str, runtime_binding_id: str, prompt: str) -> Mapping[str, Any]: ...


class AgentRuntimeAdapter:
    """Safe composition wrapper for the Agent Runtime contract client."""
    def __init__(self, client: Any, *, project_id: str, revision: int, runtime_binding_id: str):
        if not isinstance(runtime_binding_id,str) or _SAFE.fullmatch(runtime_binding_id) is None: raise OrchestratorDriverError("runtime binding is invalid")
        self.client, self.project_id, self.revision, self._binding_id = client, project_id, revision, runtime_binding_id
    def reconcile(self, request_id: str, *, prompt: str) -> Mapping[str, Any] | None:
        try: return self.client.operation(self._binding_id, request_id=request_id, project_id=self.project_id, revision_id=str(self.revision), message=prompt)
        except RuntimeOutcomeUnknown as error: raise UnknownOutcome("runtime reconciliation is unavailable") from error
        except RuntimeClientError as error: raise OrchestratorDriverError("runtime reconciliation was definitively rejected") from error
    def turn(self, *, request_id: str, session_id: str, runtime_binding_id: str, prompt: str) -> Mapping[str, Any]:
        if runtime_binding_id != self._binding_id: raise OrchestratorDriverError("runtime binding differs")
        identity = self.client.binding_identity(runtime_binding_id)
        if identity.get("session_id") != session_id: raise OrchestratorDriverError("configured runtime session differs")
        try: return self.client.submit_turn(runtime_binding_id, request_id=request_id, project_id=self.project_id, revision_id=str(self.revision), message=prompt)
        except RuntimeOutcomeUnknown as error: raise UnknownOutcome("runtime submit outcome is unknown") from error
        except RuntimeClientError as error: raise OrchestratorDriverError("runtime submit was definitively rejected") from error


@dataclass(frozen=True)
class ManagementHttpResponse:
    status: int
    body: bytes


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, request: Request, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> None: return None


def _management_transport(method: str, url: str, headers: Mapping[str, str], body: bytes | None, timeout: float) -> ManagementHttpResponse:
    try:
        request = Request(url, data=body, headers=dict(headers), method=method)
        with build_opener(ProxyHandler({}), _NoRedirect()).open(request, timeout=timeout) as response:
            return ManagementHttpResponse(response.status, response.read(64 * 1024 + 1))
    except HTTPError as error:
        return ManagementHttpResponse(error.code, error.read(64 * 1024 + 1))
    except (OSError, URLError) as error:
        raise UnknownOutcome("management transport outcome is unknown") from error


class HttpManagementAdapter:
    """Bounded no-redirect HTTP adapter; URL and scoped bearer token are injected."""
    def __init__(self, base_url: str, token: str, intent_id: str, transport: Any = _management_transport, *, timeout_seconds: float = 5.0):
        parsed = urlsplit(base_url)
        if not isinstance(token,str) or not token or not isinstance(intent_id,str) or _SAFE.fullmatch(intent_id) is None or parsed.scheme not in {"https","http"} or (parsed.scheme == "http" and parsed.hostname not in {"127.0.0.1","::1","localhost"}) or parsed.username or parsed.password or parsed.path.rstrip("/") or parsed.query or parsed.fragment or not isinstance(timeout_seconds,(int,float)) or isinstance(timeout_seconds,bool) or not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 30:
            raise OrchestratorDriverError("management adapter configuration is invalid")
        self.base_url,self.token,self.intent_id,self.transport,self.timeout_seconds=base_url.rstrip("/"),token,intent_id,transport,timeout_seconds
    def _request(self, method: str, path: str, body: Mapping[str, Any] | None = None) -> dict[str, Any]:
        raw = None if body is None else _canonical(body).encode()
        response = self.transport(method, self.base_url + path, {"Authorization":"Bearer " + self.token,"Accept":"application/json",**({"Content-Type":"application/json"} if raw else {})}, raw, self.timeout_seconds)
        if not isinstance(response, ManagementHttpResponse) or not isinstance(response.status,int) or response.status < 200 or response.status >= 300 or len(response.body) > 64 * 1024: raise UnknownOutcome("management transport outcome is unknown")
        try: value=json.loads(response.body.decode(),parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        except (UnicodeDecodeError,ValueError,json.JSONDecodeError) as error: raise UnknownOutcome("management response is invalid") from error
        if not isinstance(value,dict): raise UnknownOutcome("management response is invalid")
        return value
    def snapshot(self, project_id: str, revision: int) -> Mapping[str, Any]:
        return self._request("GET", "/projects/" + quote(project_id,safe="") + "/orchestrator-loops/" + quote(self.intent_id,safe=""))
    def post_decision(self, project_id: str, revision: int, *, idempotency_key: str, expected_version: int, decision: Mapping[str, Any]) -> Mapping[str, Any]:
        return self._request("POST", "/projects/" + quote(project_id,safe="") + "/orchestrator-loops/" + quote(self.intent_id,safe="") + "/decisions", {"idempotency_key":idempotency_key,"expected_version":expected_version,"decision":dict(decision)})


@dataclass(frozen=True)
class DriverConfiguration:
    project_id: str
    revision: int
    session_id: str
    runtime_binding_id: str
    agent_bindings: Mapping[str, frozenset[str]]
    project_definition: Mapping[str, Any]

    def __post_init__(self) -> None:
        if (not isinstance(self.project_id, str) or _SAFE.fullmatch(self.project_id) is None or type(self.revision) is not int or self.revision < 1 or not isinstance(self.session_id, str) or _SAFE.fullmatch(self.session_id) is None or not isinstance(self.runtime_binding_id, str) or _SAFE.fullmatch(self.runtime_binding_id) is None or not isinstance(self.agent_bindings, Mapping) or not self.agent_bindings or len(self.agent_bindings) > 128):
            raise OrchestratorDriverError("driver configuration is invalid")
        for agent, bindings in self.agent_bindings.items():
            if not isinstance(agent, str) or _SAFE.fullmatch(agent) is None or not isinstance(bindings, frozenset) or not bindings or len(bindings) > 32 or any(not isinstance(binding, str) or _SAFE.fullmatch(binding) is None for binding in bindings):
                raise OrchestratorDriverError("driver configuration is invalid")
        definition = self.project_definition
        if not isinstance(definition, Mapping) or set(definition) - {"prd_reference","goal","context","agents","forge_binding"} or not all(isinstance(definition.get(key), str) and 1 <= len(definition[key].encode()) <= 4096 for key in ("prd_reference","goal","context")) or not isinstance(definition.get("agents"), list) or not 1 <= len(definition["agents"]) <= 128:
            raise OrchestratorDriverError("project definition is invalid")
        if "forge_binding" in definition:
            try:
                validate_project_forge_binding(definition["forge_binding"])
            except ValueError as error:
                raise OrchestratorDriverError(str(error)) from error
        for agent in definition["agents"]:
            if not isinstance(agent, Mapping) or set(agent) - {"id","role","description"} or not isinstance(agent.get("id"),str) or _SAFE.fullmatch(agent["id"]) is None or not isinstance(agent.get("role"),str) or not 1 <= len(agent["role"].encode()) <= 256 or ("description" in agent and (not isinstance(agent["description"],str) or len(agent["description"].encode()) > 4096)):
                raise OrchestratorDriverError("project definition is invalid")
        normalized_definition = json.loads(_canonical(definition))
        if "forge_binding" in normalized_definition:
            normalized_definition["forge_binding"] = normalize_project_forge_binding(normalized_definition["forge_binding"])
        object.__setattr__(self, "project_definition", normalized_definition)


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


class ProjectOrchestratorDriver:
    def __init__(self, config: DriverConfiguration, management: ManagementLoopClient, runtime: RuntimeClient):
        self.config, self.management, self.runtime = config, management, runtime

    def step(self) -> dict[str, Any]:
        snapshot = self._snapshot()
        if snapshot["state"] != "turn_ready": return {"state": "not_turn_ready", "version": snapshot["version"]}
        prompt = self._prompt(snapshot)
        identity = hashlib.sha256(_canonical({"project":self.config.project_id,"revision":self.config.revision,"version":snapshot["version"],"prompt":prompt}).encode()).hexdigest()
        request_id, decision_key = "turn-" + identity[:48], "decision-" + identity[:48]
        operation = self.runtime.reconcile(request_id, prompt=prompt)
        if operation is None:
            try: operation = self.runtime.turn(request_id=request_id, session_id=self.config.session_id, runtime_binding_id=self.config.runtime_binding_id, prompt=prompt)
            except UnknownOutcome:
                operation = self.runtime.reconcile(request_id, prompt=prompt)
                if operation is None: raise
        decision = self._decision(operation, snapshot, request_id, prompt)
        try:
            receipt = self.management.post_decision(self.config.project_id, self.config.revision, idempotency_key=decision_key, expected_version=snapshot["version"], decision=decision)
        except UnknownOutcome:
            # A version change is durable evidence that the exact expected decision was
            # accepted; otherwise retry the same idempotency key, never Hermes.
            observed = self._snapshot()
            if observed["version"] == snapshot["version"] + 1 and observed.get("last_decision") == decision: return {"state":"management_reconciled","version":observed["version"],"request_id":request_id}
            if observed["version"] != snapshot["version"]: raise UnknownOutcome("management outcome conflicts with another decision")
            receipt = self.management.post_decision(self.config.project_id, self.config.revision, idempotency_key=decision_key, expected_version=snapshot["version"], decision=decision)
        return {"state":"submitted","version":snapshot["version"],"request_id":request_id,"decision":decision,"receipt":dict(receipt)}

    def _snapshot(self) -> dict[str, Any]:
        raw = self.management.snapshot(self.config.project_id, self.config.revision)
        required = {"project_id","revision","state","version","resources","pending_request","last_decision","config_fingerprint","assignments"}
        optional = {"project_descriptor"}
        if not isinstance(raw, Mapping) or not required.issubset(raw) or set(raw) - required - optional or raw.get("project_id") != self.config.project_id or raw.get("revision") != self.config.revision or raw.get("state") not in {"turn_ready","waiting","blocked","pause_requested","draining","paused","completed"} or type(raw.get("version")) is not int or raw["version"] < 1 or not isinstance(raw.get("config_fingerprint"),str) or not re.fullmatch(r"[0-9a-f]{64}",raw["config_fingerprint"]) or not isinstance(raw.get("resources"), Mapping) or not raw["resources"] or len(raw["resources"]) > 64 or any(not isinstance(key,str) or _SAFE.fullmatch(key) is None or type(value) not in {int,float} or not math.isfinite(value) or value < 0 for key,value in raw["resources"].items()) or not isinstance(raw.get("assignments"), list) or len(raw["assignments"]) > 64 or any(not self._valid_assignment(item) for item in raw["assignments"]) or raw.get("pending_request") is not None and not self._bounded_json(raw.get("pending_request")) or raw.get("last_decision") is not None and not self._bounded_json(raw.get("last_decision")) or "project_descriptor" in raw and not self._bounded_json(raw["project_descriptor"], string_limit=_MAX_PROMPT):
            raise OrchestratorDriverError("management loop snapshot is invalid")
        if "project_descriptor" in raw:
            try:
                validate_secret_free(raw["project_descriptor"])
            except ValueError as error:
                raise OrchestratorDriverError("management loop snapshot is invalid") from error
        for item in raw["assignments"]:
            fence = item.get("submission_fence")
            if fence is not None and fence.get("project_revision") != self.config.revision:
                raise OrchestratorDriverError("management assignment fence revision differs")
        assignment_ids = {item["assignment_id"] for item in raw["assignments"]}
        if len(assignment_ids) != len(raw["assignments"]) or any(item["binding_id"] not in self.config.agent_bindings.get(item["agent_id"], frozenset()) or any(dependency not in assignment_ids for dependency in (item.get("depends_on") or [])) for item in raw["assignments"]):
            raise OrchestratorDriverError("management assignment is unauthorized or references an unknown dependency")
        self._validate_dependency_graph(raw["assignments"])
        value = json.loads(_canonical(raw))
        if len(_canonical(value).encode()) > _MAX_PROMPT: raise OrchestratorDriverError("management loop snapshot exceeds bound")
        return value

    @staticmethod
    def _valid_assignment(item: Any) -> bool:
        required = {"assignment_id", "agent_id", "binding_id", "task_ref", "objective", "state", "receipt", "events", "events_truncated"}
        if not isinstance(item, Mapping) or not required.issubset(item) or set(item) - required - _ASSIGNMENT_OPTIONAL:
            return False
        if not all(isinstance(item.get(key), str) and _SAFE.fullmatch(item[key]) for key in ("assignment_id", "agent_id", "binding_id", "task_ref")) or not isinstance(item.get("objective"), str) or not 1 <= len(item["objective"].encode()) <= 4096 or item.get("state") not in {"assigned", "running", "paused", "succeeded", "blocked", "waived"}:
            return False
        if item.get("receipt") is not None and not ProjectOrchestratorDriver._bounded_json(item.get("receipt")):
            return False
        if not isinstance(item.get("events"), list) or len(item["events"]) > 100 or not all(ProjectOrchestratorDriver._bounded_json(event) for event in item["events"]) or type(item.get("events_truncated")) is not bool:
            return False
        depends = item.get("depends_on")
        if depends is not None and (not isinstance(depends, list) or len(depends) > _MAX_ASSIGNMENTS or any(not isinstance(value, str) or _SAFE.fullmatch(value) is None for value in depends) or len(set(depends)) != len(depends)):
            return False
        resources = item.get("resource_request")
        if resources is not None and (not isinstance(resources, Mapping) or len(resources) > _MAX_RESOURCES or any(not isinstance(key, str) or _SAFE.fullmatch(key) is None or isinstance(value, bool) or type(value) not in {int, float} or not math.isfinite(value) or value < 0 for key, value in resources.items())):
            return False
        digest = item.get("verification_input_tree_sha256")
        if not (digest is None or isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest) is not None): return False
        attempt, immutable = item.get("attempt_id"), item.get("immutable_revision")
        fence = item.get("submission_fence")
        if attempt is None and immutable is None:
            return fence is None
        if not (isinstance(attempt, str) and _SAFE.fullmatch(attempt) is not None and isinstance(immutable, str) and re.fullmatch(r"[0-9a-f]{40,64}", immutable) is not None and isinstance(fence, Mapping)):
            return False
        try:
            normalized = validate_submission_fence(fence)
        except RuntimeClientError:
            return False
        return normalized["assignment_id"] == item["assignment_id"] and normalized["immutable_revision"] == immutable

    @staticmethod
    def _bounded_json(value: Any, depth: int = 0, string_limit: int = 4096) -> bool:
        if depth > 6: return False
        if value is None or type(value) is bool or type(value) in {int,float}: return type(value) is not float or math.isfinite(value)
        if isinstance(value,str): return len(value.encode()) <= string_limit
        if isinstance(value,list): return len(value) <= 128 and all(ProjectOrchestratorDriver._bounded_json(item,depth+1,string_limit) for item in value)
        if isinstance(value,Mapping): return len(value) <= 128 and all(isinstance(key,str) and _SAFE.fullmatch(key) and ProjectOrchestratorDriver._bounded_json(item,depth+1,string_limit) for key,item in value.items())
        return False

    def _prompt(self, snapshot: Mapping[str, Any]) -> str:
        schemas = {
            "assign":{"kind":"assign","assignments":[{"assignment_id":"safe-id","agent_id":"configured-agent","binding_id":"configured-binding","task_ref":"safe-id","objective":"bounded text","depends_on":["prior-assignment"],"resource_request":{"cpu_cores":1},"verification_input_tree_sha256":"0000000000000000000000000000000000000000000000000000000000000000"}]},
            "waiting":{"kind":"waiting"}, "blocked":{"kind":"blocked"}, "completed":{"kind":"completed"},
            "request_expansion":{"kind":"request_expansion","target_resources":{"cpu_cores":1}},
        }
        # The descriptor comes from the authenticated management snapshot and is
        # included in the actual model context, so the model sees the same
        # approved project contract whose fingerprint governs this loop.
        descriptor = snapshot.get("project_descriptor")
        if descriptor is not None:
            try:
                validate_secret_free(descriptor)
            except ValueError as error:
                raise OrchestratorDriverError("project descriptor contains secret material") from error
        context = {"project_id":self.config.project_id,"revision":self.config.revision,"version":snapshot["version"],"project_definition":self.config.project_definition,"project_descriptor":descriptor,"resources":snapshot["resources"],"assignments":snapshot["assignments"],"pending_request":snapshot.get("pending_request"),"allowed_agents":{agent:sorted(bindings) for agent,bindings in sorted(self.config.agent_bindings.items())},"decision_schemas":schemas,"instruction":"Return exactly one JSON object matching one decision schema; no markdown or prose."}
        prompt = _canonical(context)
        if len(prompt.encode()) > _MAX_PROMPT: raise OrchestratorDriverError("turn context exceeds bound")
        return prompt

    def _decision(self, operation: Mapping[str, Any] | None, snapshot: Mapping[str, Any], request_id: str, prompt: str) -> dict[str, Any]:
        if not isinstance(operation, Mapping): raise OrchestratorDriverError("runtime operation is unavailable")
        digest = hashlib.sha256(prompt.encode()).hexdigest()
        if operation.get("state") != "completed" or operation.get("request_id") != request_id or operation.get("session_id") != self.config.session_id or operation.get("project_id") != self.config.project_id or operation.get("revision_id") != str(self.config.revision) or operation.get("message_sha256") != digest:
            raise OrchestratorDriverError("runtime receipt does not bind this turn")
        result = operation.get("result")
        response = result.get("final_response") if isinstance(result, Mapping) else None
        if not isinstance(response, str) or len(response.encode()) > _MAX_PROMPT: raise OrchestratorDriverError("runtime final response is invalid")
        try: decision = json.loads(response, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        except (ValueError, json.JSONDecodeError) as error: raise OrchestratorDriverError("runtime final response must be JSON") from error
        if not isinstance(decision, dict): raise OrchestratorDriverError("runtime final response must be one object")
        self._validate_decision(decision, snapshot)
        return decision

    def _validate_decision(self, decision: Mapping[str, Any], snapshot: Mapping[str, Any]) -> None:
        kind = decision.get("kind")
        if kind in {"waiting", "blocked"}:
            if set(decision) != {"kind"}: raise OrchestratorDriverError("decision schema is invalid")
            return
        if kind == "completed":
            if set(decision) != {"kind"} or any(item.get("state") not in {"succeeded","waived"} for item in snapshot["assignments"] if isinstance(item, Mapping)): raise OrchestratorDriverError("completion is invalid")
            return
        if kind == "assign":
            values = decision.get("assignments")
            if set(decision) != {"kind","assignments"} or not isinstance(values, list) or not 1 <= len(values) <= _MAX_ASSIGNMENTS: raise OrchestratorDriverError("assignment decision is invalid")
            existing = {item.get("assignment_id") for item in snapshot["assignments"] if isinstance(item, Mapping)}; seen: set[str] = set()
            for item in values:
                if not isinstance(item, Mapping) or set(item) - ({"assignment_id","agent_id","binding_id","task_ref","objective"} | _ASSIGNMENT_OPTIONAL) or not {"assignment_id","agent_id","binding_id","task_ref","objective"}.issubset(item) or not all(isinstance(item.get(key),str) and _SAFE.fullmatch(item[key]) for key in ("assignment_id","agent_id","binding_id","task_ref")) or not isinstance(item.get("objective"),str) or not 1 <= len(item["objective"].encode()) <= 4096 or item["assignment_id"] in existing or item["assignment_id"] in seen or item["binding_id"] not in self.config.agent_bindings.get(item["agent_id"],frozenset()) or not self._valid_assignment_contract(item): raise OrchestratorDriverError("assignment is not allowlisted")
                seen.add(item["assignment_id"])
                fence = item.get("submission_fence")
                if fence is not None and fence.get("project_revision") != self.config.revision:
                    raise OrchestratorDriverError("assignment fence revision differs")
            available = existing | seen
            if any(dependency not in available for item in values for dependency in (item.get("depends_on") or [])):
                raise OrchestratorDriverError("assignment dependency is unknown")
            self._validate_dependency_graph(snapshot["assignments"] + list(values))
            return
        if kind == "request_expansion":
            target = decision.get("target_resources"); current = snapshot["resources"]
            if set(decision) != {"kind","target_resources"} or not isinstance(target, Mapping) or not target or len(target)>64 or any(not isinstance(key,str) or _SAFE.fullmatch(key) is None or type(value) not in {int,float} or not math.isfinite(value) or value < 0 for key,value in target.items()) or any(target.get(key,0) < value for key,value in current.items()) or not any(target.get(key,0) > value for key,value in current.items()): raise OrchestratorDriverError("resource expansion is invalid")
            return
        raise OrchestratorDriverError("decision kind is invalid")

    @staticmethod
    def _valid_assignment_contract(item: Mapping[str, Any]) -> bool:
        """Validate optional assignment fields shared with loop and executor."""
        depends = item.get("depends_on")
        if depends is not None and (not isinstance(depends, list) or len(depends) > _MAX_ASSIGNMENTS or any(not isinstance(value, str) or _SAFE.fullmatch(value) is None for value in depends) or len(set(depends)) != len(depends)):
            return False
        resources = item.get("resource_request")
        if resources is not None and (not isinstance(resources, Mapping) or len(resources) > _MAX_RESOURCES or any(not isinstance(key, str) or _SAFE.fullmatch(key) is None or isinstance(value, bool) or type(value) not in {int, float} or not math.isfinite(value) or value < 0 for key, value in resources.items())):
            return False
        digest = item.get("verification_input_tree_sha256")
        if not (digest is None or isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest) is not None): return False
        attempt, immutable = item.get("attempt_id"), item.get("immutable_revision")
        fence = item.get("submission_fence")
        if attempt is None and immutable is None:
            return fence is None
        if not (isinstance(attempt, str) and _SAFE.fullmatch(attempt) is not None and isinstance(immutable, str) and re.fullmatch(r"[0-9a-f]{40,64}", immutable) is not None and isinstance(fence, Mapping)):
            return False
        try:
            normalized = validate_submission_fence(fence)
        except RuntimeClientError:
            return False
        return normalized["assignment_id"] == item["assignment_id"] and normalized["immutable_revision"] == immutable

    @staticmethod
    def _validate_dependency_graph(assignments: list[Mapping[str, Any]]) -> None:
        graph = {item["assignment_id"]: (item.get("depends_on") or []) for item in assignments}
        visiting: set[str] = set()
        visited: set[str] = set()
        def visit(assignment_id: str) -> None:
            if assignment_id in visiting:
                raise OrchestratorDriverError("assignment dependency cycle")
            if assignment_id in visited:
                return
            visiting.add(assignment_id)
            for dependency in graph[assignment_id]:
                if dependency not in graph:
                    raise OrchestratorDriverError("assignment dependency is unknown")
                visit(dependency)
            visiting.remove(assignment_id)
            visited.add(assignment_id)
        for assignment_id in graph:
            visit(assignment_id)
