"""Management-owned typed façade over project orchestrator loops."""
from __future__ import annotations
from pathlib import Path
import re
from typing import Any, Mapping, Callable
from shared.contracts.project_reference import PORTABLE_PROJECT_FIELDS, validate_agent_definition, validate_identifier, validate_project_infrastructure_references, validate_reference, validate_secret_free, validate_storage_policy
from .project_orchestrator_loop import ProjectLoopConfiguration, ProjectOrchestratorLoop, OrchestratorLoopError
from .state_boundary import ManagementStateBoundaryError, validate_durable_directory, validate_durable_leaf

class OrchestratorManagementError(ValueError): pass
ProjectReferenceValidation = Callable[[Mapping[str, Any]], None]

class ProjectOrchestratorRegistry:
    def __init__(self, root:str|Path, *, loop_factory:Callable[...,ProjectOrchestratorLoop]=ProjectOrchestratorLoop, validate_project_references:ProjectReferenceValidation|None=None):
        self.factory=loop_factory
        self.validate_project_references=validate_project_references
        try:
            self.root=validate_durable_directory(Path(root), Path(root), label="orchestrator loop root")
        except (ManagementStateBoundaryError, TypeError) as error:
            raise OrchestratorManagementError("loop root is invalid") from error
    def _loop(self, project_id:str, revision:int, payload:Mapping[str,Any])->ProjectOrchestratorLoop:
        allowed_payload = PORTABLE_PROJECT_FIELDS
        if not isinstance(project_id,str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}",project_id) is None or type(revision) is not int or revision < 1 or not isinstance(payload,Mapping) or set(payload) - allowed_payload or not {"prd_reference","agents","resource_requested_envelope"}.issubset(payload): raise OrchestratorManagementError("confirmed intent snapshot is invalid")
        try:
            validate_secret_free(payload)
            validate_project_infrastructure_references(payload)
            validate_reference(payload.get("prd_reference"), "prd_reference")
            if "resource_pool_id" in payload:
                validate_identifier(payload.get("resource_pool_id"), "resource_pool_id")
        except ValueError as error:
            raise OrchestratorManagementError("confirmed intent snapshot is invalid") from error
        if ("provider_reference" in payload or "hardware_reference" in payload) and self.validate_project_references is None:
            raise OrchestratorManagementError("registered infrastructure reference validation is unavailable")
        if self.validate_project_references is not None:
            try:
                self.validate_project_references(payload)
            except (TypeError, ValueError) as error:
                raise OrchestratorManagementError("confirmed infrastructure reference is not registered") from error
        if "storage_binding" in payload:
            storage_binding = payload["storage_binding"]
            if (not isinstance(storage_binding, str) or storage_binding == "storage." or not storage_binding.startswith("storage.")):
                raise OrchestratorManagementError("storage binding is invalid")
            try:
                validate_identifier(storage_binding, "storage_binding")
            except ValueError as error:
                raise OrchestratorManagementError("storage binding is invalid") from error
        declared = payload.get("binding_references")
        if declared is not None:
            if not isinstance(declared, list):
                raise OrchestratorManagementError("binding references are invalid")
            try:
                for binding in declared:
                    validate_identifier(binding, "binding reference")
            except ValueError as error:
                raise OrchestratorManagementError("binding references are invalid") from error
            if len(set(declared)) != len(declared):
                raise OrchestratorManagementError("binding references are invalid")
            if "storage_binding" in payload and payload["storage_binding"] not in declared:
                raise OrchestratorManagementError("storage binding is not declared")
        agents=payload.get("agents"); envelope=payload.get("resource_requested_envelope")
        if not isinstance(agents,list) or not isinstance(envelope,Mapping):raise OrchestratorManagementError("confirmed intent snapshot is invalid")
        if "storage_policy" in payload:
            try:
                validate_storage_policy(payload["storage_policy"])
            except ValueError as error:
                raise OrchestratorManagementError("storage policy is invalid")
        orchestrators=[a for a in agents if isinstance(a,Mapping) and a.get("role")=="project_orchestrator"]
        if len(orchestrators)!=1:raise OrchestratorManagementError("one orchestrator is required")
        bindings={}
        if not 1 <= len(agents) <= 128 or not 1 <= len(envelope) <= 64: raise OrchestratorManagementError("confirmed intent snapshot is invalid")
        metadata={}
        agent_ids = set()
        for agent in agents:
            try:
                validate_agent_definition(agent)
            except ValueError as error:
                raise OrchestratorManagementError("agent snapshot is invalid") from error
            if agent["id"] in agent_ids: raise OrchestratorManagementError("agent snapshot is invalid")
            agent_ids.add(agent["id"])
            bindings[agent["id"]]=agent["capability_bindings"]
            values={key:agent[key] for key in ("model_binding", "system_prompt") if key in agent}
            if values:
                metadata[agent["id"]]=values
        if declared is not None and not set(binding for agent in agents for binding in agent["capability_bindings"]).issubset(set(declared)):
            raise OrchestratorManagementError("binding references are invalid")
        try:
            database = validate_durable_leaf(self.root / (project_id + ".sqlite3"), self.root, label="orchestrator loop database")
            descriptor = dict(payload)
            return self.factory(database,ProjectLoopConfiguration(project_id,revision,bindings,envelope,metadata,descriptor))
        except ManagementStateBoundaryError as error:
            raise OrchestratorManagementError("orchestrator loop database is unsafe") from error
        except OrchestratorLoopError as error:raise OrchestratorManagementError("loop configuration is invalid") from error
    def start_from_confirmed_intent(self, intent:Mapping[str,Any], idempotency_key:str)->dict[str,Any]:
        if not isinstance(intent,Mapping) or set(intent)!={"intent_id","body"} or not isinstance(intent.get("body"),Mapping):raise OrchestratorManagementError("start intent is invalid")
        body=intent["body"]
        if set(body)!={"project_id","revision","kind","payload"} or body.get("kind")!="project_start_intent" or not isinstance(body.get("project_id"),str) or type(body.get("revision")) is not int or not isinstance(body.get("payload"),Mapping):raise OrchestratorManagementError("start intent is invalid")
        try: loop=self._loop(body["project_id"],body["revision"],body["payload"]);result=loop.start(idempotency_key)
        except OrchestratorLoopError as error: raise OrchestratorManagementError("loop start was rejected") from error
        return {"project_id":body["project_id"],"revision":body["revision"],"loop":result}
    def snapshot(self,project_id:str,revision:int,payload:Mapping[str,Any])->dict[str,Any]:
        try:return self._loop(project_id,revision,payload).snapshot()
        except OrchestratorLoopError as error:raise OrchestratorManagementError("loop snapshot is unavailable") from error

    def invoke(self, project_id: str, revision: int, payload: Mapping[str, Any], method: str, *args: Any, **kwargs: Any) -> dict[str, Any]:
        """Invoke only a public typed loop operation; the HTTP adapter never sees a DB path."""
        allowed = {"decision", "report_progress", "resolve_expansion", "request_pause", "drain_pause", "resume"}
        if method not in allowed:
            raise OrchestratorManagementError("loop operation is not permitted")
        try: result = getattr(self._loop(project_id, revision, payload), method)(*args, **kwargs)
        except OrchestratorLoopError as error: raise OrchestratorManagementError("loop operation was rejected") from error
        if not isinstance(result, dict):
            raise OrchestratorManagementError("loop operation returned an invalid receipt")
        return result
