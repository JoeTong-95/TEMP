"""Durable, side-effect-free node contribution and withdrawal decisions.

This module is deliberately only the coordinator's journal and policy core.  It
does not start services, kill processes, send messages, or power off hardware.
Native observations and coordinator decisions are recorded separately so a
caller cannot mistake a requested withdrawal for evidence that it is safe.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import time
from typing import Any, Callable, Literal


Action = Literal["contribute", "withdraw"]
EvidenceSource = Literal["native", "coordinator"]


class RequestConflict(ValueError):
    """A request id was reused with different immutable intent."""


@dataclass(frozen=True)
class LifecycleOperation:
    request_id: str
    node_id: str
    action: Action
    state: str
    ready_by: str | None
    created_at: float


@dataclass(frozen=True)
class WithdrawalSafety:
    safe: bool
    reasons: tuple[str, ...]


class NodeLifecycleJournal:
    """SQLite-backed lifecycle record with injected time for deterministic tests.

    Authentication and authorization of callers are external to this pure core;
    its boolean predicates are durable inputs, not an authentication mechanism.
    A single coordinator writer is required; multi-writer arbitration and locking
    are external deployment responsibilities.
    """

    HEALTHY_WINDOW_SECONDS = 60.0

    def __init__(
        self,
        path: str | Path,
        *,
        clock: Callable[[], float] = time.time,
        max_heartbeat_gap_seconds: float = 15.0,
    ) -> None:
        if not math.isfinite(max_heartbeat_gap_seconds) or max_heartbeat_gap_seconds <= 0:
            raise ValueError("max_heartbeat_gap_seconds must be a positive finite number")
        self._clock = clock
        self._max_heartbeat_gap_seconds = float(max_heartbeat_gap_seconds)
        self._connection = sqlite3.connect(str(path))
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=FULL")
        self._connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS operations (
                request_id TEXT PRIMARY KEY,
                node_id TEXT NOT NULL,
                action TEXT NOT NULL CHECK(action IN ('contribute', 'withdraw')),
                payload_sha256 TEXT NOT NULL,
                ready_by TEXT,
                state TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT NOT NULL REFERENCES operations(request_id),
                source TEXT NOT NULL CHECK(source IN ('native', 'coordinator')),
                kind TEXT NOT NULL,
                value_json TEXT NOT NULL,
                observed_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS connection_state (
                node_id TEXT PRIMARY KEY,
                state TEXT NOT NULL,
                healthy_since REAL,
                last_healthy_at REAL,
                owner_id TEXT,
                updated_at REAL NOT NULL
            );
            """
        )
        columns = {row["name"] for row in self._connection.execute("PRAGMA table_info(connection_state)")}
        if "last_healthy_at" not in columns:
            self._connection.execute("ALTER TABLE connection_state ADD COLUMN last_healthy_at REAL")
        self._connection.commit()

    def close(self) -> None:
        self._connection.close()

    def contribute(self, request_id: str, node_id: str, *, actor_id: str, ready_by: str | None = None) -> LifecycleOperation:
        return self._submit(request_id, node_id, "contribute", actor_id, ready_by)

    def withdraw(self, request_id: str, node_id: str, *, actor_id: str, ready_by: str | None = None) -> LifecycleOperation:
        """Record a withdrawal request; ``ready_by`` remains advisory only."""
        return self._submit(request_id, node_id, "withdraw", actor_id, ready_by)

    def record_evidence(
        self, request_id: str, *, source: EvidenceSource, kind: str, value: Any, observed_at: float | None = None
    ) -> None:
        if source not in ("native", "coordinator"):
            raise ValueError("evidence source must be native or coordinator")
        if not kind:
            raise ValueError("evidence kind is required")
        if self._connection.execute("SELECT 1 FROM operations WHERE request_id = ?", (request_id,)).fetchone() is None:
            raise KeyError(f"unknown request: {request_id}")
        self._validate_evidence(source, kind, value)
        timestamp = self._now() if observed_at is None else float(observed_at)
        if not math.isfinite(timestamp) or timestamp > self._now():
            raise ValueError("evidence time must be finite and not in the future")
        previous = self._connection.execute(
            """SELECT observed_at FROM evidence WHERE request_id = ? AND source = ? AND kind = ?
               ORDER BY observed_at DESC, id DESC LIMIT 1""",
            (request_id, source, kind),
        ).fetchone()
        if previous is not None and timestamp < previous["observed_at"]:
            raise ValueError("evidence time cannot precede authoritative evidence of the same kind")
        encoded = _canonical_json(value)
        self._connection.execute(
            "INSERT INTO evidence(request_id, source, kind, value_json, observed_at) VALUES (?, ?, ?, ?, ?)",
            (request_id, source, kind, encoded, timestamp),
        )
        operation = self.operation(request_id)
        if operation.action == "withdraw" and operation.state == "SAFE_TO_POWER_OFF" and self._withdrawal_reasons(request_id):
            # This is deliberately in the same SQLite transaction as the adverse
            # evidence insert, so operation() cannot expose stale safe state.
            self._connection.execute("UPDATE operations SET state = 'WITHDRAWAL_BLOCKED' WHERE request_id = ?", (request_id,))
        self._connection.commit()

    def withdrawal_safety(self, request_id: str) -> WithdrawalSafety:
        operation = self.operation(request_id)
        if operation.action != "withdraw":
            raise ValueError("withdrawal safety applies only to withdraw operations")
        reasons = self._withdrawal_reasons(request_id)
        safe = not reasons
        if safe and operation.state != "SAFE_TO_POWER_OFF":
            self._connection.execute("UPDATE operations SET state = 'SAFE_TO_POWER_OFF' WHERE request_id = ?", (request_id,))
            self._connection.commit()
        elif not safe and operation.state == "SAFE_TO_POWER_OFF":
            self._connection.execute("UPDATE operations SET state = 'WITHDRAWAL_BLOCKED' WHERE request_id = ?", (request_id,))
            self._connection.commit()
        return WithdrawalSafety(safe=safe, reasons=tuple(reasons))

    def _withdrawal_reasons(self, request_id: str) -> list[str]:
        rows = self._connection.execute(
            """SELECT source, kind, value_json FROM (
                   SELECT source, kind, value_json,
                          ROW_NUMBER() OVER (PARTITION BY source, kind ORDER BY observed_at DESC, id DESC) AS rank
                   FROM evidence WHERE request_id = ?
               ) WHERE rank = 1""",
            (request_id,),
        ).fetchall()
        latest = {(row["source"], row["kind"]): json.loads(row["value_json"]) for row in rows}
        reasons: list[str] = []
        if latest.get(("coordinator", "durable_handoff")) is not True:
            reasons.append("durable_handoff_unverified")
        if latest.get(("native", "leases_released")) is not True:
            reasons.append("leases_not_released")
        if latest.get(("native", "unknown_outcomes")) != 0:
            reasons.append("unknown_outcomes_present")
        return reasons

    def mark_disconnected(self, node_id: str) -> None:
        """Fail closed: disconnection pauses the node and clears healthy time."""
        self._connection.execute(
            """INSERT INTO connection_state(node_id, state, healthy_since, last_healthy_at, owner_id, updated_at)
               VALUES (?, 'DISCONNECTED_PAUSED', NULL, NULL, NULL, ?)
               ON CONFLICT(node_id) DO UPDATE SET state = 'DISCONNECTED_PAUSED', healthy_since = NULL,
                   last_healthy_at = NULL, owner_id = NULL, updated_at = excluded.updated_at""",
            (node_id, self._now()),
        )
        self._connection.commit()

    def observe_unhealthy(self, node_id: str) -> None:
        """Record a failed health observation, resetting the continuous-health window."""
        self.mark_disconnected(node_id)

    def observe_healthy(
        self,
        node_id: str,
        *,
        owner_id: str,
        orchestrator_approved: bool,
        ownership_verified: bool,
        effects_reconciled: bool,
    ) -> str:
        """Return a readiness decision; callers must perform and prove any resume separately."""
        if not node_id or not owner_id:
            raise ValueError("node_id and owner_id are required")
        if any(type(value) is not bool for value in (orchestrator_approved, ownership_verified, effects_reconciled)):
            raise ValueError("recovery predicates must be booleans")
        now = self._now()
        row = self._connection.execute("SELECT * FROM connection_state WHERE node_id = ?", (node_id,)).fetchone()
        if row is None:
            self._connection.execute(
                """INSERT INTO connection_state(node_id, state, healthy_since, last_healthy_at, owner_id, updated_at)
                   VALUES (?, 'HEALTHY_OBSERVING', ?, ?, ?, ?)""",
                (node_id, now, now, owner_id, now),
            )
            self._connection.commit()
            return "HEALTHY_OBSERVING"
        reset = (
            row["owner_id"] != owner_id
            or row["healthy_since"] is None
            or row["last_healthy_at"] is None
            or now < row["last_healthy_at"]
            or now - row["last_healthy_at"] > self._max_heartbeat_gap_seconds
        )
        healthy_since = now if reset else row["healthy_since"]
        observed_for = now - healthy_since
        state = "HEALTHY_OBSERVING"
        if observed_for >= self.HEALTHY_WINDOW_SECONDS and orchestrator_approved and ownership_verified and effects_reconciled:
            state = "RESUME_READY"
        self._connection.execute(
            "UPDATE connection_state SET state = ?, healthy_since = ?, last_healthy_at = ?, owner_id = ?, updated_at = ? WHERE node_id = ?",
            (state, healthy_since, now, owner_id, now, node_id),
        )
        self._connection.commit()
        return state

    def connection_state(self, node_id: str) -> str | None:
        row = self._connection.execute("SELECT state FROM connection_state WHERE node_id = ?", (node_id,)).fetchone()
        return None if row is None else str(row["state"])

    def operation(self, request_id: str) -> LifecycleOperation:
        row = self._connection.execute("SELECT * FROM operations WHERE request_id = ?", (request_id,)).fetchone()
        if row is None:
            raise KeyError(f"unknown request: {request_id}")
        return LifecycleOperation(row["request_id"], row["node_id"], row["action"], row["state"], row["ready_by"], row["created_at"])

    def _submit(self, request_id: str, node_id: str, action: Action, actor_id: str, ready_by: str | None) -> LifecycleOperation:
        if not request_id or not node_id or not actor_id:
            raise ValueError("request_id, node_id, and actor_id are required")
        _validate_ready_by(ready_by)
        payload = {"action": action, "actor_id": actor_id, "node_id": node_id, "ready_by": ready_by}
        digest = hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()
        row = self._connection.execute("SELECT * FROM operations WHERE request_id = ?", (request_id,)).fetchone()
        if row is not None:
            if row["payload_sha256"] != digest:
                raise RequestConflict(f"request id {request_id} was reused with different intent")
            return self.operation(request_id)
        state = "CONTRIBUTION_REQUESTED" if action == "contribute" else "WITHDRAWAL_REQUESTED"
        self._connection.execute(
            "INSERT INTO operations(request_id, node_id, action, payload_sha256, ready_by, state, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (request_id, node_id, action, digest, ready_by, state, self._now()),
        )
        self._connection.commit()
        return self.operation(request_id)

    def _now(self) -> float:
        value = float(self._clock())
        if not math.isfinite(value):
            raise ValueError("clock must return a finite timestamp")
        return value

    @staticmethod
    def _validate_evidence(source: EvidenceSource, kind: str, value: Any) -> None:
        expected = {
            ("coordinator", "durable_handoff"): bool,
            ("native", "leases_released"): bool,
        }.get((source, kind))
        if expected is bool and type(value) is not bool:
            raise ValueError(f"{kind} must be a boolean")
        if (source, kind) == ("native", "unknown_outcomes") and (type(value) is not int or value < 0):
            raise ValueError("unknown_outcomes must be a non-negative integer")


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _validate_ready_by(value: str | None) -> None:
    """Accept an RFC 3339 offset timestamp or null; it never authorizes force."""
    if value is None:
        return
    if not isinstance(value, str):
        raise ValueError("ready_by must be an RFC 3339 timestamp or null")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("ready_by must be an RFC 3339 timestamp or null") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("ready_by must include a UTC offset")


def utc_timestamp(epoch_seconds: float) -> str:
    """A presentation helper; journal timestamps stay numeric for deterministic policy."""
    return datetime.fromtimestamp(epoch_seconds, tz=timezone.utc).isoformat().replace("+00:00", "Z")
