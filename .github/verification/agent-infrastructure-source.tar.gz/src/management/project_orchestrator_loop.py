"""Durable typed project-orchestrator loop; adapters execute, never decide."""
from __future__ import annotations
import json, sqlite3, re, math, hashlib
from datetime import datetime, timezone
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Callable
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root
from shared.contracts.project_reference import validate_secret_free
from shared.contracts.agent_runtime import RuntimeClientError, validate_submission_fence

class OrchestratorLoopError(ValueError): pass
class OrchestratorConflict(OrchestratorLoopError): pass
def _canon(v: Any)->str:return json.dumps(v,sort_keys=True,separators=(",",":"),allow_nan=False)
_SAFE=re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_MAX_RESOURCES=64;_MAX_AGENTS=128;_MAX_BINDINGS=32;_MAX_ASSIGNMENTS=64;_MAX_EVENTS=100
def _valid_resources(value:object)->bool:return isinstance(value,Mapping) and bool(value) and len(value)<=_MAX_RESOURCES and all(isinstance(k,str) and _SAFE.fullmatch(k) and type(v) in {int,float} and math.isfinite(v) and v>=0 for k,v in value.items())
def _valid_assignment_resources(value:object)->bool:return value is None or isinstance(value,Mapping) and len(value)<=_MAX_RESOURCES and all(isinstance(k,str) and _SAFE.fullmatch(k) and not isinstance(v,bool) and type(v) in {int,float} and math.isfinite(v) and v>=0 for k,v in value.items())
def _valid_assignment_dependencies(value:object,assignment_id:str)->bool:return value is None or isinstance(value,list) and len(value)<=_MAX_ASSIGNMENTS and all(isinstance(item,str) and _SAFE.fullmatch(item) for item in value) and len(set(value))==len(value)
def _valid_verification_digest(value:object)->bool:return value is None or isinstance(value,str) and re.fullmatch(r"[0-9a-f]{64}",value) is not None

@dataclass(frozen=True)
class ProjectLoopConfiguration:
    project_id:str; revision:int; agents:Mapping[str,str]; resource_envelope:Mapping[str,int]
    agent_metadata:Mapping[str,Mapping[str,str]] = field(default_factory=dict)
    project_descriptor:Mapping[str,Any] = field(default_factory=dict)

class ProjectOrchestratorLoop:
    def __init__(self,database:str|Path, config:ProjectLoopConfiguration, *, clock:Callable[[],datetime]|None=None):
        normalized={agent:frozenset(value) if isinstance(value,(list,tuple,set,frozenset)) else frozenset({value}) for agent,value in config.agents.items()}
        metadata={agent:dict(value) for agent,value in config.agent_metadata.items()} if isinstance(config.agent_metadata, Mapping) else {}
        try:
            validate_secret_free(config.project_descriptor)
            descriptor = json.loads(_canon(config.project_descriptor)) if isinstance(config.project_descriptor, Mapping) else None
        except (TypeError, ValueError, OverflowError) as error:
            raise OrchestratorLoopError("loop configuration is invalid") from error
        try:
            database_path = Path(database)
            self.path = validate_durable_leaf(database_path, validate_state_root(database_path.parent, "orchestrator state root"), label="orchestrator loop database")
        except (ManagementStateBoundaryError, TypeError) as error:
            raise OrchestratorLoopError("orchestrator loop database is unsafe") from error
        self.config=ProjectLoopConfiguration(config.project_id,config.revision,normalized,dict(config.resource_envelope),metadata,descriptor or {})
        self.clock=clock or (lambda:datetime.now(timezone.utc))
        if not self.path.is_absolute() or not self.path.parent.is_dir() or not isinstance(config.project_id,str) or not _SAFE.fullmatch(config.project_id) or type(config.revision)is not int or config.revision<1 or not config.agents or len(config.agents)>_MAX_AGENTS or any(not isinstance(a,str) or not _SAFE.fullmatch(a) or not b or len(b)>_MAX_BINDINGS or any(not isinstance(x,str) or not _SAFE.fullmatch(x) for x in b) for a,b in normalized.items()) or not _valid_resources(config.resource_envelope) or set(metadata) - set(normalized) or any(not isinstance(agent,str) or not _SAFE.fullmatch(agent) or set(values) - {"model_binding","system_prompt"} or ("model_binding" in values and (not isinstance(values["model_binding"],str) or not _SAFE.fullmatch(values["model_binding"]))) or ("system_prompt" in values and (not isinstance(values["system_prompt"],str) or not 1 <= len(values["system_prompt"].encode()) <= 16 * 1024)) for agent,values in metadata.items()) or not isinstance(descriptor, Mapping) or len(_canon(descriptor).encode()) > 64 * 1024:raise OrchestratorLoopError("loop configuration is invalid")
        fingerprint_payload={"revision":config.revision,"agents":{key:sorted(value) for key,value in normalized.items()},"resources":dict(config.resource_envelope)}
        # Preserve restart compatibility for loops persisted before rev3 agent
        # metadata existed; metadata becomes part of identity only when present.
        if metadata:
            fingerprint_payload["agent_metadata"] = metadata
        if descriptor:
            fingerprint_payload["project_descriptor"] = descriptor
        self.fingerprint=hashlib.sha256(_canon(fingerprint_payload).encode()).hexdigest()
        with self._db() as c:
            c.execute("CREATE TABLE IF NOT EXISTS orchestrator_loops(project_id TEXT PRIMARY KEY,revision INTEGER NOT NULL,config_fingerprint TEXT NOT NULL,state TEXT NOT NULL,version INTEGER NOT NULL,resources TEXT NOT NULL,pending_request TEXT,decision TEXT)");c.execute("CREATE TABLE IF NOT EXISTS orchestrator_actions(project_id TEXT NOT NULL,revision INTEGER NOT NULL,idempotency_key TEXT NOT NULL,fingerprint TEXT NOT NULL,response TEXT NOT NULL,PRIMARY KEY(project_id,revision,idempotency_key))");c.execute("CREATE TABLE IF NOT EXISTS orchestrator_assignments(project_id TEXT NOT NULL,revision INTEGER NOT NULL,assignment_id TEXT NOT NULL,agent_id TEXT NOT NULL,binding_id TEXT NOT NULL,task_ref TEXT NOT NULL,objective TEXT NOT NULL,state TEXT NOT NULL,receipt TEXT,depends_on TEXT,resource_request TEXT,verification_input_tree_sha256 TEXT,attempt_id TEXT,immutable_revision TEXT,PRIMARY KEY(project_id,revision,assignment_id))");assignment_columns={row[1] for row in c.execute("PRAGMA table_info(orchestrator_assignments)")};
            if "depends_on" not in assignment_columns: c.execute("ALTER TABLE orchestrator_assignments ADD COLUMN depends_on TEXT")
            if "resource_request" not in assignment_columns: c.execute("ALTER TABLE orchestrator_assignments ADD COLUMN resource_request TEXT")
            if "verification_input_tree_sha256" not in assignment_columns: c.execute("ALTER TABLE orchestrator_assignments ADD COLUMN verification_input_tree_sha256 TEXT")
            if "attempt_id" not in assignment_columns: c.execute("ALTER TABLE orchestrator_assignments ADD COLUMN attempt_id TEXT")
            if "immutable_revision" not in assignment_columns: c.execute("ALTER TABLE orchestrator_assignments ADD COLUMN immutable_revision TEXT")
            if "submission_fence" not in assignment_columns: c.execute("ALTER TABLE orchestrator_assignments ADD COLUMN submission_fence TEXT")
            c.execute("CREATE TABLE IF NOT EXISTS orchestrator_assignment_events(project_id TEXT NOT NULL,revision INTEGER NOT NULL,assignment_id TEXT NOT NULL,event_id INTEGER PRIMARY KEY AUTOINCREMENT,event TEXT NOT NULL)")
            row=c.execute("SELECT revision,config_fingerprint FROM orchestrator_loops WHERE project_id=?",(config.project_id,)).fetchone()
            if row and row["revision"] != config.revision:
                raise OrchestratorConflict("persisted loop configuration differs")
            if row and row["config_fingerprint"] != self.fingerprint:
                # Databases created before project descriptors were included in
                # loop identity have no descriptor to compare.  Migrate only an
                # exact legacy fingerprint, then bind all future restarts to the
                # complete descriptor fingerprint.
                legacy = {"revision": config.revision, "agents": {key: sorted(value) for key, value in normalized.items()}, "resources": dict(config.resource_envelope)}
                if metadata:
                    legacy["agent_metadata"] = metadata
                legacy_fingerprint = hashlib.sha256(_canon(legacy).encode()).hexdigest()
                if row["config_fingerprint"] != legacy_fingerprint:
                    raise OrchestratorConflict("persisted loop configuration differs")
                c.execute("UPDATE orchestrator_loops SET config_fingerprint=? WHERE project_id=?", (self.fingerprint, config.project_id))
            self._validate_persisted_dependency_graph(c)
    @contextmanager
    def _db(self):
        c=sqlite3.connect(self.path);c.row_factory=sqlite3.Row
        try:
            with c:yield c
        finally:c.close()
    def _validate_persisted_dependency_graph(self,c:sqlite3.Connection)->None:
        graph:dict[str,list[str]]={}
        for item in c.execute("SELECT assignment_id,depends_on FROM orchestrator_assignments WHERE project_id=? AND revision=?",(self.config.project_id,self.config.revision)):
            assignment_id=item["assignment_id"]
            try:depends=json.loads(item["depends_on"]) if item["depends_on"] else []
            except (TypeError,ValueError,UnicodeError) as error:raise OrchestratorLoopError("persisted assignment dependencies are malformed") from error
            if not isinstance(assignment_id,str) or not _SAFE.fullmatch(assignment_id) or not _valid_assignment_dependencies(depends,assignment_id):raise OrchestratorLoopError("persisted assignment dependencies are malformed")
            graph[assignment_id]=depends
        for dependencies in graph.values():
            if any(dependency not in graph for dependency in dependencies):raise OrchestratorLoopError("assignment dependency is unknown")
        visiting:set[str]=set();visited:set[str]=set()
        def visit(assignment_id:str)->None:
            if assignment_id in visiting:raise OrchestratorLoopError("assignment dependency cycle")
            if assignment_id in visited:return
            visiting.add(assignment_id)
            for dependency in graph[assignment_id]:visit(dependency)
            visiting.remove(assignment_id);visited.add(assignment_id)
        for assignment_id in graph:visit(assignment_id)
    def start(self,key:str)->dict[str,Any]:
        def effect(c,row=None):
            if row is not None:return {"state":row["state"],"version":row["version"]}
            c.execute("INSERT INTO orchestrator_loops VALUES(?,?,?, 'turn_ready',1,?,NULL,NULL)",(self.config.project_id,self.config.revision,self.fingerprint,_canon(dict(self.config.resource_envelope))))
            return {"state":"turn_ready","version":1}
        return self._action(key,{"kind":"start"},effect)
    def _action(self,key:str,command:Mapping[str,Any],effect):
        if not isinstance(key,str) or not _SAFE.fullmatch(key):raise OrchestratorLoopError("idempotency key is required")
        fp=_canon(command)
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            row=c.execute("SELECT * FROM orchestrator_loops WHERE project_id=?",(self.config.project_id,)).fetchone()
            if row is not None and row["revision"] != self.config.revision:
                raise OrchestratorConflict("persisted loop revision differs")
            old=c.execute("SELECT fingerprint,response FROM orchestrator_actions WHERE project_id=? AND revision=? AND idempotency_key=?",(self.config.project_id,self.config.revision,key)).fetchone()
            if old:
                if old["fingerprint"]!=fp:raise OrchestratorConflict("idempotency conflict")
                return json.loads(old["response"])
            result=effect(c) if row is None else effect(c,row)
            c.execute("INSERT INTO orchestrator_actions VALUES(?,?,?,?,?)",(self.config.project_id,self.config.revision,key,fp,_canon(result)));return result
    def decision(self,key:str,expected_version:int,decision:Mapping[str,Any])->dict[str,Any]:
        if not isinstance(decision,Mapping) or type(expected_version)is not int:raise OrchestratorLoopError("typed decision is invalid")
        def effect(c,row):
            if row is None:raise OrchestratorConflict("loop not started")
            if row["version"]!=expected_version or row["state"] not in {"turn_ready","waiting"}:raise OrchestratorConflict("stale or terminal decision")
            if row["pending_request"]:raise OrchestratorConflict("pending expansion requires resolution")
            kind=decision.get("kind")
            if kind=="assign":
                if set(decision)!={"kind","assignments"}:raise OrchestratorLoopError("decision schema is invalid")
                assignments=decision.get("assignments")
                if not isinstance(assignments,list) or not assignments or len(assignments)>_MAX_ASSIGNMENTS:raise OrchestratorLoopError("assignments are invalid")
                existing_ids={row[0] for row in c.execute("SELECT assignment_id FROM orchestrator_assignments WHERE project_id=? AND revision=?",(self.config.project_id,self.config.revision))}
                batch_ids=set()
                for item in assignments:
                    if not isinstance(item,Mapping) or not {"assignment_id","agent_id","binding_id","task_ref","objective"}.issubset(item) or set(item)-{"assignment_id","agent_id","binding_id","task_ref","objective","depends_on","resource_request","verification_input_tree_sha256","attempt_id","immutable_revision","submission_fence"} or any(not isinstance(item.get(key),str) or not _SAFE.fullmatch(item[key]) for key in ("assignment_id","agent_id","binding_id","task_ref")) or not isinstance(item.get("objective"),str) or not 1<=len(item["objective"].encode())<=4096 or item.get("binding_id") not in self.config.agents.get(item["agent_id"],frozenset()):raise OrchestratorLoopError("assignment is not allowlisted")
                    if item["assignment_id"] in existing_ids or item["assignment_id"] in batch_ids: raise OrchestratorConflict("assignment already exists")
                    depends=item.get("depends_on"); resources=item.get("resource_request"); digest=item.get("verification_input_tree_sha256")
                    if not _valid_assignment_dependencies(depends,item["assignment_id"]): raise OrchestratorLoopError("assignment dependencies are invalid")
                    if not _valid_assignment_resources(resources): raise OrchestratorLoopError("assignment resources are invalid")
                    if not _valid_verification_digest(digest): raise OrchestratorLoopError("assignment verification digest is invalid")
                    attempt, immutable = item.get("attempt_id"), item.get("immutable_revision")
                    if (attempt is None) != (immutable is None) or (attempt is not None and (not isinstance(attempt, str) or _SAFE.fullmatch(attempt) is None or not isinstance(immutable, str) or re.fullmatch(r"[0-9a-f]{40,64}", immutable) is None)): raise OrchestratorLoopError("assignment prepared source identity is invalid")
                    if immutable is None and item.get("submission_fence") is not None: raise OrchestratorLoopError("legacy assignment cannot carry a submission fence")
                    if immutable is not None and not isinstance(item.get("submission_fence"), Mapping): raise OrchestratorLoopError("prepared assignment submission fence is required")
                    if immutable is not None:
                        try: fence = validate_submission_fence(item["submission_fence"])
                        except RuntimeClientError as error: raise OrchestratorLoopError("prepared assignment submission fence is invalid") from error
                        if fence["assignment_id"] != item["assignment_id"] or fence["immutable_revision"] != immutable or fence["project_revision"] != self.config.revision: raise OrchestratorLoopError("prepared assignment submission fence does not match assignment")
                    batch_ids.add(item["assignment_id"])
                if any(dependency not in existing_ids|batch_ids for item in assignments for dependency in (item.get("depends_on") or [])): raise OrchestratorLoopError("assignment dependency is unknown")
                graph={row[0]:json.loads(row[1]) if row[1] else [] for row in c.execute("SELECT assignment_id,depends_on FROM orchestrator_assignments WHERE project_id=? AND revision=?",(self.config.project_id,self.config.revision))}
                graph.update({item["assignment_id"]:(item.get("depends_on") or []) for item in assignments})
                visiting=set();visited=set()
                def visit(assignment_id:str)->None:
                    if assignment_id in visiting: raise OrchestratorLoopError("assignment dependency cycle")
                    if assignment_id in visited: return
                    visiting.add(assignment_id)
                    for dependency in graph[assignment_id]:
                        if dependency not in graph: raise OrchestratorLoopError("assignment dependency is unknown")
                        visit(dependency)
                    visiting.remove(assignment_id);visited.add(assignment_id)
                for assignment_id in graph: visit(assignment_id)
                for item in assignments:
                    depends=item.get("depends_on"); resources=item.get("resource_request"); digest=item.get("verification_input_tree_sha256")
                    try:c.execute("INSERT INTO orchestrator_assignments(project_id,revision,assignment_id,agent_id,binding_id,task_ref,objective,state,receipt,depends_on,resource_request,verification_input_tree_sha256,attempt_id,immutable_revision,submission_fence) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(self.config.project_id,self.config.revision,item["assignment_id"],item["agent_id"],item["binding_id"],item["task_ref"],item["objective"],'assigned',None,_canon(depends) if depends else None,_canon(dict(resources)) if resources else None,digest,item.get("attempt_id"),item.get("immutable_revision"),_canon(dict(item["submission_fence"])) if isinstance(item.get("submission_fence"),Mapping) else None))
                    except sqlite3.IntegrityError as error:raise OrchestratorConflict("assignment already exists") from error
                state="waiting";pending=None
            elif kind in {"waiting","blocked"}:
                if set(decision)!={"kind"}:raise OrchestratorLoopError("decision schema is invalid")
                state=kind;pending=None
            elif kind=="completed":
                if set(decision)!={"kind"}:raise OrchestratorLoopError("decision schema is invalid")
                active=c.execute("SELECT 1 FROM orchestrator_assignments WHERE project_id=? AND revision=? AND state NOT IN ('succeeded','waived')",(self.config.project_id,self.config.revision)).fetchone()
                if active:raise OrchestratorConflict("active assignments prevent completion")
                state="completed";pending=None
            elif kind=="request_expansion":
                if set(decision)!={"kind","target_resources"} or not _valid_resources(requested:=decision.get("target_resources")):raise OrchestratorLoopError("resource request is invalid")
                retained=json.loads(row["resources"]);delta={key:requested.get(key,0)-retained.get(key,0) for key in set(requested)|set(retained)}
                if any(value<0 for value in delta.values()) or not any(value>0 for value in delta.values()):raise OrchestratorLoopError("resource request must increase retained allocation")
                state="waiting";pending=_canon({"kind":"pending_human_or_codex_resource_request","target":dict(requested),"delta":delta,"retained":retained})
            else:raise OrchestratorLoopError("decision kind is invalid")
            version=row["version"]+1;changed=c.execute("UPDATE orchestrator_loops SET state=?,version=?,pending_request=?,decision=? WHERE project_id=? AND version=?",(state,version,pending,_canon(dict(decision)),self.config.project_id,expected_version)).rowcount
            if changed!=1:raise OrchestratorConflict("stale decision")
            return {"project_id":self.config.project_id,"revision":self.config.revision,"state":state,"version":version,"pending_request":json.loads(pending) if pending else None}
        return self._action(key,{"kind":"decision","version":expected_version,"decision":dict(decision)},effect)
    def report_progress(self,key:str,agent_id:str,assignment_id:str,progress:Mapping[str,Any])->dict[str,Any]:
        if self.config.agents.get(agent_id) is None or not isinstance(assignment_id,str) or not _SAFE.fullmatch(assignment_id) or not isinstance(progress,Mapping) or progress.get("state") not in {"running","succeeded","blocked","paused"}:raise OrchestratorLoopError("progress is unauthorized")
        state=progress["state"]
        if state=="running" and set(progress)!={"state"}:raise OrchestratorLoopError("progress is unauthorized")
        if state=="succeeded" and (set(progress)!={"state","effect_receipt","verification_receipt"} or not all(isinstance(progress.get(k),str) and _SAFE.fullmatch(progress[k]) for k in ("effect_receipt","verification_receipt")) or progress["effect_receipt"]==progress["verification_receipt"]):raise OrchestratorLoopError("progress is unauthorized")
        if state=="blocked" and (set(progress)!={"state","reason","evidence_receipt"} or not isinstance(progress.get("reason"),str) or not 1<=len(progress["reason"].encode())<=1024 or not isinstance(progress.get("evidence_receipt"),str) or not _SAFE.fullmatch(progress["evidence_receipt"])):raise OrchestratorLoopError("progress is unauthorized")
        if state=="paused" and (set(progress)!={"state","checkpoint_receipt"} or not isinstance(progress.get("checkpoint_receipt"),str) or not _SAFE.fullmatch(progress["checkpoint_receipt"])):raise OrchestratorLoopError("progress is unauthorized")
        def effect(c,row):
            assignment=c.execute("SELECT * FROM orchestrator_assignments WHERE project_id=? AND revision=? AND assignment_id=?",(self.config.project_id,self.config.revision,assignment_id)).fetchone()
            if assignment is None or assignment["agent_id"]!=agent_id:raise OrchestratorConflict("assignment is not owned")
            c.execute("INSERT INTO orchestrator_assignment_events(project_id,revision,assignment_id,event) VALUES(?,?,?,?)",(self.config.project_id,self.config.revision,assignment_id,_canon(dict(progress))))
            changed=c.execute("UPDATE orchestrator_assignments SET state=?,receipt=? WHERE project_id=? AND revision=? AND assignment_id=? AND state IN ('assigned','running','paused')",(progress["state"],_canon(dict(progress)),self.config.project_id,self.config.revision,assignment_id)).rowcount
            if changed!=1:raise OrchestratorConflict("assignment progress is stale")
            pending=c.execute("SELECT 1 FROM orchestrator_assignments WHERE project_id=? AND revision=? AND state NOT IN ('succeeded','blocked','waived')",(self.config.project_id,self.config.revision)).fetchone()
            if progress["state"]=="blocked":c.execute("UPDATE orchestrator_loops SET state='turn_ready',version=version+1 WHERE project_id=? AND state='waiting'",(self.config.project_id,))
            elif pending is None:c.execute("UPDATE orchestrator_loops SET state='turn_ready',version=version+1 WHERE project_id=? AND state='waiting'",(self.config.project_id,))
            return {"assignment_id":assignment_id,"state":"reported"}
        return self._action(key,{"kind":"progress","agent":agent_id,"assignment":assignment_id,"progress":dict(progress)},effect)

    def waive_assignment(self,key:str,assignment_id:str,actor_role:str,actor_id:str,reason:str,receipt:str)->dict[str,Any]:
        if actor_role not in {"human","controller"} or not isinstance(actor_id,str) or not _SAFE.fullmatch(actor_id) or not isinstance(reason,str) or not 1<=len(reason.encode())<=1024 or not isinstance(receipt,str) or not _SAFE.fullmatch(receipt):raise OrchestratorLoopError("waiver is unauthorized")
        def effect(c,row):
            changed=c.execute("UPDATE orchestrator_assignments SET state='waived',receipt=? WHERE project_id=? AND revision=? AND assignment_id=? AND state='blocked'",(_canon({"actor_role":actor_role,"actor_id":actor_id,"reason":reason,"receipt":receipt}),self.config.project_id,self.config.revision,assignment_id)).rowcount
            if changed!=1:raise OrchestratorConflict("assignment cannot be waived")
            version=row["version"]+1
            if c.execute("UPDATE orchestrator_loops SET version=? WHERE project_id=? AND version=?",(version,self.config.project_id,row["version"])).rowcount!=1:raise OrchestratorConflict("waiver is stale")
            return {"assignment_id":assignment_id,"state":"waived","version":version}
        return self._action(key,{"kind":"waive","assignment":assignment_id,"actor":actor_role,"actor_id":actor_id,"reason":reason,"receipt":receipt},effect)

    def resolve_expansion(self,key:str,expected_version:int,approve:bool,actor_role:str,actor_id:str,rationale:str,receipt:str,allocation_receipt:str|None=None,displaced_project_ids:list[str]|None=None)->dict[str,Any]:
        displaced=[] if displaced_project_ids is None else displaced_project_ids
        if actor_role not in {"human","codex"} or not isinstance(actor_id,str) or not _SAFE.fullmatch(actor_id) or type(approve)is not bool or not isinstance(rationale,str) or not 1<=len(rationale.encode())<=1024 or not isinstance(receipt,str) or not _SAFE.fullmatch(receipt) or not isinstance(displaced,list) or len(displaced)>64 or any(not isinstance(item,str) or not _SAFE.fullmatch(item) for item in displaced) or len(set(displaced))!=len(displaced) or (approve and (not isinstance(allocation_receipt,str) or not _SAFE.fullmatch(allocation_receipt))) or (displaced and actor_role!="human"):raise OrchestratorLoopError("resource resolution is invalid")
        def effect(c,row):
            if row is None or row["version"]!=expected_version or not row["pending_request"]:raise OrchestratorConflict("resource request is stale")
            pending=json.loads(row["pending_request"]); target=pending["target"]
            if approve and actor_role!="codex" and actor_role!="human":raise OrchestratorLoopError("resource resolution is invalid")
            resources=target if approve else json.loads(row["resources"]);version=expected_version+1
            changed=c.execute("UPDATE orchestrator_loops SET resources=?,state='turn_ready',version=?,pending_request=NULL,decision=? WHERE project_id=? AND version=?",(_canon(resources),version,_canon({"kind":"resource_resolution","approved":approve,"actor_role":actor_role,"actor_id":actor_id,"rationale":rationale,"receipt":receipt,"allocation_receipt":allocation_receipt,"displaced_project_ids":displaced}),self.config.project_id,expected_version)).rowcount
            if changed!=1:raise OrchestratorConflict("resource request is stale")
            return {"state":"turn_ready","version":version,"resources":resources,"approved":approve}
        return self._action(key,{"kind":"resolve_expansion","version":expected_version,"approve":approve,"actor_role":actor_role,"actor":actor_id,"rationale":rationale,"receipt":receipt,"allocation_receipt":allocation_receipt,"displaced":displaced},effect)

    def request_pause(self,key:str,actor_id:str,reason:str,deadline:str)->dict[str,Any]:
        try: parsed=datetime.fromisoformat(deadline.replace("Z","+00:00")) if isinstance(deadline,str) else None
        except ValueError: parsed=None
        if not isinstance(actor_id,str) or not _SAFE.fullmatch(actor_id) or not isinstance(reason,str) or not 1<=len(reason.encode())<=1024 or parsed is None or parsed.tzinfo is None or parsed<=self.clock():raise OrchestratorLoopError("pause request is invalid")
        def effect(c,row):
            if row is None or row["state"] in {"completed","paused"}:raise OrchestratorConflict("loop cannot pause")
            version=row["version"]+1
            if c.execute("UPDATE orchestrator_loops SET state='pause_requested',version=?,decision=? WHERE project_id=? AND version=?",(version,_canon({"kind":"pause","actor_id":actor_id,"reason":reason,"deadline":deadline}),self.config.project_id,row["version"])).rowcount!=1:raise OrchestratorConflict("pause is stale")
            return {"state":"pause_requested","version":version}
        return self._action(key,{"kind":"pause_requested","actor":actor_id,"reason":reason,"deadline":deadline},effect)
    def drain_pause(self,key:str,checkpoint_receipt:str)->dict[str,Any]:
        if not isinstance(checkpoint_receipt,str) or not _SAFE.fullmatch(checkpoint_receipt):raise OrchestratorLoopError("checkpoint receipt is invalid")
        def effect(c,row):
            if row is None or row["state"] not in {"pause_requested","draining"}:raise OrchestratorConflict("pause is not requested")
            active=c.execute("SELECT 1 FROM orchestrator_assignments WHERE project_id=? AND revision=? AND state IN ('assigned','running')",(self.config.project_id,self.config.revision)).fetchone()
            if active:raise OrchestratorConflict("assignments have not reached safe boundary")
            version=row["version"]+1
            if c.execute("UPDATE orchestrator_loops SET state='paused',version=?,decision=? WHERE project_id=? AND version=?",(version,_canon({"kind":"pause_checkpoint","receipt":checkpoint_receipt}),self.config.project_id,row["version"])).rowcount!=1:raise OrchestratorConflict("pause is stale")
            return {"state":"paused","version":version}
        return self._action(key,{"kind":"pause_drain","receipt":checkpoint_receipt},effect)
    def resume(self,key:str,expected_version:int)->dict[str,Any]:
        def effect(c,row):
            if row is None or row["state"]!='paused' or row["version"]!=expected_version:raise OrchestratorConflict("resume is stale")
            c.execute("UPDATE orchestrator_assignments SET state='assigned' WHERE project_id=? AND revision=? AND state='paused'",(self.config.project_id,self.config.revision))
            if c.execute("UPDATE orchestrator_loops SET state='turn_ready',version=version+1 WHERE project_id=? AND version=?",(self.config.project_id,expected_version)).rowcount!=1:raise OrchestratorConflict("resume is stale")
            return {"state":"turn_ready","version":expected_version+1}
        return self._action(key,{"kind":"resume","version":expected_version},effect)
    def snapshot(self)->dict[str,Any]:
        with self._db() as c:
            row=c.execute("SELECT * FROM orchestrator_loops WHERE project_id=?",(self.config.project_id,)).fetchone()
            if row is None:raise OrchestratorLoopError("loop not started")
            self._validate_persisted_dependency_graph(c)
            assignments=[]
            for item in c.execute("SELECT assignment_id,agent_id,binding_id,task_ref,objective,state,receipt,depends_on,resource_request,verification_input_tree_sha256,attempt_id,immutable_revision,submission_fence FROM orchestrator_assignments WHERE project_id=? AND revision=? ORDER BY assignment_id",(self.config.project_id,self.config.revision)):
                value={**dict(item),"receipt":json.loads(item["receipt"]) if item["receipt"] else None}
                if item["depends_on"] is not None: value["depends_on"]=json.loads(item["depends_on"])
                if item["resource_request"] is not None: value["resource_request"]=json.loads(item["resource_request"])
                if item["verification_input_tree_sha256"] is not None: value["verification_input_tree_sha256"]=item["verification_input_tree_sha256"]
                if item["attempt_id"] is not None: value["attempt_id"]=item["attempt_id"]; value["immutable_revision"]=item["immutable_revision"]
                if item["submission_fence"] is not None: value["submission_fence"]=json.loads(item["submission_fence"])
                attempt, immutable, fence = item["attempt_id"], item["immutable_revision"], value.get("submission_fence")
                if (attempt is None) != (immutable is None) or (immutable is None and fence is not None):
                    raise OrchestratorLoopError("persisted assignment source identity is invalid")
                if immutable is not None:
                    try: normalized = validate_submission_fence(fence)
                    except RuntimeClientError as error: raise OrchestratorLoopError("persisted assignment submission fence is invalid") from error
                    if normalized["assignment_id"] != item["assignment_id"] or normalized["immutable_revision"] != immutable or normalized["project_revision"] != self.config.revision:
                        raise OrchestratorLoopError("persisted assignment submission fence does not match assignment")
                events=list(c.execute("SELECT event FROM orchestrator_assignment_events WHERE project_id=? AND revision=? AND assignment_id=? ORDER BY event_id LIMIT ?",(self.config.project_id,self.config.revision,item["assignment_id"],_MAX_EVENTS+1)))
                value["events"]=[json.loads(event["event"]) for event in events[:_MAX_EVENTS]];value["events_truncated"]=len(events)>_MAX_EVENTS
                assignments.append(value)
        snapshot={"project_id":row["project_id"],"revision":row["revision"],"state":row["state"],"version":row["version"],"resources":json.loads(row["resources"]),"pending_request":json.loads(row["pending_request"]) if row["pending_request"] else None,"last_decision":json.loads(row["decision"]) if row["decision"] else None,"config_fingerprint":row["config_fingerprint"],"assignments":assignments}
        if self.config.project_descriptor:
            snapshot["project_descriptor"] = json.loads(_canon(self.config.project_descriptor))
        return snapshot
