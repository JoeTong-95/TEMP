"""Explicit, least-privilege forge provisioning for an accepted project only."""
from __future__ import annotations
import argparse, hashlib, http.client, json, os, re, sqlite3, ssl, sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import quote, urlsplit
from .hardware_registry import HardwareRegistry
from .project_control import ProjectControl
from .provider_registry import ProviderRegistry
from shared.contracts.forge import DEFAULT_FORGE_PROVIDER, normalize_forge_provider

class RepositoryProvisioningError(ValueError): pass
class RepositoryAuthenticationError(RepositoryProvisioningError): pass
class RemoteOutcomeUnknown(RepositoryProvisioningError):
 def __init__(self,message:str,receipt_id:str|None=None):
  super().__init__(message);self.receipt_id=receipt_id
class AuthorityDrift(RepositoryProvisioningError): pass
_ID=re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_IMMUTABLE_REF=re.compile(r"[0-9a-f]{40,64}\Z")
def _json(v:Any)->str:return json.dumps(v,sort_keys=True,separators=(",",":"),allow_nan=False)
def _github_repo_parts(value:Any)->tuple[str,str]:
 p=urlsplit(value if isinstance(value,str) else "")
 try: port=p.port
 except ValueError as error: raise RepositoryProvisioningError("GitHub repository URL is invalid") from error
 if p.scheme not in {"https","ssh"} or p.hostname is None or p.hostname.lower()!="github.com" or (p.scheme=="https" and port not in {None,443}) or (p.scheme=="ssh" and port not in {None,22}) or p.username or p.password or p.query or p.fragment:
  raise RepositoryProvisioningError("GitHub repository URL must target github.com")
 parts=p.path.strip("/").split("/")
 if len(parts)!=2 or any(not part for part in parts):raise RepositoryProvisioningError("GitHub repository URL must include owner and repository")
 repository=parts[1][:-4] if parts[1].lower().endswith(".git") else parts[1]
 if _ID.fullmatch(parts[0]) is None or _ID.fullmatch(repository) is None:raise RepositoryProvisioningError("GitHub repository owner or repository is invalid")
 return parts[0],repository
def _github_repo_identity(value:Any)->tuple[str,str]:
 owner,repository=_github_repo_parts(value)
 return owner.casefold(),repository.casefold()
def _github_canonical_url(value:Any)->str:
 owner,repository=_github_repo_parts(value)
 return f"https://github.com/{owner.casefold()}/{repository.casefold()}.git"
def _gitea_repo_identity(value:Any)->tuple[str,int,str,str]:
 p=urlsplit(value if isinstance(value,str) else "")
 try: port=p.port
 except ValueError as error: raise RepositoryProvisioningError("Gitea repository URL is invalid") from error
 if p.scheme != "https" or p.hostname is None or p.username or p.password or p.query or p.fragment:
  raise RepositoryProvisioningError("Gitea repository URL must target the approved HTTPS origin")
 parts=p.path.strip("/").split("/")
 if len(parts)!=2 or any(not part for part in parts):raise RepositoryProvisioningError("Gitea repository URL must include owner and repository")
 repository=parts[1][:-4] if parts[1].lower().endswith(".git") else parts[1]
 if _ID.fullmatch(parts[0]) is None or _ID.fullmatch(repository) is None:raise RepositoryProvisioningError("Gitea repository owner or repository is invalid")
 return p.hostname.casefold(),port or 443,parts[0],repository
def _plan_identity_matches(existing:Mapping[str,Any], expected:Mapping[str,Any])->bool:
 common=("project_id","revision","intent_id","forge_provider","storage_provider_id","storage_provider_generation","owner","owner_kind","repository","private","canonical_git_url")
 github=expected.get("forge_provider")=="github"
 for key in common:
  left=existing.get(key); right=expected.get(key)
  if github and key in {"owner","repository"}:
   if not isinstance(left,str) or not isinstance(right,str) or left.casefold()!=right.casefold(): return False
  elif github and key=="canonical_git_url":
   try:
    if _github_repo_identity(left)!=_github_repo_identity(right): return False
   except RepositoryProvisioningError: return False
  elif left!=right: return False
 return True
def _id(v:Any,n:str)->str:
 if not isinstance(v,str) or _ID.fullmatch(v) is None:raise RepositoryProvisioningError(n+" is invalid")
 return v
def _origin(v:Any)->str:
 p=urlsplit(v if isinstance(v,str) else "")
 if p.scheme!="https" or not p.hostname or p.username or p.password or p.path not in {"","/"} or p.query or p.fragment:raise RepositoryProvisioningError("Gitea origin must be one private HTTPS origin")
 return p.geturl().rstrip("/")
def _file(v:Any,n:str,secret:bool)->Path:
 p=Path(v) if isinstance(v,str) else None
 if p is None or not p.is_absolute() or p.is_symlink() or any(x.is_symlink() for x in p.parents) or not p.is_file():raise RepositoryProvisioningError(n+" is unsafe")
 if secret and os.name=="posix" and p.stat().st_mode&0o077:raise RepositoryProvisioningError(n+" must not be group or world readable")
 return p.resolve(strict=True)

class ForgeRepositoryClient:
 """Provider-neutral repository lifecycle seam used by provisioning.

 Implementations own identity endpoints, repository lookup/create payloads,
 and provider response shapes.  The provisioner owns project authority,
 idempotency, and reconciliation receipts.
 """
 provider: str
 def verify_identity(self, request: "RepositoryProvisioningRequest", identity: "BootstrapIdentity", token: str) -> None: raise NotImplementedError
 def lookup(self, request: "RepositoryProvisioningRequest", token: str) -> Mapping[str, Any] | None: raise NotImplementedError
 def create_or_lookup(self, request: "RepositoryProvisioningRequest", token: str) -> Mapping[str, Any]: raise NotImplementedError
 def matches(self, request: "RepositoryProvisioningRequest", repository: Mapping[str, Any]) -> bool: raise NotImplementedError

class HttpGitHubRepositoryClient(ForgeRepositoryClient):
 """GitHub repository lifecycle adapter with no embedded credentials."""
 provider = "github"
 def __init__(self, origin: str = "https://api.github.com", *, timeout_seconds: float = 10.0) -> None:
  p = urlsplit(origin)
  try: port = p.port
  except ValueError as error: raise RepositoryProvisioningError("GitHub origin is not an approved API host") from error
  if p.scheme != "https" or not p.hostname or p.hostname.casefold() != "api.github.com" or port not in {None, 443} or p.username or p.password or p.path not in {"", "/"} or p.query or p.fragment: raise RepositoryProvisioningError("GitHub origin is not an approved API host")
  if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float)) or not 0 < timeout_seconds <= 60: raise RepositoryProvisioningError("timeout is invalid")
  self.origin, self.timeout = origin.rstrip("/"), float(timeout_seconds)
 def _request(self, method: str, path: str, token: str, body: Mapping[str, Any] | None = None) -> tuple[int, Any]:
  if not token or any(c.isspace() for c in token): raise RepositoryProvisioningError("GitHub token is invalid")
  raw = None if body is None else _json(body).encode()
  p = urlsplit(self.origin); c = http.client.HTTPSConnection(p.hostname, p.port or 443, timeout=self.timeout)
  try:
   headers = {"Authorization": "Bearer " + token, "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "agent-stack-project-provisioner/1"}
   if raw is not None: headers.update({"Content-Type": "application/json", "Content-Length": str(len(raw))})
   c.request(method, path, raw, headers); response = c.getresponse()
   # Classify authorization failures from the status line before touching the
   # body. Providers may return oversized or malformed error bodies, and those
   # bodies must never turn a known auth failure into an ambiguous outcome.
   if response.status in {401, 403}: raise RepositoryAuthenticationError("GitHub authentication failed")
   data = response.read(131073)
   if len(data) > 131072: raise RepositoryProvisioningError("GitHub response exceeds bound")
   try: value = json.loads(data.decode()) if data else None
   except (UnicodeDecodeError, json.JSONDecodeError) as error: raise RemoteOutcomeUnknown("GitHub returned invalid JSON") from error
   return response.status, value
  except (OSError, UnicodeDecodeError) as error: raise RemoteOutcomeUnknown("GitHub request outcome is unknown") from error
  finally: c.close()
 def verify_identity(self, request, identity, token):
  status, value = self._request("GET", "/user", token)
  if status in {401, 403}: raise RepositoryAuthenticationError("GitHub authentication failed")
  login = value.get("login") if isinstance(value, Mapping) else None
  if status != 200 or not isinstance(login,str) or login.casefold() != identity.expected_username.casefold(): raise RepositoryProvisioningError("bootstrap identity does not match its reviewed contract")
  if request.owner_kind == "user" and request.owner.casefold() != identity.expected_username.casefold(): raise RepositoryProvisioningError("user repository owner must match authenticated bootstrap identity")
  if request.owner_kind == "organization":
   status, value = self._request("GET", "/orgs/" + quote(request.owner, safe=""), token)
   if status in {401, 403}: raise RepositoryAuthenticationError("GitHub authentication failed")
   org_login = value.get("login") if isinstance(value, Mapping) else None
   if status != 200 or not isinstance(org_login,str) or org_login.casefold() != request.owner.casefold(): raise RepositoryProvisioningError("requested organization is not available to bootstrap identity")
 def lookup(self, request, token):
  status, value = self._request("GET", "/repos/{}/{}".format(quote(request.owner, safe=""), quote(request.repository, safe="")), token)
  if status == 404: return None
  if status in {401, 403}: raise RepositoryAuthenticationError("GitHub authentication failed")
  if status == 200 and isinstance(value, Mapping): return value
  raise RepositoryProvisioningError("GitHub repository lookup failed")
 def create_or_lookup(self, request, token):
  found = self.lookup(request, token)
  if found is not None: return found
  path = "/user/repos" if request.owner_kind == "user" else "/orgs/" + quote(request.owner, safe="") + "/repos"
  try: status, value = self._request("POST", path, token, {"name": request.repository, "private": True, "auto_init": True})
  except RepositoryAuthenticationError:
   raise
  except (RepositoryProvisioningError, RemoteOutcomeUnknown) as error:
   try: found = self.lookup(request, token)
   except RepositoryAuthenticationError:
    raise
   except RepositoryProvisioningError as lookup_error: raise RemoteOutcomeUnknown("GitHub POST outcome could not be reconciled") from lookup_error
   if found is not None: return found
   raise RemoteOutcomeUnknown("GitHub POST outcome is unknown") from error
  if status in {200, 201} and isinstance(value, Mapping): return value
  if status in {401, 403}: raise RepositoryAuthenticationError("GitHub authentication failed")
  if status in {408, 425, 429} or status >= 500:
   try: found = self.lookup(request, token)
   except RepositoryAuthenticationError:
    raise
   except RepositoryProvisioningError as lookup_error: raise RemoteOutcomeUnknown("GitHub POST outcome could not be reconciled") from lookup_error
   if found is not None: return found
   raise RemoteOutcomeUnknown("GitHub POST outcome is unknown")
  if status in {409, 422}:
   found = self.lookup(request, token)
   if found is not None: return found
  raise RepositoryProvisioningError("GitHub repository creation failed")
 def matches(self, request, value):
  if value.get("private") is not True or not isinstance(value.get("owner"), Mapping): return False
  owner_login=value["owner"].get("login"); name=value.get("name")
  if not isinstance(owner_login,str) or not isinstance(name,str) or owner_login.casefold() != request.owner.casefold() or name.casefold() != request.repository.casefold(): return False
  try: return _github_repo_identity(value.get("clone_url") or value.get("html_url")) == (request.owner.casefold(), request.repository.casefold())
  except RepositoryProvisioningError: return False

@dataclass(frozen=True)
class BootstrapIdentity:
 expected_username:str;token_file:Path;allowed_owner:str;owner_kind:str;credential_selector:str|None=None
 def __post_init__(self):
  for n in ("expected_username","allowed_owner"):object.__setattr__(self,n,_id(getattr(self,n),"bootstrap "+n))
  if self.owner_kind not in {"user","organization"}:raise RepositoryProvisioningError("bootstrap owner_kind is invalid")
  if self.credential_selector is not None:object.__setattr__(self,"credential_selector",_id(self.credential_selector,"bootstrap credential_selector"))
  object.__setattr__(self,"token_file",_file(str(self.token_file),"bootstrap token file",True))
@dataclass(frozen=True)
class RepositoryProvisioningRequest:
 project_id:str;revision:int;intent_id:str;storage_provider_id:str|None=None;gitea_origin:str|None=None;owner:str|None=None;owner_kind:str|None=None;repository:str|None=None;forge_provider:str = DEFAULT_FORGE_PROVIDER;forge_binding:Mapping[str,Any]|None=None;repository_url:str|None=None;baseline_ref:str|None=None
 def __post_init__(self):
  for n in ("project_id","intent_id"):object.__setattr__(self,n,_id(getattr(self,n),n))
  if self.forge_binding is not None:
   try:
    from shared.contracts.forge import normalize_project_forge_binding
    binding = normalize_project_forge_binding(dict(self.forge_binding)); object.__setattr__(self,"forge_binding",binding)
    if binding["provider"] == "github":
     owner_name,repository_name = _github_repo_parts(binding["repository_url"])
     object.__setattr__(self,"repository_url",_github_canonical_url(binding["repository_url"]))
    else:
     parsed = urlsplit(binding["repository_url"]); path = parsed.path.strip("/").removesuffix(".git").split("/")
     if len(path) != 2: raise ValueError("repository_url must include owner and repository")
     owner_name,repository_name = path
    object.__setattr__(self,"forge_provider",binding["provider"])
    if self.owner is not None and self.owner.casefold()!=owner_name.casefold(): raise ValueError("owner does not match forge binding")
    if self.repository is not None and self.repository.casefold()!=repository_name.casefold(): raise ValueError("repository does not match forge binding")
    if binding["provider"] == "github":
     owner_name=owner_name.casefold(); repository_name=repository_name.casefold()
    object.__setattr__(self,"owner",owner_name)
    object.__setattr__(self,"repository",repository_name)
    if self.owner_kind is None: object.__setattr__(self,"owner_kind","organization")
    if binding["provider"] == "gitea" and self.gitea_origin is None:
     parsed_origin = urlsplit(binding["repository_url"])
     if parsed_origin.scheme != "https" or not parsed_origin.hostname:
      raise ValueError("Gitea forge binding must use an HTTPS repository URL")
     object.__setattr__(self,"gitea_origin",_origin(f"https://{parsed_origin.netloc}"))
   except (TypeError, ValueError) as error: raise RepositoryProvisioningError("forge binding is invalid") from error
  for n in ("owner","repository"):
   object.__setattr__(self,n,_id(getattr(self,n),n))
  if self.storage_provider_id is not None: object.__setattr__(self,"storage_provider_id",_id(self.storage_provider_id,"storage_provider_id"))
  if type(self.revision)is not int or self.revision<1:raise RepositoryProvisioningError("revision is invalid")
  if self.baseline_ref is not None and (not isinstance(self.baseline_ref,str) or _IMMUTABLE_REF.fullmatch(self.baseline_ref) is None):raise RepositoryProvisioningError("baseline_ref must be an immutable commit")
  if self.owner_kind not in {"user","organization"}:raise RepositoryProvisioningError("owner_kind is invalid")
  try: provider = normalize_forge_provider(self.forge_provider)
  except ValueError as error: raise RepositoryProvisioningError(str(error)) from error
  object.__setattr__(self,"forge_provider",provider)
  if self.forge_provider == "github" and self.forge_binding is None and self.repository_url is not None:
   try:
    owner_name,repository_name = _github_repo_parts(self.repository_url)
    if self.owner is not None and self.owner.casefold()!=owner_name.casefold(): raise RepositoryProvisioningError("owner does not match GitHub repository URL")
    if self.repository is not None and self.repository.casefold()!=repository_name.casefold(): raise RepositoryProvisioningError("repository does not match GitHub repository URL")
    object.__setattr__(self,"owner",owner_name.casefold()); object.__setattr__(self,"repository",repository_name.casefold()); object.__setattr__(self,"repository_url",_github_canonical_url(self.repository_url))
   except RepositoryProvisioningError: raise
   except (TypeError, ValueError) as error: raise RepositoryProvisioningError("GitHub repository URL is invalid") from error
  if self.gitea_origin is not None: object.__setattr__(self,"gitea_origin",_origin(self.gitea_origin))
 @property
 def url(self)->str:
  if self.repository_url: return self.repository_url
  if not self.gitea_origin: raise RepositoryProvisioningError("repository URL is required")
  return f"{self.gitea_origin}/{quote(self.owner,safe='')}/{quote(self.repository,safe='')}.git"

class ForgeProjectRepositoryProvisioner:
 def __init__(self,projects:ProjectControl,providers:ProviderRegistry,request:RepositoryProvisioningRequest,*,bootstrap_identity:BootstrapIdentity,ca_file:Path|None=None,timeout_seconds:float=10,repository_client:ForgeRepositoryClient|None=None)->None:
  if not all((isinstance(projects,ProjectControl),isinstance(providers,ProviderRegistry),isinstance(request,RepositoryProvisioningRequest),isinstance(bootstrap_identity,BootstrapIdentity))):raise RepositoryProvisioningError("provisioning dependencies are invalid")
  if request.forge_provider != "gitea" and repository_client is None:raise RepositoryProvisioningError("Gitea provisioning requires explicit forge_provider=gitea; GitHub is the default forge")
  if repository_client is not None and repository_client.provider != request.forge_provider:raise RepositoryProvisioningError("repository client does not match the project forge provider")
  if isinstance(timeout_seconds,bool) or not isinstance(timeout_seconds,(int,float)) or not 0<timeout_seconds<=30:raise RepositoryProvisioningError("timeout is invalid")
  owner_matches = bootstrap_identity.allowed_owner.casefold()==request.owner.casefold() if request.forge_provider=="github" else bootstrap_identity.allowed_owner==request.owner
  if not owner_matches or bootstrap_identity.owner_kind!=request.owner_kind:raise RepositoryProvisioningError("bootstrap identity is not scoped to the requested owner")
  self.projects,self.providers,self.request,self.identity=projects,providers,request,bootstrap_identity;self.client=repository_client;self.ca_file=None if ca_file is None else _file(str(ca_file),"Gitea CA file",False);self.timeout=float(timeout_seconds)
  if self.client is None:
   if self.ca_file is None: raise RepositoryProvisioningError("Gitea CA file is required")
   try:self.context=ssl.create_default_context(cafile=str(self.ca_file))
   except ssl.SSLError as e:raise RepositoryProvisioningError("Gitea CA file is invalid") from e
  else:self.context=None
 def plan(self)->dict[str,Any]:
  d=self.projects.draft(self.request.project_id)
  if d["revision"]!=self.request.revision or d["confirmed_revision"]!=self.request.revision:raise RepositoryProvisioningError("repository provisioning requires the current human-confirmed project revision")
  x=[r for r in self.projects.outbox() if r["intent_id"]==self.request.intent_id and r["project_id"]==self.request.project_id]
  if len(x)!=1 or x[0]["revision"]!=self.request.revision or x[0]["body"].get("payload")!=d["payload"]:raise RepositoryProvisioningError("repository provisioning requires the exact current accepted start intent")
  if self.request.forge_provider == "github":
   accepted_binding = d["payload"].get("forge_binding")
   equivalent_binding = False
   if isinstance(accepted_binding, Mapping) and isinstance(self.request.forge_binding, Mapping):
    try:
     equivalent_binding = accepted_binding.get("provider") == self.request.forge_binding.get("provider") == "github" and accepted_binding.get("identity") == self.request.forge_binding.get("identity") and _github_repo_identity(accepted_binding.get("repository_url")) == _github_repo_identity(self.request.forge_binding.get("repository_url"))
    except RepositoryProvisioningError:
     equivalent_binding = False
   if not equivalent_binding:
    raise RepositoryProvisioningError("accepted project forge_binding does not match the provisioning request")
   if self.identity.credential_selector != accepted_binding.get("identity"):
    raise RepositoryProvisioningError("bootstrap credential selector does not match the accepted forge binding identity")
  elif self.request.forge_provider == "gitea":
   accepted_binding = d["payload"].get("forge_binding")
   if not isinstance(accepted_binding, Mapping) or accepted_binding.get("provider") != "gitea":
    raise RepositoryProvisioningError("accepted project must explicitly declare forge_binding provider=gitea")
   accepted_identity = accepted_binding.get("identity")
   if not isinstance(accepted_identity, str) or not accepted_identity:
    raise RepositoryProvisioningError("accepted project Gitea forge_binding requires a credential identity")
   if self.identity.credential_selector != accepted_identity:
    raise RepositoryProvisioningError("bootstrap credential selector does not match the accepted forge binding identity")
   if not isinstance(self.request.forge_binding, Mapping):
    raise RepositoryProvisioningError("Gitea provisioning requires an explicit forge_binding")
   equivalent_binding = False
   try:
    equivalent_binding = accepted_binding.get("provider") == self.request.forge_binding.get("provider") == "gitea" and accepted_identity == self.request.forge_binding.get("identity") and _gitea_repo_identity(accepted_binding.get("repository_url")) == _gitea_repo_identity(self.request.forge_binding.get("repository_url"))
   except RepositoryProvisioningError:
    equivalent_binding = False
   if not equivalent_binding:
    raise RepositoryProvisioningError("accepted project forge_binding does not match the provisioning request")
   try:
    equivalent_repository = _gitea_repo_identity(accepted_binding.get("repository_url")) == _gitea_repo_identity(self.request.url)
   except RepositoryProvisioningError:
    equivalent_repository = False
   if not equivalent_repository:
    raise RepositoryProvisioningError("accepted project Gitea repository does not match the provisioning request")
  credential_selector = self.identity.credential_selector
  if credential_selector is None and isinstance(self.request.forge_binding, Mapping):
   credential_selector = self.request.forge_binding.get("identity") if self.request.forge_provider == "github" else None
  if self.client is not None and self.request.forge_provider == "github":
   return {"project_id":self.request.project_id,"revision":self.request.revision,"intent_id":self.request.intent_id,"forge_provider":self.request.forge_provider,"storage_provider_id":self.request.storage_provider_id,"storage_provider_generation":None,"owner":self.request.owner,"owner_kind":self.request.owner_kind,"repository":self.request.repository,"private":True,"canonical_git_url":self.request.url,"baseline_ref":self.request.baseline_ref,"credential_selector":credential_selector}
  p=self.providers.get(self.request.storage_provider_id)
  if p is None or p.get("role")!="storage" or "storage.git" not in p.get("manifest",{}).get("capabilities",[]):
   raise RepositoryProvisioningError("storage.git provider is not eligible: declared Storage capability is unavailable")
  readiness=self.providers.readiness(self.request.storage_provider_id, ["storage.git"])
  if readiness.get("eligible") is not True:
   reasons=", ".join(readiness.get("reasons", [])) or "composite readiness is unavailable"
   raise RepositoryProvisioningError("storage.git provider is not eligible: "+reasons)
  try:o=_origin(p["manifest"].get("private_endpoint"))
  except RepositoryProvisioningError as e:raise RepositoryProvisioningError("eligible Storage provider endpoint is not a Gitea HTTPS origin") from e
  if o!=self.request.gitea_origin:raise RepositoryProvisioningError("requested Gitea origin does not match the eligible Storage provider endpoint")
  return {"project_id":self.request.project_id,"revision":self.request.revision,"intent_id":self.request.intent_id,"forge_provider":self.request.forge_provider,"storage_provider_id":p["provider_id"],"storage_provider_generation":p["generation"],"owner":self.request.owner,"owner_kind":self.request.owner_kind,"repository":self.request.repository,"private":True,"canonical_git_url":self.request.url,"baseline_ref":self.request.baseline_ref,"credential_selector":credential_selector}
 def _current(self,plan:Mapping[str,Any])->None:
  if self.plan()!=plan:raise RepositoryProvisioningError("project or Storage authority changed during provisioning")
 def provision(self)->dict[str,Any]:
  plan=self.plan();old=self._binding()
  if old is not None:
   if not _plan_identity_matches(old,plan) or any(old.get(k) not in {None,plan.get(k)} for k in ("baseline_ref","credential_selector")):
    raise RepositoryProvisioningError("a different repository is already bound to this project revision")
   needs_migration=any(old.get(k) is None and plan.get(k) is not None for k in ("baseline_ref","credential_selector"))
   if needs_migration:
    if self.request.baseline_ref is None or self.identity.credential_selector is None:
     raise RepositoryProvisioningError("legacy repository binding requires an explicit baseline and credential selector")
    self._migrate_legacy_binding(plan)
    return {**plan,"state":"already_provisioned"}
   if old!=plan:
    self._migrate_legacy_binding(plan)
    return {**plan,"state":"already_provisioned"}
   return {**old,"state":"already_provisioned"}
  try:
   self._identity();self._current(plan);repo=self._create_or_lookup()
  except RemoteOutcomeUnknown as e:
   receipt_id=e.receipt_id or self._receipt(plan,"remote_outcome_unknown")
   raise RemoteOutcomeUnknown("remote outcome is unknown; reconciliation receipt recorded: "+receipt_id,receipt_id) from e
  if not self._matches(repo):raise RepositoryProvisioningError("remote repository mismatch; reconciliation receipt recorded: "+self._receipt(plan,"remote_repository_mismatch"))
  try:self._current(plan)
  except RepositoryProvisioningError as e:raise RepositoryProvisioningError("remote repository may be orphaned; reconciliation receipt recorded: "+self._receipt(plan,"post_write_authority_drift")+" (detail: "+str(e)+")") from e
  try:self._record(plan)
  except AuthorityDrift as e:raise RepositoryProvisioningError("remote repository may be orphaned; reconciliation receipt recorded: "+self._receipt(plan,"record_authority_drift")+" (detail: "+str(e)+")") from e
  return {**plan,"state":"provisioned"}
 def _token(self)->str:
  try:t=self.identity.token_file.read_text(encoding="utf-8").strip()
  except (OSError,UnicodeDecodeError) as e:raise RepositoryProvisioningError("bootstrap token is unavailable") from e
  if not t or len(t)>4096 or any(c.isspace() for c in t):raise RepositoryProvisioningError("bootstrap token is invalid")
  return t
 def _request(self,m:str,path:str,b:Mapping[str,Any]|None=None)->tuple[int,Any]:
  p=urlsplit(self.request.gitea_origin);raw=None if b is None else _json(b).encode();c=http.client.HTTPSConnection(p.hostname,p.port or 443,timeout=self.timeout,context=self.context)
  try:
   h={"Authorization":"token "+self._token(),"Accept":"application/json"}
   if raw is not None:h.update({"Content-Type":"application/json","Content-Length":str(len(raw))})
   c.request(m,path,raw,h);r=c.getresponse();data=r.read(131073)
   if len(data)>131072:raise RepositoryProvisioningError("Gitea response exceeds bound")
   return r.status,(json.loads(data.decode()) if data else None)
  except (OSError,UnicodeDecodeError,json.JSONDecodeError) as e:raise RepositoryProvisioningError("Gitea request failed") from e
  finally:c.close()
 def _identity(self)->None:
  if self.client is not None:
   self.client.verify_identity(self.request,self.identity,self._token()); return
  s,v=self._request("GET","/api/v1/user")
  if s!=200 or not isinstance(v,Mapping) or v.get("login")!=self.identity.expected_username:raise RepositoryProvisioningError("bootstrap identity does not match its reviewed contract")
  if self.request.owner_kind=="user":
   if self.request.owner!=self.identity.expected_username:raise RepositoryProvisioningError("user repository owner must match authenticated bootstrap identity")
  else:
   s,v=self._request("GET","/api/v1/orgs/"+quote(self.request.owner,safe=""))
   if s!=200 or not isinstance(v,Mapping) or v.get("username")!=self.request.owner:raise RepositoryProvisioningError("requested organization is not available to bootstrap identity")
 def _lookup(self)->Mapping[str,Any]|None:
  if self.client is not None: return self.client.lookup(self.request,self._token())
  s,v=self._request("GET","/api/v1/repos/{}/{}".format(quote(self.request.owner,safe=""),quote(self.request.repository,safe="")))
  if s==404:return None
  if s==200 and isinstance(v,Mapping):return v
  raise RepositoryProvisioningError("Gitea repository lookup failed")
 def _create_or_lookup(self)->Mapping[str,Any]:
  if self.client is not None: return self.client.create_or_lookup(self.request,self._token())
  found=self._lookup()
  if found is not None:return found
  path="/api/v1/user/repos" if self.request.owner_kind=="user" else "/api/v1/orgs/"+quote(self.request.owner,safe="")+"/repos"
  try:s,v=self._request("POST",path,{"name":self.request.repository,"private":True,"auto_init":True,"default_branch":"main"})
  except RepositoryProvisioningError:
   try:found=self._lookup()
   except RepositoryProvisioningError as e:raise RemoteOutcomeUnknown("POST outcome could not be reconciled") from e
   if found is not None:return found
   raise RemoteOutcomeUnknown("POST outcome is unknown")
  if s in {200,201} and isinstance(v,Mapping):return v
  if s==409:
   found=self._lookup()
   if found is not None:return found
  raise RepositoryProvisioningError("Gitea repository creation failed")
 def _matches(self,v:Mapping[str,Any])->bool:
  if self.client is not None: return self.client.matches(self.request,v)
  return v.get("name")==self.request.repository and isinstance(v.get("owner"),Mapping) and v["owner"].get("login")==self.request.owner and v.get("private") is True and v.get("clone_url")==self.request.url
 def _db(self):return sqlite3.connect(self.projects.path)
 @staticmethod
 def _tables(c):
  c.execute("CREATE TABLE IF NOT EXISTS project_repository_bindings(project_id TEXT NOT NULL,revision INTEGER NOT NULL,intent_id TEXT NOT NULL,plan TEXT NOT NULL,baseline_ref TEXT,credential_selector TEXT,created_at TEXT NOT NULL,PRIMARY KEY(project_id,revision),UNIQUE(intent_id))")
  columns={row[1] for row in c.execute("PRAGMA table_info(project_repository_bindings)").fetchall()}
  if "baseline_ref" not in columns:c.execute("ALTER TABLE project_repository_bindings ADD COLUMN baseline_ref TEXT")
  if "credential_selector" not in columns:c.execute("ALTER TABLE project_repository_bindings ADD COLUMN credential_selector TEXT")
  c.execute("CREATE TABLE IF NOT EXISTS project_repository_reconciliation_receipts(receipt_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,revision INTEGER NOT NULL,intent_id TEXT NOT NULL,reason TEXT NOT NULL,plan TEXT NOT NULL,created_at TEXT NOT NULL)")
 def _binding(self):
  c=self._db()
  try:self._tables(c);r=c.execute("SELECT plan FROM project_repository_bindings WHERE project_id=? AND revision=?",(self.request.project_id,self.request.revision)).fetchone();return json.loads(r[0]) if r else None
  finally:c.close()
 def _migrate_legacy_binding(self,plan):
  c=self._db()
  try:
   self._tables(c);c.execute("BEGIN IMMEDIATE")
   row=c.execute("SELECT plan,baseline_ref,credential_selector FROM project_repository_bindings WHERE project_id=? AND revision=? AND intent_id=?",(self.request.project_id,self.request.revision,self.request.intent_id)).fetchone()
   if row is None:raise RepositoryProvisioningError("legacy repository binding disappeared during migration")
   current=json.loads(row[0])
   if current==plan and row[1]==plan.get("baseline_ref") and row[2]==plan.get("credential_selector"):
    c.commit();return
   if not _plan_identity_matches(current,plan) or any(current.get(k) not in {None,plan.get(k)} for k in ("baseline_ref","credential_selector")) or any(value not in {None,plan.get(key)} for value,key in ((row[1],"baseline_ref"),(row[2],"credential_selector"))):
    raise RepositoryProvisioningError("a different repository is already bound to this project revision")
   self._project_current_locked(c)
   changed=c.execute("UPDATE project_repository_bindings SET plan=?,baseline_ref=?,credential_selector=? WHERE project_id=? AND revision=? AND intent_id=? AND (baseline_ref IS NULL OR baseline_ref=?) AND (credential_selector IS NULL OR credential_selector=?)",(_json(plan),plan.get("baseline_ref"),plan.get("credential_selector"),self.request.project_id,self.request.revision,self.request.intent_id,plan.get("baseline_ref"),plan.get("credential_selector"))).rowcount
   if changed!=1:raise RepositoryProvisioningError("legacy repository binding changed during migration")
   c.commit()
  finally:c.close()
 def _record(self,plan):
  c=self._db()
  try:
   self._tables(c);c.execute("BEGIN IMMEDIATE");r=c.execute("SELECT plan FROM project_repository_bindings WHERE project_id=? AND revision=?",(self.request.project_id,self.request.revision)).fetchone()
   if r is not None and json.loads(r[0])!=plan:raise RepositoryProvisioningError("a different repository is already bound to this project revision")
   self._project_current_locked(c)
   # Provider state is in its own durable registry.  It cannot share this
   # SQLite transaction, so observe the exact generation immediately before
   # committing and convert any detected drift into an orphan receipt.
   provider=self.providers.get(self.request.storage_provider_id) if self.request.storage_provider_id else None
   if self.client is None and (provider is None or provider.get("generation")!=plan["storage_provider_generation"] or not self.providers.is_eligible(self.request.storage_provider_id)):
    raise AuthorityDrift("Storage provider changed before repository binding")
   if self.request.forge_provider == "gitea":
    if provider is None or provider.get("generation")!=plan["storage_provider_generation"]:
     raise AuthorityDrift("Storage provider generation changed before repository binding")
    readiness=self.providers.readiness(self.request.storage_provider_id, ["storage.git"])
    if readiness.get("eligible") is not True:
     reasons=", ".join(readiness.get("reasons", [])) or "composite readiness is unavailable"
     raise AuthorityDrift("Storage provider readiness changed before repository binding: "+reasons)
   if r is None:c.execute("INSERT INTO project_repository_bindings(project_id,revision,intent_id,plan,baseline_ref,credential_selector,created_at) VALUES(?,?,?,?,?,?,?)",(self.request.project_id,self.request.revision,self.request.intent_id,_json(plan),plan.get("baseline_ref"),plan.get("credential_selector"),self._time()))
   c.commit()
  finally:c.close()
 def _project_current_locked(self,c):
  draft=c.execute("SELECT revision,payload,confirmed_revision FROM project_drafts WHERE project_id=?",(self.request.project_id,)).fetchone()
  if draft is None or draft[0]!=self.request.revision or draft[2]!=self.request.revision:raise AuthorityDrift("project revision changed before repository binding")
  intent=c.execute("SELECT revision,body FROM project_outbox WHERE intent_id=? AND project_id=?",(self.request.intent_id,self.request.project_id)).fetchone()
  if intent is None or intent[0]!=self.request.revision:
   raise AuthorityDrift("project start intent changed before repository binding")
  try:body=json.loads(intent[1]);payload=json.loads(draft[1])
  except (TypeError,json.JSONDecodeError) as e:raise AuthorityDrift("project state is invalid before repository binding") from e
  if not isinstance(body,Mapping) or body.get("payload")!=payload:raise AuthorityDrift("project intent changed before repository binding")
 def _receipt(self,plan,reason):
  x=hashlib.sha256(_json({"plan":plan,"reason":reason}).encode()).hexdigest();c=self._db()
  try:self._tables(c);c.execute("INSERT OR IGNORE INTO project_repository_reconciliation_receipts VALUES(?,?,?,?,?,?,?)",(x,self.request.project_id,self.request.revision,self.request.intent_id,reason,_json(plan),self._time()));c.commit()
  finally:c.close()
  return x
 @staticmethod
 def _time():return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

class GiteaProjectRepositoryProvisioner(ForgeProjectRepositoryProvisioner):
 """Compatibility name for the historical Gitea provisioner."""

class GitHubProjectRepositoryProvisioner(ForgeProjectRepositoryProvisioner):
 """GitHub-backed provisioner using the same authority/idempotency workflow."""
 def __init__(self, projects:ProjectControl, providers:ProviderRegistry, request:RepositoryProvisioningRequest, *, bootstrap_identity:BootstrapIdentity, origin:str="https://api.github.com", timeout_seconds:float=10)->None:
  if request.forge_provider != "github": raise RepositoryProvisioningError("GitHub provisioning requires forge_provider=github")
  super().__init__(projects,providers,request,bootstrap_identity=bootstrap_identity,ca_file=None,timeout_seconds=timeout_seconds,repository_client=HttpGitHubRepositoryClient(origin,timeout_seconds=timeout_seconds))

def load_request(path:str|Path):
 cfg=_file(str(path),"repository provisioning configuration",True)
 try:r=json.loads(cfg.read_text(encoding="utf-8"))
 except (OSError,UnicodeDecodeError,json.JSONDecodeError) as e:raise RepositoryProvisioningError("repository provisioning configuration is invalid") from e
 common={"project_id","revision","intent_id","projects_database","providers_database","hardware_database","bootstrap_identity"}
 legacy={"storage_provider_id","gitea_origin","owner","owner_kind","repository","gitea_ca_file"}
 modern={"forge_binding","storage_provider_id","gitea_ca_file","github_origin","baseline_ref"}
 identity_fields={"expected_username","token_file","allowed_owner","owner_kind","credential_selector"}
 if not isinstance(r,Mapping) or not common<=set(r) or set(r)-(common|legacy|modern|{"timeout_seconds","forge_provider"}) or not isinstance(r["bootstrap_identity"],Mapping) or not set(r["bootstrap_identity"])<=identity_fields or not {"expected_username","token_file","allowed_owner","owner_kind"}<=set(r["bootstrap_identity"]):raise RepositoryProvisioningError("repository provisioning configuration shape is invalid")
 configured_provider = r.get("forge_provider")
 if configured_provider is None and isinstance(r.get("forge_binding"), Mapping):
  configured_provider = r["forge_binding"].get("provider")
 try: forge_provider=normalize_forge_provider(configured_provider)
 except ValueError as error: raise RepositoryProvisioningError(str(error)) from error
 if isinstance(r.get("forge_binding"), Mapping) and r["forge_binding"].get("provider") != forge_provider:
  raise RepositoryProvisioningError("forge_provider does not match forge_binding provider")
 if forge_provider == "gitea" and "forge_binding" not in r and not legacy<=set(r): raise RepositoryProvisioningError("Gitea provisioning configuration is incomplete")
 if forge_provider == "gitea" and "forge_binding" in r and not {"storage_provider_id","gitea_ca_file"}<=set(r): raise RepositoryProvisioningError("modern Gitea provisioning configuration is incomplete")
 if forge_provider == "github" and "forge_binding" not in r and not legacy<=set(r): raise RepositoryProvisioningError("GitHub provisioning requires an explicit forge_binding")
 if forge_provider == "github" and ("forge_binding" not in r or "credential_selector" not in r["bootstrap_identity"]): raise RepositoryProvisioningError("GitHub provisioning requires an explicit forge_binding and credential selector")
 t=r.get("timeout_seconds",10)
 if isinstance(t,bool) or not isinstance(t,(int,float)):raise RepositoryProvisioningError("timeout is invalid")
 if "forge_binding" in r:
   # A forge binding intentionally contains only provider, URL, and a
   # credential selector.  Resolve user-vs-organization repository creation
   # from the reviewed bootstrap identity rather than defaulting every modern
   # binding to an organization endpoint.
   request=RepositoryProvisioningRequest(r["project_id"],r["revision"],r["intent_id"],forge_binding=r["forge_binding"],storage_provider_id=r.get("storage_provider_id"),gitea_origin=r.get("gitea_origin"),owner_kind=r["bootstrap_identity"]["owner_kind"],baseline_ref=r.get("baseline_ref"))
 else:
  request=RepositoryProvisioningRequest(**{k:r[k] for k in ("project_id","revision","intent_id","storage_provider_id","gitea_origin","owner","owner_kind","repository")}, forge_provider=forge_provider, baseline_ref=r.get("baseline_ref"))
 ca=None if forge_provider=="github" else _file(r["gitea_ca_file"],"Gitea CA file",False)
 return request,BootstrapIdentity(**r["bootstrap_identity"]),_file(r["projects_database"],"projects database",True),_file(r["providers_database"],"providers database",True),_file(r["hardware_database"],"hardware database",True),ca,float(t),r.get("github_origin","https://api.github.com")
def main(argv=None):
 p=argparse.ArgumentParser();p.add_argument("--config",required=True);p.add_argument("--apply",action="store_true");a=p.parse_args(argv)
 try:
  q,i,pdb,prdb,hdb,ca,t,origin=load_request(a.config);projects=ProjectControl(pdb);providers=ProviderRegistry(prdb,HardwareRegistry(hdb));x=GitHubProjectRepositoryProvisioner(projects,providers,q,bootstrap_identity=i,origin=origin,timeout_seconds=t) if q.forge_provider=="github" else GiteaProjectRepositoryProvisioner(projects,providers,q,bootstrap_identity=i,ca_file=ca,timeout_seconds=t);print(_json({**x.plan(),"state":"planned"} if not a.apply else x.provision()));return 0
 except (RepositoryProvisioningError,ValueError,KeyError) as e:print("repository provisioning blocked: "+str(e),file=sys.stderr);return 2
if __name__=="__main__":raise SystemExit(main())
