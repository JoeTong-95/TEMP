"""Process-local admission lock for approved Management context changes."""

from threading import RLock


# Project revisions and cached frontiers live in separate SQLite stores.  The
# Management process therefore uses one shared re-entrant lock to keep a final
# approved-context read and the native writer admission in one boundary.  The
# lock is deliberately process-local: the stores are Management-owned and any
# cross-process writer must use the service API.
APPROVED_CONTEXT_LOCK = RLock()
