"""Transport-neutral boundary for scoped communication journal operations.

The service intentionally contains no Feishu implementation, credentials, network
setup, command dispatch, or approval path. An inbound message is durable,
attributed input only; Management must evaluate any approval separately.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol

from .communication_journal import CommunicationJournal, CommunicationJournalError


_PUBLIC_MESSAGE_KINDS = frozenset({"mention", "status", "discussion", "voice"})
_EXCLUDED_MESSAGE_KINDS = frozenset({
    "personal", "secret", "hidden_reasoning", "heartbeat", "routine_heartbeat",
})


def _message_kind(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise CommunicationJournalError("message kind is invalid")
    if value in _EXCLUDED_MESSAGE_KINDS or value not in _PUBLIC_MESSAGE_KINDS:
        raise CommunicationJournalError("message kind is outside the communication boundary")
    return value


@dataclass(frozen=True)
class AuthenticatedCaller:
    """Identity established by an injected authentication boundary."""

    subject: str


@dataclass(frozen=True)
class CommunicationScope:
    """One route binding that an authenticated caller may use."""

    route: str
    project_id: str
    conversation_id: str
    runtime_id: str | None = None
    recipient_id: str | None = None

    def __post_init__(self) -> None:
        if not all(isinstance(value, str) and value for value in
                   (self.route, self.project_id, self.conversation_id)):
            raise CommunicationJournalError("communication scope identity is invalid")
        if self.runtime_id is not None and (not isinstance(self.runtime_id, str) or not self.runtime_id):
            raise CommunicationJournalError("runtime identity is invalid")
        if self.recipient_id is not None and (not isinstance(self.recipient_id, str) or not self.recipient_id):
            raise CommunicationJournalError("recipient identity is invalid")
        if (self.runtime_id is None) != (self.recipient_id is None):
            raise CommunicationJournalError("runtime and recipient identities must be paired")
        # A project route always has a stable local runtime/recipient identity;
        # configured infrastructure-Codex routes may replace these defaults.
        if self.runtime_id is None and self.recipient_id is None:
            object.__setattr__(self, "runtime_id", f"runtime:{self.project_id}")
            object.__setattr__(self, "recipient_id", f"project:{self.project_id}")

    def journal_routes(self) -> dict[str, dict[str, str]]:
        binding = {"project_id": self.project_id, "conversation_id": self.conversation_id}
        if self.runtime_id is not None:
            binding["runtime_id"] = self.runtime_id
        if self.recipient_id is not None:
            binding["recipient_id"] = self.recipient_id
        return {self.route: binding}


@dataclass(frozen=True)
class OutboundMessage:
    """The minimal data a sender receives after a durable claim."""

    external_id: str
    route: str
    project_id: str
    conversation_id: str
    correlation_id: str
    content: str
    runtime_id: str | None = None
    recipient_id: str | None = None
    message_kind: str = "discussion"
    sender_id: str | None = None
    transport_uuid_version: int | None = None


class Sender(Protocol):
    """Injectable deterministic transport adapter; return only after acceptance."""

    def send(self, message: OutboundMessage) -> None: ...


@dataclass(frozen=True)
class RepairAuthorization:
    action_id: str
    service_id: str
    approval_reference: str
    safety_class: str = "reversible"

    def __post_init__(self) -> None:
        if any(not isinstance(value, str) or not value or len(value) > 256
               for value in (self.action_id, self.service_id, self.approval_reference, self.safety_class)):
            raise CommunicationJournalError("repair authorization is invalid")
        if self.safety_class != "reversible":
            raise CommunicationJournalError("repair action is outside the reversible safety policy")


RepairDispatcher = Callable[[RepairAuthorization, str], Mapping[str, Any]]
HealthProbe = Callable[[str], Mapping[str, Any]]
@dataclass(frozen=True)
class MaintenanceNotice:
    kind: str
    subject_id: str
    summary: str
    correlation_id: str


MaintenanceProjector = Callable[[CommunicationScope, MaintenanceNotice], Any]

_PROHIBITED_REPAIR_ACTIONS = frozenset({
    "reboot", "reboot-host", "destructive", "destructive-change",
    "network", "network-security", "security", "pve2", "pve2-change",
})


Authentication = Callable[[object], AuthenticatedCaller]
ScopeResolver = Callable[[AuthenticatedCaller, str], CommunicationScope | None]


class CommunicationService:
    """Authenticate, resolve one scope, then delegate durable work to the journal."""

    def __init__(self, journal: CommunicationJournal, authenticate: Authentication,
                 resolve_scope: ScopeResolver, sender: Sender, *,
                 route_bindings: Mapping[str, CommunicationScope] | None = None,
                 repair_allowlist: Mapping[str, RepairAuthorization] | None = None,
                 repair_dispatcher: RepairDispatcher | None = None,
                 health_probe: HealthProbe | None = None,
                 maintenance_projector: MaintenanceProjector | None = None):
        self.journal = journal
        self.authenticate = authenticate
        self.resolve_scope = resolve_scope
        self.sender = sender
        self.repair_allowlist = dict(repair_allowlist or {})
        self.repair_dispatcher = repair_dispatcher
        self.health_probe = health_probe
        self.maintenance_projector = maintenance_projector
        if any(key != value.action_id for key, value in self.repair_allowlist.items()):
            raise CommunicationJournalError("repair allowlist is invalid")
        self.route_bindings = dict(route_bindings or {})
        for route, scope in self.route_bindings.items():
            if not isinstance(route, str) or not route or not isinstance(scope, CommunicationScope) or scope.route != route:
                raise CommunicationJournalError("configured route binding is invalid")

    @staticmethod
    def _same_scope(left: CommunicationScope, right: CommunicationScope) -> bool:
        return (left.route == right.route and left.project_id == right.project_id
                and left.conversation_id == right.conversation_id
                and left.runtime_id == right.runtime_id
                and left.recipient_id == right.recipient_id)

    def _scope(self, credential: object, route: str,
               expected_scope: CommunicationScope | None = None) -> tuple[AuthenticatedCaller, CommunicationScope]:
        caller = self.authenticate(credential)
        if not isinstance(caller, AuthenticatedCaller) or not caller.subject:
            raise CommunicationJournalError("authentication did not establish a caller")
        scope = self.resolve_scope(caller, route)
        if not isinstance(scope, CommunicationScope) or scope.route != route:
            raise CommunicationJournalError("caller has no route scope")
        if expected_scope is not None and not isinstance(expected_scope, CommunicationScope):
            raise CommunicationJournalError("expected route scope is invalid")
        configured = self.route_bindings.get(route)
        if configured is not None:
            if expected_scope is not None and not self._same_scope(configured, expected_scope):
                raise CommunicationJournalError("route expectation conflicts with configured binding")
            expected_scope = configured
        if expected_scope is not None and not self._same_scope(scope, expected_scope):
            raise CommunicationJournalError("authenticated route scope does not match configured identity")
        return caller, scope

    def scope_for(self, *, credential: object, route: str) -> CommunicationScope:
        """Return the authenticated scope for a caller-owned route."""
        _, scope = self._scope(credential, route)
        return scope

    @staticmethod
    def _repair_evidence(value: object, label: str) -> tuple[str, str, dict[str, Any]]:
        if not isinstance(value, Mapping) or set(value) != {"status", "reason", "evidence"}:
            raise CommunicationJournalError(f"{label} is malformed")
        status, reason, evidence = value["status"], value["reason"], value["evidence"]
        if status not in {"succeeded", "failed", "unknown", "healthy", "unhealthy"}:
            raise CommunicationJournalError(f"{label} status is invalid")
        if not isinstance(reason, str) or not reason or len(reason) > 1024 or not isinstance(evidence, Mapping):
            raise CommunicationJournalError(f"{label} is malformed")
        try:
            dict(evidence)
            json.dumps(dict(evidence), sort_keys=True, separators=(",", ":"), allow_nan=False)
        except (TypeError, ValueError) as error:
            raise CommunicationJournalError(f"{label} is malformed") from error
        return status, reason, dict(evidence)

    def execute_repair(self, *, credential: object, route: str, operation_id: str,
                       idempotency_key: str, service_id: str, action_id: str,
                       correlation_id: str, expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Run one already-authorized injected repair and persist its outcome."""
        _, scope = self._scope(credential, route, expected_scope)
        if any(not isinstance(value, str) or not value or len(value) > 256
               for value in (operation_id, idempotency_key, service_id, action_id, correlation_id)):
            raise CommunicationJournalError("repair identity is invalid")
        inserted, prior = self.journal.begin_repair(
            idempotency_key=idempotency_key, operation_id=operation_id,
            project_id=scope.project_id, service_id=service_id, action_id=action_id,
            correlation_id=correlation_id, route=route, conversation_id=scope.conversation_id,
            runtime_id=scope.runtime_id or "", recipient_id=scope.recipient_id or "")
        if not inserted:
            if prior["operation_id"] != operation_id or prior["service_id"] != service_id or prior["action_id"] != action_id or prior["correlation_id"] != correlation_id:
                raise CommunicationJournalError("repair idempotency key conflicts")
            return prior
        authorization = self.repair_allowlist.get(action_id)
        prohibited = action_id.casefold() in _PROHIBITED_REPAIR_ACTIONS or any(
            marker in action_id.casefold() for marker in ("reboot", "destructive", "network-security", "pve2"))
        if authorization is None or authorization.service_id != service_id or prohibited:
            result = self.journal.complete_repair(idempotency_key=idempotency_key, status="rejected",
                                                  reason="repair action is outside the reversible safety policy",
                                                  effect_evidence={}, health_evidence={})
            return self._project_repair(scope, result)
        status, reason, effect, health = "unknown", "repair outcome is unknown", {}, {}
        try:
            if self.repair_dispatcher is None or self.health_probe is None:
                raise CommunicationJournalError("repair capabilities are unavailable")
            dispatch_status, dispatch_reason, effect = self._repair_evidence(
                self.repair_dispatcher(authorization, operation_id), "repair execution evidence")
            reason = dispatch_reason
            if dispatch_status == "succeeded":
                probe_status, probe_reason, health = self._repair_evidence(
                    self.health_probe(operation_id), "repair health evidence")
                status = "succeeded" if probe_status == "healthy" else ("failed" if probe_status == "unhealthy" else "unknown")
                reason = probe_reason if status == "succeeded" else probe_reason
            elif dispatch_status == "failed":
                status, reason = "failed", "repair execution failed"
            else:
                status, reason = "unknown", "repair execution outcome is unknown"
        except Exception:
            status, reason = "unknown", "repair effect or health outcome is unavailable"
        result = self.journal.complete_repair(idempotency_key=idempotency_key, status=status,
                                              reason=reason, effect_evidence=effect,
                                              health_evidence=health)
        return self._project_repair(scope, result)

    def _project_repair(self, scope: CommunicationScope, result: Mapping[str, Any]) -> dict[str, Any]:
        if self.maintenance_projector is not None:
            summary = f"repair outcome status: {result['status']}"
            notice = MaintenanceNotice("maintenance_result", result["service_id"], summary,
                                       result["correlation_id"])
            self.maintenance_projector(scope, notice)
        return dict(result)

    @staticmethod
    def _journal_scope(scope: CommunicationScope) -> dict[str, Any]:
        return {
            "route": scope.route,
            "project_id": scope.project_id,
            "conversation_id": scope.conversation_id,
            "runtime_id": scope.runtime_id,
            "recipient_id": scope.recipient_id,
            "routes": scope.journal_routes(),
        }

    def receive_inbound(self, *, credential: object, route: str, external_id: str,
                        sender_id: str, correlation_id: str, content: str,
                        message_kind: str = "discussion",
                        expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Persist one authenticated transport event; it never applies an approval."""
        kind = _message_kind(message_kind)
        _, scope = self._scope(credential, route, expected_scope)
        result = self.journal.inbound(external_id=external_id, sender=sender_id,
                                      correlation_id=correlation_id, content=content,
                                      message_kind=kind,
                                      **self._journal_scope(scope))
        return {**result, "route": scope.route, "project_id": scope.project_id,
                "conversation_id": scope.conversation_id, "runtime_id": scope.runtime_id,
                "recipient_id": scope.recipient_id, "message_kind": kind}

    def queue_outbound(self, *, credential: object, route: str, external_id: str,
                       correlation_id: str, content: str,
                       message_kind: str = "discussion",
                       expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Durably queue a message. The caller must invoke delivery separately."""
        kind = _message_kind(message_kind)
        caller, scope = self._scope(credential, route, expected_scope)
        return self.journal.outbox(external_id=external_id, correlation_id=correlation_id,
                                   content=content, message_kind=kind, sender=caller.subject,
                                   **self._journal_scope(scope))

    def outbox_status(self, *, credential: object, route: str, external_id: str,
                      expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Read a scoped delivery state, including ``unknown`` reconciliation cases."""
        _, scope = self._scope(credential, route, expected_scope)
        return self.journal.get(kind="outbox", external_id=external_id, **self._journal_scope(scope))

    def list_outbox(self, *, credential: object, route: str,
                    states: frozenset[str] = frozenset({"pending"}), limit: int = 100,
                    cursor: str | None = None,
                    expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Discover a bounded page of durable outbound work after restart."""
        _, scope = self._scope(credential, route, expected_scope)
        return self.journal.list_route_messages(kind="outbox", states=states, limit=limit,
                                                cursor=cursor, **self._journal_scope(scope))

    def deliver_outbound(self, *, credential: object, route: str, external_id: str,
                         lease_seconds: int | float = 30,
                         expected_scope: CommunicationScope | None = None) -> dict[str, Any] | None:
        """Claim once and invoke the injected sender.

        A sender exception makes the record ``unknown``: it is deliberately not
        retried. A later Management reconciliation must decide any next action.
        """
        caller, scope = self._scope(credential, route, expected_scope)
        journal_scope = self._journal_scope(scope)
        claim = self.journal.claim_outbox(external_id=external_id, claimant=caller.subject,
                                          lease_seconds=lease_seconds, sender=caller.subject,
                                          **journal_scope)
        if claim is None:
            return None
        record = self.journal.get(kind="outbox", external_id=external_id, **journal_scope)
        message = OutboundMessage(external_id=external_id, route=scope.route,
                                  project_id=scope.project_id, conversation_id=scope.conversation_id,
                                  correlation_id=record["correlation_id"], content=record["content"],
                                  runtime_id=record.get("runtime_id"), recipient_id=record.get("recipient_id"),
                                  message_kind=record.get("message_kind", "discussion"),
                                  sender_id=record.get("sender"),
                                  transport_uuid_version=record.get("transport_uuid_version"))
        try:
            self.sender.send(message)
        except Exception:
            desired_state = "unknown"
        else:
            desired_state = "delivered"
        try:
            self.journal.outcome(external_id=external_id, claimant=caller.subject,
                                 claim_token=claim["claim_token"], state=desired_state, **journal_scope)
        except CommunicationJournalError:
            # A slow sender can cross its bounded lease. The journal has then
            # recorded unknown atomically; never convert that ambiguity to a retry.
            if self.journal.get(kind="outbox", external_id=external_id, **journal_scope)["state"] != "unknown":
                raise
            desired_state = "unknown"
        return {"state": desired_state, "claim_generation": claim["claim_generation"]}
