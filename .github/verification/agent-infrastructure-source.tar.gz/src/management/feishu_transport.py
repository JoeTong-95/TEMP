"""Bounded Feishu HTTP sender and verified-event translator.

Official API references (checked 2026-09-04):
* https://open.feishu.cn/document/server-docs/authentication-management/access-token/tenant_access_token_internal
* https://open.feishu.cn/document/server-docs/im-v1/message/create
* https://open.feishu.cn/document/server-docs/im-v1/message/events/receive
* https://open.feishu.cn/document/server-docs/im-v1/message/get-2
* https://github.com/larksuite/oapi-sdk-python/blob/v2_main/samples/event/flask_sample.py
* https://github.com/larksuite/oapi-sdk-python/blob/v2_main/lark_oapi/event/dispatcher_handler.py

This is an adapter, not a listener or credential loader.  Deployments inject an
already-configured app ID/secret, route bindings, bounded HTTP client, and event
signature verifier.  It never follows redirects or configures proxies.
"""
from __future__ import annotations

import json
import math
import time
import hashlib
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import Any, Callable, Mapping, Protocol
from urllib.parse import urlsplit

from .communication_journal import CommunicationJournalError
from .communication_service import CommunicationScope, CommunicationService, MaintenanceNotice, OutboundMessage, Sender


FEISHU_ORIGIN = "https://open.feishu.cn"
TOKEN_URL = f"{FEISHU_ORIGIN}/open-apis/auth/v3/tenant_access_token/internal"
MESSAGE_URL = f"{FEISHU_ORIGIN}/open-apis/im/v1/messages?receive_id_type=chat_id"
_MAX_FAILURE_STATUS_PAGES = 10_000


class FeishuTransportError(CommunicationJournalError):
    """A Feishu response or event is malformed, unverified, or unsuccessful."""


@dataclass(frozen=True)
class HttpResponse:
    status: int
    body: Mapping[str, Any]


class BoundedHttpClient(Protocol):
    """HTTP implementation must enforce the passed timeout and redirect policy."""

    def post(self, *, url: str, headers: Mapping[str, str], body: Mapping[str, Any],
             timeout_seconds: float, allow_redirects: bool) -> HttpResponse: ...


class EventAuthenticator(Protocol):
    """Authenticate original callback bytes before their parsed event is used.

    Feishu's supported Python path is the official ``lark_oapi``
    ``EventDispatcherHandler`` configured with the developer-console
    verification token and (when configured) encrypt key.  Its callback
    verification/decryption semantics are intentionally not reimplemented
    here.  An injected adapter must fail closed and return its configured
    Communication credential only after that official boundary accepts the
    callback.  For encrypted callbacks it must pass the SDK-decrypted plaintext
    body to :meth:`FeishuInboundTranslator.ingest`, not the ciphertext.
    """

    def authenticate(self, *, headers: Mapping[str, str], raw_body: bytes) -> object: ...


@dataclass(frozen=True)
class FeishuRoute:
    chat_id: str
    project_id: str
    conversation_id: str
    runtime_id: str | None = None
    recipient_id: str | None = None
    mention_targets: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class FeishuConfig:
    app_id: str
    app_secret: str = field(repr=False)
    routes: Mapping[str, FeishuRoute]
    timeout_seconds: float = 10.0
    token_refresh_skew_seconds: float = 30.0

    def __post_init__(self) -> None:
        if not isinstance(self.app_id, str) or not self.app_id or not isinstance(self.app_secret, str) or not self.app_secret:
            raise FeishuTransportError("Feishu app configuration is incomplete")
        if not _finite_number(self.timeout_seconds) or not 0 < self.timeout_seconds <= 30:
            raise FeishuTransportError("Feishu timeout must be finite and from 0 through 30 seconds")
        if not _finite_number(self.token_refresh_skew_seconds) or self.token_refresh_skew_seconds < 0:
            raise FeishuTransportError("Feishu token refresh skew is invalid")
        copied_routes = dict(self.routes)
        if not copied_routes or len({route.chat_id for route in copied_routes.values() if isinstance(route, FeishuRoute)}) != len(copied_routes):
            raise FeishuTransportError("Feishu routes must have unique chat bindings")
        for name, route in copied_routes.items():
            if not isinstance(name, str) or not name or not isinstance(route, FeishuRoute):
                raise FeishuTransportError("Feishu route is invalid")
            if not all(isinstance(value, str) and value for value in (route.chat_id, route.project_id, route.conversation_id)):
                raise FeishuTransportError("Feishu route is incomplete")
            if route.runtime_id is not None and (not isinstance(route.runtime_id, str) or not route.runtime_id):
                raise FeishuTransportError("Feishu runtime identity is invalid")
            if route.recipient_id is not None and (not isinstance(route.recipient_id, str) or not route.recipient_id):
                raise FeishuTransportError("Feishu recipient identity is invalid")
            if (route.runtime_id is None) != (route.recipient_id is None):
                raise FeishuTransportError("Feishu runtime and recipient identities must be paired")
            if not isinstance(route.mention_targets, Mapping):
                raise FeishuTransportError("Feishu mention target bindings are invalid")
            if any(not isinstance(key, str) or not key or not isinstance(value, str) or not value
                   for key, value in route.mention_targets.items()):
                raise FeishuTransportError("Feishu mention target bindings are invalid")
            copied_routes[name] = replace(
                route, mention_targets=MappingProxyType(dict(route.mention_targets)),
            )
        object.__setattr__(self, "routes", MappingProxyType(copied_routes))


@dataclass(frozen=True)
class VoiceTranscriptionRequest:
    """A durable voice reference awaiting an explicitly approved STT workflow."""

    route: str
    project_id: str
    conversation_id: str
    message_id: str
    file_key: str
    sender_id: str


@dataclass(frozen=True)
class InboundEvent:
    event_id: str
    message_id: str
    route: str
    sender_id: str
    correlation_id: str
    content: str
    mentions: tuple[str, ...]
    voice: VoiceTranscriptionRequest | None = None
    runtime_id: str | None = None
    recipient_id: str | None = None
    message_kind: str = "discussion"


class VoiceDownloader(Protocol):
    def download(self, request: VoiceTranscriptionRequest) -> bytes: ...


class SttAdapter(Protocol):
    adapter_id: str
    def submit(self, request: VoiceTranscriptionRequest, audio: bytes) -> None: ...


class FeishuVoiceHandoff:
    """Bounded media handoff to an injected allowlisted STT adapter.

    It has no model installation, tenant token, or transcription authority. The
    stable message ID is the adapter idempotency key; adapters must preserve it.
    """
    def __init__(self, config: FeishuConfig, downloader: VoiceDownloader, adapters: Mapping[str, SttAdapter], *, max_audio_bytes: int = 25_000_000):
        if not isinstance(max_audio_bytes, int) or not 1 <= max_audio_bytes <= 100_000_000 or not adapters:
            raise FeishuTransportError("voice handoff configuration is invalid")
        if any(not isinstance(key, str) or not key or getattr(value, "adapter_id", None) != key for key, value in adapters.items()):
            raise FeishuTransportError("STT adapter allowlist is invalid")
        self.config, self.downloader, self.adapters, self.max_audio_bytes = config, downloader, dict(adapters), max_audio_bytes

    def handoff(self, request: VoiceTranscriptionRequest, adapter_id: str) -> dict[str, str]:
        route = self.config.routes.get(request.route)
        if route is None or route.project_id != request.project_id or route.conversation_id != request.conversation_id or not isinstance(adapter_id, str) or adapter_id not in self.adapters:
            raise FeishuTransportError("voice handoff scope or adapter is denied")
        audio = self.downloader.download(request)
        if not isinstance(audio, bytes) or not audio or len(audio) > self.max_audio_bytes:
            raise FeishuTransportError("voice download is invalid or exceeds limit")
        self.adapters[adapter_id].submit(request, audio)
        return {"adapter_id": adapter_id, "message_id": request.message_id, "state": "submitted"}


@dataclass(frozen=True)
class OperationalNotice:
    kind: str
    subject_id: str
    summary: str
    correlation_id: str

    def __post_init__(self) -> None:
        if self.kind not in {"codex_to_stack", "stack_to_codex", "maintenance_escalation", "maintenance_result", "node_disconnected", "node_reconnected", "model_rollout"} or any(not isinstance(value, str) or not value or len(value) > 2048 for value in (self.subject_id, self.summary, self.correlation_id)):
            raise FeishuTransportError("operational notice is invalid")


_DIAGNOSTIC_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:._/-]{0,127}$")
_CREDENTIAL_KEYS = (
    r"authorization|access[_ -]?token|refresh[_ -]?token|id[_ -]?token|token|"
    r"client[_ -]?secret|secret|password|passwd|api[ _-]?key|access[ _-]?key|credential"
)
_CREDENTIAL_ASSIGNMENT = re.compile(
    rf"(?i)(?<![A-Za-z0-9_])[\"']?(?:{_CREDENTIAL_KEYS})[\"']?\s*[:=]\s*"
)
_CREDENTIAL_FLAG = re.compile(rf"(?i)--(?:{_CREDENTIAL_KEYS})\s+")
_BEARER_PREFIX = re.compile(r"(?i)\bbearer\s+")


def _redact_value(text: str, value_start: int) -> tuple[str, int]:
    """Replace one value while retaining its quote and surrounding syntax."""
    if value_start >= len(text):
        return text, value_start
    if text[value_start:value_start + 7].lower() == "bearer ":
        index = value_start + 7
        # Braces and brackets can be ordinary characters in an unquoted
        # diagnostic token (for example ``password=abc}SECRET``).  Stopping
        # there would leak the suffix.  Whitespace and shell separators are
        # the only safe token boundaries for this deliberately conservative
        # form; JSON quoted values are handled by the branch above.
        while index < len(text) and text[index] not in " \t,;&":
            index += 1
        return text[:value_start] + "[redacted]" + text[index:], index
    quote = text[value_start] if text[value_start] in "\"'" else None
    if quote is not None:
        index = value_start + 1
        escaped = False
        while index < len(text):
            char = text[index]
            if char == quote and not escaped:
                return text[:value_start] + quote + "[redacted]" + quote + text[index + 1:], index + 1
            escaped = char == "\\" and not escaped
            if char != "\\":
                escaped = False
            index += 1
        end = len(text)
        return text[:value_start] + quote + "[redacted]", end
    index = value_start
    while index < len(text) and text[index] not in " \t,;&":
        index += 1
    if index == value_start:
        # Preserve the delimiter while making progress.  An empty value must
        # still be marked so a later credential form is not skipped.
        marker = "[redacted]"
        return text[:value_start] + marker + text[value_start:], value_start + len(marker)
    return text[:value_start] + "[redacted]" + text[index:], index


def _value_is_redacted(text: str, value_start: int) -> bool:
    value_start += len(text[value_start:]) - len(text[value_start:].lstrip())
    if text.startswith("[redacted]", value_start):
        return True
    if value_start < len(text) and text[value_start] in "\"'":
        quote = text[value_start]
        return text.startswith(quote + "[redacted]" + quote, value_start)
    return False


def _diagnostic_identity(value: object, name: str) -> str:
    if not isinstance(value, str) or not _DIAGNOSTIC_ID.fullmatch(value):
        raise FeishuTransportError(f"{name} is invalid")
    return value


def _sanitize_diagnostic_summary(value: object) -> str:
    if not isinstance(value, str) or not value.strip():
        raise FeishuTransportError("diagnostic summary is invalid")
    # Diagnostics are operator-visible evidence. Collapse formatting and redact
    # common credential forms before the value is persisted or sent.
    summary = " ".join(value.split())
    # Find the next credential form in source order and mask its value with
    # quote awareness. Re-scanning after each replacement makes nested JSON and
    # any permutation of forms deterministic without exposing a later value.
    for _ in range(64):
        matches = []
        for pattern in (_CREDENTIAL_ASSIGNMENT, _CREDENTIAL_FLAG, _BEARER_PREFIX):
            for match in pattern.finditer(summary):
                if not _value_is_redacted(summary, match.end()):
                    matches.append(match)
                    break
        if not matches:
            break
        match = min(matches, key=lambda item: item.start())
        value_start = match.end()
        updated, end = _redact_value(summary, value_start)
        if updated == summary:
            break
        summary = updated
    return summary[:512]


@dataclass(frozen=True)
class DiagnosticEvent:
    """A bounded, correlatable infrastructure failure for operator reporting."""

    diagnostic_id: str
    service_id: str
    project_id: str
    summary: str
    correlation_id: str
    effect_id: str | None = None

    def __post_init__(self) -> None:
        diagnostic_id = _diagnostic_identity(self.diagnostic_id, "diagnostic ID")
        service_id = _diagnostic_identity(self.service_id, "service ID")
        project_id = _diagnostic_identity(self.project_id, "project ID")
        correlation_id = _diagnostic_identity(self.correlation_id, "correlation ID")
        effect_id = self.effect_id if self.effect_id is not None else diagnostic_id
        effect_id = _diagnostic_identity(effect_id, "effect ID")
        object.__setattr__(self, "diagnostic_id", diagnostic_id)
        object.__setattr__(self, "service_id", service_id)
        object.__setattr__(self, "project_id", project_id)
        object.__setattr__(self, "summary", _sanitize_diagnostic_summary(self.summary))
        object.__setattr__(self, "correlation_id", correlation_id)
        object.__setattr__(self, "effect_id", effect_id)


class FeishuManagementNotifier:
    """Typed, journal-backed notices; delivery claims make retries idempotent."""
    def __init__(self, service: CommunicationService, credential: object): self.service, self.credential = service, credential
    def queue(self, route: str, notice: OperationalNotice) -> dict[str, Any]:
        canonical = json.dumps({"kind": notice.kind, "subject_id": notice.subject_id, "summary": notice.summary, "correlation_id": notice.correlation_id}, sort_keys=True, separators=(",", ":"))
        external_id = "notice-" + hashlib.sha256((route + "\0" + canonical).encode("utf-8")).hexdigest()[:40]
        return self.service.queue_outbound(credential=self.credential, route=route, external_id=external_id, correlation_id=notice.correlation_id, content=canonical)

    def project_maintenance_result(self, route: str, notice: MaintenanceNotice,
                                    *, expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Convert the transport-neutral Management notice at the Feishu boundary."""
        if not isinstance(notice, MaintenanceNotice) or notice.kind != "maintenance_result":
            raise FeishuTransportError("maintenance notice is invalid")
        scope = self.service.scope_for(credential=self.credential, route=route)
        if expected_scope is not None and (
                not isinstance(expected_scope, CommunicationScope)
                or any(getattr(scope, key) != getattr(expected_scope, key)
                       for key in ("route", "project_id", "conversation_id", "runtime_id", "recipient_id"))):
            raise FeishuTransportError("maintenance notice scope is invalid")
        if scope.route != route or not notice.subject_id or not notice.correlation_id:
            raise FeishuTransportError("maintenance notice scope is invalid")
        summary = _sanitize_diagnostic_summary(notice.summary)
        operational = OperationalNotice("maintenance_result", notice.subject_id,
                                        summary, notice.correlation_id)
        return self.queue(route, operational)
    def deliver(self, route: str, external_id: str,
                *, expected_scope: CommunicationScope | None = None) -> dict[str, Any] | None:
        return self.service.deliver_outbound(
            credential=self.credential, route=route, external_id=external_id,
            expected_scope=expected_scope,
        )

    @staticmethod
    def _failure_external_id(route: str, event: DiagnosticEvent) -> str:
        if not isinstance(route, str) or not route:
            raise FeishuTransportError("failure route is invalid")
        # The key is derived only from stable identities. A changed diagnostic
        # summary therefore cannot create a second effect for the same event.
        identity = f"{route}\0{event.diagnostic_id}\0{event.effect_id}"
        return "failure-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:40]

    @staticmethod
    def _failure_content(event: DiagnosticEvent) -> str:
        return json.dumps({
            "kind": "infrastructure_failure",
            "diagnostic_id": event.diagnostic_id,
            "effect_id": event.effect_id,
            "service_id": event.service_id,
            "project_id": event.project_id,
            "summary": event.summary,
            "correlation_id": event.correlation_id,
        }, sort_keys=True, separators=(",", ":"))

    def queue_failure(self, route: str, event: DiagnosticEvent,
                      *, expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Persist one sanitized failure notice in the scoped status outbox."""
        if not isinstance(event, DiagnosticEvent):
            raise FeishuTransportError("diagnostic event is invalid")
        scope = expected_scope or self.service.scope_for(credential=self.credential, route=route)
        if not isinstance(scope, CommunicationScope) or scope.route != route:
            raise FeishuTransportError("failure route scope is invalid")
        if scope.project_id != event.project_id:
            raise FeishuTransportError("diagnostic project is outside the authenticated route scope")
        external_id = self._failure_external_id(route, event)
        queued = self.service.queue_outbound(
            credential=self.credential, route=route, external_id=external_id,
            correlation_id=event.correlation_id, content=self._failure_content(event),
            message_kind="status", expected_scope=scope,
        )
        return {
            **queued,
            "external_id": external_id,
            "diagnostic_id": event.diagnostic_id,
            "effect_id": event.effect_id,
            "project_id": event.project_id,
            "service_id": event.service_id,
        }

    def failure_status(self, route: str, diagnostic: str | DiagnosticEvent,
                       effect_id: str | None = None,
                       *, expected_scope: CommunicationScope | None = None) -> dict[str, Any]:
        """Read the truthful operator-visible state of a failure notice."""
        scope = expected_scope or self.service.scope_for(credential=self.credential, route=route)
        if not isinstance(scope, CommunicationScope) or scope.route != route:
            raise FeishuTransportError("failure route scope is invalid")
        if isinstance(diagnostic, DiagnosticEvent):
            event = diagnostic
            if event.project_id != scope.project_id:
                raise FeishuTransportError("diagnostic project is outside the authenticated route scope")
        else:
            diagnostic_id = _diagnostic_identity(diagnostic, "diagnostic ID")
            if effect_id is None:
                # The effect identity is assigned by the producer and may be
                # distinct from the diagnostic identity. Discover it from the
                # scoped durable outbox before deriving an external key.
                first_candidate = None
                cursor = None
                seen_cursors = set()
                pages = 0
                while True:
                    if pages >= _MAX_FAILURE_STATUS_PAGES:
                        raise FeishuTransportError("failure status pagination exceeded its bound")
                    page = self.service.list_outbox(
                        credential=self.credential, route=route,
                        states=frozenset({"pending", "sending", "delivered", "unknown"}),
                        limit=100, cursor=cursor, expected_scope=scope,
                    )
                    pages += 1
                    if not isinstance(page, Mapping):
                        raise FeishuTransportError("failure status page is invalid")
                    items = page.get("items")
                    next_cursor = page.get("next_cursor")
                    if not isinstance(items, list) or (next_cursor is not None and
                                                       (not isinstance(next_cursor, str) or not next_cursor)):
                        raise FeishuTransportError("failure status page is invalid")
                    for item in items:
                        if not isinstance(item, Mapping) or not isinstance(item.get("external_id"), str) \
                                or not isinstance(item.get("content"), str):
                            raise FeishuTransportError("failure status item is invalid")
                        try:
                            payload = json.loads(item["content"])
                        except (TypeError, ValueError, json.JSONDecodeError):
                            continue
                        if isinstance(payload, Mapping) and payload.get("diagnostic_id") == diagnostic_id:
                            # Only the first match is needed to reconstruct the
                            # durable identity. A second match is definitive
                            # ambiguity, so fail immediately instead of
                            # retaining an unbounded list across all pages.
                            if first_candidate is not None:
                                raise FeishuTransportError(
                                    "diagnostic ID is ambiguous in the authenticated route scope"
                                )
                            first_candidate = (item["external_id"], payload)
                    if next_cursor is None:
                        break
                    if next_cursor == cursor or next_cursor in seen_cursors:
                        raise FeishuTransportError("failure status pagination did not make progress")
                    seen_cursors.add(next_cursor)
                    cursor = next_cursor
                if first_candidate is not None:
                    _external_id, payload = first_candidate
                    try:
                        event = DiagnosticEvent(
                            diagnostic_id=payload["diagnostic_id"], effect_id=payload["effect_id"],
                            service_id=payload["service_id"], project_id=payload["project_id"],
                            summary=payload["summary"], correlation_id=payload["correlation_id"],
                        )
                    except (KeyError, TypeError, FeishuTransportError) as error:
                        raise FeishuTransportError("failure notice payload is invalid") from error
                    if event.project_id != scope.project_id or self._failure_external_id(route, event) != _external_id:
                        raise FeishuTransportError("failure notice payload conflicts with durable scope")
                else:
                    event = DiagnosticEvent(
                        diagnostic_id=diagnostic_id, service_id="unknown", project_id="unknown",
                        summary="status lookup", correlation_id=diagnostic_id,
                    )
            else:
                event = DiagnosticEvent(
                    diagnostic_id=diagnostic_id, effect_id=effect_id,
                    service_id="unknown", project_id="unknown",
                    summary="status lookup", correlation_id=diagnostic_id,
                )
        external_id = self._failure_external_id(route, event)
        record = self.service.outbox_status(
            credential=self.credential, route=route, external_id=external_id,
            expected_scope=scope,
        )
        try:
            payload = json.loads(record["content"])
        except (TypeError, ValueError, json.JSONDecodeError) as error:
            raise FeishuTransportError("failure notice payload is invalid") from error
        required = {"kind", "diagnostic_id", "effect_id", "service_id", "project_id", "summary", "correlation_id"}
        if not isinstance(payload, Mapping) or set(payload) != required or payload.get("kind") != "infrastructure_failure":
            raise FeishuTransportError("failure notice payload is invalid")
        try:
            payload_diagnostic = _diagnostic_identity(payload["diagnostic_id"], "diagnostic ID")
            payload_effect = _diagnostic_identity(payload["effect_id"], "effect ID")
            payload_service = _diagnostic_identity(payload["service_id"], "service ID")
            payload_project = _diagnostic_identity(payload["project_id"], "project ID")
            payload_correlation = _diagnostic_identity(payload["correlation_id"], "correlation ID")
            payload_summary = _sanitize_diagnostic_summary(payload["summary"])
        except FeishuTransportError as error:
            raise FeishuTransportError("failure notice payload is invalid") from error
        if (payload_diagnostic != event.diagnostic_id or payload_effect != event.effect_id
                or payload_summary != payload["summary"] or payload_project != record["project_id"]
                or payload_project != scope.project_id or payload_correlation != record["correlation_id"]):
            raise FeishuTransportError("failure notice payload conflicts with durable scope")
        state = record["state"]
        return {
            "external_id": external_id,
            "diagnostic_id": payload_diagnostic,
            "effect_id": payload_effect,
            "project_id": payload_project,
            "service_id": payload_service,
            "correlation_id": payload_correlation,
            "delivery_status": state,
            "operator_status": state,
        }

    def report_failure(self, route: str, event: DiagnosticEvent, *,
                       codex_available: bool = True) -> dict[str, Any]:
        """Queue and, when reachable, attempt a failure notice delivery.

        ``codex_unavailable`` and ``unknown`` are explicit operator statuses;
        neither is converted into a successful notification claim.
        """
        if type(codex_available) is not bool:
            raise FeishuTransportError("Codex availability is invalid")
        scope = self.service.scope_for(credential=self.credential, route=route)
        if not isinstance(event, DiagnosticEvent) or event.project_id != scope.project_id:
            raise FeishuTransportError("diagnostic project is outside the authenticated route scope")
        queued = self.queue_failure(route, event, expected_scope=scope)
        if not codex_available:
            durable_state = queued["state"]
            return {
                **queued,
                "codex_available": False,
                "delivery_status": durable_state,
                "operator_status": "codex_unavailable" if durable_state == "pending" else durable_state,
            }
        delivered = self.deliver(route, queued["external_id"], expected_scope=scope)
        if delivered is None:
            current = self.failure_status(route, event, expected_scope=scope)
            return {**queued, **current, "codex_available": True}
        state = delivered["state"]
        return {
            **queued,
            "codex_available": True,
            "delivery_status": state,
            "operator_status": state,
        }

    # Names used by callers that describe the same owning operation in terms
    # of diagnostics rather than failures.
    notify_failure = report_failure
    queue_diagnostic = queue_failure


def _finite_number(value: object) -> bool:
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):  # type: ignore[override]
        return None


class BoundedHttpsClient:
    """Concrete HTTPS client for Feishu's fixed API origin only.

    It disables environment proxies and redirects, bounds response bytes, and
    translates network/JSON errors without exposing request secrets.
    """

    def __init__(self, *, max_request_bytes: int = 100_000, max_response_bytes: int = 1_000_000,
                 opener: Any | None = None):
        if isinstance(max_request_bytes, bool) or not isinstance(max_request_bytes, int) or not 1 <= max_request_bytes <= 1_000_000:
            raise FeishuTransportError("HTTP request limit is invalid")
        if isinstance(max_response_bytes, bool) or not isinstance(max_response_bytes, int) or not 1 <= max_response_bytes <= 10_000_000:
            raise FeishuTransportError("HTTP response limit is invalid")
        self.max_request_bytes = max_request_bytes
        self.max_response_bytes = max_response_bytes
        self.opener = opener or urllib.request.build_opener(
            urllib.request.ProxyHandler({}), _NoRedirect(), urllib.request.HTTPSHandler(),
        )

    def post(self, *, url: str, headers: Mapping[str, str], body: Mapping[str, Any],
             timeout_seconds: float, allow_redirects: bool) -> HttpResponse:
        try:
            parsed = urlsplit(url)
            valid_origin = (parsed.scheme == "https" and parsed.hostname == "open.feishu.cn"
                            and parsed.port in (None, 443) and parsed.username is None
                            and parsed.password is None and not parsed.fragment)
        except (TypeError, ValueError):
            valid_origin = False
        if not valid_origin:
            raise FeishuTransportError("HTTP destination is not the Feishu API origin")
        if allow_redirects or not _finite_number(timeout_seconds) or not 0 < timeout_seconds <= 30:
            raise FeishuTransportError("HTTP redirect or timeout policy is invalid")
        try:
            encoded = json.dumps(body, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
            if len(encoded) > self.max_request_bytes:
                raise FeishuTransportError("Feishu HTTP request exceeds limit")
            request = urllib.request.Request(url, data=encoded, headers=dict(headers), method="POST")
            with self.opener.open(request, timeout=float(timeout_seconds)) as response:
                raw = response.read(self.max_response_bytes + 1)
                status = response.getcode()
        except (OSError, urllib.error.URLError, urllib.error.HTTPError, TypeError, ValueError) as error:
            raise FeishuTransportError("Feishu HTTP request failed") from error
        if len(raw) > self.max_response_bytes:
            raise FeishuTransportError("Feishu HTTP response exceeds limit")
        try:
            decoded = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise FeishuTransportError("Feishu HTTP response is not JSON") from error
        if not isinstance(decoded, Mapping):
            raise FeishuTransportError("Feishu HTTP response is not an object")
        return HttpResponse(status, decoded)


class FeishuSender(Sender):
    """Sends a claimed outbox item using a cached tenant access token."""

    def __init__(self, config: FeishuConfig, http: BoundedHttpClient,
                 clock: Callable[[], float] = time.monotonic):
        self.config = config
        self.http = http
        self.clock = clock
        self._token: str | None = None
        self._token_expires_at = 0.0

    def _tenant_token(self) -> str:
        if self._token is not None and self.clock() < self._token_expires_at:
            return self._token
        response = self.http.post(
            url=TOKEN_URL, headers={"Content-Type": "application/json"},
            body={"app_id": self.config.app_id, "app_secret": self.config.app_secret},
            timeout_seconds=self.config.timeout_seconds, allow_redirects=False,
        )
        body = response.body
        token = body.get("tenant_access_token")
        expires_in = body.get("expire")
        if response.status != 200 or body.get("code") != 0 or not isinstance(token, str) or not token:
            raise FeishuTransportError("Feishu tenant token request failed")
        if not _finite_number(expires_in) or expires_in <= 0:
            raise FeishuTransportError("Feishu token expiry is invalid")
        usable_for = max(0.0, float(expires_in) - self.config.token_refresh_skew_seconds)
        self._token = token
        self._token_expires_at = self.clock() + usable_for
        return token

    @staticmethod
    def message_uuid(message: OutboundMessage) -> str:
        """Return the durable UUID for the journal schema that accepted ``message``.

        Version one is the pre-identity Feishu key.  It remains selectable for
        legacy rows after their route identities are bound, so a lost response
        cannot cause Feishu to accept a second visible message.  New journal
        rows use version two, which includes the scoped runtime and recipient.
        """
        if not isinstance(message.external_id, str) or not message.external_id:
            raise FeishuTransportError("message external ID is invalid")
        has_runtime = message.runtime_id is not None
        has_recipient = message.recipient_id is not None
        if has_runtime != has_recipient:
            raise FeishuTransportError("message runtime and recipient identities must be paired")
        if (isinstance(message.transport_uuid_version, bool)
                or message.transport_uuid_version not in (None, 1, 2)):
            raise FeishuTransportError("message UUID version is invalid")
        if not has_runtime and message.transport_uuid_version == 2:
            raise FeishuTransportError("scoped UUID version requires both identities")
        if (message.transport_uuid_version == 1
                or (message.transport_uuid_version is None
                    and not has_runtime and not has_recipient)):
            canonical_values = [message.route, message.project_id, message.conversation_id,
                                message.external_id]
        elif message.transport_uuid_version in (None, 2):
            canonical_values = [message.route, message.project_id, message.conversation_id,
                                message.runtime_id, message.recipient_id, message.external_id]
        else:
            raise FeishuTransportError("message UUID version is invalid")
        canonical = json.dumps(canonical_values, ensure_ascii=False,
                               separators=(",", ":")).encode("utf-8")
        return "agent-" + hashlib.sha256(canonical).hexdigest()[:40]

    @staticmethod
    def _route_identity(route: FeishuRoute) -> tuple[str, str]:
        runtime_id = route.runtime_id
        recipient_id = route.recipient_id
        if runtime_id is None and recipient_id is None:
            return f"runtime:{route.project_id}", f"project:{route.project_id}"
        if runtime_id is None or recipient_id is None:
            raise FeishuTransportError("configured Feishu route has partial identity")
        return runtime_id, recipient_id

    def _normalize_message(self, message: OutboundMessage, route: FeishuRoute) -> OutboundMessage:
        expected_runtime, expected_recipient = self._route_identity(route)
        has_runtime = message.runtime_id is not None
        has_recipient = message.recipient_id is not None
        if has_runtime != has_recipient:
            raise FeishuTransportError("message runtime and recipient identities must be paired")
        if not has_runtime:
            # A compatibility message has no scoped identity.  Bind both route
            # identities before UUID derivation while retaining the v1 key so a
            # retry cannot create a second visible Feishu message.
            version = message.transport_uuid_version if message.transport_uuid_version is not None else 1
            return replace(message, runtime_id=expected_runtime, recipient_id=expected_recipient,
                           transport_uuid_version=version)
        if message.runtime_id != expected_runtime or message.recipient_id != expected_recipient:
            raise FeishuTransportError("outbound recipient identity is outside the configured scope")
        return message

    def send(self, message: OutboundMessage) -> str:
        if message.message_kind not in {"mention", "status", "discussion", "voice"}:
            raise FeishuTransportError("message kind is outside the communication boundary")
        route = self.config.routes.get(message.route)
        if route is None or route.project_id != message.project_id or route.conversation_id != message.conversation_id:
            raise FeishuTransportError("outbound route is not configured for this scope")
        message = self._normalize_message(message, route)
        message_uuid = self.message_uuid(message)
        response = self.http.post(
            url=MESSAGE_URL,
            headers={"Authorization": f"Bearer {self._tenant_token()}", "Content-Type": "application/json"},
            body={"receive_id": route.chat_id, "msg_type": "text",
                  "content": json.dumps({"text": message.content}, ensure_ascii=False),
                  "uuid": message_uuid},
            timeout_seconds=self.config.timeout_seconds, allow_redirects=False,
        )
        data = response.body.get("data")
        if response.status != 200 or response.body.get("code") != 0 or not isinstance(data, Mapping):
            raise FeishuTransportError("Feishu message send failed")
        if not isinstance(data.get("message_id"), str) or not data["message_id"]:
            raise FeishuTransportError("Feishu message send did not return a message ID")
        # This is API acceptance evidence, not evidence that a human read it.
        return data["message_id"]


class FeishuInboundTranslator:
    """Verify, normalize, and persist Feishu message events through the service."""

    def __init__(self, service: CommunicationService, config: FeishuConfig, authenticator: EventAuthenticator,
                 max_event_bytes: int = 1_000_000):
        self.service = service
        self.config = config
        self.authenticator = authenticator
        if isinstance(max_event_bytes, bool) or not isinstance(max_event_bytes, int) or not 1 <= max_event_bytes <= 10_000_000:
            raise FeishuTransportError("Feishu event limit is invalid")
        self.max_event_bytes = max_event_bytes

    def ingest(self, *, headers: Mapping[str, str], raw_body: bytes) -> InboundEvent:
        if not isinstance(raw_body, bytes) or len(raw_body) > self.max_event_bytes:
            raise FeishuTransportError("raw callback body is invalid")
        credential = self.authenticator.authenticate(headers=headers, raw_body=raw_body)
        try:
            event = json.loads(raw_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise FeishuTransportError("authenticated callback body is not JSON") from error
        if not isinstance(event, Mapping):
            raise FeishuTransportError("authenticated callback body is not an object")
        header = self._mapping(event.get("header"), "event header")
        payload = self._mapping(event.get("event"), "event payload")
        message = self._mapping(payload.get("message"), "message")
        sender = self._mapping(payload.get("sender"), "sender")
        event_id = self._text(header.get("event_id"), "event ID")
        if header.get("event_type") != "im.message.receive_v1":
            raise FeishuTransportError("unsupported Feishu event type")
        message_id = self._text(message.get("message_id"), "message ID")
        chat_id = self._text(message.get("chat_id"), "chat ID")
        route_name, route = self._route_for_chat(chat_id)
        sender_id = self._sender_id(sender)
        message_type = self._text(message.get("message_type"), "message type")
        mentions = self._mentions(message.get("mentions"))
        raw_kind = message.get("message_kind", payload.get("message_kind"))
        has_explicit_kind = raw_kind is not None
        message_kind = self._message_kind(raw_kind)
        expected_scope = self._route_scope(route_name, route)
        if message_type == "text":
            content = self._text_content(message.get("content"))
            voice = None
            if not has_explicit_kind and mentions:
                message_kind = "mention"
        elif message_type == "audio":
            file_key = self._voice_file_key(message.get("content"))
            voice = VoiceTranscriptionRequest(route_name, route.project_id, route.conversation_id,
                                               message_id, file_key, sender_id)
            content = json.dumps({"kind": "voice", "transcription": "pending", "file_key": file_key}, sort_keys=True)
            if not has_explicit_kind:
                message_kind = "voice"
        else:
            raise FeishuTransportError("unsupported Feishu message type")
        if mentions or message_kind == "mention":
            self._validate_mention_target(route, mentions)
        # Message ID, rather than a redelivered event ID, is the durable duplicate
        # key and stable correlation key. The delivery event ID remains attributed
        # in the returned normalization record.
        stored = self.service.receive_inbound(credential=credential, route=route_name, external_id=message_id,
                                              sender_id=sender_id, correlation_id=message_id, content=content,
                                              message_kind=message_kind, expected_scope=expected_scope)
        runtime_id = stored["runtime_id"]
        recipient_id = stored["recipient_id"]
        return InboundEvent(event_id, message_id, route_name, sender_id, message_id, content, mentions, voice,
                            runtime_id, recipient_id, message_kind)

    def _route_for_chat(self, chat_id: str) -> tuple[str, FeishuRoute]:
        matches = [(name, route) for name, route in self.config.routes.items() if route.chat_id == chat_id]
        if len(matches) != 1:
            raise FeishuTransportError("chat has no unique configured route")
        return matches[0]

    @staticmethod
    def _route_scope(route_name: str, route: FeishuRoute):
        runtime_id, recipient_id = FeishuSender._route_identity(route)
        return CommunicationScope(route_name, route.project_id, route.conversation_id,
                                  runtime_id=runtime_id, recipient_id=recipient_id)

    @staticmethod
    def _validate_mention_target(route: FeishuRoute, mentions: tuple[str, ...]) -> None:
        _runtime_id, expected_recipient = FeishuSender._route_identity(route)
        if not mentions:
            raise FeishuTransportError("mention target is absent")
        if len(set(mentions)) != 1:
            raise FeishuTransportError("mention target is ambiguous")
        identifier = mentions[0]
        target = route.mention_targets.get(identifier, identifier)
        allowed = {expected_recipient, f"project:{route.project_id}", "infrastructure-codex"}
        allowed.update(route.mention_targets.values())
        if target not in allowed or target != expected_recipient:
            raise FeishuTransportError("mention target is outside the configured recipient")

    @staticmethod
    def _message_kind(raw_kind: object) -> str:
        if raw_kind is None:
            return "discussion"
        if not isinstance(raw_kind, str) or raw_kind not in {"mention", "status", "discussion", "voice"}:
            raise FeishuTransportError("message kind is outside the communication boundary")
        return raw_kind

    @staticmethod
    def _mapping(value: object, name: str) -> Mapping[str, Any]:
        if not isinstance(value, Mapping):
            raise FeishuTransportError(f"{name} is invalid")
        return value

    @staticmethod
    def _text(value: object, name: str) -> str:
        if not isinstance(value, str) or not value:
            raise FeishuTransportError(f"{name} is invalid")
        return value

    def _text_content(self, encoded: object) -> str:
        try:
            value = json.loads(self._text(encoded, "text content"))
        except json.JSONDecodeError as error:
            raise FeishuTransportError("text content is not JSON") from error
        return self._text(value.get("text") if isinstance(value, Mapping) else None, "text")

    def _voice_file_key(self, encoded: object) -> str:
        try:
            value = json.loads(self._text(encoded, "voice content"))
        except json.JSONDecodeError as error:
            raise FeishuTransportError("voice content is not JSON") from error
        if not isinstance(value, Mapping):
            raise FeishuTransportError("voice content is invalid")
        return self._text(value.get("file_key") or value.get("file_key_id"), "voice file key")

    def _sender_id(self, sender: Mapping[str, Any]) -> str:
        sender_id = self._mapping(sender.get("sender_id"), "sender ID")
        for key in ("open_id", "user_id", "union_id"):
            value = sender_id.get(key)
            if isinstance(value, str) and value:
                return value
        raise FeishuTransportError("sender identity is absent")

    def _mentions(self, raw_mentions: object) -> tuple[str, ...]:
        if raw_mentions is None:
            return ()
        if not isinstance(raw_mentions, list):
            raise FeishuTransportError("mentions are invalid")
        identifiers = []
        for mention in raw_mentions:
            if not isinstance(mention, Mapping):
                raise FeishuTransportError("mention is invalid")
            mention_id = self._mapping(mention.get("id"), "mention ID")
            identifier = next((mention_id.get(key) for key in ("open_id", "user_id", "union_id")
                               if isinstance(mention_id.get(key), str) and mention_id[key]), None)
            if identifier is None:
                raise FeishuTransportError("mention identity is invalid")
            identifiers.append(identifier)
        return tuple(identifiers)
