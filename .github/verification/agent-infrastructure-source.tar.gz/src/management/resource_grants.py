"""Durable, fail-closed project resource reservations.

This is accounting only: it neither admits provider work nor unloads a model.
Provider release evidence records a reported release; it is not a physical-unload
claim. Callers authenticate actors before entering this pure core.
"""
from __future__ import annotations

import hashlib, json, math, sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterator, Mapping

from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


class ResourceGrantError(ValueError): pass
Clock = Callable[[], datetime]

def _ts(value: datetime) -> str:
    if value.tzinfo is None: raise ResourceGrantError("clock must be timezone-aware")
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
def _parse(value: str) -> datetime:
    try: result=datetime.fromisoformat(value.replace("Z","+00:00"))
    except (AttributeError,ValueError) as error: raise ResourceGrantError("observed_at must be RFC3339") from error
    if result.tzinfo is None: raise ResourceGrantError("observed_at must include timezone")
    return result.astimezone(timezone.utc)
def _canonical(value: Any) -> str: return json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False)

class ResourceGrants:
 def __init__(self,database:str|Path,*,clock:Clock|None=None,max_capacity_age_seconds:int=60):
  database_path=Path(database)
  try:
   state_root=validate_state_root(database_path.parent,"resource grant state root")
   self.database=validate_durable_leaf(database_path,state_root,label="resource grant database")
  except ManagementStateBoundaryError as error: raise ResourceGrantError(str(error)) from error
  if not isinstance(max_capacity_age_seconds,int) or isinstance(max_capacity_age_seconds,bool) or max_capacity_age_seconds<1: raise ResourceGrantError("max capacity age must be positive")
  self.clock=clock or (lambda:datetime.now(timezone.utc)); self.max_capacity_age_seconds=max_capacity_age_seconds; self._init()
 def report_capacity(self,pool_id:str,provider_id:str,hardware_node_id:str,quantities:Mapping[str,Any],observed_at:str)->None:
  self._ids(pool_id,provider_id,hardware_node_id); self._quantities(quantities); observed=_parse(observed_at); now=self.clock().astimezone(timezone.utc)
  if observed>now: raise ResourceGrantError("future capacity evidence is rejected")
  with self._conn() as c:
   c.execute("BEGIN IMMEDIATE"); old=c.execute("SELECT * FROM capacity WHERE pool_id=?",(pool_id,)).fetchone()
   if old and (old['provider_id']!=provider_id or old['hardware_node_id']!=hardware_node_id or observed<=_parse(old['observed_at'])): raise ResourceGrantError("capacity owner changed or sample is stale")
   c.execute("INSERT INTO capacity(pool_id,provider_id,hardware_node_id,quantities,observed_at) VALUES(?,?,?,?,?) ON CONFLICT(pool_id) DO UPDATE SET quantities=excluded.quantities,observed_at=excluded.observed_at",(pool_id,provider_id,hardware_node_id,_canonical(dict(quantities)),_ts(observed)))
 def grant(self,command_id:str,actor:str,actor_role:str,project_id:str,pool_id:str,quantities:Mapping[str,Any],*,expected_revision:int|None=None,loan_receipt:Mapping[str,Any]|None=None)->dict[str,Any]:
  self._command(command_id,actor); self._ids(project_id,pool_id); self._quantities(quantities)
  if actor_role not in {"human","codex"}: raise ResourceGrantError("only human or Codex may create a grant")
  if loan_receipt is not None and actor_role!='human': raise ResourceGrantError("only an authenticated human may approve a loan")
  request={"op":"grant","actor_role":actor_role,"project":project_id,"pool":pool_id,"q":dict(quantities),"expected":expected_revision,"loan":loan_receipt}
  def action(c):
   existing=c.execute("SELECT * FROM grants WHERE project_id=? AND pool_id=?",(project_id,pool_id)).fetchone()
   if existing and existing['loan_source']:
    old=json.loads(existing['quantities'])
    if any(quantities.get(k,0)>old.get(k,0) for k in quantities):
     raise ResourceGrantError("loan expansion requires a new human approval flow")
   return self._grant(c,project_id,pool_id,dict(quantities),expected_revision,loan_receipt)
  return self._mutate(command_id,actor,request,action)
 def resize(self,command_id:str,actor:str,actor_role:str,project_id:str,pool_id:str,quantities:Mapping[str,Any],*,expected_revision:int)->dict[str,Any]:
  self._command(command_id,actor); self._ids(project_id,pool_id); self._quantities(quantities)
  if actor_role not in {"human","codex","orchestrator"}: raise ResourceGrantError("invalid actor role")
  request={"op":"resize","actor_role":actor_role,"project":project_id,"pool":pool_id,"q":dict(quantities),"expected":expected_revision}
  def action(c):
   current=self._row(c,project_id,pool_id); self._revision(current,expected_revision)
   old=json.loads(current["quantities"])
   if current['loan_source'] and any(quantities.get(k,0)>old.get(k,0) for k in quantities): raise ResourceGrantError("loan expansion requires a new human approval flow")
   if actor_role not in {"human","codex","orchestrator"}: raise ResourceGrantError("invalid actor role")
   if actor_role=="orchestrator" and any(quantities.get(k,0)>old.get(k,0) for k in set(old)|set(quantities)): raise ResourceGrantError("orchestrator cannot expand a grant")
   return self._resize_existing(c,current,dict(quantities),reactivate=False)
  return self._mutate(command_id,actor,request,action)
 def release(self,command_id:str,actor:str,actor_role:str,project_id:str,pool_id:str,*,expected_revision:int,provider_release_evidence:str)->dict[str,Any]:
  self._command(command_id,actor); self._ids(project_id,pool_id)
  if actor_role not in {"human","codex","orchestrator"}: raise ResourceGrantError("invalid actor role")
  if not isinstance(provider_release_evidence,str) or not provider_release_evidence: raise ResourceGrantError("explicit provider release evidence is required")
  request={"op":"release","actor_role":actor_role,"project":project_id,"pool":pool_id,"expected":expected_revision,"evidence":provider_release_evidence}
  def action(c):
   row=self._row(c,project_id,pool_id); self._revision(row,expected_revision)
   if c.execute("SELECT 1 FROM loans WHERE source_project=? AND pool_id=? AND active=1",(project_id,pool_id)).fetchone(): raise ResourceGrantError("source grant cannot release while loans remain active")
   c.execute("UPDATE grants SET active=0,revision=revision+1,release_evidence=? WHERE project_id=? AND pool_id=?",(provider_release_evidence,project_id,pool_id))
   if row["loan_source"]: c.execute("UPDATE loans SET active=0,release_evidence=? WHERE target_project=? AND pool_id=?",(provider_release_evidence,project_id,pool_id))
   return self._snapshot(c,project_id,pool_id)
  return self._mutate(command_id,actor,request,action)
 def can_start(self,project_id:str,envelope:Mapping[str,Any])->bool:
  pool_id=envelope.get("pool_id"); quantities=envelope.get("quantities")
  try: self._quantities(quantities)
  except ResourceGrantError:return False
  with self._conn() as c:
   try: row=self._row(c,project_id,pool_id)
   except ResourceGrantError:return False
   if not row["active"] or not self._fresh_capacity(c,pool_id) or not self._physical_within_capacity(c,pool_id): return False
   granted=json.loads(row["quantities"]); outgoing=self._outgoing(c,project_id,pool_id)
   return all(quantities[k]<=granted.get(k,0)-outgoing.get(k,0) for k in quantities)
 def pool_projection(self,pool_id:str)->dict[str,Any]|None:
  """Return non-secret capacity ownership and freshness for composition checks."""
  self._ids(pool_id)
  with self._conn() as c:
   row=c.execute("SELECT provider_id,hardware_node_id,quantities,observed_at FROM capacity WHERE pool_id=?",(pool_id,)).fetchone()
   if row is None:return None
   return {"pool_id":pool_id,"provider_id":row["provider_id"],"hardware_node_id":row["hardware_node_id"],"quantities":json.loads(row["quantities"]),"observed_at":row["observed_at"],"fresh":self._fresh_capacity(c,pool_id)}
 def _grant(self,c,project,pool,q,expected,loan):
  existing=c.execute("SELECT * FROM grants WHERE project_id=? AND pool_id=?",(project,pool)).fetchone()
  if existing:
   if expected is None: raise ResourceGrantError("grant update requires expected revision")
   self._revision(existing,expected)
   if not existing['active'] and existing['loan_source']: raise ResourceGrantError("released loan cannot be reactivated without a new human approval flow")
   return self._resize_existing(c,existing,q,reactivate=not bool(existing['loan_source']))
  if expected is not None: raise ResourceGrantError("new grant cannot supply expected revision")
  source=None
  if loan is not None:
   if not isinstance(loan,Mapping) or not all(isinstance(loan.get(k),str) and loan[k] for k in ("approval_id","approved_actor","provider_handoff_evidence","source_project_id")): raise ResourceGrantError("cross-project loan requires an explicit human approval receipt and provider handoff evidence")
   source=loan["source_project_id"]
   if not self._fresh_capacity(c,pool) or not self._physical_within_capacity(c,pool): raise ResourceGrantError("fresh non-overcommitted capacity is required for a loan")
   self._loan_ok(c,source,pool,q)
  else: self._capacity_ok(c,pool,project,q,None)
  c.execute("INSERT INTO grants(project_id,pool_id,quantities,revision,active,loan_source,release_evidence) VALUES(?,?,?,1,1,?,NULL)",(project,pool,_canonical(q),source))
  if source: c.execute("INSERT INTO loans(source_project,target_project,pool_id,quantities,active,receipt,release_evidence) VALUES(?,?,?,?,1,?,NULL)",(source,project,pool,_canonical(q),_canonical(dict(loan))))
  return self._snapshot(c,project,pool)
 def project_grants(self,project_id:str)->list[dict[str,Any]]:
  if not isinstance(project_id,str) or not project_id: raise ResourceGrantError("project_id is required")
  with self._conn() as c:
   rows=c.execute("SELECT pool_id FROM grants WHERE project_id=? AND active=1 ORDER BY pool_id",(project_id,)).fetchall()
   return [self._snapshot(c,project_id,row["pool_id"]) for row in rows]
 def _resize_existing(self,c,row,q,*,reactivate):
  outgoing=self._outgoing(c,row['project_id'],row['pool_id'])
  if any(q.get(k,0)<outgoing.get(k,0) for k in outgoing): raise ResourceGrantError("source grant cannot shrink below outstanding loans")
  self._capacity_ok(c,row["pool_id"],row["project_id"],q,row["loan_source"]); c.execute("UPDATE grants SET quantities=?,revision=revision+1,active=?,release_evidence=? WHERE project_id=? AND pool_id=?",(_canonical(q),1 if reactivate else row['active'],None if reactivate else row['release_evidence'],row["project_id"],row["pool_id"]));
  if row['loan_source']: c.execute("UPDATE loans SET quantities=? WHERE target_project=? AND pool_id=?",(_canonical(q),row['project_id'],row['pool_id']))
  return self._snapshot(c,row["project_id"],row["pool_id"])
 def _capacity_ok(self,c,pool,project,q,loan_source):
  if not self._fresh_capacity(c,pool): raise ResourceGrantError("fresh measured capacity is required")
  if loan_source: return self._loan_ok(c,loan_source,pool,q,exclude_target=project)
  capacity=json.loads(c.execute("SELECT quantities FROM capacity WHERE pool_id=?",(pool,)).fetchone()[0]); used=self._regular_used(c,pool,exclude_project=project)
  if any(q[k]+used.get(k,0)>capacity.get(k,0) for k in q): raise ResourceGrantError("capacity would be oversubscribed")
 def _loan_ok(self,c,source,pool,q,exclude_target=None):
  row=self._row(c,source,pool)
  if not row["active"]: raise ResourceGrantError("loan source has no active grant")
  available=json.loads(row["quantities"]); out=self._outgoing(c,source,pool,exclude_target)
  if any(q[k]+out.get(k,0)>available.get(k,0) for k in q): raise ResourceGrantError("human loan exceeds source reservation")
 def _outgoing(self,c,project,pool,exclude_target=None):
  result={}
  for row in c.execute("SELECT target_project,quantities FROM loans WHERE source_project=? AND pool_id=? AND active=1",(project,pool)):
   if row['target_project']!=exclude_target:
    for k,v in json.loads(row["quantities"]).items(): result[k]=result.get(k,0)+v
  return result
 def _regular_used(self,c,pool,exclude_project=None):
  result={}
  for row in c.execute("SELECT project_id,quantities FROM grants WHERE pool_id=? AND active=1 AND loan_source IS NULL",(pool,)):
   if row['project_id']!=exclude_project:
    for k,v in json.loads(row['quantities']).items(): result[k]=result.get(k,0)+v
  return result
 def _fresh_capacity(self,c,pool):
  row=c.execute("SELECT observed_at FROM capacity WHERE pool_id=?",(pool,)).fetchone()
  return row is not None and 0 <= (self.clock().astimezone(timezone.utc)-_parse(row["observed_at"])).total_seconds() <= self.max_capacity_age_seconds
 def _physical_within_capacity(self,c,pool):
  row=c.execute("SELECT quantities FROM capacity WHERE pool_id=?",(pool,)).fetchone()
  if row is None:return False
  capacity=json.loads(row['quantities']); used=self._regular_used(c,pool)
  return all(used.get(k,0)<=capacity.get(k,0) for k in used)
 def _mutate(self,command,actor,request,action):
  digest=hashlib.sha256(_canonical(request).encode()).hexdigest()
  with self._conn() as c:
   c.execute("BEGIN IMMEDIATE"); old=c.execute("SELECT digest,result FROM commands WHERE command_id=? AND actor=?",(command,actor)).fetchone()
   if old:
    if old["digest"]!=digest: raise ResourceGrantError("idempotency command conflicts")
    return json.loads(old["result"])
   result=action(c); c.execute("INSERT INTO commands(command_id,actor,digest,result) VALUES(?,?,?,?)",(command,actor,digest,_canonical(result))); return result
 def _row(self,c,project,pool):
  row=c.execute("SELECT * FROM grants WHERE project_id=? AND pool_id=?",(project,pool)).fetchone()
  if row is None: raise ResourceGrantError("unknown grant")
  return row
 @staticmethod
 def _revision(row,expected):
  if not isinstance(expected,int) or isinstance(expected,bool) or row["revision"]!=expected: raise ResourceGrantError("grant revision is stale")
 def _snapshot(self,c,project,pool):
  row=self._row(c,project,pool); return {"project_id":project,"pool_id":pool,"quantities":json.loads(row["quantities"]),"revision":row["revision"],"active":bool(row["active"]),"loan_source_project_id":row["loan_source"],"release_evidence":row["release_evidence"]}
 @staticmethod
 def _command(command,actor):
  if not isinstance(command,str) or not command or not isinstance(actor,str) or not actor: raise ResourceGrantError("command and actor are required")
 @staticmethod
 def _ids(*values):
  if any(not isinstance(value,str) or not value or len(value)>128 for value in values): raise ResourceGrantError("pool/provider/hardware IDs are required and bounded")
 @staticmethod
 def _quantities(q):
  if not isinstance(q,Mapping) or not q: raise ResourceGrantError("named quantities are required")
  for name,value in q.items():
   if not isinstance(name,str) or not name or isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0: raise ResourceGrantError("quantities must be finite nonnegative named values")
 def _init(self):
  with self._conn() as c:c.executescript("CREATE TABLE IF NOT EXISTS capacity(pool_id TEXT PRIMARY KEY,provider_id TEXT NOT NULL,hardware_node_id TEXT NOT NULL,quantities TEXT NOT NULL,observed_at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS grants(project_id TEXT NOT NULL,pool_id TEXT NOT NULL,quantities TEXT NOT NULL,revision INTEGER NOT NULL,active INTEGER NOT NULL,loan_source TEXT,release_evidence TEXT,PRIMARY KEY(project_id,pool_id));CREATE TABLE IF NOT EXISTS loans(source_project TEXT,target_project TEXT,pool_id TEXT,quantities TEXT,active INTEGER,receipt TEXT,release_evidence TEXT,PRIMARY KEY(target_project,pool_id));CREATE TABLE IF NOT EXISTS commands(command_id TEXT,actor TEXT,digest TEXT,result TEXT,PRIMARY KEY(command_id,actor));")
 @contextmanager
 def _conn(self)->Iterator[sqlite3.Connection]:
  c=sqlite3.connect(self.database,timeout=10);c.row_factory=sqlite3.Row
  try:
   with c:yield c
  finally:c.close()
