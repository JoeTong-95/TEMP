"""Native Prefect pilot flow; Prefect owns run lifecycle, pause, and cancellation."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .fixture import FixtureService
from .pilot_runtime import invoke_configured_agent
from .pilot_store import PilotStore

try:
 from prefect import flow, task
 from prefect import runtime as prefect_runtime
 from prefect.flow_runs import pause_flow_run
except ImportError: PREFECT_AVAILABLE=False
else: PREFECT_AVAILABLE=True

class PilotFlowUnavailable(RuntimeError): pass

if PREFECT_AVAILABLE:
 @task(retries=0,persist_result=True,result_serializer='json',name='pilot-agent')
 def agent_task(project_id:str,request_id:str,model_ref:str,memory_ref:str,value:int)->dict[str,Any]:
  return invoke_configured_agent(project_id=project_id,request_id=request_id,model_ref=model_ref,memory_ref=memory_ref,value=value)
 @task(retries=0,persist_result=True,result_serializer='json',name='pilot-tool-fixture')
 def tool_task(root:str,project_id:str,request_id:str,value:int)->dict[str,Any]: return FixtureService(Path(root)/'fixture').execute(project_id,request_id,{'value':value})
 @task(retries=0,persist_result=True,result_serializer='json',name='pilot-condition')
 def condition_task(result:dict[str,Any])->bool: return int(result['output']['sum'])>0
 @task(retries=0,persist_result=True,result_serializer='json',name='pilot-artifact')
 def artifact_task(agent:dict[str,Any],tool:dict[str,Any])->dict[str,Any]:
  required={'artifact_reference','artifact_sha256','output'}
  if not required.issubset(tool): raise RuntimeError('protected tool result lacks artifact evidence')
  return {'artifact_reference':tool['artifact_reference'],'artifact_sha256':tool['artifact_sha256'],'output':tool['output'],'agent_runtime_kind':agent['runtime_kind'],'native_session_ref':agent.get('native_session_ref'),'evidence_ref':agent.get('evidence_ref')}
 @flow(name='agent-stack-pilot-v1',retries=0,persist_result=True,result_serializer='json',validate_parameters=False)
 def pilot_flow(root:str,control_db:str,project_id:str,request_id:str,model_ref:str,memory_ref:str,value:int,approval_scope:str)->dict[str,Any]:
  agent=agent_task(project_id,request_id,model_ref,memory_ref,value)
  tool=tool_task(root,project_id,request_id,value)
  approved=condition_task(tool)
  if approved:
   # Agent request finished before this call, so no model capacity is retained
   # while Prefect pauses. Resume/cancel remains native Prefect state.
   pause_flow_run(wait_for_input=None,timeout=3600)
   flow_run_id=str(prefect_runtime.flow_run.id)
   if not PilotStore(control_db).approved(flow_run_id,approval_scope):
    raise RuntimeError('native run resumed without a server-recorded approval')
   artifact=artifact_task(agent,tool)
  else:
   artifact={'not_created':'condition_false'}
  return {'runtime_kind':'prefect','prefect_flow_run_id':str(prefect_runtime.flow_run.id),'agent':agent,'tool':tool,'condition':approved,'approval_scope':approval_scope,'artifact':artifact}
else:
 def pilot_flow(*args:Any,**kwargs:Any)->dict[str,Any]: raise PilotFlowUnavailable('prefect==3.8.5 is required for pilot execution')
