"""Crash-safe Management control journal for configured Hermes sessions."""
from __future__ import annotations
import hashlib,json,os,re,sqlite3
from contextlib import closing
from pathlib import Path
from typing import Any,Mapping
from shared.contracts.agent_runtime import RuntimeClient,RuntimeClientError,RuntimeOutcomeUnknown
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root
_SAFE=re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
class ManagementRuntimeControlError(ValueError):pass
class ManagementRuntimeControl:
 def __init__(self,database:Path,runtime:RuntimeClient,bindings:Mapping[str,Mapping[str,str]],*,state_root:Path|None=None):
  self.runtime=runtime;self.bindings={p:dict(v) for p,v in bindings.items()}
  try:
   database_path=Path(database)
   self.database=validate_durable_leaf(database_path,validate_state_root(state_root if state_root is not None else database_path.parent,"runtime control state root"),label="runtime control database")
  except (ManagementStateBoundaryError,TypeError) as error:
   raise ManagementRuntimeControlError("safe control journal is required") from error
  if not self.bindings:raise ManagementRuntimeControlError("safe control journal is required")
  c=sqlite3.connect(self.database)
  try:c.execute("CREATE TABLE IF NOT EXISTS runtime_control_ops(project_id TEXT,session_id TEXT,operation_id TEXT,kind TEXT,fingerprint TEXT,state TEXT,step TEXT,receipt TEXT,PRIMARY KEY(project_id,session_id,operation_id))");c.commit()
  finally:c.close()
  if os.name=="posix" and self.database.exists():os.chmod(self.database,0o600)
 def status(self,p:str,s:str)->dict[str,Any]:return self.runtime.status(self._binding(p,s))
 def get(self,p:str,s:str,op:str)->dict[str,Any]:
  with closing(sqlite3.connect(self.database)) as c:r=c.execute("SELECT kind,fingerprint,state,step,receipt FROM runtime_control_ops WHERE project_id=? AND session_id=? AND operation_id=?",(p,s,op)).fetchone()
  if not r:raise ManagementRuntimeControlError("unknown runtime control operation")
  return {"project_id":p,"session_id":s,"operation_id":op,"kind":r[0],"fingerprint":r[1],"state":r[2],"step":r[3],"receipt":json.loads(r[4]) if r[4] else None}
 def command(self,p:str,s:str,kind:str,op:str,*,target_binding:str|None=None,expected_revision:int|None=None)->dict[str,Any]:
  if kind not in {"pause","drain","checkpoint","resume","binding"} or not all(isinstance(x,str) and _SAFE.fullmatch(x) for x in (p,s,op)):raise ManagementRuntimeControlError("runtime command is invalid")
  self._binding(p,s);fp=hashlib.sha256(json.dumps({"kind":kind,"target_binding":target_binding,"expected_revision":expected_revision},sort_keys=True,separators=(",",":")).encode()).hexdigest()
  with closing(sqlite3.connect(self.database)) as c, c:
   c.execute("BEGIN IMMEDIATE");row=c.execute("SELECT fingerprint,state FROM runtime_control_ops WHERE project_id=? AND session_id=? AND operation_id=?",(p,s,op)).fetchone()
   if row:
    if row[0]!=fp:raise ManagementRuntimeControlError("operation identity conflicts")
    existing=True
   else:
    existing=False;c.execute("INSERT INTO runtime_control_ops VALUES(?,?,?,?,?,'prepared',?,NULL)",(p,s,op,kind,fp,"pause" if kind=="drain" else kind))
  if existing:return self.get(p,s,op) # prepared/unknown are intentionally never replayed
  return self._effect(p,s,op,target_binding,expected_revision)
 def reconcile(self,p:str,s:str,op:str)->dict[str,Any]:
  value=self.get(p,s,op)
  if value["state"]!="unknown":return value
  # Read-only status is evidence only: it may complete pause/resume, but cannot
  # prove checkpoint or binding POST completion, which remain quarantined.
  observed=self.status(p,s).get("state");kind=value["kind"]
  if (kind=="pause" and observed=="paused") or (kind=="resume" and observed=="idle"):
   return self._finish(p,s,op,"completed",{"observed_state":observed,"reconciled":True})
  return value
 def _effect(self,p,s,op,target,revision):
  value=self.get(p,s,op);binding=self._binding(p,s)
  try:
   if value["kind"]=="pause":receipt=self.runtime.pause(binding)
   elif value["kind"]=="resume":receipt=self.runtime.resume(binding)
   elif value["kind"]=="checkpoint":receipt=self.runtime.checkpoint(binding)
   elif value["kind"]=="binding":
    if not isinstance(target,str) or type(revision)is not int:raise ManagementRuntimeControlError("binding target and revision are required")
    receipt=self.runtime.update_binding(binding,new_binding_id=target,operation_id=op,expected_revision=revision)
   else:
    pause=self.runtime.pause(binding);self._step(p,s,op,"checkpoint",pause);checkpoint=self.runtime.checkpoint(binding);receipt={"pause":pause,"checkpoint":checkpoint}
   return self._finish(p,s,op,"completed",receipt)
  except RuntimeOutcomeUnknown:
   # A drain checkpoint is a second side effect.  Preserve the proven pause
   # step but quarantine the operation: paused status cannot prove a checkpoint.
   prior=self.get(p,s,op).get("receipt")
   return self._finish(p,s,op,"unknown",prior)
  except RuntimeClientError as e:return self._finish(p,s,op,"rejected",{"error":"runtime rejected command"})
 def _step(self,p,s,op,step,receipt):
  with closing(sqlite3.connect(self.database)) as c, c:c.execute("UPDATE runtime_control_ops SET step=?,receipt=? WHERE project_id=? AND session_id=? AND operation_id=?",(step,json.dumps(receipt,separators=(",",":")),p,s,op))
 def _finish(self,p,s,op,state,receipt):
  with closing(sqlite3.connect(self.database)) as c, c:c.execute("UPDATE runtime_control_ops SET state=?,receipt=? WHERE project_id=? AND session_id=? AND operation_id=?",(state,json.dumps(receipt,separators=(",",":")) if receipt is not None else None,p,s,op))
  return self.get(p,s,op)
 def _binding(self,p,s):
  value=self.bindings.get(p,{}).get(s)
  if not value:raise ManagementRuntimeControlError("runtime session is not configured for project")
  return value
