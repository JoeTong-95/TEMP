"""Management-owned catalog admission derived from durable project grants."""
from __future__ import annotations
from typing import Any,Mapping
from .model_capability_catalog import ModelCapabilityCatalog,CatalogError,CatalogConflict
from .resource_grants import ResourceGrants
from .provider_registry import ProviderRegistry,ProviderRegistryError
class CatalogAdmissionError(ValueError):pass
class CatalogAdmission:
 def __init__(self,catalog:ModelCapabilityCatalog,grants:ResourceGrants,providers:ProviderRegistry):self.catalog,self.grants,self.providers=catalog,grants,providers
 def _readiness(self,entry):
  evidence=entry.get('availability',{}) if isinstance(entry,Mapping) else {}
  provider_id=evidence.get('provider_id') if isinstance(evidence,Mapping) else None
  if not isinstance(provider_id,str):return {'eligible':False,'reasons':['provider_not_registered'],'unavailable_dependency':provider_id}
  provider=self.providers.get(provider_id)
  if provider is None or provider.get('generation')!=evidence.get('generation'):
   return {'eligible':False,'reasons':['provider_generation_stale'],'unavailable_dependency':provider_id}
  if provider.get('role')!='inference':
   return {'eligible':False,'reasons':['provider_role_mismatch'],'unavailable_dependency':provider_id}
  declared=evidence.get('capability') if isinstance(evidence,Mapping) else None
  if declared is None:
   capabilities=provider.get('manifest',{}).get('capabilities',[]) if isinstance(provider.get('manifest'),Mapping) else []
   inference_capabilities=[value for value in capabilities if isinstance(value,str) and value.startswith('inference.')]
   if len(inference_capabilities)!=1:
    return {'eligible':False,'reasons':['inference_capability_undeclared'],'unavailable_dependency':provider_id}
   declared=inference_capabilities[0]
  if not isinstance(declared,str) or not declared.startswith('inference.'):
   return {'eligible':False,'reasons':['inference_capability_invalid'],'unavailable_dependency':provider_id}
  required=[declared]
  return self.providers.readiness(provider_id, required)
 def _live(self,entry):
  return self._readiness(entry).get('eligible') is True
 def _ready_entries(self,project_id:str,model_id:str|None=None,revision:str|None=None):
  entries=self.catalog.list_current(project_id,self._grant(project_id))
  selected=[]
  for entry in entries:
   if model_id is not None and (entry.get('model_id')!=model_id or entry.get('revision')!=revision):continue
   readiness=self._readiness(entry)
   if readiness.get('eligible') is True:selected.append((entry,readiness))
  return selected
 def _grant(self,project_id:str)->dict[str,float]:
  values={}
  for grant in self.grants.project_grants(project_id):
   for name,value in grant['quantities'].items():values[name]=values.get(name,0)+value
  return values
 def list_current(self,project_id:str)->list[dict[str,Any]]:
  return [entry for entry,_ in self._ready_entries(project_id)]
 def admit(self,project_id:str,idempotency_key:str,model_id:str,revision:str)->dict[str,Any]:
  try:
   grant=self._grant(project_id)
   replayed=self.catalog.replay_admission(project_id,idempotency_key,model_id,revision,grant)
   if replayed is not None:return replayed
   ready=self._ready_entries(project_id,model_id,revision)
   entries=[entry for entry,_ in ready]
   if not entries:
    return self.catalog.record_admission(project_id,idempotency_key,model_id,revision,grant,{'state':'requires_additional_resources','reason':'provider_unavailable','unavailable_dependency':'provider'})
   selected_entry=entries[0]
   selected=selected_entry['availability']
   reservation=self.providers.reserve_generation(selected['provider_id'],selected['generation'])
   try:
    result=self.catalog.admit(project_id,idempotency_key,model_id,revision,grant,selected_provider_id=selected['provider_id'],selected_generation=selected['generation'],provider_generation_check=lambda provider_id,generation: self._selected_provider_ready(selected_entry,provider_id,generation))
   finally:
    try:self.providers.release_generation(reservation)
    except ProviderRegistryError:pass
   if result.get('state')=='admitted':
    result['provider_id']=selected['provider_id'];result['provider_generation']=selected['generation']
   return result
  except CatalogConflict as error:raise CatalogAdmissionError(str(error)) from error
  except ProviderRegistryError as error:raise CatalogAdmissionError('provider generation changed during admission') from error
  except CatalogError as error:raise CatalogAdmissionError('catalog admission rejected') from error
 def _selected_provider_ready(self,entry,provider_id,generation):
  availability=entry.get('availability',{}) if isinstance(entry,Mapping) else {}
  expected=availability.get('provider_id') if isinstance(availability,Mapping) else None
  expected_generation=availability.get('generation') if isinstance(availability,Mapping) else None
  return provider_id==expected and generation==expected_generation and self._readiness(entry).get('eligible') is True
 def release(self,project_id:str,model_id:str,revision:str,receipt:Mapping[str,Any])->dict[str,Any]:
  try:
   provider=self.providers.get(receipt.get('provider_id')) if isinstance(receipt,Mapping) else None
   if not provider or provider.get('revoked') or provider.get('generation')!=receipt.get('generation') or not isinstance(provider.get('health'),Mapping) or provider['health'].get('status')!='healthy':raise CatalogAdmissionError('provider generation is not live')
   return self.catalog.release(model_id,revision,project_id,receipt)
  except CatalogError as error:raise CatalogAdmissionError('catalog release rejected') from error
 def physical_unload(self,model_id:str,revision:str,receipt)->dict[str,Any]:
  try:
   provider=self.providers.get(receipt.get('provider_id')) if isinstance(receipt,Mapping) else None
   if not provider or provider.get('revoked') or provider.get('generation')!=receipt.get('generation') or not isinstance(provider.get('health'),Mapping) or provider['health'].get('status')!='healthy':raise CatalogAdmissionError('provider generation is not live')
   return self.catalog.physical_unload(model_id,revision,receipt)
  except CatalogError as error:raise CatalogAdmissionError('physical unload rejected') from error
 def claim_physical_unload(self,model_id:str,revision:str,operation_id:str,provider_id:str,generation:int)->dict[str,Any]:
  try:
   provider=self.providers.get(provider_id)
   if not provider or provider.get('revoked') or provider.get('generation')!=generation or not isinstance(provider.get('health'),Mapping) or provider['health'].get('status')!='healthy':raise CatalogAdmissionError('provider generation is not live')
   return self.catalog.claim_physical_unload(model_id,revision,operation_id,provider_id,generation)
  except CatalogError as error:raise CatalogAdmissionError('physical unload claim rejected') from error
