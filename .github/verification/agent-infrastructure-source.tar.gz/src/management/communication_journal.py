"""Durable, scoped communication inbox/outbox journal.

This module intentionally has no transport, Feishu, tenant, agent, command, or
approval implementation. Inbound text is evidence for Management; it grants no authority.
"""
from __future__ import annotations

import base64
import json
import math
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterator, Mapping
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


class CommunicationJournalError(ValueError):
    """A caller supplied an invalid or inaccessible journal operation."""


_PUBLIC_MESSAGE_KINDS = frozenset({"mention", "status", "discussion", "voice"})
_UNSET = object()


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _stamp(value: datetime) -> str:
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


class CommunicationJournal:
    """A small SQLite inbox/outbox, scoped on every public operation."""

    def __init__(self, path: str | Path):
        journal_path = Path(path)
        try:
            state_root = validate_state_root(journal_path.parent, "communication journal state root")
            self.path = validate_durable_leaf(journal_path, state_root, label="communication journal database")
        except ManagementStateBoundaryError as error:
            raise CommunicationJournalError(str(error)) from error
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            try:
                database.execute(
                    """CREATE TABLE IF NOT EXISTS messages (
                        kind TEXT NOT NULL, external_id TEXT NOT NULL, route TEXT NOT NULL,
                        sender TEXT, project_id TEXT NOT NULL, conversation_id TEXT NOT NULL,
                        runtime_id TEXT, recipient_id TEXT,
                        message_kind TEXT NOT NULL DEFAULT 'discussion',
                        transport_uuid_version INTEGER NOT NULL DEFAULT 2,
                        correlation_id TEXT NOT NULL, content TEXT NOT NULL, state TEXT NOT NULL,
                        claimant TEXT, claim_token TEXT, claim_generation INTEGER NOT NULL DEFAULT 0,
                        lease_until TEXT, created_at TEXT NOT NULL,
                        PRIMARY KEY (kind, route, external_id)
                    )"""
                )
                database.execute(
                    """CREATE TABLE IF NOT EXISTS repair_outcomes (
                        idempotency_key TEXT PRIMARY KEY, schema TEXT NOT NULL,
                        operation_id TEXT NOT NULL, project_id TEXT NOT NULL,
                        service_id TEXT NOT NULL, action_id TEXT NOT NULL,
                        correlation_id TEXT NOT NULL, status TEXT NOT NULL,
                        reason TEXT NOT NULL, effect_evidence TEXT NOT NULL,
                        health_evidence TEXT NOT NULL, created_at TEXT NOT NULL,
                        completed_at TEXT NOT NULL, route TEXT NOT NULL,
                        conversation_id TEXT NOT NULL, runtime_id TEXT NOT NULL,
                        recipient_id TEXT NOT NULL
                    )"""
                )
                # Re-read the schema only after BEGIN IMMEDIATE has serialized
                # this migration with every other journal constructor. A
                # second constructor therefore sees the committed result and
                # never races a duplicate ALTER TABLE operation.
                columns = {row["name"] for row in database.execute("PRAGMA table_info(messages)")}
                transport_uuid_version_was_missing = "transport_uuid_version" not in columns
                for name, declaration in (("runtime_id", "TEXT"), ("recipient_id", "TEXT"),
                                          # A pre-kind journal cannot truthfully be
                                          # classified during schema migration. Keep
                                          # those rows NULL until their authenticated
                                          # callback supplies the effective kind.
                                          ("message_kind", "TEXT"),
                                          ("transport_uuid_version", "INTEGER")):
                    if name not in columns:
                        database.execute(f"ALTER TABLE messages ADD COLUMN {name} {declaration}")
                        columns.add(name)
                # Rows without persisted identities are unambiguously from the
                # pre-identity schema and retain the old transport key. Rows
                # with both identities already present are ambiguous: the
                # scoped implementation also wrote this schema before the UUID
                # version column existed, so selecting v1 or v2 could replay a
                # lost acknowledgement under a different Feishu UUID. Leave
                # those rows unbound and let _bind_existing fail closed until
                # an authoritative version is recorded.
                if transport_uuid_version_was_missing:
                    database.execute(
                        "UPDATE messages SET transport_uuid_version=1 "
                        "WHERE transport_uuid_version IS NULL "
                        "AND runtime_id IS NULL AND recipient_id IS NULL"
                    )
                # Outbound rows have no callback that can derive a kind. Their
                # pre-kind schema semantics were the public discussion default, so
                # retain that effective kind before a strict sender reads them.
                database.execute(
                    "UPDATE messages SET message_kind='discussion' "
                    "WHERE kind='outbox' AND message_kind IS NULL"
                )
                database.execute("COMMIT")
            except BaseException:
                # Explicit rollback makes a failed/interrupted migration safe
                # to retry from its original schema and data. Preserve the
                # original interruption even if rollback itself is unavailable.
                if database.in_transaction:
                    try:
                        database.execute("ROLLBACK")
                    except BaseException:
                        pass
                raise

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        database = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        try:
            database.row_factory = sqlite3.Row
            database.execute("PRAGMA busy_timeout = 10000")
            yield database
        finally:
            database.close()

    @staticmethod
    def _required_text(**values: object) -> None:
        if not all(isinstance(value, str) and value for value in values.values()):
            raise CommunicationJournalError("required text is invalid")

    def _scope(self, routes: Mapping[str, Mapping[str, str]], route: str,
               project_id: str, conversation_id: str, runtime_id: str | None = None,
               recipient_id: str | None = None) -> tuple[str, str]:
        self._required_text(route=route, project_id=project_id, conversation_id=conversation_id)
        item = routes.get(route)
        if (not isinstance(item, Mapping) or item.get("project_id") != project_id
                or item.get("conversation_id") != conversation_id):
            raise CommunicationJournalError("route scope denied")
        configured_runtime = item.get("runtime_id")
        configured_recipient = item.get("recipient_id")
        if (configured_runtime is None) != (configured_recipient is None):
            raise CommunicationJournalError("route identities must be paired")
        if (runtime_id is None) != (recipient_id is None):
            raise CommunicationJournalError("runtime and recipient identities must be paired")
        if configured_runtime is None:
            configured_runtime = f"runtime:{project_id}"
            configured_recipient = f"project:{project_id}"
        self._required_text(runtime_id=configured_runtime, recipient_id=configured_recipient)
        if ((runtime_id is not None and runtime_id != configured_runtime)
                or (recipient_id is not None and recipient_id != configured_recipient)):
            raise CommunicationJournalError("route scope denied")
        return configured_runtime, configured_recipient

    def inbound(self, *, external_id: str, route: str, sender: str, project_id: str,
                conversation_id: str, correlation_id: str, content: str,
                routes: Mapping[str, Mapping[str, str]], runtime_id: str | None = None,
                recipient_id: str | None = None, message_kind: str = "discussion") -> dict[str, Any]:
        runtime_id, recipient_id = self._scope(
            routes, route, project_id, conversation_id, runtime_id, recipient_id,
        )
        self._required_text(external_id=external_id, sender=sender, correlation_id=correlation_id, content=content)
        if message_kind not in _PUBLIC_MESSAGE_KINDS:
            raise CommunicationJournalError("message kind is outside the communication boundary")
        return self._insert("inbox", external_id, route, sender, project_id, conversation_id,
                            runtime_id, recipient_id, message_kind, correlation_id, content, "received")

    def outbox(self, *, external_id: str, route: str, project_id: str,
               conversation_id: str, correlation_id: str, content: str,
                routes: Mapping[str, Mapping[str, str]], runtime_id: str | None = None,
                recipient_id: str | None = None, message_kind: str = "discussion",
                sender: str | None = None) -> dict[str, Any]:
        runtime_id, recipient_id = self._scope(
            routes, route, project_id, conversation_id, runtime_id, recipient_id,
        )
        self._required_text(external_id=external_id, correlation_id=correlation_id, content=content)
        if sender is not None:
            self._required_text(sender=sender)
        if message_kind not in _PUBLIC_MESSAGE_KINDS:
            raise CommunicationJournalError("message kind is outside the communication boundary")
        return self._insert("outbox", external_id, route, sender, project_id, conversation_id,
                            runtime_id, recipient_id, message_kind, correlation_id, content, "pending")

    @staticmethod
    def _conflict() -> CommunicationJournalError:
        return CommunicationJournalError("external message conflict")

    def _bind_existing(
        self,
        database: sqlite3.Connection,
        *,
        kind: str,
        external_id: str,
        route: str,
        project_id: str,
        conversation_id: str,
        runtime_id: str,
        recipient_id: str,
        correlation_id: object = _UNSET,
        content: object = _UNSET,
        message_kind: object = _UNSET,
        sender: object = _UNSET,
    ) -> sqlite3.Row | None:
        """Validate and, when safe, bind one pre-identity row in this transaction.

        Legacy identity columns stay NULL until an operation has authenticated and
        resolved the exact route.  The immutable journal fields are checked before
        either identity or sender is filled, so a replay cannot turn a NULL into a
        cross-scope wildcard.
        """
        row = database.execute(
            """SELECT kind, route, external_id, sender, project_id, conversation_id,
                      runtime_id, recipient_id, message_kind, correlation_id, content,
                      state, claimant, claim_token, claim_generation, lease_until,
                      transport_uuid_version
               FROM messages WHERE kind=? AND route=? AND external_id=?""",
            (kind, route, external_id),
        ).fetchone()
        if row is None:
            return None
        if row["project_id"] != project_id or row["conversation_id"] != conversation_id:
            raise self._conflict()
        row_has_runtime = row["runtime_id"] is not None
        row_has_recipient = row["recipient_id"] is not None
        if row_has_runtime != row_has_recipient:
            raise self._conflict()
        version = row["transport_uuid_version"]
        if (isinstance(version, bool) or not isinstance(version, int)
                or version not in (1, 2)):
            raise self._conflict()
        # A scoped UUID requires both identities.  A legacy row may be bound
        # to the authoritative pair during its first authenticated replay,
        # but it must continue using its pre-upgrade (v1) transport key.
        if not row_has_runtime and version != 1:
            raise self._conflict()
        updates: dict[str, object] = {}
        for name, expected in (
            ("correlation_id", correlation_id),
            ("content", content),
        ):
            if expected is not _UNSET and row[name] != expected:
                raise self._conflict()
        if message_kind is not _UNSET:
            if row["message_kind"] is None:
                # The old schema had no message-kind field. The first
                # authenticated replay derives its effective kind; subsequent
                # callbacks remain subject to immutable payload checks.
                updates["message_kind"] = message_kind
            elif row["message_kind"] != message_kind:
                raise self._conflict()
        for name, expected in (("runtime_id", runtime_id), ("recipient_id", recipient_id)):
            if row[name] is not None and row[name] != expected:
                raise self._conflict()

        if not row_has_runtime:
            updates["runtime_id"] = runtime_id
            updates["recipient_id"] = recipient_id

        if sender is not _UNSET:
            if kind == "inbox":
                if row["sender"] != sender:
                    raise self._conflict()
            elif kind == "outbox":
                if row["sender"] is None:
                    if sender is not None:
                        updates["sender"] = sender
                elif sender is None or row["sender"] != sender:
                    raise self._conflict()

        if updates:
            assignments = ", ".join(f"{name}=?" for name in updates)
            database.execute(
                f"UPDATE messages SET {assignments} WHERE kind=? AND route=? AND external_id=?",
                (*updates.values(), kind, route, external_id),
            )
            row = database.execute(
                """SELECT kind, route, external_id, sender, project_id, conversation_id,
                          runtime_id, recipient_id, message_kind, correlation_id, content,
                          state, claimant, claim_token, claim_generation, lease_until,
                          transport_uuid_version
                   FROM messages WHERE kind=? AND route=? AND external_id=?""",
                (kind, route, external_id),
            ).fetchone()
        return row

    def _insert(self, kind: str, external_id: str, route: str, sender: str | None,
                project_id: str, conversation_id: str, runtime_id: str,
                recipient_id: str, message_kind: str, correlation_id: str,
                content: str, state: str) -> dict[str, Any]:
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            try:
                existing = self._bind_existing(
                    database, kind=kind, external_id=external_id, route=route,
                    project_id=project_id, conversation_id=conversation_id,
                    runtime_id=runtime_id, recipient_id=recipient_id,
                    correlation_id=correlation_id, content=content,
                    message_kind=message_kind, sender=sender,
                )
                if existing is not None:
                    database.execute("COMMIT")
                    return {"state": existing["state"], "duplicate": True}
                database.execute(
                    """INSERT INTO messages (kind, external_id, route, sender, project_id, conversation_id,
                       runtime_id, recipient_id, message_kind, transport_uuid_version,
                       correlation_id, content, state, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 2, ?, ?, ?, ?)""",
                    (kind, external_id, route, sender, project_id, conversation_id, runtime_id,
                     recipient_id, message_kind, correlation_id, content, state, _stamp(_now())),
                )
                database.execute("COMMIT")
            except CommunicationJournalError:
                database.execute("ROLLBACK")
                raise
            except sqlite3.IntegrityError as error:
                database.execute("ROLLBACK")
                raise self._conflict() from error
        return {"state": state, "duplicate": False}

    def claim_outbox(self, *, external_id: str, route: str, project_id: str,
                     conversation_id: str, routes: Mapping[str, Mapping[str, str]], claimant: str,
                     lease_seconds: int | float = 30, runtime_id: str | None = None,
                     recipient_id: str | None = None, sender: str | None = None) -> dict[str, Any] | None:
        runtime_id, recipient_id = self._scope(
            routes, route, project_id, conversation_id, runtime_id, recipient_id,
        )
        self._required_text(external_id=external_id, claimant=claimant)
        if sender is not None:
            self._required_text(sender=sender)
        if (isinstance(lease_seconds, bool) or not isinstance(lease_seconds, (int, float))
                or not math.isfinite(lease_seconds) or int(lease_seconds) != lease_seconds or not 1 <= lease_seconds <= 300):
            raise CommunicationJournalError("lease must be a finite whole number from 1 through 300")
        now = _now()
        token = uuid.uuid4().hex
        lease_until = _stamp(now + timedelta(seconds=lease_seconds))
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            row = self._bind_existing(
                database, kind="outbox", external_id=external_id, route=route,
                project_id=project_id, conversation_id=conversation_id,
                runtime_id=runtime_id, recipient_id=recipient_id,
                sender=sender if sender is not None else _UNSET,
            )
            if row is None:
                database.execute("ROLLBACK")
                raise CommunicationJournalError("unknown outbox")
            if row["state"] == "sending" and row["lease_until"] and row["lease_until"] <= _stamp(now):
                database.execute(
                    """UPDATE messages SET state='unknown', lease_until=NULL WHERE kind='outbox' AND route=?
                       AND external_id=? AND project_id=? AND conversation_id=?
                       AND runtime_id=? AND recipient_id=? AND state='sending'""",
                    (route, external_id, project_id, conversation_id, runtime_id, recipient_id),
                )
                database.execute("COMMIT")
                return None
            if row["state"] != "pending":
                database.execute("ROLLBACK")
                return None
            generation = row["claim_generation"] + 1
            updated = database.execute(
                """UPDATE messages SET state='sending', claimant=?, claim_token=?, claim_generation=?, lease_until=?
                   WHERE kind='outbox' AND route=? AND external_id=? AND project_id=? AND conversation_id=?
                     AND runtime_id=? AND recipient_id=? AND state='pending'""",
                (claimant, token, generation, lease_until, route, external_id, project_id,
                 conversation_id, runtime_id, recipient_id),
            ).rowcount
            database.execute("COMMIT")
        if updated != 1:
            return None
        return {"external_id": external_id, "claim_token": token, "claim_generation": generation, "lease_until": lease_until}

    def outcome(self, *, external_id: str, route: str, project_id: str, conversation_id: str,
                routes: Mapping[str, Mapping[str, str]], claimant: str, claim_token: str, state: str,
                runtime_id: str | None = None, recipient_id: str | None = None) -> None:
        runtime_id, recipient_id = self._scope(
            routes, route, project_id, conversation_id, runtime_id, recipient_id,
        )
        self._required_text(external_id=external_id, claimant=claimant, claim_token=claim_token)
        if state not in {"delivered", "unknown"}:
            raise CommunicationJournalError("outcome must be delivered or unknown")
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            row = self._bind_existing(
                database, kind="outbox", external_id=external_id, route=route,
                project_id=project_id, conversation_id=conversation_id,
                runtime_id=runtime_id, recipient_id=recipient_id,
            )
            if row is None:
                database.execute("ROLLBACK")
                raise CommunicationJournalError("claim lost")
            # A timed-out submission is ambiguous even if no other worker has
            # subsequently attempted a claim. It belongs to reconciliation.
            database.execute(
                """UPDATE messages SET state='unknown', lease_until=NULL WHERE kind='outbox' AND route=?
                   AND external_id=? AND project_id=? AND conversation_id=? AND state='sending'
                     AND runtime_id=? AND recipient_id=?
                     AND lease_until IS NOT NULL AND lease_until <= ?""",
                (route, external_id, project_id, conversation_id, runtime_id, recipient_id, _stamp(_now())),
            )
            updated = database.execute(
                """UPDATE messages SET state=?, lease_until=NULL WHERE kind='outbox' AND route=? AND external_id=?
                   AND project_id=? AND conversation_id=? AND runtime_id=? AND recipient_id=?
                   AND claimant=? AND claim_token=? AND state='sending'""",
                (state, route, external_id, project_id, conversation_id, runtime_id, recipient_id,
                 claimant, claim_token),
            ).rowcount
            database.execute("COMMIT")
        if updated != 1:
            raise CommunicationJournalError("claim lost")

    def get(self, *, kind: str, external_id: str, route: str, project_id: str,
            conversation_id: str, routes: Mapping[str, Mapping[str, str]], runtime_id: str | None = None,
            recipient_id: str | None = None) -> dict[str, Any]:
        runtime_id, recipient_id = self._scope(
            routes, route, project_id, conversation_id, runtime_id, recipient_id,
        )
        if kind not in {"inbox", "outbox"}:
            raise CommunicationJournalError("invalid message kind")
        self._required_text(external_id=external_id)
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            row = self._bind_existing(
                database, kind=kind, external_id=external_id, route=route,
                project_id=project_id, conversation_id=conversation_id,
                runtime_id=runtime_id, recipient_id=recipient_id,
            )
            if row is not None:
                database.execute("COMMIT")
            else:
                database.execute("ROLLBACK")
        if row is None:
            raise CommunicationJournalError("message absent")
        return {
            "route": row["route"], "sender": row["sender"],
            "project_id": row["project_id"], "conversation_id": row["conversation_id"],
            "runtime_id": row["runtime_id"], "recipient_id": row["recipient_id"],
            "message_kind": row["message_kind"], "correlation_id": row["correlation_id"],
            "content": row["content"], "state": row["state"],
            "transport_uuid_version": row["transport_uuid_version"],
        }

    def repair_outcome(self, *, idempotency_key: str, operation_id: str,
                       project_id: str, service_id: str, action_id: str,
                       correlation_id: str, status: str, reason: str,
                       effect_evidence: Mapping[str, Any],
                       health_evidence: Mapping[str, Any], route: str,
                       conversation_id: str, runtime_id: str,
                       recipient_id: str) -> dict[str, Any]:
        """Insert one immutable scoped repair outcome or return its replay."""
        self._required_text(idempotency_key=idempotency_key, operation_id=operation_id,
                            project_id=project_id, service_id=service_id,
                            action_id=action_id, correlation_id=correlation_id,
                            reason=reason, route=route,
                            conversation_id=conversation_id, runtime_id=runtime_id,
                            recipient_id=recipient_id)
        if status not in {"succeeded", "rejected", "failed", "unknown"}:
            raise CommunicationJournalError("repair outcome status is invalid")
        if not isinstance(effect_evidence, Mapping) or not isinstance(health_evidence, Mapping):
            raise CommunicationJournalError("repair evidence is invalid")
        self._scope({route: {"project_id": project_id, "conversation_id": conversation_id,
                             "runtime_id": runtime_id, "recipient_id": recipient_id}},
                    route, project_id, conversation_id, runtime_id, recipient_id)
        try:
            encoded_effect = json.dumps(dict(effect_evidence), sort_keys=True, separators=(",", ":"), allow_nan=False)
            encoded_health = json.dumps(dict(health_evidence), sort_keys=True, separators=(",", ":"), allow_nan=False)
        except (TypeError, ValueError) as error:
            raise CommunicationJournalError("repair evidence is invalid") from error
        now = _stamp(_now())
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            row = database.execute("SELECT * FROM repair_outcomes WHERE idempotency_key=?",
                                   (idempotency_key,)).fetchone()
            if row is not None:
                for key, value in (("operation_id", operation_id), ("project_id", project_id),
                                   ("service_id", service_id), ("action_id", action_id),
                                   ("correlation_id", correlation_id), ("route", route),
                                   ("conversation_id", conversation_id), ("runtime_id", runtime_id),
                                   ("recipient_id", recipient_id)):
                    if row[key] != value:
                        database.execute("ROLLBACK")
                        raise CommunicationJournalError("repair idempotency key conflicts")
                database.execute("COMMIT")
                result = self._repair_row(row)
                result["_inserted"] = False
                return result
            database.execute(
                """INSERT INTO repair_outcomes
                   (idempotency_key,schema,operation_id,project_id,service_id,action_id,correlation_id,
                    status,reason,effect_evidence,health_evidence,created_at,completed_at,route,
                    conversation_id,runtime_id,recipient_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (idempotency_key, "agent-stack.repair-outcome.v1", operation_id, project_id,
                 service_id, action_id, correlation_id, status, reason, encoded_effect,
                 encoded_health, now, now, route, conversation_id, runtime_id, recipient_id),
            )
            row = database.execute("SELECT * FROM repair_outcomes WHERE idempotency_key=?",
                                  (idempotency_key,)).fetchone()
            database.execute("COMMIT")
        result = self._repair_row(row)
        result["_inserted"] = True
        return result

    def begin_repair(self, *, idempotency_key: str, operation_id: str,
                     project_id: str, service_id: str, action_id: str,
                     correlation_id: str, route: str, conversation_id: str,
                     runtime_id: str, recipient_id: str) -> tuple[bool, dict[str, Any]]:
        """Atomically reserve a repair identity before invoking its effect."""
        result = self.repair_outcome(
            idempotency_key=idempotency_key, operation_id=operation_id,
            project_id=project_id, service_id=service_id, action_id=action_id,
            correlation_id=correlation_id, status="unknown",
            reason="repair execution in progress", effect_evidence={},
            health_evidence={}, route=route, conversation_id=conversation_id,
            runtime_id=runtime_id, recipient_id=recipient_id)
        inserted = bool(result.pop("_inserted", False))
        return inserted, result

    def complete_repair(self, *, idempotency_key: str, status: str, reason: str,
                        effect_evidence: Mapping[str, Any],
                        health_evidence: Mapping[str, Any]) -> dict[str, Any]:
        if status not in {"succeeded", "rejected", "failed", "unknown"} or not isinstance(reason, str) or not reason:
            raise CommunicationJournalError("repair completion is invalid")
        try:
            effect = json.dumps(dict(effect_evidence), sort_keys=True, separators=(",", ":"), allow_nan=False)
            health = json.dumps(dict(health_evidence), sort_keys=True, separators=(",", ":"), allow_nan=False)
        except (TypeError, ValueError) as error:
            raise CommunicationJournalError("repair evidence is invalid") from error
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            row = database.execute("SELECT * FROM repair_outcomes WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            if row is None:
                database.execute("ROLLBACK")
                raise CommunicationJournalError("repair outcome absent")
            if row["reason"] != "repair execution in progress":
                database.execute("COMMIT")
                return self._repair_row(row)
            database.execute("UPDATE repair_outcomes SET status=?,reason=?,effect_evidence=?,health_evidence=? WHERE idempotency_key=?",
                             (status, reason, effect, health, idempotency_key))
            row = database.execute("SELECT * FROM repair_outcomes WHERE idempotency_key=?", (idempotency_key,)).fetchone()
            database.execute("COMMIT")
        return self._repair_row(row)

    @staticmethod
    def _repair_row(row: sqlite3.Row) -> dict[str, Any]:
        try:
            effect = json.loads(row["effect_evidence"])
            health = json.loads(row["health_evidence"])
        except (TypeError, ValueError, json.JSONDecodeError) as error:
            raise CommunicationJournalError("repair outcome evidence is malformed") from error
        if not isinstance(effect, dict) or not isinstance(health, dict):
            raise CommunicationJournalError("repair outcome evidence is malformed")
        return {"schema": row["schema"], "idempotency_key": row["idempotency_key"],
                "operation_id": row["operation_id"], "project_id": row["project_id"],
                "service_id": row["service_id"], "action_id": row["action_id"],
                "correlation_id": row["correlation_id"], "status": row["status"],
                "reason": row["reason"], "effect_evidence": effect,
                "health_evidence": health, "created_at": row["created_at"],
                "completed_at": row["completed_at"], "route": row["route"],
                "conversation_id": row["conversation_id"], "runtime_id": row["runtime_id"],
                "recipient_id": row["recipient_id"]}

    def get_repair_outcome(self, *, idempotency_key: str, route: str,
                           project_id: str, conversation_id: str,
                           runtime_id: str, recipient_id: str,
                           routes: Mapping[str, Mapping[str, str]]) -> dict[str, Any]:
        runtime_id, recipient_id = self._scope(routes, route, project_id, conversation_id,
                                               runtime_id, recipient_id)
        self._required_text(idempotency_key=idempotency_key)
        with self._connect() as database:
            row = database.execute("SELECT * FROM repair_outcomes WHERE idempotency_key=?",
                                   (idempotency_key,)).fetchone()
        if row is None:
            raise CommunicationJournalError("repair outcome absent")
        if any(row[key] != value for key, value in (("route", route), ("project_id", project_id),
                                                     ("conversation_id", conversation_id),
                                                     ("runtime_id", runtime_id), ("recipient_id", recipient_id))):
            raise CommunicationJournalError("repair outcome scope denied")
        return self._repair_row(row)

    def list_route_messages(self, *, kind: str, states: frozenset[str], route: str,
                            project_id: str, conversation_id: str,
                            routes: Mapping[str, Mapping[str, str]], limit: int = 100,
                            runtime_id: str | None = None, recipient_id: str | None = None,
                            cursor: str | None = None) -> dict[str, Any]:
        """Return one bounded, stable page for a single explicitly granted route."""
        runtime_id, recipient_id = self._scope(
            routes, route, project_id, conversation_id, runtime_id, recipient_id,
        )
        allowed_states = {"received", "pending", "sending", "delivered", "unknown"}
        if kind not in {"inbox", "outbox"} or not isinstance(states, frozenset) or not states <= allowed_states or not states:
            raise CommunicationJournalError("message list filter is invalid")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise CommunicationJournalError("message list limit is invalid")
        after = self._decode_cursor(cursor)
        placeholders = ", ".join("?" for _ in states)
        candidate_query = f"""SELECT kind, route, external_id, sender, project_id, conversation_id,
                                      runtime_id, recipient_id, message_kind, correlation_id, content,
                                      state, transport_uuid_version, created_at FROM messages
                    WHERE kind=? AND route=? AND project_id=? AND conversation_id=?
                      AND state IN ({placeholders})"""
        candidate_parameters: list[Any] = [kind, route, project_id, conversation_id, *sorted(states)]
        if after is not None:
            candidate_query += " AND (created_at > ? OR (created_at = ? AND external_id > ?))"
            candidate_parameters.extend((after[0], after[0], after[1]))
        candidate_query += " ORDER BY created_at ASC, external_id ASC LIMIT ?"
        candidate_parameters.append(limit + 1)
        query = f"""SELECT external_id, runtime_id, recipient_id, message_kind, correlation_id,
                             content, state, created_at, transport_uuid_version
                    FROM messages
                    WHERE kind=? AND route=? AND project_id=? AND conversation_id=?
                      AND state IN ({placeholders}) AND runtime_id=? AND recipient_id=?"""
        parameters: list[Any] = [kind, route, project_id, conversation_id, *sorted(states),
                                 runtime_id, recipient_id]
        if after is not None:
            query += " AND (created_at > ? OR (created_at = ? AND external_id > ?))"
            parameters.extend((after[0], after[0], after[1]))
        query += " ORDER BY created_at ASC, external_id ASC LIMIT ?"
        parameters.append(limit + 1)
        with self._connect() as database:
            database.execute("BEGIN IMMEDIATE")
            candidates = database.execute(candidate_query, candidate_parameters).fetchall()
            for candidate in candidates:
                self._bind_existing(
                    database, kind=kind, external_id=candidate["external_id"], route=route,
                    project_id=project_id, conversation_id=conversation_id,
                    runtime_id=runtime_id, recipient_id=recipient_id,
                    correlation_id=candidate["correlation_id"], content=candidate["content"],
                    message_kind=candidate["message_kind"],
                )
            rows = database.execute(query, parameters).fetchall()
            database.execute("COMMIT")
        page = [dict(row) for row in rows[:limit]]
        next_cursor = None
        if len(rows) > limit:
            last = page[-1]
            next_cursor = self._encode_cursor(last["created_at"], last["external_id"])
        return {"items": page, "next_cursor": next_cursor}

    @staticmethod
    def _encode_cursor(created_at: str, external_id: str) -> str:
        raw = json.dumps([created_at, external_id], separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")

    @staticmethod
    def _decode_cursor(cursor: str | None) -> tuple[str, str] | None:
        if cursor is None:
            return None
        if not isinstance(cursor, str) or not cursor or len(cursor) > 1024:
            raise CommunicationJournalError("message cursor is invalid")
        try:
            padded = cursor + "=" * (-len(cursor) % 4)
            value = json.loads(base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8"))
        except (UnicodeEncodeError, UnicodeDecodeError, ValueError, json.JSONDecodeError) as error:
            raise CommunicationJournalError("message cursor is invalid") from error
        if not (isinstance(value, list) and len(value) == 2 and all(isinstance(part, str) and part for part in value)):
            raise CommunicationJournalError("message cursor is invalid")
        return value[0], value[1]
