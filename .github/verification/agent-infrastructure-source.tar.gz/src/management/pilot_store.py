"""Control-plane definitions, grants, and Prefect status projections only."""
from __future__ import annotations
import hashlib, json, sqlite3, secrets
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator
from .pilot_spec import PilotDefinition
from .pilot_provider import ControlledAudioProvider, ControlledSvgProvider, ControlledThreeDProvider
from shared.contracts.pilot_artifact import AudioArtifact, AudioJobRequest, ImageArtifact, ImageJobRequest, PilotAudioArtifactStore, PilotThreeDArtifactStore, StoredAudioArtifact, ThreeDArtifact, ThreeDJobRequest

class PilotStore:
 def __init__(self,path:str|Path,audio_store:PilotAudioArtifactStore|None=None,three_d_store:PilotThreeDArtifactStore|None=None):
  self.audio_store=audio_store
  self.three_d_store=three_d_store
  self.path=str(path); Path(self.path).parent.mkdir(parents=True,exist_ok=True)
  with self._db() as c:
   c.executescript('''CREATE TABLE IF NOT EXISTS pilot_definitions(hash TEXT PRIMARY KEY,parent_hash TEXT,semantic TEXT NOT NULL,layout TEXT NOT NULL,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS pilot_grants(id TEXT PRIMARY KEY,scope TEXT NOT NULL,actor TEXT NOT NULL,mode TEXT NOT NULL CHECK(mode IN ('once','standing')),revoked INTEGER NOT NULL DEFAULT 0,consumed INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS pilot_bindings(project_id TEXT PRIMARY KEY,definition_hash TEXT NOT NULL,model_ref TEXT NOT NULL,memory_ref TEXT NOT NULL,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS pilot_projections(prefect_flow_run_id TEXT PRIMARY KEY,request_id TEXT UNIQUE NOT NULL,definition_hash TEXT NOT NULL,status TEXT NOT NULL,detail TEXT NOT NULL DEFAULT '{}',updated TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS pilot_approvals(prefect_flow_run_id TEXT PRIMARY KEY,scope TEXT NOT NULL,actor TEXT NOT NULL,grant_id TEXT NOT NULL,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);''')
   c.execute('CREATE TABLE IF NOT EXISTS pilot_submissions(request_id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,native_id TEXT,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
   c.execute('''CREATE TABLE IF NOT EXISTS pilot_image_jobs(job_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,request_id TEXT UNIQUE NOT NULL,modality TEXT NOT NULL,format TEXT NOT NULL,mode TEXT NOT NULL,status TEXT NOT NULL,progress INTEGER NOT NULL,artifact_hash TEXT NOT NULL,artifact_bytes BLOB NOT NULL,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
 @contextmanager
 def _db(self)->Iterator[sqlite3.Connection]:
  c=sqlite3.connect(self.path); c.row_factory=sqlite3.Row
  try:
   with c: yield c
  finally:
   c.close()
 def publish(self,definition:PilotDefinition,parent_hash:str|None=None)->str:
  with self._db() as c: c.execute('INSERT OR IGNORE INTO pilot_definitions VALUES(?,?,?,?,CURRENT_TIMESTAMP)',(definition.version_hash,parent_hash,json.dumps(definition.semantic,sort_keys=True),json.dumps(definition.layout,sort_keys=True)))
  return definition.version_hash
 def definitions(self)->list[dict[str,Any]]:
  with self._db() as c:
   rows=c.execute('SELECT hash,parent_hash,semantic,layout,created FROM pilot_definitions ORDER BY created').fetchall()
  return [{**dict(r),'semantic':json.loads(r['semantic']),'layout':json.loads(r['layout'])} for r in rows]
 def definition(self,h:str)->dict[str,Any]:
  with self._db() as c:r=c.execute('SELECT * FROM pilot_definitions WHERE hash=?',(h,)).fetchone()
  if not r: raise KeyError('unknown definition');
  return {'schema':'agent-stack.pilot.v1',**json.loads(r['semantic']),'layout':json.loads(r['layout'])}
 def grant(self,scope:str,actor:str,mode:str)->str:
  if mode not in {'once','standing'}: raise ValueError('grant mode must be once or standing')
  token=secrets.token_urlsafe(24)
  with self._db() as c:c.execute('INSERT INTO pilot_grants(id,scope,actor,mode) VALUES(?,?,?,?)',(token,scope,actor,mode))
  return token
 def bind(self,project_id:str,definition_hash:str,model_ref:str,memory_ref:str)->None:
  with self._db() as c:c.execute('INSERT INTO pilot_bindings(project_id,definition_hash,model_ref,memory_ref) VALUES(?,?,?,?) ON CONFLICT(project_id) DO UPDATE SET definition_hash=excluded.definition_hash,model_ref=excluded.model_ref,memory_ref=excluded.memory_ref',(project_id,definition_hash,model_ref,memory_ref))
 def binding(self,project_id:str)->dict[str,str]:
  with self._db() as c:r=c.execute('SELECT project_id,definition_hash,model_ref,memory_ref FROM pilot_bindings WHERE project_id=?',(project_id,)).fetchone()
  if not r: raise KeyError('unknown project binding')
  return dict(r)
 def revoke(self,grant_id:str)->None:
  with self._db() as c:
   if not c.execute('UPDATE pilot_grants SET revoked=1 WHERE id=?',(grant_id,)).rowcount: raise KeyError('unknown grant')
 def authorize(self,grant_id:str,scope:str,actor:str)->bool:
  with self._db() as c:
   c.execute('BEGIN IMMEDIATE')
   r=c.execute('SELECT * FROM pilot_grants WHERE id=?',(grant_id,)).fetchone()
   if not r or r['revoked'] or r['scope']!=scope or r['actor']!=actor or (r['mode']=='once' and r['consumed']): return False
   if r['mode']=='once' and not c.execute('UPDATE pilot_grants SET consumed=1 WHERE id=? AND consumed=0 AND revoked=0',(grant_id,)).rowcount: return False
   return True
 def authorize_and_record(self,prefect_id:str,grant_id:str,scope:str,actor:str)->bool:
  with self._db() as c:
   c.execute('BEGIN IMMEDIATE')
   existing=c.execute('SELECT scope,actor,grant_id FROM pilot_approvals WHERE prefect_flow_run_id=?',(prefect_id,)).fetchone()
   if existing: return dict(existing)=={'scope':scope,'actor':actor,'grant_id':grant_id}
   grant=c.execute('SELECT * FROM pilot_grants WHERE id=?',(grant_id,)).fetchone()
   if not grant or grant['revoked'] or grant['scope']!=scope or grant['actor']!=actor or (grant['mode']=='once' and grant['consumed']): return False
   if grant['mode']=='once' and not c.execute('UPDATE pilot_grants SET consumed=1 WHERE id=? AND consumed=0 AND revoked=0',(grant_id,)).rowcount: return False
   c.execute('INSERT INTO pilot_approvals(prefect_flow_run_id,scope,actor,grant_id) VALUES(?,?,?,?)',(prefect_id,scope,actor,grant_id))
   return True
 def record_approval(self,prefect_id:str,scope:str,actor:str,grant_id:str)->None:
  with self._db() as c:
   c.execute('INSERT INTO pilot_approvals(prefect_flow_run_id,scope,actor,grant_id) VALUES(?,?,?,?)',(prefect_id,scope,actor,grant_id))
 def approved(self,prefect_id:str,scope:str)->bool:
  with self._db() as c:
   return c.execute('SELECT 1 FROM pilot_approvals a JOIN pilot_grants g ON g.id=a.grant_id WHERE a.prefect_flow_run_id=? AND a.scope=? AND g.revoked=0',(prefect_id,scope)).fetchone() is not None
 def claim_submission(self,request_id:str,fingerprint:str)->str|None:
  with self._db() as c:
   c.execute('BEGIN IMMEDIATE'); row=c.execute('SELECT fingerprint,native_id FROM pilot_submissions WHERE request_id=?',(request_id,)).fetchone()
   if row:
    if row['fingerprint']!=fingerprint: raise ValueError('request id conflicts with immutable submission')
    return row['native_id']
   c.execute('INSERT INTO pilot_submissions(request_id,fingerprint) VALUES(?,?)',(request_id,fingerprint)); return None
 def record_submission_native(self,request_id:str,fingerprint:str,native_id:str)->None:
  with self._db() as c:
   c.execute('BEGIN IMMEDIATE'); row=c.execute('SELECT fingerprint,native_id FROM pilot_submissions WHERE request_id=?',(request_id,)).fetchone()
   if not row or row['fingerprint']!=fingerprint: raise ValueError('submission claim changed')
   if row['native_id'] and row['native_id']!=native_id: raise ValueError('submission native identity changed')
   c.execute('UPDATE pilot_submissions SET native_id=? WHERE request_id=?',(native_id,request_id))
 def project(self,prefect_id:str,request_id:str,definition_hash:str,status:str,detail:dict[str,Any]|None=None)->None:
  with self._db() as c:c.execute('INSERT INTO pilot_projections(prefect_flow_run_id,request_id,definition_hash,status,detail) VALUES(?,?,?,?,?) ON CONFLICT(prefect_flow_run_id) DO UPDATE SET status=excluded.status,detail=excluded.detail,updated=CURRENT_TIMESTAMP',(prefect_id,request_id,definition_hash,status,json.dumps(detail or {},sort_keys=True)))
 def projection(self,prefect_id:str)->dict[str,Any]:
  with self._db() as c:r=c.execute('SELECT * FROM pilot_projections WHERE prefect_flow_run_id=?',(prefect_id,)).fetchone()
  if not r: raise KeyError('unknown Prefect flow run'); return {}
  return {**dict(r),'detail':json.loads(r['detail'])}
 def create_image_job(self,request:ImageJobRequest)->dict[str,Any]:
  """Persist one artifact from the explicitly selected deterministic provider."""
  svg=ControlledSvgProvider().render(request)
  artifact_hash=hashlib.sha256(svg).hexdigest(); job_id=secrets.token_urlsafe(18)
  with self._db() as c:
   existing=c.execute('SELECT * FROM pilot_image_jobs WHERE request_id=?',(request.request_id,)).fetchone()
   if existing:
    if existing['project_id'] != request.project_id or existing['artifact_hash'] != artifact_hash: raise ValueError('request id conflicts with immutable image job')
    return self._image_job(existing)
   c.execute('INSERT INTO pilot_image_jobs(job_id,project_id,request_id,modality,format,mode,status,progress,artifact_hash,artifact_bytes) VALUES(?,?,?,?,?,?,?,?,?,?)',(job_id,request.project_id,request.request_id,request.modality,request.format,request.mode,'completed',100,artifact_hash,sqlite3.Binary(svg)))
   return self._image_job(c.execute('SELECT * FROM pilot_image_jobs WHERE job_id=?',(job_id,)).fetchone())
 def _image_job(self,row:sqlite3.Row)->dict[str,Any]:
  return ImageArtifact(job_id=row['job_id'],project_id=row['project_id'],request_id=row['request_id'],modality=row['modality'],format=row['format'],mode=row['mode'],status=row['status'],progress=row['progress'],artifact_reference=f'/v1/projects/{row["project_id"]}/artifacts/{row["job_id"]}',artifact_sha256=row['artifact_hash']).as_dict()
 def image_job(self,job_id:str,project_id:str)->dict[str,Any]:
  with self._db() as c:r=c.execute('SELECT * FROM pilot_image_jobs WHERE job_id=?',(job_id,)).fetchone()
  if not r: raise KeyError('unknown image job')
  if r['project_id'] != project_id: raise PermissionError('image job is outside this project scope')
  return self._image_job(r)
 def image_artifact(self,project_id:str,job_id:str)->tuple[bytes,str]:
  with self._db() as c:r=c.execute('SELECT project_id,artifact_hash,artifact_bytes FROM pilot_image_jobs WHERE job_id=?',(job_id,)).fetchone()
  if not r: raise KeyError('unknown image artifact')
  if r['project_id'] != project_id: raise PermissionError('artifact is outside this project scope')
  content=bytes(r['artifact_bytes'])
  if hashlib.sha256(content).hexdigest()!=r['artifact_hash']: raise ValueError('image artifact integrity check failed')
  return content,r['artifact_hash']
 def create_audio_job(self,request:AudioJobRequest)->dict[str,Any]:
  """Authorize the controlled provider and project the Storage receipt."""
  if self.audio_store is None: raise RuntimeError('audio storage service is not configured')
  audio=ControlledAudioProvider().render(request)
  return self._audio_job(self.audio_store.store_audio(request,audio))
 def _audio_job(self,row:StoredAudioArtifact)->dict[str,Any]:
  return AudioArtifact(job_id=row.job_id,project_id=row.project_id,request_id=row.request_id,modality=row.modality,format=row.format,mode=row.mode,status=row.status,progress=row.progress,artifact_reference=f'/v1/projects/{row.project_id}/artifacts/{row.job_id}',artifact_sha256=row.artifact_sha256).as_dict()
 def audio_job(self,job_id:str,project_id:str)->dict[str,Any]:
  if self.audio_store is None: raise RuntimeError('audio storage service is not configured')
  return self._audio_job(self.audio_store.audio_job(job_id,project_id))
 def audio_artifact(self,project_id:str,job_id:str)->tuple[bytes,str]:
  if self.audio_store is None: raise RuntimeError('audio storage service is not configured')
  return self.audio_store.read_audio(project_id,job_id)
 def create_3d_job(self,request:ThreeDJobRequest)->dict[str,Any]:
  if self.three_d_store is None: raise RuntimeError('3D storage service is not configured')
  provider=ControlledThreeDProvider()
  return self.three_d_store.submit_3d(request,provider.render(request)).as_dict()
 def three_d_job(self,job_id:str,project_id:str)->dict[str,Any]:
  if self.three_d_store is None: raise RuntimeError('3D storage service is not configured')
  return self.three_d_store.three_d_job(job_id,project_id).as_dict()
 def three_d_artifact(self,project_id:str,job_id:str)->tuple[bytes,str]:
  if self.three_d_store is None: raise RuntimeError('3D storage service is not configured')
  return self.three_d_store.read_3d(project_id,job_id)
