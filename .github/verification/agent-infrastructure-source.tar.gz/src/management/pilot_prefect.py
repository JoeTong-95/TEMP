"""Small native Prefect control seam; no local scheduler or run ledger."""
from __future__ import annotations

from uuid import UUID
import json
from typing import Any

class NativePrefectUnavailable(RuntimeError):
    pass

def resume(flow_run_id: str) -> dict[str, str]:
    """Resume the exact paused Prefect run and return its native identifier."""
    try:
        from prefect.flow_runs import resume_flow_run
    except ImportError as exc:
        raise NativePrefectUnavailable('prefect==3.8.5 is required') from exc
    run_id = UUID(flow_run_id)
    resume_flow_run(run_id)
    return {'prefect_flow_run_id': str(run_id), 'action': 'resumed'}

def cancel(flow_run_id: str) -> dict[str, str]:
    """Request cancellation through Prefect and return the resulting native state."""
    try:
        from prefect.client.orchestration import get_client
        from prefect.states import Cancelling
    except ImportError as exc:
        raise NativePrefectUnavailable('prefect==3.8.5 is required') from exc
    run_id = UUID(flow_run_id)
    with get_client(sync_client=True) as client:
        result = client.set_flow_run_state(run_id, Cancelling(), force=True)
    status = getattr(getattr(result, 'state', None), 'type', None)
    return {'prefect_flow_run_id': str(run_id), 'action': 'cancelling', 'state': str(status or 'CANCELLING')}

def status(flow_run_id: str) -> dict[str, str]:
    """Read native state only; callers may combine this with their projection."""
    try:
        from prefect.client.orchestration import get_client
    except ImportError as exc:
        raise NativePrefectUnavailable('prefect==3.8.5 is required') from exc
    run_id = UUID(flow_run_id)
    with get_client(sync_client=True) as client:
        run = client.read_flow_run(run_id)
    return {'prefect_flow_run_id': str(run_id), 'state': str(run.state_type), 'state_name': str(run.state_name)}

def completed_result(flow_run_id: str) -> dict[str, Any] | None:
    """Read persisted Prefect result only after a genuine completed state."""
    try:
        from prefect.client.orchestration import get_client
    except ImportError as exc:
        raise NativePrefectUnavailable('prefect==3.8.5 is required') from exc
    with get_client(sync_client=True) as client:
        run = client.read_flow_run(UUID(flow_run_id))
    if str(run.state_type) != 'StateType.COMPLETED':
        return None
    value = run.state.result()
    if not isinstance(value, dict):
        return None
    allowed = {'runtime_kind','prefect_flow_run_id','artifact','agent','tool','condition','approval_scope'}
    result = {key:value[key] for key in allowed if key in value}
    encoded = json.dumps(result,sort_keys=True,ensure_ascii=True)
    if len(encoded.encode()) > 65_536:
        raise ValueError('native persisted result exceeds API bound')
    return result
