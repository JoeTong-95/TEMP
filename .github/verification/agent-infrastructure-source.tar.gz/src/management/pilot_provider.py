"""Deterministic, non-LLM providers used by the local pilot."""
from __future__ import annotations

import hashlib
import json
import io
import wave

from shared.contracts.pilot_artifact import (
    CONTROLLED_AUDIO_CAPABILITY,
    CONTROLLED_IMAGE_CAPABILITY,
    AudioJobRequest,
    ImageJobRequest,
    CONTROLLED_VIDEO_CAPABILITY,
    VideoJobRequest,
    CONTROLLED_3D_CAPABILITY,
    ThreeDJobRequest,
)


class ControlledSvgProvider:
    """Render the reviewed SVG fixture without selecting or calling a real engine."""

    capability = CONTROLLED_IMAGE_CAPABILITY

    def render(self, request: ImageJobRequest) -> bytes:
        if (request.modality, request.format, request.mode) != ("image", "svg", "controlled"):
            raise ValueError("provider does not support this image capability")
        seed = json.dumps({
            "project_id": request.project_id,
            "request_id": request.request_id,
            "prompt": request.prompt,
            "width": request.width,
            "height": request.height,
        }, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(seed.encode()).hexdigest()
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{request.width}" height="{request.height}" '
                f'viewBox="0 0 {request.width} {request.height}">'
                f'<rect width="100%" height="100%" fill="#172033"/>'
                f'<text x="50%" y="50%" fill="#d9e8ff" text-anchor="middle" dominant-baseline="middle" '
                f'font-family="sans-serif" font-size="18">controlled image {digest[:12]}</text></svg>').encode()


class ControlledAudioProvider:
    """Render a deterministic silent WAV fixture without selecting a real engine."""

    capability = CONTROLLED_AUDIO_CAPABILITY

    def render(self, request: AudioJobRequest) -> bytes:
        if (request.modality, request.format, request.mode) != ("audio", "wav", "controlled"):
            raise ValueError("provider does not support this audio capability")
        seed = json.dumps({
            "project_id": request.project_id,
            "request_id": request.request_id,
            "prompt": request.prompt,
            "duration_seconds": request.duration_seconds,
        }, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(seed.encode()).digest()
        sample_rate = 8_000
        sample_count = sample_rate * request.duration_seconds
        # A deterministic low-volume tone makes the fixture audibly identifiable.
        samples = bytes(digest[index % len(digest)] for index in range(sample_count))
        output = io.BytesIO()
        with wave.open(output, "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(1)
            wav.setframerate(sample_rate)
            wav.writeframes(samples)
        return output.getvalue()


class ControlledVideoProvider:
    """Render a deterministic opaque fixture; no video engine is selected."""

    capability = CONTROLLED_VIDEO_CAPABILITY

    def render(self, request: VideoJobRequest) -> bytes:
        if (request.modality, request.format, request.mode) != ("video", "mp4", "controlled"):
            raise ValueError("provider does not support this video capability")
        seed = json.dumps({
            "project_id": request.project_id, "request_id": request.request_id,
            "prompt": request.prompt, "width": request.width,
            "height": request.height, "duration_seconds": request.duration_seconds,
        }, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(seed.encode()).hexdigest()
        return f"CONTROLLED_VIDEO_FIXTURE\n{digest}\n{request.width}x{request.height}\n{request.duration_seconds}s\n".encode()


class ControlledThreeDProvider:
    """Render a deterministic GLB-labelled fixture without selecting a 3D engine."""

    capability = CONTROLLED_3D_CAPABILITY

    def render(self, request: ThreeDJobRequest) -> bytes:
        if (request.modality, request.format, request.mode) != ("3d", "glb", "controlled"):
            raise ValueError("provider does not support this 3D capability")
        seed = json.dumps({"project_id": request.project_id, "request_id": request.request_id, "prompt": request.prompt}, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(seed.encode()).hexdigest()
        # This is deliberately an opaque, deterministic controlled artifact, not an engine output.
        return f"CONTROLLED_3D_FIXTURE\n{digest}\nformat=glb\n".encode()
