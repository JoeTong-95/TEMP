"""Explicit Prefect 3.8.5 adapter for durable project-start dispatches.

The dispatcher supplies a stable intent id; this adapter uses it as Prefect's
native idempotency key.  Client construction is explicit so ambient Prefect
profiles and cloud settings cannot select an endpoint or credentials.
"""
from __future__ import annotations

import json
from typing import Any, Callable, Mapping, Protocol
from uuid import UUID


class PrefectClient(Protocol):
    def create_flow_run_from_deployment(
        self,
        deployment_id: UUID,
        *,
        parameters: dict[str, Any] | None = None,
        name: str | None = None,
        idempotency_key: str | None = None,
    ) -> Any: ...

    def read_flow_runs(self, *, flow_run_filter: Any = None, limit: int | None = None) -> list[Any]: ...


FlowRunFilterFactory = Callable[[UUID, str], Any]


def _detached(value: Mapping[str, Any]) -> dict[str, Any]:
    return json.loads(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False))


def native_flow_run_filter(deployment_id: UUID, intent_id: str) -> Any:
    """Construct the pinned Prefect 3.8.5 schema instead of hand-writing JSON."""
    from prefect.client.schemas.filters import FlowRunFilter, FlowRunFilterDeploymentId, FlowRunFilterIdempotencyKey

    return FlowRunFilter(
        deployment_id=FlowRunFilterDeploymentId(any_=[deployment_id]),
        idempotency_key=FlowRunFilterIdempotencyKey(any_=[intent_id]),
    )


class PrefectProjectSubmitter:
    """Synchronous ``ExecutionSubmitter`` implementation for Prefect deployments."""

    def __init__(self, deployment_id: UUID | str, client: PrefectClient, *, filter_factory: FlowRunFilterFactory = native_flow_run_filter) -> None:
        self.deployment_id = UUID(str(deployment_id))
        self.client = client
        self.filter_factory = filter_factory

    @staticmethod
    def _receipt(intent_id: str, deployment_id: UUID, run: Any) -> dict[str, str]:
        if getattr(run, "deployment_id", None) != deployment_id or getattr(run, "idempotency_key", None) != intent_id:
            raise ValueError("Prefect flow run does not match the requested deployment and intent")
        run_id = getattr(run, "id", None)
        if run_id is None:
            raise ValueError("Prefect did not return a flow-run id")
        return {"intent_id": intent_id, "execution_id": str(run_id)}

    def submit(self, intent_id: str, body: Mapping[str, Any]) -> Mapping[str, Any]:
        if not isinstance(intent_id, str) or not intent_id:
            raise ValueError("intent_id is required")
        detached_body = _detached(body)
        run = self.client.create_flow_run_from_deployment(
            self.deployment_id,
            parameters={"start_intent": {"intent_id": intent_id, "body": detached_body}},
            name=f"project-start-{intent_id}",
            idempotency_key=intent_id,
        )
        return self._receipt(intent_id, self.deployment_id, run)

    def lookup(self, intent_id: str) -> Mapping[str, Any] | None:
        if not isinstance(intent_id, str) or not intent_id:
            raise ValueError("intent_id is required")
        runs = self.client.read_flow_runs(flow_run_filter=self.filter_factory(self.deployment_id, intent_id), limit=2)
        if not isinstance(runs, list):
            raise ValueError("Prefect returned a malformed flow-run query result")
        if not runs:
            return None
        if len(runs) != 1:
            raise ValueError("Prefect returned ambiguous flow runs for one start intent")
        run = runs[0]
        return self._receipt(intent_id, self.deployment_id, run)
