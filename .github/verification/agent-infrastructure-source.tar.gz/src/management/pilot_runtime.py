"""Narrow private HTTP contract for the locally owned agent runtime."""
from __future__ import annotations
import json
import os
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler
from urllib.error import URLError, HTTPError
from typing import Any

class PilotRuntimeError(RuntimeError): pass

_MAX_RESPONSE_BYTES=1_048_576
_MAX_SUMMARY_BYTES=16_384
_DEADLINE_SECONDS=180
_RUNTIME_CONFIG={
 'platform-canary-a':('PILOT_RUNTIME_ENDPOINT_A','http://127.0.0.1:18110/v1/pilot/agent','PILOT_RUNTIME_CAPABILITY_FILE_A'),
 'platform-canary-b':('PILOT_RUNTIME_ENDPOINT_B','http://127.0.0.1:18111/v1/pilot/agent','PILOT_RUNTIME_CAPABILITY_FILE_B'),
}

class _NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*args:Any,**kwargs:Any): return None

def _private_endpoint(endpoint:str)->bool:
 parsed=urlparse(endpoint)
 return parsed.scheme=='http' and parsed.hostname=='127.0.0.1' and parsed.port in {18110,18111} and parsed.path=='/v1/pilot/agent' and not parsed.params and not parsed.query and not parsed.fragment and parsed.username is None and parsed.password is None

def invoke_configured_agent(*,project_id:str,request_id:str,model_ref:str,memory_ref:str,value:int)->dict[str,Any]:
 """Resolve the protected per-project capability inside the executing task."""
 fake=os.environ.get('PILOT_TEST_FAKE_AGENT_RESULT_PATH')
 if fake:
  if not fake.startswith('/srv/agent-stack/state/pilot/test/'):
   raise PilotRuntimeError('test fake result path is outside dedicated pilot test state')
  try: return json.loads(Path(fake).read_text(encoding='utf-8'))
  except (OSError,json.JSONDecodeError) as exc: raise PilotRuntimeError('test fake result unavailable') from exc
 if project_id not in _RUNTIME_CONFIG: raise PilotRuntimeError('unknown pilot project')
 endpoint_key,default_endpoint,file_key=_RUNTIME_CONFIG[project_id]
 capability_file=os.environ.get(file_key)
 if not capability_file: raise PilotRuntimeError('runtime capability file is not configured')
 try: capability=Path(capability_file).read_text(encoding='utf-8').strip()
 except OSError as exc: raise PilotRuntimeError('runtime capability file is unavailable') from exc
 return invoke_agent(os.environ.get(endpoint_key,default_endpoint),capability,project_id=project_id,request_id=request_id,model_ref=model_ref,memory_ref=memory_ref,value=value)

def invoke_agent(endpoint:str, capability:str, *, project_id:str, request_id:str, model_ref:str, memory_ref:str, value:int)->dict[str,Any]:
 """Call the fixed local contract; definition data never supplies a URL or token."""
 if not _private_endpoint(endpoint) or not capability: raise PilotRuntimeError('runtime endpoint/capability is not private configured state')
 body=json.dumps({'schema':'agent-stack.pilot-agent.v1','project_id':project_id,'request_id':request_id,'model_ref':model_ref,'memory_ref':memory_ref,'input':{'value':value}},sort_keys=True).encode()
 req=Request(endpoint,data=body,method='POST',headers={'Content-Type':'application/json','Authorization':'Bearer '+capability})
 try:
  opener=build_opener(ProxyHandler({}),_NoRedirect())
  with opener.open(req,timeout=_DEADLINE_SECONDS) as response: raw=response.read(_MAX_RESPONSE_BYTES+1)
 except (URLError,HTTPError) as e: raise PilotRuntimeError('local runtime request failed') from e
 if len(raw)>_MAX_RESPONSE_BYTES: raise PilotRuntimeError('local runtime response exceeds limit')
 try: result=json.loads(raw)
 except json.JSONDecodeError as e: raise PilotRuntimeError('local runtime returned malformed JSON') from e
 if not isinstance(result,dict) or not {'schema','summary','runtime_kind'}.issubset(result) or result['schema']!='agent-stack.pilot-agent-result.v1' or not isinstance(result['summary'],str) or len(result['summary'].encode())>_MAX_SUMMARY_BYTES or result['runtime_kind'] not in {'hermes','fixture'}: raise PilotRuntimeError('local runtime contract mismatch')
 # Optional native session/usage evidence is retained as opaque JSON-safe data
 # and travels into Prefect's persisted result rather than an operator prompt.
 if 'native_session_ref' in result and not isinstance(result['native_session_ref'],str): raise PilotRuntimeError('native session reference is invalid')
 if 'evidence_ref' in result and not isinstance(result['evidence_ref'],str): raise PilotRuntimeError('runtime evidence reference is invalid')
 if result['runtime_kind']=='hermes' and (not isinstance(result.get('native_session_ref'),str) or not result['native_session_ref'] or not isinstance(result.get('evidence_ref'),str) or not result['evidence_ref']): raise PilotRuntimeError('Hermes result lacks native evidence')
 return result
