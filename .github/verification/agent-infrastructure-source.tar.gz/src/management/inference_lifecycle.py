"""Durable Management submission and polling for admitted inference work."""
from __future__ import annotations

import http.client
import json
import math
from typing import Any, Mapping, Protocol
from urllib.parse import quote, urlsplit

from .catalog_admission import CatalogAdmission, CatalogAdmissionError
from .model_capability_catalog import CatalogConflict, CatalogError
from .provider_registry import ProviderRegistry
from .model_capability_catalog import _sanitize_outcome
from shared.contracts.credentials import SecretValidationError, validate_bounded_secret


class InferenceLifecycleError(ValueError):
    pass


class InferenceRequestConflict(InferenceLifecycleError):
    pass


class ProviderOutcomeUnknown(InferenceLifecycleError):
    def __init__(self, request_id: str):
        super().__init__("provider outcome is unknown for " + request_id)
        self.request_id = request_id


class InferenceProvider(Protocol):
    def submit(self, request_id: str, model_id: str, revision: str, provider_id: str, generation: int) -> Mapping[str, Any]: ...
    def poll(self, request_id: str, model_id: str, revision: str, provider_id: str, generation: int) -> Mapping[str, Any]: ...


class InferenceProviderClient:
    def __init__(self, providers: ProviderRegistry, *, provider_tokens: Mapping[str, str] | None = None,
                 timeout_seconds: float = 5.0, max_response_bytes: int = 64 * 1024):
        if providers is None or not callable(getattr(providers, "get", None)):
            raise InferenceLifecycleError("provider registry is required")
        if provider_tokens is not None and (not isinstance(provider_tokens, Mapping) or any(
            not isinstance(k, str) or not k or self._invalid_token(v)
            for k, v in provider_tokens.items())):
            raise InferenceLifecycleError("inference provider credentials are invalid")
        if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float)) or not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 30:
            raise InferenceLifecycleError("inference provider timeout is invalid")
        if type(max_response_bytes) is not int or not 1 <= max_response_bytes <= 1024 * 1024:
            raise InferenceLifecycleError("inference provider response bound is invalid")
        self.providers, self.provider_tokens = providers, dict(provider_tokens or {})
        self.timeout_seconds, self.max_response_bytes = float(timeout_seconds), max_response_bytes

    @staticmethod
    def _invalid_token(value: object) -> bool:
        try:
            validate_bounded_secret(value)
        except (SecretValidationError, UnicodeEncodeError):
            return True
        return False

    def submit(self, request_id, model_id, revision, provider_id, generation):
        return self._request("POST", request_id, model_id, revision, provider_id, generation)

    def poll(self, request_id, model_id, revision, provider_id, generation):
        return self._request("GET", request_id, model_id, revision, provider_id, generation)

    def _request(self, method, request_id, model_id, revision, provider_id, generation):
        provider = self.providers.get(provider_id)
        manifest = provider.get("manifest", {}) if isinstance(provider, Mapping) else {}
        endpoint = manifest.get("private_endpoint") if isinstance(manifest, Mapping) else None
        if provider is None or provider.get("generation") != generation or provider.get("role") != "inference" or not isinstance(endpoint, str):
            raise InferenceLifecycleError("selected inference provider is unavailable")
        token = self.provider_tokens.get(provider_id)
        if token is None: raise InferenceLifecycleError("selected inference provider credential is unavailable")
        parsed = urlsplit(endpoint)
        if parsed.scheme not in {"http", "https"} or parsed.username or parsed.password or parsed.query or parsed.fragment or not parsed.hostname:
            raise InferenceLifecycleError("selected inference provider endpoint is invalid")
        if parsed.scheme == "http" and parsed.hostname not in {"127.0.0.1", "::1", "localhost"}:
            raise InferenceLifecycleError("inference provider transport must be private HTTPS")
        base = parsed.path.rstrip("/")
        if base == "/v1": base = ""
        path = f"{base}/agent-stack/inference/requests/{quote(request_id, safe='')}"
        body = {"request_id": request_id, "effect_id": request_id, "model_id": model_id, "revision": revision,
                "provider_id": provider_id, "provider_generation": generation}
        raw = json.dumps(body, separators=(",", ":")).encode() if method == "POST" else None
        cls = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
        conn = cls(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80), timeout=self.timeout_seconds)
        try:
            headers = {"Accept": "application/json", "Authorization": "Bearer " + token}
            if raw is not None: headers.update({"Content-Type": "application/json", "Content-Length": str(len(raw))})
            conn.request(method, path, raw, headers); response = conn.getresponse(); data = response.read(self.max_response_bytes + 1)
            if len(data) > self.max_response_bytes or response.status not in {200, 202}:
                if method == "POST" and response.status in {400, 401, 403, 404, 405, 409, 415, 422}: raise InferenceLifecycleError("provider rejected inference operation")
                raise ProviderOutcomeUnknown(request_id)
            try: value = json.loads(data.decode())
            except (UnicodeDecodeError, json.JSONDecodeError) as error: raise ProviderOutcomeUnknown(request_id) from error
            if not isinstance(value, Mapping): raise ProviderOutcomeUnknown(request_id)
            return dict(value)
        except (InferenceLifecycleError, ProviderOutcomeUnknown): raise
        except (OSError, http.client.HTTPException, TimeoutError) as error: raise ProviderOutcomeUnknown(request_id) from error
        finally: conn.close()


class InferenceLifecycleCoordinator:
    def __init__(self, admission: CatalogAdmission, provider: InferenceProvider):
        if admission is None or not callable(getattr(admission, "admit", None)) or not hasattr(admission, "catalog"):
            raise InferenceLifecycleError("catalog admission is required")
        if provider is None or not callable(getattr(provider, "submit", None)) or not callable(getattr(provider, "poll", None)):
            raise InferenceLifecycleError("inference provider submit and poll are required")
        self.admission, self.provider = admission, provider

    def submit(self, project_id, request_id, model_id, revision):
        existing = self.admission.catalog.request_record(request_id)
        if existing is not None:
            self._identity(existing, project_id, model_id, revision); return self._public(existing)
        try: decision = self.admission.admit(project_id, request_id, model_id, revision)
        except (CatalogAdmissionError, CatalogConflict, CatalogError) as error: raise InferenceLifecycleError(str(error)) from error
        if decision.get("state") != "admitted":
            detail = decision.get("reason") if isinstance(decision, Mapping) else None
            if not isinstance(detail, str) or not detail:
                detail = "additional_resources_required"
            detail = detail[:256]
            outcome = {"request_id": request_id, "effect_id": request_id,
                       "state": "failed", "reason": "admission_rejected", "detail": detail}
            return self._public(self.admission.catalog.record_request(
                request_id, project_id, model_id, revision, "failed",
                effect_id=request_id, outcome=outcome))
        provider_id, generation = decision.get("provider_id"), decision.get("provider_generation")
        if not isinstance(provider_id, str) or type(generation) is not int or generation < 1: raise InferenceLifecycleError("admission did not identify an approved provider generation")
        record, claimed = self.admission.catalog.claim_request(request_id, project_id, model_id, revision, provider_id, generation)
        if not claimed: return self._public(record)
        try: outcome = self.provider.submit(request_id, model_id, revision, provider_id, generation)
        except Exception:
            return self._unknown(request_id, "provider_submit_exception")
        try:
            return self._record(request_id, outcome)
        except Exception:
            return self._unknown(request_id, "provider_submit_response_invalid")

    def poll(self, request_id, *, project_id=None):
        record = self._require(request_id)
        if project_id is not None and record["project_id"] != project_id: raise InferenceLifecycleError("inference request is outside project scope")
        if record["state"] in {"completed", "failed", "unknown"}: return self._public(record)
        try: outcome = self.provider.poll(request_id, record["model_id"], record["revision"], record["provider_id"], record["provider_generation"])
        except (ProviderOutcomeUnknown, InferenceLifecycleError): outcome={"request_id":request_id,"effect_id":request_id,"state":"unknown","reason":"provider_poll_unknown"}
        except Exception: outcome={"request_id":request_id,"effect_id":request_id,"state":"unknown","reason":"provider_poll_exception"}
        try: return self._record(request_id, outcome)
        except InferenceLifecycleError: return self._public(self.admission.catalog.update_request(request_id, "unknown", outcome={"request_id":request_id,"effect_id":request_id,"state":"unknown","reason":"provider_poll_response_invalid"}))

    def status(self, request_id, *, project_id=None):
        record=self._require(request_id)
        if project_id is not None and record["project_id"] != project_id: raise InferenceLifecycleError("inference request is outside project scope")
        return self._public(record)

    def reconcile(self, request_id, outcome=None, *, project_id=None):
        record = self._require(request_id)
        if project_id is not None and record["project_id"] != project_id: raise InferenceLifecycleError("inference request is outside project scope")
        # An unknown local state means the submit acknowledgement was lost.  A
        # reconciliation is an explicit provider receipt lookup, never a new
        # submission.  Keep terminal records idempotent and avoid contacting a
        # provider after a result has already been durably recovered.
        if outcome is None:
            if record["state"] in {"completed", "failed"}: return self._public(record)
            try:
                outcome = self.provider.poll(request_id, record["model_id"], record["revision"], record["provider_id"], record["provider_generation"])
            except (ProviderOutcomeUnknown, InferenceLifecycleError):
                return self._unknown(request_id, "provider_reconcile_unknown")
            except Exception:
                return self._unknown(request_id, "provider_reconcile_exception")
            # A receipt lookup is useful only when it proves a terminal
            # outcome for this exact operation.  Unknown, queued/active, and
            # malformed responses must not leave the request replayable.
            if (not isinstance(outcome, Mapping) or outcome.get("request_id") != request_id
                    or outcome.get("effect_id") != request_id
                    or outcome.get("state") not in {"completed", "failed"}):
                return self._unknown(request_id, "provider_reconcile_incomplete")
        if not isinstance(outcome, Mapping) or outcome.get("request_id") != request_id or outcome.get("effect_id") != request_id or outcome.get("state") not in {"completed", "failed"}:
            raise InferenceLifecycleError("reconciliation outcome identities are invalid")
        if record["state"] in {"completed", "failed"}: return self._public(record)
        return self._public(self.admission.catalog.update_request(request_id, outcome["state"], outcome=dict(outcome)))

    def _record(self, request_id, outcome):
        if not isinstance(outcome, Mapping) or outcome.get("request_id") != request_id or outcome.get("effect_id") != request_id or outcome.get("state") not in {"queued","active","completed","failed","unknown"}: raise InferenceLifecycleError("provider outcome must contain matching request_id and effect_id")
        return self._public(self.admission.catalog.update_request(request_id, outcome["state"], outcome=dict(outcome)))

    def _unknown(self, request_id, reason):
        return self._public(self.admission.catalog.update_request(request_id, "unknown", outcome={"request_id": request_id, "effect_id": request_id, "state": "unknown", "reason": reason}))

    def _require(self, request_id):
        record=self.admission.catalog.request_record(request_id)
        if record is None: raise InferenceLifecycleError("unknown inference request")
        return record

    @staticmethod
    def _identity(record, project_id, model_id, revision):
        if any(record.get(k) != v for k,v in (("project_id",project_id),("model_id",model_id),("revision",revision))) or record.get("effect_id") != record.get("request_id"): raise InferenceRequestConflict("idempotency conflict")

    @staticmethod
    def _public(record):
        public = {k: record.get(k) for k in ("request_id","effect_id","project_id","model_id","revision","state","provider_id","provider_generation","outcome","updated_at")}
        if public["outcome"] is not None:
            public["outcome"] = _sanitize_outcome(public["outcome"])
        return public

InferenceRequestCoordinator = InferenceLifecycleCoordinator
HttpInferenceProvider = InferenceProviderClient
