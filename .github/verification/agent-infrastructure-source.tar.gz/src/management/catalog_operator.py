"""Check-first import of reviewed catalog material; it has no inference controls."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .hardware_registry import HardwareRegistry
from .model_capability_catalog import ModelCapabilityCatalog
from .provider_registry import ProviderRegistry


class CatalogOperatorError(ValueError):
    pass


def _regular_absolute(path: str | Path, label: str) -> Path:
    value = Path(path)
    if not value.is_absolute() or value.is_symlink() or not value.is_file():
        raise CatalogOperatorError(f"{label} must be an existing absolute non-symlink file")
    return value


def _json(path: str | Path, label: str) -> tuple[Path, dict[str, Any]]:
    value = _regular_absolute(path, label)
    try:
        parsed = json.loads(value.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CatalogOperatorError(f"{label} must be valid JSON") from error
    if not isinstance(parsed, dict):
        raise CatalogOperatorError(f"{label} must be a JSON object")
    return value, parsed


def _canonical_json_sha256(path: Path) -> str:
    """Hash JSON semantics, not checkout-dependent whitespace or line endings."""
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
        canonical = json.dumps(document, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    except (OSError, ValueError, TypeError) as error:
        raise CatalogOperatorError("reviewed evidence must be canonicalizable JSON") from error
    return hashlib.sha256(canonical).hexdigest()


def _utc(value: Any, label: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, ValueError) as error:
        raise CatalogOperatorError(f"{label} must be RFC3339") from error
    if parsed.tzinfo is None:
        raise CatalogOperatorError(f"{label} must include a timezone")
    return parsed.astimezone(timezone.utc)


def import_entry(**kwargs: Any) -> dict[str, Any]:
    """Check and apply the idempotent profile import.  No provider state changes occur."""
    # Reproduce check validation with an isolated in-memory catalog so --check never writes.
    catalog_path = _regular_absolute(kwargs["catalog_db"], "catalog database")
    hardware_path = _regular_absolute(kwargs["hardware_db"], "hardware database")
    providers_path = _regular_absolute(kwargs["providers_db"], "providers database")
    _, entry = _json(kwargs["entry_file"], "catalog entry"); _, proof = _json(kwargs["provider_evidence_file"], "provider evidence")
    profile_path = _regular_absolute(kwargs["reviewed_profile_file"], "reviewed profile"); lock_path = _regular_absolute(kwargs["model_lock_file"], "model lock")
    now = (kwargs.get("clock") or (lambda: datetime.now(timezone.utc)))().astimezone(timezone.utc)
    source = entry.get("source_evidence")
    if not isinstance(source, Mapping) or source.get("reviewed_profile_canonical_json_sha256") != _canonical_json_sha256(profile_path) or source.get("model_lock_canonical_json_sha256") != _canonical_json_sha256(lock_path): raise CatalogOperatorError("catalog source evidence does not bind the supplied reviewed files")
    required={"schema","provider_id","generation","model_id","revision","health","reviewed_profile_canonical_json_sha256","model_lock_canonical_json_sha256"}
    health=proof.get("health")
    if proof.get("schema")!="agent-stack.provider-catalog-evidence.v1" or set(proof)!=required or proof.get("model_id")!=entry.get("model_id") or proof.get("revision")!=entry.get("revision") or proof.get("reviewed_profile_canonical_json_sha256")!=source.get("reviewed_profile_canonical_json_sha256") or proof.get("model_lock_canonical_json_sha256")!=source.get("model_lock_canonical_json_sha256") or not isinstance(health,Mapping) or set(health)!={"status","observed_at","lease_expires_at"} or health.get("status")!="healthy" or _utc(health.get("observed_at"),"health observed_at")>now or _utc(health.get("lease_expires_at"),"health lease_expires_at")<=now: raise CatalogOperatorError("provider evidence is invalid or not fresh")
    provider=ProviderRegistry(providers_path,HardwareRegistry(hardware_path,clock=lambda:now),clock=lambda:now).get(proof["provider_id"])
    if provider is None or provider["generation"]!=proof["generation"] or provider["role"]!="inference" or provider["health"] is None or any(provider["health"].get(k)!=health.get(k) for k in health) or provider["health"].get("provider_generation")!=proof["generation"]: raise CatalogOperatorError("provider evidence does not exactly match registry health")
    candidate={**entry,"availability":{"provider_id":proof["provider_id"],"generation":proof["generation"],"model_id":entry["model_id"],"revision":entry["revision"],"tested":True,"lease_expires_at":health["lease_expires_at"]}}
    ModelCapabilityCatalog.validate_entry(candidate)
    if kwargs.get("apply"): ModelCapabilityCatalog(catalog_path,clock=lambda:now).register(candidate)
    return {"state":"imported" if kwargs.get("apply") else "checked","model_id":entry["model_id"],"revision":entry["revision"],"provider_id":proof["provider_id"],"generation":proof["generation"],"lease_expires_at":health["lease_expires_at"]}


def main(argv: list[str] | None = None) -> int:
    parser=argparse.ArgumentParser(description="Check or import reviewed model catalog evidence; never controls inference")
    for name in ("catalog-db","hardware-db","providers-db","entry-file","provider-evidence-file","reviewed-profile-file","model-lock-file"): parser.add_argument("--"+name,required=True)
    parser.add_argument("--apply",action="store_true",help="write only after all checks pass (default is check-only)")
    args=parser.parse_args(argv)
    try: result=import_entry(**{key.replace("_","-").replace("-","_"):value for key,value in vars(args).items()})
    except (CatalogOperatorError, ValueError) as error: parser.error(str(error))
    print(json.dumps(result,sort_keys=True)); return 0

if __name__ == "__main__": raise SystemExit(main())
