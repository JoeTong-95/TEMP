"""External-configured assignment executor composition.

Configured workers require the independent Storage verification service. The
direct ``AssignmentExecutor`` constructor retains its legacy compatibility
default for isolated unit callers, but this external worker never uses it.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import hashlib
import http.client
import json
import math
import re
import time
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import quote, urlsplit

from .project_assignment_executor import AssignmentExecutor, AgentBinding, AssignmentExecutorError
from .project_orchestrator_driver import HttpManagementAdapter, UnknownOutcome
from .project_orchestrator_worker import _safe_file, _token, _origin, WorkerConfigError
from shared.contracts.agent_runtime import RuntimeAdmissionRejected, RuntimeBinding, RuntimeClient, RuntimeOutcomeUnknown, RuntimeClientError
from shared.contracts.project_verification import MAX_VERIFICATION_ENVELOPE_BYTES, MAX_VERIFICATION_OUTPUT_BYTES
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root

_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_MAX_PARALLELISM = 32
_MAX_VERIFICATION_OUTPUT = MAX_VERIFICATION_OUTPUT_BYTES
_MAX_VERIFICATION_RESPONSE = MAX_VERIFICATION_ENVELOPE_BYTES
_VERIFICATION_ENVELOPE = {"operation_id", "project_id", "workspace_id", "command_id", "expected_input_tree_sha256", "state", "result"}


@dataclass(frozen=True)
class AssignmentVerificationConfiguration:
    base_url: str
    token_file: Path
    workspace_id: str
    command_id: str
    timeout_seconds: float = 30.0
    poll_interval_seconds: float = 0.1

    def __post_init__(self) -> None:
        origin = _origin(self.base_url)
        parsed = urlsplit(origin)
        if parsed.hostname not in {"127.0.0.1", "::1", "localhost"} or not isinstance(self.workspace_id, str) or _SAFE.fullmatch(self.workspace_id) is None or not isinstance(self.command_id, str) or _SAFE.fullmatch(self.command_id) is None or _safe_file(str(self.token_file)) != self.token_file or isinstance(self.timeout_seconds, bool) or not isinstance(self.timeout_seconds, (int, float)) or not math.isfinite(self.timeout_seconds) or not 0 < self.timeout_seconds <= 300 or isinstance(self.poll_interval_seconds, bool) or not isinstance(self.poll_interval_seconds, (int, float)) or not math.isfinite(self.poll_interval_seconds) or not 0 < self.poll_interval_seconds <= 2:
            raise WorkerConfigError("assignment verification configuration is invalid")


class StorageVerificationClient:
    """Authenticated client for Storage's isolated verification service."""

    def __init__(self, configuration: AssignmentVerificationConfiguration, project_id: str) -> None:
        self.configuration = configuration
        self.project_id = project_id
        self.token = _token(str(configuration.token_file))

    def _request(self, method: str, path: str, body: Mapping[str, Any] | None = None) -> Mapping[str, Any]:
        parsed = urlsplit(self.configuration.base_url)
        connection = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, timeout=min(30.0, self.configuration.timeout_seconds)) if parsed.scheme == "https" else http.client.HTTPConnection(parsed.hostname, parsed.port or 80, timeout=min(30.0, self.configuration.timeout_seconds))
        headers = {"Authorization": "Bearer " + self.token, "Accept": "application/json", "Content-Type": "application/json", "X-Project-Id": self.project_id}
        raw = json.dumps(dict(body), sort_keys=True, separators=(",", ":")).encode("utf-8") if body is not None else None
        try:
            connection.request(method, path, raw, headers)
            response = connection.getresponse()
            payload = response.read(_MAX_VERIFICATION_RESPONSE + 1)
        except (OSError, ValueError) as error:
            raise UnknownOutcome("verification outcome is unknown") from error
        finally:
            connection.close()
        if len(payload) > _MAX_VERIFICATION_RESPONSE:
            raise UnknownOutcome("verification response exceeded bounds")
        if response.status in {401, 403, 409}:
            raise AssignmentExecutorError("verification request was rejected")
        if response.status < 200 or response.status >= 300:
            raise UnknownOutcome("verification response is unavailable")
        try:
            value = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise UnknownOutcome("verification response is malformed") from error
        if not isinstance(value, Mapping):
            raise UnknownOutcome("verification response is malformed")
        return value

    def verify(self, assignment: Mapping[str, Any], *, project_id: str, revision: int, request_id: str, effect_receipt: str, message: str) -> Mapping[str, Any]:
        digest = assignment.get("verification_input_tree_sha256")
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise AssignmentExecutorError("assignment has no approved verification input digest")
        operation_id = "verification-" + hashlib.sha256((project_id + ":" + str(revision) + ":" + assignment["assignment_id"] + ":" + digest).encode()).hexdigest()[:48]
        request = {"operation_id": operation_id, "project_id": project_id, "workspace_id": self.configuration.workspace_id, "command_id": self.configuration.command_id, "expected_input_tree_sha256": digest}
        evidence = self._request("POST", "/operations", request)
        deadline = time.monotonic() + self.configuration.timeout_seconds
        while True:
            if not isinstance(evidence, Mapping) or set(evidence) != _VERIFICATION_ENVELOPE or any(evidence.get(key) != value for key, value in request.items()):
                raise AssignmentExecutorError("verification evidence identity is invalid")
            state = evidence.get("state")
            if not isinstance(state, str):
                raise AssignmentExecutorError("verification evidence state is invalid")
            if state in {"accepted", "running"} and evidence.get("result") is not None:
                raise AssignmentExecutorError("verification evidence envelope is invalid")
            if state == "unknown":
                raise UnknownOutcome("verification outcome is unknown")
            if state in {"completed", "failed"}:
                result = evidence.get("result")
                required = {"exit_code", "result", "input_tree_sha256", "output_sha256"}
                allowed = required | {"output"}
                valid_result = isinstance(result, Mapping) and required.issubset(result) and not set(result) - allowed and type(result.get("exit_code")) is int and result.get("exit_code") == 0 and result.get("result") == "passed" and result.get("input_tree_sha256") == digest and isinstance(result.get("input_tree_sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", result["input_tree_sha256"]) is not None and isinstance(result.get("output_sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", result["output_sha256"]) is not None and ("output" not in result or isinstance(result["output"], str) and len(result["output"].encode("utf-8")) <= _MAX_VERIFICATION_OUTPUT)
                if state != "completed" or not valid_result:
                    raise AssignmentExecutorError("independent verification did not pass")
                verified = dict(evidence)
                verified["verification_receipt"] = "verification-" + hashlib.sha256(json.dumps(evidence, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()[:48]
                return verified
            if state not in {"accepted", "running"}:
                raise AssignmentExecutorError("verification evidence is invalid")
            if time.monotonic() >= deadline:
                raise UnknownOutcome("verification did not reach a terminal state")
            time.sleep(self.configuration.poll_interval_seconds)
            evidence = self._request("GET", "/operations/" + quote(operation_id, safe=""))


@dataclass(frozen=True)
class AssignmentWorkerConfiguration:
    management_base_url: str
    management_token_file: Path
    journal_database: Path
    project_id: str
    revision: int
    intent_id: str
    agents: Mapping[str, RuntimeBinding]
    max_parallelism: int | None = None
    resource_bounds: Mapping[str, int | float] = field(default_factory=dict)
    verification: AssignmentVerificationConfiguration | None = None
    state_root: Path | None = None

    def __post_init__(self) -> None:
        try:
            journal_path = Path(self.journal_database)
            state_root = validate_state_root(self.state_root if self.state_root is not None else journal_path.parent, "assignment state root")
            journal_database = validate_durable_leaf(journal_path, state_root, label="assignment journal database")
        except (ManagementStateBoundaryError, TypeError) as error:
            raise WorkerConfigError("assignment worker journal is unsafe") from error
        if _origin(self.management_base_url) != self.management_base_url or _safe_file(str(self.management_token_file)) != self.management_token_file or not isinstance(self.project_id, str) or _SAFE.fullmatch(self.project_id) is None or type(self.revision) is not int or self.revision < 1 or not isinstance(self.intent_id, str) or _SAFE.fullmatch(self.intent_id) is None or not self.agents or any(key != value.binding_id and not isinstance(key, str) for key, value in self.agents.items()) or (self.max_parallelism is not None and (type(self.max_parallelism) is not int or not 1 <= self.max_parallelism <= _MAX_PARALLELISM)) or not isinstance(self.resource_bounds, Mapping) or len(self.resource_bounds) > 64 or any(not isinstance(key, str) or _SAFE.fullmatch(key) is None or isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0 for key, value in self.resource_bounds.items()) or (self.verification is not None and not isinstance(self.verification, AssignmentVerificationConfiguration)):
            raise WorkerConfigError("assignment worker configuration is invalid")
        object.__setattr__(self, "state_root", state_root)
        object.__setattr__(self, "journal_database", journal_database)


class ManagementProgressAdapter(HttpManagementAdapter):
    def progress(self, project_id, revision, *, idempotency_key, agent_id, assignment_id, progress):
        return self._request("POST", "/projects/" + project_id + "/orchestrator-loops/" + self.intent_id + "/progress", {"idempotency_key": idempotency_key, "agent_id": agent_id, "assignment_id": assignment_id, "progress": dict(progress)})


class RuntimeAssignmentAdapter:
    def __init__(self, client: RuntimeClient, project_id: str, revision: int): self.client, self.project_id, self.revision = client, project_id, revision
    def prepare(self, *, binding_id, session_id, assignment_id, immutable_revision, submission_fence):
        try:
            if self.client.binding_identity(binding_id).get("session_id") != session_id: raise AssignmentExecutorError("runtime session differs")
            return self.client.prepare_assignment_attempt(binding_id, project_id=self.project_id, revision_id=str(self.revision), immutable_revision=immutable_revision, assignment_id=assignment_id, submission_fence=submission_fence)
        except RuntimeOutcomeUnknown as error: raise UnknownOutcome("runtime preparation outcome unknown") from error
        except RuntimeAdmissionRejected as error: raise AssignmentExecutorError(error.reason) from error
        except RuntimeClientError as error: raise AssignmentExecutorError("runtime preparation definitively rejected") from error
    def reconcile(self, request_id, *, binding_id, session_id, message, attempt_id=None, immutable_revision=None, submission_fence=None):
        try: return self.client.operation(binding_id, request_id=request_id, project_id=self.project_id, revision_id=str(self.revision), message=message, attempt_id=attempt_id, immutable_revision=immutable_revision, submission_fence=submission_fence)
        except RuntimeOutcomeUnknown as error: raise UnknownOutcome("runtime outcome unknown") from error
        except RuntimeAdmissionRejected as error: raise AssignmentExecutorError(error.reason) from error
        except RuntimeClientError as error: raise AssignmentExecutorError("runtime definitively rejected") from error
    def submit(self, request_id, *, session_id, binding_id, message, attempt_id=None, immutable_revision=None, submission_fence=None):
        try:
            if self.client.binding_identity(binding_id).get("session_id") != session_id: raise AssignmentExecutorError("runtime session differs")
            return self.client.submit_turn(binding_id, request_id=request_id, project_id=self.project_id, revision_id=str(self.revision), message=message, attempt_id=attempt_id, immutable_revision=immutable_revision, submission_fence=submission_fence)
        except RuntimeOutcomeUnknown as error: raise UnknownOutcome("runtime outcome unknown") from error
        except RuntimeAdmissionRejected as error: raise AssignmentExecutorError(error.reason) from error
        except RuntimeClientError as error: raise AssignmentExecutorError("runtime definitively rejected") from error


def load_assignment_configuration(path: str | Path) -> AssignmentWorkerConfiguration:
    file = _safe_file(str(path))
    try: raw = json.loads(file.read_text(encoding="utf-8"), parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (OSError, ValueError, json.JSONDecodeError) as error: raise WorkerConfigError("assignment configuration is invalid") from error
    required = {"management_base_url", "management_token_file", "journal_database", "project_id", "revision", "intent_id", "agents", "timeout_seconds"}
    allowed = required | {"max_parallelism", "resource_bounds", "verification", "state_root"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or not set(raw).issubset(allowed) or not isinstance(raw.get("agents"), list) or not 1 <= len(raw["agents"]) <= 128 or type(raw.get("timeout_seconds")) not in {int, float} or not math.isfinite(raw["timeout_seconds"]) or not 0 < raw["timeout_seconds"] <= 30:
        raise WorkerConfigError("assignment configuration is invalid")
    agents = {}
    for value in raw["agents"]:
        if not isinstance(value, Mapping) or set(value) != {"agent_id", "binding_id", "base_url", "session_id", "token_file"}: raise WorkerConfigError("assignment agent configuration is invalid")
        binding = RuntimeBinding(value["binding_id"], _origin(value["base_url"]), value["session_id"], _token(value["token_file"]), raw["timeout_seconds"])
        agent = value["agent_id"]
        if not isinstance(agent, str) or _SAFE.fullmatch(agent) is None or agent in agents: raise WorkerConfigError("assignment agent configuration is invalid")
        agents[agent] = binding
    verification = None
    if "verification" in raw:
        value = raw["verification"]
        if not isinstance(value, Mapping) or set(value) - {"base_url", "token_file", "workspace_id", "command_id", "timeout_seconds", "poll_interval_seconds"} or not {"base_url", "token_file", "workspace_id", "command_id"}.issubset(value): raise WorkerConfigError("assignment verification configuration is invalid")
        try: verification = AssignmentVerificationConfiguration(_origin(value["base_url"]), _safe_file(value["token_file"]), value["workspace_id"], value["command_id"], value.get("timeout_seconds", 30.0), value.get("poll_interval_seconds", 0.1))
        except (KeyError, TypeError, ValueError) as error: raise WorkerConfigError("assignment verification configuration is invalid") from error
    return AssignmentWorkerConfiguration(_origin(raw["management_base_url"]), _safe_file(raw["management_token_file"]), Path(raw["journal_database"]), raw["project_id"], raw["revision"], raw["intent_id"], agents, raw.get("max_parallelism"), raw.get("resource_bounds", {}), verification, Path(raw["state_root"]) if "state_root" in raw else None)


def run_assignment_tick(config: AssignmentWorkerConfiguration) -> dict[str, Any]:
    if config.verification is None:
        raise WorkerConfigError("external assignment execution requires independent verification")
    management = ManagementProgressAdapter(config.management_base_url, _token(str(config.management_token_file)), config.intent_id)
    runtime = RuntimeAssignmentAdapter(RuntimeClient({binding.binding_id: binding for binding in config.agents.values()}), config.project_id, config.revision)
    bindings = {agent: AgentBinding(agent, binding.binding_id, binding.session_id) for agent, binding in config.agents.items()}
    verifier = StorageVerificationClient(config.verification, config.project_id)
    return AssignmentExecutor(config.journal_database, config.project_id, config.revision, bindings, management, runtime, max_parallelism=config.max_parallelism, resource_bounds=config.resource_bounds, verification=verifier, verification_required=True, state_root=config.state_root).tick()


def prefect_assignment_tick(config_path: str) -> dict[str, Any]: return run_assignment_tick(load_assignment_configuration(config_path))
def main(argv=None):
    parser = argparse.ArgumentParser(); parser.add_argument("--config", required=True); args = parser.parse_args(argv); print(json.dumps(prefect_assignment_tick(args.config), sort_keys=True, separators=(",", ":"))); return 0
if __name__ == "__main__": raise SystemExit(main())
