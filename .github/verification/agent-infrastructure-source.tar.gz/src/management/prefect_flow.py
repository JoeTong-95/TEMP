"""Optional Prefect 3 adapter for the neutral, owned fixture flow.

This is deliberately separate from :mod:`management.canary`: ``fixture`` is a
local canary runtime, while this module only labels work ``prefect`` after a
real Prefect flow has reported its runtime flow-run id.  It refuses cloud,
implicit, and ephemeral endpoints.  Prefect remains the workflow/retry owner;
the command journal only correlates the logical request with the native run.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
from typing import Any
from urllib.parse import urlsplit
from uuid import UUID

from .fixture import ArtifactIntegrityError, FixtureError, FixtureService, lookup_fixture
from .journal import CommandJournal, RequestConflict, StaleTransition
from .workflow import WorkflowEdge, WorkflowNode, WorkflowSpec

try:  # Keep the stdlib-only local test path usable when Prefect is absent.
    from prefect import flow, task
    from prefect import runtime as prefect_runtime
    from prefect.settings import PREFECT_API_URL, PREFECT_SERVER_ALLOW_EPHEMERAL_MODE, temporary_settings
except ImportError:  # pragma: no cover - covered by environments without Prefect
    PREFECT_AVAILABLE = False
else:
    PREFECT_AVAILABLE = True


_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


class PrefectAdapterUnavailable(RuntimeError):
    """The optional Prefect dependency is not installed in this environment."""


class PrefectConfigurationError(ValueError):
    """The requested API endpoint is not an explicit local Prefect server."""


class ReconciliationRequired(RuntimeError):
    """An effect may have happened; inspect its receipt rather than rerun it."""


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def _validate_input(project_id: object, value: object) -> tuple[str, int]:
    if not isinstance(project_id, str) or not _IDENTIFIER.fullmatch(project_id):
        raise ValueError("project_id must be a safe fixture identifier")
    if isinstance(value, bool) or not isinstance(value, int) or abs(value) > 1_000_000:
        raise ValueError("value must be a bounded fixture integer")
    return project_id, value


def _loopback_api_url(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise PrefectConfigurationError("an explicit PREFECT_API_URL or --prefect-api-url is required")
    parsed = urlsplit(value)
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"} or parsed.path.rstrip("/") != "/api":
        raise PrefectConfigurationError("Prefect smoke requires an explicit loopback http://127.0.0.1:<port>/api endpoint")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise PrefectConfigurationError("Prefect API URL must not contain credentials, query, or fragment")
    return value.rstrip("/")


def _scope(project_id: str, spec: WorkflowSpec) -> dict[str, str]:
    return {"project_id": project_id, "runtime_kind": "prefect", "workflow_version_hash": spec.version_hash}


def default_prefect_workflow_spec() -> WorkflowSpec:
    """The same declared v1 graph, without importing or invoking the local canary."""
    return WorkflowSpec(
        nodes=(
            WorkflowNode("input", "input", output_type="fixture_payload"),
            WorkflowNode("tool", "tool", input_type="fixture_payload", output_type="fixture_result", config={"operation": "sum"}),
            WorkflowNode("artifact", "artifact", input_type="fixture_result"),
        ),
        edges=(
            WorkflowEdge("input", "tool", "fixture_payload"),
            WorkflowEdge("tool", "artifact", "fixture_result"),
        ),
    )


def _expected(value: int) -> dict[str, int]:
    """A fixed evaluator, deliberately outside the effect-bearing task."""
    return {"sum": value, "count": 1}


def _evidence(result: dict[str, object], graph_hash: str, flow_run_id: str) -> dict[str, str]:
    return {
        "artifact_reference": str(result["artifact_reference"]),
        "artifact_sha256": str(result["artifact_sha256"]),
        "runtime_kind": "prefect",
        "workflow_version_hash": graph_hash,
        "prefect_flow_run_id": flow_run_id,
    }


def _native_flow_run_id(value: object) -> str:
    """Accept only a nonempty Prefect UUID, never a caller-invented label."""
    if not isinstance(value, str):
        raise ArtifactIntegrityError("Prefect native flow-run id is absent")
    try:
        UUID(value)
    except (ValueError, AttributeError) as error:
        raise ArtifactIntegrityError("Prefect native flow-run id is not a UUID") from error
    return value


if PREFECT_AVAILABLE:

    @task(name="fixture-effect", retries=0, persist_result=True, result_serializer="json")
    def execute_fixture_effect(storage_root: str, project_id: str, effect_id: str, payload_json: str) -> str:
        """The sole effect-bearing stage: it is explicitly never retried by Prefect."""
        payload = json.loads(payload_json)
        result = FixtureService(storage_root).execute(project_id, effect_id, payload)
        return _json(result)


    @task(name="verify-fixture-evidence", retries=0, persist_result=True, result_serializer="json")
    def verify_fixture_evidence(
        storage_root: str, project_id: str, effect_id: str, payload_json: str,
        result_json: str, expected_json: str,
    ) -> str:
        """Read-only receipt/artifact verification with fixed expected output criteria."""
        payload = json.loads(payload_json)
        produced = json.loads(result_json)
        expected = json.loads(expected_json)
        receipt = lookup_fixture(storage_root, project_id, effect_id, payload)
        if receipt is None or receipt != produced or receipt.get("output") != expected:
            raise ArtifactIntegrityError("fixture result fails independently checked receipt/artifact evidence")
        return _json(receipt)


    @flow(name="agent-stack-prefect-fixture-v1", retries=0, persist_result=True,
          result_serializer="json", validate_parameters=False)
    def prefect_fixture_flow(
        storage_root: str, project_id: str, effect_id: str, payload_json: str,
        expected_json: str, workflow_version_hash: str,
    ) -> str:
        """Run the typed fixture effect and return a JSON-safe native correlation envelope."""
        flow_run_id = str(prefect_runtime.flow_run.id)
        produced = execute_fixture_effect(storage_root, project_id, effect_id, payload_json)
        verified = verify_fixture_evidence(storage_root, project_id, effect_id, payload_json, produced, expected_json)
        return _json({
            "prefect_flow_run_id": flow_run_id,
            "result": json.loads(verified),
            "runtime_kind": "prefect",
            "workflow_version_hash": workflow_version_hash,
        })


def _decode_flow_result(value: object, graph_hash: str) -> tuple[str, dict[str, object]]:
    if not isinstance(value, str):
        raise ArtifactIntegrityError("Prefect flow did not return its JSON result envelope")
    try:
        envelope = json.loads(value)
    except json.JSONDecodeError as error:
        raise ArtifactIntegrityError("Prefect flow returned malformed JSON") from error
    if not isinstance(envelope, dict) or set(envelope) != {"prefect_flow_run_id", "result", "runtime_kind", "workflow_version_hash"}:
        raise ArtifactIntegrityError("Prefect flow returned an unexpected result envelope")
    run_id, result = envelope["prefect_flow_run_id"], envelope["result"]
    if envelope["runtime_kind"] != "prefect" or envelope["workflow_version_hash"] != graph_hash or not isinstance(result, dict):
        raise ArtifactIntegrityError("Prefect flow result envelope failed validation")
    return _native_flow_run_id(run_id), result


def run_prefect_smoke(
    state_dir: str | Path, request_id: str, project_id: str, value: int, prefect_api_url: str,
    spec: WorkflowSpec,
) -> dict[str, Any]:
    """Run one real local Prefect flow against an explicitly supplied loopback API.

    The caller must start the Prefect server separately.  Setting both a supplied
    API URL and ``PREFECT_SERVER_ALLOW_EPHEMERAL_MODE=False`` prevents this adapter
    from silently starting an ephemeral server or using a Cloud profile.
    """
    if not PREFECT_AVAILABLE:
        raise PrefectAdapterUnavailable("Prefect is not installed; install the pinned runtime before smoke testing")
    project_id, value = _validate_input(project_id, value)
    api_url = _loopback_api_url(prefect_api_url)
    spec.validate()
    graph_hash = spec.version_hash
    root = Path(state_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    payload = {"value": value}
    journal = CommandJournal(root / "command-journal.sqlite3")
    submission = journal.accept(request_id, _scope(project_id, spec), {"value": value, "workflow_version_hash": graph_hash})
    record = submission.record
    if record.state == "completed":
        result = lookup_fixture(root / "fixture", project_id, request_id, payload)
        flow_run_id = _native_flow_run_id(record.native_run_id)
        expected_evidence = _evidence(result, graph_hash, flow_run_id) if result is not None else None
        if (result is None or result.get("output") != _expected(value)
                or not isinstance(record.detail, dict) or record.detail != expected_evidence):
            raise ArtifactIntegrityError("completed Prefect journal evidence does not match the receipt")
        return {"journal_state": "completed", "replayed": True, "request_id": request_id,
                "runtime_kind": "prefect", "result": result, "prefect_flow_run_id": flow_run_id}
    if record.state in {"dispatching", "submitted", "unknown"}:
        raise ReconciliationRequired("request is in flight or ambiguous; reconcile its receipt before another execution")
    if record.state == "failed":
        return {"journal_state": "failed", "replayed": True, "request_id": request_id,
                "runtime_kind": "prefect", "detail": record.detail}
    claimant = "prefect-smoke-v1"
    claim = journal.claim_dispatch(request_id, claimant)
    if claim is None:
        raise ReconciliationRequired("another dispatcher owns this request; reconcile before retrying")
    try:
        # The settings context scopes the explicit server URL to this call only.
        with temporary_settings(updates={PREFECT_API_URL: api_url, PREFECT_SERVER_ALLOW_EPHEMERAL_MODE: False}):
            envelope = prefect_fixture_flow(
                str(root / "fixture"), project_id, request_id, _json(payload), _json(_expected(value)), graph_hash,
            )
        flow_run_id, result = _decode_flow_result(envelope, graph_hash)
        # The authoritative native id comes from prefect.runtime.flow_run inside the flow.
        journal.mark_submitted(request_id, claim.claimant, claim.generation, flow_run_id)
        evidence = _evidence(result, graph_hash, flow_run_id)
        journal.reconcile_outcome(request_id, "completed", evidence)
    except Exception as error:
        try:
            journal.mark_unknown(request_id, claim.claimant, claim.generation, {"error": type(error).__name__})
        except StaleTransition:
            pass
        raise
    return {"journal_state": "completed", "replayed": False, "request_id": request_id,
            "runtime_kind": "prefect", "result": result, "prefect_flow_run_id": flow_run_id,
            "evidence": evidence}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the optional local Prefect fixture smoke flow")
    parser.add_argument("--state-dir", required=True)
    parser.add_argument("--request-id", required=True)
    parser.add_argument("--project-id", required=True)
    parser.add_argument("--value", required=True, type=int)
    parser.add_argument("--prefect-api-url", default=os.environ.get("PREFECT_API_URL"),
                        help="required loopback Prefect API URL; PREFECT_API_URL is accepted when explicitly set")
    args = parser.parse_args(argv)
    try:
        print(_json(run_prefect_smoke(args.state_dir, args.request_id, args.project_id, args.value,
                                      args.prefect_api_url, default_prefect_workflow_spec())))
    except (PrefectAdapterUnavailable, PrefectConfigurationError, ReconciliationRequired,
            RequestConflict, FixtureError, StaleTransition, ValueError) as error:
        print(_json({"error": type(error).__name__, "message": str(error), "runtime_kind": "prefect"}))
        return 2
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
