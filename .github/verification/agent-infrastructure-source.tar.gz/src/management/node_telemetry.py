"""Explicit, node-local telemetry publishing tick; not a daemon or health claim."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import math
import os
from pathlib import Path
import tempfile
import time
from typing import Any, Callable, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


Collector = Callable[..., dict[str, Any]]
Sender = Callable[[str, str, Mapping[str, Any]], int]


class TelemetryPublisherError(ValueError):
    """A configuration error that is safe to expose without credentials."""


@dataclass(frozen=True)
class NodeTelemetryConfig:
    hardware_node_id: str
    host_boot_id: str
    registration: Mapping[str, Any]
    endpoint: str
    node_token: str = field(repr=False)
    state_dir: Path
    cadence_seconds: int = 10
    retry_base_seconds: float = 1.0
    retry_max_seconds: float = 60.0
    request_timeout_seconds: float = 3.0

    def __post_init__(self) -> None:
        parsed = urlsplit(self.endpoint)
        if not self.hardware_node_id or not self.host_boot_id or not self.node_token:
            raise TelemetryPublisherError("node identity and injected token are required")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise TelemetryPublisherError("endpoint must not contain credentials, query, or fragment")
        if parsed.scheme == "http":
            if parsed.hostname not in {"127.0.0.1", "::1"}:
                raise TelemetryPublisherError("HTTP is permitted only for an exact loopback literal")
        elif parsed.scheme != "https":
            raise TelemetryPublisherError("endpoint must use HTTPS, except isolated loopback HTTP")
        if not parsed.hostname:
            raise TelemetryPublisherError("endpoint host is required")
        if parsed.path not in {"", "/"}:
            raise TelemetryPublisherError("endpoint must be an origin root, not an API path")
        # Linux cannot prove filesystem locality here; the operator must select a
        # local mount. Reject obvious Windows network paths and indirection.
        state_text = str(self.state_dir)
        if state_text.startswith("\\\\") or self.state_dir.is_symlink() or not self.state_dir.is_dir():
            raise TelemetryPublisherError("state_dir must be an existing node-local directory")
        if not isinstance(self.registration, Mapping):
            raise TelemetryPublisherError("registration must be an object")
        identity = self.registration.get("node_identity")
        if self.registration.get("node_id") != self.hardware_node_id or not isinstance(identity, Mapping) or identity.get("host_boot_id") != self.host_boot_id:
            raise TelemetryPublisherError("registration identity must match configured node and boot")
        if type(self.cadence_seconds) is not int or self.cadence_seconds < 1 or any(not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value <= 0 for value in (self.retry_base_seconds, self.retry_max_seconds, self.request_timeout_seconds)) or self.retry_max_seconds < self.retry_base_seconds:
            raise TelemetryPublisherError("cadence, retry, and timeout bounds are invalid")


class NodeTelemetryPublisher:
    """One caller-driven tick at a time; it does not report connection health.

    The orchestrator must ensure exactly one publisher owns a node state directory;
    this compact seam makes no multi-thread or multi-process writer guarantee.
    """

    def __init__(self, config: NodeTelemetryConfig, collector: Collector, *, sender: Sender | None = None, monotonic: Callable[[], float] = time.monotonic) -> None:
        self.config = config
        self.collector = collector
        self.sender = sender or self._send
        self.monotonic = monotonic
        self._started = False
        self._state_path = config.state_dir / "node-telemetry-publisher.json"
        self._state = self._load_state()

    def tick(self) -> dict[str, Any]:
        """Attempt registration then publish one new sample, respecting bounded backoff."""
        now = float(self.monotonic())
        if not math.isfinite(now):
            raise TelemetryPublisherError("monotonic clock must be finite")
        if now < self._state.get("next_retry_at", 0.0):
            return {"status": "backoff", "pending": bool(self._state.get("pending"))}
        if now < self._state.get("next_cadence_at", 0.0):
            return {"status": "cadence-wait", "pending": False}
        if not self._started:
            self._state["pending"] = {"kind": "registration"}
            self._persist()
            if not self._post("/hardware/nodes/register", self.config.registration, now):
                return {"status": "pending-registration", "pending": True}
            self._state.pop("pending", None)
            self._started = True
        sequence = int(self._state.get("next_sequence", 0))
        sample = self.collector(hardware_node_id=self.config.hardware_node_id, host_boot_id=self.config.host_boot_id, sequence=sequence, cadence_seconds=self.config.cadence_seconds)
        if not isinstance(sample, dict) or sample.get("hardware_node_id") != self.config.hardware_node_id or sample.get("host_boot_id") != self.config.host_boot_id or sample.get("sequence") != sequence:
            raise TelemetryPublisherError("collector returned a mismatched sample")
        # Persist before transport: a crash after remote acceptance is unknown and
        # must never cause reuse of this sequence with changed content.
        self._state["next_sequence"] = sequence + 1
        self._state["last_sample"] = sample
        self._state["pending"] = {"kind": "telemetry", "sequence": sequence, "sample_id": sample.get("sample_id")}
        self._persist()
        published = self._post("/hardware/telemetry", sample, now)
        if published:
            self._state.pop("pending", None)
            self._state["failure_count"] = 0
            self._state["next_retry_at"] = 0.0
            self._state["next_cadence_at"] = now + self.config.cadence_seconds
            self._persist()
            return {"status": "published", "sequence": sequence, "pending": False}
        self._persist()
        return {"status": "pending", "sequence": sequence, "pending": True}

    def _post(self, path: str, payload: Mapping[str, Any], now: float) -> bool:
        try:
            status = self.sender(self.config.endpoint.rstrip("/") + path, self.config.node_token, payload)
            if status not in ({200} if path.endswith("register") else {202}):
                raise OSError("unexpected status")
            return True
        except (OSError, ValueError, HTTPError, URLError):
            failures = int(self._state.get("failure_count", 0)) + 1
            self._state["failure_count"] = failures
            self._state["next_retry_at"] = now + min(self.config.retry_max_seconds, self.config.retry_base_seconds * (2 ** min(failures - 1, 16)))
            self._persist()
            return False

    def _load_state(self) -> dict[str, Any]:
        if not self._state_path.exists():
            return {"node_id": self.config.hardware_node_id, "host_boot_id": self.config.host_boot_id, "next_sequence": 0, "failure_count": 0, "next_retry_at": 0.0, "next_cadence_at": 0.0}
        if self._state_path.is_symlink():
            raise TelemetryPublisherError("publisher state must not be a symlink")
        try:
            data = json.loads(self._state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            raise TelemetryPublisherError("publisher state is corrupt") from None
        if not isinstance(data, dict) or data.get("node_id") != self.config.hardware_node_id or data.get("host_boot_id") != self.config.host_boot_id:
            raise TelemetryPublisherError("publisher state does not match configured node boot identity")
        for name in ("next_sequence", "failure_count"):
            if type(data.get(name)) is not int or data[name] < 0:
                raise TelemetryPublisherError("publisher state has invalid counters")
        if data.get("pending") is not None and not isinstance(data["pending"], dict):
            raise TelemetryPublisherError("publisher state has invalid pending record")
        # Monotonic times are process-local and cannot survive a reboot.
        data["next_retry_at"] = 0.0
        data["next_cadence_at"] = 0.0
        return data

    def _persist(self) -> None:
        # Token and endpoint are deliberately not part of this node-local journal.
        serializable = {name: value for name, value in self._state.items() if name not in {"next_retry_at", "next_cadence_at"}}
        descriptor, name = tempfile.mkstemp(prefix=".node-telemetry-", dir=self.config.state_dir)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(serializable, handle, sort_keys=True, separators=(",", ":"), allow_nan=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(name, self._state_path)
            if os.name != "nt":
                directory_fd = os.open(self.config.state_dir, os.O_RDONLY | os.O_DIRECTORY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
        finally:
            Path(name).unlink(missing_ok=True)

    def _send(self, url: str, token: str, payload: Mapping[str, Any]) -> int:
        body = json.dumps(payload, separators=(",", ":"), allow_nan=False).encode("utf-8")
        request = Request(url, data=body, method="POST", headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"})
        opener = build_opener(_NoRedirect())
        with opener.open(request, timeout=self.config.request_timeout_seconds) as response:
            return int(response.status)


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *_args: Any, **_kwargs: Any) -> None:
        return None
