"""Durable safe-withdrawal state machine for software graph nodes.

This is deliberately a control-plane journal: callers perform the actual drain,
checkpoint, detach and resource-release work, then submit verifiable receipts.
It never force-stops a workload and it never deletes Storage-owned data.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
import sqlite3
import threading
from pathlib import Path
import time
from typing import Any, Callable, Literal, Mapping
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


NodeKind = Literal["inference", "storage"]
_WITHDRAW_PHASES = ("finish_loop", "checkpoint_verify", "detach", "release_resources")
_RESTORE_PHASES = ("validate_checkpoint", "reconnect", "verify")
_WITHDRAW_EVIDENCE = {
    "finish_loop": "loop_finished",
    "checkpoint_verify": "checkpoint_verified",
    "detach": "detached",
    "release_resources": "resources_released",
}
_RESTORE_EVIDENCE = {
    "validate_checkpoint": "checkpoint_verified",
    "reconnect": "provider_reconnected",
    "verify": "state_verified",
}


class SoftwareNodeLifecycleError(ValueError):
    pass


class SoftwareNodeLifecycleConflict(SoftwareNodeLifecycleError):
    pass


def _serialized(method):
    """Serialize operations on the injected single-writer journal instance."""
    def wrapped(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return wrapped


@dataclass(frozen=True)
class SoftwareNodeLifecycleOperation:
    operation_id: str
    node_id: str
    kind: NodeKind
    state: str
    phase: str | None
    progress: int
    generation: int
    visibility: str
    error: str | None
    checkpoint_id: str | None
    provider_id: str | None

    def projection(self) -> dict[str, Any]:
        # A cancelled operation has explicitly returned ownership to the node;
        # it must not continue to look withdrawn in the operator projection.
        withdrawing = self.state in {"WITHDRAWING", "FAILED", "RESTORING"}
        actions = []
        if self.state == "WITHDRAWING": actions.append("cancel")
        if self.state == "FAILED": actions.extend(("retry", "cancel"))
        if self.state == "WITHDRAWN": actions.append("restore")
        return {
            "node_id": self.node_id, "kind": self.kind,
            "visibility": self.visibility,
            "lifecycle": {"operation_id": self.operation_id, "state": self.state,
                          "phase": self.phase, "progress": self.progress,
                          "generation": self.generation, "can_cancel": self.state == "WITHDRAWING",
                          "actions": actions, "error": self.error,
                          "checkpoint_id": self.checkpoint_id,
                          "provider_id": self.provider_id,
                          "retention": {"data": self.kind == "storage", "repositories": self.kind == "storage", "backups": self.kind == "storage"},
                          "appearance": "darkened" if withdrawing else "normal"},
        }


class SoftwareNodeLifecycleJournal:
    """SQLite operation journal requiring human confirmation and verified receipts."""
    def __init__(self, path: str | Path, *, clock: Callable[[], float] = time.time) -> None:
        self._clock = clock
        self._lock = threading.RLock()
        database_path = Path(path)
        try:
            state_root = validate_state_root(database_path.parent, "software node lifecycle state root")
            database = validate_durable_leaf(database_path, state_root, label="software node lifecycle database")
        except ManagementStateBoundaryError as error:
            raise SoftwareNodeLifecycleError(str(error)) from error
        # ManagementApiServer uses a bounded ThreadingHTTPServer.  The journal
        # remains the single durable writer, but its injected instance may be
        # called by more than one request thread; SQLite's connection affinity
        # must therefore be disabled (the WAL transaction boundaries provide
        # the actual durability/serialization).
        self._db = sqlite3.connect(str(database), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.executescript("""
        CREATE TABLE IF NOT EXISTS software_node_operations (
          operation_id TEXT PRIMARY KEY, node_id TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('inference','storage')),
          confirmation_sha256 TEXT NOT NULL, state TEXT NOT NULL, phase TEXT, progress INTEGER NOT NULL,
          generation INTEGER NOT NULL, visibility TEXT NOT NULL, error TEXT, checkpoint_id TEXT, provider_id TEXT,
          payload_sha256 TEXT NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS software_node_evidence (
          id INTEGER PRIMARY KEY AUTOINCREMENT, operation_id TEXT NOT NULL REFERENCES software_node_operations(operation_id),
          phase TEXT NOT NULL, kind TEXT NOT NULL, value_json TEXT NOT NULL, observed_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS software_node_audit (
          id INTEGER PRIMARY KEY AUTOINCREMENT, operation_id TEXT NOT NULL REFERENCES software_node_operations(operation_id),
          event TEXT NOT NULL, detail_json TEXT NOT NULL, occurred_at REAL NOT NULL,
          actor_id TEXT NOT NULL DEFAULT 'local-stack', actor_role TEXT NOT NULL DEFAULT 'local_stack');
        """)
        # The journal was introduced before actor provenance was part of the
        # Management event contract.  Add the columns in-place for an existing
        # local journal; SQLite applies the defaults to historical rows.
        columns = {row[1] for row in self._db.execute("PRAGMA table_info(software_node_audit)")}
        if "actor_id" not in columns:
            self._db.execute("ALTER TABLE software_node_audit ADD COLUMN actor_id TEXT NOT NULL DEFAULT 'local-stack'")
        if "actor_role" not in columns:
            self._db.execute("ALTER TABLE software_node_audit ADD COLUMN actor_role TEXT NOT NULL DEFAULT 'local_stack'")
        self._db.commit()

    def close(self) -> None: self._db.close()

    @_serialized
    def withdraw(self, operation_id: str, node_id: str, kind: NodeKind, *, confirmation_receipt: str, expected_generation: int = 0, provider_id: str | None = None, actor_id: str = "local-stack", actor_role: str = "local_stack") -> SoftwareNodeLifecycleOperation:
        self._id(operation_id, "operation_id"); self._id(node_id, "node_id"); self._kind(kind)
        if provider_id is not None: self._id(provider_id, "provider_id")
        if not isinstance(confirmation_receipt, str) or len(confirmation_receipt) < 16:
            raise SoftwareNodeLifecycleError("a human sliding-confirmation receipt is required")
        if type(expected_generation) is not int or expected_generation < 0: raise SoftwareNodeLifecycleError("expected_generation must be a non-negative integer")
        if expected_generation != 0: raise SoftwareNodeLifecycleConflict("new withdrawal generation must be zero")
        payload = {"node_id": node_id, "kind": kind, "provider_id": provider_id, "confirmation_sha256": self._digest(confirmation_receipt)}
        encoded = self._json(payload)
        old = self._db.execute("SELECT * FROM software_node_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if old:
            if old["payload_sha256"] != self._digest(encoded): raise SoftwareNodeLifecycleConflict("operation_id replay conflicts")
            return self.operation(operation_id)
        now = self._now()
        self._db.execute(
            """INSERT INTO software_node_operations
               (operation_id,node_id,kind,confirmation_sha256,state,phase,
                progress,generation,visibility,error,checkpoint_id,provider_id,
                payload_sha256,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (operation_id, node_id, kind, payload["confirmation_sha256"],
             "WITHDRAWING", "finish_loop", 0, 0, "withdrawing", None, None,
             provider_id, self._digest(encoded), now, now),
        )
        self._audit(operation_id, "withdrawal_confirmed", {"kind": kind, "confirmation": "human_sliding_receipt"}, now, actor_id=actor_id, actor_role=actor_role)
        self._db.commit(); return self.operation(operation_id)

    @_serialized
    def record_evidence(self, operation_id: str, *, phase: str, kind: str, value: Any, observed_at: float | None = None, actor_id: str = "local-stack", actor_role: str = "local_stack") -> SoftwareNodeLifecycleOperation:
        op = self.operation(operation_id)
        valid = _WITHDRAW_EVIDENCE if op.state in {"WITHDRAWING", "FAILED"} else _RESTORE_EVIDENCE if op.state == "RESTORING" else None
        # Evidence is phase-scoped.  Accepting a receipt for a future phase
        # allows a caller to skip the drain/checkpoint/detach ordering.
        if valid is None or phase != op.phase or phase not in valid or kind != valid[phase] or type(value) is not bool:
            raise SoftwareNodeLifecycleError("evidence is invalid for the current lifecycle phase")
        if observed_at is not None and (type(observed_at) not in {int, float} or isinstance(observed_at, bool) or not math.isfinite(observed_at) or abs(observed_at) > 10**12):
            raise SoftwareNodeLifecycleError("evidence timestamp must be a finite bounded number")
        when = self._now() if observed_at is None else float(observed_at)
        if when > self._now(): raise SoftwareNodeLifecycleError("evidence cannot be future dated")
        self._db.execute("INSERT INTO software_node_evidence(operation_id,phase,kind,value_json,observed_at) VALUES(?,?,?,?,?)", (operation_id,phase,kind,self._json(value),when))
        if value is False:
            self._transition(op, "FAILED", phase, op.progress, error=kind + "_failed")
            self._audit(operation_id, "withdrawal_failed" if op.state != "RESTORING" else "restore_failed", {"phase":phase,"reason":kind}, when, actor_id=actor_id, actor_role=actor_role)
        self._db.commit(); return self.operation(operation_id)

    @_serialized
    def advance(self, operation_id: str, *, expected_generation: int, progress: int, actor_id: str = "local-stack", actor_role: str = "local_stack") -> SoftwareNodeLifecycleOperation:
        op = self.operation(operation_id)
        if op.generation != expected_generation: raise SoftwareNodeLifecycleConflict("lifecycle generation is stale")
        if op.state not in {"WITHDRAWING", "RESTORING"}: raise SoftwareNodeLifecycleConflict("operation cannot advance")
        phases = _WITHDRAW_PHASES if op.state == "WITHDRAWING" else _RESTORE_PHASES
        index = phases.index(op.phase or "")
        if type(progress) is not int or not op.progress <= progress <= 100: raise SoftwareNodeLifecycleError("progress must be monotonic from 0 through 100")
        evidence = _WITHDRAW_EVIDENCE if op.state == "WITHDRAWING" else _RESTORE_EVIDENCE
        latest = self._latest_bool(operation_id, op.phase or "", evidence[op.phase or ""])
        if progress < 100:
            self._transition(op, op.state, op.phase, progress); self._db.commit(); return self.operation(operation_id)
        if latest is not True: raise SoftwareNodeLifecycleConflict("phase completion needs a verified receipt")
        if index + 1 < len(phases): self._transition(op, op.state, phases[index+1], 0)
        elif op.state == "WITHDRAWING":
            self._transition(op, "WITHDRAWN", None, 100, visibility="removed")
            self._audit(operation_id, "withdrawal_completed", {"storage_retained": op.kind == "storage"}, self._now(), actor_id=actor_id, actor_role=actor_role)
        else:
            self._transition(op, "VISIBLE", None, 100, visibility="visible")
            self._audit(operation_id, "restore_completed", {"checkpoint_verified": True}, self._now(), actor_id=actor_id, actor_role=actor_role)
        self._db.commit(); return self.operation(operation_id)

    @_serialized
    def cancel(self, operation_id: str, *, expected_generation: int, actor_id: str = "local-stack", actor_role: str = "local_stack") -> SoftwareNodeLifecycleOperation:
        op = self.operation(operation_id)
        if op.generation != expected_generation: raise SoftwareNodeLifecycleConflict("lifecycle generation is stale")
        if op.state not in {"WITHDRAWING", "FAILED"}: raise SoftwareNodeLifecycleConflict("withdrawal can no longer be cancelled; restore is required")
        self._transition(op, "CANCELLED", None, op.progress, visibility="visible")
        self._audit(operation_id, "withdrawal_cancelled", {}, self._now(), actor_id=actor_id, actor_role=actor_role); self._db.commit(); return self.operation(operation_id)

    @_serialized
    def retry(self, operation_id: str, *, expected_generation: int, actor_id: str = "local-stack", actor_role: str = "local_stack") -> SoftwareNodeLifecycleOperation:
        op = self.operation(operation_id)
        if op.generation != expected_generation or op.state != "FAILED": raise SoftwareNodeLifecycleConflict("only the current failed operation can retry")
        self._transition(op, "WITHDRAWING", op.phase, op.progress, error=None)
        self._audit(operation_id, "withdrawal_retry", {}, self._now(), actor_id=actor_id, actor_role=actor_role); self._db.commit(); return self.operation(operation_id)

    @_serialized
    def restore(self, operation_id: str, restore_operation_id: str, *, expected_generation: int, provider_id: str | None = None, actor_id: str = "local-stack", actor_role: str = "local_stack") -> SoftwareNodeLifecycleOperation:
        old = self.operation(operation_id)
        if old.generation != expected_generation or old.state != "WITHDRAWN": raise SoftwareNodeLifecycleConflict("only a completed withdrawal can be restored")
        self._id(restore_operation_id, "restore_operation_id")
        if provider_id is not None: self._id(provider_id, "provider_id")
        # A distinct id protects undo/retry from being confused with the destructive command.
        if self._db.execute("SELECT 1 FROM software_node_operations WHERE operation_id=?", (restore_operation_id,)).fetchone(): raise SoftwareNodeLifecycleConflict("restore operation id already exists")
        now = self._now()
        claimed = self._db.execute("UPDATE software_node_operations SET generation=generation+1,updated_at=? WHERE operation_id=? AND generation=? AND state='WITHDRAWN'", (now, operation_id, expected_generation))
        if claimed.rowcount != 1:
            self._db.rollback()
            raise SoftwareNodeLifecycleConflict("lifecycle generation is stale")
        payload = {"restore_of": operation_id, "provider_id": provider_id}
        encoded = self._json(payload)
        self._db.execute(
            """INSERT INTO software_node_operations
               (operation_id,node_id,kind,confirmation_sha256,state,phase,
                progress,generation,visibility,error,checkpoint_id,provider_id,
                payload_sha256,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (restore_operation_id, old.node_id, old.kind, self._digest(encoded),
             "RESTORING", "validate_checkpoint", 0, 0, "withdrawing", None,
             old.checkpoint_id, provider_id, self._digest(encoded), now, now),
        )
        self._audit(restore_operation_id, "restore_requested", {"restore_of":operation_id,"provider_id":provider_id}, now, actor_id=actor_id, actor_role=actor_role)
        self._db.commit(); return self.operation(restore_operation_id)

    @_serialized
    def operation(self, operation_id: str) -> SoftwareNodeLifecycleOperation:
        row=self._db.execute("SELECT * FROM software_node_operations WHERE operation_id=?",(operation_id,)).fetchone()
        if row is None: raise KeyError("unknown software node lifecycle operation")
        return SoftwareNodeLifecycleOperation(*[row[x] for x in ("operation_id","node_id","kind","state","phase","progress","generation","visibility","error","checkpoint_id","provider_id")])

    def projection(self, operation_id: str) -> dict[str, Any]: return self.operation(operation_id).projection()
    @_serialized
    def audit(self, operation_id: str) -> list[dict[str, Any]]:
        return [{"event":r["event"],"detail":json.loads(r["detail_json"]),"occurred_at":r["occurred_at"],"actor_id":r["actor_id"],"actor_role":r["actor_role"]} for r in self._db.execute("SELECT event,detail_json,occurred_at,actor_id,actor_role FROM software_node_audit WHERE operation_id=? ORDER BY id",(operation_id,))]
    @_serialized
    def event_records(self) -> list[dict[str, Any]]:
        """Return lifecycle audit facts for the Management cursor projection."""
        rows = self._db.execute("""SELECT a.id,a.operation_id,o.node_id,o.generation,a.event,a.detail_json,
                                   a.occurred_at,a.actor_id,a.actor_role
                                   FROM software_node_audit a JOIN software_node_operations o
                                   ON o.operation_id=a.operation_id ORDER BY a.id""").fetchall()
        return [{"event_id": r["id"], "operation_id": r["operation_id"], "node_id": r["node_id"],
                 "revision": r["generation"], "action": r["event"], "detail": json.loads(r["detail_json"]),
                 "occurred_at": r["occurred_at"], "actor_id": r["actor_id"], "actor_role": r["actor_role"]} for r in rows]
    def _latest_bool(self, op: str, phase: str, kind: str) -> bool | None:
        r=self._db.execute("SELECT value_json FROM software_node_evidence WHERE operation_id=? AND phase=? AND kind=? ORDER BY observed_at DESC,id DESC LIMIT 1",(op,phase,kind)).fetchone(); return None if r is None else json.loads(r["value_json"])
    def _transition(self, op: SoftwareNodeLifecycleOperation, state: str, phase: str | None, progress: int, *, visibility: str | None = None, error: str | None = None) -> None:
        result = self._db.execute("UPDATE software_node_operations SET state=?,phase=?,progress=?,generation=generation+1,visibility=?,error=?,updated_at=? WHERE operation_id=? AND generation=?",(state,phase,progress,visibility or op.visibility,error,self._now(),op.operation_id,op.generation))
        if result.rowcount != 1:
            self._db.rollback()
            raise SoftwareNodeLifecycleConflict("lifecycle generation is stale")
    def _audit(self, op: str, event: str, detail: Mapping[str, Any], now: float, *, actor_id: str = "local-stack", actor_role: str = "local_stack") -> None:
        if not isinstance(actor_id, str) or not actor_id or not isinstance(actor_role, str) or not actor_role:
            raise SoftwareNodeLifecycleError("audit actor identity is required")
        self._db.execute("INSERT INTO software_node_audit(operation_id,event,detail_json,occurred_at,actor_id,actor_role) VALUES(?,?,?,?,?,?)",(op,event,self._json(detail),now,actor_id,actor_role))
    @staticmethod
    def _id(value: Any, name: str) -> None:
        if not isinstance(value,str) or not value or len(value)>128 or not value.replace("-","").replace("_","").replace(".","").replace(":","").isalnum(): raise SoftwareNodeLifecycleError(name+" is invalid")
    @staticmethod
    def _kind(value: Any) -> None:
        if value not in ("inference","storage"): raise SoftwareNodeLifecycleError("node kind must be inference or storage")
    @staticmethod
    def _json(value: Any) -> str: return json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False)
    @staticmethod
    def _digest(value: str) -> str: return hashlib.sha256(value.encode()).hexdigest()
    def _now(self) -> float: return float(self._clock())
