"""Read-only, normalized management workspace projections.

This adapter intentionally projects only registered facts.  A missing meter is
represented by ``null`` plus a ``missing_data`` record; it is never invented as
zero.  It owns no scheduler, approval, or provider mutation.
"""
from __future__ import annotations

from datetime import datetime, timezone
import base64
import hashlib
import json
import math
import re
from typing import Any, Callable, Mapping
from urllib.parse import unquote, urlsplit

from .project_control import ProjectControl
from .provider_registry import ProviderRegistry
from .resource_grants import ResourceGrants
from .usage_reporting import UsageReportingStore
from .software_node_lifecycle import SoftwareNodeLifecycleJournal
from shared.contracts.project_reference import PORTABLE_AGENT_FIELDS, PORTABLE_PROJECT_FIELDS, validate_secret_free


def _utc(clock: Callable[[], datetime]) -> str:
    return clock().astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _cursor(value: int) -> str:
    return base64.urlsafe_b64encode(str(value).encode("ascii")).decode("ascii").rstrip("=")


def _uncursor(value: str | None) -> int:
    if value is None: return 0
    if not isinstance(value, str) or not value or len(value) > 64: raise ValueError("event cursor is invalid")
    try: parsed = int(base64.urlsafe_b64decode(value + "=" * (-len(value) % 4)).decode("ascii"))
    except (ValueError, UnicodeDecodeError): raise ValueError("event cursor is invalid") from None
    if parsed < 0: raise ValueError("event cursor is invalid")
    return parsed

def _event_time(value: str | None) -> str | None:
    if value is None: return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        # ProjectControl's SQLite CURRENT_TIMESTAMP is UTC but has no offset.
        try: parsed = datetime.strptime(value, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError: return value
    if parsed.tzinfo is None: parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


class ManagementProjection:
    """Stable management-read contracts assembled from existing durable cores."""
    def __init__(self, projects: ProjectControl, providers: ProviderRegistry, grants: ResourceGrants | None,
                 reporting: UsageReportingStore | None, clock: Callable[[], datetime],
                 lifecycle: SoftwareNodeLifecycleJournal | None = None, inference_lifecycle: Any | None = None) -> None:
        self.projects, self.providers, self.grants, self.reporting, self.clock, self.lifecycle, self.inference_lifecycle = projects, providers, grants, reporting, clock, lifecycle, inference_lifecycle

    def _provider_status(self, provider: Mapping[str, Any]) -> tuple[str, dict[str, Any], dict[str, Any]]:
        manifest = provider.get("manifest", {})
        readiness = self.providers.readiness(provider.get("provider_id"), manifest.get("capabilities", []) if isinstance(manifest, Mapping) else [])
        checks = readiness.get("checks", {})
        freshness = checks.get("freshness", {}) if isinstance(checks, Mapping) else {}
        return ("ready" if readiness.get("eligible") is True else "unavailable", dict(readiness), {"state": "fresh" if freshness.get("ok") is True else "stale", "observed_at": freshness.get("observed_at"), "reason": "; ".join(readiness.get("reasons", []))})

    def _binding_readiness(self, binding: Mapping[str, Any]) -> dict[str, Any]:
        provider = self.providers.get(binding.get("provider_id"))
        if provider is None or provider.get("generation") != binding.get("provider_generation"):
            return {"provider_id": binding.get("provider_id"), "eligible": False, "status": "unavailable", "reasons": ["binding_provider_generation_stale"], "unavailable_dependency": binding.get("provider_id")}
        return self.providers.readiness(binding.get("provider_id"), [binding.get("capability")])

    @staticmethod
    def _setting(setting_id: str, value: Any, *, source: str, authority: str, revision: int | None,
                 freshness: Mapping[str, Any] | None = None, missing: Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Build the stable, secret-free settings item envelope.

        A missing setting remains addressable and carries an explicit reason;
        callers never need to infer absence from a missing JSON key.
        """
        is_missing = missing is not None
        return {"id": setting_id, "value": None if is_missing else value,
                "source": source, "authority": authority, "revision": revision,
                "freshness": dict(freshness or ({"state": "missing", "observed_at": None} if is_missing else {"state": "current", "observed_at": None})),
                "missing": dict(missing) if is_missing else None}

    @staticmethod
    def _response(node_id: str, settings: list[dict[str, Any]]) -> dict[str, Any]:
        return {"node_id": node_id, "settings": settings,
                "missing_data": [{"setting_id": item["id"], **item["missing"]} for item in settings if item.get("missing") is not None]}

    @staticmethod
    def _safe_project_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
        # ProjectControl permits durable implementation fields. Only the
        # explicit portable schema may cross this read boundary.
        result: dict[str, Any] = {}
        for key in PORTABLE_PROJECT_FIELDS:
            if key in payload:
                value = payload[key]
                try:
                    validate_secret_free(value)
                    value = json.loads(json.dumps(value, sort_keys=True, allow_nan=False))
                except (TypeError, ValueError):
                    continue
                result[key] = value
        agents = payload.get("agents")
        if isinstance(agents, list):
            projected_agents = []
            for agent in agents:
                if not isinstance(agent, Mapping): continue
                try:
                    validate_secret_free(agent)
                    projected = json.loads(json.dumps(agent, sort_keys=True, allow_nan=False))
                except (TypeError, ValueError): continue
                projected_agents.append({key: projected[key] for key in PORTABLE_AGENT_FIELDS if key in projected})
            result["agents"] = projected_agents
        return result

    @staticmethod
    def _actor(role: str | None, actor_id: str | None, observed_at: str | None) -> dict[str, Any]:
        # Provider and hardware registries are reported by a locally authenticated
        # stack component.  Project journals preserve the original actor.
        # The public provenance union is intentionally small.  Component roles
        # (provider/controller/orchestrator) are represented by the local stack
        # actor rather than leaking an internal role into the wire contract.
        kind = role if role in {"human", "codex"} else "local_stack"
        return {"actor_kind": kind, "actor_id": actor_id, "observed_at": observed_at}

    def _project_row(self, project: Mapping[str, Any]) -> dict[str, Any]:
        project_id = project["project_id"]
        grants: list[dict[str, Any]] = []
        if self.grants is not None:
            grants = self.grants.project_grants(project_id)
        tokens: dict[str, Any] = {"input": None, "output": None, "total": None, "source": "missing"}
        missing: list[dict[str, str]] = []
        if self.reporting is not None:
            totals = self.reporting.token_totals(project_id)
            if totals is not None: tokens = {**totals, "source": "usage_records"}
            else: missing.append({"subject_id": project_id, "field": "tokens", "reason": "no_usage_records"})
        else: missing.append({"subject_id": project_id, "field": "tokens", "reason": "reporting_not_configured"})
        audit = self.projects.audit(project_id)
        events = audit["requests"]
        latest = events[-1] if events else None
        provenance = self._actor(latest.get("actor_role") if latest else None, latest.get("actor_id") if latest else None, None)
        status = project["status"]
        lifecycle = self.projects.lifecycle(project_id)
        lifecycle_state = lifecycle["state"]
        admission = self.projects.admission_status(project_id)
        # A request is not an acknowledgement.  Keep the durable request state
        # visible instead of projecting pause_requested as paused or
        # end_requested as completed work.
        normalized = "active" if status == "start_intent_accepted" and lifecycle_state == "active" else lifecycle_state if lifecycle_state != "draft" else status
        return {"project_id": project_id, "revision": project["revision"], "status": normalized,
                "lifecycle": lifecycle,
                "allocation": {"grants": grants, "state": "reported" if self.grants is not None else "missing"},
                # ProjectControl records intents, not execution wall time.  These
                # fields stay explicit until the runtime reports lifecycle timing.
                "duration": {"active_seconds": None, "paused_seconds": None, "as_of": _utc(self.clock)},
                "tokens": tokens, "provenance": provenance, "admission": admission,
                "freshness": {"state": "unknown", "observed_at": None}, "missing_data": missing + [
                    {"subject_id": project_id, "field": "duration.active_seconds", "reason": "runtime_duration_not_reported"},
                    {"subject_id": project_id, "field": "duration.paused_seconds", "reason": "runtime_duration_not_reported"}],}

    @staticmethod
    def _route_observations(snapshot: Mapping[str, Any]) -> list[dict[str, Any]]:
        """Project only bounded route facts carried by persisted telemetry."""
        observations: dict[str, dict[str, Any]] = {}
        observation_keys: dict[str, tuple[datetime, datetime, int, int]] = {}
        telemetry = snapshot.get("telemetry")
        if not isinstance(telemetry, Mapping):
            return []
        loss_states = {"stale", "unreachable", "not-collected", "unknown"}
        minimum_time = datetime.min.replace(tzinfo=timezone.utc)

        def parsed_timestamp(value: Any) -> datetime | None:
            if not isinstance(value, str):
                return None
            try:
                parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
                if parsed.tzinfo is None:
                    return None
                return parsed.astimezone(timezone.utc)
            except (OverflowError, ValueError):
                return None

        def timestamp(value: Any) -> datetime:
            parsed = parsed_timestamp(value)
            if parsed is None:
                return minimum_time
            return parsed

        for sample in telemetry.values():
            if not isinstance(sample, Mapping) or not isinstance(sample.get("route_observations"), list):
                continue
            sample_freshness = sample.get("freshness")
            sample_freshness_state = sample_freshness.get("state") if isinstance(sample_freshness, Mapping) else None
            sample_loss = isinstance(sample_freshness_state, str) and sample_freshness_state in loss_states
            for raw in sample["route_observations"]:
                if not isinstance(raw, Mapping):
                    continue
                route_id = raw.get("id")
                if not isinstance(route_id, str) or not re.fullmatch(r"[-A-Za-z0-9._]{1,128}", route_id):
                    continue
                route: dict[str, Any] = {"id": route_id}
                endpoint = raw.get("endpoint")
                if endpoint is None:
                    if "endpoint" in raw:
                        route["endpoint"] = None
                elif isinstance(endpoint, str) and len(endpoint) <= 512:
                    try:
                        parsed = urlsplit(endpoint)
                        port = parsed.port
                        valid_endpoint = (parsed.scheme in {"http", "https"} and parsed.hostname
                                          and (port is None or 0 <= port <= 65535)
                                          and not parsed.username and not parsed.password
                                          and not parsed.query and not parsed.fragment)
                        valid_endpoint = bool(valid_endpoint and not parsed.username and not parsed.password and not parsed.query and not parsed.fragment)
                    except ValueError:
                        valid_endpoint = False
                    if valid_endpoint:
                        route["endpoint"] = endpoint
                owner = raw.get("owner")
                if owner is None:
                    if "owner" in raw:
                        route["owner"] = None
                elif isinstance(owner, str) and 0 < len(owner) <= 128:
                    route["owner"] = owner
                latency = raw.get("latency_ms")
                if latency is None:
                    if "latency_ms" in raw:
                        route["latency_ms"] = None
                elif isinstance(latency, (int, float)) and not isinstance(latency, bool):
                    try:
                        valid_latency = math.isfinite(latency) and latency >= 0
                    except (OverflowError, TypeError, ValueError):
                        valid_latency = False
                    if valid_latency:
                        route["latency_ms"] = latency
                health = raw.get("health")
                valid_health = isinstance(health, str) and health in {"healthy", "degraded", "unhealthy", "unknown"}
                if valid_health:
                    route["health"] = health
                freshness = raw.get("freshness")
                freshness_state = freshness.get("state") if isinstance(freshness, Mapping) else None
                if (isinstance(freshness_state, str)
                        and freshness_state in {"fresh", "late", "stale", "unreachable", "not-collected", "unknown"}):
                    projected_freshness: dict[str, Any] = {"state": freshness["state"]}
                    for key in ("observed_at", "received_at", "reason"):
                        value = freshness.get(key)
                        if value is None:
                            if key in freshness:
                                projected_freshness[key] = None
                        elif isinstance(value, str) and 0 < len(value) <= 256:
                            if key not in {"observed_at", "received_at"} or parsed_timestamp(value) is not None:
                                projected_freshness[key] = value
                    route["freshness"] = projected_freshness
                source = raw.get("source")
                if isinstance(source, str) and 0 < len(source) <= 128:
                    route["source"] = source
                route_loss = (sample_loss
                              or (isinstance(freshness_state, str) and freshness_state in loss_states)
                              or (isinstance(health, str) and health in {"unhealthy", "unknown"}))
                if route_loss:
                    route["health"] = "degraded"
                    route["freshness"] = {**(route.get("freshness", {})), "state": "stale"}
                route_freshness = raw.get("freshness")
                route_observed_at = route_freshness.get("observed_at") if isinstance(route_freshness, Mapping) else None
                route_received_at = route_freshness.get("received_at") if isinstance(route_freshness, Mapping) else None
                observed_at = timestamp(route_observed_at)
                if observed_at == minimum_time:
                    observed_at = timestamp(sample.get("observed_at"))
                received_at = timestamp(route_received_at)
                if received_at == minimum_time:
                    received_at = timestamp(sample.get("received_at"))
                sequence = sample.get("sequence")
                sequence_value = sequence if type(sequence) is int and sequence >= 0 else -1
                candidate_key = (observed_at, received_at, 0 if route_loss else 1, sequence_value)
                if route_id not in observation_keys or candidate_key >= observation_keys[route_id]:
                    observation_keys[route_id] = candidate_key
                    observations[route_id] = route
        return list(observations.values())

    def project_route_observations(self, project_id: str) -> list[dict[str, Any]]:
        """Return route observations only from hardware selected by one project."""
        draft = self.projects.draft(project_id)
        payload = draft.get("payload", {})
        hardware_ids: set[str] = set()
        hardware_reference = payload.get("hardware_reference")
        if isinstance(hardware_reference, str) and hardware_reference:
            hardware_ids.add(hardware_reference)
        provider_reference = payload.get("provider_reference")
        if isinstance(provider_reference, str):
            provider = self.providers.get(provider_reference)
            if isinstance(provider, Mapping) and isinstance(provider.get("hardware_node_id"), str):
                hardware_ids.add(provider["hardware_node_id"])
        binding_names: set[str] = set()
        declared_bindings = payload.get("binding_references")
        if isinstance(declared_bindings, list):
            binding_names.update(binding for binding in declared_bindings if isinstance(binding, str))
        for agent in payload.get("agents", []):
            if isinstance(agent, Mapping) and isinstance(agent.get("capability_bindings"), list):
                binding_names.update(binding for binding in agent["capability_bindings"] if isinstance(binding, str))
        bindings = {binding["logical_binding"]: binding for binding in self.providers.list_bindings()}
        for binding_name in binding_names:
            binding = bindings.get(binding_name)
            provider_id = binding.get("provider_id") if isinstance(binding, Mapping) else None
            provider = self.providers.get(provider_id) if isinstance(provider_id, str) else None
            if isinstance(provider, Mapping) and isinstance(provider.get("hardware_node_id"), str):
                hardware_ids.add(provider["hardware_node_id"])
        observations: dict[str, dict[str, Any]] = {}
        for snapshot in self.providers.hardware.list_snapshots():
            if snapshot.get("node_id") in hardware_ids:
                for route in self._route_observations(snapshot):
                    observations[route["id"]] = route
        return list(observations.values())

    def workspace(self, project_ids: frozenset[str] | None) -> dict[str, Any]:
        projects = self.projects.list_projects(project_ids)
        nodes: list[dict[str, Any]] = []
        links: list[dict[str, str]] = []
        routes_by_id: dict[str, dict[str, Any]] = {}
        for row in projects:
            project_id = row["project_id"]
            project_row = self._project_row(row)
            nodes.append({"id": "project:" + project_id, "kind": "project", "label": project_id,
                          "status": project_row["status"],
                          "provenance": project_row["provenance"], "freshness": {"state":"unknown","observed_at":None}})
            draft = self.projects.draft(project_id)
            orchestrator_id = "orchestrator:" + project_id
            nodes.append({"id": orchestrator_id, "kind": "orchestrator", "label": "Project orchestrator", "status": "unknown", "provenance": self._actor(None, None, None), "freshness": {"state": "unknown", "observed_at": None}})
            links.append({"source": "project:" + project_id, "target": orchestrator_id, "kind": "governs"})
            # Storage is a project capability, not an agent/runtime detail.
            # Keep the declared binding visible even when no agent consumes it;
            # this is what lets an unstarted draft truthfully show its intended
            # repository/storage authority.
            storage_binding = draft["payload"].get("storage_binding")
            if not isinstance(storage_binding, str):
                declared_bindings = draft["payload"].get("binding_references", [])
                storage_binding = next((value for value in declared_bindings if isinstance(value, str) and value.startswith("storage.")), None) if isinstance(declared_bindings, list) else None
            storage_policy = draft["payload"].get("storage_policy")
            storage_declared = isinstance(storage_policy, (Mapping, str)) and (not isinstance(storage_policy, str) or bool(storage_policy.strip()))
            if isinstance(storage_binding, str) and storage_binding:
                bid = "binding:" + storage_binding
                if not any(n["id"] == bid for n in nodes):
                    nodes.append({"id": bid, "kind": "binding", "label": storage_binding, "status": "declared", "provenance": self._actor(None, None, None), "freshness": {"state": "unknown", "observed_at": None}})
                storage_declared = True
            if storage_declared:
                storage_id = "storage:project:" + project_id
                nodes.append({"id": storage_id, "kind": "storage", "label": "Project storage", "status": "declared", "provenance": self._actor(None, None, None), "freshness": {"state": "unknown", "observed_at": None}})
                links.append({"source": "project:" + project_id, "target": storage_id, "kind": "uses"})
                if isinstance(storage_binding, str) and storage_binding:
                    links.append({"source": storage_id, "target": "binding:" + storage_binding, "kind": "configured_by"})
            # A project may explicitly select a registered provider and/or
            # hardware identity.  Keep that selection in the authoritative
            # topology so a saved draft reloads with the same selectable node;
            # never infer it from registration order or a logical binding.
            provider_reference = draft["payload"].get("provider_reference")
            if isinstance(provider_reference, str) and provider_reference:
                provider_id = "provider:" + provider_reference
                provider = self.providers.get(provider_reference)
                if provider is None:
                    nodes.append({"id": provider_id, "kind": "provider", "label": provider_reference, "status": "unavailable", "provenance": self._actor(None, provider_reference, None), "freshness": {"state": "missing", "observed_at": None}})
                elif not any(n["id"] == provider_id for n in nodes):
                    health = provider.get("health") or {}
                    status, _readiness, freshness = self._provider_status(provider)
                    nodes.append({"id": provider_id, "kind": "provider", "label": provider_reference, "status": status, "provenance": self._actor(None, provider_reference, health.get("observed_at")), "freshness": freshness})
                links.append({"source": "project:" + project_id, "target": provider_id, "kind": "uses"})
            hardware_reference = draft["payload"].get("hardware_reference")
            if isinstance(hardware_reference, str) and hardware_reference:
                hardware_id = "hardware:" + hardware_reference
                snapshot = self.providers.hardware.get_snapshot(hardware_reference)
                if snapshot is None:
                    nodes.append({"id": hardware_id, "kind": "hardware", "label": hardware_reference, "status": "unavailable", "provenance": self._actor(None, hardware_reference, None), "freshness": {"state": "missing", "observed_at": None}})
                elif not any(n["id"] == hardware_id for n in nodes):
                    nodes.append({"id": hardware_id, "kind": "hardware", "label": hardware_reference, "status": "unknown", "provenance": self._actor(None, hardware_reference, snapshot.get("updated_at")), "freshness": {"state": "unknown", "observed_at": snapshot.get("updated_at")}})
                links.append({"source": "project:" + project_id, "target": hardware_id, "kind": "uses"})
            for agent in draft["payload"].get("agents", []):
                agent_id = agent["id"]; aid = "agent:" + project_id + ":" + agent_id
                role = agent.get("role", "agent")
                nodes.append({"id":aid,"kind":"agent","label":agent_id,"status":"unknown","provenance":self._actor(None,None,None),"freshness":{"state":"unknown","observed_at":None}})
                links.append({"source":"project:"+project_id,"target":aid,"kind":"contains"})
                runtime_id = "runtime:" + project_id + ":" + agent_id
                nodes.append({"id":runtime_id,"kind":"runtime","label":role,"status":"unknown","provenance":self._actor(None,None,None),"freshness":{"state":"unknown","observed_at":None}})
                links.append({"source": aid, "target": runtime_id, "kind": "runs_on"})
                if role == "project_orchestrator": links.append({"source": orchestrator_id, "target": aid, "kind": "owns"})
                for binding in agent.get("capability_bindings",[]):
                    bid="binding:"+binding
                    if not any(n["id"] == bid for n in nodes): nodes.append({"id":bid,"kind":"binding","label":binding,"status":"unknown","provenance":self._actor(None,None,None),"freshness":{"state":"unknown","observed_at":None}})
                    links.append({"source":aid,"target":bid,"kind":"uses"})
                    resolved=self.providers.binding(binding)
                    if resolved and isinstance(resolved.get("provider"),Mapping):
                        provider=resolved["provider"]; pid="provider:"+provider["provider_id"]
                        if not any(n["id"] == pid for n in nodes):
                            health=provider.get("health") or {}; status, readiness, freshness = self._provider_status(provider)
                            nodes.append({"id":pid,"kind":"provider","label":provider["provider_id"],"status":status,"provenance":self._actor(None,provider["provider_id"],health.get("observed_at")),"freshness":freshness})
                            role_kind = provider.get("role") if provider.get("role") in {"inference", "storage", "agent-runtime", "management"} else None
                            if role_kind in {"inference", "storage"}:
                                typed_id = role_kind + ":" + provider["provider_id"]
                                nodes.append({"id": typed_id, "kind": role_kind, "label": provider["provider_id"], "status": status, "provenance": self._actor(None, provider["provider_id"], health.get("observed_at")), "freshness": freshness})
                                links.append({"source": pid, "target": typed_id, "kind": "role"})
                        links.append({"source":bid,"target":pid,"kind":"resolved_by"})
        for snapshot in self.providers.hardware.list_snapshots():
            node_id=snapshot["node_id"]; hid="hardware:"+node_id
            route_observations = self._route_observations(snapshot)
            if not any(n["id"] == hid for n in nodes):
                hardware_node = {"id":hid,"kind":"hardware","label":node_id,"status":"unknown","provenance":self._actor(None,node_id,snapshot.get("updated_at")),"freshness":{"state":"unknown","observed_at":snapshot.get("updated_at")}}
                if route_observations:
                    hardware_node["route_observations"] = route_observations
                nodes.append(hardware_node)
            else:
                existing = next(n for n in nodes if n["id"] == hid)
                if route_observations:
                    existing["route_observations"] = route_observations
            for route in route_observations:
                routes_by_id[route["id"]] = route
        # Include every registered provider, even if no currently scoped project uses it.
        for provider in self.providers.list():
            pid="provider:"+provider["provider_id"]
            if not any(n["id"] == pid for n in nodes):
                health=provider.get("health") or {}; status, readiness, freshness = self._provider_status(provider)
                nodes.append({"id":pid,"kind":"provider","label":provider["provider_id"],"status":status,"provenance":self._actor(None,provider["provider_id"],health.get("observed_at")),"freshness":freshness})
                if provider.get("role") in {"inference", "storage"}:
                    typed_id = provider["role"] + ":" + provider["provider_id"]
                    nodes.append({"id": typed_id, "kind": provider["role"], "label": provider["provider_id"], "status": status, "provenance": self._actor(None, provider["provider_id"], health.get("observed_at")), "freshness": freshness})
                    links.append({"source": pid, "target": typed_id, "kind": "role"})
            links.append({"source":pid,"target":"hardware:"+provider["hardware_node_id"],"kind":"hosted_by"})
        for binding in self.providers.list_bindings():
            bid="binding:"+binding["logical_binding"]
            binding_readiness=self._binding_readiness(binding)
            binding_checks=binding_readiness.get("checks", {})
            binding_freshness=binding_checks.get("freshness", {}) if isinstance(binding_checks, Mapping) else {}
            binding_status="ready" if binding_readiness.get("eligible") is True else "unavailable"
            existing_binding=next((node for node in nodes if node["id"]==bid), None)
            if existing_binding is None:
                nodes.append({"id":bid,"kind":"binding","label":binding["logical_binding"],"status":binding_status,"provenance":self._actor("controller",None,binding["updated_at"]),"freshness":{"state":"fresh" if binding_freshness.get("ok") is True else "stale","observed_at":binding_freshness.get("observed_at") or binding["updated_at"],"reason":"; ".join(binding_readiness.get("reasons", []))}})
            else:
                existing_binding["status"]=binding_status
                existing_binding["freshness"]={"state":"fresh" if binding_freshness.get("ok") is True else "stale","observed_at":binding_freshness.get("observed_at") or binding["updated_at"],"reason":"; ".join(binding_readiness.get("reasons", []))}
            links.append({"source":bid,"target":"provider:"+binding["provider_id"],"kind":"resolved_by"})
        if self.inference_lifecycle is not None:
            requests = self.inference_lifecycle.admission.catalog.request_records(frozenset(row["project_id"] for row in projects))
            for request in requests:
                request_node = "inference-request:" + request["project_id"] + ":" + request["request_id"]
                effect_node = "inference-effect:" + request["effect_id"]
                provenance = self._actor("local_stack", "management", request.get("updated_at"))
                freshness = {"state": "current", "observed_at": request.get("updated_at")}
                public_request = {key: request.get(key) for key in ("request_id", "effect_id", "model_id", "revision", "state", "provider_id", "provider_generation")}
                outcome = request.get("outcome")
                if isinstance(outcome, Mapping):
                    safe_outcome = {key: value for key, value in outcome.items() if key in {"request_id", "effect_id", "state", "reason", "detail", "status"} and isinstance(value, str) and len(value) <= (256 if key in {"reason", "detail", "status"} else 128)}
                    public_request["outcome"] = safe_outcome
                nodes.append({"id": request_node, "kind": "inference_request", "label": request["request_id"], "status": request["state"], "provenance": provenance, "freshness": freshness, "request": public_request})
                nodes.append({"id": effect_node, "kind": "inference_effect", "label": request["effect_id"], "status": request["state"], "provenance": provenance, "freshness": freshness})
                links.extend(({"source": "project:" + request["project_id"], "target": request_node, "kind": "contains"}, {"source": request_node, "target": effect_node, "kind": "produces"}))
        ledger=[self._project_row(row) for row in projects]
        missing=[item for row in ledger for item in row["missing_data"]]
        result = {"revision": len(nodes)+len(links)+sum(row["revision"] for row in projects), "generated_at":_utc(self.clock), "nodes":nodes,"links":links,"projects":ledger,"missing_data":missing}
        if routes_by_id:
            result["routes"] = list(routes_by_id.values())
        return result

    def settings(self, node_id: str, project_ids: frozenset[str] | None) -> dict[str, Any]:
        """Expose complete, non-secret settings for every projected node kind."""
        requested_node_id = node_id
        if node_id.startswith("project:"):
            project_id = node_id.split(":", 1)[1]
            if project_ids is not None and project_id not in project_ids: raise PermissionError
            draft = self.projects.draft(project_id)
            return self._response(node_id, [self._setting("project.payload", self._safe_project_payload(draft["payload"]), source="project_control", authority="human_confirmation_required", revision=draft["revision"])])
        if node_id.startswith("agent:"):
            parts = node_id.split(":", 2)
            if len(parts) != 3: raise KeyError(node_id)
            project_id, agent_id = parts[1:]
            if project_ids is not None and project_id not in project_ids: raise PermissionError
            draft = self.projects.draft(project_id)
            agent = next((item for item in draft["payload"].get("agents", []) if isinstance(item, Mapping) and item.get("id") == agent_id), None)
            if agent is None: raise KeyError(node_id)
            value = self._safe_project_payload({"agents": [agent]}).get("agents", [{}])[0]
            return self._response(node_id, [self._setting("agent.definition", value, source="project_control", authority="human_confirmation_required", revision=draft["revision"])])
        if node_id.startswith("orchestrator:"):
            project_id = node_id.split(":", 1)[1]
            if project_ids is not None and project_id not in project_ids: raise PermissionError
            draft = self.projects.draft(project_id)
            agent = next((item for item in draft["payload"].get("agents", []) if isinstance(item, Mapping) and item.get("role") == "project_orchestrator"), None)
            value = {"project_id": project_id, "agent_id": agent.get("id") if agent else None, "state": "declared" if agent else "missing"}
            return self._response(node_id, [self._setting("orchestrator.definition", value, source="project_control", authority="management", revision=draft["revision"], missing=None if agent else {"reason": "orchestrator_not_declared"})])
        if node_id.startswith("runtime:"):
            parts = node_id.split(":", 2)
            if len(parts) != 3: raise KeyError(node_id)
            project_id, agent_id = parts[1:]
            if project_ids is not None and project_id not in project_ids: raise PermissionError
            draft = self.projects.draft(project_id)
            agent = next((item for item in draft["payload"].get("agents", []) if isinstance(item, Mapping) and item.get("id") == agent_id), None)
            value = {"project_id": project_id, "agent_id": agent_id, "role": agent.get("role") if agent else None, "capability_bindings": agent.get("capability_bindings", []) if agent else []}
            return self._response(node_id, [self._setting("runtime.binding", value, source="project_control", authority="agent_runtime", revision=draft["revision"], missing=None if agent else {"reason": "runtime_not_registered"})])
        typed_role = node_id.split(":", 1)[0] if ":" in node_id else ""
        provider_id = node_id.split(":", 1)[1] if typed_role in {"inference", "storage"} else node_id.split(":", 1)[1] if node_id.startswith("provider:") else None
        if provider_id is not None:
            provider = self.providers.get(provider_id)
            if provider is None: raise KeyError(node_id)
            role = provider.get("role")
            setting_id = "provider.manifest" if typed_role not in {"inference", "storage"} else role + ".configuration"
            value = {"provider_id": provider.get("provider_id"), "hardware_node_id": provider.get("hardware_node_id"), "role": role, "capabilities": provider.get("manifest", {}).get("capabilities"), "compatibility_fingerprint": provider.get("manifest", {}).get("compatibility_fingerprint"), "build_digest": provider.get("manifest", {}).get("build_digest"), "configuration_hash": provider.get("manifest", {}).get("configuration_hash"), "health": provider.get("health")}
            return self._response(requested_node_id, [self._setting(setting_id, value, source="provider_registry", authority="provider", revision=provider["generation"], freshness={"state": "current", "observed_at": provider.get("updated_at")})])
        if node_id.startswith("hardware:"):
            snapshot = self.providers.hardware.get_snapshot(node_id.split(":", 1)[1])
            if snapshot is None: raise KeyError(node_id)
            registration = snapshot["registration"]
            value = {key: registration.get(key) for key in ("node_identity", "capabilities", "resource_limits", "working_root")}
            revision = int(hashlib.sha256(json.dumps({"registration": registration, "updated_at": snapshot.get("updated_at")}, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()[:8], 16) or 1
            return self._response(node_id, [self._setting("hardware.registration", value, source="hardware_registry", authority="local_stack", revision=revision, freshness={"state": "current", "observed_at": snapshot.get("updated_at")})])
        if node_id.startswith("binding:"):
            name = node_id.split(":", 1)[1]; binding = next((row for row in self.providers.list_bindings() if row["logical_binding"] == name), None)
            if binding is None: raise KeyError(node_id)
            value = {key: binding.get(key) for key in ("logical_binding", "capability", "compatibility_fingerprint", "provider_id", "provider_generation", "generation", "updated_at")}
            readiness = self._binding_readiness(binding)
            checks = readiness.get("checks", {})
            freshness_check = checks.get("freshness", {}) if isinstance(checks, Mapping) else {}
            reasons = readiness.get("reasons", [])
            freshness = {
                "state": "fresh" if freshness_check.get("ok") is True else "stale",
                "observed_at": freshness_check.get("observed_at") or binding["updated_at"],
                "reason": "; ".join(reason for reason in reasons if isinstance(reason, str)),
            }
            return self._response(node_id, [self._setting("binding.resolution", value, source="provider_registry", authority="controller", revision=binding["generation"], freshness=freshness)])
        raise KeyError(node_id)

    @staticmethod
    def _safe_manifest(manifest: Mapping[str, Any]) -> dict[str, Any]:
        return {key: value for key,value in manifest.items() if key not in {"private_endpoint","endpoint","token","secret","credential"}}

    @staticmethod
    def _auth_event_project_id(action: str) -> str | None:
        """Return the project addressed by an authentication action, if any.

        Authentication outcomes for global management routes remain visible to
        an authorized management reader.  Outcomes for project routes must be
        subject to the same project scope as the rest of this projection.
        """
        if not isinstance(action, str) or not action.startswith("auth:"):
            return None
        path = action.split(":", 2)[-1]
        parsed = urlsplit(path)
        parts = [unquote(part) for part in parsed.path.split("/") if part]
        return parts[1] if len(parts) >= 2 and parts[0] == "projects" else None

    def actions(self, project_ids: frozenset[str] | None, cursor: str | None, limit: int = 100) -> dict[str, Any]:
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise ValueError("event limit must be an integer from 1 through 1000")
        after=_uncursor(cursor)
        rows=[]
        for project in self.projects.list_projects(project_ids):
            audit=self.projects.audit(project["project_id"])
            for request in audit["requests"]:
                rows.append({"project_id":project["project_id"],"action_id":request["action_id"],"action":request["action"],"actor_id":request["actor_id"],"actor_role":request["actor_role"],"occurred_at":_event_time(request.get("created_at")),"revision":request["response"].get("revision")})
        for record in self.projects.auth_events():
            event_project_id = self._auth_event_project_id(record["action"])
            if event_project_id is not None and (project_ids is None or event_project_id not in project_ids):
                continue
            rows.append({"subject_id": record["subject"], "action_id": record["action_id"], "action": record["action"], "actor_id": record["actor_id"], "actor_role": record["actor_role"], "occurred_at": _event_time(record["occurred_at"]), "revision": None, "kind": "management.authentication", "outcome": record["outcome"]})
        if self.lifecycle is not None:
            for record in self.lifecycle.event_records():
                rows.append({"subject_id": record["node_id"], "action_id": f"lifecycle:{record['operation_id']}:{record['event_id']}", "action": record["action"], "actor_id": record["actor_id"], "actor_role": record["actor_role"],
                             "occurred_at": datetime.fromtimestamp(record["occurred_at"], timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"), "revision": record["revision"], "kind": "software_node.lifecycle"})
        rows.sort(key=lambda row:(row["occurred_at"] or "",row.get("project_id", row.get("subject_id", "")),row["action"]))
        page=rows[after:after+limit]
        events=[]
        for i, row in enumerate(page):
            subject = row.get("subject_id") or "project:" + row["project_id"]
            timestamp = row["occurred_at"]
            events.append({"cursor":_cursor(after+i+1), "kind":row.get("kind", "management.action"), "subject":subject, "subject_id":subject,
                           "revision":row.get("revision"), "timestamp":timestamp, "occurred_at":timestamp,
                           "action_id":row["action_id"],
                           "actor_id":row.get("actor_id"), "actor_role":row.get("actor_role"),
                           "provenance":self._actor(row.get("actor_role"),row.get("actor_id"),timestamp), "action":row["action"], "outcome":row.get("outcome")})
        return {"events":events,"next_cursor":_cursor(after+len(page)) if after+len(page)<len(rows) else None}

    def information(self, project_id: str, start: str | None, end: str | None) -> dict[str, Any]:
        if self.reporting is None: return {"project_id":project_id,"series":[],"missing_data":[{"subject_id":project_id,"field":"series","reason":"reporting_not_configured"}]}
        return self.reporting.time_series(project_id,start,end)

    def node_information(self, node_id: str, start: str | None, end: str | None) -> dict[str, Any]:
        """Generic node-scoped Information projection with truthful gaps."""
        if node_id.startswith("project:"):
            return self.information(node_id.split(":", 1)[1], start, end)
        if node_id.startswith("agent:") or node_id.startswith("runtime:") or node_id.startswith("orchestrator:"):
            project_id = node_id.split(":", 2)[1] if node_id.startswith(("agent:", "runtime:")) else node_id.split(":", 1)[1]
            if self.reporting is None:
                return {"node_id": node_id, "from": start, "to": end, "series": [], "missing_data": [{"subject_id": node_id, "field": "series", "reason": "reporting_not_configured"}]}
            project = self.information(project_id, start, end)
            return {"node_id": node_id, "from": project.get("from"), "to": project.get("to"), "series": project.get("series", []),
                    "missing_data": project.get("missing_data", []) or [{"subject_id": node_id, "field": "series", "reason": "agent_scoped_history_not_reported"}]}
        if node_id.startswith("hardware:"):
            snapshot = self.providers.hardware.get_snapshot(node_id.split(":", 1)[1])
            if snapshot is None: raise KeyError(node_id)
            start_time = datetime.fromisoformat(start.replace("Z", "+00:00")) if start is not None else None
            end_time = datetime.fromisoformat(end.replace("Z", "+00:00")) if end is not None else None
            if start_time is not None and start_time.tzinfo is None or end_time is not None and end_time.tzinfo is None: raise ValueError("time range timestamps require timezone")
            if start_time is not None and end_time is not None and start_time >= end_time: raise ValueError("time range must be ascending")
            series = []
            missing = []
            for telemetry in snapshot.get("telemetry", {}).values():
                observed = datetime.fromisoformat(telemetry["observed_at"].replace("Z", "+00:00"))
                if start_time is not None and observed < start_time or end_time is not None and observed >= end_time: continue
                for metric in telemetry.get("metrics", []):
                    availability = metric.get("availability", {})
                    series.append({"name": metric.get("name"), "unit": metric.get("unit"), "samples": [{"observed_at": telemetry.get("observed_at"), "received_at": telemetry.get("received_at"), "value": metric.get("value"), "availability": availability.get("state"), "provenance": {"source": telemetry.get("source"), "collector": telemetry.get("collector")}}]})
                    if availability.get("state") != "reported": missing.append({"subject_id": node_id, "field": metric.get("name"), "reason": availability.get("reason") or availability.get("state")})
            if not series: missing.append({"subject_id": node_id, "field": "series", "reason": "no_telemetry_sample_in_range" if start is not None or end is not None else "no_telemetry_sample"})
            return {"node_id": node_id, "from": start, "to": end, "series": series, "missing_data": missing}
        if node_id.startswith(("provider:", "inference:", "storage:", "binding:")):
            return {"node_id": node_id, "from": start, "to": end, "series": [], "missing_data": [{"subject_id": node_id, "field": "series", "reason": "provider_history_not_reported"}]}
        raise KeyError(node_id)
