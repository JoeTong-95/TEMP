"""Durable, dependency-free hardware registration and telemetry projections.

This is a pure core: callers have already authenticated and supplied their scoped
hardware-node identity.  It deliberately creates no HTTP surface, directories,
network connections, service readiness decision, or power-control command.

The stored/read API is snake_case. UI adapters may map it to camelCase, but must
not treat a telemetry projection as readiness or a lifecycle authorization.
"""

from __future__ import annotations

import ipaddress
import json
import math
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, Callable, Iterator, Mapping
from urllib.parse import urlparse

from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


class HardwareRegistryError(ValueError):
    """Raised when an untrusted caller-supplied record fails core validation."""


Clock = Callable[[], datetime]
_AVAILABILITY = {"reported", "unsupported", "disabled", "unauthorized", "collector-error", "no-sample"}
_PRIVATE_SUFFIXES = (".internal", ".local", ".ts.net")


def _utc_text(value: datetime) -> str:
    if value.tzinfo is None:
        raise HardwareRegistryError("clock must return a timezone-aware datetime")
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_time(value: Any, name: str) -> datetime:
    if not isinstance(value, str):
        raise HardwareRegistryError(f"{name} must be an RFC3339 timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise HardwareRegistryError(f"{name} must be an RFC3339 timestamp") from error
    if parsed.tzinfo is None:
        raise HardwareRegistryError(f"{name} must include a timezone")
    return parsed.astimezone(timezone.utc)


def _require_string(data: Mapping[str, Any], name: str) -> str:
    value = data.get(name)
    if not isinstance(value, str) or not value:
        raise HardwareRegistryError(f"{name} must be a non-empty string")
    return value


def _is_private_host(host: str, allowed_suffixes: tuple[str, ...]) -> bool:
    try:
        address = ipaddress.ip_address(host)
        return address.is_private or address.is_loopback or address in ipaddress.ip_network("100.64.0.0/10")
    except ValueError:
        lowered = host.lower().rstrip(".")
        return "." not in lowered or lowered.endswith(allowed_suffixes)


class HardwareRegistry:
    """SQLite-backed registration and last-sample projection store.

    The parent directory must already exist; this class does not create working
    roots or any other directories. `clock` is injectable for deterministic
    receipt timestamps and freshness projections.
    """

    def __init__(self, database: str | Path, *, clock: Clock | None = None, freshness_grace_seconds: int = 0, stale_after_seconds: int = 60, private_dns_suffixes: tuple[str, ...] = _PRIVATE_SUFFIXES):
        database_path = Path(database)
        try:
            state_root = validate_state_root(database_path.parent, "hardware registry state root")
            self.database = validate_durable_leaf(database_path, state_root, label="hardware registry database")
        except ManagementStateBoundaryError as error:
            raise HardwareRegistryError(str(error)) from error
        if freshness_grace_seconds < 0 or stale_after_seconds < 1:
            raise HardwareRegistryError("freshness thresholds must be positive")
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.freshness_grace_seconds = freshness_grace_seconds
        self.stale_after_seconds = stale_after_seconds
        if not private_dns_suffixes or any(not isinstance(suffix, str) or not suffix.startswith(".") for suffix in private_dns_suffixes):
            raise HardwareRegistryError("private_dns_suffixes must contain dotted private DNS suffixes")
        self.private_dns_suffixes = private_dns_suffixes
        self._initialize()

    def register(self, caller_node_id: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        """Upsert one caller-scoped node registration; no authentication is claimed."""
        if not isinstance(payload, Mapping):
            raise HardwareRegistryError("registration payload must be an object")
        node_id = _require_string(payload, "node_id")
        if caller_node_id != node_id:
            raise HardwareRegistryError("caller_node_id must match payload node_id")
        self._validate_registration(payload)
        record = json.dumps(dict(payload), sort_keys=True, separators=(",", ":"))
        now = _utc_text(self.clock())
        with self._connection() as connection:
            connection.execute(
                "INSERT INTO hardware_nodes(node_id, registration, registered_at, updated_at) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(node_id) DO UPDATE SET registration=excluded.registration, updated_at=excluded.updated_at",
                (node_id, record, now, now),
            )
        return self.get_snapshot(node_id)  # type: ignore[return-value]

    def ingest_telemetry(self, caller_node_id: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        """Accept exactly newer telemetry for a node/collector/boot stream.

        `received_at` is assigned from the injected Management clock, never trusted
        from a node-supplied payload. A boot change is accepted only when its
        observed timestamp is newer than the current stream, preventing delayed
        samples from an old boot from replacing the current projection.
        """
        if not isinstance(payload, Mapping):
            raise HardwareRegistryError("telemetry payload must be an object")
        node_id = _require_string(payload, "hardware_node_id")
        if caller_node_id != node_id:
            raise HardwareRegistryError("caller_node_id must match hardware_node_id")
        telemetry = dict(payload)
        self._validate_telemetry(telemetry)
        received_time = self.clock()
        observed_time = _parse_time(telemetry["observed_at"], "observed_at")
        if observed_time > received_time.astimezone(timezone.utc):
            raise HardwareRegistryError("future producer observed_at is rejected; clock skew must be reconciled")
        received_at = _utc_text(received_time)
        telemetry["received_at"] = received_at
        collector_id = telemetry["collector"]["id"]
        observed_at = telemetry["observed_at"]
        sequence = telemetry["sequence"]
        boot_id = telemetry["host_boot_id"]
        encoded = json.dumps(telemetry, sort_keys=True, separators=(",", ":"))
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            registration_row = connection.execute("SELECT registration FROM hardware_nodes WHERE node_id=?", (node_id,)).fetchone()
            if registration_row is None:
                raise HardwareRegistryError("hardware node must be registered before telemetry is accepted")
            registered_boot_id = json.loads(registration_row["registration"])["node_identity"]["host_boot_id"]
            if boot_id != registered_boot_id:
                raise HardwareRegistryError("telemetry host_boot_id must match the current registered node identity")
            cursor = connection.execute(
                "SELECT host_boot_id, sequence, observed_at FROM telemetry_cursor WHERE node_id=? AND collector_id=?",
                (node_id, collector_id),
            ).fetchone()
            if cursor is not None:
                if cursor["host_boot_id"] == boot_id and sequence <= cursor["sequence"]:
                    raise HardwareRegistryError("telemetry sequence is stale or duplicate for this boot")
                if cursor["host_boot_id"] == boot_id and _parse_time(observed_at, "observed_at") < _parse_time(cursor["observed_at"], "cursor observed_at"):
                    raise HardwareRegistryError("same-boot telemetry observed_at cannot move backwards")
                if cursor["host_boot_id"] != boot_id and _parse_time(observed_at, "observed_at") <= _parse_time(cursor["observed_at"], "cursor observed_at"):
                    raise HardwareRegistryError("telemetry from an older boot cannot replace the current projection")
            connection.execute(
                "INSERT INTO telemetry_cursor(node_id, collector_id, host_boot_id, sequence, observed_at, telemetry, received_at) VALUES (?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(node_id, collector_id) DO UPDATE SET host_boot_id=excluded.host_boot_id, sequence=excluded.sequence, observed_at=excluded.observed_at, telemetry=excluded.telemetry, received_at=excluded.received_at",
                (node_id, collector_id, boot_id, sequence, observed_at, encoded, received_at),
            )
        return self.get_snapshot(node_id)["telemetry"][collector_id]

    def get_snapshot(self, node_id: str) -> dict[str, Any] | None:
        """Return a read-only copy of one registration plus current collector projections."""
        with self._connection() as connection:
            node = connection.execute("SELECT registration, registered_at, updated_at FROM hardware_nodes WHERE node_id=?", (node_id,)).fetchone()
            if node is None:
                return None
            rows = connection.execute("SELECT collector_id, telemetry FROM telemetry_cursor WHERE node_id=? ORDER BY collector_id", (node_id,)).fetchall()
        telemetry = {row["collector_id"]: self._with_freshness(json.loads(row["telemetry"])) for row in rows}
        return {"node_id": node_id, "registration": json.loads(node["registration"]), "registered_at": node["registered_at"], "updated_at": node["updated_at"], "telemetry": telemetry}

    def list_snapshots(self) -> list[dict[str, Any]]:
        with self._connection() as connection:
            node_ids = [row["node_id"] for row in connection.execute("SELECT node_id FROM hardware_nodes ORDER BY node_id")]
        return [snapshot for node_id in node_ids if (snapshot := self.get_snapshot(node_id)) is not None]

    def _with_freshness(self, telemetry: dict[str, Any]) -> dict[str, Any]:
        result = json.loads(json.dumps(telemetry))
        supplied = result["freshness"]
        projected = {**supplied, "grace_seconds": self.freshness_grace_seconds, "stale_after_seconds": self.stale_after_seconds}
        if supplied["state"] in {"unreachable", "not-collected", "unknown"}:
            result["freshness"] = projected
            return result  # Connectivity/no-collection is separately sourced; do not infer it.
        age = max(0.0, (self.clock().astimezone(timezone.utc) - _parse_time(result["observed_at"], "observed_at")).total_seconds())
        fresh_limit = result["cadence_seconds"] + self.freshness_grace_seconds
        computed = "fresh" if age <= fresh_limit else "late" if age <= self.stale_after_seconds else "stale"
        severity = {"fresh": 0, "late": 1, "stale": 2}
        state = supplied["state"] if severity[supplied["state"]] >= severity[computed] else computed
        result["freshness"] = {**projected, "state": state, "valid_until": _utc_text(_parse_time(result["observed_at"], "observed_at") + timedelta(seconds=fresh_limit))}
        return result

    def _validate_registration(self, payload: Mapping[str, Any]) -> None:
        identity = payload.get("node_identity")
        if not isinstance(identity, Mapping):
            raise HardwareRegistryError("node_identity must be an object")
        for name in ("public_key_fingerprint", "host_boot_id", "platform", "architecture"):
            _require_string(identity, name)
        capabilities = payload.get("capabilities")
        if not isinstance(capabilities, list) or not capabilities or not all(isinstance(item, str) and item for item in capabilities):
            raise HardwareRegistryError("capabilities must be a non-empty string list")
        root = payload.get("working_root")
        if not isinstance(root, Mapping) or not isinstance(root.get("path"), str) or not root["path"] or root.get("persistent") is not True or root.get("isolated_task_directories") is not True:
            raise HardwareRegistryError("working_root must be persistent with isolated_task_directories; it is not created")
        self._validate_working_root(root["path"], identity["platform"])
        endpoints = payload.get("private_endpoints")
        if not isinstance(endpoints, list) or not endpoints:
            raise HardwareRegistryError("private_endpoints must be non-empty")
        for endpoint in endpoints:
            if not isinstance(endpoint, Mapping) or endpoint.get("authentication_required") is not True:
                raise HardwareRegistryError("private endpoints require application authentication")
            uri = endpoint.get("uri")
            parsed = urlparse(uri if isinstance(uri, str) else "")
            if parsed.scheme not in {"https", "grpcs"} or not parsed.hostname or not _is_private_host(parsed.hostname, self.private_dns_suffixes):
                raise HardwareRegistryError("endpoint must use a private https/grpcs host; public endpoints are refused")
        limits = payload.get("resource_limits")
        if not isinstance(limits, Mapping) or not self._valid_limit(limits.get("cpu_cores"), integer=False) or not self._valid_limit(limits.get("memory_bytes"), integer=True) or not self._valid_limit(limits.get("storage_bytes"), integer=True):
            raise HardwareRegistryError("resource_limits must have positive cpu_cores, memory_bytes and storage_bytes")
        _parse_time(payload.get("observed_at"), "observed_at")

    def _validate_telemetry(self, telemetry: dict[str, Any]) -> None:
        for name in ("sample_id", "hardware_node_id", "host_boot_id", "source"):
            _require_string(telemetry, name)
        if not isinstance(telemetry.get("sequence"), int) or isinstance(telemetry["sequence"], bool) or telemetry["sequence"] < 0:
            raise HardwareRegistryError("sequence must be a non-negative integer")
        _parse_time(telemetry.get("observed_at"), "observed_at")
        collector = telemetry.get("collector")
        if not isinstance(collector, Mapping):
            raise HardwareRegistryError("collector must be an object")
        _require_string(collector, "id")
        _require_string(collector, "version")
        if not isinstance(telemetry.get("cadence_seconds"), int) or telemetry["cadence_seconds"] < 1:
            raise HardwareRegistryError("cadence_seconds must be a positive integer")
        if self.stale_after_seconds <= telemetry["cadence_seconds"] + self.freshness_grace_seconds:
            raise HardwareRegistryError("stale_after_seconds must exceed cadence plus freshness grace")
        freshness = telemetry.get("freshness")
        if not isinstance(freshness, Mapping) or freshness.get("state") not in {"fresh", "late", "stale", "unreachable", "not-collected", "unknown"}:
            raise HardwareRegistryError("freshness must declare a supported state")
        metrics = telemetry.get("metrics")
        if not isinstance(metrics, list) or not metrics:
            raise HardwareRegistryError("metrics must be non-empty")
        for metric in metrics:
            if not isinstance(metric, Mapping) or not isinstance(metric.get("name"), str) or not isinstance(metric.get("unit"), str):
                raise HardwareRegistryError("metric name and unit are required")
            availability = metric.get("availability")
            if not isinstance(availability, Mapping) or availability.get("state") not in _AVAILABILITY:
                raise HardwareRegistryError("metric availability must be explicit")
            device = metric.get("device")
            if not isinstance(device, Mapping) or not isinstance(device.get("kind"), str) or not isinstance(device.get("id"), str) or not device["id"]:
                raise HardwareRegistryError("metric device identity is required")
            value = metric.get("value")
            if availability["state"] == "reported":
                if value is None or (isinstance(value, float) and not math.isfinite(value)):
                    raise HardwareRegistryError("reported metric requires a finite non-null value")
            elif value is not None:
                raise HardwareRegistryError("unavailable metric values must be null, never a fabricated zero")

    @staticmethod
    def _valid_limit(value: Any, *, integer: bool) -> bool:
        if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0 or not math.isfinite(value):
            return False
        return not integer or isinstance(value, int)

    @staticmethod
    def _validate_working_root(path: str, platform: str) -> None:
        if platform == "windows":
            candidate = PureWindowsPath(path)
            if path.startswith("\\\\") or not candidate.is_absolute() or str(candidate).rstrip("\\/") == candidate.drive.rstrip("\\/") or ".." in candidate.parts:
                raise HardwareRegistryError("working_root must be an absolute non-root local Windows path without traversal or UNC")
        elif platform == "linux":
            candidate = PurePosixPath(path)
            if not candidate.is_absolute() or str(candidate) == "/" or ".." in candidate.parts:
                raise HardwareRegistryError("working_root must be an absolute non-root Linux path without traversal")
        else:
            raise HardwareRegistryError("working_root platform must be windows or linux")

    def _initialize(self) -> None:
        with self._connection() as connection:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS hardware_nodes (
                    node_id TEXT PRIMARY KEY,
                    registration TEXT NOT NULL,
                    registered_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS telemetry_cursor (
                    node_id TEXT NOT NULL REFERENCES hardware_nodes(node_id),
                    collector_id TEXT NOT NULL,
                    host_boot_id TEXT NOT NULL,
                    sequence INTEGER NOT NULL,
                    observed_at TEXT NOT NULL,
                    telemetry TEXT NOT NULL,
                    received_at TEXT NOT NULL,
                    PRIMARY KEY (node_id, collector_id)
                );
            """)

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database, timeout=10.0)
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            with connection:
                yield connection
        finally:
            connection.close()
