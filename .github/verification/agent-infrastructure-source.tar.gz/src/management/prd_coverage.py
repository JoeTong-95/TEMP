"""Durable approved-PRD coverage and native gap-ticket refinement."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import re
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol

from .github_frontier import _repo
from .context_admission import APPROVED_CONTEXT_LOCK


class PRDCoverageError(ValueError):
    """The coverage operation cannot accept the supplied contract."""


class PRDCoverageConflict(PRDCoverageError):
    """A stable discovery identity was reused incompatibly."""


class PRDCoverageUnavailable(PRDCoverageError):
    """The approved PRD or native frontier cannot be verified now."""


class CoverageOutcomeUnknown(PRDCoverageUnavailable):
    """The native writer may have applied an issue mutation."""


class CoverageIssueWriter(Protocol):
    def upsert_issue(self, **request: Any) -> Mapping[str, Any]: ...


class CoverageIssueWriterFactory(Protocol):
    def for_repository(self, repository: str, *, identity: str | None = None) -> CoverageIssueWriter: ...


class HttpGitHubIssueWriterFactory:
    """Create native writers after the accepted project selects its repository."""

    def __init__(self, request_factory: Callable[..., Callable[[str, str, Mapping[str, Any] | None], tuple[int, Any]]]) -> None:
        self.request_factory = request_factory

    def for_repository(self, repository: str, *, identity: str | None = None) -> "HttpGitHubIssueWriter":
        try:
            request = self.request_factory(repository, identity)
        except TypeError:
            request = self.request_factory(repository)
        return HttpGitHubIssueWriter(repository, request)


class HttpGitHubIssueWriter:
    """Small mutation adapter for native issue, parent, and blocker links.

    The transport is injected so the service can use the authenticated GitHub
    client in production and a controlled forge in tests.
    """

    def __init__(self, repository: str, request: Callable[[str, str, Mapping[str, Any] | None], tuple[int, Any]]) -> None:
        self.repository = _repo(repository)
        self.request = request
        owner, name = self.repository.removeprefix("https://github.com/").split("/")
        self.base = f"/repos/{owner}/{name}"

    def _raw_request(self, method: str, path: str, body: Mapping[str, Any] | None = None) -> Any:
        is_issue_create = method == "POST" and path == f"{self.base}/issues"
        try:
            status, response = self.request(method, path, body)
        except Exception as error:
            if method == "GET":
                raise PRDCoverageUnavailable("GitHub issue read is unavailable") from error
            raise CoverageOutcomeUnknown("GitHub issue mutation outcome is unknown") from error
        if not isinstance(status, int) or not 200 <= status < 300:
            if is_issue_create:
                raise CoverageOutcomeUnknown("GitHub issue creation outcome is unknown")
            raise PRDCoverageUnavailable("GitHub issue mutation was rejected")
        return response

    def _request(self, method: str, path: str, body: Mapping[str, Any] | None = None) -> Mapping[str, Any]:
        response = self._raw_request(method, path, body)
        if not isinstance(response, Mapping):
            raise PRDCoverageUnavailable("GitHub issue mutation returned invalid JSON")
        return response

    def _create_issue(self, title: str, body: str) -> tuple[Mapping[str, Any], int]:
        """Create once and classify any unusable success response as unknown."""
        response = self._raw_request(
            "POST",
            f"{self.base}/issues",
            {"title": title, "body": body, "labels": ["ready-for-agent", "stage:v1.1", "work:implementation"]},
        )
        if not isinstance(response, Mapping) or self._is_pull_request(response):
            raise CoverageOutcomeUnknown("GitHub issue creation returned an invalid identity")
        try:
            issue_number = _positive_issue(response.get("number"), "created issue number")
            self._issue_id_value(response)
        except PRDCoverageError as error:
            raise CoverageOutcomeUnknown("GitHub issue creation returned an invalid identity") from error
        return response, issue_number

    @staticmethod
    def _marker(discovery_key: str) -> str:
        return f"<!-- {discovery_key} -->"

    @staticmethod
    def _is_pull_request(item: Mapping[str, Any]) -> bool:
        return item.get("pull_request") is not None

    @staticmethod
    def _issue_number(item: Mapping[str, Any], expected: int | None = None) -> int:
        number = item.get("number")
        if type(number) is not int or number < 1 or (expected is not None and number != expected):
            raise PRDCoverageUnavailable("GitHub issue identity is invalid")
        return number

    @staticmethod
    def _issue_id_value(item: Mapping[str, Any]) -> int:
        value = item.get("id")
        if type(value) is not int or value < 1:
            raise PRDCoverageUnavailable("GitHub issue identity is invalid")
        return value

    def _get_issue(self, number: int) -> Mapping[str, Any] | None:
        """Fetch a persisted issue, treating a missing number as stale data."""
        try:
            status, response = self.request("GET", f"{self.base}/issues/{number}", None)
        except Exception as error:
            raise PRDCoverageUnavailable("GitHub issue identity lookup is unavailable") from error
        if status == 404:
            return None
        if not isinstance(status, int) or not 200 <= status < 300:
            raise PRDCoverageUnavailable("GitHub issue identity lookup was rejected")
        if not isinstance(response, Mapping):
            raise PRDCoverageUnavailable("GitHub issue identity is invalid")
        self._issue_number(response, number)
        self._issue_id_value(response)
        return response

    def _validated_reuse(self, number: int, discovery_key: str, expected_id: int | None = None) -> Mapping[str, Any] | None:
        candidate = self._get_issue(number)
        marker = self._marker(discovery_key)
        if candidate is not None and expected_id is not None and candidate["id"] != expected_id:
            raise PRDCoverageUnavailable("GitHub issue identity changed after creation")
        if candidate is not None and not self._is_pull_request(candidate):
            body = candidate.get("body")
            if isinstance(body, str) and marker in body.splitlines():
                listed = self._find_issue(discovery_key)
                if listed is None:
                    return candidate
                if (listed["number"], listed["id"]) != (candidate["number"], candidate["id"]):
                    raise PRDCoverageUnavailable("GitHub discovery marker matches multiple issues")
                return candidate
        # A stale, mismatched, missing, or PR target must be rediscovered by
        # the exact marker before any mutation is considered.
        listed = self._find_issue(discovery_key)
        if expected_id is not None and (
            listed is None or (listed["number"], listed["id"]) != (number, expected_id)
        ):
            raise PRDCoverageUnavailable("GitHub created issue identity cannot be revalidated")
        return listed

    def _find_issue(self, discovery_key: str) -> Mapping[str, Any] | None:
        matches: dict[tuple[int, int], Mapping[str, Any]] = {}
        marker = self._marker(discovery_key)
        for page in range(1, 21):
            value = self._raw_request("GET", f"{self.base}/issues?state=all&per_page=100&page={page}")
            if not isinstance(value, list) or len(value) > 100:
                raise PRDCoverageUnavailable("GitHub issue listing returned invalid JSON")
            for item in value:
                if not isinstance(item, Mapping) or self._is_pull_request(item):
                    continue
                body = item.get("body")
                if not isinstance(body, str) or marker not in body.splitlines():
                    continue
                number = self._issue_number(item)
                issue_id = self._issue_id_value(item)
                matches.setdefault((number, issue_id), item)
                if len(matches) > 1:
                    raise PRDCoverageUnavailable("GitHub discovery marker matches multiple issues")
            if len(value) < 100:
                return next(iter(matches.values()), None)
        raise PRDCoverageUnavailable("GitHub issue pagination exceeded bound")

    def _reconcile_unknown_creation(self, discovery_key: str) -> Mapping[str, Any]:
        """Bound a retry to discovery reads after an ambiguous create.

        GitHub's issue listing can lag the committed POST.  Re-read the full,
        bounded pagination window a small fixed number of times, but never
        cross the create boundary again while the outcome remains unknown.
        """
        for _attempt in range(3):
            discovered = self._find_issue(discovery_key)
            if discovered is not None:
                return discovered
        raise CoverageOutcomeUnknown("GitHub issue creation outcome remains unknown")

    def _relationship_rows(self, path: str) -> list[Mapping[str, Any]]:
        rows: list[Mapping[str, Any]] = []
        for page in range(1, 21):
            value = self._raw_request("GET", f"{path}?per_page=100&page={page}")
            if not isinstance(value, list) or len(value) > 100:
                raise PRDCoverageUnavailable("GitHub relationship listing returned invalid JSON")
            for item in value:
                if not isinstance(item, Mapping) or type(item.get("number")) is not int or item["number"] < 1:
                    raise PRDCoverageUnavailable("GitHub relationship listing returned invalid JSON")
                if self._is_pull_request(item):
                    raise PRDCoverageUnavailable("GitHub relationship points to a pull request")
                self._issue_id_value(item)
                rows.append(item)
            if len(value) < 100:
                return rows
        raise PRDCoverageUnavailable("GitHub relationship pagination exceeded bound")

    def _canonical_relationship_rows(self, path: str) -> list[Mapping[str, int]]:
        """Resolve every relationship row to the issue identity it names.

        GitHub relationship responses carry both an issue number and database
        id.  The number alone is not a stable identity: a stale row can name a
        number that now resolves to a different issue id.  Resolve all rows,
        including rows that will be removed, before allowing any mutation.
        """
        canonical: list[Mapping[str, int]] = []
        seen: dict[int, int] = {}
        for row in self._relationship_rows(path):
            issue = self._get_issue(row["number"])
            if issue is None or self._is_pull_request(issue):
                raise PRDCoverageUnavailable("GitHub relationship points to a pull request or missing issue")
            issue_id = self._issue_id_value(issue)
            if row["id"] != issue_id:
                raise PRDCoverageUnavailable("GitHub relationship identity is inconsistent")
            previous_id = seen.get(issue["number"])
            if previous_id is not None:
                if previous_id != issue_id:
                    raise PRDCoverageUnavailable("GitHub relationship identity is inconsistent")
                continue
            seen[issue["number"]] = issue_id
            canonical.append({"number": issue["number"], "id": issue_id})
        return canonical

    @staticmethod
    def _relationship_id(item: Mapping[str, Any]) -> int:
        value = item.get("id")
        if type(value) is not int or value < 1:
            raise PRDCoverageUnavailable("GitHub relationship identity is invalid")
        return value

    def _issue_id(self, number: int) -> int:
        response = self._get_issue(number)
        if response is None or self._is_pull_request(response):
            raise PRDCoverageUnavailable("GitHub relationship points to a pull request or missing issue")
        return self._issue_id_value(response)

    def upsert_issue(self, **request: Any) -> Mapping[str, Any]:
        discovery_key = _text(request.get("discovery_key"), "discovery_key")
        title = _text(request.get("title"), "title")
        body = _text(request.get("body"), "body", max_bytes=64 * 1024)
        parent = _positive_issue(request.get("parent_issue_number"), "parent_issue_number")
        previous_parent = request.get("previous_parent_issue_number")
        if previous_parent is not None:
            previous_parent = _positive_issue(previous_parent, "previous_parent_issue_number")
        blocked = request.get("blocked_by", [])
        if (
            not isinstance(blocked, list)
            or any(type(value) is not int or value < 1 for value in blocked)
            or len(set(blocked)) != len(blocked)
        ):
            raise PRDCoverageError("blocked_by is invalid")
        if parent in blocked:
            raise PRDCoverageError("parent issue cannot block its child")
        persisted = request.get("issue_number")
        persisted_id = request.get("issue_id")
        if persisted_id is not None:
            persisted_id = self._issue_id_value({"id": persisted_id})
        record_created_issue = request.get("record_created_issue")
        if record_created_issue is not None and not callable(record_created_issue):
            raise PRDCoverageError("record_created_issue is invalid")
        creation_outcome_unknown = request.get("creation_outcome_unknown", False)
        if type(creation_outcome_unknown) is not bool:
            raise PRDCoverageError("creation_outcome_unknown is invalid")
        if persisted is not None:
            persisted = _positive_issue(persisted, "issue_number")
            discovered = self._validated_reuse(persisted, discovery_key, persisted_id)
        elif creation_outcome_unknown:
            discovered = self._reconcile_unknown_creation(discovery_key)
        else:
            discovered = self._find_issue(discovery_key)
        existing = discovered["number"] if discovered is not None else None
        if discovered is not None:
            if previous_parent is None:
                for key in ("parent_issue_number", "parent_number"):
                    candidate = discovered.get(key)
                    if type(candidate) is int and candidate > 0:
                        previous_parent = candidate
                        break
                if previous_parent is None and isinstance(discovered.get("parent_issue"), Mapping):
                    candidate = discovered["parent_issue"].get("number")
                    if type(candidate) is int and candidate > 0:
                        previous_parent = candidate
        was_existing = existing is not None
        if was_existing and (existing == parent or existing == previous_parent or existing in blocked):
            raise PRDCoverageError("existing issue cannot be its own parent or blocker")
        # Validate all relationship targets and rows before the first mutation.
        # A persisted number must never cause a PATCH or relationship write
        # until its current GitHub identity and links are confirmed.
        self._issue_id(parent)
        if previous_parent is not None and previous_parent != parent:
            self._issue_id(previous_parent)
        blocker_ids = {blocker: self._issue_id(blocker) for blocker in blocked}
        parent_link = f"{self.base}/issues/{parent}/sub_issues"
        previous_parent_link = (
            f"{self.base}/issues/{previous_parent}/sub_issues"
            if previous_parent is not None and previous_parent != parent
            else None
        )
        current_children = [] if not was_existing else self._canonical_relationship_rows(parent_link)
        previous_children = (
            [] if not was_existing or previous_parent_link is None
            else self._canonical_relationship_rows(previous_parent_link)
        )
        current_blockers = []
        if was_existing:
            blocker_link = f"{self.base}/issues/{existing}/dependencies/blocked_by"
            current_blockers = self._canonical_relationship_rows(blocker_link)
            target_id = discovered["id"]
            if any(item["number"] == existing and item["id"] != target_id for item in current_children):
                raise PRDCoverageUnavailable("GitHub parent relationship identity is inconsistent")
            if any(item["number"] == existing and item["id"] != target_id for item in previous_children):
                raise PRDCoverageUnavailable("GitHub previous parent relationship identity is inconsistent")
            for item in current_blockers:
                if item["number"] in blocker_ids and item["id"] != blocker_ids[item["number"]]:
                    raise PRDCoverageUnavailable("GitHub blocker relationship identity is inconsistent")
                if item["number"] == existing:
                    raise PRDCoverageError("existing issue cannot be its own parent or blocker")
        if existing is not None:
            result = self._request("PATCH", f"{self.base}/issues/{existing}", {"title": title, "body": body})
            issue_number = existing
        else:
            result, issue_number = self._create_issue(title, body)
            if record_created_issue is not None:
                created_identity = dict(result)
                created_identity["number"] = issue_number
                if "html_url" in created_identity and "url" not in created_identity:
                    created_identity["url"] = created_identity["html_url"]
                try:
                    record_created_issue(created_identity)
                except Exception as error:
                    raise CoverageOutcomeUnknown("created issue identity could not be journaled") from error
        if self._is_pull_request(result):
            raise PRDCoverageUnavailable("GitHub mutation returned a pull request")
        issue_id = result.get("id") or (discovered or {}).get("id")
        if type(issue_id) is not int or issue_id < 1:
            issue_id = self._issue_id(issue_number)
        if discovered is not None and type(discovered.get("id")) is int and issue_id != discovered["id"]:
            raise PRDCoverageUnavailable("GitHub issue identity changed during mutation")
        blocker_link = f"{self.base}/issues/{issue_number}/dependencies/blocked_by"
        if not was_existing or not any(item.get("number") == issue_number and item.get("id") == issue_id for item in current_children):
            self._request("POST", parent_link, {"sub_issue_id": issue_id})
        if was_existing and previous_parent is not None and previous_parent != parent:
            if any(item.get("number") == issue_number and item.get("id") == issue_id for item in previous_children):
                self._raw_request("DELETE", f"{self.base}/issues/{previous_parent}/sub_issue", {"sub_issue_id": issue_id})
        desired_blockers = set(blocked)
        for item in current_blockers:
            number = item["number"]
            if number not in desired_blockers:
                blocker_id = self._relationship_id(item)
                self._raw_request("DELETE", f"{blocker_link}/{blocker_id}")
        current_blocker_numbers = {item["number"] for item in current_blockers}
        for blocker in blocked:
            if blocker in current_blocker_numbers:
                continue
            blocker_id = blocker_ids[blocker]
            self._request("POST", blocker_link, {"issue_id": blocker_id})
        output = dict(result)
        output["number"] = issue_number
        if "html_url" in output and "url" not in output:
            output["url"] = output["html_url"]
        output["discovery_key"] = discovery_key
        output["parent_issue_number"] = parent
        output["blocked_by"] = list(blocked)
        return output


_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_MAX_TEXT = 16 * 1024
_MAX_EVIDENCE = 32 * 1024
_SCHEMA = "agent-stack.prd-coverage"


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def _text(value: Any, name: str, *, max_bytes: int = _MAX_TEXT) -> str:
    if not isinstance(value, str) or not value.strip() or len(value.encode("utf-8")) > max_bytes:
        raise PRDCoverageError(f"{name} is invalid")
    return value


def _mapping(value: Any, name: str, *, max_bytes: int = _MAX_EVIDENCE) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise PRDCoverageError(f"{name} must be an object")
    try:
        encoded = _canonical(value).encode("utf-8")
    except (TypeError, ValueError) as error:
        raise PRDCoverageError(f"{name} is invalid") from error
    if len(encoded) > max_bytes:
        raise PRDCoverageError(f"{name} exceeds its bound")
    return dict(value)


def _positive_issue(value: Any, name: str) -> int:
    if type(value) is not int or value < 1:
        raise PRDCoverageError(f"{name} must be a positive integer")
    return value


class PRDCoverageStore:
    """SQLite journal for coverage observations and uncertain native writes."""

    def __init__(self, database: str | Path, *, clock: Callable[[], datetime] | None = None) -> None:
        path = Path(database)
        if not path.is_absolute() or path.is_symlink() or not path.parent.is_dir() or any(parent.is_symlink() for parent in path.parents):
            raise PRDCoverageError("coverage database location is unsafe")
        self.path = path
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        with self._db() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS prd_coverage_discoveries (
                    discovery_key TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    discovery_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    input_hash TEXT NOT NULL,
                    requirement TEXT NOT NULL,
                    evidence TEXT NOT NULL,
                    parent_issue_number INTEGER NOT NULL,
                    blocked_by TEXT NOT NULL,
                    status TEXT NOT NULL,
                    issue_number INTEGER,
                    issue_url TEXT,
                    response TEXT,
                    previous_parent_issue_number INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    claim_token TEXT,
                    claim_started_at REAL
                )"""
            )
            columns = {row[1] for row in connection.execute("PRAGMA table_info(prd_coverage_discoveries)")}
            if "claim_token" not in columns:
                connection.execute("ALTER TABLE prd_coverage_discoveries ADD COLUMN claim_token TEXT")
            if "claim_started_at" not in columns:
                connection.execute("ALTER TABLE prd_coverage_discoveries ADD COLUMN claim_started_at REAL")
            if "previous_parent_issue_number" not in columns:
                connection.execute("ALTER TABLE prd_coverage_discoveries ADD COLUMN previous_parent_issue_number INTEGER")

    @contextmanager
    def _db(self):
        connection = sqlite3.connect(self.path, timeout=30)
        connection.execute("PRAGMA busy_timeout=30000")
        connection.row_factory = sqlite3.Row
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def get(self, discovery_key: str) -> dict[str, Any] | None:
        with self._db() as connection:
            row = connection.execute("SELECT * FROM prd_coverage_discoveries WHERE discovery_key=?", (discovery_key,)).fetchone()
        return self._projection(row) if row is not None else None

    def list(self, project_id: str) -> list[dict[str, Any]]:
        with self._db() as connection:
            rows = connection.execute("SELECT * FROM prd_coverage_discoveries WHERE project_id=? ORDER BY discovery_key", (project_id,)).fetchall()
        return [self._projection(row) for row in rows]

    @staticmethod
    def _projection(row: sqlite3.Row) -> dict[str, Any]:
        value = dict(row)
        value.pop("claim_token", None)
        value.pop("claim_started_at", None)
        value["requirement"] = json.loads(value.pop("requirement"))
        value["evidence"] = json.loads(value.pop("evidence"))
        value["blocked_by"] = json.loads(value.pop("blocked_by"))
        response = value.pop("response")
        value["response"] = json.loads(response) if response else None
        return value

    def begin(self, value: Mapping[str, Any]) -> dict[str, Any]:
        now = value.get("now") or self.clock().astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        row = {
            "discovery_key": value["discovery_key"], "project_id": value["project_id"], "revision": value["revision"],
            "discovery_id": value["discovery_id"], "kind": value["kind"], "input_hash": value["input_hash"],
            "requirement": _canonical(value["requirement"]), "evidence": _canonical(value["evidence"]),
            "parent_issue_number": value["parent_issue_number"], "blocked_by": _canonical(value["blocked_by"]),
            "status": value["status"], "issue_number": value.get("issue_number"), "issue_url": value.get("issue_url"),
            "response": _canonical(value["response"]) if value.get("response") is not None else None,
            "previous_parent_issue_number": value.get("previous_parent_issue_number"),
            "created_at": value.get("created_at", now), "updated_at": now,
        }
        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT kind FROM prd_coverage_discoveries WHERE discovery_key=?", (value["discovery_key"],)).fetchone()
            if existing is not None and existing[0] != value["kind"]:
                raise PRDCoverageConflict("discovery identity cannot change its classification")
            connection.execute(
                """INSERT INTO prd_coverage_discoveries
                (discovery_key,project_id,revision,discovery_id,kind,input_hash,requirement,evidence,parent_issue_number,blocked_by,status,issue_number,issue_url,response,previous_parent_issue_number,created_at,updated_at,claim_token,claim_started_at)
                VALUES (:discovery_key,:project_id,:revision,:discovery_id,:kind,:input_hash,:requirement,:evidence,:parent_issue_number,:blocked_by,:status,:issue_number,:issue_url,:response,:previous_parent_issue_number,:created_at,:updated_at,NULL,NULL)
                ON CONFLICT(discovery_key) DO UPDATE SET input_hash=excluded.input_hash, requirement=excluded.requirement,
                evidence=excluded.evidence, parent_issue_number=excluded.parent_issue_number, blocked_by=excluded.blocked_by,
                previous_parent_issue_number=excluded.previous_parent_issue_number,
                updated_at=excluded.updated_at""", row,
            )
        return self.get(value["discovery_key"]) or {}

    def claim(self, value: Mapping[str, Any]) -> dict[str, Any]:
        """Atomically claim one discovery key before crossing the native boundary."""
        now = value.get("now") or self.clock().astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        token = uuid.uuid4().hex
        started = time.time()
        row = {
            "discovery_key": value["discovery_key"], "project_id": value["project_id"], "revision": value["revision"],
            "discovery_id": value["discovery_id"], "kind": value["kind"], "input_hash": value["input_hash"],
            "requirement": _canonical(value["requirement"]), "evidence": _canonical(value["evidence"]),
            "parent_issue_number": value["parent_issue_number"], "blocked_by": _canonical(value["blocked_by"]),
            "status": "native_write_in_progress", "issue_number": value.get("issue_number"),
            "issue_url": value.get("issue_url"), "response": _canonical(value["response"]) if value.get("response") is not None else None,
            "previous_parent_issue_number": value.get("previous_parent_issue_number"),
            "created_at": value.get("created_at", now), "updated_at": now,
        }
        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT * FROM prd_coverage_discoveries WHERE discovery_key=?", (value["discovery_key"],)).fetchone()
            if existing is not None:
                existing_value = dict(existing)
                if existing_value.get("kind") != value["kind"]:
                    return {"state": "conflict", "record": self._projection(existing)}
                active_token = existing_value.get("claim_token")
                active_started = existing_value.get("claim_started_at")
                if existing_value.get("input_hash") == value["input_hash"] and existing_value.get("status") in {"ticket_created", "needs_human_clarification"}:
                    return {"state": "complete", "record": self._projection(existing)}
                if active_token and active_started is not None and started - float(active_started) < 300:
                    return {"state": "busy", "record": self._projection(existing)}
                if row["previous_parent_issue_number"] is None:
                    row["previous_parent_issue_number"] = existing_value.get("previous_parent_issue_number")
                if row["previous_parent_issue_number"] is None and existing_value.get("parent_issue_number") != row["parent_issue_number"]:
                    row["previous_parent_issue_number"] = existing_value.get("parent_issue_number")
                connection.execute(
                    """UPDATE prd_coverage_discoveries SET project_id=?,revision=?,discovery_id=?,kind=?,input_hash=?,requirement=?,evidence=?,
                    parent_issue_number=?,blocked_by=?,status=?,issue_number=?,issue_url=?,response=?,previous_parent_issue_number=?,updated_at=?,claim_token=?,claim_started_at=?
                    WHERE discovery_key=?""",
                    (row["project_id"], row["revision"], row["discovery_id"], row["kind"], row["input_hash"], row["requirement"], row["evidence"], row["parent_issue_number"], row["blocked_by"], row["status"], row["issue_number"] if row["issue_number"] is not None else existing_value.get("issue_number"), row["issue_url"] if row["issue_url"] is not None else existing_value.get("issue_url"), row["response"] if row["response"] is not None else existing_value.get("response"), row["previous_parent_issue_number"], row["updated_at"], token, started, value["discovery_key"]),
                )
            else:
                connection.execute(
                    """INSERT INTO prd_coverage_discoveries
                    (discovery_key,project_id,revision,discovery_id,kind,input_hash,requirement,evidence,parent_issue_number,blocked_by,status,issue_number,issue_url,response,previous_parent_issue_number,created_at,updated_at,claim_token,claim_started_at)
                    VALUES (:discovery_key,:project_id,:revision,:discovery_id,:kind,:input_hash,:requirement,:evidence,:parent_issue_number,:blocked_by,:status,:issue_number,:issue_url,:response,:previous_parent_issue_number,:created_at,:updated_at,:claim_token,:claim_started_at)""",
                    {**row, "claim_token": token, "claim_started_at": started},
                )
            claimed = connection.execute("SELECT * FROM prd_coverage_discoveries WHERE discovery_key=?", (value["discovery_key"],)).fetchone()
            return {"state": "claimed", "token": token, "record": self._projection(claimed)}

    def release(self, discovery_key: str, claim_token: str, *, status: str = "pending_native_write") -> dict[str, Any]:
        if status not in {"pending_native_write", "native_creation_outcome_unknown"}:
            raise PRDCoverageError("coverage release status is invalid")
        now = self.clock().astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        with self._db() as connection:
            connection.execute(
                "UPDATE prd_coverage_discoveries SET status=?,claim_token=NULL,claim_started_at=NULL,updated_at=? WHERE discovery_key=? AND claim_token=?",
                (status, now, discovery_key, claim_token),
            )
        return self.get(discovery_key) or {}

    def record_created_issue(self, discovery_key: str, claim_token: str, issue: Mapping[str, Any]) -> dict[str, Any]:
        """Persist a canonical create acknowledgement before relationship writes."""
        if not isinstance(issue, Mapping):
            raise PRDCoverageError("created issue identity is invalid")
        number = _positive_issue(issue.get("number"), "created issue number")
        issue_id = issue.get("id")
        if type(issue_id) is not int or issue_id < 1:
            raise PRDCoverageError("created issue database id is invalid")
        issue_url = issue.get("url")
        if issue_url is not None and (not isinstance(issue_url, str) or not issue_url):
            raise PRDCoverageError("created issue URL is invalid")
        now = self.clock().astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = connection.execute(
                "SELECT issue_number,response,status,claim_token FROM prd_coverage_discoveries WHERE discovery_key=?",
                (discovery_key,),
            ).fetchone()
            if current is None or current["claim_token"] != claim_token or current["status"] != "native_write_in_progress":
                raise PRDCoverageConflict("coverage claim is stale or invalid")
            if current["issue_number"] is not None and current["issue_number"] != number:
                raise PRDCoverageConflict("created issue number conflicts with the durable identity")
            if current["response"]:
                prior = json.loads(current["response"])
                if type(prior.get("id")) is int and prior["id"] != issue_id:
                    raise PRDCoverageConflict("created issue database id conflicts with the durable identity")
            connection.execute(
                "UPDATE prd_coverage_discoveries SET issue_number=?,issue_url=?,response=?,updated_at=? WHERE discovery_key=? AND claim_token=?",
                (number, issue_url, _canonical(issue), now, discovery_key, claim_token),
            )
        return self.get(discovery_key) or {}

    def finish(self, discovery_key: str, *, status: str, issue_number: int | None, issue_url: str | None, response: Mapping[str, Any] | None, claim_token: str | None = None) -> dict[str, Any]:
        now = self.clock().astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        with self._db() as connection:
            updated = connection.execute(
                "UPDATE prd_coverage_discoveries SET status=?,issue_number=?,issue_url=?,response=?,previous_parent_issue_number=NULL,updated_at=?,claim_token=NULL,claim_started_at=NULL WHERE discovery_key=? AND (claim_token=? OR (? IS NULL AND claim_token IS NULL))",
                (status, issue_number, issue_url, _canonical(response) if response is not None else None, now, discovery_key, claim_token, claim_token),
            )
            if updated.rowcount != 1:
                raise PRDCoverageConflict("coverage claim is stale or invalid")
        return self.get(discovery_key) or {}


class PRDCoverageService:
    """Record approved-PRD gaps and idempotently hand them to the native writer."""

    def __init__(self, database: str | Path, projects: Any, frontier: Any, writer: CoverageIssueWriter | None, *, clock: Callable[[], datetime] | None = None) -> None:
        self.store = PRDCoverageStore(database, clock=clock)
        self.projects = projects
        self.frontier = frontier
        self.writer = writer

    @staticmethod
    def _requirement(value: Any) -> dict[str, str]:
        item = _mapping(value, "requirement")
        if set(item) != {"id", "title", "description"}:
            raise PRDCoverageError("requirement must contain exactly id, title, and description")
        return {key: _text(item[key], f"requirement.{key}") for key in item}

    def _approved_context(self, project_id: str, expected_revision: int) -> tuple[dict[str, Any], dict[str, Any]]:
        try:
            draft = self.projects.draft(project_id)
        except (KeyError, ValueError, TypeError) as error:
            raise PRDCoverageUnavailable("project PRD is unavailable") from error
        if draft.get("revision") != expected_revision or draft.get("confirmed_revision") != expected_revision:
            raise PRDCoverageConflict("coverage requires the exact human-confirmed PRD revision")
        payload = draft.get("payload")
        if not isinstance(payload, Mapping) or not isinstance(payload.get("prd_reference"), str) or not payload["prd_reference"]:
            raise PRDCoverageError("approved project PRD reference is missing")
        try:
            frontier = self.frontier.view(project_id)
        except (KeyError, ValueError, TypeError) as error:
            raise PRDCoverageUnavailable("native issue frontier is unavailable") from error
        if not isinstance(frontier, Mapping) or frontier.get("status") != "available" or frontier.get("project_revision") != expected_revision:
            raise PRDCoverageUnavailable("fresh native issue frontier is required")
        return dict(draft), dict(frontier)

    @staticmethod
    def _context_fingerprint(draft: Mapping[str, Any], frontier: Mapping[str, Any]) -> str:
        """Identify stable approved context used for a native mutation.

        ``GitHubFrontierStore.read`` derives the frontier freshness state and age
        from its clock on every read.  Those values describe cache recency, not
        the authoritative project or issue context, so they must not make an
        unchanged frontier appear to have changed between the pre-claim and
        post-claim reads.
        """
        stable_frontier = {
            key: value
            for key, value in frontier.items()
            if key not in {"freshness", "status"}
        }
        return hashlib.sha256(_canonical({"draft": draft, "frontier": stable_frontier}).encode("utf-8")).hexdigest()

    @staticmethod
    def _frontier_numbers(frontier: Mapping[str, Any]) -> set[int]:
        numbers: set[int] = set()
        parent = frontier.get("parent_context")
        if isinstance(parent, Mapping) and type(parent.get("number")) is int:
            numbers.add(parent["number"])
        for group in ("actionable", "blocked"):
            values = frontier.get(group, [])
            if not isinstance(values, list):
                raise PRDCoverageUnavailable("native issue frontier is malformed")
            for item in values:
                if not isinstance(item, Mapping) or type(item.get("number")) is not int or item["number"] < 1:
                    raise PRDCoverageUnavailable("native issue frontier is malformed")
                numbers.add(item["number"])
                ancestry = item.get("ancestry", [])
                if not isinstance(ancestry, list):
                    raise PRDCoverageUnavailable("native issue frontier is malformed")
                if any(type(value) is not int or value < 1 for value in ancestry):
                    raise PRDCoverageUnavailable("native issue frontier is malformed")
                nested = item.get("blockers", [])
                if not isinstance(nested, list):
                    raise PRDCoverageUnavailable("native issue frontier is malformed")
                for blocker in nested:
                    if not isinstance(blocker, Mapping) or type(blocker.get("number")) is not int or blocker["number"] < 1:
                        raise PRDCoverageUnavailable("native issue frontier is malformed")
                    numbers.add(blocker["number"])
        return numbers

    def discover(self, project_id: str, expected_revision: int, discovery_id: str, kind: str, requirement: Mapping[str, Any], evidence: Mapping[str, Any], parent_issue_number: int | None = None, blocked_by: list[int] | None = None) -> dict[str, Any]:
        project_id = _text(project_id, "project_id")
        expected_revision = _positive_issue(expected_revision, "expected_revision")
        discovery_id = _text(discovery_id, "discovery_id")
        if _SAFE.fullmatch(discovery_id) is None:
            raise PRDCoverageError("discovery_id is invalid")
        if not isinstance(kind, str) or kind not in {"approved_gap", "proposed_change"}:
            raise PRDCoverageError("kind must be approved_gap or proposed_change")
        requirement = self._requirement(requirement)
        evidence = _mapping(evidence, "evidence")
        if any(not isinstance(evidence.get(key), str) or not evidence[key].strip() for key in ("source", "details")):
            raise PRDCoverageError("evidence must include a substantive source and detail")
        draft, frontier = self._approved_context(project_id, expected_revision)
        known = self._frontier_numbers(frontier)
        native_parent = _positive_issue(parent_issue_number if parent_issue_number is not None else frontier.get("parent_issue_number"), "parent_issue_number")
        if native_parent not in known:
            raise PRDCoverageError("parent issue is not present in the native frontier")
        blocked_by = [] if blocked_by is None else blocked_by
        if not isinstance(blocked_by, list) or any(type(value) is not int or value < 1 for value in blocked_by) or len(set(blocked_by)) != len(blocked_by):
            raise PRDCoverageError("blocked_by must contain unique positive issue numbers")
        if native_parent in blocked_by:
            raise PRDCoverageError("parent issue cannot block its child")
        if any(value not in known for value in blocked_by):
            raise PRDCoverageError("blocked issue is not present in the native frontier")
        discovery_key = f"agent-stack:prd-gap:{project_id}:{expected_revision}:{discovery_id}"
        payload = {"kind": kind, "requirement": requirement, "evidence": evidence, "parent_issue_number": native_parent, "blocked_by": sorted(blocked_by)}
        input_hash = hashlib.sha256(_canonical(payload).encode("utf-8")).hexdigest()
        existing = self.store.get(discovery_key)
        if existing is not None and existing["kind"] != kind:
            raise PRDCoverageConflict("discovery identity cannot change its classification")
        if existing is not None and existing["input_hash"] == input_hash and existing["status"] in {"ticket_created", "needs_human_clarification"}:
            return {**existing, "requires_human_clarification": existing["status"] == "needs_human_clarification"}
        if kind == "proposed_change":
            result = self.store.begin({**payload, "discovery_key": discovery_key, "project_id": project_id, "revision": expected_revision, "discovery_id": discovery_id, "input_hash": input_hash, "status": "needs_human_clarification", "response": None, "issue_number": existing.get("issue_number") if existing else None, "issue_url": existing.get("issue_url") if existing else None})
            return {**result, "requires_human_clarification": True}
        if self.writer is None:
            raise PRDCoverageUnavailable("native issue writer is not configured")
        approved_context_fingerprint = self._context_fingerprint(draft, frontier)
        previous_parent = existing.get("previous_parent_issue_number") if existing else None
        if previous_parent is None and existing is not None and existing.get("parent_issue_number") != native_parent:
            previous_parent = existing.get("parent_issue_number")
        claim_value = {**payload, "discovery_key": discovery_key, "project_id": project_id, "revision": expected_revision, "discovery_id": discovery_id, "input_hash": input_hash, "status": "pending_native_write", "response": existing.get("response") if existing else None, "issue_number": existing.get("issue_number") if existing else None, "issue_url": existing.get("issue_url") if existing else None, "previous_parent_issue_number": previous_parent}
        deadline = time.monotonic() + 30
        while True:
            claim = self.store.claim(claim_value)
            if claim["state"] == "claimed":
                claim_token = claim["token"]
                break
            if claim["state"] == "complete":
                record = claim["record"]
                return {**record, "requires_human_clarification": record["status"] == "needs_human_clarification"}
            if claim["state"] == "conflict":
                raise PRDCoverageConflict("discovery identity cannot change its classification")
            if time.monotonic() >= deadline:
                raise PRDCoverageUnavailable("native coverage write is already in progress")
            time.sleep(0.01)
        issue_number_for_write = existing.get("issue_number") if existing else None
        existing_response = existing.get("response") if existing else None
        issue_id_for_write = existing_response.get("id") if isinstance(existing_response, Mapping) and type(existing_response.get("id")) is int else None
        creation_outcome_unknown = (
            existing is not None
            and issue_number_for_write is None
            and existing.get("status") in {"native_creation_outcome_unknown", "native_write_in_progress"}
        )
        try:
            # Hold the Management admission boundary through writer acquisition
            # and the native mutation.  A second context read closes the seam
            # where a writer factory could otherwise observe stale inputs.
            with APPROVED_CONTEXT_LOCK:
                final_draft, final_frontier = self._approved_context(project_id, expected_revision)
                if self._context_fingerprint(final_draft, final_frontier) != approved_context_fingerprint:
                    raise PRDCoverageConflict("approved project context changed after claim")
                final_parent = _positive_issue(parent_issue_number if parent_issue_number is not None else final_frontier.get("parent_issue_number"), "parent_issue_number")
                if final_parent != native_parent:
                    raise PRDCoverageConflict("native parent changed after claim")
                body = "<!-- " + discovery_key + " -->\n\n" + requirement["description"] + "\n\nEvidence: " + _canonical(evidence)
                request = {"discovery_key": discovery_key, "title": requirement["title"], "body": body, "parent_issue_number": native_parent, "previous_parent_issue_number": previous_parent, "blocked_by": sorted(blocked_by), "issue_number": issue_number_for_write, "issue_id": issue_id_for_write, "creation_outcome_unknown": creation_outcome_unknown, "record_created_issue": lambda issue: self.store.record_created_issue(discovery_key, claim_token, issue)}
                repository = final_frontier.get("repository")
                payload = final_draft.get("payload")
                binding = payload.get("forge_binding") if isinstance(payload, Mapping) else None
                identity = binding.get("identity") if isinstance(binding, Mapping) and isinstance(binding.get("identity"), str) else None
                writer = self.writer
                factory = getattr(writer, "for_repository", None)
                if callable(factory):
                    if not isinstance(repository, str) or not repository:
                        raise PRDCoverageUnavailable("native issue repository is unavailable")
                    try:
                        import inspect
                        accepts_identity = "identity" in inspect.signature(factory).parameters
                    except (TypeError, ValueError):
                        accepts_identity = False
                    writer = factory(repository, identity=identity) if accepts_identity else factory(repository)
                checked_draft, checked_frontier = self._approved_context(project_id, expected_revision)
                if self._context_fingerprint(checked_draft, checked_frontier) != approved_context_fingerprint:
                    raise PRDCoverageConflict("approved project context changed during writer admission")
                response = writer.upsert_issue(**request)
        except CoverageOutcomeUnknown:
            status = "native_creation_outcome_unknown" if issue_number_for_write is None else "pending_native_write"
            self.store.release(discovery_key, claim_token, status=status)
            raise
        except PRDCoverageError:
            status = "native_creation_outcome_unknown" if creation_outcome_unknown else "pending_native_write"
            self.store.release(discovery_key, claim_token, status=status)
            raise
        except Exception as error:
            status = "native_creation_outcome_unknown" if creation_outcome_unknown else "pending_native_write"
            self.store.release(discovery_key, claim_token, status=status)
            raise PRDCoverageUnavailable("native issue writer is unavailable") from error
        if not isinstance(response, Mapping) or type(response.get("number")) is not int or response["number"] < 1:
            status = "native_creation_outcome_unknown" if issue_number_for_write is None else "pending_native_write"
            self.store.release(discovery_key, claim_token, status=status)
            raise PRDCoverageUnavailable("native issue writer returned an invalid issue")
        issue_url = response.get("url")
        if issue_url is not None and (not isinstance(issue_url, str) or not issue_url):
            status = "native_creation_outcome_unknown" if issue_number_for_write is None else "pending_native_write"
            self.store.release(discovery_key, claim_token, status=status)
            raise PRDCoverageUnavailable("native issue writer returned an invalid URL")
        finished = self.store.finish(discovery_key, status="ticket_created", issue_number=response["number"], issue_url=issue_url, response=dict(response), claim_token=claim_token)
        if finished.get("status") != "ticket_created":
            raise PRDCoverageUnavailable("native coverage write did not complete")
        return finished

    def view(self, project_id: str) -> dict[str, Any]:
        project_id = _text(project_id, "project_id")
        draft = self.projects.draft(project_id)
        records = self.store.list(project_id)
        try:
            frontier = self.frontier.view(project_id)
        except (KeyError, ValueError, TypeError):
            frontier = {"status": "unavailable"}
        return {
            "schema": _SCHEMA,
            "project_id": project_id,
            "revision": draft.get("revision"),
            "coverage_status": "incomplete",
            "complete": False,
            "frontier_status": frontier.get("status"),
            "frontier_empty": not frontier.get("actionable") and not frontier.get("blocked"),
            "discoveries": records,
        }
