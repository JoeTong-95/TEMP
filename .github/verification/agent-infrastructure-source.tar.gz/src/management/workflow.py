"""Small, declarative workflow graph contract for the local v1 fixture.

This intentionally describes a graph; it neither selects nor imitates a workflow
engine.  A future adapter may compile a validated ``WorkflowSpec`` for Prefect or
another engine, but this module does not claim that it has done so.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import re
from typing import Any, Mapping, Sequence


_ID = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")
_KINDS = {"input", "tool", "artifact"}
_TYPES = {"fixture_payload", "fixture_result"}


class WorkflowValidationError(ValueError):
    """A graph is not a safe v1 input -> tool -> artifact declaration."""


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def _identifier(value: object, label: str) -> str:
    if not isinstance(value, str) or not _ID.fullmatch(value):
        raise WorkflowValidationError(label + " must be a safe 1-64 character identifier")
    return value


def _type(value: object, label: str) -> str:
    if not isinstance(value, str) or value not in _TYPES:
        raise WorkflowValidationError(label + " is not a v1 declared type")
    return value


def _mapping(value: object, label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise WorkflowValidationError(label + " must be an object")
    _validate_json(value, label)
    # JSON round-trip makes a private, canonical JSON-compatible copy.
    try:
        return json.loads(_json(dict(value)))
    except (TypeError, ValueError) as error:
        raise WorkflowValidationError(label + " must be JSON-safe") from error


def _validate_json(value: object, label: str, depth: int = 0) -> None:
    """Reject lossy/non-portable config before it can affect a version hash."""
    if depth > 16:
        raise WorkflowValidationError(label + " exceeds maximum JSON nesting")
    if value is None or isinstance(value, (str, int, float, bool)):
        # JSON encoder below rejects non-finite floats with allow_nan=False.
        return
    if isinstance(value, Mapping):
        for key, item in value.items():
            if not isinstance(key, str):
                raise WorkflowValidationError(label + " object keys must be strings")
            _validate_json(item, label, depth + 1)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _validate_json(item, label, depth + 1)
        return
    raise WorkflowValidationError(label + " contains a non-JSON value")


@dataclass(frozen=True)
class WorkflowNode:
    """A semantic node; canvas coordinates and machine endpoints are non-canonical."""

    node_id: str
    kind: str
    input_type: str | None = None
    output_type: str | None = None
    config: Mapping[str, Any] = field(default_factory=dict)
    canvas: Mapping[str, Any] | None = None
    physical_endpoint: str | None = None

    def semantic(self) -> dict[str, Any]:
        node_id = _identifier(self.node_id, "node_id")
        if not isinstance(self.kind, str) or self.kind not in _KINDS:
            raise WorkflowValidationError("unknown node kind: " + repr(self.kind))
        if self.input_type is not None:
            _type(self.input_type, "input_type")
        if self.output_type is not None:
            _type(self.output_type, "output_type")
        return {
            "config": _mapping(self.config, "node config"),
            "input_type": self.input_type,
            "kind": self.kind,
            "node_id": node_id,
            "output_type": self.output_type,
        }


@dataclass(frozen=True)
class WorkflowEdge:
    source: str
    target: str
    value_type: str
    canvas: Mapping[str, Any] | None = None
    physical_endpoint: str | None = None

    def semantic(self) -> dict[str, str]:
        return {
            "source": _identifier(self.source, "edge source"),
            "target": _identifier(self.target, "edge target"),
            "value_type": _type(self.value_type, "edge value_type"),
        }


@dataclass(frozen=True)
class WorkflowSpec:
    """The deliberately narrow v1 graph: exactly input -> tool -> artifact."""

    nodes: Sequence[WorkflowNode]
    edges: Sequence[WorkflowEdge]
    schema: str = "agent-stack.workflow.v1"

    @classmethod
    def from_dict(cls, document: Mapping[str, Any]) -> "WorkflowSpec":
        if not isinstance(document, Mapping):
            raise WorkflowValidationError("workflow document must be an object")
        unknown_document = set(document) - {"schema", "nodes", "edges"}
        if unknown_document:
            raise WorkflowValidationError("unknown workflow document fields: " + ", ".join(sorted(map(str, unknown_document))))
        raw_nodes, raw_edges = document.get("nodes"), document.get("edges")
        if not isinstance(raw_nodes, list) or not isinstance(raw_edges, list):
            raise WorkflowValidationError("workflow document needs nodes and edges arrays")
        nodes: list[WorkflowNode] = []
        for item in raw_nodes:
            if not isinstance(item, Mapping):
                raise WorkflowValidationError("every node must be an object")
            unknown_node = set(item) - {"node_id", "kind", "input_type", "output_type", "config", "canvas", "physical_endpoint"}
            if unknown_node:
                raise WorkflowValidationError("unknown node fields: " + ", ".join(sorted(map(str, unknown_node))))
            nodes.append(WorkflowNode(
                node_id=item.get("node_id"), kind=item.get("kind"),
                input_type=item.get("input_type"), output_type=item.get("output_type"),
                config=item.get("config", {}), canvas=item.get("canvas"),
                physical_endpoint=item.get("physical_endpoint"),
            ))
        edges: list[WorkflowEdge] = []
        for item in raw_edges:
            if not isinstance(item, Mapping):
                raise WorkflowValidationError("every edge must be an object")
            unknown_edge = set(item) - {"source", "target", "value_type", "canvas", "physical_endpoint"}
            if unknown_edge:
                raise WorkflowValidationError("unknown edge fields: " + ", ".join(sorted(map(str, unknown_edge))))
            edges.append(WorkflowEdge(
                source=item.get("source"), target=item.get("target"), value_type=item.get("value_type"),
                canvas=item.get("canvas"), physical_endpoint=item.get("physical_endpoint"),
            ))
        return cls(nodes=nodes, edges=edges, schema=document.get("schema", "agent-stack.workflow.v1"))

    def validate(self) -> None:
        if self.schema != "agent-stack.workflow.v1":
            raise WorkflowValidationError("unknown workflow schema")
        if len(self.nodes) != 3 or len(self.edges) != 2:
            raise WorkflowValidationError("v1 requires exactly three nodes and two edges")
        semantic_nodes = [node.semantic() for node in self.nodes]
        ids = [node["node_id"] for node in semantic_nodes]
        if len(ids) != len(set(ids)):
            raise WorkflowValidationError("node ids must be unique")
        by_id = {node["node_id"]: node for node in semantic_nodes}
        if {node["kind"] for node in semantic_nodes} != _KINDS:
            raise WorkflowValidationError("v1 requires exactly one input, tool, and artifact node")
        input_node = next(node for node in semantic_nodes if node["kind"] == "input")
        tool_node = next(node for node in semantic_nodes if node["kind"] == "tool")
        artifact_node = next(node for node in semantic_nodes if node["kind"] == "artifact")
        if input_node["input_type"] is not None or input_node["output_type"] != "fixture_payload" or input_node["config"] != {}:
            raise WorkflowValidationError("input must produce fixture_payload and have no input")
        if (tool_node["input_type"] != "fixture_payload" or tool_node["output_type"] != "fixture_result"
                or tool_node["config"] != {"operation": "sum"}):
            raise WorkflowValidationError("tool must explicitly be the sum fixture operation")
        if artifact_node["input_type"] != "fixture_result" or artifact_node["output_type"] is not None or artifact_node["config"] != {}:
            raise WorkflowValidationError("artifact must consume fixture_result and have no output")

        semantic_edges = [edge.semantic() for edge in self.edges]
        pairs = {(edge["source"], edge["target"], edge["value_type"]) for edge in semantic_edges}
        if len(pairs) != len(semantic_edges):
            raise WorkflowValidationError("duplicate edges are not permitted")
        for edge in semantic_edges:
            if edge["source"] not in by_id or edge["target"] not in by_id:
                raise WorkflowValidationError("edge has a dangling node reference")
            if by_id[edge["source"]]["output_type"] != edge["value_type"] or by_id[edge["target"]]["input_type"] != edge["value_type"]:
                raise WorkflowValidationError("edge type does not match its node ports")
        expected = {
            (input_node["node_id"], tool_node["node_id"], "fixture_payload"),
            (tool_node["node_id"], artifact_node["node_id"], "fixture_result"),
        }
        if pairs != expected:
            raise WorkflowValidationError("v1 graph must be input -> tool -> artifact without cycles")

    def canonical_document(self) -> dict[str, Any]:
        self.validate()
        return {
            "edges": sorted((edge.semantic() for edge in self.edges), key=lambda edge: (edge["source"], edge["target"], edge["value_type"])),
            "nodes": sorted((node.semantic() for node in self.nodes), key=lambda node: node["node_id"]),
            "schema": self.schema,
        }

    @property
    def version_hash(self) -> str:
        """Immutable semantic identity; layout and physical routing never affect it."""
        return hashlib.sha256(_json(self.canonical_document()).encode("utf-8")).hexdigest()
