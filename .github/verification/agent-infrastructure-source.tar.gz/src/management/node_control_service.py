"""External-configured loopback node-control service launcher."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping

from .hardware_registry import HardwareRegistry
from .node_control_api import NodeControlConfig, NodeControlError, serve
from .state_boundary import ManagementStateBoundaryError, validate_durable_leaf, validate_state_root


def load_config(path: str | Path) -> tuple[Path, NodeControlConfig]:
    source = Path(path)
    if not source.is_absolute() or not source.is_file() or source.is_symlink() or any(parent.is_symlink() for parent in source.parents):
        raise NodeControlError("node-control configuration is unsafe")
    try:
        raw: Any = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise NodeControlError("node-control configuration is invalid") from error
    required = {"database", "listen_host", "listen_port", "tokens"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or set(raw) - (required | {"state_root"}) or not isinstance(raw["database"], str) or not isinstance(raw["tokens"], list):
        raise NodeControlError("node-control configuration schema is invalid")
    database = Path(raw["database"])
    try:
        state_root = validate_state_root(raw.get("state_root", str(database.parent)), "node-control state root")
        database = validate_durable_leaf(database, state_root, label="node-control database")
    except (ManagementStateBoundaryError, TypeError) as error:
        raise NodeControlError("node-control database is unsafe") from error
    token_files: dict[Path, str] = {}
    for entry in raw["tokens"]:
        if not isinstance(entry, Mapping) or set(entry) != {"token_file", "node_id"} or not isinstance(entry["token_file"], str) or not isinstance(entry["node_id"], str):
            raise NodeControlError("node-control token declaration is invalid")
        token = Path(entry["token_file"])
        if token in token_files:
            raise NodeControlError("node-control token declaration is duplicated")
        token_files[token] = entry["node_id"]
    return database, NodeControlConfig(token_files, raw["listen_host"], raw["listen_port"])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="authenticated loopback node-control service")
    parser.add_argument("--config", required=True)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args(argv)
    database, config = load_config(args.config)
    if args.check:
        print("configuration validated; listener was not started")
        return 0
    server = serve(HardwareRegistry(database), config)
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
