"""Fail-closed projection of one still-approved project start intent."""
from __future__ import annotations

import hashlib
import json
from typing import Any, Callable, Mapping

from .project_control import ProjectControl
from .provider_registry import ProviderRegistry


class ExecutionPlanError(ValueError): pass


def _canonical(value: Any) -> str: return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


class ManagementExecutionPlanner:
    def __init__(self, projects: ProjectControl, providers: ProviderRegistry, validate_project: Callable[[str, dict[str, Any]], bool], runtime_bindings: Mapping[str, str], verification_actions: Mapping[str, Mapping[str, str]] | None = None, admission: Callable[[str, dict[str, Any]], Mapping[str, Any]] | None = None) -> None:
        if not isinstance(runtime_bindings, Mapping) or any(not isinstance(key, str) or not key or not isinstance(value, str) or not value for key, value in runtime_bindings.items()): raise ExecutionPlanError("runtime binding allowlist is invalid")
        if verification_actions is not None and (not isinstance(verification_actions,Mapping) or any(not isinstance(project,str) or not isinstance(action,Mapping) or set(action)!={"workspace_id","command_id"} or any(not isinstance(value,str) or not value for value in action.values()) for project,action in verification_actions.items())): raise ExecutionPlanError("verification action allowlist is invalid")
        self.projects, self.providers, self.validate_project, self.runtime_bindings, self.verification_actions, self.admission = projects, providers, validate_project, dict(runtime_bindings), {project:dict(action) for project,action in (verification_actions or {}).items()}, admission

    def verification_action(self, project_id: str, intent_id: str, expected_input_tree_sha256: str) -> dict[str, str]:
        """Create evidence work only; this never changes project approval or merge state."""
        action=self.verification_actions.get(project_id)
        if action is None or not isinstance(expected_input_tree_sha256,str) or len(expected_input_tree_sha256)!=64 or any(char not in "0123456789abcdef" for char in expected_input_tree_sha256): raise ExecutionPlanError("verification action is not allowlisted")
        self._snapshot(project_id,intent_id)
        return {"operation_id":"verify-"+intent_id,"project_id":project_id,"workspace_id":action["workspace_id"],"command_id":action["command_id"],"expected_input_tree_sha256":expected_input_tree_sha256,"kind":"project_verification_evidence"}

    def _snapshot(self, project_id: str, intent_id: str) -> tuple[dict[str, Any], str]:
        draft = self.projects.draft(project_id)
        matches = [entry for entry in self.projects.outbox() if entry["intent_id"] == intent_id and entry["project_id"] == project_id]
        if len(matches) != 1: raise ExecutionPlanError("start intent is unknown")
        entry = matches[0]; body = entry.get("body")
        if not isinstance(body, Mapping) or body.get("revision") != draft.get("revision") or draft.get("confirmed_revision") != draft.get("revision") or body.get("payload") != draft.get("payload"):
            raise ExecutionPlanError("start intent is not the current approved revision")
        payload = json.loads(_canonical(body["payload"]))
        if self.admission is None:
            raise ExecutionPlanError("project admission unavailable: composite_readiness")
        report = self.admission(project_id, json.loads(_canonical(payload)))
        if not isinstance(report, Mapping) or report.get("eligible") is not True:
            raise ExecutionPlanError(f"project admission unavailable: {(report.get('unavailable_dependency') if isinstance(report, Mapping) else None) or 'declared dependency'}")
        return {"project_id": project_id, "revision": draft["revision"], "payload": payload}, _canonical(entry)

    def plan(self, project_id: str, intent_id: str) -> dict[str, Any]:
        if not isinstance(project_id, str) or not project_id or not isinstance(intent_id, str) or not intent_id: raise ExecutionPlanError("project and intent identifiers are required")
        first, fingerprint = self._snapshot(project_id, intent_id)
        agents = first["payload"].get("agents")
        orchestrators = [agent for agent in agents if isinstance(agent, Mapping) and agent.get("role") == "project_orchestrator"] if isinstance(agents, list) else []
        if len(orchestrators) != 1 or not isinstance(orchestrators[0].get("capability_bindings"), list): raise ExecutionPlanError("approved project has no unambiguous orchestrator runtime binding")
        candidates: list[tuple[str, str, Mapping[str, Any]]] = []
        for logical_binding in orchestrators[0]["capability_bindings"]:
            if not isinstance(logical_binding, str) or logical_binding not in self.runtime_bindings: continue
            resolved = self.providers.binding(logical_binding)
            provider = resolved.get("provider") if isinstance(resolved, Mapping) else None
            if isinstance(provider, Mapping) and provider.get("role") == "agent-runtime": candidates.append((logical_binding, self.runtime_bindings[logical_binding], provider))
        if len(candidates) != 1: raise ExecutionPlanError("approved project requires exactly one healthy allowlisted agent-runtime binding")
        binding, session_id, provider = candidates[0]
        second, second_fingerprint = self._snapshot(project_id, intent_id)
        if second != first or second_fingerprint != fingerprint: raise ExecutionPlanError("approved project changed while its plan was resolved")
        payload_json = _canonical(first["payload"]); digest = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        message = "Approved project execution intent " + intent_id + "\n" + _canonical({"project_id": project_id, "revision": first["revision"], "payload": first["payload"]})
        if len(message.encode("utf-8")) > 64 * 1024: raise ExecutionPlanError("approved execution message exceeds runtime bounds")
        return {"intent_id": intent_id, "project_id": project_id, "revision": first["revision"], "payload": first["payload"], "payload_sha256": digest, "runtime_binding": binding, "runtime_session_id": session_id, "provider": {"provider_id": provider.get("provider_id"), "generation": provider.get("generation"), "hardware_node_id": provider.get("hardware_node_id"), "capabilities": provider.get("manifest", {}).get("capabilities", []) if isinstance(provider.get("manifest"), Mapping) else [], "required_capability": resolved.get("capability") if isinstance(resolved, Mapping) else None, "health": provider.get("health")}, "message": message}
