"""Authenticated loopback adapter for project and provider control cores.

It records no scheduler claim and never starts work; ``start`` only delegates to
the ProjectControl intent journal.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import hmac
import hashlib
import json
import math
import shutil
import re
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping
from urllib.parse import unquote, urlsplit

from .project_control import ProjectConflictError, ProjectControl, ProjectControlError
from .provider_registry import ProviderRegistry, ProviderRegistryError
from .management_execution_plan import ExecutionPlanError, ManagementExecutionPlanner
from .orchestrator_management import ProjectOrchestratorRegistry, OrchestratorManagementError
from .catalog_admission import CatalogAdmission, CatalogAdmissionError
from .usage_reporting import UsageReportingStore, UsageReportingError
from .management_runtime_control import ManagementRuntimeControl, ManagementRuntimeControlError
from .management_projection import ManagementProjection
from .github_frontier import GitHubFrontierService
from .prd_coverage import PRDCoverageService
from .resource_grants import ResourceGrants
from .resource_grants import ResourceGrantError
from .software_node_lifecycle import SoftwareNodeLifecycleJournal, SoftwareNodeLifecycleError, SoftwareNodeLifecycleConflict
from .inference_lifecycle import InferenceLifecycleCoordinator, InferenceLifecycleError, InferenceRequestConflict
from shared.contracts.project_verification import MAX_VERIFICATION_OUTPUT_BYTES

MAX_BODY_BYTES = 64 * 1024


@dataclass(frozen=True)
class Principal:
    actor_id: str
    role: str
    projects: frozenset[str] = frozenset()
    providers: frozenset[str] = frozenset()
    expires_at: datetime | None = None
    create_projects: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.actor_id, str) or not self.actor_id or self.role not in {"human", "codex", "orchestrator", "provider", "controller"}:
            raise ValueError("principal actor_id and role are invalid")
        if not isinstance(self.projects, frozenset) or not isinstance(self.providers, frozenset) or any(not isinstance(value, str) or not value for value in self.projects | self.providers):
            raise ValueError("principal scopes must be frozensets of non-empty identifiers")
        if self.expires_at is not None and self.expires_at.tzinfo is None:
            raise ValueError("principal expiry must be timezone-aware")
        if type(self.create_projects) is not bool or (self.create_projects and self.role not in {"human", "codex"}):
            raise ValueError("project creation is only available to human or codex principals")


@dataclass(frozen=True)
class ManagementApiConfig:
    tokens: Mapping[str, Principal] = field(repr=False)
    host: str = "127.0.0.1"
    port: int = 0
    max_body_bytes: int = MAX_BODY_BYTES
    request_timeout_seconds: float = 2.0
    project_document_root: Path | None = None
    project_files_root: Path | None = None
    max_prd_bytes: int = 512 * 1024

    def __post_init__(self) -> None:
        if self.host != "127.0.0.1" or not isinstance(self.tokens, Mapping) or not self.tokens or any(not isinstance(token, str) or not token or not token.isascii() or not isinstance(principal, Principal) for token, principal in self.tokens.items()):
            raise ValueError("loopback host and non-empty scoped injected tokens are required")
        if type(self.port) is not int or not 0 <= self.port <= 65535 or type(self.max_body_bytes) is not int or not 1 <= self.max_body_bytes <= MAX_BODY_BYTES or isinstance(self.request_timeout_seconds, bool) or not isinstance(self.request_timeout_seconds, (int, float)) or not math.isfinite(self.request_timeout_seconds) or not 0 < self.request_timeout_seconds <= 30:
            raise ValueError("request bounds are invalid")
        if type(self.max_prd_bytes) is not int or not 1 <= self.max_prd_bytes <= 1024 * 1024:
            raise ValueError("PRD preview bound is invalid")
        if self.project_document_root is not None:
            root = Path(self.project_document_root)
            if not root.is_absolute() or not root.is_dir():
                raise ValueError("project document root must be an existing absolute directory")
            object.__setattr__(self, "project_document_root", root.resolve(strict=True))
        if self.project_files_root is not None:
            root = Path(self.project_files_root)
            if not root.is_absolute() or not root.is_dir() or root.is_symlink() or any(parent.is_symlink() for parent in root.parents):
                raise ValueError("project files root must be an existing absolute non-symlink directory")
            object.__setattr__(self, "project_files_root", root.resolve(strict=True))


class ManagementApiServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address: tuple[str, int], projects: ProjectControl, providers: ProviderRegistry, config: ManagementApiConfig, clock: Callable[[], datetime], planner: ManagementExecutionPlanner | None = None, verification_submitter: Callable[[Mapping[str, str]], Mapping[str, Any]] | None = None, orchestrator_registry: ProjectOrchestratorRegistry | None = None, catalog_admission: CatalogAdmission | None = None, merge_submitter: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None, usage_reporting: UsageReportingStore | None = None, runtime_control: ManagementRuntimeControl | None = None, grants: ResourceGrants | None = None, software_lifecycle: SoftwareNodeLifecycleJournal | None = None, frontier_service: GitHubFrontierService | None = None, coverage_service: PRDCoverageService | None = None, inference_lifecycle: InferenceLifecycleCoordinator | None = None):
        self.projects, self.providers, self.config, self.clock, self.planner, self.verification_submitter, self.orchestrator_registry, self.catalog_admission, self.merge_submitter, self.usage_reporting, self.runtime_control, self.software_lifecycle, self.frontier_service, self.coverage_service, self.inference_lifecycle = projects, providers, config, clock, planner, verification_submitter, orchestrator_registry, catalog_admission, merge_submitter, usage_reporting, runtime_control, software_lifecycle, frontier_service, coverage_service, inference_lifecycle
        self.projection = ManagementProjection(projects, providers, grants, usage_reporting, clock, software_lifecycle, inference_lifecycle)
        super().__init__(address, ManagementApiHandler)


class ManagementApiHandler(BaseHTTPRequestHandler):
    server: ManagementApiServer
    protocol_version = "HTTP/1.1"

    def setup(self) -> None:
        super().setup(); self.connection.settimeout(self.server.config.request_timeout_seconds)

    def do_GET(self) -> None:  # noqa: N802
        principal = self._principal()
        if principal is None: return
        parts = self._parts()
        try:
            if parts in (["readiness"], ["management", "v1", "readiness"]):
                self._topology_role(principal)
                providers = [self.server.providers.readiness(provider["provider_id"], provider.get("manifest", {}).get("capabilities", [])) for provider in self.server.providers.list()]
                eligible = all(item["eligible"] for item in providers) if providers else False
                self._json(HTTPStatus.OK, {"schema": "agent-stack.readiness", "eligible": eligible, "status": "ready" if eligible else "unavailable", "providers": providers, "unavailable_dependencies": [item["unavailable_dependency"] for item in providers if item.get("unavailable_dependency")]}); return
            if len(parts) == 3 and parts[0] == "providers" and parts[2] == "readiness":
                self._topology_role(principal)
                provider = self.server.providers.get(parts[1])
                if provider is None: self._error(HTTPStatus.NOT_FOUND, "provider not found")
                else: self._json(HTTPStatus.OK, self.server.providers.readiness(parts[1], provider.get("manifest", {}).get("capabilities", [])))
                return
            if parts == ["projects"]:
                self._project_role(principal)
                project_ids = principal.projects | self.server.projects.owned_project_ids(principal.actor_id)
                rows = self.server.projects.list_projects(project_ids)
                self._json(HTTPStatus.OK, {"projects": rows}); return
            if parts == ["management", "v1", "workspace"]:
                self._project_role(principal)
                scoped = principal.projects | self.server.projects.owned_project_ids(principal.actor_id)
                self._json(HTTPStatus.OK, self.server.projection.workspace(scoped)); return
            if len(parts) == 5 and parts[:3] == ["management", "v1", "nodes"] and parts[4] == "settings":
                self._project_role(principal); scoped = principal.projects | self.server.projects.owned_project_ids(principal.actor_id)
                self._json(HTTPStatus.OK, self.server.projection.settings(parts[3], scoped)); return
            if len(parts) == 5 and parts[:3] == ["management", "v1", "nodes"] and parts[4] == "information":
                self._project_role(principal); scoped = principal.projects | self.server.projects.owned_project_ids(principal.actor_id)
                node_id = parts[3]
                if node_id.startswith(("project:", "agent:", "runtime:", "orchestrator:")):
                    project_id = node_id.split(":", 2)[1] if node_id.startswith(("agent:", "runtime:")) else node_id.split(":", 1)[1]
                    if project_id not in scoped: raise PermissionError
                query = self._query(); self._json(HTTPStatus.OK, self.server.projection.node_information(node_id, query.get("from"), query.get("to"))); return
            if len(parts) == 6 and parts[:3] == ["management", "v1", "nodes"] and parts[4] == "lifecycle":
                self._lifecycle_scope(principal, parts[3]); journal = self._lifecycle()
                operation = journal.operation(parts[5])
                if operation.node_id != parts[3]: raise KeyError(parts[5])
                self._lifecycle_scope(principal, parts[3], operation)
                self._json(HTTPStatus.OK, {**operation.projection(), "audit": journal.audit(parts[5])}); return
            if parts == ["management", "v1", "events"]:
                self._project_role(principal); scoped = principal.projects | self.server.projects.owned_project_ids(principal.actor_id)
                query = self._query()
                limit = 100
                if "limit" in query:
                    try: limit = int(query["limit"])
                    except ValueError: raise ValueError("event limit must be an integer from 1 through 1000") from None
                self._json(HTTPStatus.OK, self.server.projection.actions(scoped, query.get("cursor"), limit)); return
            if len(parts) == 2 and parts[0] == "projects":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self.server.projects.draft(parts[1])); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "admission":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self.server.projects.admission_status(parts[1])); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "lifecycle":
                self._project_scope(principal, parts[1])
                state = self.server.projects.lifecycle(parts[1])
                local_available = self.server.config.project_files_root is not None
                local_capability = state["capabilities"]["delete"]["local_project_files"]
                local_capability["available"] = local_available and local_capability["available"]
                local_capability["reason"] = None if local_available else "project_files_root_not_configured"
                self._json(HTTPStatus.OK, state); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "prd":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self._prd_document(parts[1])); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "audit":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self.server.projects.audit(parts[1])); return
            if len(parts) == 4 and parts[0] == "projects" and parts[2] == "execution-plans":
                self._execution_scope(principal, parts[1])
                if self.server.planner is None: raise ExecutionPlanError("execution planning is not configured")
                self._json(HTTPStatus.OK, self.server.planner.plan(parts[1], parts[3])); return
            if len(parts) == 4 and parts[0] == "projects" and parts[2] == "orchestrator-loops":
                self._execution_scope(principal, parts[1])
                intent = self._confirmed_start_intent(parts[1], parts[3])
                self._json(HTTPStatus.OK, self._loop_registry().snapshot(intent["body"]["project_id"], intent["body"]["revision"], intent["body"]["payload"])); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "models":
                self._execution_scope(principal, parts[1])
                if self.server.catalog_admission is None: raise CatalogAdmissionError("catalog admission is not configured")
                self._json(HTTPStatus.OK,{"models":self.server.catalog_admission.list_current(parts[1])}); return
            if len(parts) == 4 and parts[0] == "projects" and parts[2] == "model-release-intents":
                self._execution_scope(principal, parts[1])
                if self.server.catalog_admission is None: raise CatalogAdmissionError("catalog admission is not configured")
                self._json(HTTPStatus.OK, self.server.catalog_admission.catalog.release_intent_status(parts[3], parts[1])); return
            if len(parts) == 4 and parts[0] == "projects" and parts[2] == "inference-requests":
                self._execution_scope(principal, parts[1])
                if self.server.inference_lifecycle is None: raise InferenceLifecycleError("inference lifecycle is not configured")
                self._json(HTTPStatus.OK, self.server.inference_lifecycle.status(parts[3], project_id=parts[1])); return
            if len(parts) == 4 and parts[0] == "projects" and parts[2] == "runtime-sessions":
                self._execution_scope(principal,parts[1]);self._json(HTTPStatus.OK,self._runtime().status(parts[1],parts[3]));return
            if len(parts) == 6 and parts[0] == "projects" and parts[2] == "runtime-sessions" and parts[4] == "operations":
                self._execution_scope(principal,parts[1]);self._json(HTTPStatus.OK,self._runtime().get(parts[1],parts[3],parts[5]));return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "reporting-policy":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self._reporting().policy(parts[1])); return
            if len(parts) == 4 and parts[0] == "projects" and parts[2] == "weekly-reports":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self._reporting().weekly_report(parts[1], parts[3])); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "weekly-reports":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, {"reports":self._reporting().weekly_reports(parts[1])}); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "information":
                self._project_scope(principal, parts[1]); query=self._query(); self._json(HTTPStatus.OK, self.server.projection.information(parts[1],query.get("from"),query.get("to"))); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "workspace":
                project_id = parts[1]
                self._project_scope(principal, project_id)
                draft = self.server.projects.draft(project_id)
                intents = [row for row in self.server.projects.outbox() if row["project_id"] == project_id and row["revision"] == draft["revision"]]
                if len(intents) != 1: raise ProjectConflictError("one current exact start intent is required")
                intent = self._confirmed_start_intent(project_id, intents[0]["intent_id"])
                self._json(HTTPStatus.OK, self._workspace_projection(intent)); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "frontier":
                self._project_scope(principal, parts[1])
                if self.server.frontier_service is None: raise ValueError("project frontier is not configured")
                self._json(HTTPStatus.OK, self.server.frontier_service.view(parts[1])); return
            if len(parts) == 3 and parts[0] == "projects" and parts[2] == "coverage":
                self._project_scope(principal, parts[1])
                if self.server.coverage_service is None: raise ValueError("project PRD coverage is not configured")
                self._json(HTTPStatus.OK, self.server.coverage_service.view(parts[1])); return
            if parts == ["hardware", "nodes"]:
                self._topology_role(principal); self._json(HTTPStatus.OK, {"nodes": [self._hardware_projection(node) for node in self.server.providers.hardware.list_snapshots()]}); return
            if len(parts) == 3 and parts[:2] == ["hardware", "nodes"]:
                self._topology_role(principal); node = self.server.providers.hardware.get_snapshot(parts[2])
                if node is None: self._error(HTTPStatus.NOT_FOUND, "hardware node not found")
                else: self._json(HTTPStatus.OK, self._hardware_projection(node))
                return
            if len(parts) == 2 and parts[0] == "providers":
                self._topology_role(principal); provider = self.server.providers.get(parts[1])
                if provider is None: self._error(HTTPStatus.NOT_FOUND, "provider not found")
                else: self._json(HTTPStatus.OK, self._provider_projection(provider, self.server.providers.readiness(parts[1], provider.get("manifest", {}).get("capabilities", []))))
                return
            self._error(HTTPStatus.NOT_FOUND, "route not found")
        except ExecutionPlanError as error: self._error(HTTPStatus.CONFLICT, str(error))
        except (KeyError, ProjectControlError, OrchestratorManagementError, CatalogAdmissionError, UsageReportingError, SoftwareNodeLifecycleError, ValueError) as error: self._error(HTTPStatus.NOT_FOUND if isinstance(error, KeyError) else HTTPStatus.CONFLICT if isinstance(error, (ProjectConflictError, SoftwareNodeLifecycleConflict)) else HTTPStatus.BAD_REQUEST, str(error))
        except PermissionError: self._error(HTTPStatus.FORBIDDEN, "principal scope is not permitted")

    def do_POST(self) -> None:  # noqa: N802
        self._mutate("POST")

    def do_PUT(self) -> None:  # noqa: N802
        self._mutate("PUT")

    def do_DELETE(self) -> None:  # noqa: N802
        if urlsplit(self.path).path == "/management/session":
            principal = self._principal()
            if principal is not None:
                self._record_auth_event(principal, "logout")
                self._empty(HTTPStatus.NO_CONTENT)
            return
        self._mutate("DELETE")

    def _mutate(self, method: str) -> None:
        principal = self._principal()
        if principal is None: return
        body = self._body()
        if body is None: return
        parts = self._parts()
        try:
            # Safe software-node withdrawal is a receipt-backed control-plane
            # operation.  Management records intent/progress only; the owning
            # role supplies evidence and performs the actual drain/checkpoint.
            if method == "POST" and len(parts) == 5 and parts[:3] == ["management", "v1", "nodes"] and parts[4] == "withdraw":
                self._human_lifecycle_scope(principal, parts[3])
                self._lifecycle_scope(principal, parts[3])
                if self.server.software_lifecycle is None: raise SoftwareNodeLifecycleError("software node lifecycle is not configured")
                if set(body) != {"operation_id", "kind", "confirmation_receipt"} and set(body) != {"operation_id", "kind", "confirmation_receipt", "expected_generation"}:
                    raise ValueError("exact withdrawal fields are required")
                kind = self._text(body, "kind")
                result = self.server.software_lifecycle.withdraw(self._text(body, "operation_id"), parts[3], kind, confirmation_receipt=self._text(body, "confirmation_receipt"), expected_generation=body.get("expected_generation", 0), provider_id=self._provider_id_for_node(parts[3]), actor_id=principal.actor_id, actor_role=principal.role)
                self._json(HTTPStatus.ACCEPTED, {**result.projection(), "audit": self.server.software_lifecycle.audit(result.operation_id)}); return
            if method == "POST" and len(parts) == 7 and parts[:3] == ["management", "v1", "nodes"] and parts[4] == "lifecycle":
                self._lifecycle_scope(principal, parts[3]); journal = self._lifecycle(); operation_id = parts[5]; action = parts[6]
                operation = journal.operation(operation_id)
                if operation.node_id != parts[3]: raise KeyError(operation_id)
                self._lifecycle_scope(principal, parts[3], operation)
                if action == "evidence":
                    if set(body) not in ({"phase", "kind", "value"}, {"phase", "kind", "value", "observed_at"}): raise ValueError("exact lifecycle evidence fields are required")
                    result = journal.record_evidence(operation_id, phase=self._text(body, "phase"), kind=self._text(body, "kind"), value=body.get("value"), observed_at=body.get("observed_at"), actor_id=principal.actor_id, actor_role=principal.role)
                elif action == "progress":
                    if set(body) != {"expected_generation", "progress"}: raise ValueError("exact lifecycle progress fields are required")
                    result = journal.advance(operation_id, expected_generation=self._generation(body, "expected_generation"), progress=body["progress"], actor_id=principal.actor_id, actor_role=principal.role)
                elif action in {"cancel", "retry"}:
                    if set(body) != {"expected_generation"}: raise ValueError("exact lifecycle generation fields are required")
                    result = journal.cancel(operation_id, expected_generation=self._generation(body, "expected_generation"), actor_id=principal.actor_id, actor_role=principal.role) if action == "cancel" else journal.retry(operation_id, expected_generation=self._generation(body, "expected_generation"), actor_id=principal.actor_id, actor_role=principal.role)
                elif action in {"restore", "reconnect"}:
                    if set(body) not in ({"restore_operation_id", "expected_generation"}, {"restore_operation_id", "expected_generation", "provider_id"}): raise ValueError("exact lifecycle restore fields are required")
                    result = journal.restore(operation_id, self._text(body, "restore_operation_id"), expected_generation=self._generation(body, "expected_generation"), provider_id=body.get("provider_id"), actor_id=principal.actor_id, actor_role=principal.role)
                else: raise ValueError("unsupported lifecycle operation")
                self._json(HTTPStatus.OK, {**result.projection(), "audit": journal.audit(result.operation_id)}); return
            if method == "POST" and parts == ["projects"]:
                project_id = self._text(body, "project_id")
                expected_revision = self._optional_revision(body, "expected_revision")
                self._project_role(principal)
                owner_actor_id = None
                if self.server.projects.is_owner(project_id, principal.actor_id) and expected_revision is None:
                    owner_actor_id = principal.actor_id
                elif not self._has_project_scope(principal, project_id):
                    self._creation_scope(principal, project_id, expected_revision)
                    owner_actor_id = principal.actor_id
                self._json(HTTPStatus.OK, self.server.projects.propose(project_id, self._mapping(body, "payload"), actor_role=principal.role, actor_id=principal.actor_id, idempotency_key=self._text(body, "idempotency_key"), expected_revision=expected_revision, owner_actor_id=owner_actor_id)); return
            if method == "PUT" and len(parts) == 2 and parts[0] == "projects":
                self._project_scope(principal, parts[1])
                self._json(HTTPStatus.OK, self.server.projects.propose(parts[1], self._mapping(body, "payload"), actor_role=principal.role, actor_id=principal.actor_id, idempotency_key=self._text(body, "idempotency_key"), expected_revision=self._revision(body, "expected_revision"))); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "confirm":
                self._human_project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self.server.projects.confirm(parts[1], self._revision(body, "revision"), actor_role=principal.role, actor_id=principal.actor_id)); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "start":
                self._human_project_scope(principal, parts[1]); self._json(HTTPStatus.ACCEPTED, self.server.projects.start(parts[1], expected_revision=self._revision(body, "expected_revision"), actor_role=principal.role, actor_id=principal.actor_id, idempotency_key=self._text(body, "idempotency_key"))); return
            if method == "POST" and len(parts) == 4 and parts[0] == "projects" and parts[2:] == ["frontier", "refresh"]:
                self._project_scope(principal, parts[1])
                if body != {}: raise ValueError("frontier refresh does not accept caller-supplied bindings")
                if self.server.frontier_service is None: raise ValueError("project frontier refresh is not configured")
                self._json(HTTPStatus.OK, self.server.frontier_service.refresh(parts[1])); return
            if method == "POST" and len(parts) == 4 and parts[0] == "projects" and parts[2:] == ["coverage", "discover"]:
                self._project_scope(principal, parts[1])
                if self.server.coverage_service is None: raise ValueError("project PRD coverage is not configured")
                allowed = {"expected_revision", "discovery_id", "kind", "requirement", "evidence", "parent_issue_number", "blocked_by"}
                required = {"expected_revision", "discovery_id", "kind", "requirement", "evidence"}
                if set(body) - allowed or not required.issubset(body): raise ValueError("exact PRD coverage discovery fields are required")
                self._json(HTTPStatus.OK, self.server.coverage_service.discover(parts[1], self._revision(body, "expected_revision"), self._text(body, "discovery_id"), self._text(body, "kind"), self._mapping(body, "requirement"), self._mapping(body, "evidence"), body.get("parent_issue_number"), body.get("blocked_by"))); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] in {"pause", "end"}:
                self._human_project_scope(principal, parts[1])
                if set(body) != {"expected_revision", "idempotency_key", "reason"}:
                    raise ValueError("project lifecycle requires exactly expected_revision, idempotency_key, and reason")
                operation = self.server.projects.pause if parts[2] == "pause" else self.server.projects.end
                self._json(HTTPStatus.ACCEPTED, operation(parts[1], expected_revision=self._revision(body, "expected_revision"), actor_role=principal.role, actor_id=principal.actor_id, idempotency_key=self._text(body, "idempotency_key"), reason=self._text(body, "reason"))); return
            if method == "DELETE" and len(parts) == 2 and parts[0] == "projects":
                project_id = parts[1]
                required = {"scope", "project_id", "revision", "confirmation", "idempotency_key"}
                if set(body) - required or not required.issubset(body):
                    raise ValueError("project deletion requires exactly scope, project_id, revision, confirmation, and idempotency_key")
                if principal.role != "human" or (not self._has_project_scope(principal, project_id) and not self.server.projects.can_replay_deletion(project_id, body.get("idempotency_key"), principal.actor_id)):
                    raise PermissionError
                if body["project_id"] != project_id:
                    raise ValueError("project_id confirmation does not match route")
                revision = self._revision(body, "revision")
                scope = self._text(body, "scope")
                if scope == "management_record":
                    self._json(HTTPStatus.OK, self.server.projects.delete_management_record(project_id, expected_revision=revision, actor_role=principal.role, actor_id=principal.actor_id, idempotency_key=self._text(body, "idempotency_key"), confirmation=body["confirmation"])); return
                if scope != "local_project_files":
                    raise ValueError("unsupported project deletion scope")
                if self.server.config.project_files_root is None:
                    raise ProjectControlError("local project files deletion is unavailable: no project_files_root is configured")
                confirmation = body["confirmation"]
                if not isinstance(confirmation, Mapping) or set(confirmation) != {"scope", "project_id", "revision", "relative_path"}:
                    raise ValueError("local file deletion confirmation fields are incomplete")
                relative_path = confirmation.get("relative_path")
                if relative_path != project_id:
                    raise ValueError("local file deletion relative_path must exactly match project_id")
                if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", project_id):
                    raise ValueError("project id cannot identify a local project directory")
                cached = self.server.projects.check_local_files_deletion(project_id, expected_revision=revision, actor_role=principal.role, actor_id=principal.actor_id, idempotency_key=self._text(body, "idempotency_key"), confirmation=confirmation, relative_path=relative_path)
                if cached is not None:
                    self._json(HTTPStatus.OK, cached); return
                # Validate the exact revision before any destructive filesystem
                # operation; the journal records the completed local action
                # only after this bounded deletion succeeds.
                draft = self.server.projects.draft(project_id)
                if draft["revision"] != revision:
                    raise ProjectConflictError("local file deletion requires the current exact project revision")
                root = self.server.config.project_files_root
                target = root / project_id
                if target.is_symlink() or any(parent.is_symlink() for parent in target.parents if parent != root):
                    raise ProjectControlError("local project path must not traverse symlinks")
                resolved = target.resolve(strict=False)
                if not resolved.is_relative_to(root):
                    raise ProjectControlError("local project path escapes configured project_files_root")
                if target.exists():
                    if not target.is_dir():
                        raise ProjectControlError("local project path is not a directory")
                    try:
                        shutil.rmtree(target)
                    except OSError as error:
                        raise ProjectControlError("local project files could not be deleted safely") from error
                self._json(HTTPStatus.OK, self.server.projects.record_local_files_deletion(project_id, expected_revision=revision, actor_role=principal.role, actor_id=principal.actor_id, idempotency_key=self._text(body, "idempotency_key"), confirmation=confirmation, relative_path=relative_path)); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "verification-actions":
                self._execution_scope(principal, parts[1])
                if self.server.planner is None or self.server.verification_submitter is None or set(body) != {"intent_id","expected_input_tree_sha256"}: raise ExecutionPlanError("verification dispatch is not configured")
                action=self.server.planner.verification_action(parts[1],self._text(body,"intent_id"),self._text(body,"expected_input_tree_sha256"))
                evidence=self.server.verification_submitter(action)
                self._json(HTTPStatus.ACCEPTED,{"kind":"project_verification_evidence","action":action,"evidence":self._verification_evidence(action,evidence),"approval_changed":False,"merge_changed":False}); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "merge-actions":
                self._execution_scope(principal, parts[1])
                required={"operation_id","repo_alias","pull_number","head_sha","verification_operation_id"}
                if self.server.merge_submitter is None or set(body) != required: raise ExecutionPlanError("merge dispatch is not configured")
                # Management only forwards this typed request. It cannot issue a
                # review receipt; Storage independently binds the receipt and PR.
                outcome=self.server.merge_submitter(body)
                if not isinstance(outcome,Mapping) or outcome.get("operation_id") != body["operation_id"] or outcome.get("state") not in {"merged","rejected","unknown","prepared"}: raise ExecutionPlanError("merge authority returned invalid outcome")
                self._json(HTTPStatus.OK,{"kind":"receipt_gated_merge","request":body,"outcome":dict(outcome),"approval_changed":False,"merge_changed":outcome.get("state")=="merged"}); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "binding-change-proposals":
                # Nondurable evidence only: never render this response as applied binding state.
                self._project_scope(principal, parts[1])
                if set(body) != {"idempotency_key", "expected_revision", "target_binding"}: raise ValueError("exact binding proposal fields are required")
                revision = self._revision(body, "expected_revision"); target = self._text(body, "target_binding")
                draft = self.server.projects.draft(parts[1])
                if draft["revision"] != revision or self.server.providers.binding(target) is None: raise ProjectConflictError("binding proposal names an unavailable exact target")
                # A proposal is evidence for the existing human-confirmed project workflow,
                # deliberately not a model/provider mutation or an implicit approval.
                self._json(HTTPStatus.ACCEPTED, {"kind":"binding_change_proposal","project_id":parts[1],"revision":revision,"target_binding":target,"idempotency_key":self._text(body,"idempotency_key"),"requires_human_confirmation":True,"approval_changed":False,"merge_changed":False}); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "model-admissions":
                self._execution_scope(principal,parts[1])
                if self.server.catalog_admission is None or set(body)!={"idempotency_key","model_id","revision"}: raise CatalogAdmissionError("catalog admission is not configured")
                self._json(HTTPStatus.ACCEPTED,self.server.catalog_admission.admit(parts[1],self._text(body,"idempotency_key"),self._text(body,"model_id"),self._text(body,"revision")));return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "usage-records":
                self._project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self._reporting().record_usage(parts[1], body)); return
            if method == "PUT" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "reporting-policy":
                self._human_project_scope(principal, parts[1]); self._json(HTTPStatus.OK, self._reporting().set_policy(parts[1], body)); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "model-releases":
                self._execution_scope(principal,parts[1])
                if self.server.catalog_admission is None or set(body)!={"model_id","revision","provider_receipt"}: raise CatalogAdmissionError("model release is not configured")
                self._json(HTTPStatus.OK,self.server.catalog_admission.release(parts[1],self._text(body,"model_id"),self._text(body,"revision"),self._mapping(body,"provider_receipt")));return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "model-release-intents":
                self._orchestrator_scope(principal, parts[1])
                if self.server.catalog_admission is None or set(body)!={"model_id","revision","orchestrator_id","operation_id"}: raise CatalogAdmissionError("model release intent is not configured")
                orchestrator_id = self._text(body, "orchestrator_id")
                if orchestrator_id != principal.actor_id: raise PermissionError
                self._json(HTTPStatus.ACCEPTED,self.server.catalog_admission.catalog.observe_idle(self._text(body,"model_id"),self._text(body,"revision"),parts[1],orchestrator_id,self._text(body,"operation_id")));return
            if method == "POST" and len(parts) == 5 and parts[0] == "projects" and parts[2] == "model-release-intents" and parts[4] == "acknowledge":
                self._execution_scope(principal, parts[1])
                if self.server.catalog_admission is None: raise CatalogAdmissionError("model release intent is not configured")
                self._json(HTTPStatus.OK,self.server.catalog_admission.catalog.acknowledge_release(parts[3],parts[1],principal.actor_id,body));return
            if method == "POST" and parts == ["models","physical-unloads"]:
                if principal.role not in {"controller","provider"}: raise PermissionError
                if self.server.catalog_admission is None or set(body)!={"model_id","revision","provider_receipt"}: raise CatalogAdmissionError("physical unload is not configured")
                receipt = self._mapping(body, "provider_receipt")
                self._provider_receipt_scope(principal, receipt)
                self._json(HTTPStatus.OK,self.server.catalog_admission.physical_unload(self._text(body,"model_id"),self._text(body,"revision"),receipt));return
            if method == "POST" and parts == ["models","physical-unloads","claim"]:
                if principal.role not in {"controller", "human", "codex"}: raise PermissionError
                if self.server.catalog_admission is None or set(body)!={"model_id","revision","operation_id","provider_id","generation"}: raise CatalogAdmissionError("physical unload claim is not configured")
                provider_id=self._text(body,"provider_id"); generation=body.get("generation")
                if type(generation) is not int: raise ValueError("physical unload generation is invalid")
                self._json(HTTPStatus.OK,self.server.catalog_admission.claim_physical_unload(self._text(body,"model_id"),self._text(body,"revision"),self._text(body,"operation_id"),provider_id,generation));return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "orchestrator-loops":
                self._execution_scope(principal, parts[1])
                if set(body) != {"intent_id", "idempotency_key"}: raise ValueError("exact loop start fields are required")
                intent = self._confirmed_start_intent(parts[1], self._text(body, "intent_id"))
                self._require_current_admission(parts[1])
                self._json(HTTPStatus.ACCEPTED, self._loop_registry().start_from_confirmed_intent(intent, self._text(body, "idempotency_key"))); return
            if method == "POST" and len(parts) == 5 and parts[0] == "projects" and parts[2] == "orchestrator-loops" and parts[4] == "resource-resolutions":
                self._project_scope(principal, parts[1])
                if principal.role not in {"human", "codex"}: raise PermissionError
                if set(body) != {"idempotency_key", "expected_version", "approve", "rationale", "receipt", "allocation_receipt", "displaced_project_ids"}: raise ValueError("exact resource resolution fields are required")
                if type(body["approve"]) is not bool or not isinstance(body["displaced_project_ids"], list) or any(not isinstance(value, str) for value in body["displaced_project_ids"]): raise ValueError("resource resolution is invalid")
                intent = self._confirmed_start_intent(parts[1], parts[3]); data = intent["body"]
                allocation = self._text(body, "allocation_receipt") if body["approve"] else None
                result = self._loop_registry().invoke(data["project_id"], data["revision"], data["payload"], "resolve_expansion", self._text(body, "idempotency_key"), self._revision(body, "expected_version"), body["approve"], principal.role, principal.actor_id, self._text(body, "rationale"), self._text(body, "receipt"), allocation_receipt=allocation, displaced_project_ids=body["displaced_project_ids"])
                self._json(HTTPStatus.OK, result); return
            if method == "POST" and len(parts) == 5 and parts[0] == "projects" and parts[2] == "orchestrator-loops":
                self._execution_scope(principal, parts[1])
                intent = self._confirmed_start_intent(parts[1], parts[3]); loop = self._loop_registry()
                project_id, revision, payload = intent["body"]["project_id"], intent["body"]["revision"], intent["body"]["payload"]
                operation = parts[4]
                if operation == "decisions" and set(body) == {"idempotency_key", "expected_version", "decision"}:
                    result = loop.invoke(project_id, revision, payload, "decision", self._text(body, "idempotency_key"), self._revision(body, "expected_version"), self._mapping(body, "decision"))
                elif operation == "progress" and set(body) == {"idempotency_key", "agent_id", "assignment_id", "progress"}:
                    result = loop.invoke(project_id, revision, payload, "report_progress", self._text(body, "idempotency_key"), self._text(body, "agent_id"), self._text(body, "assignment_id"), self._mapping(body, "progress"))
                elif operation == "pause" and set(body) == {"idempotency_key", "reason", "deadline"}:
                    result = loop.invoke(project_id, revision, payload, "request_pause", self._text(body, "idempotency_key"), principal.actor_id, self._text(body, "reason"), self._text(body, "deadline"))
                elif operation == "drain" and set(body) == {"idempotency_key", "checkpoint_receipt"}:
                    result = loop.invoke(project_id, revision, payload, "drain_pause", self._text(body, "idempotency_key"), self._mapping(body, "checkpoint_receipt"))
                elif operation == "resume" and set(body) == {"idempotency_key", "expected_version"}:
                    result = loop.invoke(project_id, revision, payload, "resume", self._text(body, "idempotency_key"), self._revision(body, "expected_version"))
                else: raise ValueError("exact typed loop operation fields are required")
                self._json(HTTPStatus.OK, result); return
            if method == "POST" and len(parts) == 5 and parts[0] == "projects" and parts[2] == "runtime-sessions" and parts[4] == "operations":
                self._execution_scope(principal,parts[1])
                if set(body)-{"kind","operation_id","target_binding","expected_revision"} or not {"kind","operation_id"}.issubset(body): raise ValueError("exact runtime operation fields are required")
                self._json(HTTPStatus.ACCEPTED,self._runtime().command(parts[1],parts[3],self._text(body,"kind"),self._text(body,"operation_id"),target_binding=body.get("target_binding"),expected_revision=body.get("expected_revision")));return
            if method == "POST" and len(parts) == 7 and parts[0] == "projects" and parts[2] == "runtime-sessions" and parts[4] == "operations" and parts[6] == "reconcile":
                self._execution_scope(principal,parts[1])
                if body:raise ValueError("runtime reconciliation takes no body")
                self._json(HTTPStatus.OK,self._runtime().reconcile(parts[1],parts[3],parts[5]));return
            if method == "POST" and parts == ["providers", "register"]:
                manifest = self._mapping(body, "manifest"); provider_id = self._text(manifest, "provider_id"); self._provider_scope(principal, provider_id)
                self._json(HTTPStatus.OK, self.server.providers.register(provider_id, manifest, expected_generation=self._optional_revision(body, "expected_generation"))); return
            if method == "POST" and len(parts) == 3 and parts[0] == "projects" and parts[2] == "inference-requests":
                self._execution_scope(principal, parts[1])
                if self.server.inference_lifecycle is None: raise InferenceLifecycleError("inference lifecycle is not configured")
                if set(body) != {"request_id", "model_id", "revision"}: raise ValueError("exact inference request fields are required")
                self._json(HTTPStatus.ACCEPTED, self.server.inference_lifecycle.submit(parts[1], self._text(body,"request_id"), self._text(body,"model_id"), self._text(body,"revision"))); return
            if method == "POST" and len(parts) == 5 and parts[0] == "projects" and parts[2] == "inference-requests" and parts[4] == "poll":
                self._execution_scope(principal, parts[1])
                if self.server.inference_lifecycle is None: raise InferenceLifecycleError("inference lifecycle is not configured")
                if body: raise ValueError("inference poll takes no body")
                self._json(HTTPStatus.OK, self.server.inference_lifecycle.poll(parts[3], project_id=parts[1])); return
            if method == "POST" and len(parts) == 5 and parts[0] == "projects" and parts[2] == "inference-requests" and parts[4] == "reconcile":
                self._execution_scope(principal, parts[1])
                if self.server.inference_lifecycle is None: raise InferenceLifecycleError("inference lifecycle is not configured")
                if body and not isinstance(body, dict): raise ValueError("inference reconciliation body is invalid")
                self._json(HTTPStatus.OK, self.server.inference_lifecycle.reconcile(parts[3], body or None, project_id=parts[1])); return
            if method == "POST" and len(parts) == 3 and parts[0] == "providers" and parts[2] == "health":
                self._provider_scope(principal, parts[1])
                readiness = body.get("readiness")
                if readiness is None and any(key in body for key in ("authenticated", "service_reachable")):
                    readiness = {key: body[key] for key in ("authenticated", "service_reachable") if key in body}
                self._json(HTTPStatus.OK, self.server.providers.observe_health(parts[1], self._text(body, "status"), self._text(body, "observed_at"), expected_generation=self._revision(body, "expected_generation"), host_boot_id=self._text(body, "host_boot_id"), lease_seconds=self._optional_revision(body, "lease_seconds"), readiness=readiness)); return
            if method == "POST" and len(parts) == 3 and parts[0] == "providers" and parts[2] == "capacity":
                self._provider_scope(principal, parts[1])
                if self.server.projection.grants is None:
                    raise ResourceGrantError("capacity reporting is not configured")
                if set(body) != {"pool_id", "quantities", "observed_at"}:
                    raise ValueError("capacity requires exactly pool_id, quantities, and observed_at")
                provider = self.server.providers.get(parts[1])
                if provider is None:
                    raise ProviderRegistryError("unknown provider")
                pool_id = self._text(body, "pool_id")
                existing = self.server.projection.grants.pool_projection(pool_id)
                if existing is not None and existing["provider_id"] != parts[1]:
                    # A provider principal cannot overwrite a pool owned by
                    # another provider.  A new pool is allowed and becomes
                    # owned by this provider atomically in report_capacity.
                    raise ResourceGrantError("capacity pool is owned by another provider")
                self.server.projection.grants.report_capacity(pool_id, parts[1], provider["hardware_node_id"], body["quantities"], self._text(body, "observed_at"))
                self._json(HTTPStatus.OK, {"provider_id": parts[1], "pool_id": pool_id, "accepted": True, "observed_at": body["observed_at"]}); return
            if method == "POST" and parts == ["providers", "bindings"]:
                if principal.role != "controller": raise PermissionError
                self._json(HTTPStatus.OK, self.server.providers.bind(self._text(body, "logical_binding"), self._text(body, "capability"), self._text(body, "compatibility_fingerprint"), expected_binding_generation=self._optional_revision(body, "expected_binding_generation"))); return
            self._error(HTTPStatus.NOT_FOUND, "route not found")
        except PermissionError: self._error(HTTPStatus.FORBIDDEN, "principal scope is not permitted")
        except ExecutionPlanError as error: self._error(HTTPStatus.CONFLICT, str(error))
        except (ProjectControlError, ProviderRegistryError, ResourceGrantError, OrchestratorManagementError, CatalogAdmissionError, UsageReportingError, SoftwareNodeLifecycleError, ValueError) as error: self._error(HTTPStatus.CONFLICT if isinstance(error, (ProjectConflictError, SoftwareNodeLifecycleConflict)) else HTTPStatus.BAD_REQUEST, str(error))

    def _principal(self) -> Principal | None:
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer ") or not header[7:].isascii():
            self._record_auth_event(None, "unauthorized")
            self._error(HTTPStatus.FORBIDDEN, "principal is not permitted"); return None
        supplied = header[7:]; match = None
        for token, principal in self.server.config.tokens.items():
            if hmac.compare_digest(supplied, token): match = principal
        if match is None:
            self._record_auth_event(None, "unauthorized")
            self._error(HTTPStatus.FORBIDDEN, "principal is not permitted"); return None
        if match.expires_at is not None and match.expires_at <= self.server.clock().astimezone(timezone.utc):
            self._record_auth_event(match, "expired")
            self._error(HTTPStatus.FORBIDDEN, "principal is not permitted"); return None
        return match

    def _record_auth_event(self, principal: Principal | None, outcome: str) -> None:
        actor_id = principal.actor_id if principal is not None else None
        actor_role = principal.role if principal is not None else None
        action = f"auth:{self.command}:{urlsplit(self.path).path}"
        action_id = "auth:" + hashlib.sha256(json.dumps({"action": action, "outcome": outcome, "actor_id": actor_id, "actor_role": actor_role}, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        occurred_at = self.server.clock().astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        self.server.projects.record_auth_event({"action_id": action_id, "action": action, "outcome": outcome, "actor_id": actor_id, "actor_role": actor_role, "subject": "management", "occurred_at": occurred_at})

    def _project_role(self, principal: Principal) -> None:
        if principal.role not in {"human", "codex", "orchestrator"}: raise PermissionError

    def _project_scope(self, principal: Principal, project_id: str) -> None:
        self._project_role(principal)
        if not self._has_project_scope(principal, project_id): raise PermissionError

    def _has_project_scope(self, principal: Principal, project_id: str) -> bool:
        return project_id in principal.projects or self.server.projects.is_owner(project_id, principal.actor_id)

    def _creation_scope(self, principal: Principal, project_id: str, expected_revision: int | None) -> None:
        self._project_role(principal)
        if not principal.create_projects or expected_revision is not None or self.server.projects.has_project(project_id): raise PermissionError

    def _human_project_scope(self, principal: Principal, project_id: str) -> None:
        if principal.role != "human" or not self._has_project_scope(principal, project_id): raise PermissionError

    def _execution_scope(self, principal: Principal, project_id: str) -> None:
        if principal.role not in {"controller", "orchestrator"} or project_id not in principal.projects: raise PermissionError

    def _orchestrator_scope(self, principal: Principal, project_id: str) -> None:
        if principal.role != "orchestrator" or project_id not in principal.projects: raise PermissionError

    def _loop_registry(self) -> ProjectOrchestratorRegistry:
        if self.server.orchestrator_registry is None: raise OrchestratorManagementError("orchestrator loops are not configured")
        return self.server.orchestrator_registry

    def _runtime(self) -> ManagementRuntimeControl:
        if self.server.runtime_control is None: raise ManagementRuntimeControlError("runtime control is not configured")
        return self.server.runtime_control

    def _lifecycle(self) -> SoftwareNodeLifecycleJournal:
        if self.server.software_lifecycle is None: raise SoftwareNodeLifecycleError("software node lifecycle is not configured")
        return self.server.software_lifecycle

    @staticmethod
    def _provider_id_for_node(node_id: str) -> str | None:
        prefix, separator, value = node_id.partition(":")
        return value if separator and prefix in {"provider", "inference", "storage"} else node_id if prefix not in {"project", "agent", "runtime", "orchestrator", "hardware", "binding"} else None

    def _lifecycle_scope(self, principal: Principal, node_id: str, operation: Any | None = None) -> None:
        # Only authenticated Management operators/role owners may inspect or
        # report lifecycle evidence.  Hardware nodes are intentionally excluded.
        if principal.role not in {"human", "codex", "controller", "provider", "orchestrator"} or not isinstance(node_id, str) or not node_id:
            raise PermissionError
        project_id = self._project_id_for_node(node_id)
        if project_id is not None and not self._has_project_scope(principal, project_id):
            raise PermissionError
        provider_id = operation.provider_id if operation is not None and operation.provider_id else self._provider_id_for_node(node_id)
        # Provider/inference/storage nodes without a project prefix are global
        # role instances.  A project-scoped Codex/orchestrator/controller token
        # must not gain access merely from its role; only a human operator or
        # the exact authenticated provider authority may inspect or mutate it.
        if provider_id is not None and project_id is None:
            if principal.role == "human":
                pass
            elif principal.role == "provider" and provider_id in principal.providers:
                pass
            else:
                raise PermissionError
        if principal.role == "provider" and provider_id not in principal.providers:
            raise PermissionError
        if principal.providers and provider_id is not None and principal.role in {"controller", "orchestrator"} and provider_id not in principal.providers:
            raise PermissionError
        if operation is not None and operation.node_id != node_id:
            raise PermissionError

    @staticmethod
    def _project_id_for_node(node_id: str) -> str | None:
        if node_id.startswith("project:"):
            value = node_id.split(":", 2)
            return value[1] if len(value) > 1 and value[1] else None
        if node_id.startswith(("agent:", "runtime:", "orchestrator:")):
            value = node_id.split(":", 2)
            return value[1] if len(value) > 1 and value[1] else None
        return None

    @staticmethod
    def _human_lifecycle_scope(principal: Principal, node_id: str) -> None:
        # Initiation is limited to the explicitly withdrawable software role
        # families.  A project, agent/runtime, hardware, or binding node is a
        # projection/owner boundary, never a withdrawal target.
        if principal.role != "human" or not isinstance(node_id, str) or not node_id or node_id.split(":", 1)[0] in {"project", "hardware", "binding", "agent", "runtime", "orchestrator"}:
            raise PermissionError

    def _reporting(self) -> UsageReportingStore:
        if self.server.usage_reporting is None: raise UsageReportingError("usage reporting is not configured")
        return self.server.usage_reporting

    def _confirmed_start_intent(self, project_id: str, intent_id: str) -> dict[str, Any]:
        if not isinstance(intent_id, str) or not intent_id: raise ValueError("intent_id is required")
        rows = [row for row in self.server.projects.outbox() if row["intent_id"] == intent_id and row["project_id"] == project_id]
        if len(rows) != 1: raise ProjectConflictError("exact project start intent is required")
        row = rows[0]; body = row["body"]; draft = self.server.projects.draft(project_id)
        if (not isinstance(body, Mapping) or body.get("project_id") != project_id or body.get("revision") != draft["revision"] or draft.get("confirmed_revision") != draft["revision"] or body.get("payload") != draft["payload"]):
            raise ProjectConflictError("start intent is no longer the confirmed exact draft")
        return {"intent_id": intent_id, "body": body}

    def _require_current_admission(self, project_id: str) -> None:
        report = self.server.projects.admission_status(project_id)
        if not isinstance(report, Mapping) or report.get("eligible") is not True:
            dependency = report.get("unavailable_dependency") if isinstance(report, Mapping) else None
            reason = report.get("reason") if isinstance(report, Mapping) else None
            detail = f"{dependency}: {reason}" if dependency and reason else dependency or reason or "composite_readiness"
            raise ProjectControlError(f"project admission unavailable: {detail}")

    def _workspace_projection(self, intent: Mapping[str, Any]) -> dict[str, Any]:
        """UI wire contract: bounded nodes/links only, independently decodable and secret-free."""
        body = intent["body"]; payload = body["payload"]
        def text(value: Any, fallback: str) -> str:
            value = value if isinstance(value, str) else fallback
            return "".join(character if character.isprintable() else " " for character in value).strip()[:256] or fallback
        def node_id(prefix: str, value: Any) -> str:
            import hashlib, re
            candidate = prefix + "-" + text(value, "unknown")
            return candidate if re.fullmatch(r"[-A-Za-z0-9._]{1,128}", candidate) else prefix + "-" + hashlib.sha256(candidate.encode()).hexdigest()[:24]
        project_node = node_id("project", body["project_id"])
        nodes: list[dict[str, Any]] = [{"id": project_node, "kind": "project", "label": text(body["project_id"], "Project"), "status": "idle"}]; links: list[dict[str, str]] = []
        known: set[str] = {project_node}; provider_hardware: list[tuple[str, str]] = []
        def add_node(value: dict[str, Any]) -> None:
            if len(nodes) >= 200 or value["id"] in known: return
            known.add(value["id"]); nodes.append(value)
        def add_link(source: str, target: str, label: str) -> None:
            if len(links) < 400 and source in known and target in known and source != target: links.append({"source":source,"target":target,"label":text(label,"related")})
        for agent in payload["agents"]:
            aid = agent["id"]; agent_node = node_id("agent", aid)
            add_node({"id":agent_node,"kind":"agent_runtime","label":text(aid,"Agent"),"status":"unknown"})
            add_link(project_node, agent_node, "contains")
            for binding in agent["capability_bindings"]:
                binding_node = node_id("binding", binding)
                add_node({"id":binding_node,"kind":"binding","label":text(binding,"Binding"),"status":"unknown"})
                add_link(agent_node, binding_node, "uses")
        storage_binding = payload.get("storage_binding")
        if not isinstance(storage_binding, str):
            declared = payload.get("binding_references", [])
            storage_binding = next((value for value in declared if isinstance(value, str) and value.startswith("storage.")), None) if isinstance(declared, list) else None
        storage_policy = payload.get("storage_policy")
        storage_declared = isinstance(storage_policy, (Mapping, str)) and (not isinstance(storage_policy, str) or bool(storage_policy.strip()))
        if isinstance(storage_binding, str) and storage_binding:
            storage_declared = True
            storage_node = node_id("storage", body["project_id"])
            storage_binding_node = node_id("binding", storage_binding)
            add_node({"id": storage_node, "kind": "storage", "label": "Project storage", "status": "unknown"})
            add_node({"id": storage_binding_node, "kind": "binding", "label": text(storage_binding, "Storage binding"), "status": "unknown"})
            add_link(project_node, storage_node, "uses")
            add_link(storage_node, storage_binding_node, "configured by")
        elif storage_declared:
            storage_node = node_id("storage", body["project_id"])
            add_node({"id": storage_node, "kind": "storage", "label": "Project storage", "status": "unknown"})
            add_link(project_node, storage_node, "uses")
        binding_rows = {row["logical_binding"]: row for row in self.server.providers.list_bindings()}
        for node in list(nodes):
            if node["kind"] != "binding": continue
            binding = binding_rows.get(node["label"])
            if binding is None: continue
            readiness = self.server.projection._binding_readiness(binding)
            checks = readiness.get("checks", {})
            freshness_check = checks.get("freshness", {}) if isinstance(checks, Mapping) else {}
            reasons = [reason for reason in readiness.get("reasons", []) if isinstance(reason, str)]
            node.update({
                "status": "ready" if readiness.get("eligible") is True else "unavailable",
                "provider_id": binding["provider_id"],
                "provider_generation": binding["provider_generation"],
                "freshness": "fresh" if freshness_check.get("ok") is True else "stale",
                "reason": "; ".join(reasons),
                "reasons": reasons,
            })
            provider = self.server.providers.get(binding["provider_id"])
            provider_id = binding["provider_id"]
            node["unavailable_dependency"] = readiness.get("unavailable_dependency")
            node["provider_current_generation"] = provider.get("generation") if isinstance(provider, Mapping) else None
            provider_node = node_id("provider", provider_id)
            if provider_node not in known:
                health = provider.get("health") if isinstance(provider, Mapping) else None
                health = health if isinstance(health, Mapping) else {}
                status = "healthy" if health.get("status") == "healthy" else "unknown"
                provider_value = {"id":provider_node,"kind":"provider","label":text(provider_id,"Provider"),"health":status,"freshness":"fresh" if status == "healthy" else "unknown","status":"idle"}
                if isinstance(provider, Mapping):
                    provider_value["generation"] = provider.get("generation")
                    if isinstance(provider.get("hardware_node_id"), str): provider_hardware.append((provider_node, provider["hardware_node_id"]))
                add_node(provider_value)
            add_link(node["id"], provider_node, "resolved by")
        for hardware in self.server.providers.hardware.list_snapshots():
            if isinstance(hardware.get("node_id"), str):
                registration = hardware.get("registration") if isinstance(hardware.get("registration"), Mapping) else {}
                resources = registration.get("resource_limits") if isinstance(registration.get("resource_limits"), Mapping) else {}
                safe_resources = {key:value for key,value in resources.items() if key in {"cpu_cores","memory_mib","gpu_count","gpu_memory_mib","disk_gib","network_mbps"} and type(value) in {int,float} and value >= 0 and math.isfinite(value)}
                add_node({"id":node_id("hardware",hardware["node_id"]),"kind":"hardware","label":text(hardware["node_id"],"Hardware"),"health":"unknown","freshness":"unknown","resources":safe_resources,"status":"unknown"})
        for provider_node, hardware_id in provider_hardware:
            add_link(provider_node, node_id("hardware", hardware_id), "hosted by")
        loop = self._loop_registry().snapshot(body["project_id"], body["revision"], payload)
        loop_status = {"turn_ready":"idle","waiting":"running","pause_requested":"draining","draining":"draining","paused":"paused","completed":"completed","blocked":"blocked"}.get(loop.get("state"),"unknown")
        orchestrator_node = node_id("orchestrator", body["project_id"])
        add_node({"id":orchestrator_node,"kind":"orchestrator","label":"Project orchestrator","status":loop_status})
        add_link(project_node, orchestrator_node, "governs")
        result = {"nodes": nodes, "links": links}
        routes = self.server.projection.project_route_observations(body["project_id"])
        if routes:
            result["routes"] = routes
        return result

    @staticmethod
    def _topology_role(principal: Principal) -> None:
        if principal.role not in {"human", "controller"}: raise PermissionError

    def _prd_document(self, project_id: str) -> dict[str, str]:
        """Read only the scoped project's declared bounded Markdown document."""
        root = self.server.config.project_document_root
        if root is None:
            raise KeyError("PRD preview is not configured")
        reference = self.server.projects.draft(project_id).get("payload", {}).get("prd_reference")
        if not isinstance(reference, str) or "\\" in reference:
            raise ValueError("PRD reference is invalid")
        relative = PurePosixPath(reference)
        if relative.is_absolute() or not relative.parts or any(part in {"", ".", ".."} for part in relative.parts) or relative.suffix.lower() not in {".md", ".markdown"}:
            raise ValueError("PRD reference must be a relative Markdown path")
        candidate = root.joinpath(*relative.parts)
        try:
            if candidate.is_symlink() or any(parent.is_symlink() for parent in candidate.parents if parent != root and parent.is_relative_to(root)):
                raise ValueError("PRD reference must not traverse symlinks")
            resolved = candidate.resolve(strict=True)
            if not resolved.is_relative_to(root) or not resolved.is_file():
                raise ValueError("PRD reference escapes the configured root")
            size = resolved.stat().st_size
            if size > self.server.config.max_prd_bytes:
                raise ValueError("PRD document exceeds the preview bound")
            content = resolved.read_text(encoding="utf-8")
        except FileNotFoundError as error:
            raise KeyError("PRD document not found") from error
        except (OSError, UnicodeDecodeError) as error:
            raise ValueError("PRD document is not readable UTF-8 Markdown") from error
        return {"path": reference, "content": content}

    def _provider_scope(self, principal: Principal, provider_id: str) -> None:
        if principal.role != "provider" or provider_id not in principal.providers: raise PermissionError

    def _provider_receipt_scope(self, principal: Principal, receipt: Mapping[str, Any]) -> None:
        if principal.role == "provider":
            self._provider_scope(principal, receipt.get("provider_id"))

    @staticmethod
    def _verification_evidence(action: Mapping[str, str], evidence: Mapping[str, Any]) -> dict[str, Any]:
        """Diagnostics are bounded evidence only; they never carry connection data."""
        required={"operation_id","project_id","workspace_id","command_id","expected_input_tree_sha256","state","result"}
        if not isinstance(evidence,Mapping) or set(evidence)!=required or any(evidence.get(key)!=action.get(key) for key in ("operation_id","project_id","workspace_id","command_id","expected_input_tree_sha256")) or evidence.get("state") not in {"accepted","running","completed","failed","unknown"}:
            raise ExecutionPlanError("verification evidence is invalid")
        result=evidence["result"]
        terminal=evidence["state"] in {"completed","failed"}
        if (terminal and not isinstance(result,Mapping)) or (not terminal and result is not None): raise ExecutionPlanError("verification evidence is invalid")
        if result is not None:
            required={"exit_code","result","input_tree_sha256","output_sha256"}; allowed=required|{"output","error"}
            digest=lambda value:isinstance(value,str) and __import__("re").fullmatch(r"[0-9a-f]{64}",value)
            if not isinstance(result,Mapping) or not required.issubset(result) or set(result)-allowed or type(result["exit_code"]) is not int or not 0<=result["exit_code"]<=255 or result["result"] not in {"passed","failed"} or not digest(result["input_tree_sha256"]) or result["input_tree_sha256"]!=action["expected_input_tree_sha256"] or not digest(result["output_sha256"]): raise ExecutionPlanError("verification evidence is invalid")
            if "output" in result and (not isinstance(result["output"],str) or len(result["output"].encode("utf-8"))>MAX_VERIFICATION_OUTPUT_BYTES): raise ExecutionPlanError("verification diagnostics exceed bounds")
            if "error" in result and (not isinstance(result["error"],str) or len(result["error"])>128 or __import__("re").fullmatch(r"[a-z0-9_]+",result["error"]) is None): raise ExecutionPlanError("verification evidence is invalid")
            if evidence["state"]=="completed" and (result["result"]!="passed" or result["exit_code"]!=0 or "error" in result): raise ExecutionPlanError("verification evidence is invalid")
            if evidence["state"]=="failed" and (result["result"]!="failed" or (result["exit_code"]==0 and "error" not in result)): raise ExecutionPlanError("verification evidence is invalid")
            result=dict(result)
        return {"operation_id":evidence["operation_id"],"project_id":evidence["project_id"],"workspace_id":evidence["workspace_id"],"command_id":evidence["command_id"],"expected_input_tree_sha256":evidence["expected_input_tree_sha256"],"state":evidence["state"],"result":result}

    def _parts(self) -> list[str]: return [unquote(part) for part in urlsplit(self.path).path.split("/") if part]
    def _query(self) -> dict[str, str]:
        from urllib.parse import parse_qsl
        result = dict(parse_qsl(urlsplit(self.path).query, keep_blank_values=True))
        if len(result) != len(list(parse_qsl(urlsplit(self.path).query, keep_blank_values=True))) or any(not key or not value or len(key)>64 or len(value)>1024 for key,value in result.items()): raise ValueError("query is invalid")
        return result
    @staticmethod
    def _hardware_projection(node: Mapping[str, Any]) -> dict[str, Any]:
        registration = node.get("registration", {})
        return {"node_id": node.get("node_id"), "generation": node.get("generation"), "registration": {"node_identity": registration.get("node_identity"), "capabilities": registration.get("capabilities"), "resource_limits": registration.get("resource_limits")}, "telemetry": node.get("telemetry")}
    @staticmethod
    def _provider_projection(provider: Mapping[str, Any], readiness: Mapping[str, Any] | None = None) -> dict[str, Any]:
        manifest = provider.get("manifest", {})
        health = provider.get("health")
        if isinstance(health, Mapping):
            safe_health = dict(health)
            evidence = safe_health.get("readiness")
            if isinstance(evidence, Mapping):
                safe_health["readiness"] = {key: evidence[key] for key in ("authenticated", "service_reachable", "checked_at") if key in evidence}
            health = safe_health
        return {"provider_id": provider.get("provider_id"), "hardware_node_id": provider.get("hardware_node_id"), "role": provider.get("role"), "generation": provider.get("generation"), "revoked": provider.get("revoked"), "capabilities": manifest.get("capabilities"), "compatibility_fingerprint": manifest.get("compatibility_fingerprint"), "health": health, "readiness": dict(readiness or {})}
    def _body(self) -> dict[str, Any] | None:
        if self.headers.get("Content-Type", "").split(";", 1)[0].lower() != "application/json": self._error(HTTPStatus.BAD_REQUEST, "Content-Type application/json required"); return None
        try: length = int(self.headers.get("Content-Length", "-1"))
        except ValueError: length = -1
        if not 0 <= length <= self.server.config.max_body_bytes: self._error(HTTPStatus.BAD_REQUEST, "bounded Content-Length required"); return None
        try: value = json.loads(self.rfile.read(length).decode("utf-8"), parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        except (OSError, UnicodeDecodeError, ValueError, json.JSONDecodeError): self._error(HTTPStatus.BAD_REQUEST, "valid UTF-8 JSON object required"); return None
        if not isinstance(value, dict): self._error(HTTPStatus.BAD_REQUEST, "JSON payload must be an object"); return None
        return value
    @staticmethod
    def _text(data: Mapping[str, Any], name: str) -> str:
        value = data.get(name)
        if not isinstance(value, str) or not value: raise ValueError(f"{name} is required")
        return value
    @staticmethod
    def _mapping(data: Mapping[str, Any], name: str) -> Mapping[str, Any]:
        value = data.get(name)
        if not isinstance(value, Mapping): raise ValueError(f"{name} must be an object")
        return value
    @staticmethod
    def _optional_revision(data: Mapping[str, Any], name: str) -> int | None:
        value = data.get(name)
        if value is None: return None
        if type(value) is not int or value < 1: raise ValueError(f"{name} must be a positive integer or null")
        return value
    @classmethod
    def _revision(cls, data: Mapping[str, Any], name: str) -> int:
        value = cls._optional_revision(data, name)
        if value is None: raise ValueError(f"{name} is required")
        return value
    @staticmethod
    def _generation(data: Mapping[str, Any], name: str) -> int:
        value = data.get(name)
        if type(value) is not int or value < 0: raise ValueError(f"{name} must be a non-negative integer")
        return value
    def _json(self, status: HTTPStatus, data: Any) -> None:
        body = json.dumps(data, separators=(",", ":"), allow_nan=False).encode("utf-8"); self.send_response(status); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store"); self.send_header("Connection", "close"); self.end_headers(); self.wfile.write(body)
    def _empty(self, status: HTTPStatus) -> None:
        self.send_response(status); self.send_header("Content-Length", "0"); self.send_header("Cache-Control", "no-store"); self.send_header("Connection", "close"); self.end_headers()
    def _error(self, status: HTTPStatus, message: str) -> None: self._json(status, {"error": message})
    def log_message(self, _format: str, *_args: object) -> None: pass


def serve(projects: ProjectControl, providers: ProviderRegistry, config: ManagementApiConfig, *, clock: Callable[[], datetime] | None = None, planner: ManagementExecutionPlanner | None = None, verification_submitter: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None, orchestrator_registry: ProjectOrchestratorRegistry | None = None, catalog_admission: CatalogAdmission | None = None, merge_submitter: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None, usage_reporting: UsageReportingStore | None = None, runtime_control: ManagementRuntimeControl | None = None, grants: ResourceGrants | None = None, software_lifecycle: SoftwareNodeLifecycleJournal | None = None, lifecycle_journal: SoftwareNodeLifecycleJournal | None = None, frontier_service: GitHubFrontierService | None = None, coverage_service: PRDCoverageService | None = None, inference_lifecycle: InferenceLifecycleCoordinator | None = None) -> ManagementApiServer:
    return ManagementApiServer((config.host, config.port), projects, providers, config, clock or (lambda: datetime.now(timezone.utc)), planner, verification_submitter, orchestrator_registry, catalog_admission, merge_submitter, usage_reporting, runtime_control, grants, software_lifecycle or lifecycle_journal, frontier_service, coverage_service, inference_lifecycle)
