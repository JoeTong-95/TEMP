"""Local authenticated HTTP adapter for :mod:`management.hardware_registry`.

This module is intentionally not a deployment.  A caller supplies tokens and a
registry at process construction; token values must come from a secret manager or
environment injection, never this repository.  It binds only ``127.0.0.1`` by
default, emits no CORS headers, and has no public-host default.

Example launcher (for a local integration harness only)::

    registry = HardwareRegistry("state/hardware.sqlite3")
    config = HardwareApiConfig(operator_tokens=(operator_token,),
                               node_tokens={node_token: "node-a"})
    server = serve(registry, config)
    server.serve_forever()
"""

from __future__ import annotations

import hmac
import json
import socket
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Mapping
from urllib.parse import unquote, urlsplit

from .hardware_registry import HardwareRegistry, HardwareRegistryError


MAX_BODY_BYTES = 64 * 1024


@dataclass(frozen=True)
class HardwareApiConfig:
    """Injected credentials and local listener settings; values are not persisted."""

    operator_tokens: tuple[str, ...]
    node_tokens: Mapping[str, str]
    host: str = "127.0.0.1"
    port: int = 0
    max_body_bytes: int = MAX_BODY_BYTES

    def __post_init__(self) -> None:
        if self.host != "127.0.0.1":
            raise ValueError("hardware API only permits loopback binds")
        if not self.operator_tokens or not self.node_tokens:
            raise ValueError("at least one injected operator token and node token are required")
        if any(not token for token in self.operator_tokens) or any(not token or not node_id for token, node_id in self.node_tokens.items()):
            raise ValueError("tokens and scoped node IDs must be non-empty")
        if set(self.operator_tokens).intersection(self.node_tokens):
            raise ValueError("a bearer token cannot hold both operator and node roles")
        if not 1 <= self.max_body_bytes <= MAX_BODY_BYTES:
            raise ValueError("max_body_bytes must be between 1 and 65536")


class HardwareApiServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], registry: HardwareRegistry, config: HardwareApiConfig):
        self.registry = registry
        self.config = config
        super().__init__(address, HardwareApiHandler)


class HardwareApiHandler(BaseHTTPRequestHandler):
    server: HardwareApiServer
    protocol_version = "HTTP/1.1"

    def setup(self) -> None:
        super().setup()
        self.connection.settimeout(2.0)

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        if not self._require_operator():
            return
        path = urlsplit(self.path).path
        if path == "/hardware/nodes":
            self._send_json(HTTPStatus.OK, {"nodes": self.server.registry.list_snapshots()})
            return
        prefix = "/hardware/nodes/"
        if path.startswith(prefix) and path[len(prefix):] and "/" not in path[len(prefix):]:
            snapshot = self.server.registry.get_snapshot(unquote(path[len(prefix):]))
            if snapshot is None:
                self._error(HTTPStatus.NOT_FOUND, "hardware node not found")
            else:
                self._send_json(HTTPStatus.OK, snapshot)
            return
        self._error(HTTPStatus.NOT_FOUND, "route not found")

    def do_POST(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        path = urlsplit(self.path).path
        if path not in {"/hardware/nodes/register", "/hardware/telemetry"}:
            self._error(HTTPStatus.NOT_FOUND, "route not found")
            return
        node_id = self._require_node()
        if node_id is None:
            return
        payload = self._read_json()
        if payload is None:
            return
        expected_id = "node_id" if path.endswith("register") else "hardware_node_id"
        if payload.get(expected_id) != node_id:
            self._error(HTTPStatus.FORBIDDEN, "node token scope does not match payload")
            return
        try:
            if path.endswith("register"):
                result = self.server.registry.register(node_id, payload)
                self._send_json(HTTPStatus.OK, result)
            else:
                result = self.server.registry.ingest_telemetry(node_id, payload)
                self._send_json(HTTPStatus.ACCEPTED, result)
        except HardwareRegistryError as error:
            # The core treats stale/idempotency/order failures as conflicts; shape
            # violations are bad requests. Its messages are stable operator-safe text.
            status = HTTPStatus.CONFLICT if any(word in str(error) for word in ("stale", "duplicate", "older boot", "must be registered", "cannot move backwards")) else HTTPStatus.BAD_REQUEST
            self._error(status, str(error))

    def _require_operator(self) -> bool:
        kind, _ = self._credential()
        if kind is None:
            self._error(HTTPStatus.UNAUTHORIZED, "valid bearer token required")
            return False
        if kind != "operator":
            self._error(HTTPStatus.FORBIDDEN, "operator token required")
            return False
        return True

    def _require_node(self) -> str | None:
        kind, node_id = self._credential()
        if kind is None:
            self._error(HTTPStatus.UNAUTHORIZED, "valid bearer token required")
            return None
        if kind != "node":
            self._error(HTTPStatus.FORBIDDEN, "node token required")
            return None
        return node_id

    def _credential(self) -> tuple[str | None, str | None]:
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return None, None
        supplied = header[7:]
        if not supplied or not supplied.isascii():
            return None, None
        # Compare every configured token so this adapter does not use ordinary
        # equality for bearer secrets. Scope choice remains deterministic.
        operator_match = any(hmac.compare_digest(supplied, token) for token in self.server.config.operator_tokens)
        matched_node = None
        for token, node_id in self.server.config.node_tokens.items():
            if hmac.compare_digest(supplied, token):
                matched_node = node_id
        if operator_match:
            return "operator", None
        return ("node", matched_node) if matched_node is not None else (None, None)

    def _read_json(self) -> dict | None:
        content_type = self.headers.get("Content-Type", "")
        if content_type.split(";", 1)[0].strip().lower() != "application/json":
            self._error(HTTPStatus.BAD_REQUEST, "Content-Type application/json required")
            return None
        length_header = self.headers.get("Content-Length")
        try:
            length = int(length_header) if length_header is not None else -1
        except ValueError:
            length = -1
        if length < 0 or length > self.server.config.max_body_bytes:
            self._error(HTTPStatus.BAD_REQUEST, "bounded Content-Length required")
            return None
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"), parse_constant=self._reject_nonfinite)
        except (OSError, UnicodeDecodeError, ValueError, json.JSONDecodeError):
            self._error(HTTPStatus.BAD_REQUEST, "valid UTF-8 JSON object required")
            return None
        if not isinstance(payload, dict):
            self._error(HTTPStatus.BAD_REQUEST, "JSON payload must be an object")
            return None
        return payload

    @staticmethod
    def _reject_nonfinite(_constant: str) -> None:
        raise ValueError("non-finite JSON values are not accepted")

    def _send_json(self, status: HTTPStatus, payload: dict) -> None:
        body = json.dumps(payload, separators=(",", ":"), allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: HTTPStatus, message: str) -> None:
        self._send_json(status, {"error": message})

    def log_message(self, _format: str, *_args: object) -> None:
        """Avoid logging bearer-adjacent request details from this local adapter."""


def serve(registry: HardwareRegistry, config: HardwareApiConfig) -> HardwareApiServer:
    """Construct (but do not start) a loopback-only local HTTP server."""
    return HardwareApiServer((config.host, config.port), registry, config)
