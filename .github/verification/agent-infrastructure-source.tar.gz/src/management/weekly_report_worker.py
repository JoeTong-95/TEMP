"""One-shot, caller-scheduled weekly report queueing; never a timer or sender."""
from __future__ import annotations
import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol
from .feishu_transport import OperationalNotice
from .usage_reporting import UsageReportingStore

class NoticeQueue(Protocol):
    def queue(self, route: str, notice: OperationalNotice) -> dict[str, Any]: ...

@dataclass(frozen=True)
class WeeklyReportJob:
    project_id: str
    week_start: str
    route: str
    def __post_init__(self) -> None:
        if not all(isinstance(value,str) and value for value in (self.project_id,self.week_start,self.route)): raise ValueError("weekly report job is invalid")

class WeeklyReportWorker:
    def __init__(self, store: UsageReportingStore, notifier: NoticeQueue): self.store,self.notifier=store,notifier
    def run_once(self, job: WeeklyReportJob) -> dict[str, Any]:
        report=self.store.weekly_report(job.project_id,job.week_start)
        decisions=self.store.record_decisions(job.project_id,report["week_start"],report["automated_decisions"])
        summary=json.dumps({"kind":"weekly_report","week_start":report["week_start"],"total_tokens":report["tokens"]["total"],"decision_ids":[item["decision_id"] for item in decisions],"decision_kinds":[item["kind"] for item in decisions]},sort_keys=True,separators=(",",":"))
        queued=self.notifier.queue(job.route,OperationalNotice("stack_to_codex",job.project_id,summary,"weekly-report:"+report["week_start"]))
        return {"report":report,"decisions":decisions,"queued":queued}

def load_job_config(path: str | Path) -> WeeklyReportJob:
    source=Path(path)
    if not source.is_absolute() or not source.is_file() or source.is_symlink() or any(parent.is_symlink() for parent in source.parents):raise ValueError("reporting configuration is unsafe")
    try:raw=json.loads(source.read_text(encoding="utf-8"))
    except (OSError,UnicodeDecodeError,json.JSONDecodeError) as error:raise ValueError("reporting configuration is invalid") from error
    if not isinstance(raw,dict) or set(raw)!={"project_id","week_start","route"}:raise ValueError("reporting configuration schema is invalid")
    return WeeklyReportJob(raw["project_id"],raw["week_start"],raw["route"])

def main(argv: list[str] | None = None) -> int:
    parser=argparse.ArgumentParser(description="Validate one weekly report job; a host injects the notifier.")
    parser.add_argument("--config",required=True);args=parser.parse_args(argv)
    job=load_job_config(args.config)
    # Deliberately no credential, network, timer, or implicit sender in this CLI.
    print(json.dumps({"project_id":job.project_id,"week_start":job.week_start,"route":job.route,"state":"notifier_required"},sort_keys=True));return 0

if __name__ == "__main__": raise SystemExit(main())
