"""Versioned, safe v1 pilot DAG definitions.

Definitions contain logical references only.  Canvas layout and physical endpoint
placement are deliberately stored separately and never participate in identity.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib, json, re
from typing import Any, Mapping

_ID = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_NODE_TYPES = {"input", "agent", "tool", "condition", "approval", "artifact"}
_PORTS = {"request", "agent_result", "tool_result", "condition_result", "approved_result", "artifact"}
_ALLOWED = {
    "input": {"node_id", "kind", "output_type", "config"},
    "agent": {"node_id", "kind", "input_type", "output_type", "config"},
    "tool": {"node_id", "kind", "input_type", "output_type", "config"},
    "condition": {"node_id", "kind", "input_type", "output_type", "config"},
    "approval": {"node_id", "kind", "input_type", "output_type", "config"},
    "artifact": {"node_id", "kind", "input_type", "config"},
}

class PilotSpecError(ValueError): pass

def _dump(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)

def _id(value: object, field: str) -> str:
    if not isinstance(value, str) or not _ID.fullmatch(value): raise PilotSpecError(field + " must be a safe identifier")
    return value

def _json(value: object, depth: int = 0) -> None:
    if depth > 12: raise PilotSpecError("configuration nesting exceeds 12")
    if value is None or isinstance(value, (str, int, float, bool)): return
    if isinstance(value, list):
        for x in value: _json(x, depth + 1)
        return
    if isinstance(value, Mapping):
        for k, x in value.items():
            if not isinstance(k, str): raise PilotSpecError("configuration keys must be strings")
            _json(x, depth + 1)
        return
    raise PilotSpecError("configuration must be JSON-safe")

def _no_url(value: object) -> None:
    if isinstance(value, str) and ("://" in value or value.startswith("//")): raise PilotSpecError("URLs are not permitted in pilot definitions")
    if isinstance(value, list):
        for x in value: _no_url(x)
    if isinstance(value, Mapping):
        for x in value.values(): _no_url(x)

@dataclass(frozen=True)
class PilotDefinition:
    semantic: dict[str, Any]
    layout: dict[str, Any]
    version_hash: str

    @classmethod
    def parse(cls, document: Mapping[str, Any]) -> "PilotDefinition":
        if not isinstance(document, Mapping) or set(document) != {"schema", "nodes", "edges", "layout"}:
            raise PilotSpecError("definition requires exactly schema, nodes, edges, layout")
        if document["schema"] != "agent-stack.pilot.v1": raise PilotSpecError("unknown pilot schema")
        nodes, edges, layout = document["nodes"], document["edges"], document["layout"]
        if not isinstance(nodes, list) or not isinstance(edges, list) or not isinstance(layout, Mapping): raise PilotSpecError("nodes/edges/layout have invalid types")
        if not 2 <= len(nodes) <= 16 or len(edges) >= 16: raise PilotSpecError("pilot graph must have 2-16 nodes and fewer than 16 edges")
        normalized: list[dict[str, Any]] = []
        seen: set[str] = set()
        for raw in nodes:
            if not isinstance(raw, Mapping) or not isinstance(raw.get("kind"), str) or raw["kind"] not in _NODE_TYPES: raise PilotSpecError("unknown node kind")
            kind = raw["kind"]
            if set(raw) != _ALLOWED[kind]: raise PilotSpecError("unknown or missing fields for " + kind)
            node = dict(raw); node["node_id"] = _id(node["node_id"], "node_id")
            if node["node_id"] in seen: raise PilotSpecError("duplicate node_id")
            seen.add(node["node_id"])
            for port in ("input_type", "output_type"):
                if port in node and node[port] not in _PORTS: raise PilotSpecError("unknown port type")
            if not isinstance(node["config"], Mapping): raise PilotSpecError("node config must be object")
            _json(node["config"]); _no_url(node["config"])
            normalized.append(json.loads(_dump(node)))
        by_id = {n["node_id"]: n for n in normalized}
        parsed_edges: list[dict[str, str]] = []
        for raw in edges:
            if not isinstance(raw, Mapping) or set(raw) != {"source", "target", "value_type"}: raise PilotSpecError("edge fields are invalid")
            edge = {k: _id(raw[k], "edge " + k) if k != "value_type" else raw[k] for k in raw}
            if not isinstance(edge["value_type"], str) or edge["value_type"] not in _PORTS: raise PilotSpecError("unknown edge type")
            if edge["source"] not in by_id or edge["target"] not in by_id: raise PilotSpecError("dangling edge")
            if by_id[edge["source"]].get("output_type") != edge["value_type"] or by_id[edge["target"]].get("input_type") != edge["value_type"]: raise PilotSpecError("edge port type mismatch")
            parsed_edges.append(edge)
        if len({(e["source"],e["target"],e["value_type"]) for e in parsed_edges}) != len(parsed_edges): raise PilotSpecError("duplicate edge")
        cls._acyclic(by_id, parsed_edges)
        cls._shape(normalized, parsed_edges)
        _json(layout); _no_url(layout)
        semantic = {"schema": document["schema"], "nodes": sorted(normalized,key=lambda n:n["node_id"]), "edges": sorted(parsed_edges,key=lambda e:(e["source"],e["target"],e["value_type"]))}
        return cls(semantic, json.loads(_dump(dict(layout))), hashlib.sha256(_dump(semantic).encode()).hexdigest())

    @staticmethod
    def _acyclic(nodes: Mapping[str, Any], edges: list[dict[str,str]]) -> None:
        outgoing = {key: [] for key in nodes}; incoming = {key: 0 for key in nodes}
        for e in edges: outgoing[e["source"]].append(e["target"]); incoming[e["target"]] += 1
        ready = sorted(k for k,v in incoming.items() if not v); walked = 0
        while ready:
            node = ready.pop(); walked += 1
            for target in outgoing[node]:
                incoming[target] -= 1
                if not incoming[target]: ready.append(target)
        if walked != len(nodes): raise PilotSpecError("cycles are forbidden")

    @staticmethod
    def _shape(nodes: list[dict[str,Any]], edges: list[dict[str,str]]) -> None:
        kinds = [n["kind"] for n in nodes]
        if any(kinds.count(kind) != 1 for kind in _NODE_TYPES): raise PilotSpecError("v1 requires exactly one of each executable node kind")
        tool = [n for n in nodes if n["kind"] == "tool"]
        if tool and any(n["config"] != {"operation":"fixture_sum"} for n in tool): raise PilotSpecError("only protected fixture_sum tool is allowed")
        condition = [n for n in nodes if n["kind"] == "condition"]
        if condition and any(n["config"] != {"predicate":"sum_positive"} for n in condition): raise PilotSpecError("only sum_positive condition is allowed")
        approval = [n for n in nodes if n["kind"] == "approval"]
        if approval and any(set(n["config"]) != {"scope"} or not isinstance(n["config"]["scope"],str) for n in approval): raise PilotSpecError("approval needs only a logical scope")
        agent = [n for n in nodes if n["kind"] == "agent"]
        if agent and any(set(n["config"]) != {"model_ref","memory_ref"} for n in agent): raise PilotSpecError("agent needs logical model_ref and memory_ref")
        by_kind = {node["kind"]:node["node_id"] for node in nodes}
        required = [("input","agent","request"),("agent","tool","agent_result"),("tool","condition","tool_result"),("condition","approval","condition_result"),("approval","artifact","approved_result")]
        actual = {(edge["source"],edge["target"],edge["value_type"]) for edge in edges}
        expected = {(by_kind[a],by_kind[b],value_type) for a,b,value_type in required}
        if actual != expected: raise PilotSpecError("v1 requires the input-agent-tool-condition-approval-artifact path")

def default_definition() -> dict[str, Any]:
    return {"schema":"agent-stack.pilot.v1","nodes":[
      {"node_id":"input","kind":"input","output_type":"request","config":{}},
      {"node_id":"agent","kind":"agent","input_type":"request","output_type":"agent_result","config":{"model_ref":"qwen4bit-local","memory_ref":"platform-canary"}},
      {"node_id":"tool","kind":"tool","input_type":"agent_result","output_type":"tool_result","config":{"operation":"fixture_sum"}},
      {"node_id":"condition","kind":"condition","input_type":"tool_result","output_type":"condition_result","config":{"predicate":"sum_positive"}},
      {"node_id":"approval","kind":"approval","input_type":"condition_result","output_type":"approved_result","config":{"scope":"pilot.synthetic.execute"}},
      {"node_id":"artifact","kind":"artifact","input_type":"approved_result","config":{}},
    ],"edges":[
      {"source":"input","target":"agent","value_type":"request"},{"source":"agent","target":"tool","value_type":"agent_result"},{"source":"tool","target":"condition","value_type":"tool_result"},{"source":"condition","target":"approval","value_type":"condition_result"},{"source":"approval","target":"artifact","value_type":"approved_result"}],"layout":{"nodes":{"input":{"x":0,"y":0},"agent":{"x":150,"y":0},"tool":{"x":300,"y":0},"condition":{"x":450,"y":0},"approval":{"x":600,"y":0},"artifact":{"x":750,"y":0}},"physical":{"agent":"runtime-local","tool":"fixture-local"}}}
