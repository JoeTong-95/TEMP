"""Loopback same-origin host for the reviewed UI and its two bounded APIs."""
from __future__ import annotations

import argparse
import http.client
import json
import mimetypes
import os
import socket
import secrets
import time
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Mapping
from urllib.parse import urlsplit

MAX_BODY_BYTES = 64 * 1024
MAX_RESPONSE_BYTES = 1024 * 1024
_HOP_BY_HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade"}
# Keep the same-origin gateway allowlist bounded to complete API roots.  The
# composed Management API owns /management/v1/* (workspace, events, settings,
# information, and lifecycle); without this root the SPA receives index.html.
_MANAGEMENT_PREFIXES = ("/projects", "/hardware", "/management")
_TRUSTED_BOOTSTRAP_PATH = "/management/bootstrap"
_SESSION_PATH = "/management/session"
_MAX_COOKIE_HEADER_BYTES = 16 * 1024
_COOKIE_OCTET_RANGES = ((0x21, 0x21), (0x23, 0x2B), (0x2D, 0x3A), (0x3C, 0x5B), (0x5D, 0x7E))

class StaticUiHostError(ValueError): pass
class CookieHeaderError(ValueError): pass
class RequestBodyTooLarge(ValueError): pass
class RequestBodyReadError(ValueError): pass


def _cookie_pairs(cookie: str) -> list[tuple[str, str, str]]:
    """Parse a Cookie header once, rejecting ambiguous input."""
    if not isinstance(cookie, str) or len(cookie.encode("utf-8", "replace")) > _MAX_COOKIE_HEADER_BYTES:
        raise CookieHeaderError("cookie header is invalid or too large")

    pairs: list[tuple[str, str, str]] = []
    start = 0
    quoted = False
    escaped = False
    for position, character in enumerate(cookie):
        if ord(character) < 0x20 or ord(character) == 0x7F:
            raise CookieHeaderError("cookie header contains control characters")
        if escaped:
            escaped = False
        elif quoted and character == "\\":
            escaped = True
        elif character == '"':
            quoted = not quoted
        elif character == ";" and not quoted:
            parts = cookie[start:position]
            start = position + 1
            pair = parts.lstrip(" \t")
            if pair.strip():
                pairs.append(_cookie_pair(pair))
    if quoted or escaped:
        raise CookieHeaderError("cookie header has an unterminated quote")
    pair = cookie[start:].lstrip(" \t")
    if pair.strip():
        pairs.append(_cookie_pair(pair))
    return pairs


def _cookie_pair(pair: str) -> tuple[str, str, str]:
    name, separator, value = pair.partition("=")
    if not separator or not _is_cookie_name(name):
        raise CookieHeaderError("cookie pair is invalid")
    if value.startswith('"'):
        if len(value) < 2 or not value.endswith('"'):
            raise CookieHeaderError("cookie value is invalid")
        # Keep the original spelling for safe forwarding, but validate and
        # decode once here so authentication cannot ask SimpleCookie to parse
        # a value that this boundary accepted.
        decoded: list[str] = []
        index = 1
        closing = len(value) - 1
        while index < closing:
            character = value[index]
            if character == "\\":
                index += 1
                if index >= closing:
                    raise CookieHeaderError("cookie value is invalid")
                escaped = value[index]
                if not _is_cookie_visible(escaped) and escaped not in {'"', '\\'}:
                    raise CookieHeaderError("cookie value is invalid")
                decoded.append(escaped)
            elif character == '"' or not _is_cookie_visible(character):
                raise CookieHeaderError("cookie value is invalid")
            else:
                decoded.append(character)
            index += 1
        return pair, name, ''.join(decoded)
    elif '"' in value:
        raise CookieHeaderError("cookie value is invalid")
    if any(not _is_cookie_octet(character) for character in value):
        raise CookieHeaderError("cookie value is invalid")
    return pair, name, value


def _is_cookie_name(name: str) -> bool:
    return bool(name) and name.isascii() and all(
        character.isalnum() or character in "!#$%&'*+-.^_`|~" for character in name
    )


def _is_cookie_octet(character: str) -> bool:
    codepoint = ord(character)
    return any(lower <= codepoint <= upper for lower, upper in _COOKIE_OCTET_RANGES)


def _is_cookie_visible(character: str) -> bool:
    codepoint = ord(character)
    return 0x20 <= codepoint <= 0x7E


def _without_management_session(cookie: str) -> str:
    """Remove the gateway-only session cookie without dropping other cookies."""
    retained = [pair for pair, name, _ in _cookie_pairs(cookie) if name.lower() != "management_session"]
    return "; ".join(retained)


def _private_token_file(value: object) -> Path:
    path = Path(value) if isinstance(value, (str, Path)) else Path()
    if not path.is_absolute() or not path.is_file() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise StaticUiHostError("management token file is unsafe")
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise StaticUiHostError("management token file must be owner-only")
    return path


def _read_management_token(path: Path) -> str:
    try:
        token = path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError) as error:
        raise StaticUiHostError("management token is unavailable") from error
    if not token or len(token) > 4096 or not token.isascii() or any(character.isspace() for character in token):
        raise StaticUiHostError("management token is malformed")
    return token

@dataclass(frozen=True)
class UiGatewayConfig:
    host: str; port: int; document_root: Path; management_origin: str; attended_origin: str; request_timeout_seconds: float = 2.0; management_token_file: Path | None = None; session_ttl_seconds: int = 900

    def __post_init__(self) -> None:
        if self.management_token_file is not None:
            path = _private_token_file(self.management_token_file)
            _read_management_token(path)
            object.__setattr__(self, "management_token_file", path)
        if type(self.session_ttl_seconds) is not int or not 1 <= self.session_ttl_seconds <= 86400:
            raise StaticUiHostError("management session expiry is invalid")

def _loopback_origin(value: object, label: str) -> str:
    if not isinstance(value, str): raise StaticUiHostError(f"{label} is invalid")
    parsed = urlsplit(value)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.port is None or parsed.path or parsed.query or parsed.fragment or parsed.username or parsed.password:
        raise StaticUiHostError(f"{label} must be an explicit loopback HTTP origin")
    return value.rstrip("/")

def load_configuration(path: str | Path) -> UiGatewayConfig:
    source = Path(path)
    if not source.is_absolute() or not source.is_file() or source.is_symlink() or any(parent.is_symlink() for parent in source.parents): raise StaticUiHostError("UI host configuration is unsafe")
    try: raw = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error: raise StaticUiHostError("UI host configuration is invalid") from error
    required = {"host", "port", "document_root", "management_origin", "attended_origin"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or set(raw) - (required | {"request_timeout_seconds", "management_token_file", "session_ttl_seconds"}) or raw["host"] != "127.0.0.1" or type(raw["port"]) is not int or not 1 <= raw["port"] <= 65535: raise StaticUiHostError("UI host configuration schema is invalid")
    root, timeout = Path(raw["document_root"]), raw.get("request_timeout_seconds", 2.0)
    if not root.is_absolute() or not root.is_dir() or root.is_symlink() or any(parent.is_symlink() for parent in root.parents) or isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 0 < timeout <= 30: raise StaticUiHostError("UI host configuration is unsafe")
    token_file = raw.get("management_token_file")
    if token_file is not None and not isinstance(token_file, str):
        raise StaticUiHostError("management token file is invalid")
    return UiGatewayConfig(raw["host"], raw["port"], root, _loopback_origin(raw["management_origin"], "management_origin"), _loopback_origin(raw["attended_origin"], "attended_origin"), float(timeout), _private_token_file(token_file) if token_file is not None else None, raw.get("session_ttl_seconds", 900))

class UiGatewayServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, config: UiGatewayConfig): self.config = config; self.sessions: dict[str, tuple[str, float]] = {}; super().__init__((config.host, config.port), UiGatewayHandler)

class UiGatewayHandler(BaseHTTPRequestHandler):
    server: UiGatewayServer
    protocol_version = "HTTP/1.1"
    def setup(self) -> None: super().setup(); self.connection.settimeout(self.server.config.request_timeout_seconds)
    def handle(self) -> None:
        try:
            super().handle()
        except OSError:
            # A browser may disappear while a bounded response is being sent.
            # Treat that as a completed connection, not a server-side failure.
            self.close_connection = True
    def send_error(self, code: int, message: str | None = None, explain: str | None = None) -> None:
        # BaseHTTPRequestHandler handles unknown verbs itself, which would
        # otherwise bypass the framing gate and permit a pipelined body.
        if code == HTTPStatus.NOT_IMPLEMENTED:
            self._unsupported_method()
            return
        super().send_error(code, message, explain)
    def do_GET(self) -> None: self._handle()
    def do_HEAD(self) -> None: self._handle()
    def do_POST(self) -> None: self._handle()
    def do_PUT(self) -> None: self._handle()
    def do_DELETE(self) -> None: self._handle()
    def do_PATCH(self) -> None: self._handle()
    def do_TRACE(self) -> None: self._unsupported_method()
    def do_CONNECT(self) -> None: self._unsupported_method()
    def _handle(self) -> None:
        try:
            self._preflight()
        except RequestBodyTooLarge:
            self._request_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, b"request body is invalid or too large\n")
            return
        except RequestBodyReadError:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request framing is invalid\n")
            return
        except StaticUiHostError:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request framing is invalid\n")
            return
        try:
            cookie = self._cookie_header()
        except CookieHeaderError:
            self._request_error(HTTPStatus.BAD_REQUEST, b"cookie header is invalid or duplicated\n")
            return
        path = urlsplit(self.path).path
        if path == _SESSION_PATH and self.command == "POST":
            self._session_login(cookie)
        elif path == _SESSION_PATH and self.command == "DELETE":
            self._session_logout(cookie)
        elif path == _TRUSTED_BOOTSTRAP_PATH and self.command in {"GET", "HEAD"}:
            self._trusted_bootstrap()
        else:
            origin = self._origin_for(path)
            if origin is not None: self._proxy(origin, management=any(self._matches(path, prefix) for prefix in _MANAGEMENT_PREFIXES), cookie=cookie)
            elif self.command in {"GET", "HEAD"}: self._static(path)
            else: self._reply(HTTPStatus.NOT_FOUND, b"not found\n", "text/plain; charset=utf-8")
    @staticmethod
    def _matches(path: str, prefix: str) -> bool: return path == prefix or path.startswith(prefix + "/")
    def _origin_for(self, path: str) -> str | None:
        if any(self._matches(path, prefix) for prefix in _MANAGEMENT_PREFIXES): return self.server.config.management_origin
        if self._matches(path, "/chat"): return self.server.config.attended_origin
        return None
    def _cookie_header(self) -> str:
        values = [value for key, value in self.headers.items() if key.lower() == "cookie"]
        if len(values) > 1:
            raise CookieHeaderError("duplicate cookie headers")
        return values[0] if values else ""

    def _preflight(self) -> int:
        """Validate request framing before selecting any route or side effect."""
        transfer_encoding = [value for key, value in self.headers.items() if key.lower() == "transfer-encoding"]
        content_lengths = [value for key, value in self.headers.items() if key.lower() == "content-length"]
        if transfer_encoding or len(content_lengths) > 1:
            raise StaticUiHostError("request framing is invalid")
        if not content_lengths:
            size = 0
        else:
            declared = content_lengths[0].strip()
            # Bound the lexical representation before converting it to int;
            # this also avoids pathological integer parsing costs.
            if not declared.isascii() or not declared.isdecimal():
                raise StaticUiHostError("request framing is invalid")
            if len(declared) > len(str(MAX_BODY_BYTES)):
                raise RequestBodyTooLarge
            size = int(declared)
            if size > MAX_BODY_BYTES:
                raise RequestBodyTooLarge
        path = urlsplit(self.path).path
        body_allowed = self.command == "POST" and (
            self._matches(path, "/management") or self._matches(path, "/projects")
            or self._matches(path, "/hardware") or self._matches(path, "/chat")
        )
        if size and not body_allowed:
            raise StaticUiHostError("request body is not permitted")
        self._declared_length = size
        return size

    def _request_body(self) -> bytes | None:
        size = getattr(self, "_declared_length", None)
        if size is None:
            size = self._preflight()
        if size == 0:
            return b""
        try:
            body = self.rfile.read(size)
        except (socket.timeout, TimeoutError, OSError) as error:
            raise RequestBodyReadError from error
        return body if len(body) == size else None

    def _unsupported_method(self) -> None:
        try:
            self._preflight()
        except RequestBodyTooLarge:
            self._request_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, b"request body is invalid or too large\n")
            return
        except (RequestBodyReadError, StaticUiHostError):
            self._request_error(HTTPStatus.BAD_REQUEST, b"request framing is invalid\n")
            return
        self._request_error(HTTPStatus.METHOD_NOT_ALLOWED, b"method not allowed\n")

    def _request_error(self, status: HTTPStatus, message: bytes) -> None:
        self.close_connection = True
        self.send_response(status)
        self.send_header("Connection", "close")
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(message)))
        self.end_headers()
        try:
            self.wfile.write(message)
        except OSError:
            pass

    def _proxy(self, origin: str, *, management: bool, cookie: str) -> None:
        session_token = None
        try:
            body = self._request_body()
        except RequestBodyTooLarge:
            self._request_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, b"request body is invalid or too large\n"); return
        except RequestBodyReadError:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request framing is invalid\n"); return
        if body is None:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request framing is invalid\n"); return
        if self.command in {"GET", "HEAD"} and body:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request body is not permitted\n"); return
        try:
            sanitized_cookie = _without_management_session(cookie)
        except CookieHeaderError:
            self._request_error(HTTPStatus.BAD_REQUEST, b"cookie header is invalid or too large\n"); return
        if management and self.server.config.management_token_file is not None:
            try:
                session_token = self._session_token(cookie)
            except CookieHeaderError:
                self._request_error(HTTPStatus.BAD_REQUEST, b"cookie header is invalid or too large\n"); return
            except StaticUiHostError:
                self._reply(HTTPStatus.SERVICE_UNAVAILABLE, b"gateway credentials are unavailable\n", "text/plain; charset=utf-8"); return
            if session_token is None:
                self._reply(HTTPStatus.UNAUTHORIZED, b"management session is required\n", "text/plain; charset=utf-8"); return
            if self.command not in {"GET", "HEAD"} and not self._same_origin_write(): return
        parsed = urlsplit(origin); upstream = None
        try:
            excluded = _HOP_BY_HOP | {"host", "content-length"}
            if management and self.server.config.management_token_file is not None:
                excluded = excluded | {"authorization"}
            headers = {key: value for key, value in self.headers.items() if key.lower() not in excluded}
            # Remove every case variant before adding the sanitized header;
            # otherwise HTTP clients may forward a stale lowercase duplicate.
            for key in tuple(headers):
                if key.lower() == "cookie":
                    headers.pop(key, None)
            if sanitized_cookie:
                headers["Cookie"] = sanitized_cookie
            if management and self.server.config.management_token_file is not None:
                headers["Authorization"] = "Bearer " + (session_token or _read_management_token(self.server.config.management_token_file))
            if body: headers["Content-Length"] = str(len(body))
            upstream = http.client.HTTPConnection(parsed.hostname, parsed.port, timeout=self.server.config.request_timeout_seconds)
            upstream.request(self.command, self.path, body=body or None, headers=headers); response = upstream.getresponse()
            if 300 <= response.status < 400: response.read(); self._reply(HTTPStatus.BAD_GATEWAY, b"upstream redirect rejected\n", "text/plain; charset=utf-8"); return
            declared = response.getheader("Content-Length")
            if declared is not None and (not declared.isdigit() or int(declared) > MAX_RESPONSE_BYTES): response.read(); self._reply(HTTPStatus.BAD_GATEWAY, b"upstream response is too large\n", "text/plain; charset=utf-8"); return
            payload = response.read(MAX_RESPONSE_BYTES + 1)
            if len(payload) > MAX_RESPONSE_BYTES: self._reply(HTTPStatus.BAD_GATEWAY, b"upstream response is too large\n", "text/plain; charset=utf-8"); return
            self.send_response(response.status)
            for key, value in response.getheaders():
                if key.lower() not in _HOP_BY_HOP | {"content-length", "location"}: self.send_header(key, value)
            self.send_header("Content-Length", str(len(payload))); self.end_headers()
            if self.command != "HEAD": self._safe_write(payload)
        except (OSError, http.client.HTTPException): self._reply(HTTPStatus.BAD_GATEWAY, b"upstream is unavailable\n", "text/plain; charset=utf-8")
        except StaticUiHostError: self._reply(HTTPStatus.SERVICE_UNAVAILABLE, b"gateway credentials are unavailable\n", "text/plain; charset=utf-8")
        finally:
            if upstream is not None: upstream.close()

    def _trusted_bootstrap(self) -> None:
        payload = json.dumps({"trusted": self.server.config.management_token_file is not None}, separators=(",", ":")).encode("utf-8")
        self._reply(HTTPStatus.OK, payload, "application/json; charset=utf-8")
    def _same_origin_write(self) -> bool:
        origin = self.headers.get("Origin")
        expected = f"http://{self.server.config.host}:{self.server.server_address[1]}"
        if origin != expected:
            self._reply(HTTPStatus.FORBIDDEN, b"same-origin request required\n", "text/plain; charset=utf-8"); return False
        return True
    def _session_token(self, cookie: str) -> str | None:
        pairs = _cookie_pairs(cookie)
        session_values = [value for _, name, value in pairs if name.lower() == "management_session"]
        if len(session_values) > 1:
            raise CookieHeaderError("duplicate management session cookies")
        if not session_values: return None
        session_value = session_values[0]
        record = self.server.sessions.get(session_value)
        if record is None: return None
        token, expires = record
        if expires <= time.time(): self.server.sessions.pop(session_value, None); return None
        current = _read_management_token(self.server.config.management_token_file)  # type: ignore[arg-type]
        if not secrets.compare_digest(token, current):
            self.server.sessions.pop(session_value, None)
            return None
        return token
    def _session_login(self, cookie: str) -> None:
        try:
            body = self._request_body()
        except RequestBodyTooLarge:
            self._request_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, b"request body is invalid or too large\n"); return
        except RequestBodyReadError:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request framing is invalid\n"); return
        if body is None:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request framing is invalid\n")
            return
        if body:
            self._request_error(HTTPStatus.BAD_REQUEST, b"request body is not permitted\n"); return
        if not self._same_origin_write(): return
        header = self.headers.get("Authorization", "")
        supplied = header[7:] if header.startswith("Bearer ") else ""
        try: expected = _read_management_token(self.server.config.management_token_file) if self.server.config.management_token_file is not None else ""
        except StaticUiHostError:
            self._reply(HTTPStatus.SERVICE_UNAVAILABLE, b"gateway credentials are unavailable\n", "text/plain; charset=utf-8"); return
        if not supplied or not expected or not secrets.compare_digest(supplied, expected):
            self._reply(HTTPStatus.UNAUTHORIZED, b"setup authorization rejected\n", "text/plain; charset=utf-8"); return
        opaque = secrets.token_urlsafe(32); self.server.sessions[opaque] = (expected, time.time() + self.server.config.session_ttl_seconds)
        payload = json.dumps({"authenticated": True, "expires_in": self.server.config.session_ttl_seconds}, separators=(",", ":")).encode("utf-8")
        self.send_response(HTTPStatus.OK); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Cache-Control", "no-store"); self.send_header("Set-Cookie", f"management_session={opaque}; HttpOnly; SameSite=Strict; Path=/; Max-Age={self.server.config.session_ttl_seconds}"); self.send_header("Content-Length", str(len(payload))); self.end_headers(); self._safe_write(payload)

    def _session_logout(self, cookie: str) -> None:
        if not self._same_origin_write():
            return
        try:
            pairs = _cookie_pairs(cookie)
            session_values = [value for _, name, value in pairs if name.lower() == "management_session"]
            if len(session_values) > 1:
                raise CookieHeaderError("duplicate management session cookies")
        except CookieHeaderError:
            self._request_error(HTTPStatus.BAD_REQUEST, b"cookie header is invalid or duplicated\n")
            return
        if session_values:
            record = self.server.sessions.pop(session_values[0], None)
            if record is not None:
                self._notify_management_logout(record[0])
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Set-Cookie", "management_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _notify_management_logout(self, token: str) -> None:
        """Record logout at the authoritative Management public boundary."""
        origin = urlsplit(self.server.config.management_origin)
        connection: http.client.HTTPConnection | None = None
        try:
            connection = http.client.HTTPConnection(origin.hostname, origin.port, timeout=self.server.config.request_timeout_seconds)
            connection.request("DELETE", _SESSION_PATH, headers={"Authorization": "Bearer " + token})
            response = connection.getresponse(); response.read()
        except (OSError, http.client.HTTPException):
            pass
        finally:
            if connection is not None:
                connection.close()

    def _static(self, path: str) -> None:
        if not path.startswith("/") or "\\" in path or "%" in path: self._reply(HTTPStatus.NOT_FOUND, b"not found\n", "text/plain; charset=utf-8"); return
        relative = path.lstrip("/") or "index.html"; root = self.server.config.document_root.resolve(); candidate = (root / relative).resolve()
        try: candidate.relative_to(root)
        except ValueError: self._reply(HTTPStatus.NOT_FOUND, b"not found\n", "text/plain; charset=utf-8"); return
        if not candidate.is_file() or candidate.is_symlink():
            if "." not in relative.rsplit("/", 1)[-1]: candidate = root / "index.html"
            if not candidate.is_file(): self._reply(HTTPStatus.NOT_FOUND, b"not found\n", "text/plain; charset=utf-8"); return
        payload = candidate.read_bytes()
        if len(payload) > MAX_RESPONSE_BYTES: self._reply(HTTPStatus.SERVICE_UNAVAILABLE, b"static asset exceeds gateway limit\n", "text/plain; charset=utf-8"); return
        self._reply(HTTPStatus.OK, payload, mimetypes.guess_type(str(candidate))[0] or "application/octet-stream")
    def _safe_write(self, payload: bytes) -> None:
        try:
            self.wfile.write(payload)
        except OSError:
            self.close_connection = True

    def _reply(self, status: HTTPStatus, payload: bytes, content_type: str) -> None:
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(payload))); self.send_header("Cache-Control", "no-store"); self.end_headers()
        if self.command != "HEAD": self._safe_write(payload)
    def log_message(self, format: str, *args: object) -> None: pass

def serve(config: UiGatewayConfig) -> UiGatewayServer: return UiGatewayServer(config)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="serve reviewed UI through a bounded loopback same-origin gateway"); parser.add_argument("--config", required=True); parser.add_argument("--check", action="store_true")
    args = parser.parse_args(argv); config = load_configuration(args.config)
    if args.check: print("UI gateway configuration validated; listener was not started"); return 0
    server = serve(config)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
    return 0
if __name__ == "__main__": raise SystemExit(main())
