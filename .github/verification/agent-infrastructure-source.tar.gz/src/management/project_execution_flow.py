"""Prefect execution of one immutable approved project start intent.

Only the durable ``{intent_id, body}`` envelope is a Prefect parameter. Runtime
routes, sessions, credentials, and turn rendering are worker-local trusted
dependencies, never flow parameters or project-selected configuration.
"""
from __future__ import annotations

import hashlib
import json
import os
import math
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol

from shared.contracts.agent_runtime import RuntimeBinding, RuntimeClient
from .state_boundary import ManagementStateBoundaryError, validate_durable_directory, validate_durable_leaf, validate_state_root


class ProjectExecutionError(ValueError): pass
class RuntimeExecutionIncomplete(RuntimeError): pass


class BindingResolver(Protocol):
    def resolve(self, intent_id: str, project_id: str, revision: int, payload: Mapping[str, Any]) -> str: ...


TurnMessageBuilder = Callable[[Mapping[str, Any]], str]

class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl): return None

class ManagementPlanClient:
    """Authenticated read-only plan fetch; no project input can select its origin."""
    def __init__(self, base_url: str, token: str, timeout: float = 5.0) -> None:
        parsed=urlsplit(base_url)
        if not isinstance(token,str) or not token or parsed.scheme not in {"https","http"} or (parsed.scheme=="http" and parsed.hostname not in {"127.0.0.1","::1","localhost"}) or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path.rstrip("/") or not isinstance(timeout,(int,float)) or isinstance(timeout,bool) or not math.isfinite(timeout) or timeout<=0: raise ProjectExecutionError("management plan client configuration is invalid")
        self.base_url,self.token,self.timeout=base_url.rstrip("/"),token,timeout
    def fetch(self, project_id: str, intent_id: str) -> dict[str,Any]:
        url=self.base_url+"/projects/"+quote(project_id,safe="")+"/execution-plans/"+quote(intent_id,safe="")
        try:
            with build_opener(ProxyHandler({}),_NoRedirect()).open(Request(url,headers={"Authorization":"Bearer "+self.token,"Accept":"application/json"}),timeout=self.timeout) as response: raw=response.read(64*1024+1)
        except HTTPError as error:
            try:
                detail=json.loads(error.read(64*1024+1).decode("utf-8")).get("error")
            except (OSError,UnicodeDecodeError,json.JSONDecodeError,AttributeError):
                detail=None
            raise ProjectExecutionError(str(detail) if isinstance(detail,str) and detail else "management plan is unavailable or rejected") from error
        except (OSError,URLError) as error: raise ProjectExecutionError("management plan outcome is unknown") from error
        if len(raw)>64*1024: raise ProjectExecutionError("management plan exceeds bounds")
        try: plan=json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError,json.JSONDecodeError) as error: raise ProjectExecutionError("management plan is malformed") from error
        if not isinstance(plan,dict): raise ProjectExecutionError("management plan is malformed")
        return plan

def _route_path(state_dir: Path, intent_id: str) -> Path:
    if not intent_id or "/" in intent_id or "\\" in intent_id: raise ProjectExecutionError("intent identifier is unsafe")
    return state_dir / "execution-routes" / (intent_id+".json")

def _safe_route_directory(root: Path) -> Path:
    try:
        state_root = validate_state_root(root, "worker route state root")
        directory = validate_durable_directory(root / "execution-routes", state_root, label="execution route directory", allow_missing=True)
        directory.mkdir(mode=0o700, exist_ok=True)
        return validate_durable_directory(directory, state_root, label="execution route directory")
    except (ManagementStateBoundaryError, OSError, TypeError) as error:
        raise ProjectExecutionError("worker route state directory is unsafe") from error

def _fresh_provider(plan: Mapping[str,Any]) -> None:
    provider=plan.get("provider"); health=provider.get("health") if isinstance(provider,Mapping) else None
    if not isinstance(provider,Mapping) or not isinstance(provider.get("provider_id"),str) or not isinstance(provider.get("hardware_node_id"),str) or type(provider.get("generation")) is not int or not isinstance(health,Mapping) or health.get("status")!="healthy" or health.get("provider_generation")!=provider.get("generation") or not isinstance(health.get("hardware_boot_id"),str) or not isinstance(health.get("lease_expires_at"),str) or not isinstance(health.get("observed_at"),str): raise ProjectExecutionError("management plan provider health is invalid")
    try:
        observed=datetime.fromisoformat(health["observed_at"].replace("Z","+00:00")); lease=datetime.fromisoformat(health["lease_expires_at"].replace("Z","+00:00"))
    except ValueError as error: raise ProjectExecutionError("management plan provider timestamps are invalid") from error
    now=datetime.now(timezone.utc)
    if observed.tzinfo is None or lease.tzinfo is None or observed>now or lease<=now: raise ProjectExecutionError("management plan provider health is stale")

def _composite_plan_readiness(plan: Mapping[str,Any]) -> None:
    provider=plan.get("provider")
    health=provider.get("health") if isinstance(provider,Mapping) else None
    evidence=health.get("readiness") if isinstance(health,Mapping) else None
    if not isinstance(provider,Mapping) or not isinstance(health,Mapping):
        raise ProjectExecutionError("management plan provider composite readiness is unavailable: provider_identity")
    capabilities=provider.get("capabilities") if isinstance(provider.get("capabilities"),list) else []
    if provider.get("required_capability") and provider["required_capability"] not in capabilities:
        raise ProjectExecutionError("management plan provider composite readiness is unavailable: declared_capabilities_missing")
    if not isinstance(evidence,Mapping) or evidence.get("authenticated") is not True:
        raise ProjectExecutionError("management plan provider composite readiness is unavailable: authentication_unavailable")
    if evidence.get("service_reachable") is not True:
        raise ProjectExecutionError("management plan provider composite readiness is unavailable: service_unreachable")
    try:
        observed=datetime.fromisoformat(health["observed_at"].replace("Z","+00:00")); lease=datetime.fromisoformat(health["lease_expires_at"].replace("Z","+00:00"))
    except (KeyError,AttributeError,TypeError,ValueError) as error:
        raise ProjectExecutionError("management plan provider composite readiness is unavailable: readiness_stale") from error
    now=datetime.now(timezone.utc)
    if health.get("status")!="healthy" or health.get("provider_generation")!=provider.get("generation") or observed.tzinfo is None or lease.tzinfo is None or observed>now or lease<=now:
        raise ProjectExecutionError("management plan provider composite readiness is unavailable: readiness_stale")

def fetch_and_pin_management_plan(plan_client: ManagementPlanClient, state_dir: str|Path, approved: "ApprovedStartIntent", runtime: RuntimeClient, local_sessions: Mapping[str,str]) -> dict[str,Any]:
    root=Path(state_dir); directory=_safe_route_directory(root)
    try: path=validate_durable_leaf(_route_path(root,approved.intent_id), root, label="execution route file")
    except ManagementStateBoundaryError as error: raise ProjectExecutionError("execution route file is unsafe") from error
    if path.exists(): raise ProjectExecutionError("execution route already exists; reconcile using its pinned identity")
    plan=plan_client.fetch(approved.project_id,approved.intent_id)
    digest=hashlib.sha256(approved.payload_json.encode()).hexdigest()
    required={"intent_id","project_id","revision","payload","payload_sha256","runtime_binding","runtime_session_id","provider","message"}
    if set(plan)!=required or plan.get("intent_id")!=approved.intent_id or plan.get("project_id")!=approved.project_id or plan.get("revision")!=approved.revision or plan.get("payload")!=approved.payload() or plan.get("payload_sha256")!=digest or not isinstance(plan.get("runtime_binding"),str) or local_sessions.get(plan["runtime_binding"])!=plan.get("runtime_session_id") or not isinstance(plan.get("message"),str) or len(plan["message"].encode("utf-8"))>64*1024: raise ProjectExecutionError("management plan does not match the approved intent or local route allowlist")
    _fresh_provider(plan); bundle={"plan":plan,"runtime_identity":runtime.binding_identity(plan["runtime_binding"])}; raw=_canonical(bundle).encode("utf-8")
    try:
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError as error: raise ProjectExecutionError("execution route already exists; reconcile using its pinned identity") from error
    try:
        with os.fdopen(fd,"wb") as handle: handle.write(raw); handle.flush(); os.fsync(handle.fileno())
        try: dfd=os.open(directory,os.O_RDONLY); os.fsync(dfd); os.close(dfd)
        except OSError: pass
    except Exception:
        raise
    return bundle

def pinned_management_plan(state_dir: str|Path, approved: "ApprovedStartIntent", runtime: RuntimeClient, local_sessions: Mapping[str,str]) -> dict[str,Any]:
    root=Path(state_dir); _safe_route_directory(root)
    try: path=validate_durable_leaf(_route_path(root,approved.intent_id), root, label="execution route file", allow_missing=False)
    except ManagementStateBoundaryError as error: raise ProjectExecutionError("pinned execution route is unsafe") from error
    if not path.is_file(): raise ProjectExecutionError("no pinned execution route exists for reconciliation")
    try: plan=json.loads(path.read_text(encoding="utf-8"))
    except (OSError,json.JSONDecodeError) as error: raise ProjectExecutionError("pinned execution route is invalid") from error
    if not isinstance(plan,dict) or set(plan)!={"plan","runtime_identity"} or not isinstance(plan["plan"],dict) or not isinstance(plan["runtime_identity"],dict): raise ProjectExecutionError("pinned execution route is invalid")
    bundle=plan; plan=bundle["plan"]; digest=hashlib.sha256(approved.payload_json.encode()).hexdigest()
    if plan.get("intent_id")!=approved.intent_id or plan.get("project_id")!=approved.project_id or plan.get("revision")!=approved.revision or plan.get("payload")!=approved.payload() or plan.get("payload_sha256")!=digest or local_sessions.get(plan.get("runtime_binding"))!=plan.get("runtime_session_id") or runtime.binding_identity(plan["runtime_binding"])!=bundle["runtime_identity"] or not isinstance(plan.get("message"),str): raise ProjectExecutionError("pinned execution route no longer matches the approved intent or local identity")
    provider=plan.get("provider"); health=provider.get("health") if isinstance(provider,Mapping) else None
    if not isinstance(provider,Mapping) or not isinstance(health,Mapping) or not isinstance(provider.get("provider_id"),str) or type(provider.get("generation")) is not int or not isinstance(provider.get("hardware_node_id"),str) or health.get("provider_generation")!=provider.get("generation") or not isinstance(health.get("hardware_boot_id"),str): raise ProjectExecutionError("pinned execution provider identity is invalid")
    return bundle


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass(frozen=True)
class ApprovedStartIntent:
    intent_id: str
    project_id: str
    revision: int
    payload_json: str

    @classmethod
    def from_parameter(cls, value: Mapping[str, Any]) -> "ApprovedStartIntent":
        if not isinstance(value, Mapping) or set(value) != {"intent_id", "body"}:
            raise ProjectExecutionError("Prefect parameter must be the explicit start-intent envelope")
        intent_id, body = value.get("intent_id"), value.get("body")
        if not isinstance(intent_id, str) or not intent_id or not isinstance(body, Mapping):
            raise ProjectExecutionError("start-intent envelope is malformed")
        if set(body) != {"project_id", "revision", "kind", "payload"} or body.get("kind") != "project_start_intent":
            raise ProjectExecutionError("start-intent body is malformed")
        project_id, revision, payload = body.get("project_id"), body.get("revision"), body.get("payload")
        if not isinstance(project_id, str) or not project_id or type(revision) is not int or revision < 1 or not isinstance(payload, Mapping):
            raise ProjectExecutionError("start-intent body fields are invalid")
        try: payload_json = _canonical(payload)
        except (TypeError, ValueError) as error: raise ProjectExecutionError("start-intent payload is not canonical JSON") from error
        if len(payload_json.encode("utf-8")) > 64 * 1024 or len(_canonical(value).encode("utf-8")) > 80 * 1024:
            raise ProjectExecutionError("start-intent envelope exceeds the bounded size")
        return cls(intent_id, project_id, revision, payload_json)

    def payload(self) -> dict[str, Any]: return json.loads(self.payload_json)
    def snapshot(self) -> dict[str, Any]: return {"intent_id": self.intent_id, "project_id": self.project_id, "revision": self.revision, "payload": self.payload()}
    def fingerprint(self) -> str: return hashlib.sha256(_canonical(self.snapshot()).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class WorkerDependencies:
    resolver: BindingResolver
    runtime: RuntimeClient
    message_builder: TurnMessageBuilder
    admission: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None

@dataclass(frozen=True)
class ManagementWorkerDependencies:
    plan_client: ManagementPlanClient
    state_dir: Path
    runtime: RuntimeClient
    local_sessions: Mapping[str,str]


_worker_factory: Callable[[], WorkerDependencies] | None = None


def configure_project_execution_worker(factory: Callable[[], WorkerDependencies]) -> None:
    """Set worker-startup dependencies; credentials never travel through Prefect."""
    global _worker_factory
    if not callable(factory): raise ProjectExecutionError("worker dependency factory is required")
    _worker_factory = factory


def _dependencies() -> WorkerDependencies | ManagementWorkerDependencies:
    if _worker_factory is None:
        config_path = os.environ.get("AGENT_STACK_PROJECT_EXECUTION_CONFIG")
        if not config_path: raise ProjectExecutionError("project execution worker configuration path is not set")
        return load_project_execution_worker_config(config_path)
    dependencies = _worker_factory()
    if not isinstance(dependencies, WorkerDependencies): raise ProjectExecutionError("worker dependency factory returned an invalid dependency bundle")
    return dependencies


def _message(approved: ApprovedStartIntent, builder: TurnMessageBuilder) -> str:
    message = builder(approved.snapshot())
    if not isinstance(message, str) or not message or len(message.encode("utf-8")) > 64 * 1024:
        raise ProjectExecutionError("configured turn message must be a bounded non-empty string")
    return message


def _require_current_admission(approved: ApprovedStartIntent, admission: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None) -> None:
    if not callable(admission):
        raise ProjectExecutionError("current composite admission is required; migrate to management plan dispatch")
    try:
        report = admission(approved.snapshot())
    except Exception as error:
        raise ProjectExecutionError("current composite admission is unavailable; migrate to management plan dispatch") from error
    evidence = (
        isinstance(report, Mapping)
        and report.get("authenticated") is True
        and report.get("service_reachable") is True
        and report.get("fresh") is True
    )
    if not evidence and isinstance(report, Mapping) and isinstance(report.get("dependencies"), list) and report["dependencies"]:
        def dependency_is_fresh(item: object) -> bool:
            if not isinstance(item, Mapping) or item.get("eligible") is not True or not isinstance(item.get("checks"), Mapping):
                return False
            checks = item["checks"]
            return all(isinstance(checks.get(name), Mapping) and checks[name].get("ok") is True for name in ("authentication", "service_reachability", "freshness"))
        evidence = all(
            dependency_is_fresh(item)
            for item in report["dependencies"]
        )
    if not isinstance(report, Mapping) or report.get("eligible") is not True or not evidence:
        dependency = report.get("unavailable_dependency") if isinstance(report, Mapping) else None
        reason = report.get("reason") if isinstance(report, Mapping) else None
        raise ProjectExecutionError(f"current composite admission is unavailable: {dependency or reason or 'composite_readiness'}")


def load_project_execution_worker_config(path: str | Path) -> WorkerDependencies | ManagementWorkerDependencies:
    """Load process-local credentials and exact approved-intent routes from JSON.

    The operator supplies this absolute, non-symlink file outside the repository.
    Each intent route pins the approved payload digest and one configured message;
    this deliberately does not read a PRD path or any project-controlled file.
    """
    config_path = Path(path)
    if not config_path.is_absolute() or config_path.is_symlink() or not config_path.is_file():
        raise ProjectExecutionError("worker configuration must be an absolute non-symlink file")
    try: raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error: raise ProjectExecutionError("worker configuration is invalid JSON") from error
    if not isinstance(raw, Mapping) or not isinstance(raw.get("runtime_bindings"), Mapping):
        raise ProjectExecutionError("worker configuration has an invalid shape")
    bindings: dict[str, RuntimeBinding] = {}
    try:
        for binding_id, item in raw["runtime_bindings"].items():
            if not isinstance(item, Mapping): raise ProjectExecutionError("runtime binding is invalid")
            bindings[binding_id] = RuntimeBinding(binding_id, item["base_url"], item["session_id"], item["token"], item.get("timeout_seconds", 5.0))
    except (KeyError, TypeError, ValueError) as error: raise ProjectExecutionError("runtime binding is invalid") from error
    if set(raw) == {"runtime_bindings", "management", "state_dir"}:
        management=raw["management"]
        if not isinstance(management,Mapping) or set(management) - {"base_url","token","timeout_seconds"} or not isinstance(raw["state_dir"],str): raise ProjectExecutionError("management worker configuration is invalid")
        local_sessions={key:value.session_id for key,value in bindings.items()}
        return ManagementWorkerDependencies(ManagementPlanClient(management.get("base_url"),management.get("token"),management.get("timeout_seconds",5.0)),Path(raw["state_dir"]),RuntimeClient(bindings),local_sessions)
    if set(raw) != {"runtime_bindings", "approved_intents"} or not isinstance(raw["approved_intents"], Mapping):
        raise ProjectExecutionError("worker configuration has an invalid shape")
    routes: dict[str, dict[str, Any]] = {}
    for intent_id, item in raw["approved_intents"].items():
        if not isinstance(intent_id, str) or not isinstance(item, Mapping) or set(item) != {"project_id", "revision", "payload_sha256", "binding_id", "message"}:
            raise ProjectExecutionError("approved intent route is invalid")
        if not isinstance(item.get("project_id"), str) or type(item.get("revision")) is not int or item["revision"] < 1 or not isinstance(item.get("payload_sha256"), str) or len(item["payload_sha256"]) != 64 or item.get("binding_id") not in bindings or not isinstance(item.get("message"), str) or not item["message"] or len(item["message"].encode("utf-8")) > 64 * 1024:
            raise ProjectExecutionError("approved intent route is invalid")
        routes[intent_id] = dict(item)
    def route(snapshot: Mapping[str, Any]) -> dict[str, Any]:
        item = routes.get(snapshot.get("intent_id"))
        payload = snapshot.get("payload")
        digest = hashlib.sha256(_canonical(payload).encode("utf-8")).hexdigest() if isinstance(payload, Mapping) else ""
        if item is None or item["project_id"] != snapshot.get("project_id") or item["revision"] != snapshot.get("revision") or item["payload_sha256"] != digest:
            raise ProjectExecutionError("start intent is not an explicitly approved worker route")
        return item
    class ConfigResolver:
        def resolve(self, intent_id: str, project_id: str, revision: int, payload: Mapping[str, Any]) -> str:
            return route({"intent_id": intent_id, "project_id": project_id, "revision": revision, "payload": payload})["binding_id"]
    return WorkerDependencies(ConfigResolver(), RuntimeClient(bindings), lambda snapshot: route(snapshot)["message"])


def execute_approved_start_intent(start_intent: Mapping[str, Any], dependencies: WorkerDependencies) -> dict[str, Any]:
    """Submit once. Any non-completed receipt remains a recovery state, not success."""
    approved = ApprovedStartIntent.from_parameter(start_intent)
    _require_current_admission(approved, dependencies.admission)
    binding_id = dependencies.resolver.resolve(approved.intent_id, approved.project_id, approved.revision, approved.payload())
    if not isinstance(binding_id, str) or not binding_id: raise ProjectExecutionError("configured binding resolver did not select a runtime")
    receipt = dependencies.runtime.submit_turn(binding_id, request_id=approved.intent_id, project_id=approved.project_id, revision_id=str(approved.revision), message=_message(approved, dependencies.message_builder))
    if receipt.get("state") != "completed": raise RuntimeExecutionIncomplete("runtime turn is not confirmed completed; reconcile its durable receipt")
    return {"intent_id": approved.intent_id, "project_id": approved.project_id, "revision": approved.revision, "binding_id": binding_id, "intent_fingerprint": approved.fingerprint(), "runtime_receipt": receipt}


def reconcile_approved_start_intent(start_intent: Mapping[str, Any], dependencies: WorkerDependencies) -> dict[str, Any] | None:
    """Read-only recovery; it never resubmits a possibly effected native turn."""
    approved = ApprovedStartIntent.from_parameter(start_intent)
    _require_current_admission(approved, dependencies.admission)
    binding_id = dependencies.resolver.resolve(approved.intent_id, approved.project_id, approved.revision, approved.payload())
    if not isinstance(binding_id, str) or not binding_id: raise ProjectExecutionError("configured binding resolver did not select a runtime")
    receipt = dependencies.runtime.operation(binding_id, request_id=approved.intent_id, project_id=approved.project_id, revision_id=str(approved.revision), message=_message(approved, dependencies.message_builder))
    if receipt is None: return None
    return {"intent_id": approved.intent_id, "project_id": approved.project_id, "revision": approved.revision, "binding_id": binding_id, "intent_fingerprint": approved.fingerprint(), "runtime_receipt": receipt}

def execute_management_planned_intent(start_intent: Mapping[str, Any], plan_client: ManagementPlanClient, state_dir: str|Path, runtime: RuntimeClient, local_sessions: Mapping[str,str]) -> dict[str,Any]:
    approved=ApprovedStartIntent.from_parameter(start_intent); plan=fetch_and_pin_management_plan(plan_client,state_dir,approved,runtime,local_sessions)["plan"]
    current=plan_client.fetch(approved.project_id,approved.intent_id)
    if current != plan:
        _composite_plan_readiness(current)
        raise ProjectExecutionError("management plan changed before submit; current composite admission is required")
    _composite_plan_readiness(current)
    receipt=runtime.submit_turn(plan["runtime_binding"],request_id=approved.intent_id,project_id=approved.project_id,revision_id=str(approved.revision),message=plan["message"])
    if receipt.get("state")!="completed": raise RuntimeExecutionIncomplete("runtime turn is not confirmed completed; reconcile its durable receipt")
    return {"intent_id":approved.intent_id,"binding_id":plan["runtime_binding"],"intent_fingerprint":approved.fingerprint(),"runtime_receipt":receipt}

def reconcile_management_planned_intent(start_intent: Mapping[str, Any], state_dir: str|Path, runtime: RuntimeClient, local_sessions: Mapping[str,str]) -> dict[str,Any]|None:
    approved=ApprovedStartIntent.from_parameter(start_intent); plan=pinned_management_plan(state_dir,approved,runtime,local_sessions)["plan"]
    receipt=runtime.operation(plan["runtime_binding"],request_id=approved.intent_id,project_id=approved.project_id,revision_id=str(approved.revision),message=plan["message"])
    return None if receipt is None else {"intent_id":approved.intent_id,"binding_id":plan["runtime_binding"],"intent_fingerprint":approved.fingerprint(),"runtime_receipt":receipt}


def _run_flow(start_intent: Mapping[str, Any]) -> dict[str, Any]:
    dependencies=_dependencies()
    if isinstance(dependencies,ManagementWorkerDependencies):
        return execute_management_planned_intent(start_intent,dependencies.plan_client,dependencies.state_dir,dependencies.runtime,dependencies.local_sessions)
    return execute_approved_start_intent(start_intent, dependencies)


try:
    from prefect import flow, task
except ImportError:  # pragma: no cover
    PREFECT_AVAILABLE = False
    project_execution_flow = None
else:
    PREFECT_AVAILABLE = True

if PREFECT_AVAILABLE:
    @task(name="project-orchestrator-turn", retries=0, persist_result=True, result_serializer="json")
    def submit_project_orchestrator_turn(start_intent: dict[str, Any]) -> dict[str, Any]: return _run_flow(start_intent)

    @flow(name="agent-stack-project-execution", retries=0, persist_result=True, result_serializer="json", validate_parameters=False)
    def project_execution_flow(start_intent: dict[str, Any]) -> dict[str, Any]: return submit_project_orchestrator_turn(start_intent)
