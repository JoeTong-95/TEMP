"""Launch the private, authenticated loopback merge-authority HTTP service."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Mapping

from .gitea_merge_authority import MergeAuthorityError, _token
from .merge_authority_http import serve
from .merge_authority_service import _private_config, build_from_config


def load_http_scopes(path: str | Path) -> Mapping[str, frozenset[str]]:
    raw = _private_config(Path(path))
    if set(raw) != {"listen_host", "listen_port", "scopes"} or raw["listen_host"] != "127.0.0.1" or type(raw["listen_port"]) is not int or not 1 <= raw["listen_port"] <= 65535 or not isinstance(raw["scopes"], list):
        raise MergeAuthorityError("merge HTTP configuration schema is invalid")
    values: dict[str, frozenset[str]] = {}
    for scope in raw["scopes"]:
        if not isinstance(scope, Mapping) or set(scope) != {"token_file", "projects"} or not isinstance(scope["token_file"], str) or not isinstance(scope["projects"], list) or not scope["projects"]:
            raise MergeAuthorityError("merge HTTP token scope is invalid")
        token_path = Path(scope["token_file"])
        token = _token(token_path)
        projects = frozenset(scope["projects"])
        if not token or token in values or any(not isinstance(project, str) or not project for project in projects):
            raise MergeAuthorityError("merge HTTP token scope is invalid")
        values[token] = projects
    if not values:
        raise MergeAuthorityError("merge HTTP token scopes are empty")
    return values


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="authenticated loopback receipt-gated merge service")
    parser.add_argument("--authority-config", required=True)
    parser.add_argument("--http-config", required=True)
    args = parser.parse_args(argv)
    authority = build_from_config(args.authority_config)
    raw = _private_config(Path(args.http_config))
    scopes = load_http_scopes(args.http_config)
    server = serve(authority, scopes, (raw["listen_host"], raw["listen_port"]))
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
