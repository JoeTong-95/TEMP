"""Storage-owned authenticated shared-memory authority.

The v1 retention policy is append-only revisions: corrections point at the
source revision and may supersede it; physical deletion is deliberately not a
public operation. A caller can therefore recover the current value and its
correction/supersession provenance after a restart without losing the audit
trail. Publication outcomes are durable and keyed by caller-supplied identity.
"""
from __future__ import annotations

from contextlib import closing
import argparse
import hashlib, hmac, json, os, sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Mapping

from shared.contracts.shared_memory import AuthenticatedCaller, MemoryRequest, ScopeGrant, SharedMemoryAdapter, SharedMemoryDenied, SharedMemoryError, _record, _scope

MAX_BODY=32*1024
DELETION_PROVENANCE={'policy':'append_only','public_delete':False,'state':'retained'}

def _now(): return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def _safe_path(path:Path):
    if not path.is_absolute() or path.is_symlink() or any(p.is_symlink() for p in path.parents) or not path.parent.is_dir(): raise SharedMemoryError('memory database path is unsafe')

@dataclass(frozen=True)
class SharedMemoryServiceConfig:
    database:Path
    callers:Mapping[str,AuthenticatedCaller]
    def __post_init__(self):
        _safe_path(self.database)
        if not self.callers or any(not isinstance(token,str) or not token or not isinstance(caller,AuthenticatedCaller) for token,caller in self.callers.items()): raise SharedMemoryError('memory caller config is invalid')

class SharedMemoryStore:
    def __init__(self, config:SharedMemoryServiceConfig):
        self.config=config
        with closing(sqlite3.connect(config.database)) as db:
            db.execute('CREATE TABLE IF NOT EXISTS memory_records(record_id TEXT NOT NULL,scope TEXT NOT NULL,revision INTEGER NOT NULL,record TEXT NOT NULL,PRIMARY KEY(record_id,scope,revision))')
            db.execute('CREATE TABLE IF NOT EXISTS memory_proposals(idempotency_key TEXT PRIMARY KEY,record TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS memory_operations(idempotency_key TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,owner TEXT,outcome TEXT NOT NULL)')
            if 'owner' not in {column[1] for column in db.execute('PRAGMA table_info(memory_operations)')}:
                db.execute('ALTER TABLE memory_operations ADD COLUMN owner TEXT')
            for key,outcome in db.execute('SELECT idempotency_key,outcome FROM memory_operations WHERE owner IS NULL'):
                try: owner=json.loads(outcome)['record']['provenance']['actor_id']
                except (KeyError,TypeError,json.JSONDecodeError): continue
                if isinstance(owner,str): db.execute('UPDATE memory_operations SET owner=? WHERE idempotency_key=?',(owner,key))
            db.commit()
    @staticmethod
    def _perm(caller:AuthenticatedCaller,scope:str,permission:str):
        _,scope_id=_scope(scope)
        if scope.startswith(('project.','handoffs.')) and scope_id not in caller.project_ids: raise SharedMemoryDenied('project scope denied')
        if scope.startswith('agent.') and scope_id!=caller.agent_id: raise SharedMemoryDenied('private agent scope denied')
        permission = 'publish' if permission == 'write' else permission
        if not any(g.scope==scope and (getattr(g,permission) or (permission == 'publish' and g.write)) for g in caller.grants): raise SharedMemoryDenied('scope permission denied')
    @staticmethod
    def _payload_record(payload:Mapping[str,Any],revision:int):
        required={'record_id','scope','expected_revision','idempotency_key','provenance','sensitivity','observed_at','freshness','grants','content','metadata','correction_of','supersedes'}
        if set(payload)!=required: raise SharedMemoryError('memory write schema invalid')
        stamp=_now()
        return {key:payload[key] for key in ('record_id','scope','provenance','sensitivity','observed_at','freshness','grants','content','metadata','correction_of','supersedes')} | {'revision':revision,'updated_at':stamp,'deletion_provenance':DELETION_PROVENANCE}
    @staticmethod
    def _current_records(db:sqlite3.Connection,scope:str)->dict[str,dict[str,Any]]:
        rows=db.execute('SELECT record FROM memory_records WHERE scope=? ORDER BY revision',(scope,)).fetchall()
        records={}
        for row in rows:
            record=json.loads(row[0]);record.setdefault('deletion_provenance',DELETION_PROVENANCE)
            if record['record_id'] not in records or record['revision'] > records[record['record_id']]['revision']: records[record['record_id']]=record
        return records
    @classmethod
    def _resolved(cls,db:sqlite3.Connection,record_id:str,scope:str)->tuple[dict[str,Any]|None,list[dict[str,Any]]]:
        records=cls._current_records(db,scope); current=records.get(record_id)
        seen=set()
        chain=[]
        while current is not None:
            if current['record_id'] in seen: raise SharedMemoryError('supersession cycle detected')
            seen.add(current['record_id'])
            chain.append({'record_id':current['record_id'],'supersedes':current.get('supersedes')})
            successors=[record for record in records.values() if record.get('supersedes')==current['record_id']]
            if not successors:return current,chain
            current=max(successors,key=lambda record:record['revision'])
        return None,chain
    @classmethod
    def _current(cls,db:sqlite3.Connection,record_id:str,scope:str)->dict[str,Any]|None:
        return cls._resolved(db,record_id,scope)[0]
    @classmethod
    def _validate_supersession(cls,db:sqlite3.Connection,payload:Mapping[str,Any]):
        supersedes=payload.get('supersedes');record_id=payload.get('record_id')
        if supersedes is None:return
        if supersedes==record_id: raise SharedMemoryError('record cannot supersede itself')
        records=cls._current_records(db,payload['scope']);current=records.get(supersedes);seen=set()
        if current is None: raise SharedMemoryError('superseded record does not exist')
        if any(record['record_id']!=record_id and record.get('supersedes')==supersedes for record in records.values()): raise SharedMemoryError('record already has a successor')
        while current is not None:
            if current['record_id']==record_id or current['record_id'] in seen: raise SharedMemoryError('supersession cycle detected')
            seen.add(current['record_id']);current=records.get(current.get('supersedes'))
    def write(self,caller:AuthenticatedCaller,request:MemoryRequest)->dict[str,Any]:
        payload=request.payload; scope=payload.get('scope')
        if request.operation == 'propose': self._perm(caller,scope,'propose')
        else: self._perm(caller,scope,'write')
        if request.operation not in {'propose','publish','correct','handoff'}: raise SharedMemoryError('write operation denied')
        if (payload.get('correction_of') is None)!=(payload.get('supersedes') is None) or payload.get('correction_of')!=payload.get('supersedes'): raise SharedMemoryError('correction provenance must be absent or name one superseded record')
        provenance=payload.get('provenance')
        if not isinstance(provenance,Mapping) or provenance.get('actor_id')!=caller.caller_id: raise SharedMemoryDenied('provenance actor is not caller')
        fingerprint=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest(); key=payload.get('idempotency_key')
        with closing(sqlite3.connect(self.config.database)) as db:
            db.execute('BEGIN IMMEDIATE'); old=db.execute('SELECT fingerprint,outcome FROM memory_operations WHERE idempotency_key=?',(key,)).fetchone()
            if old:
                if not hmac.compare_digest(old[0],fingerprint): raise SharedMemoryError('idempotency key conflicts')
                return json.loads(old[1])
            if request.operation == 'propose':
                record=self._payload_record(payload,1); normalized=_record(record)
                output={'status':'proposed','record':record}; encoded=json.dumps(output,sort_keys=True,separators=(',',':'))
                db.execute('INSERT INTO memory_proposals VALUES(?,?)',(key,json.dumps(record,sort_keys=True,separators=(',',':'))))
                db.execute('INSERT INTO memory_operations(idempotency_key,fingerprint,owner,outcome) VALUES(?,?,?,?)',(key,fingerprint,caller.caller_id,encoded));db.commit();return output
            latest=db.execute('SELECT revision,record FROM memory_records WHERE record_id=? AND scope=? ORDER BY revision DESC LIMIT 1',(payload.get('record_id'),scope)).fetchone()
            expected=payload.get('expected_revision')
            source=None
            if request.operation=='correct' and payload.get('correction_of') is not None:
                source=db.execute('SELECT revision,record FROM memory_records WHERE record_id=? AND scope=? ORDER BY revision DESC LIMIT 1',(payload['correction_of'],scope)).fetchone()
            if latest is None:
                if request.operation=='correct':
                    if source is None or expected!=source[0]: raise SharedMemoryError('record revision conflict')
                    revision=source[0]+1
                elif expected is not None: raise SharedMemoryError('record revision conflict')
                else: revision=1
            else:
                if expected!=latest[0]: raise SharedMemoryError('record revision conflict')
                if request.operation=='correct' and payload.get('correction_of') is None: raise SharedMemoryError('correction must name source')
                revision=latest[0]+1
            self._validate_supersession(db,payload)
            record=self._payload_record(payload,revision); normalized=_record(record)
            output={'status': 'proposed' if request.operation == 'propose' else 'published', 'record':record}; encoded=json.dumps(output,sort_keys=True,separators=(',',':'))
            db.execute('INSERT INTO memory_records VALUES(?,?,?,?)',(normalized.record_id,normalized.scope,revision,json.dumps(record,sort_keys=True,separators=(',',':')))); db.execute('INSERT INTO memory_operations(idempotency_key,fingerprint,owner,outcome) VALUES(?,?,?,?)',(key,fingerprint,caller.caller_id,encoded));db.commit();return output
    def read(self,caller:AuthenticatedCaller,record_id:str,scope:str)->dict[str,Any]:
        self._perm(caller,scope,'read');self._perm(caller,scope,'disclose')
        with closing(sqlite3.connect(self.config.database)) as db: record,chain=self._resolved(db,record_id,scope)
        if record is None:return {'record':None}
        grants=record['grants']
        if caller.caller_id not in grants['read'] or caller.caller_id not in grants['disclose']: raise SharedMemoryDenied('record disclosure denied')
        return {'record':record,'supersession_chain':chain}
    def context(self,caller:AuthenticatedCaller,scope:str,limit:int=8)->dict[str,Any]:
        self._perm(caller,scope,'read');self._perm(caller,scope,'disclose')
        if type(limit) is not int or not 1<=limit<=32: raise SharedMemoryError('context limit invalid')
        with closing(sqlite3.connect(self.config.database)) as db:
            current=self._current_records(db,scope)
        superseded={record['supersedes'] for record in current.values() if record.get('supersedes') not in {None,record['record_id']}}
        records=[]
        for record in sorted(current.values(),key=lambda record:record['revision'],reverse=True):
            if record['record_id'] in superseded: continue
            grants=record['grants']
            if caller.caller_id in grants['read'] and caller.caller_id in grants['disclose']: records.append(record)
        return {'records':records[:limit]}
    def operation(self,caller:AuthenticatedCaller,key:str)->dict[str,Any]:
        if not isinstance(key,str) or not key: raise SharedMemoryError('operation key invalid')
        with closing(sqlite3.connect(self.config.database)) as db: row=db.execute('SELECT owner,outcome FROM memory_operations WHERE idempotency_key=?',(key,)).fetchone()
        if row is None: raise SharedMemoryError('operation not found')
        owner,value=row[0],json.loads(row[1]);record=value.get('record') if isinstance(value,Mapping) else None
        if not isinstance(record,Mapping): raise SharedMemoryError('operation outcome invalid')
        if owner == caller.caller_id:return value
        self._perm(caller,record.get('scope'),'read');self._perm(caller,record.get('scope'),'disclose')
        grants=record.get('grants',{})
        if caller.caller_id not in grants.get('read',[]) or caller.caller_id not in grants.get('disclose',[]): raise SharedMemoryDenied('operation disclosure denied')
        return value

def serve(store:SharedMemoryStore,address=('127.0.0.1',0)):
    if address[0]!='127.0.0.1':raise SharedMemoryError('memory HTTP must bind loopback')
    class Server(ThreadingHTTPServer):pass
    server=Server(address,BaseHTTPRequestHandler);server.store=store
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,status,value):
            raw=json.dumps(value,separators=(',',':')).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
        def caller(self):
            token=self.headers.get('Authorization','')[7:] if self.headers.get('Authorization','').startswith('Bearer ') else ''
            for candidate,caller in store.config.callers.items():
                if hmac.compare_digest(token,candidate):return caller
            raise SharedMemoryDenied('caller not authenticated')
        def body(self):
            length=int(self.headers.get('Content-Length','-1'))
            if not 0<=length<=MAX_BODY:raise SharedMemoryError('body invalid')
            data=json.loads(self.rfile.read(length).decode());
            if not isinstance(data,dict):raise SharedMemoryError('body invalid')
            return data
        def do_POST(self):
            try:
                caller=self.caller(); body=self.body()
                if self.path=='/records':
                    operation=body.pop('operation',None)
                    result=store.write(caller,MemoryRequest(operation,body))
                elif self.path=='/context' and set(body)=={'scope','limit'}: result=store.context(caller,body['scope'],body['limit'])
                else: raise SharedMemoryError('route denied')
                self.reply(200,result)
            except SharedMemoryDenied:self.reply(403,{'error':'denied'})
            except (SharedMemoryError,ValueError,UnicodeDecodeError,json.JSONDecodeError):self.reply(409,{'error':'invalid'})
        def do_GET(self):
            try:
                caller=self.caller();parts=self.path.split('/')
                if len(parts)==3 and parts[1]=='operations': self.reply(200,store.operation(caller,parts[2]))
                elif len(parts)==4 and parts[1]=='records': self.reply(200,store.read(caller,parts[3],parts[2]))
                else: raise SharedMemoryError('route denied')
            except SharedMemoryDenied:self.reply(403,{'error':'denied'})
            except SharedMemoryError:self.reply(404,{'error':'missing'})
    server.RequestHandlerClass=Handler
    return server

def load_config(path:str|Path)->tuple[SharedMemoryServiceConfig,tuple[str,int]]:
    path=Path(path)
    if not path.is_absolute() or not path.is_file() or path.is_symlink() or any(p.is_symlink() for p in path.parents) or (os.name=='posix' and path.stat().st_mode&0o077): raise SharedMemoryError('memory config unsafe')
    raw=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(raw,Mapping) or set(raw)!={'listen_host','listen_port','database','callers','basic_memory'} or raw['listen_host']!='127.0.0.1' or type(raw['listen_port']) is not int or not isinstance(raw['callers'],list) or raw['basic_memory']!={'enabled':False,'synthetic_data_only':True,'destructive_tools':'denied'}: raise SharedMemoryError('memory config invalid')
    callers={}
    for item in raw['callers']:
        if not isinstance(item,Mapping) or set(item)!={'token_file','caller_id','project_ids','agent_id','grants'}: raise SharedMemoryError('memory caller declaration invalid')
        token_path=Path(item['token_file'])
        if not token_path.is_absolute() or not token_path.is_file() or token_path.is_symlink() or any(p.is_symlink() for p in token_path.parents):raise SharedMemoryError('memory token unsafe')
        token=token_path.read_text(encoding='utf-8').strip()
        grants=tuple(ScopeGrant(**grant) for grant in item['grants'])
        callers[token]=AuthenticatedCaller(item['caller_id'],grants,tuple(item['project_ids']),item['agent_id'])
    return SharedMemoryServiceConfig(Path(raw['database']),callers),(raw['listen_host'],raw['listen_port'])

def main(argv=None):
    parser=argparse.ArgumentParser(description='scoped durable shared memory authority');parser.add_argument('--config',required=True);parser.add_argument('--check',action='store_true');args=parser.parse_args(argv)
    config,address=load_config(args.config)
    if args.check: print('configuration validated; listener was not started');return 0
    serve(SharedMemoryStore(config),address).serve_forever();return 0
if __name__=='__main__':raise SystemExit(main())
