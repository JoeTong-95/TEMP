"""Authenticated loopback API owned by independent verification for review receipts."""
from __future__ import annotations

import hmac
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from typing import Any, Mapping

from .code_review_issuer import CodeReviewIssuer, CodeReviewIssuerError


class CodeReviewIssuerHttpServer(ThreadingHTTPServer):
    def __init__(self, address: tuple[str, int], issuer: CodeReviewIssuer, token_projects: Mapping[str, frozenset[str]]):
        if address[0] != "127.0.0.1" or not token_projects:
            raise CodeReviewIssuerError("review issuer must use loopback and explicit scopes")
        self.issuer, self.token_projects = issuer, dict(token_projects)
        super().__init__(address, make_handler(self))


def make_handler(server: CodeReviewIssuerHttpServer):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None: return
        def reply(self, status: HTTPStatus, value: Mapping[str, Any]) -> None:
            raw=json.dumps(dict(value), separators=(",", ":")).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
        def do_POST(self) -> None:
            if self.path != "/review-receipts": self.reply(404,{"error":"not_found"}); return
            try:
                length=int(self.headers.get("Content-Length","-1"))
                if not 0 <= length <= 16*1024: raise ValueError
                body=json.loads(self.rfile.read(length).decode())
                if not isinstance(body,Mapping) or set(body)!={"verification_operation_id","project_id","subject"}: raise ValueError
                token=self.headers.get("Authorization","")[7:] if self.headers.get("Authorization","").startswith("Bearer ") else ""
                project=body.get("project_id")
                if not isinstance(project,str) or not any(hmac.compare_digest(token,candidate) and project in projects for candidate,projects in server.token_projects.items()): self.reply(403,{"error":"not_permitted"}); return
                self.reply(200,server.issuer.issue(body["verification_operation_id"],project,body["subject"]))
            except (ValueError,UnicodeDecodeError,json.JSONDecodeError,CodeReviewIssuerError): self.reply(409,{"error":"invalid_review_request"})
    return Handler


def serve(issuer: CodeReviewIssuer, token_projects: Mapping[str, frozenset[str]], address: tuple[str,int] = ("127.0.0.1",0)) -> CodeReviewIssuerHttpServer:
    return CodeReviewIssuerHttpServer(address,issuer,token_projects)
