"""Storage layer: durable bundles, scoped memory, verification, and code authority."""
from __future__ import annotations

from pathlib import Path

from shared.contracts.pilot_artifact import PilotAudioArtifactStore, PilotThreeDArtifactStore, PilotVideoArtifactStore

__all__ = (
    "Config",
    "PilotAudioArtifactService",
    "PilotVideoArtifactService",
    "create_pilot_video_artifact_store",
    "create_pilot_audio_artifact_store",
    "PilotThreeDArtifactService",
    "create_pilot_3d_artifact_store",
    "load_configuration",
)


def create_pilot_video_artifact_store(path: str | Path) -> PilotVideoArtifactStore:
    """Build the Storage-owned implementation behind the shared video contract."""
    from .pilot_artifact_service import PilotVideoArtifactService

    return PilotVideoArtifactService(path)


def create_pilot_audio_artifact_store(path: str | Path, *, legacy_path: str | Path | None = None) -> PilotAudioArtifactStore:
    """Build the Storage-owned implementation behind the shared audio contract."""
    from .pilot_artifact_service import PilotAudioArtifactService

    return PilotAudioArtifactService(path, legacy_path=legacy_path)


def create_pilot_3d_artifact_store(path: str | Path) -> PilotThreeDArtifactStore:
    """Build the Storage-owned implementation behind the shared 3D contract."""
    from .pilot_artifact_service import PilotThreeDArtifactService

    return PilotThreeDArtifactService(path)


def __getattr__(name: str):
    if name not in __all__:
        raise AttributeError(name)
    if name == "PilotAudioArtifactService":
        from .pilot_artifact_service import PilotAudioArtifactService
        return PilotAudioArtifactService
    if name == "PilotVideoArtifactService":
        from .pilot_artifact_service import PilotVideoArtifactService
        return PilotVideoArtifactService
    if name == "PilotThreeDArtifactService":
        from .pilot_artifact_service import PilotThreeDArtifactService
        return PilotThreeDArtifactService
    from . import storage_runtime_bundle_service
    return getattr(storage_runtime_bundle_service, name)
