"""Immutable Storage adapter for a runtime-owned exported checkpoint directory."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from pathlib import Path
from typing import Any

SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
STORAGE_MANIFEST = "storage-manifest.json"
COMPLETE = "storage-complete.json"


class CheckpointError(ValueError): pass


def _digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _root(value: str | Path, create: bool = False) -> Path:
    path = Path(value).absolute()
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if current.exists() and current.is_symlink(): raise CheckpointError("symlinked root ancestor")
    if create: path.mkdir(parents=True, exist_ok=True)
    if not path.is_dir(): raise CheckpointError("safe directory required")
    return path


def _namespace(*values: str) -> None:
    if not all(isinstance(value, str) and SAFE.fullmatch(value) for value in values):
        raise CheckpointError("unsafe checkpoint namespace")


def _safe_child(root: Path, *parts: str, create: bool = False) -> Path:
    current = root
    for part in parts:
        current = current / part
        if current.exists() and current.is_symlink(): raise CheckpointError("symlinked checkpoint ancestor")
        if create and not current.exists(): current.mkdir(mode=0o700)
        if create and not current.is_dir(): raise CheckpointError("checkpoint ancestor is not a directory")
    return current


def _fsync_directory(directory: Path) -> None:
    try:
        fd = os.open(directory, os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    except PermissionError:
        if os.name != "nt": raise


def _native_export(source: Path) -> list[Path]:
    manifests = list(source.glob("*.manifest.json"))
    if len(manifests) != 1 or manifests[0].is_symlink(): raise CheckpointError("one native checkpoint manifest required")
    try: native = json.loads(manifests[0].read_text(encoding="utf-8"))
    except ValueError as error: raise CheckpointError("invalid native checkpoint manifest") from error
    if not isinstance(native, dict): raise CheckpointError("invalid native checkpoint manifest")
    database = native.get("database")
    if not isinstance(database, str) or Path(database).name != database or not re.fullmatch(r"[0-9a-f]{64}", str(native.get("sha256"))): raise CheckpointError("invalid native checkpoint manifest")
    db = source / database
    if not db.is_file() or db.is_symlink() or _digest(db) != native["sha256"]: raise CheckpointError("native checkpoint checksum")
    files = [manifests[0], db]
    if len({path.name for path in files}) != len(files) or any(path.name in {STORAGE_MANIFEST, COMPLETE} for path in files): raise CheckpointError("reserved storage name")
    return files


def _atomic_json(path: Path, value: Any) -> None:
    fd, pending = tempfile.mkstemp(dir=path.parent, prefix=".pending-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, sort_keys=True, separators=(",", ":")); handle.flush(); os.fsync(handle.fileno())
        os.replace(pending, path)
        _fsync_directory(path.parent)
    finally:
        if os.path.exists(pending): os.unlink(pending)


def publish(storage_root: str | Path, source_root: str | Path, project_id: str, agent_id: str, checkpoint_id: str) -> dict[str, Any]:
    _namespace(project_id, agent_id, checkpoint_id)
    storage, source = _root(storage_root, True), _root(source_root)
    files = _native_export(source)
    parent = _safe_child(storage, project_id, agent_id, create=True)
    final = _safe_child(parent, checkpoint_id)
    if final.exists():
        if final.is_symlink(): raise CheckpointError("unsafe existing bundle")
        return _verify_bundle(final, project_id, agent_id, checkpoint_id, files)
    stage = final.parent / ("." + checkpoint_id + ".pending")
    if stage.exists(): raise CheckpointError("pending bundle requires reconciliation")
    stage.mkdir(parents=True)
    try:
        entries=[]
        for source_file in files:
            before=_digest(source_file); target=stage/source_file.name; shutil.copyfile(source_file,target)
            with target.open("r+b") as handle: os.fsync(handle.fileno())
            if before != _digest(source_file) or before != _digest(target): raise CheckpointError("source changed during publish")
            entries.append({"path":source_file.name,"bytes":target.stat().st_size,"sha256":before})
        staged_native = _native_export(stage)
        if {(path.name, _digest(path)) for path in staged_native} != {(path.name, _digest(path)) for path in files}:
            raise CheckpointError("source changed during publish")
        manifest={"project_id":project_id,"agent_id":agent_id,"checkpoint_id":checkpoint_id,"files":entries}
        _atomic_json(stage/STORAGE_MANIFEST,manifest); _atomic_json(stage/COMPLETE,{"storage_manifest_sha256":_digest(stage/STORAGE_MANIFEST)})
        os.replace(stage,final)
        _fsync_directory(final.parent)
        return _verify_bundle(final,project_id,agent_id,checkpoint_id,files)
    except Exception:
        raise


def _verify_bundle(bundle: Path, project: str, agent: str, checkpoint: str, source_files: list[Path] | None = None) -> dict[str, Any]:
    if bundle.is_symlink() or not bundle.is_dir(): raise CheckpointError("unsafe bundle")
    manifest_path, complete_path=bundle/STORAGE_MANIFEST,bundle/COMPLETE
    if not manifest_path.is_file() or manifest_path.is_symlink() or not complete_path.is_file(): raise CheckpointError("incomplete bundle")
    try: manifest=json.loads(manifest_path.read_text(encoding="utf-8")); complete=json.loads(complete_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error: raise CheckpointError("bundle metadata") from error
    if not isinstance(manifest, dict) or not isinstance(complete, dict): raise CheckpointError("bundle metadata")
    if manifest.get("project_id") != project or manifest.get("agent_id") != agent or manifest.get("checkpoint_id") != checkpoint or complete_path.is_symlink() or complete.get("storage_manifest_sha256") != _digest(manifest_path): raise CheckpointError("bundle identity/checksum")
    if not isinstance(manifest.get("files"), list) or not manifest["files"]: raise CheckpointError("empty bundle")
    seen=set()
    for entry in manifest.get("files",[]):
        if not isinstance(entry,dict) or not isinstance(entry.get("path"),str) or Path(entry["path"]).name != entry["path"] or not isinstance(entry.get("bytes"),int) or entry["bytes"] < 0 or not isinstance(entry.get("sha256"),str) or not re.fullmatch(r"[0-9a-f]{64}",entry["sha256"]) or entry["path"] in seen: raise CheckpointError("bundle entry")
        seen.add(entry["path"]); path=bundle/entry["path"]
        if not path.is_file() or path.is_symlink() or path.stat().st_size != entry["bytes"] or _digest(path)!=entry["sha256"]: raise CheckpointError("bundle payload checksum")
    native_files = _native_export(bundle)
    if {path.name for path in native_files} != seen or len(seen) != 2: raise CheckpointError("bundle must contain exactly one native export")
    expected_names = {STORAGE_MANIFEST, COMPLETE, *(path.name for path in native_files)}
    if {path.name for path in bundle.iterdir()} != expected_names: raise CheckpointError("unexpected bundle file")
    if source_files and {(x.name,_digest(x)) for x in source_files} != {(x["path"],x["sha256"]) for x in manifest["files"]}: raise CheckpointError("existing bundle differs from source")
    return manifest


def materialize(storage_root: str | Path, project_id: str, agent_id: str, checkpoint_id: str, destination: str | Path) -> dict[str, Any]:
    _namespace(project_id,agent_id,checkpoint_id); root=_root(storage_root); destination=Path(destination).absolute()
    if destination.exists() or any(part.is_symlink() for part in [destination.parent, *destination.parents]): raise CheckpointError("fresh safe destination required")
    bundle=_safe_child(root,project_id,agent_id,checkpoint_id); manifest=_verify_bundle(bundle,project_id,agent_id,checkpoint_id)
    stage=destination.parent/("."+destination.name+".pending")
    if stage.exists(): raise CheckpointError("pending materialization")
    stage.mkdir()
    for entry in manifest["files"]:
        target=stage/entry["path"]; shutil.copyfile(bundle/entry["path"],target)
        with target.open("r+b") as handle: os.fsync(handle.fileno())
        if _digest(target) != entry["sha256"]: raise CheckpointError("materialization changed during copy")
    os.replace(stage,destination)
    _fsync_directory(destination.parent)
    return manifest
