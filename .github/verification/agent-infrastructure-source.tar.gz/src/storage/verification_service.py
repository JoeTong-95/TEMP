"""Authenticated loopback boundary for isolated, server-defined verification."""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import hashlib
import hmac
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import sqlite3
import threading
import time
import math
from uuid import uuid4
from contextlib import contextmanager
from typing import Any, Callable, Mapping

from .project_verification_runner import ProjectVerificationRunner, VerificationResult, input_tree_digest
from shared.contracts.project_verification import MAX_VERIFICATION_ENVELOPE_BYTES, MAX_VERIFICATION_OUTPUT_BYTES


MAX_BODY = 64 * 1024
_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")


class VerificationServiceError(ValueError): pass


def _private_file(path: Path, label: str) -> Path:
    if not path.is_absolute() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents) or not path.is_file():
        raise VerificationServiceError(f"{label} is unsafe")
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise VerificationServiceError(f"{label} must not be group or world readable")
    return path.resolve(strict=True)


@dataclass(frozen=True)
class VerificationResources:
    timeout_seconds: int = 60
    max_output_bytes: int = MAX_VERIFICATION_OUTPUT_BYTES
    memory_max_bytes: int = 128 * 1024 * 1024
    tasks_max: int = 64
    cpu_quota_percent: int = 50
    max_input_bytes: int = 64 * 1024 * 1024
    max_input_files: int = 10_000
    max_input_file_bytes: int = 16 * 1024 * 1024


@dataclass(frozen=True)
class VerificationServiceConfiguration:
    workspace_root: Path
    receipt_database: Path
    sandbox_parent: Path
    project_workspaces: Mapping[str, Mapping[str, str]]
    command_resources: Mapping[str, VerificationResources]
    bearer_project_scopes: Mapping[str, frozenset[str]] = field(repr=False)


def _safe_dir(path: Path, label: str) -> None:
    if not path.is_absolute() or path.is_symlink() or not path.is_dir() or any(parent.is_symlink() for parent in path.parents):
        raise VerificationServiceError(f"{label} must be an existing absolute non-symlink directory")


def _bounded_output(value: Any, *, truncate: bool = False) -> str:
    if not isinstance(value, str):
        raise VerificationServiceError("verification diagnostics are malformed")
    encoded=value.encode("utf-8")
    if len(encoded) <= MAX_VERIFICATION_OUTPUT_BYTES:
        return value
    if not truncate:
        raise VerificationServiceError("verification diagnostics exceed bounds")
    return encoded[:MAX_VERIFICATION_OUTPUT_BYTES].decode("utf-8", "ignore")


class VerificationService:
    def __init__(self, configuration: VerificationServiceConfiguration, *, runner_factory: Callable[..., ProjectVerificationRunner] = ProjectVerificationRunner) -> None:
        if not isinstance(configuration.project_workspaces,Mapping) or not isinstance(configuration.command_resources,Mapping) or not isinstance(configuration.bearer_project_scopes,Mapping): raise VerificationServiceError("configuration allowlists are invalid")
        self.config = VerificationServiceConfiguration(configuration.workspace_root, configuration.receipt_database, configuration.sandbox_parent, {p: dict(w) if isinstance(w,Mapping) else w for p, w in configuration.project_workspaces.items()}, dict(configuration.command_resources), {t: frozenset(p) if isinstance(p,(frozenset,set,list,tuple)) else p for t, p in configuration.bearer_project_scopes.items()})
        _safe_dir(self.config.workspace_root, "workspace root"); _safe_dir(self.config.sandbox_parent, "sandbox parent")
        if not self.config.receipt_database.is_absolute() or self.config.receipt_database.is_symlink() or not self.config.receipt_database.parent.is_dir() or any(parent.is_symlink() for parent in self.config.receipt_database.parents): raise VerificationServiceError("receipt database is unsafe")
        if not self.config.command_resources or any(not isinstance(key, str) or not _SAFE.fullmatch(key) or not isinstance(value, VerificationResources) or type(value.timeout_seconds) is not int or not 1 <= value.timeout_seconds <= 300 or type(value.max_output_bytes) is not int or not 1 <= value.max_output_bytes <= MAX_VERIFICATION_OUTPUT_BYTES or type(value.memory_max_bytes) is not int or not 16 * 1024 * 1024 <= value.memory_max_bytes <= 1024 * 1024 * 1024 or type(value.tasks_max) is not int or not 1 <= value.tasks_max <= 256 or type(value.cpu_quota_percent) is not int or not 1 <= value.cpu_quota_percent <= 100 or any(type(limit) is not int or limit < 1 for limit in (value.max_input_bytes,value.max_input_files,value.max_input_file_bytes)) for key, value in self.config.command_resources.items()): raise VerificationServiceError("configured commands are invalid")
        if not isinstance(self.config.project_workspaces, Mapping): raise VerificationServiceError("configured workspaces are invalid")
        for project, workspaces in self.config.project_workspaces.items():
            if not isinstance(project, str) or not _SAFE.fullmatch(project) or not isinstance(workspaces, Mapping) or not workspaces: raise VerificationServiceError("configured workspaces are invalid")
            for workspace_id, relative in workspaces.items():
                path = self.config.workspace_root / relative
                if not isinstance(workspace_id, str) or not _SAFE.fullmatch(workspace_id) or not isinstance(relative, str) or Path(relative).is_absolute() or ".." in Path(relative).parts or path.is_symlink() or not path.is_dir() or self.config.workspace_root.resolve() not in path.resolve().parents or path.resolve() == self.config.sandbox_parent.resolve() or path.resolve() in self.config.sandbox_parent.resolve().parents or self.config.sandbox_parent.resolve() in path.resolve().parents: raise VerificationServiceError("configured workspaces are invalid")
        if not isinstance(self.config.bearer_project_scopes, Mapping) or any(not isinstance(token, str) or not token or not isinstance(projects, frozenset) or not projects or any(not isinstance(project,str) or not _SAFE.fullmatch(project) for project in projects) for token, projects in self.config.bearer_project_scopes.items()): raise VerificationServiceError("project token scopes are invalid")
        self._runner_factory = runner_factory
        self._worker_slots = threading.BoundedSemaphore(1)
        with self._connection() as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS verification_operations(operation_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,workspace_id TEXT NOT NULL,command_id TEXT NOT NULL,input_sha256 TEXT NOT NULL,state TEXT NOT NULL,result TEXT,owner_token TEXT,lease_until REAL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
            columns={row["name"] for row in connection.execute("PRAGMA table_info(verification_operations)")}
            if "owner_token" not in columns: connection.execute("ALTER TABLE verification_operations ADD COLUMN owner_token TEXT")
            if "lease_until" not in columns: connection.execute("ALTER TABLE verification_operations ADD COLUMN lease_until REAL")

    @contextmanager
    def _connection(self):
        connection = sqlite3.connect(self.config.receipt_database); connection.row_factory = sqlite3.Row
        try:
            with connection: yield connection
        finally: connection.close()

    def _workspace(self, project_id: str, workspace_id: str) -> Path:
        relative = self.config.project_workspaces.get(project_id, {}).get(workspace_id)
        if relative is None: raise VerificationServiceError("project workspace is not configured")
        return self.config.workspace_root / relative

    def _receipt(self, row: sqlite3.Row) -> dict[str, Any]:
        try: result = json.loads(row["result"]) if row["result"] else None
        except (TypeError,ValueError) as error: raise VerificationServiceError("operation receipt is malformed") from error
        if result is not None and not isinstance(result,Mapping): raise VerificationServiceError("operation receipt is malformed")
        if result is not None and "output" in result: _bounded_output(result["output"])
        receipt={"operation_id":row["operation_id"],"project_id":row["project_id"],"workspace_id":row["workspace_id"],"command_id":row["command_id"],"expected_input_tree_sha256":row["input_sha256"],"state":row["state"],"result":result}
        if len(json.dumps(receipt,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode("utf-8")) > MAX_VERIFICATION_ENVELOPE_BYTES: raise VerificationServiceError("verification receipt exceeds bounds")
        return receipt

    def operation(self, operation_id: str, project_id: str) -> dict[str, Any]:
        with self._connection() as connection: row = connection.execute("SELECT * FROM verification_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None or row["project_id"] != project_id: raise VerificationServiceError("operation not found")
        return self._receipt(row)

    def verify(self, operation_id: str, project_id: str, workspace_id: str, command_id: str, expected_input_tree_sha256: str, *, asynchronous: bool = False) -> dict[str, Any]:
        if not all(isinstance(value, str) and _SAFE.fullmatch(value) for value in (operation_id, project_id, workspace_id, command_id)) or not isinstance(expected_input_tree_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_input_tree_sha256): raise VerificationServiceError("verification request is invalid")
        workspace = self._workspace(project_id, workspace_id); resources = self.config.command_resources.get(command_id)
        if resources is None: raise VerificationServiceError("verification command is not configured")
        owner=uuid4().hex; claimed=False; now=time.time(); lease=now+resources.timeout_seconds+45
        try:
            with self._connection() as connection:
                connection.execute("BEGIN IMMEDIATE"); existing = connection.execute("SELECT * FROM verification_operations WHERE operation_id=?", (operation_id,)).fetchone()
                if existing is not None:
                    receipt = self._receipt(existing)
                    if (receipt["project_id"],receipt["workspace_id"],receipt["command_id"],receipt["expected_input_tree_sha256"]) != (project_id,workspace_id,command_id,expected_input_tree_sha256): raise VerificationServiceError("operation_id reuse conflicts")
                    if receipt["state"] == "unknown":
                        changed=connection.execute("UPDATE verification_operations SET state='accepted',result=NULL,owner_token=?,lease_until=?,updated_at=CURRENT_TIMESTAMP WHERE operation_id=? AND state='unknown'",(owner,lease,operation_id)).rowcount
                        if changed != 1: return self._receipt(connection.execute("SELECT * FROM verification_operations WHERE operation_id=?",(operation_id,)).fetchone())
                        claimed=True
                    elif receipt["state"] in {"accepted","running"} and existing["lease_until"] is not None and existing["lease_until"] <= now:
                        connection.execute("UPDATE verification_operations SET state='unknown',result=NULL,owner_token=NULL,lease_until=NULL,updated_at=CURRENT_TIMESTAMP WHERE operation_id=? AND state IN ('accepted','running') AND lease_until<=?",(operation_id,now))
                        existing=connection.execute("SELECT * FROM verification_operations WHERE operation_id=?",(operation_id,)).fetchone(); return self._receipt(existing)
                    else:
                        return receipt
                if existing is None:
                    connection.execute("INSERT INTO verification_operations(operation_id,project_id,workspace_id,command_id,input_sha256,state,owner_token,lease_until) VALUES(?,?,?,?,?,'accepted',?,?)", (operation_id,project_id,workspace_id,command_id,expected_input_tree_sha256,owner,lease)); claimed=True
            if asynchronous:
                if not self._worker_slots.acquire(blocking=False): return self._finish(operation_id,owner,"failed",{"error":"verification_backpressure"})
                threading.Thread(target=self._background_execute,args=(operation_id,project_id,workspace_id,command_id,expected_input_tree_sha256,owner,resources),daemon=True).start()
                return self.operation(operation_id,project_id)
            return self._execute(operation_id,project_id,workspace_id,command_id,expected_input_tree_sha256,owner,resources)
        except Exception as error:
            if claimed: self._set_state(operation_id, owner, "unknown")
            raise VerificationServiceError("verification outcome is unknown") from error

    def _background_execute(self, operation_id: str, project_id: str, workspace_id: str, command_id: str, expected: str, owner: str, resources: VerificationResources) -> None:
        try: self._execute(operation_id,project_id,workspace_id,command_id,expected,owner,resources)
        except VerificationServiceError: pass
        finally: self._worker_slots.release()

    def _execute(self, operation_id: str, project_id: str, workspace_id: str, command_id: str, expected_input_tree_sha256: str, owner: str, resources: VerificationResources) -> dict[str, Any]:
        workspace=self._workspace(project_id,workspace_id)
        try:
            actual = input_tree_digest(workspace, max_input_bytes=resources.max_input_bytes, max_input_files=resources.max_input_files, max_input_file_bytes=resources.max_input_file_bytes)
            if actual != expected_input_tree_sha256:
                return self._finish(operation_id, owner, "failed", {"error":"input_tree_changed","input_tree_sha256":actual})
            if not self._set_state(operation_id, owner, "running"): return self.operation(operation_id,project_id)
            runner = self._runner_factory(workspace, self.config.sandbox_parent, timeout_seconds=resources.timeout_seconds, max_output_bytes=resources.max_output_bytes, memory_max_bytes=resources.memory_max_bytes, tasks_max=resources.tasks_max, cpu_quota_percent=resources.cpu_quota_percent, max_input_bytes=resources.max_input_bytes, max_input_files=resources.max_input_files, max_input_file_bytes=resources.max_input_file_bytes)
            outcome = runner.verify(command_id)
            if outcome.input_tree_sha256 != expected_input_tree_sha256: return self._finish(operation_id, owner, "failed", {"error":"input_tree_changed","input_tree_sha256":outcome.input_tree_sha256})
            return self._finish(operation_id, owner, "completed" if outcome.result == "passed" else "failed", {"exit_code":outcome.exit_code,"result":outcome.result,"input_tree_sha256":outcome.input_tree_sha256,"output_sha256":outcome.output_sha256,"output":outcome.output})
        except Exception as error:
            self._set_state(operation_id, owner, "unknown")
            raise VerificationServiceError("verification outcome is unknown") from error

    def _set_state(self, operation_id: str, owner: str, state: str) -> bool:
        with self._connection() as connection: return connection.execute("UPDATE verification_operations SET state=?,updated_at=CURRENT_TIMESTAMP WHERE operation_id=? AND owner_token=? AND state IN ('accepted','running')", (state, operation_id, owner)).rowcount == 1

    def _finish(self, operation_id: str, owner: str, state: str, result: Mapping[str, Any]) -> dict[str, Any]:
        result=dict(result)
        if "output" in result: result["output"]=_bounded_output(result["output"],truncate=True)
        raw=json.dumps(result,sort_keys=True,separators=(",",":"),allow_nan=False,ensure_ascii=True)
        receipt={"operation_id":operation_id,"project_id":None,"workspace_id":None,"command_id":None,"expected_input_tree_sha256":None,"state":state,"result":result}
        with self._connection() as connection:
            row=connection.execute("SELECT * FROM verification_operations WHERE operation_id=?",(operation_id,)).fetchone()
            if row is None: raise VerificationServiceError("verification operation disappeared")
            receipt.update(project_id=row["project_id"],workspace_id=row["workspace_id"],command_id=row["command_id"],expected_input_tree_sha256=row["input_sha256"])
            if len(json.dumps(receipt,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode("utf-8")) > MAX_VERIFICATION_ENVELOPE_BYTES: raise VerificationServiceError("verification receipt exceeds bounds")
            changed=connection.execute("UPDATE verification_operations SET state=?,result=?,owner_token=NULL,lease_until=NULL,updated_at=CURRENT_TIMESTAMP WHERE operation_id=? AND owner_token=? AND state IN ('accepted','running')", (state,raw,operation_id,owner)).rowcount; row=connection.execute("SELECT * FROM verification_operations WHERE operation_id=?",(operation_id,)).fetchone()
        if changed != 1: raise VerificationServiceError("verification ownership was lost")
        return self._receipt(row)

    def authorize(self, authorization: str | None, project_id: str) -> bool:
        if not isinstance(project_id,str): return False
        token = authorization[7:] if authorization and authorization.startswith("Bearer ") else ""
        return any(hmac.compare_digest(token, candidate) and project_id in projects for candidate, projects in self.config.bearer_project_scopes.items())


def make_handler(service: VerificationService):
    class Handler(BaseHTTPRequestHandler):
        def setup(self) -> None:
            super().setup(); self.connection.settimeout(5)
        def log_message(self, format: str, *args: Any) -> None: return
        def reply(self, status: int, value: Mapping[str, Any]) -> None:
            raw=json.dumps(value,separators=(",",":"),allow_nan=False).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
        def do_POST(self) -> None:
            if self.path != "/operations": self.reply(404,{"error":"not_found"}); return
            try:
                length=int(self.headers.get("Content-Length","-1"));
                if not 0 <= length <= MAX_BODY: raise VerificationServiceError("request too large")
                body=json.loads(self.rfile.read(length)); required={"operation_id","project_id","workspace_id","command_id","expected_input_tree_sha256"}
                if not isinstance(body,Mapping) or set(body)!=required or not service.authorize(self.headers.get("Authorization"),body.get("project_id")): self.reply(401,{"error":"unauthorized"}); return
                receipt=service.verify(**body,asynchronous=True); self.reply(HTTPStatus.ACCEPTED if receipt["state"] in {"accepted","running"} else HTTPStatus.OK,receipt)
            except (VerificationServiceError,ValueError,UnicodeError): self.reply(409,{"error":"invalid_operation"})
        def do_GET(self) -> None:
            parts=self.path.strip("/").split("/")
            if len(parts)!=2 or parts[0]!="operations": self.reply(404,{"error":"not_found"}); return
            project=self.headers.get("X-Project-Id","")
            if not service.authorize(self.headers.get("Authorization"),project): self.reply(401,{"error":"unauthorized"}); return
            try:self.reply(200,service.operation(parts[1],project))
            except VerificationServiceError:self.reply(404,{"error":"not_found"})
    return Handler


def serve(service: VerificationService, address: tuple[str,int] = ("127.0.0.1",0)) -> ThreadingHTTPServer: return ThreadingHTTPServer(address,make_handler(service))


def load_configuration(path: str | Path) -> VerificationServiceConfiguration:
    config_path=Path(path)
    try: config_path=_private_file(config_path,"configuration file")
    except VerificationServiceError as error: raise VerificationServiceError("configuration is unavailable") from error
    try: raw=json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError,ValueError) as error: raise VerificationServiceError("configuration is invalid") from error
    required={"workspace_root","receipt_database","sandbox_parent","project_workspaces","command_resources","bearer_project_scopes_file"}
    if not isinstance(raw,Mapping) or set(raw)!=required or any(not isinstance(raw[key],str) or not raw[key] for key in ("workspace_root","receipt_database","sandbox_parent","bearer_project_scopes_file")): raise VerificationServiceError("configuration fields are invalid")
    try: scopes_path=_private_file(Path(raw["bearer_project_scopes_file"]),"project scopes file"); scopes=json.loads(scopes_path.read_text(encoding="utf-8"))
    except (OSError,ValueError) as error: raise VerificationServiceError("project token file is unavailable") from error
    if not isinstance(scopes,list) or not scopes: raise VerificationServiceError("project token scopes are invalid")
    tokens={}
    for scope in scopes:
        if not isinstance(scope,Mapping) or set(scope)!={"token_file","projects"} or not isinstance(scope["token_file"],str) or not isinstance(scope["projects"],list) or not scope["projects"] or any(not isinstance(project,str) or not _SAFE.fullmatch(project) for project in scope["projects"]): raise VerificationServiceError("project token scopes are invalid")
        try: token=_private_file(Path(scope["token_file"]),"project token file").read_text(encoding="utf-8").strip()
        except (OSError,UnicodeDecodeError) as error: raise VerificationServiceError("project token file is unavailable") from error
        if not token or not token.isascii() or len(token)>4096 or any(character.isspace() for character in token) or token in tokens: raise VerificationServiceError("project token scopes are invalid")
        tokens[token]=scope["projects"]
    if not isinstance(raw["project_workspaces"],Mapping) or not isinstance(raw["command_resources"],Mapping): raise VerificationServiceError("configuration allowlists are invalid")
    resources={}
    for command,item in raw["command_resources"].items():
        if not isinstance(item,Mapping) or set(item)-set(VerificationResources.__dataclass_fields__): raise VerificationServiceError("command resources are invalid")
        try: resources[command]=VerificationResources(**item)
        except (TypeError,ValueError) as error: raise VerificationServiceError("command resources are invalid") from error
    return VerificationServiceConfiguration(Path(raw["workspace_root"]),Path(raw["receipt_database"]),Path(raw["sandbox_parent"]),{project:dict(workspaces) for project,workspaces in raw["project_workspaces"].items()},{command:value for command,value in resources.items()},{token:frozenset(projects) for token,projects in tokens.items()})


def main(argv: list[str] | None = None) -> int:
    parser=argparse.ArgumentParser(description="Serve isolated project verification on loopback")
    parser.add_argument("--config",required=True); parser.add_argument("--host",default="127.0.0.1"); parser.add_argument("--port",type=int,default=18121); parser.add_argument("--check",action="store_true",help="validate configuration without opening a listener")
    args=parser.parse_args(argv)
    if args.host!="127.0.0.1" or not 1<=args.port<=65535: raise SystemExit("loopback host and valid port required")
    service=VerificationService(load_configuration(args.config))
    if args.check:
        print("configuration validated; listener was not started")
        return 0
    server=serve(service,(args.host,args.port))
    try: server.serve_forever()
    finally: server.server_close()
    return 0


if __name__=="__main__": raise SystemExit(main())
