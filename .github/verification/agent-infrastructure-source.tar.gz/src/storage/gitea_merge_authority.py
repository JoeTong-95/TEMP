"""Receipt-gated Storage-side Gitea merge authority.

Gitea branch-statuses are deliberately *not* an approval input: a contributor
can create a convincing status.  This module only merges a specific PR head
after an independent durable receipt binds project, command, reviewer and head.
It journals ``prepared`` before the irreversible API call, so response loss
never causes a blind retry.
"""
from __future__ import annotations

from contextlib import closing
from dataclasses import dataclass
import hashlib
import hmac
import json
import os
from pathlib import Path
import sqlite3
from typing import Any, Callable, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

from shared.contracts.forge import normalize_forge_provider


class MergeAuthorityError(ValueError):
    """Caller/configuration error; no merge effect was requested."""


class ForgeDefinitiveRejection(MergeAuthorityError):
    """A received 4xx response conclusively rejected the requested action."""


class ForgeTransportUnknown(RuntimeError):
    """A forge effect may have happened and must be reconciled, not retried."""


# Compatibility names retained for the old Gitea-only import surface.  The
# authority below catches the provider-neutral base classes, so adapters can
# be added without teaching the journal about a provider's API vocabulary.
class GiteaDefinitiveRejection(ForgeDefinitiveRejection):
    """Deprecated provider-specific alias for compatibility callers."""


class GiteaTransportUnknown(ForgeTransportUnknown):
    """Deprecated provider-specific alias for compatibility callers."""


_MAX_RESPONSE_BYTES = 1_000_000


def _safe_existing_path(path: Path, label: str, *, file: bool | None = None) -> None:
    if not path.is_absolute() or path.is_symlink() or any(item.is_symlink() for item in path.parents):
        raise MergeAuthorityError(f"{label} path is unsafe")
    if file is True and not path.is_file():
        raise MergeAuthorityError(f"{label} file is missing")
    if file is False and not path.is_dir():
        raise MergeAuthorityError(f"{label} directory is missing")


def _private_file(path: Path, label: str) -> None:
    _safe_existing_path(path, label, file=True)
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise MergeAuthorityError(f"{label} must not be group/world accessible")


def _token(path: Path) -> str:
    _private_file(path, "merge token")
    value = path.read_text(encoding="utf-8").strip()
    if not value or not value.isascii() or any(char.isspace() for char in value):
        raise MergeAuthorityError("merge token is invalid")
    return value


def _identifier(value: object, label: str) -> None:
    if not isinstance(value, str) or not value or len(value) > 128 or any(char.isspace() for char in value):
        raise MergeAuthorityError(f"{label} is invalid")


def _sha(value: object) -> bool:
    return isinstance(value, str) and len(value) == 40 and all(char in "0123456789abcdef" for char in value)


@dataclass(frozen=True)
class RepoBinding:
    owner: str
    repository: str
    base: str
    project_id: str
    command_id: str
    evaluator_revision: str
    forge_provider: str = "github"
    repository_url: str | None = None

    def __post_init__(self) -> None:
        for label, value in (
            ("repository owner", self.owner), ("repository name", self.repository),
            ("base branch", self.base), ("project id", self.project_id),
            ("review command id", self.command_id), ("evaluator revision", self.evaluator_revision),
        ):
            _identifier(value, label)
        try:
            object.__setattr__(self, "forge_provider", normalize_forge_provider(self.forge_provider))
        except ValueError as error:
            raise MergeAuthorityError(str(error)) from error
        if self.repository_url is not None and (not isinstance(self.repository_url, str) or not self.repository_url):
            raise MergeAuthorityError("repository URL is invalid")

    @property
    def canonical_url(self) -> str:
        if self.repository_url:
            return self.repository_url
        origin = "https://github.com" if self.forge_provider == "github" else "https://gitea.local"
        return f"{origin}/{quote(self.owner, safe='')}/{quote(self.repository, safe='')}.git"


@dataclass(frozen=True)
class MergeAuthorityConfig:
    database: Path
    merge_token_file: Path
    merge_principal: str
    repositories: Mapping[str, RepoBinding]

    def __post_init__(self) -> None:
        _safe_existing_path(self.database.parent, "merge authority database parent", file=False)
        if self.database.is_symlink() or any(item.is_symlink() for item in self.database.parents):
            raise MergeAuthorityError("merge authority database path is unsafe")
        _token(self.merge_token_file)
        _identifier(self.merge_principal, "merge principal")
        if not self.repositories:
            raise MergeAuthorityError("at least one repository binding is required")
        for alias, binding in self.repositories.items():
            _identifier(alias, "repository alias")
            if not isinstance(binding, RepoBinding):
                raise MergeAuthorityError("repository binding is invalid")


class ForgeTransport:
    """Small injected forge boundary used by receipt-gated merge authority.

    The payloads deliberately use the normalized pull-request shape exposed by
    GitHub and Gitea.  Provider-specific paths, auth headers, and merge request
    bodies belong in the adapter implementations, never in ``MergeAuthority``.
    """

    def get_pull(self, binding: RepoBinding, number: int, token: str) -> Mapping[str, Any]:
        raise NotImplementedError

    def merge(self, binding: RepoBinding, number: int, head_sha: str, token: str) -> Mapping[str, Any]:
        raise NotImplementedError


class ForgeTransportRegistry(ForgeTransport):
    """Dispatch one operation to the adapter named by its project binding."""

    def __init__(self, adapters: Mapping[str, ForgeTransport]) -> None:
        if not adapters or any(not isinstance(name, str) or not hasattr(adapter, "get_pull") or not hasattr(adapter, "merge") for name, adapter in adapters.items()):
            raise MergeAuthorityError("forge adapter registry is invalid")
        self.adapters = dict(adapters)

    def _adapter(self, binding: RepoBinding) -> ForgeTransport:
        try:
            return self.adapters[binding.forge_provider]
        except KeyError as error:
            raise MergeAuthorityError("forge provider is not configured") from error

    def get_pull(self, binding: RepoBinding, number: int, token: str) -> Mapping[str, Any]:
        return self._adapter(binding).get_pull(binding, number, token)

    def merge(self, binding: RepoBinding, number: int, head_sha: str, token: str) -> Mapping[str, Any]:
        return self._adapter(binding).merge(binding, number, head_sha, token)


class GiteaTransport(ForgeTransport):
    """Deprecated compatibility name for the provider-neutral boundary."""


class _RejectRedirect(HTTPRedirectHandler):
    def redirect_request(self, request: Request, fp: Any, code: int, message: str, headers: Any, newurl: str) -> None:
            raise ForgeTransportUnknown("forge returned a redirect; effect is not trusted")


class HttpGiteaTransport(GiteaTransport):
    """Bounded direct HTTP(S) Gitea transport with proxies and redirects disabled."""

    def __init__(self, origin: str, *, timeout_seconds: float = 10.0) -> None:
        parsed = urlsplit(origin)
        loopback = parsed.hostname in {"127.0.0.1", "::1", "localhost"}
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise MergeAuthorityError("Gitea origin must be a plain HTTP(S) origin")
        if parsed.scheme != "https" and not loopback:
            raise MergeAuthorityError("non-loopback Gitea origin must use HTTPS")
        if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
            raise MergeAuthorityError("Gitea origin must not include a path, query, or fragment")
        if not isinstance(timeout_seconds, (int, float)) or not 0 < timeout_seconds <= 60:
            raise MergeAuthorityError("Gitea timeout is invalid")
        self.origin = origin.rstrip("/")
        self.timeout_seconds = float(timeout_seconds)
        self._opener = build_opener(ProxyHandler({}), _RejectRedirect())

    def _request(self, method: str, path: str, token: str, body: Mapping[str, Any] | None = None) -> Mapping[str, Any]:
        data = None if body is None else json.dumps(dict(body), separators=(",", ":")).encode("utf-8")
        request = Request(self.origin + path, data=data, method=method, headers={
            "Accept": "application/json", "Authorization": f"token {token}",
            **({"Content-Type": "application/json"} if data is not None else {}),
        })
        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                if response.status < 200 or response.status >= 300:
                    raise ForgeTransportUnknown(f"unexpected Gitea status {response.status}")
                raw = response.read(_MAX_RESPONSE_BYTES + 1)
        except HTTPError as error:
            if error.code == 405 and path.endswith("/merge"):
                raise GiteaTransportUnknown("Gitea merge policy has not settled") from error
            if 400 <= error.code < 500:
                raise GiteaDefinitiveRejection(f"Gitea rejected request with HTTP {error.code}") from error
            raise GiteaTransportUnknown(f"Gitea returned HTTP {error.code}") from error
        except ForgeTransportUnknown as error:
            # Preserve the legacy exception identity for Gitea callers while
            # keeping the authority's catch boundary provider-neutral.
            if isinstance(error, GiteaTransportUnknown):
                raise
            raise GiteaTransportUnknown(str(error)) from error
        except (URLError, OSError, TimeoutError) as error:
            raise GiteaTransportUnknown("Gitea transport outcome is unknown") from error
        if len(raw) > _MAX_RESPONSE_BYTES:
            raise GiteaTransportUnknown("Gitea response exceeded the safe bound")
        try:
            decoded = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise GiteaTransportUnknown("Gitea returned invalid JSON") from error
        if not isinstance(decoded, Mapping):
            raise GiteaTransportUnknown("Gitea returned a non-object response")
        return decoded

    @staticmethod
    def _pull_path(binding: RepoBinding, number: int) -> str:
        return "/api/v1/repos/{}/{}/pulls/{}".format(quote(binding.owner, safe=""), quote(binding.repository, safe=""), number)

    def get_pull(self, binding: RepoBinding, number: int, token: str) -> Mapping[str, Any]:
        return self._request("GET", self._pull_path(binding, number), token)

    def merge(self, binding: RepoBinding, number: int, head_sha: str, token: str) -> Mapping[str, Any]:
        # ``sha`` is the provider's conditional expected-head guard.  The
        # authority never permits an unbound "merge whatever is current"
        # operation, even for legacy Gitea deployments.
        # Gitea names this field ``head_commit_id`` (GitHub calls it ``sha``).
        # Keep that vocabulary inside the adapter so the authority's expected
        # head remains pinned for both providers.
        return self._request("POST", self._pull_path(binding, number) + "/merge", token, {"Do": "merge", "head_commit_id": head_sha})


class HttpGitHubTransport(ForgeTransport):
    """Bounded GitHub REST adapter.

    ``origin`` is the API origin (normally ``https://api.github.com``), while
    the project binding remains the project's explicit Git clone URL.  A
    caller supplies the scoped token at operation time; no credential is kept
    in this adapter or in a repository binding.
    """

    def __init__(self, origin: str = "https://api.github.com", *, timeout_seconds: float = 10.0) -> None:
        parsed = urlsplit(origin)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise MergeAuthorityError("GitHub origin must be a plain HTTPS origin")
        if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
            raise MergeAuthorityError("GitHub origin must not include a path, query, or fragment")
        if not isinstance(timeout_seconds, (int, float)) or isinstance(timeout_seconds, bool) or not 0 < timeout_seconds <= 60:
            raise MergeAuthorityError("GitHub timeout is invalid")
        self.origin = origin.rstrip("/")
        self.timeout_seconds = float(timeout_seconds)
        self._opener = build_opener(ProxyHandler({}), _RejectRedirect())

    @staticmethod
    def _pull_path(binding: RepoBinding, number: int) -> str:
        return "/repos/{}/{}/pulls/{}".format(quote(binding.owner, safe=""), quote(binding.repository, safe=""), number)

    def _request(self, method: str, path: str, token: str, body: Mapping[str, Any] | None = None) -> Mapping[str, Any]:
        if not isinstance(token, str) or not token or any(char.isspace() for char in token):
            raise MergeAuthorityError("GitHub token is invalid")
        data = None if body is None else json.dumps(dict(body), separators=(",", ":")).encode("utf-8")
        request = Request(self.origin + path, data=data, method=method, headers={
            "Accept": "application/vnd.github+json", "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            **({"Content-Type": "application/json"} if data is not None else {}),
        })
        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                raw = response.read(_MAX_RESPONSE_BYTES + 1)
        except HTTPError as error:
            if 400 <= error.code < 500:
                raise ForgeDefinitiveRejection(f"GitHub rejected request with HTTP {error.code}") from error
            raise ForgeTransportUnknown(f"GitHub returned HTTP {error.code}") from error
        except ForgeTransportUnknown:
            raise
        except (URLError, OSError, TimeoutError) as error:
            raise ForgeTransportUnknown("GitHub transport outcome is unknown") from error
        if len(raw) > _MAX_RESPONSE_BYTES:
            raise ForgeTransportUnknown("GitHub response exceeded the safe bound")
        try:
            decoded = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ForgeTransportUnknown("GitHub returned invalid JSON") from error
        if not isinstance(decoded, Mapping):
            raise ForgeTransportUnknown("GitHub returned a non-object response")
        return decoded

    def get_pull(self, binding: RepoBinding, number: int, token: str) -> Mapping[str, Any]:
        return self._request("GET", self._pull_path(binding, number), token)

    def merge(self, binding: RepoBinding, number: int, head_sha: str, token: str) -> Mapping[str, Any]:
        return self._request("PUT", self._pull_path(binding, number) + "/merge", token, {"sha": head_sha, "merge_method": "merge"})


def build_forge_transport(provider: str = "github", origin: str | None = None, *, timeout_seconds: float = 10.0) -> ForgeTransport:
    """Construct one provider adapter at the composition boundary.

    Management and merge authority call this once during composition; they do
    not branch on provider-specific API paths or authentication schemes.  The
    origin is intentionally an endpoint setting, not a repository binding or
    credential.  GitHub is the default and Gitea must be selected explicitly.
    """
    selected = normalize_forge_provider(provider)
    if selected == "github":
        return HttpGitHubTransport(origin or "https://api.github.com", timeout_seconds=timeout_seconds)
    if not origin:
        raise MergeAuthorityError("Gitea origin is required for the optional Gitea adapter")
    return HttpGiteaTransport(origin, timeout_seconds=timeout_seconds)


class MergeAuthority:
    def __init__(self, config: MergeAuthorityConfig, forge: ForgeTransport, receipts: Callable[[str], Mapping[str, Any]]):
        if not isinstance(forge, ForgeTransport) and not (hasattr(forge, "get_pull") and hasattr(forge, "merge")):
            raise MergeAuthorityError("forge transport is invalid")
        self.config, self.forge, self.receipts = config, forge, receipts
        # Keep the old attribute for callers that only inspected the injected
        # fake; all authority behavior uses the provider-neutral name above.
        self.gitea = forge
        self.token = _token(config.merge_token_file)
        with closing(sqlite3.connect(config.database)) as database:
            database.execute("CREATE TABLE IF NOT EXISTS merge_operations("
                "operation_id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, state TEXT NOT NULL, "
                "request TEXT NOT NULL, outcome TEXT NOT NULL)")
            database.commit()

    @staticmethod
    def _request_schema(request: Mapping[str, Any]) -> None:
        required = {"operation_id", "repo_alias", "pull_number", "head_sha", "verification_operation_id"}
        if not isinstance(request, Mapping) or set(request) != required:
            raise MergeAuthorityError("merge request schema is invalid")
        for key in ("operation_id", "repo_alias", "verification_operation_id"):
            _identifier(request.get(key), key)
        if type(request["pull_number"]) is not int or request["pull_number"] < 1 or not _sha(request["head_sha"]):
            raise MergeAuthorityError("merge request schema is invalid")

    @staticmethod
    def _fingerprint(request: Mapping[str, Any], binding: RepoBinding) -> str:
        # Include immutable target identity in addition to the caller envelope;
        # a reused operation id cannot be redirected to another provider/repo.
        material = {**dict(request), "forge_provider": binding.forge_provider,
                    "canonical_repository_url": binding.canonical_url, "base": binding.base,
                    "pull_number": request.get("pull_number"), "expected_head_sha": request.get("head_sha")}
        return hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def _claim(self, operation_id: str, fingerprint: str, request: Mapping[str, Any], prepared: Mapping[str, Any]) -> dict[str, Any] | None:
        """Atomically claim a merge operation before making an external call."""
        encoded_request = json.dumps(dict(request), sort_keys=True, separators=(",", ":"))
        encoded_outcome = json.dumps(dict(prepared), sort_keys=True, separators=(",", ":"))
        with closing(sqlite3.connect(self.config.database, isolation_level="IMMEDIATE")) as database:
            row = database.execute("SELECT fingerprint,outcome FROM merge_operations WHERE operation_id=?", (operation_id,)).fetchone()
            if row is not None:
                if not hmac.compare_digest(row[0], fingerprint): raise MergeAuthorityError("merge operation replay conflicts")
                return json.loads(row[1])
            try:
                database.execute("INSERT INTO merge_operations(operation_id,fingerprint,state,request,outcome) VALUES(?,?,?,?,?)", (operation_id, fingerprint, "prepared", encoded_request, encoded_outcome))
                database.commit()
            except sqlite3.IntegrityError:
                row = database.execute("SELECT fingerprint,outcome FROM merge_operations WHERE operation_id=?", (operation_id,)).fetchone()
                if row is None or not hmac.compare_digest(row[0], fingerprint): raise MergeAuthorityError("merge operation replay conflicts")
                return json.loads(row[1])
        return None

    def _stored(self, operation_id: str, fingerprint: str) -> dict[str, Any] | None:
        with closing(sqlite3.connect(self.config.database)) as database:
            row = database.execute("SELECT fingerprint,outcome FROM merge_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None:
            return None
        if not hmac.compare_digest(row[0], fingerprint):
            raise MergeAuthorityError("merge operation replay conflicts")
        return json.loads(row[1])

    def _save(self, operation_id: str, fingerprint: str, request: Mapping[str, Any], state: str, outcome: Mapping[str, Any], *, replace: bool = False) -> None:
        encoded_request = json.dumps(dict(request), sort_keys=True, separators=(",", ":"))
        encoded_outcome = json.dumps(dict(outcome), sort_keys=True, separators=(",", ":"))
        with closing(sqlite3.connect(self.config.database)) as database:
            if replace:
                database.execute("UPDATE merge_operations SET state=?,outcome=? WHERE operation_id=?", (state, encoded_outcome, operation_id))
            else:
                database.execute("INSERT INTO merge_operations(operation_id,fingerprint,state,request,outcome) VALUES(?,?,?,?,?)",
                    (operation_id, fingerprint, state, encoded_request, encoded_outcome))
            database.commit()

    def _validate_pull(self, pull: Mapping[str, Any], binding: RepoBinding, request: Mapping[str, Any]) -> str:
        head, base, user = pull.get("head"), pull.get("base"), pull.get("user")
        repository = base.get("repo") if isinstance(base, Mapping) else None
        owner = repository.get("owner") if isinstance(repository, Mapping) else None
        author = user.get("login") if isinstance(user, Mapping) else None
        if (not isinstance(pull, Mapping) or pull.get("number") != request["pull_number"] or not isinstance(head, Mapping)
                or head.get("sha") != request["head_sha"] or not isinstance(base, Mapping) or base.get("ref") != binding.base
                or not isinstance(repository, Mapping) or not isinstance(owner, Mapping) or owner.get("login") != binding.owner
                or repository.get("name") != binding.repository or not isinstance(author, str)):
            raise MergeAuthorityError("forge pull does not bind requested target")
        return author

    def _validate_receipt(self, request: Mapping[str, Any], binding: RepoBinding, author: str) -> None:
        try:
            receipt = self.receipts(request["verification_operation_id"])
        except Exception as error:
            raise MergeAuthorityError("independent review receipt is unavailable") from error
        expected_subject = {"repo_alias": request["repo_alias"], "pull_number": request["pull_number"], "head_sha": request["head_sha"]}
        if (not isinstance(receipt, Mapping) or set(receipt) != {"operation_id", "project_id", "command_id", "evaluator_revision", "state", "reviewer_id", "subject"}
                or receipt.get("operation_id") != request["verification_operation_id"] or receipt.get("project_id") != binding.project_id
                or receipt.get("command_id") != binding.command_id or receipt.get("evaluator_revision") != binding.evaluator_revision
                or receipt.get("state") != "passed" or not isinstance(receipt.get("reviewer_id"), str)
                or receipt["reviewer_id"] in {author, self.config.merge_principal} or receipt.get("subject") != expected_subject):
            raise MergeAuthorityError("independent verification receipt is not bound to this merge")

    def _journal_binding(self, request: Mapping[str, Any], fingerprint: str) -> RepoBinding:
        """Resolve a journaled alias without allowing its target to drift."""
        binding = self.config.repositories.get(request.get("repo_alias"))
        if binding is None:
            raise MergeAuthorityError("journal repository binding is unavailable")
        if not hmac.compare_digest(fingerprint, self._fingerprint(request, binding)):
            raise MergeAuthorityError("journal repository binding changed")
        return binding

    def request(self, request: Mapping[str, Any]) -> dict[str, Any]:
        self._request_schema(request)
        request = dict(request)
        binding = self.config.repositories.get(request["repo_alias"])
        if binding is None:
            raise MergeAuthorityError("repository alias is not configured")
        fingerprint = self._fingerprint(request, binding)
        # Idempotent replay must return the durable outcome without consulting
        # the forge again.  The pull may have changed after a successful merge,
        # and a fresh provider read must not turn a completed operation into a
        # replay failure.
        stored = self._stored(request["operation_id"], fingerprint)
        if stored is not None:
            return stored
        author = self._validate_pull(self.forge.get_pull(binding, request["pull_number"], self.token), binding, request)
        self._validate_receipt(request, binding, author)
        prepared = {"operation_id": request["operation_id"], "state": "prepared", "repo_alias": request["repo_alias"],
                    "pull_number": request["pull_number"], "pre_merge_head_sha": request["head_sha"]}
        stored = self._claim(request["operation_id"], fingerprint, request, prepared)
        if stored is not None:
            return stored
        try:
            result = self.forge.merge(binding, request["pull_number"], request["head_sha"], self.token)
        except ForgeDefinitiveRejection as error:
            outcome = {**prepared, "state": "rejected", "reason": str(error)}
        except ForgeTransportUnknown:
            outcome = {**prepared, "state": "unknown"}
        except Exception as error:
            outcome = {**prepared, "state": "unknown", "reason": type(error).__name__}
        else:
            merge_sha = result.get("sha") if isinstance(result, Mapping) else None
            if not isinstance(result, Mapping) or result.get("merged") is not True:
                outcome = {**prepared, "state": "rejected", "reason": "forge did not confirm merge"}
            elif not _sha(merge_sha) or merge_sha == request["head_sha"]:
                outcome = {**prepared, "state": "unknown", "reason": "forge merge commit identity is ambiguous"}
            else:
                outcome = {**prepared, "state": "merged", "merge_commit_sha": merge_sha}
        self._save(request["operation_id"], fingerprint, request, outcome["state"], outcome, replace=True)
        return outcome

    def reconcile(self, operation_id: str) -> dict[str, Any]:
        _identifier(operation_id, "operation id")
        with closing(sqlite3.connect(self.config.database)) as database:
            row = database.execute("SELECT fingerprint,state,request,outcome FROM merge_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None:
            raise MergeAuthorityError("merge operation not found")
        fingerprint, state, encoded_request, encoded_outcome = row
        request, outcome = json.loads(encoded_request), json.loads(encoded_outcome)
        if state not in {"prepared", "unknown"}:
            return outcome
        binding = self._journal_binding(request, fingerprint)
        try:
            pull = self.forge.get_pull(binding, request["pull_number"], self.token)
        except ForgeDefinitiveRejection as error:
            final = {**outcome, "state": "rejected", "reason": str(error)}
        except ForgeTransportUnknown:
            return outcome
        else:
            head = pull.get("head") if isinstance(pull, Mapping) else None
            merge_commit = pull.get("merge_commit_sha") if isinstance(pull, Mapping) else None
            if isinstance(pull, Mapping) and pull.get("merged") is True:
                if isinstance(head, Mapping) and head.get("sha") == request["head_sha"] and _sha(merge_commit) and merge_commit != request["head_sha"]:
                    final = {**outcome, "state": "merged", "merge_commit_sha": merge_commit}
                else:
                    final = {**outcome, "state": "unknown", "reason": "merged pull does not bind journaled head/commit"}
            elif isinstance(pull, Mapping) and pull.get("state") == "closed":
                final = {**outcome, "state": "rejected", "reason": "pull closed without journaled merge"}
            else:
                return outcome
        self._save(operation_id, fingerprint, request, final["state"], final, replace=True)
        return final

    def retry_unknown(self, operation_id: str) -> dict[str, Any]:
        """Explicitly retry one journaled unknown effect after exact reconciliation."""
        outcome = self.reconcile(operation_id)
        if outcome.get("state") != "unknown": return outcome
        with closing(sqlite3.connect(self.config.database)) as database:
            row = database.execute("SELECT fingerprint,request,outcome FROM merge_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None: raise MergeAuthorityError("merge operation not found")
        fingerprint, encoded_request, encoded_outcome = row; request=json.loads(encoded_request); prior=json.loads(encoded_outcome)
        binding=self._journal_binding(request, fingerprint)
        author=self._validate_pull(self.forge.get_pull(binding,request["pull_number"],self.token),binding,request); self._validate_receipt(request,binding,author)
        try: result=self.forge.merge(binding,request["pull_number"],request["head_sha"],self.token)
        except ForgeTransportUnknown: final={**prior,"state":"unknown"}
        except ForgeDefinitiveRejection as error: final={**prior,"state":"rejected","reason":str(error)}
        else:
            sha=result.get("sha") if isinstance(result,Mapping) else None
            final={**prior,"state":"merged","merge_commit_sha":sha} if result.get("merged") is True and _sha(sha) and sha != request["head_sha"] else {**prior,"state":"unknown"}
        self._save(operation_id,fingerprint,request,final["state"],final,replace=True); return final

    def operation_project(self, operation_id: str) -> str:
        """Return the immutable journaled project to authorize a reconciliation read."""
        _identifier(operation_id, "operation id")
        with closing(sqlite3.connect(self.config.database)) as database:
            row = database.execute("SELECT fingerprint,request FROM merge_operations WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None:
            raise MergeAuthorityError("merge operation not found")
        fingerprint, request = row
        request = json.loads(request)
        binding = self._journal_binding(request, fingerprint)
        return binding.project_id
