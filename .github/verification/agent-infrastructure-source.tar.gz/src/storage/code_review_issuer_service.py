"""Start independent review-receipt issuance beside the verification authority."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Mapping

from .code_review_issuer import CodeReviewIssuer, ReviewCommand
from .code_review_issuer_http import serve
from .code_review_receipts import CodeReviewReceiptStore
from .merge_authority_service import _private_config
from .gitea_merge_authority import _token, MergeAuthorityError
from .verification_service import VerificationService, load_configuration


def load_issuer_configuration(verification_config: str | Path, issuer_config: str | Path) -> tuple[Mapping[str, object], int]:
    """Validate the two external issuer declarations without opening a listener."""
    load_configuration(verification_config)
    raw=_private_config(Path(issuer_config)); required={"receipt_database","reviewer_id","commands","http"}
    if set(raw)!=required or not isinstance(raw["commands"],Mapping) or not isinstance(raw["http"],Mapping): raise MergeAuthorityError("review issuer config schema is invalid")
    http=raw["http"]
    if set(http)!={"host","port","scopes"} or http["host"]!="127.0.0.1" or type(http["port"]) is not int or not 1<=http["port"]<=65535 or not isinstance(http["scopes"],list): raise MergeAuthorityError("review issuer HTTP config is invalid")
    return raw, http["port"]


def main(argv: list[str] | None = None) -> int:
    parser=argparse.ArgumentParser(description="independent verification review-receipt issuer")
    parser.add_argument("--verification-config",required=True); parser.add_argument("--issuer-config",required=True); args=parser.parse_args(argv)
    raw, _=load_issuer_configuration(args.verification_config,args.issuer_config)
    http=raw["http"]
    if set(http)!={"host","port","scopes"} or http["host"]!="127.0.0.1" or type(http["port"]) is not int or not isinstance(http["scopes"],list): raise MergeAuthorityError("review issuer HTTP config is invalid")
    scopes={}
    for item in http["scopes"]:
        if not isinstance(item,Mapping) or set(item)!={"token_file","projects"} or not isinstance(item["projects"],list): raise MergeAuthorityError("review issuer scope is invalid")
        token=_token(Path(item["token_file"])); projects=frozenset(item["projects"])
        if not projects or token in scopes: raise MergeAuthorityError("review issuer scope is invalid")
        scopes[token]=projects
    commands={key:ReviewCommand(value) for key,value in raw["commands"].items()}
    issuer=CodeReviewIssuer(VerificationService(load_configuration(args.verification_config)),CodeReviewReceiptStore(Path(raw["receipt_database"])),raw["reviewer_id"],commands)
    server=serve(issuer,scopes,(http["host"],http["port"])); server.serve_forever(); return 0


if __name__=="__main__": raise SystemExit(main())
