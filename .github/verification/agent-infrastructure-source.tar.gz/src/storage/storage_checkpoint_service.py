"""Loopback HTTP adapter for immutable native Hermes checkpoint exports only."""
from __future__ import annotations

import argparse
import base64
from dataclasses import dataclass, field
import hmac
import json
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import tempfile
from typing import Any, Mapping

from .storage_checkpoints import CheckpointError, materialize, publish

DEFAULT_MAX_BODY = 16 * 1024 * 1024


class StorageCheckpointServiceError(ValueError): pass


@dataclass(frozen=True)
class StorageCheckpointServiceConfig:
    storage_root: Path
    temporary_root: Path
    bearer_scopes: Mapping[str, Mapping[str, frozenset[str]]] = field(repr=False)
    host: str = "127.0.0.1"
    port: int = 0
    max_body_bytes: int = DEFAULT_MAX_BODY

    def __post_init__(self) -> None:
        for root in (self.storage_root, self.temporary_root):
            if not root.is_absolute() or root.is_symlink() or not root.is_dir(): raise StorageCheckpointServiceError("storage locations must be existing non-symlink directories")
            current = Path(root.anchor)
            for part in root.parts[1:]:
                current /= part
                if current.exists() and current.is_symlink(): raise StorageCheckpointServiceError("storage locations cannot have symlink ancestors")
        if self.host != "127.0.0.1" or type(self.port) is not int or not 0 <= self.port <= 65535 or type(self.max_body_bytes) is not int or not 1024 <= self.max_body_bytes <= DEFAULT_MAX_BODY:
            raise StorageCheckpointServiceError("loopback address or body bound is invalid")
        if not self.bearer_scopes or any(not isinstance(token, str) or not token or not isinstance(scopes, Mapping) or any(not isinstance(project, str) or not project or not isinstance(agents, frozenset) or not agents for project, agents in scopes.items()) for token, scopes in self.bearer_scopes.items()): raise StorageCheckpointServiceError("scoped bearer credentials are required")


class StorageCheckpointServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, config: StorageCheckpointServiceConfig): self.config = config; super().__init__((config.host, config.port), StorageCheckpointHandler)


class StorageCheckpointHandler(BaseHTTPRequestHandler):
    server: StorageCheckpointServer
    def log_message(self, format: str, *args: object) -> None: return
    def setup(self) -> None: super().setup(); self.connection.settimeout(5)

    def _route(self) -> tuple[str, str, str, str] | None:
        parts = self.path.split("?", 1)[0].strip("/").split("/")
        if len(parts) == 6 and parts[0] == "projects" and parts[2] == "agents" and parts[4] == "checkpoints": return parts[1], parts[3], parts[5], "bundle"
        if len(parts) == 7 and parts[0] == "projects" and parts[2] == "agents" and parts[4] == "checkpoints" and parts[6] == "materialize": return parts[1], parts[3], parts[5], "materialize"
        return None

    def _scope(self, project: str, agent: str) -> bool:
        header = self.headers.get("Authorization", ""); supplied = header[7:] if header.startswith("Bearer ") else ""
        return any(hmac.compare_digest(supplied, token) and agent in scopes.get(project, frozenset()) for token, scopes in self.server.config.bearer_scopes.items())

    def _reply(self, status: HTTPStatus, value: Mapping[str, Any]) -> None:
        raw = json.dumps(value, separators=(",", ":"), allow_nan=False).encode(); self.send_response(status); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(raw))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(raw)

    def _body(self) -> Mapping[str, Any]:
        try: length = int(self.headers.get("Content-Length", "-1"))
        except ValueError: length = -1
        if self.headers.get("Content-Type", "").split(";", 1)[0] != "application/json" or not 0 <= length <= self.server.config.max_body_bytes: raise StorageCheckpointServiceError("bounded JSON body required")
        try: value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeError, ValueError) as error: raise StorageCheckpointServiceError("invalid JSON") from error
        if not isinstance(value, Mapping): raise StorageCheckpointServiceError("JSON object required")
        return value

    @staticmethod
    def _encoded(directory: Path, maximum: int) -> dict[str, Any]:
        native = list(directory.glob("*.manifest.json"))
        if len(native) != 1: raise StorageCheckpointServiceError("verified native export unavailable")
        data = json.loads(native[0].read_text(encoding="utf-8")); database = directory / data["database"]
        if not database.is_file() or database.is_symlink() or native[0].stat().st_size + database.stat().st_size > maximum // 2: raise StorageCheckpointServiceError("native export exceeds response bound")
        return {"native_manifest": {"name": native[0].name, "base64": base64.b64encode(native[0].read_bytes()).decode("ascii")}, "database": {"name": database.name, "base64": base64.b64encode(database.read_bytes()).decode("ascii")}}

    def do_POST(self) -> None:
        route = self._route()
        if route is None or not self._scope(*route[:2]): self._reply(HTTPStatus.UNAUTHORIZED if route else HTTPStatus.NOT_FOUND, {"error": "not_found" if route is None else "unauthorized"}); return
        project, agent, checkpoint, action = route
        try:
            if action == "materialize":
                if self._body(): raise StorageCheckpointServiceError("materialize takes no body")
                with tempfile.TemporaryDirectory(dir=self.server.config.temporary_root) as temporary:
                    destination = Path(temporary) / "native"; materialize(self.server.config.storage_root, project, agent, checkpoint, destination)
                    self._reply(HTTPStatus.OK, self._encoded(destination, self.server.config.max_body_bytes)); return
            body = self._body()
            if set(body) != {"native_manifest", "database"}: raise StorageCheckpointServiceError("exact native export payload required")
            with tempfile.TemporaryDirectory(dir=self.server.config.temporary_root) as temporary:
                directory = Path(temporary)
                names: set[str] = set()
                for key in ("native_manifest", "database"):
                    item = body[key]
                    if not isinstance(item, Mapping) or set(item) != {"name", "base64"} or not isinstance(item["name"], str) or Path(item["name"]).name != item["name"] or not isinstance(item["base64"], str): raise StorageCheckpointServiceError("invalid native export entry")
                    if not item["name"] or item["name"] in names: raise StorageCheckpointServiceError("duplicate or empty native export filename")
                    names.add(item["name"])
                    try: raw = base64.b64decode(item["base64"], validate=True)
                    except ValueError as error: raise StorageCheckpointServiceError("invalid base64") from error
                    if len(raw) > self.server.config.max_body_bytes: raise StorageCheckpointServiceError("native export too large")
                    (directory / item["name"]).write_bytes(raw)
                manifest = publish(self.server.config.storage_root, directory, project, agent, checkpoint)
                self._reply(HTTPStatus.OK, {"checkpoint_id": checkpoint, "manifest": manifest})
        except (CheckpointError, StorageCheckpointServiceError, OSError, ValueError) as error: self._reply(HTTPStatus.CONFLICT, {"error": str(error)})

    def do_GET(self) -> None:
        route = self._route()
        if route is None or not self._scope(*route[:2]): self._reply(HTTPStatus.UNAUTHORIZED if route else HTTPStatus.NOT_FOUND, {"error": "not_found" if route is None else "unauthorized"}); return
        project, agent, checkpoint, action = route
        if action != "bundle": self._reply(HTTPStatus.NOT_FOUND, {"error": "not_found"}); return
        try:
            with tempfile.TemporaryDirectory(dir=self.server.config.temporary_root) as temporary:
                destination = Path(temporary) / "native"; materialize(self.server.config.storage_root, project, agent, checkpoint, destination)
                self._reply(HTTPStatus.OK, self._encoded(destination, self.server.config.max_body_bytes))
        except (CheckpointError, StorageCheckpointServiceError, OSError, ValueError) as error: self._reply(HTTPStatus.CONFLICT, {"error": str(error)})


def serve(config: StorageCheckpointServiceConfig) -> StorageCheckpointServer: return StorageCheckpointServer(config)


def load_configuration(path: str | Path) -> StorageCheckpointServiceConfig:
    config_path = Path(path)
    if config_path.is_symlink() or not config_path.is_file(): raise StorageCheckpointServiceError("configuration file is unavailable")
    try: raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error: raise StorageCheckpointServiceError("configuration is invalid") from error
    required = {"storage_root", "temporary_root", "bearer_tokens_file"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or set(raw) - (required | {"port", "max_body_bytes"}): raise StorageCheckpointServiceError("configuration fields are invalid")
    credential_path = Path(raw["bearer_tokens_file"])
    if not credential_path.is_absolute() or credential_path.is_symlink() or not credential_path.is_file(): raise StorageCheckpointServiceError("credential file is unavailable")
    try: credentials = json.loads(credential_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error: raise StorageCheckpointServiceError("credential file is invalid") from error
    if not isinstance(credentials, Mapping): raise StorageCheckpointServiceError("credential scopes are invalid")
    scopes: dict[str, dict[str, frozenset[str]]] = {}
    for token, projects in credentials.items():
        if not isinstance(token, str) or not token or not isinstance(projects, Mapping): raise StorageCheckpointServiceError("credential scopes are invalid")
        scoped: dict[str, frozenset[str]] = {}
        for project, agents in projects.items():
            if not isinstance(project, str) or not project or not isinstance(agents, list) or not agents or any(not isinstance(agent, str) or not agent for agent in agents): raise StorageCheckpointServiceError("credential scopes are invalid")
            scoped[project] = frozenset(agents)
        scopes[token] = scoped
    try: return StorageCheckpointServiceConfig(Path(raw["storage_root"]), Path(raw["temporary_root"]), scopes, port=raw.get("port", 18130), max_body_bytes=raw.get("max_body_bytes", DEFAULT_MAX_BODY))
    except (TypeError, ValueError) as error: raise StorageCheckpointServiceError("configuration is invalid") from error


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Serve scoped immutable native checkpoint storage."); parser.add_argument("--config", required=True); parser.add_argument("--check", action="store_true"); args = parser.parse_args(argv)
    config = load_configuration(args.config)
    if args.check: print("configuration validated; listener was not started"); return 0
    server = serve(config)
    try: server.serve_forever()
    finally: server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
