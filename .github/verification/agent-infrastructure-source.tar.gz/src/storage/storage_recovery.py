"""Portable, browsable recovery-set storage with an explicit cold-copy queue.

This is deliberately a filesystem service.  It does not mount FNOS, encrypt or
archive data, start a timer, or treat a copy as a live runtime database.
"""
from __future__ import annotations

from dataclasses import dataclass
from contextlib import contextmanager
from functools import wraps
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import ctypes
import errno
import json
import os
from pathlib import Path, PureWindowsPath
import re
import shutil
import stat
import sys
import tempfile
import threading
from typing import Any, Iterable, Mapping, Sequence
from uuid import uuid4
from ctypes import wintypes


SAFE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
MAX_FILES = 10_000
MAX_FILE_BYTES = 2 * 1024 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024 * 1024
_CLASSIFICATIONS = {"AVG", "numbered", "skull"}


class RecoveryError(ValueError):
    pass


_FILE_ATTRIBUTE_REPARSE_POINT = 0x0400


def _is_reparse_point(path: Path) -> bool:
    """Return whether *path* is a Windows reparse point without following it."""
    if os.name != "nt":
        return False
    try:
        attributes = path.stat(follow_symlinks=False).st_file_attributes
    except (AttributeError, OSError):
        # An inspection failure must never be treated as proof that a path is
        # ordinary.  Callers use this predicate as a security boundary.
        return True
    return bool(attributes & _FILE_ATTRIBUTE_REPARSE_POINT)


def _entry_present(path: Path) -> bool:
    """Check a directory entry without following links.

    ``Path.exists`` follows links and therefore reports a dangling link as
    absent.  Cleanup state is authenticated by name and must treat such an
    entry as durable evidence (and fail closed) instead of allowing a retry to
    proceed. ``lstat`` is the no-follow view used for Windows reparse entries.
    Inspection errors are not absence: callers must fail closed with
    the controlled recovery error rather than silently ignoring an
    inaccessible entry.
    """
    try:
        os.lstat(path)
    except FileNotFoundError:
        return False
    except OSError as error:
        raise RecoveryError("cleanup entry cannot be inspected") from error
    return True


def _safe_existing_token(path: Path) -> None:
    """Validate an existing private token and every path component before use."""
    def symlink_or_uninspectable(candidate: Path) -> bool:
        try:
            return stat.S_ISLNK(os.lstat(candidate).st_mode)
        except OSError:
            return True

    if (not path.is_absolute() or symlink_or_uninspectable(path) or _is_reparse_point(path)
            or not path.is_file()):
        raise RecoveryError("token file is unsafe")
    for parent in path.parents:
        if symlink_or_uninspectable(parent) or _is_reparse_point(parent):
            raise RecoveryError("token file is unsafe")
    if os.name != "nt" and path.stat().st_mode & 0o077:
        raise RecoveryError("token file is not private")


def _open_validated_token(path: Path) -> bytes:
    """Open, validate, and read a token from the same filesystem object.

    The descriptor is acquired before path validation.  A no-follow open on
    POSIX plus an identity comparison against a no-follow stat prevents a
    replacement of the file (or an ancestor) from redirecting the subsequent
    read.  Windows callers additionally rely on the reparse checks while the
    handle remains open; any uncertain inspection fails closed.
    """
    if not path.is_absolute():
        raise RecoveryError("token file is unsafe")
    flags = os.O_RDONLY
    flags |= getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError as error:
        raise RecoveryError("token file is unavailable") from error
    try:
        try:
            opened = os.fstat(descriptor)
            _safe_existing_token(path)
            current = os.stat(path, follow_symlinks=False)
        except (OSError, RecoveryError) as error:
            raise RecoveryError("token file is unsafe") from error
        if (int(opened.st_dev), int(opened.st_ino)) != (int(current.st_dev), int(current.st_ino)):
            raise RecoveryError("token file was replaced")
        if os.name != "nt" and opened.st_mode & 0o077:
            raise RecoveryError("token file is not private")
        try:
            with os.fdopen(descriptor, "rb", closefd=True) as handle:
                descriptor = -1
                return handle.read()
        except OSError as error:
            raise RecoveryError("token file is unavailable") from error
    finally:
        if descriptor != -1:
            try:
                os.close(descriptor)
            except OSError:
                pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def _identifier(value: str) -> str:
    if not isinstance(value, str) or not SAFE.fullmatch(value):
        raise RecoveryError("unsafe identifier")
    return value


def _manifest_relative_path(value: Any, root: Path | None = None) -> Path:
    """Validate a manifest path before any filesystem operation uses it."""
    if not isinstance(value, str) or not value or "\x00" in value or "\\" in value:
        raise RecoveryError("recovery file entry is unsafe")
    relative = Path(value)
    windows = PureWindowsPath(value)
    if (relative.is_absolute() or windows.is_absolute() or windows.drive
            or windows.root or ".." in relative.parts or ".." in windows.parts):
        raise RecoveryError("recovery file entry is unsafe")
    if root is not None:
        try:
            (root / relative).resolve(strict=False).relative_to(root.resolve(strict=True))
        except (OSError, RuntimeError, ValueError) as error:
            raise RecoveryError("recovery file entry is outside its trusted root") from error
    return relative


def _safe_directory(path: Path, *, create: bool = False) -> Path:
    if not path.is_absolute():
        raise RecoveryError("recovery roots must be absolute")
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if current.exists() and current.is_symlink():
            raise RecoveryError("symlinked recovery root ancestor")
    if create:
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.is_symlink() or not path.is_dir():
        raise RecoveryError("safe recovery directory required")
    return path


def _child(root: Path, *parts: str, create: bool = False) -> Path:
    current = root
    for part in parts:
        _identifier(part.lstrip("."))
        current /= part
        try:
            entry = os.lstat(current)
        except FileNotFoundError:
            entry = None
        except OSError as error:
            raise RecoveryError("recovery namespace cannot be inspected") from error
        if entry is not None and stat.S_ISLNK(entry.st_mode):
            raise RecoveryError("symlinked recovery namespace")
        if create and entry is None:
            current.mkdir(mode=0o700)
            entry = os.lstat(current)
        if create and (entry is None or not stat.S_ISDIR(entry.st_mode)):
            raise RecoveryError("unsafe recovery namespace")
    return current


def _fsync_directory(path: Path) -> None:
    try:
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    except PermissionError:
        if os.name != "nt":
            raise


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.{uuid4().hex}.pending")
    with temporary.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, sort_keys=True, separators=(",", ":"), allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    _fsync_directory(path.parent)


def _write_json_noreplace(path: Path, value: Mapping[str, Any]) -> bool:
    """Publish a new JSON record without replacing an existing directory entry."""
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError:
        return False
    try:
        with os.fdopen(descriptor, "wb", closefd=True) as handle:
            descriptor = -1
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        if descriptor != -1:
            os.close(descriptor)
    _fsync_directory(path.parent)
    return True


@contextmanager
def _open_verified_cleanup_record(path: Path):
    """Open a cleanup record and bind writes to that exact filesystem object."""
    flags = os.O_RDWR | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
        opened = os.fstat(descriptor)
        if (not stat.S_ISREG(opened.st_mode) or _is_reparse_point(path)):
            raise RecoveryError("cleanup record is unsafe")
        named = os.stat(path, follow_symlinks=False)
        identity = (int(opened.st_dev), int(opened.st_ino))
        if identity != (int(named.st_dev), int(named.st_ino)):
            raise RecoveryError("cleanup record was replaced")
    except (OSError, RecoveryError) as error:
        try:
            os.close(descriptor)
        except (UnboundLocalError, OSError):
            pass
        raise RecoveryError("cleanup record cannot be opened safely") from error
    try:
        yield descriptor, identity
    finally:
        try:
            os.close(descriptor)
        except OSError:
            pass


_CLEANUP_DESCRIPTOR_STATE = threading.local()


def _owned_cleanup_descriptors() -> set["_OwnedDescriptor"]:
    descriptors = getattr(_CLEANUP_DESCRIPTOR_STATE, "descriptors", None)
    if descriptors is None:
        descriptors = set()
        _CLEANUP_DESCRIPTOR_STATE.descriptors = descriptors
    return descriptors


def _close_cleanup_descriptors(function):
    """Close descriptors acquired by one reconciliation invocation."""
    @wraps(function)
    def guarded(*args, **kwargs):
        owned_before = set(_owned_cleanup_descriptors())
        try:
            return function(*args, **kwargs)
        finally:
            for descriptor in _owned_cleanup_descriptors() - owned_before:
                descriptor.close()
    return guarded


class _OwnedDescriptor:
    """Own a duplicated descriptor until the current operation exits.

    Reconciliation has a number of deliberately fail-closed exits after the
    record is authenticated.  Keeping ownership in a small object makes the
    descriptor lifetime exception-safe as well as return-safe; ``__index__``
    lets the ``os`` APIs continue to receive the underlying descriptor.
    """

    def __init__(self, descriptor: int) -> None:
        self._descriptor = descriptor
        _owned_cleanup_descriptors().add(self)

    def __index__(self) -> int:
        return self._descriptor

    def fileno(self) -> int:
        return self._descriptor

    def close(self) -> None:
        descriptor = self._descriptor
        self._descriptor = -1
        _owned_cleanup_descriptors().discard(self)
        if descriptor != -1:
            os.close(descriptor)

    def __del__(self) -> None:
        try:
            self.close()
        except OSError:
            pass


def _read_cleanup_record_fd(descriptor: int, secret: bytes | None = None) -> dict[str, Any]:
    """Read the newest complete journal entry from an already bound handle.

    The first release wrote one JSON object.  Keep accepting that format while
    treating subsequent newline-delimited objects as an append-only journal.
    A torn final append is ignored; a complete malformed entry is not.
    """
    try:
        os.lseek(descriptor, 0, os.SEEK_SET)
        raw = b""
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            raw += chunk
    except OSError as error:
        raise RecoveryError("cleanup record is malformed") from error
    if not raw:
        raise RecoveryError("cleanup record is malformed")
    lines = raw.splitlines(keepends=True)
    records: list[dict[str, Any]] = []
    for index, line in enumerate(lines):
        complete = line.endswith((b"\n", b"\r")) or index < len(lines) - 1
        payload = line.strip()
        if not payload:
            continue
        try:
            value = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as error:
            if index == len(lines) - 1 and not complete:
                break
            raise RecoveryError("cleanup record is malformed") from error
        if not isinstance(value, dict):
            raise RecoveryError("cleanup record is malformed")
        records.append(value)
    if not records:
        raise RecoveryError("cleanup record is malformed")
    if secret is not None:
        for value in records:
            identity = value.get("identity")
            quarantine = value.get("quarantine")
            state = value.get("state")
            if (not isinstance(state, str) or not isinstance(quarantine, str)
                    or not isinstance(identity, list) or len(identity) != 2
                    or any(type(item) is not int for item in identity)
                    or not isinstance(value.get("mac"), str)
                    or not hmac.compare_digest(value["mac"], _cleanup_mac(secret, state, quarantine, tuple(identity)))):
                raise RecoveryError("cleanup authentication failed")
    return records[-1]


def _write_json_cleanup_record(descriptor: int, path: Path, identity: tuple[int, int], value: Mapping[str, Any]) -> None:
    """Append an authenticated transition to an already-open record journal."""
    try:
        named = os.stat(path, follow_symlinks=False)
        if (int(named.st_dev), int(named.st_ino)) != identity:
            raise RecoveryError("cleanup record ownership changed")
        bound = os.fstat(descriptor)
        if (int(bound.st_dev), int(bound.st_ino)) != identity:
            raise RecoveryError("cleanup record ownership changed")
        payload_value = {key: item for key, item in value.items() if key != "_record_identity"}
        payload = json.dumps(payload_value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        os.lseek(descriptor, 0, os.SEEK_SET)
        raw = b""
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            raw += chunk
        lines = raw.splitlines(keepends=True)
        if lines:
            offset = sum(len(line) for line in lines[:-1])
            final = lines[-1]
            if final and not final.endswith((b"\n", b"\r")):
                try:
                    json.loads(final.strip().decode("utf-8"))
                except (UnicodeDecodeError, ValueError):
                    os.ftruncate(descriptor, offset)
        os.lseek(descriptor, 0, os.SEEK_END)
        if os.lseek(descriptor, 0, os.SEEK_CUR) > 0:
            os.write(descriptor, b"\n")
        written = 0
        while written < len(payload):
            written += os.write(descriptor, payload[written:])
        os.fsync(descriptor)
        named = os.stat(path, follow_symlinks=False)
        if (int(named.st_dev), int(named.st_ino)) != identity:
            raise RecoveryError("cleanup record ownership changed")
    except RecoveryError:
        raise
    except OSError as error:
        raise RecoveryError("cleanup record cannot be updated safely") from error


def _write_json_cleanup_record_path(path: Path, value: Mapping[str, Any], *, expected_identity: tuple[int, int] | None = None) -> None:
    """Open, verify, and update a cleanup record without replacing its name."""
    if expected_identity is None:
        embedded = value.get("_record_identity")
        if isinstance(embedded, tuple) and len(embedded) == 2 and all(type(item) is int for item in embedded):
            expected_identity = embedded
    with _open_verified_cleanup_record(path) as (descriptor, identity):
        if expected_identity is not None and identity != expected_identity:
            raise RecoveryError("cleanup record ownership changed")
        _write_json_cleanup_record(descriptor, path, identity, value)


def _read_cleanup_record_path(path: Path, secret: bytes | None = None) -> dict[str, Any]:
    with _open_verified_cleanup_record(path) as (descriptor, _identity):
        return _read_cleanup_record_fd(descriptor, secret)


def _posix_open_directory_child(parent_descriptor: int, name: str) -> int:
    """Open one ordinary directory relative to a held parent."""
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    directory = getattr(os, "O_DIRECTORY", 0)
    if not nofollow or not directory or os.open not in getattr(os, "supports_dir_fd", set()):
        raise RecoveryError("safe recovery file access is unavailable")
    descriptor: int | None = None
    try:
        before = os.stat(name, dir_fd=parent_descriptor, follow_symlinks=False)
        if not stat.S_ISDIR(before.st_mode):
            raise RecoveryError("recovery namespace is unsafe")
        descriptor = os.open(name, os.O_RDONLY | directory | nofollow, dir_fd=parent_descriptor)
        opened = os.fstat(descriptor)
        if (not stat.S_ISDIR(opened.st_mode)
                or (int(opened.st_dev), int(opened.st_ino)) != (int(before.st_dev), int(before.st_ino))):
            raise RecoveryError("recovery namespace changed")
        result = descriptor
        descriptor = None
        return result
    except RecoveryError:
        raise
    except OSError as error:
        raise RecoveryError("recovery namespace is unsafe") from error
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _posix_open_directory_path(path: Path) -> tuple[int, tuple[int, int]]:
    """Resolve an absolute directory from the filesystem root without links."""
    if not path.is_absolute():
        raise RecoveryError("recovery roots must be absolute")
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    directory = getattr(os, "O_DIRECTORY", 0)
    if not nofollow or not directory:
        raise RecoveryError("safe recovery file access is unavailable")
    cursor: int | None = None
    try:
        cursor = os.open(Path(path.anchor), os.O_RDONLY | directory | nofollow)
        for component in path.parts[1:]:
            child = _posix_open_directory_child(cursor, component)
            os.close(cursor)
            cursor = child
        information = os.fstat(cursor)
        result = cursor
        cursor = None
        return result, (int(information.st_dev), int(information.st_ino))
    except RecoveryError:
        raise
    except OSError as error:
        raise RecoveryError("materialization destination is unsafe") from error
    finally:
        if cursor is not None:
            os.close(cursor)


def _posix_open_directory_from_root(
    root_descriptor: int, root: Path, path: Path, *, create: bool = False,
) -> tuple[int, tuple[int, int]]:
    """Resolve *path* relative to the same held trusted-root object."""
    try:
        relative = path.relative_to(root)
    except ValueError as error:
        raise RecoveryError("recovery namespace is outside its trusted root") from error
    cursor: int | None = os.dup(root_descriptor)
    try:
        for component in relative.parts:
            if component in {"", ".", ".."} or os.sep in component or "\x00" in component:
                raise RecoveryError("recovery namespace is outside its trusted root")
            if create:
                try:
                    os.stat(component, dir_fd=cursor, follow_symlinks=False)
                except FileNotFoundError:
                    try:
                        os.mkdir(component, mode=0o700, dir_fd=cursor)
                    except FileExistsError:
                        pass
            child = _posix_open_directory_child(cursor, component)
            os.close(cursor)
            cursor = child
        information = os.fstat(cursor)
        result = cursor
        cursor = None
        return result, (int(information.st_dev), int(information.st_ino))
    except RecoveryError:
        raise
    except OSError as error:
        raise RecoveryError("materialization destination is unsafe") from error
    finally:
        if cursor is not None:
            os.close(cursor)


def _posix_open_regular_file_from_directory(directory_descriptor: int, relative: Path) -> int:
    """Open one regular file by walking a held directory capability."""
    if not relative.parts or relative.is_absolute():
        raise RecoveryError("recovery file path is unsafe")
    cursor: int | None = os.dup(directory_descriptor)
    descriptor: int | None = None
    try:
        for component in relative.parts[:-1]:
            if component in {"", ".", ".."} or os.sep in component or "\x00" in component:
                raise RecoveryError("recovery file path is unsafe")
            child = _posix_open_directory_child(cursor, component)
            os.close(cursor)
            cursor = child
        name = relative.parts[-1]
        if name in {"", ".", ".."} or os.sep in name or "\x00" in name:
            raise RecoveryError("recovery file path is unsafe")
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
        before = os.stat(name, dir_fd=cursor, follow_symlinks=False)
        if not stat.S_ISREG(before.st_mode):
            raise RecoveryError("recovery file is unsafe")
        descriptor = os.open(name, flags, dir_fd=cursor)
        opened = os.fstat(descriptor)
        if (not stat.S_ISREG(opened.st_mode)
                or (int(opened.st_dev), int(opened.st_ino)) !=
                (int(before.st_dev), int(before.st_ino))):
            raise RecoveryError("recovery file was replaced")
        result = descriptor
        descriptor = None
        return result
    except RecoveryError:
        raise
    except OSError as error:
        raise RecoveryError("recovery file is unsafe") from error
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if cursor is not None:
            os.close(cursor)


def _posix_digest_regular_file(descriptor: int) -> tuple[int, str]:
    """Digest an already opened regular file without resolving its pathname."""
    try:
        os.lseek(descriptor, 0, os.SEEK_SET)
        digest = hashlib.sha256()
        size = 0
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                return size, digest.hexdigest()
            digest.update(chunk)
            size += len(chunk)
    except OSError as error:
        raise RecoveryError("recovery file is unavailable") from error


def _posix_link_descriptor(descriptor: int, parent_descriptor: int, name: str) -> None:
    """Link a completed anonymous inode using an unprivileged POSIX route."""
    error_number = errno.ENOSYS
    try:
        linkat = getattr(ctypes.CDLL(None, use_errno=True), "linkat", None)
    except (AttributeError, OSError):
        linkat = None
    if linkat is not None:
        linkat.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
        linkat.restype = ctypes.c_int
        if linkat(descriptor, b"", parent_descriptor, os.fsencode(name), 0x1000) == 0:  # AT_EMPTY_PATH
            return
        error_number = ctypes.get_errno() or error_number
    for prefix in ("/proc/self/fd", "/dev/fd"):
        try:
            os.link(f"{prefix}/{descriptor}", name, dst_dir_fd=parent_descriptor, follow_symlinks=True)
            return
        except OSError as error:
            error_number = error.errno or error_number
    raise RecoveryError(f"unprivileged recovery publication is unavailable (errno {error_number})")


def _posix_link_named_noreplace(parent_descriptor: int, source: str, destination: str) -> None:
    """Hard-link a named temporary without replacing a concurrent winner."""
    _posix_link_named_noreplace_from(
        parent_descriptor, source, parent_descriptor, destination,
    )


def _posix_link_named_noreplace_from(
    source_descriptor: int, source: str, destination_descriptor: int, destination: str,
) -> None:
    """Hard-link between held directories without replacing a concurrent winner."""
    try:
        os.link(
            source, destination,
            src_dir_fd=source_descriptor, dst_dir_fd=destination_descriptor,
            follow_symlinks=False,
        )
    except FileExistsError as error:
        raise RecoveryError("recovery destination already exists") from error
    except OSError as error:
        raise RecoveryError("unprivileged recovery publication is unavailable") from error


def _posix_rename_noreplace(parent_descriptor: int, source: str, destination: str) -> None:
    """Rename within a held directory while rejecting a concurrent winner."""
    if sys.platform == "darwin":
        # Darwin exposes the descriptor-relative equivalent as renameatx_np.
        # RENAME_EXCL is an atomic no-replace operation; unlike a path-based
        # renamex_np call, this keeps the already verified parent descriptor as
        # the ancestry boundary.
        try:
            renameatx = getattr(ctypes.CDLL(None, use_errno=True), "renameatx_np")
        except (AttributeError, OSError) as error:
            raise RecoveryError("atomic recovery publication is unavailable") from error
        renameatx.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        renameatx.restype = ctypes.c_int
        result = renameatx(
            parent_descriptor, os.fsencode(source),
            parent_descriptor, os.fsencode(destination), 0x00000004,  # RENAME_EXCL
        )
        if result:
            error_number = ctypes.get_errno() or errno.EIO
            raise RecoveryError("recovery destination already exists") if error_number == errno.EEXIST else RecoveryError("recovery publication failed")
        return
    try:
        renameat2 = getattr(ctypes.CDLL(None, use_errno=True), "renameat2")
    except (AttributeError, OSError) as error:
        raise RecoveryError("atomic recovery publication is unavailable") from error
    renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    renameat2.restype = ctypes.c_int
    result = renameat2(
        parent_descriptor, os.fsencode(source),
        parent_descriptor, os.fsencode(destination), 1,
    )
    if result:
        error_number = ctypes.get_errno() or errno.EIO
        raise RecoveryError("recovery destination already exists") if error_number == errno.EEXIST else RecoveryError("recovery publication failed")


def _posix_exchange(parent_descriptor: int, first: str, second: str) -> None:
    """Atomically exchange two names in a held directory."""
    if sys.platform == "darwin":
        # Darwin's descriptor-relative exchange primitive is renameatx_np;
        # RENAME_SWAP keeps the verified parent boundary and swaps both names
        # atomically without publishing an intermediate pathname.
        try:
            renameatx = getattr(ctypes.CDLL(None, use_errno=True), "renameatx_np")
        except (AttributeError, OSError) as error:
            raise RecoveryError("atomic recovery cleanup is unavailable") from error
        renameatx.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        renameatx.restype = ctypes.c_int
        if renameatx(
            parent_descriptor, os.fsencode(first),
            parent_descriptor, os.fsencode(second), 0x00000002,  # RENAME_SWAP
        ):
            raise RecoveryError("atomic recovery cleanup failed")
        return
    try:
        renameat2 = getattr(ctypes.CDLL(None, use_errno=True), "renameat2")
    except (AttributeError, OSError) as error:
        raise RecoveryError("atomic recovery cleanup is unavailable") from error
    renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    renameat2.restype = ctypes.c_int
    if renameat2(parent_descriptor, os.fsencode(first), parent_descriptor, os.fsencode(second), 2):
        raise RecoveryError("atomic recovery cleanup failed")


def _posix_publish_json(parent_descriptor: int, temporary: str, name: str,
                        expected_identity: tuple[int, int] | None) -> None:
    """Publish a journal only if its target stayed the object we read."""
    if expected_identity is None:
        _posix_rename_noreplace(parent_descriptor, temporary, name)
        return
    exchanged = False
    try:
        _posix_exchange(parent_descriptor, temporary, name)
        exchanged = True
        try:
            current = os.stat(temporary, dir_fd=parent_descriptor, follow_symlinks=False)
        except OSError as error:
            raise RecoveryError("recovery journal publication cannot be verified") from error
        identity = (int(current.st_dev), int(current.st_ino))
        if identity != expected_identity:
            _posix_exchange(parent_descriptor, temporary, name)
            exchanged = False
            raise RecoveryError("recovery journal publication target was replaced")
        os.unlink(temporary, dir_fd=parent_descriptor)
    except RecoveryError:
        if exchanged:
            try:
                _posix_exchange(parent_descriptor, temporary, name)
            except RecoveryError:
                # Keep the displaced entry as durable evidence if rollback
                # itself cannot be completed safely.
                raise
        try:
            os.unlink(temporary, dir_fd=parent_descriptor)
        except OSError:
            pass
        raise


# Kept as a compatibility seam for directory publication callers and existing
# tests; the primitive is equally safe for regular files.
_posix_rename_directory_noreplace = _posix_rename_noreplace


def _posix_descriptor_path(descriptor: int) -> Path:
    """Resolve a held directory descriptor after its original name may have moved."""
    for prefix in ("/proc/self/fd", "/dev/fd"):
        try:
            value = os.readlink(f"{prefix}/{descriptor}")
        except OSError:
            continue
        if os.path.isabs(value) and not value.endswith(" (deleted)"):
            return Path(value)
    raise RecoveryError("descriptor-bound recovery cleanup is unavailable")


def _cleanup_owned_posix_directory(descriptor: int, display_root: Path) -> tuple[str, ...]:
    """Remove owned descendants through held descriptors, preserving replacements."""
    try:
        entries = list(os.scandir(_posix_descriptor_path(descriptor)))
    except (OSError, RecoveryError):
        return (str(display_root),)
    residual: list[str] = []

    def restore_if_absent(temporary: str, name: str, display_path: Path) -> None:
        try:
            # A pathname existence check is not a reservation.  Publish the
            # retained entry with the same atomic no-replace primitive used by
            # normal recovery publication so a concurrent winner is never
            # overwritten.
            _posix_rename_noreplace(descriptor, temporary, name)
            return
        except FileNotFoundError:
            pass
        except RecoveryError:
            pass
        except OSError:
            pass
        residual.append(str(display_path))

    for entry in entries:
        name = entry.name
        display_path = display_root / name
        temporary = f".cleanup-{uuid4().hex}"
        try:
            initial = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
            identity = (int(initial.st_dev), int(initial.st_ino))
            os.rename(name, temporary, src_dir_fd=descriptor, dst_dir_fd=descriptor)
            moved = os.stat(temporary, dir_fd=descriptor, follow_symlinks=False)
            if (int(moved.st_dev), int(moved.st_ino)) != identity:
                restore_if_absent(temporary, name, display_path)
                continue
            if stat.S_ISDIR(moved.st_mode):
                child = _posix_open_directory_child(descriptor, temporary)
                try:
                    child_residual = _cleanup_owned_posix_directory(child, display_path)
                finally:
                    os.close(child)
                if child_residual:
                    residual.extend(child_residual)
                    restore_if_absent(temporary, name, display_path)
                    continue
                _posix_retire_owned_entry(descriptor, temporary, identity, moved.st_mode)
            elif stat.S_ISREG(moved.st_mode):
                _posix_retire_owned_entry(descriptor, temporary, identity, moved.st_mode)
            else:
                os.rename(temporary, name, src_dir_fd=descriptor, dst_dir_fd=descriptor)
                residual.append(str(display_path))
        except FileNotFoundError:
            continue
        except (OSError, RecoveryError):
            residual.append(str(display_path))
            try:
                os.stat(temporary, dir_fd=descriptor, follow_symlinks=False)
            except OSError:
                pass
            else:
                restore_if_absent(temporary, name, display_path)
    return tuple(dict.fromkeys(residual))


def _posix_retire_owned_entry(parent_descriptor: int, name: str, identity: tuple[int, int], mode: int) -> bool:
    """Remove an owned entry without deleting a replacement at its name.

    ``unlinkat`` has no inode-compare operation.  Exchange the entry with a
    fresh, operation-owned tombstone first; a replacement installed at the
    original name consequently remains at that name and is never removed.
    If the atomic exchange capability is unavailable, retain the entry and
    fail closed rather than falling back to stat-then-unlink/rmdir.
    """
    tombstone = f".cleanup-retire-{uuid4().hex}"
    marker_tombstone = f".cleanup-marker-{uuid4().hex}"
    is_directory = stat.S_ISDIR(mode)
    tombstone_identity: tuple[int, int] | None = None
    exchanged = False
    try:
        if is_directory:
            os.mkdir(tombstone, mode=0o700, dir_fd=parent_descriptor)
        elif stat.S_ISREG(mode):
            fd = os.open(tombstone, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600, dir_fd=parent_descriptor)
            os.close(fd)
        else:
            return False
        marker = os.stat(tombstone, dir_fd=parent_descriptor, follow_symlinks=False)
        tombstone_identity = (int(marker.st_dev), int(marker.st_ino))
        _posix_exchange(parent_descriptor, name, tombstone)
        exchanged = True
        retired = os.stat(tombstone, dir_fd=parent_descriptor, follow_symlinks=False)
        if (int(retired.st_dev), int(retired.st_ino)) != identity:
            # The exchange did not move the object we authenticated. Preserve
            # both names for reconciliation; never remove either by name.
            return False
        if is_directory:
            os.rmdir(tombstone, dir_fd=parent_descriptor)
        else:
            os.unlink(tombstone, dir_fd=parent_descriptor)
        # Move the empty operation marker out of the public name with an
        # atomic no-replace rename.  Unlike stat-then-unlink, this gives us a
        # safe identity check: if a replacement won the name, it is moved to
        # the private marker and restored with another no-replace rename.
        _posix_rename_noreplace(parent_descriptor, name, marker_tombstone)
        moved_marker = os.stat(marker_tombstone, dir_fd=parent_descriptor, follow_symlinks=False)
        if (int(moved_marker.st_dev), int(moved_marker.st_ino)) != tombstone_identity:
            try:
                _posix_rename_noreplace(parent_descriptor, marker_tombstone, name)
            except (OSError, RecoveryError):
                pass
            return False
        if is_directory:
            os.rmdir(marker_tombstone, dir_fd=parent_descriptor)
        else:
            os.unlink(marker_tombstone, dir_fd=parent_descriptor)
        return True
    except (OSError, RecoveryError):
        # The original entry or tombstone is durable evidence for retry.
        return False
    finally:
        # A capability/setup failure can leave our private marker behind. It
        # is safe to retire that marker only before an exchange, and only
        # while its identity is still ours. Once exchanged, retain it as
        # durable reconciliation evidence whenever ownership is uncertain.
        if not exchanged and tombstone_identity is not None:
            try:
                marker = os.stat(tombstone, dir_fd=parent_descriptor, follow_symlinks=False)
                marker_is_owned = (
                    (int(marker.st_dev), int(marker.st_ino)) == tombstone_identity
                    and ((is_directory and stat.S_ISDIR(marker.st_mode))
                         or (not is_directory and stat.S_ISREG(marker.st_mode)))
                )
                if marker_is_owned:
                    if is_directory:
                        os.rmdir(tombstone, dir_fd=parent_descriptor)
                    else:
                        os.unlink(tombstone, dir_fd=parent_descriptor)
            except OSError:
                # The marker is deliberately left for reconciliation if it
                # disappeared or was replaced during this cleanup attempt.
                pass


class _PosixStageGuard:
    """Bind one recovery stage to the exact parent and trusted root opened at creation."""

    def __init__(self, stage: Path, destination: Path, trusted_root: Path | None) -> None:
        self.stage = stage
        self.destination = destination
        self.trusted_root = trusted_root
        self.root_descriptor: int | None = None
        self.parent_descriptor: int | None = None
        self.stage_descriptor: int | None = None
        self.root_identity: tuple[int, int] | None = None
        self.parent_identity: tuple[int, int] | None = None
        self.stage_identity: tuple[int, int] | None = None
        self.temporary_descriptor: int | None = None
        self.temporary_name: str | None = None
        self.temporary_identity: tuple[int, int] | None = None
        self.temporary_root_descriptor: int | None = None
        self.temporary_root_identity: tuple[int, int] | None = None
        self.temporary_file_name: str | None = None
        self.temporary_file_identity: tuple[int, int] | None = None
        self._operation_bound_parent = False
        self.outputs: list[
            tuple[tuple[tuple[str, tuple[int, int]], ...], str, tuple[int, int]]
        ] = []
        # The operation-owned manifest is the sole authority for rollback.
        # Names currently present below the stage are not evidence of
        # ownership: another actor may have injected or replaced them.
        self.owned_entries: list[
            tuple[tuple[tuple[str, tuple[int, int]], ...], str, tuple[int, int], bool]
        ] = []
        self.published = False

    @classmethod
    def create(cls, stage: Path, destination: Path, trusted_root: Path | None,
               temporary_root: Path | None = None, *,
               trusted_root_descriptor: int | None = None,
               parent_descriptor: int | None = None,
               temporary_root_descriptor: int | None = None) -> "_PosixStageGuard":
        guard = cls(stage, destination, trusted_root)
        try:
            if trusted_root is not None:
                if trusted_root_descriptor is not None:
                    guard.root_descriptor = os.dup(trusted_root_descriptor)
                    information = os.fstat(guard.root_descriptor)
                    guard.root_identity = (int(information.st_dev), int(information.st_ino))
                else:
                    guard.root_descriptor, guard.root_identity = _posix_open_directory_path(trusted_root)
                if parent_descriptor is not None:
                    guard.parent_descriptor = os.dup(parent_descriptor)
                    information = os.fstat(guard.parent_descriptor)
                    guard.parent_identity = (int(information.st_dev), int(information.st_ino))
                    guard._operation_bound_parent = True
                else:
                    guard.parent_descriptor, guard.parent_identity = _posix_open_directory_from_root(
                        guard.root_descriptor, trusted_root, stage.parent,
                    )
            else:
                guard.parent_descriptor, guard.parent_identity = _posix_open_directory_path(stage.parent)
            if guard.parent_descriptor is None:
                raise RecoveryError("materialization destination is unavailable")
            if temporary_root is None:
                temporary_root = trusted_root
            if temporary_root is None:
                # A named fallback must never write through a movable pathname.
                # Without a configured root there is no safe operation-owned
                # place to stage bytes, so fail closed before writing any bytes.
                raise RecoveryError("safe recovery temporary storage is unavailable")
            if temporary_root_descriptor is not None:
                guard.temporary_root_descriptor = os.dup(temporary_root_descriptor)
                information = os.fstat(guard.temporary_root_descriptor)
                guard.temporary_root_identity = (int(information.st_dev), int(information.st_ino))
            else:
                guard.temporary_root_descriptor, guard.temporary_root_identity = _posix_open_directory_path(temporary_root)
            guard.temporary_name = f".recovery-output-{uuid4().hex}.tmp"
            os.mkdir(guard.temporary_name, mode=0o700, dir_fd=guard.temporary_root_descriptor)
            guard.temporary_descriptor = _posix_open_directory_child(
                guard.temporary_root_descriptor, guard.temporary_name,
            )
            temporary = os.fstat(guard.temporary_descriptor)
            guard.temporary_identity = (int(temporary.st_dev), int(temporary.st_ino))
            for name, message in ((destination.name, "materialize destination must be a fresh safe directory"),
                                  (stage.name, "pending materialization requires reconciliation")):
                try:
                    os.stat(name, dir_fd=guard.parent_descriptor, follow_symlinks=False)
                except FileNotFoundError:
                    pass
                else:
                    raise RecoveryError(message)
            os.mkdir(stage.name, mode=0o700, dir_fd=guard.parent_descriptor)
            guard.stage_descriptor = _posix_open_directory_child(guard.parent_descriptor, stage.name)
            information = os.fstat(guard.stage_descriptor)
            guard.stage_identity = (int(information.st_dev), int(information.st_ino))
            guard.validate()
            return guard
        except Exception:
            guard.cleanup()
            guard.close()
            raise

    def close(self) -> None:
        self._cleanup_temporary()
        for attribute in ("stage_descriptor", "temporary_descriptor", "temporary_root_descriptor", "parent_descriptor", "root_descriptor"):
            descriptor = getattr(self, attribute)
            if descriptor is not None:
                setattr(self, attribute, None)
                try:
                    os.close(descriptor)
                except OSError:
                    pass

    def _cleanup_temporary(self) -> None:
        if self.temporary_descriptor is not None and self.temporary_file_name is not None and self.temporary_file_identity is not None:
            if _posix_retire_owned_entry(
                self.temporary_descriptor, self.temporary_file_name,
                self.temporary_file_identity, stat.S_IFREG,
            ):
                self.temporary_file_name = None
                self.temporary_file_identity = None
        if self.temporary_root_descriptor is not None and self.temporary_name is not None and self.temporary_identity is not None:
            if _posix_retire_owned_entry(
                self.temporary_root_descriptor, self.temporary_name,
                self.temporary_identity, stat.S_IFDIR,
            ):
                self.temporary_name = None
                self.temporary_identity = None

    def _reopen_parent(self) -> int:
        if self._operation_bound_parent:
            if self.parent_descriptor is None or self.parent_identity is None:
                raise RecoveryError("materialization destination parent is unavailable")
            parent = os.dup(self.parent_descriptor)
            information = os.fstat(parent)
            if (int(information.st_dev), int(information.st_ino)) != self.parent_identity:
                os.close(parent)
                raise RecoveryError("materialization destination parent changed")
            return parent
        if self.trusted_root is not None:
            if self.root_descriptor is None or self.root_identity is None:
                raise RecoveryError("trusted recovery root is unavailable")
            current_root, current_identity = _posix_open_directory_path(self.trusted_root)
            os.close(current_root)
            if current_identity != self.root_identity:
                raise RecoveryError("trusted recovery root changed")
            parent, identity = _posix_open_directory_from_root(
                self.root_descriptor, self.trusted_root, self.stage.parent,
            )
        else:
            parent, identity = _posix_open_directory_path(self.stage.parent)
        if identity != self.parent_identity:
            os.close(parent)
            raise RecoveryError("materialization destination parent changed")
        return parent

    def validate(self) -> None:
        if self.parent_descriptor is None or self.stage_descriptor is None:
            raise RecoveryError("materialization destination is unavailable")
        reopened: int | None = None
        try:
            reopened = self._reopen_parent()
            held_parent = os.fstat(self.parent_descriptor)
            held_stage = os.fstat(self.stage_descriptor)
            if ((int(held_parent.st_dev), int(held_parent.st_ino)) != self.parent_identity
                    or (int(held_stage.st_dev), int(held_stage.st_ino)) != self.stage_identity):
                raise RecoveryError("materialization destination changed")
            name = self.destination.name if self.published else self.stage.name
            named = os.stat(name, dir_fd=self.parent_descriptor, follow_symlinks=False)
            if (not stat.S_ISDIR(named.st_mode)
                    or (int(named.st_dev), int(named.st_ino)) != self.stage_identity):
                raise RecoveryError("materialization destination changed")
        except RecoveryError:
            raise
        except OSError as error:
            raise RecoveryError("materialization destination changed") from error
        finally:
            if reopened is not None:
                os.close(reopened)

    def open_output_parent(self, parts: tuple[str, ...]) -> tuple[int, tuple[tuple[str, tuple[int, int]], ...]]:
        if self.stage_descriptor is None or not parts:
            raise RecoveryError("materialization destination is unavailable")
        self.validate()
        cursor: int | None = os.dup(self.stage_descriptor)
        ancestry: list[tuple[str, tuple[int, int]]] = []
        try:
            for component in parts[:-1]:
                if component in {"", ".", ".."} or os.sep in component or "\x00" in component:
                    raise RecoveryError("materialization destination is unsafe")
                created_here = False
                try:
                    os.stat(component, dir_fd=cursor, follow_symlinks=False)
                except FileNotFoundError:
                    os.mkdir(component, mode=0o700, dir_fd=cursor)
                    created_here = True
                child = _posix_open_directory_child(cursor, component)
                information = os.fstat(child)
                identity = (int(information.st_dev), int(information.st_ino))
                ancestry.append((component, identity))
                # Record only directories this operation actually created.
                # Existing directories are intentionally outside rollback
                # ownership, even when they are used as output parents.
                if created_here:
                    self.owned_entries.append((tuple(ancestry[:-1]), component, identity, True))
                os.close(cursor)
                cursor = child
            result = cursor
            cursor = None
            self.validate_output_parent(tuple(ancestry), result)
            return result, tuple(ancestry)
        finally:
            if cursor is not None:
                os.close(cursor)

    def validate_output_parent(
        self,
        ancestry: tuple[tuple[str, tuple[int, int]], ...],
        held_descriptor: int,
    ) -> None:
        if self.stage_descriptor is None:
            raise RecoveryError("materialization destination is unavailable")
        self.validate()
        cursor: int | None = os.dup(self.stage_descriptor)
        try:
            for component, expected in ancestry:
                child = _posix_open_directory_child(cursor, component)
                os.close(cursor)
                cursor = child
                information = os.fstat(cursor)
                if (int(information.st_dev), int(information.st_ino)) != expected:
                    raise RecoveryError("materialization destination changed")
            held = os.fstat(held_descriptor)
            current = os.fstat(cursor)
            if ((int(held.st_dev), int(held.st_ino))
                    != (int(current.st_dev), int(current.st_ino))):
                raise RecoveryError("materialization destination changed")
        finally:
            if cursor is not None:
                os.close(cursor)

    def validate_outputs(self) -> None:
        """Re-resolve every completed output below the still-bound stage."""
        if self.stage_descriptor is None:
            raise RecoveryError("materialization destination is unavailable")
        for ancestry, name, expected_identity in self.outputs:
            cursor: int | None = os.dup(self.stage_descriptor)
            try:
                for component, expected_parent in ancestry:
                    child = _posix_open_directory_child(cursor, component)
                    os.close(cursor)
                    cursor = child
                    information = os.fstat(cursor)
                    if (int(information.st_dev), int(information.st_ino)) != expected_parent:
                        raise RecoveryError("materialization destination changed")
                current = os.stat(name, dir_fd=cursor, follow_symlinks=False)
                if (not stat.S_ISREG(current.st_mode)
                        or (int(current.st_dev), int(current.st_ino)) != expected_identity):
                    raise RecoveryError("materialization destination changed")
            except RecoveryError:
                raise
            except OSError as error:
                raise RecoveryError("materialization destination changed") from error
            finally:
                if cursor is not None:
                    os.close(cursor)

    def cleanup(self) -> None:
        self._cleanup_temporary()
        if self.stage_descriptor is None:
            return
        # Remove completed output files before the operation-owned directories.
        # The output manifest is the authority for file ownership; identity
        # checks happen against held descriptors immediately before retirement
        # so replacements and injected entries are preserved.
        for ancestry, name, identity in sorted(
            self.outputs, key=lambda item: len(item[0]), reverse=True
        ):
            cursor: int | None = None
            try:
                cursor = os.dup(self.stage_descriptor)
                for component, expected in ancestry:
                    child = _posix_open_directory_child(cursor, component)
                    os.close(cursor)
                    cursor = child
                current = os.stat(name, dir_fd=cursor, follow_symlinks=False)
                if (stat.S_ISREG(current.st_mode)
                        and (int(current.st_dev), int(current.st_ino)) == identity):
                    _posix_retire_owned_entry(cursor, name, identity, current.st_mode)
            except (FileNotFoundError, OSError, RecoveryError):
                pass
            finally:
                if cursor is not None:
                    os.close(cursor)

        # Remove only operation-owned directories, from leaves upward.
        # Identity checks happen against the held parent descriptor immediately
        # before removal; replacements and injected entries are preserved.
        for ancestry, name, identity, is_directory in sorted(
            self.owned_entries, key=lambda item: len(item[0]), reverse=True
        ):
            cursor: int | None = None
            try:
                cursor = os.dup(self.stage_descriptor)
                for component, expected in ancestry:
                    child = _posix_open_directory_child(cursor, component)
                    os.close(cursor)
                    cursor = child
                current = os.stat(name, dir_fd=cursor, follow_symlinks=False)
                current_identity = (int(current.st_dev), int(current.st_ino))
                if current_identity != identity:
                    continue
                if is_directory and stat.S_ISDIR(current.st_mode):
                    _posix_retire_owned_entry(cursor, name, identity, current.st_mode)
                elif not is_directory and stat.S_ISREG(current.st_mode):
                    _posix_retire_owned_entry(cursor, name, identity, current.st_mode)
            except (FileNotFoundError, OSError, RecoveryError):
                pass
            finally:
                if cursor is not None:
                    os.close(cursor)
        if self.parent_descriptor is None or self.stage_identity is None:
            return
        for name in (self.destination.name, self.stage.name):
            try:
                current = os.stat(name, dir_fd=self.parent_descriptor, follow_symlinks=False)
                if (not stat.S_ISDIR(current.st_mode)
                        or (int(current.st_dev), int(current.st_ino)) != self.stage_identity):
                    continue
                if _posix_retire_owned_entry(
                    self.parent_descriptor, name, self.stage_identity, current.st_mode,
                ):
                    return
            except (FileNotFoundError, OSError):
                continue

    def publish(self) -> None:
        if self.parent_descriptor is None:
            raise RecoveryError("materialization destination is unavailable")
        self.validate()
        self.validate_outputs()
        _posix_rename_directory_noreplace(
            self.parent_descriptor, self.stage.name, self.destination.name,
        )
        self.published = True
        try:
            self.validate()
            # The rename commits the complete tree, but nested output names
            # can still be replaced concurrently. Revalidate the full
            # manifest after publication before reporting success.
            self.validate_outputs()
            os.fsync(self.parent_descriptor)
        except Exception:
            self.cleanup()
            raise


_PathFlavor = type(Path())


class _GuardedPosixStagePath(_PathFlavor):
    """Path-compatible carrier that preserves the legacy publication seam."""

    def __new__(cls, path: Path, guard: _PosixStageGuard):
        value = super().__new__(cls, path)
        value.posix_guard = guard
        return value

    def __init__(self, path: Path, guard: _PosixStageGuard) -> None:
        super().__init__(path)


def _write_chunks_to_posix_stage(
    chunks: Iterable[bytes],
    guard: _PosixStageGuard,
    relative: Path,
) -> tuple[int, str]:
    """Write chunks to an anonymous inode, then publish under a verified parent."""
    parts = tuple(relative.parts)
    parent_descriptor, ancestry = guard.open_output_parent(parts)
    private_descriptor: int | None = None
    temporary_name: str | None = None
    temporary_identity: tuple[int, int] | None = None
    published_identity: tuple[int, int] | None = None
    digest = hashlib.sha256()
    size = 0
    try:
        temporary_flag = getattr(os, "O_TMPFILE", 0)
        if temporary_flag:
            try:
                private_descriptor = _open_posix_tmpfile(parent_descriptor, temporary_flag)
            except OSError as error:
                # O_TMPFILE is Linux-specific and is rejected by macOS,
                # WSL DrvFS, and several otherwise-POSIX filesystems.  Only
                # capability errors select the portable named-temp route;
                # permission and I/O failures remain hard failures.
                unsupported = {
                    getattr(errno, "EOPNOTSUPP", 95), errno.EINVAL,
                    getattr(errno, "ENOTSUP", getattr(errno, "EOPNOTSUPP", 95)),
                    getattr(errno, "ENOSYS", 38), errno.EISDIR,
                }
                if error.errno not in unsupported:
                    raise
        if private_descriptor is None:
            # The name is created relative to a private operation directory
            # anchored at the configured trusted root. It is never exposed as
            # a completed output and is removed by descriptor-bound cleanup.
            if guard.temporary_descriptor is None:
                raise RecoveryError("safe recovery temporary storage is unavailable")
            temporary_name = f"output-{uuid4().hex}.tmp"
            private_descriptor = os.open(
                temporary_name,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
                dir_fd=guard.temporary_descriptor,
            )
            temporary = os.fstat(private_descriptor)
            temporary_identity = (int(temporary.st_dev), int(temporary.st_ino))
            guard.temporary_file_name = temporary_name
            guard.temporary_file_identity = temporary_identity
        with os.fdopen(os.dup(private_descriptor), "wb", closefd=True) as output_handle:
            for chunk in chunks:
                if not chunk:
                    continue
                digest.update(chunk)
                size += len(chunk)
                output_handle.write(chunk)
            output_handle.flush()
            os.fsync(output_handle.fileno())
        # Capture the inode identity before publication.  The descriptor is
        # the stable ownership proof; querying the public pathname after the
        # commit would reintroduce the replacement race this path avoids.
        private = os.fstat(private_descriptor)
        published_identity = (int(private.st_dev), int(private.st_ino))
        guard.validate_output_parent(ancestry, parent_descriptor)
        if temporary_name is None:
            _posix_link_descriptor(private_descriptor, parent_descriptor, parts[-1])
        else:
            # Atomic no-replace rename is the commit point.  It neither
            # exposes a placeholder nor follows a pathname after publication.
            _posix_link_named_noreplace_from(
                guard.temporary_descriptor, temporary_name, parent_descriptor, parts[-1],
            )
            retired = _posix_retire_owned_entry(
                guard.temporary_descriptor, temporary_name, temporary_identity,
                stat.S_IFREG,
            )
            if retired:
                temporary_name = None
                guard.temporary_file_name = None
                guard.temporary_file_identity = None
        guard.owned_entries.append((ancestry, parts[-1], published_identity, False))
        guard.outputs.append((ancestry, parts[-1], published_identity))
        return size, digest.hexdigest()
    except (RecoveryError, OSError) as error:
        if published_identity is not None:
            try:
                current = os.stat(parts[-1], dir_fd=parent_descriptor, follow_symlinks=False)
                if stat.S_ISREG(current.st_mode) and (int(current.st_dev), int(current.st_ino)) == published_identity:
                    _posix_retire_owned_entry(
                        parent_descriptor, parts[-1], published_identity, current.st_mode,
                    )
            except (FileNotFoundError, OSError):
                pass
        if isinstance(error, RecoveryError):
            raise
        if isinstance(error, FileNotFoundError):
            raise RecoveryError("materialization destination changed") from error
        raise RecoveryError("materialized checksum failure") from error
    finally:
        if temporary_name is not None:
            try:
                temporary_parent = guard.temporary_descriptor
                if temporary_parent is None:
                    raise OSError(errno.ENOENT, "temporary storage unavailable")
                current = os.stat(temporary_name, dir_fd=temporary_parent, follow_symlinks=False)
                if (stat.S_ISREG(current.st_mode)
                        and temporary_identity is not None
                        and (int(current.st_dev), int(current.st_ino)) == temporary_identity):
                    _posix_retire_owned_entry(
                        temporary_parent, temporary_name, temporary_identity, current.st_mode,
                    )
            except OSError:
                pass
        if private_descriptor is not None:
            os.close(private_descriptor)
        os.close(parent_descriptor)


def _open_posix_tmpfile(parent_descriptor: int, temporary_flag: int) -> int:
    """Create an anonymous POSIX temporary file relative to *parent_descriptor*."""
    return os.open(".", os.O_RDWR | temporary_flag, 0o600, dir_fd=parent_descriptor)


def _copy_to_posix_stage(source: Path, guard: _PosixStageGuard, relative: Path) -> tuple[int, str]:
    """Copy a source file without ever attaching its bytes to the placeholder."""
    try:
        handle = source.open("rb")
    except OSError as error:
        raise RecoveryError("recovery source is unavailable") from error
    with handle:
        return _write_chunks_to_posix_stage(
            iter(lambda: handle.read(1024 * 1024), b""), guard, relative,
        )


def _copy_bound_file_to_posix_stage(source_descriptor: int, guard: _PosixStageGuard, relative: Path) -> tuple[int, str]:
    """Copy a regular file through a held source directory capability."""
    descriptor = _posix_open_regular_file_from_directory(source_descriptor, relative)
    try:
        opened = os.fstat(descriptor)
        with os.fdopen(descriptor, "rb", closefd=False) as handle:
            result = _write_chunks_to_posix_stage(iter(lambda: handle.read(1024 * 1024), b""), guard, relative)
        after = os.fstat(descriptor)
        if (int(opened.st_dev), int(opened.st_ino)) != (int(after.st_dev), int(after.st_ino)):
            raise RecoveryError("recovery file was replaced")
        os.close(descriptor)
        descriptor = -1
        return result
    finally:
        if descriptor != -1:
            os.close(descriptor)


def _write_json_posix_stage(guard: _PosixStageGuard, relative: Path, value: Mapping[str, Any]) -> None:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    _write_chunks_to_posix_stage((payload,), guard, relative)


def _publish_directory_noreplace(
    stage: Path,
    destination: Path,
) -> None:
    """Atomically publish a directory without replacing a concurrent winner."""
    if os.name == "posix":
        posix_guard = getattr(stage, "posix_guard", None)
        if posix_guard is not None:
            posix_guard.publish()
            return
        parent_fd = os.open(stage.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            _posix_rename_directory_noreplace(parent_fd, stage.name, destination.name)
        finally:
            os.close(parent_fd)
        return
    # MoveFileEx with no replace flag gives Windows the same atomic
    # no-overwrite contract, including when a destination appears concurrently.
    if os.name == "nt":
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.MoveFileExW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint]
        kernel32.MoveFileExW.restype = ctypes.c_int
        if not kernel32.MoveFileExW(str(stage), str(destination), 0):
            error_number = ctypes.get_last_error()
            if error_number in {80, 183}:  # ERROR_FILE_EXISTS / ERROR_ALREADY_EXISTS
                raise RecoveryError("recovery destination already exists")
            raise RecoveryError("recovery publication failed")
        return
    raise RecoveryError("safe recovery publication is unavailable")


def _windows_move_noreplace(source: Path, destination: Path) -> bool:
    """Atomically move a path to a new name without replacing a winner."""
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.MoveFileExW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint]
    kernel32.MoveFileExW.restype = ctypes.c_int
    # A zero flag rejects an existing destination and performs the rename as
    # one filesystem operation.  MOVEFILE_REPLACE_EXISTING is intentionally
    # never used for cleanup.
    return bool(kernel32.MoveFileExW(str(source), str(destination), 0))


def _windows_open_directory(path: Path) -> tuple[int, tuple[int, int]]:
    """Open one non-reparse directory while denying rename/delete by name."""
    if os.name != "nt":
        raise RecoveryError("Windows cold cleanup is unavailable")
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateFileW.argtypes = [
        ctypes.c_wchar_p, wintypes.DWORD, wintypes.DWORD,
        ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE,
    ]
    kernel32.CreateFileW.restype = wintypes.HANDLE
    access = 0x00010000 | 0x00000001 | 0x00000080 | 0x00100000  # DELETE, LIST, ATTRIBUTES, SYNCHRONIZE
    share = 0x00000001 | 0x00000002  # read/write; deliberately no FILE_SHARE_DELETE
    flags = 0x02000000 | 0x00200000  # FILE_FLAG_BACKUP_SEMANTICS | OPEN_REPARSE_POINT
    handle = kernel32.CreateFileW(str(path), access, share, None, 3, flags, None)
    invalid = ctypes.c_void_p(-1).value
    if handle == invalid:
        raise RecoveryError("cold retention directory cannot be opened safely")
    descriptor = int(handle)
    try:
        before = os.stat(path, follow_symlinks=False)
        if not stat.S_ISDIR(before.st_mode) or _is_reparse_point(path):
            raise RecoveryError("cold retention directory is unsafe")
        current = os.stat(path, follow_symlinks=False)
        identity = (int(before.st_dev), int(before.st_ino))
        if (int(current.st_dev), int(current.st_ino)) != identity:
            raise RecoveryError("cold retention directory was replaced")
        return descriptor, identity
    except (OSError, RecoveryError):
        _windows_close_handle(descriptor)
        raise


def _windows_close_handle(handle: int) -> None:
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.CloseHandle(wintypes.HANDLE(handle))


def _windows_handle_path(handle: int) -> Path:
    """Return the current name of the exact Windows object held by *handle*."""
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetFinalPathNameByHandleW.argtypes = [
        wintypes.HANDLE, ctypes.c_wchar_p, wintypes.DWORD, wintypes.DWORD,
    ]
    kernel32.GetFinalPathNameByHandleW.restype = wintypes.DWORD
    size = 512
    while size <= 32768:
        buffer = ctypes.create_unicode_buffer(size)
        length = kernel32.GetFinalPathNameByHandleW(
            wintypes.HANDLE(handle), buffer, size, 0,
        )
        if length == 0:
            break
        if length < size:
            return Path(buffer.value)
        size *= 2
    raise RecoveryError("cold retention handle path cannot be resolved")


def _windows_mark_handle_deleted(handle: int) -> None:
    class Disposition(ctypes.Structure):
        _fields_ = [("delete_file", wintypes.BOOLEAN)]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.SetFileInformationByHandle.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
    ]
    kernel32.SetFileInformationByHandle.restype = wintypes.BOOL
    disposition = Disposition(1)
    if not kernel32.SetFileInformationByHandle(
            wintypes.HANDLE(handle), 4, ctypes.byref(disposition), ctypes.sizeof(disposition)):
        raise RecoveryError("cold retention entry cannot be deleted safely")


def _windows_remove_bound_directory(path: Path, expected_identity: tuple[int, int]) -> None:
    """Delete a directory tree through Windows handles, never by pathname."""
    handle, identity = _windows_open_directory(path)
    try:
        _windows_remove_bound_directory_handle(path, handle, identity, expected_identity)
    finally:
        _windows_close_handle(handle)


def _windows_remove_bound_directory_handle(
        path: Path, handle: int, identity: tuple[int, int], expected_identity: tuple[int, int],
    ) -> None:
    if identity != expected_identity:
        raise RecoveryError("obsolete cold copy was replaced")
    # Resolve enumeration from the held directory object.  Enumerating the
    # caller's mutable pathname can enter a replacement namespace between the
    # initial identity check and the first child operation.
    bound_path = _windows_handle_path(handle)
    for name in os.listdir(bound_path):
        child = bound_path / name
        try:
            before = os.stat(child, follow_symlinks=False)
        except FileNotFoundError:
            continue
        except OSError as error:
            raise RecoveryError("obsolete cold copy cannot be inspected") from error
        if stat.S_ISLNK(before.st_mode) or _is_reparse_point(child):
            raise RecoveryError("obsolete cold copy is unsafe")
        child_handle, child_identity = _windows_open_directory(child) if stat.S_ISDIR(before.st_mode) else _windows_open_file(child)
        try:
            if child_identity != (int(before.st_dev), int(before.st_ino)):
                raise RecoveryError("obsolete cold copy was replaced")
            if stat.S_ISDIR(before.st_mode):
                _windows_remove_bound_directory_handle(child, child_handle, child_identity, child_identity)
            else:
                _windows_mark_handle_deleted(child_handle)
        finally:
            _windows_close_handle(child_handle)
    try:
        current = os.stat(bound_path, follow_symlinks=False)
    except OSError as error:
        raise RecoveryError("obsolete cold copy ownership cannot be verified") from error
    if (int(current.st_dev), int(current.st_ino)) != identity:
        raise RecoveryError("obsolete cold copy was replaced")
    _windows_mark_handle_deleted(handle)


def _windows_open_file(path: Path) -> tuple[int, tuple[int, int]]:
    """Open a regular file for handle-bound deletion without following links."""
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateFileW.argtypes = [
        ctypes.c_wchar_p, wintypes.DWORD, wintypes.DWORD,
        ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE,
    ]
    kernel32.CreateFileW.restype = wintypes.HANDLE
    access = 0x00010000 | 0x00000080 | 0x00100000  # DELETE, ATTRIBUTES, SYNCHRONIZE
    share = 0x00000001 | 0x00000002
    flags = 0x00200000  # FILE_FLAG_OPEN_REPARSE_POINT
    handle = kernel32.CreateFileW(str(path), access, share, None, 3, flags, None)
    invalid = ctypes.c_void_p(-1).value
    if handle == invalid:
        raise RecoveryError("obsolete cold copy file cannot be opened safely")
    descriptor = int(handle)
    try:
        before = os.stat(path, follow_symlinks=False)
        if not stat.S_ISREG(before.st_mode) or _is_reparse_point(path):
            raise RecoveryError("obsolete cold copy is unsafe")
        return descriptor, (int(before.st_dev), int(before.st_ino))
    except (OSError, RecoveryError):
        _windows_close_handle(descriptor)
        raise


def _cleanup_names(stage: Path) -> tuple[Path, Path, Path]:
    """Return deterministic quarantine, record, and reconciled names."""
    suffix = ".pending"
    if not stage.name.endswith(suffix):
        raise RecoveryError("invalid failed-stage name")
    stem = stage.name[: -len(suffix)]
    return (
        stage.with_name(f"{stem}.cleanup"),
        stage.with_name(f"{stem}.cleanup.json"),
        stage.with_name(f"{stem}.reconciled"),
    )


def _cleanup_mac(secret: bytes, state: str, quarantine: str, identity: tuple[int, int]) -> str:
    payload = f"{state}\0{quarantine}\0{identity[0]}\0{identity[1]}".encode("utf-8")
    return hmac.new(secret, payload, hashlib.sha256).hexdigest()


def _remove_owned_stage(stage: Path, identity: tuple[int, int], secret: bytes | None = None) -> None:
    """Remove a failed stage only after binding it to its verified directory."""
    if os.name == "nt":
        if not secret:
            return
        # Windows has no portable descriptor-relative recursive remover.  An
        # atomic no-replace rename removes the public name, then ownership is
        # checked again.  The private quarantine is deliberately retained as
        # durable reconciliation state; it is never recursively deleted by
        # path after a racy name lookup.
        quarantine, record, _ = _cleanup_names(stage)
        try:
            if _entry_present(quarantine) or _entry_present(record):
                return
            # Bind the record to the stage only after confirming that the
            # observed entry is still the owned, ordinary directory.  The
            # record must never replace a pre-existing foreign entry.
            try:
                observed = os.stat(stage, follow_symlinks=False)
                if (stat.S_ISLNK(observed.st_mode) or not stat.S_ISDIR(observed.st_mode)
                        or _is_reparse_point(stage)
                        or (int(observed.st_dev), int(observed.st_ino)) != identity):
                    return
            except (OSError, RecoveryError):
                return
            # Persist the observed identity before moving the name.  This
            # makes a crash between rename and record update reconstructible,
            # while a name-only quarantine remains untrusted.
            try:
                if not _write_json_noreplace(record, {"state": "quarantine_pending", "quarantine": quarantine.name, "identity": list(identity), "mac": _cleanup_mac(secret, "quarantine_pending", quarantine.name, identity)}):
                    return
                with _open_verified_cleanup_record(record) as (record_fd, record_identity):
                    if not _windows_move_noreplace(stage, quarantine):
                        return
                    moved_stat = quarantine.stat()
                    moved_identity = (int(moved_stat.st_dev), int(moved_stat.st_ino))
                    if moved_identity == identity:
                        _write_json_cleanup_record(record_fd, record, record_identity, {"state": "reconciliation_required", "quarantine": quarantine.name, "identity": list(identity), "mac": _cleanup_mac(secret, "reconciliation_required", quarantine.name, identity)})
                        return
            # A foreign replacement was encountered.  Restore it only when
            # the public name is still absent; no-replace preserves a newer
            # foreign winner if another actor populated it meanwhile.
                    if not _entry_present(quarantine):
                        return
                    _windows_move_noreplace(quarantine, stage)
                    _write_json_cleanup_record(record_fd, record, record_identity, {"state": "foreign_replacement", "quarantine": quarantine.name, "identity": list(moved_identity), "mac": _cleanup_mac(secret, "foreign_replacement", quarantine.name, moved_identity)})
                    return
            except RecoveryError:
                raise
            except Exception:
                return
        except OSError:
            # The stage or quarantine remains for explicit reconciliation.
            return
    elif os.name != "posix":
        return

    parent_fd = os.open(stage.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    quarantine = f".cleanup-{uuid4().hex}"
    try:
        os.mkdir(quarantine, mode=0o700, dir_fd=parent_fd)
        quarantine_stat = os.stat(quarantine, dir_fd=parent_fd, follow_symlinks=False)
        quarantine_identity = (int(quarantine_stat.st_dev), int(quarantine_stat.st_ino))
        # Exchange first: a concurrent replacement at the public name is
        # moved to quarantine and can be restored without ever being removed.
        try:
            renameat2 = getattr(ctypes.CDLL(None, use_errno=True), "renameat2")
        except (AttributeError, OSError):
            return
        renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        renameat2.restype = ctypes.c_int
        if renameat2(parent_fd, os.fsencode(stage.name), parent_fd, os.fsencode(quarantine), 2):
            return
        moved = os.stat(quarantine, dir_fd=parent_fd, follow_symlinks=False)
        moved_identity = (int(moved.st_dev), int(moved.st_ino))
        if moved_identity != identity:
            renameat2(parent_fd, os.fsencode(quarantine), parent_fd, os.fsencode(stage.name), 2)
            return
        quarantine_fd = os.open(quarantine, os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0), dir_fd=parent_fd)
        try:
            _remove_owned_tree_fd(quarantine_fd)
        finally:
            os.close(quarantine_fd)
        # The exchange leaves our empty marker at the public stage name. Move
        # that marker to a private tombstone with an atomic no-replace rename,
        # then verify its identity. This retires the interrupted public name
        # without a name-based unlink race; if a foreign replacement wins the
        # name first, preserve it and leave deterministic reconciliation state.
        # Keep the destination absent: RENAME_NOREPLACE requires an unused
        # destination and protects against a same-name foreign winner.
        marker_tombstone = f".cleanup-{uuid4().hex}"
        try:
            renameat2(parent_fd, os.fsencode(stage.name), parent_fd,
                      os.fsencode(marker_tombstone), 1)  # RENAME_NOREPLACE
            retired = os.stat(marker_tombstone, dir_fd=parent_fd, follow_symlinks=False)
            retired_identity = (int(retired.st_dev), int(retired.st_ino))
            if retired_identity != quarantine_identity:
                try:
                    renameat2(parent_fd, os.fsencode(marker_tombstone), parent_fd,
                              os.fsencode(stage.name), 1)
                except OSError:
                    pass
        except (AttributeError, OSError):
            # Capability or race failure is recoverable state; do not fall
            # back to rmdir/unlink by name, which could delete a replacement.
            pass
    finally:
        os.close(parent_fd)


def _remove_owned_tree_fd(directory_fd: int) -> None:
    """Recursively remove entries relative to a held directory descriptor."""
    for name in os.listdir(directory_fd):
        current = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
        expected = (int(current.st_dev), int(current.st_ino))
        quarantine = f".cleanup-entry-{uuid4().hex}"
        os.mkdir(quarantine, mode=0o700, dir_fd=directory_fd)
        try:
            renameat2 = getattr(ctypes.CDLL(None, use_errno=True), "renameat2")
            renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
            renameat2.restype = ctypes.c_int
            if renameat2(directory_fd, os.fsencode(name), directory_fd, os.fsencode(quarantine), 2):
                # Retain the emptied marker: a final name-based rmdir would
                # be able to delete a replacement installed after the last
                # identity check.
                continue
            moved = os.stat(quarantine, dir_fd=directory_fd, follow_symlinks=False)
            moved_identity = (int(moved.st_dev), int(moved.st_ino))
            if moved_identity != expected:
                renameat2(directory_fd, os.fsencode(quarantine), directory_fd, os.fsencode(name), 2)
                # Retain the emptied marker for the same replacement fence.
                continue
            if stat.S_ISDIR(moved.st_mode):
                child_fd = os.open(quarantine, os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0), dir_fd=directory_fd)
                try:
                    bound = os.fstat(child_fd)
                    if ((int(bound.st_dev), int(bound.st_ino)) != expected
                            or not stat.S_ISDIR(bound.st_mode)):
                        continue
                    _remove_owned_tree_fd(child_fd)
                finally:
                    os.close(child_fd)
                # Retain the emptied marker: a final name-based rmdir would
                # be able to delete a replacement installed after the last
                # identity check.
            elif stat.S_ISREG(moved.st_mode):
                # Erase content through the descriptor-bound marker.  The
                # marker itself is retained as deterministic evidence, so no
                # later name-based unlink can remove a replacement.
                file_fd = os.open(quarantine, os.O_WRONLY | getattr(os, "O_NOFOLLOW", 0), dir_fd=directory_fd)
                try:
                    bound = os.fstat(file_fd)
                    if ((int(bound.st_dev), int(bound.st_ino)) != expected
                            or not stat.S_ISREG(bound.st_mode)):
                        continue
                    os.ftruncate(file_fd, 0)
                    os.fsync(file_fd)
                finally:
                    os.close(file_fd)
        except (AttributeError, OSError):
            # Keep both the entry and its private marker for reconciliation;
            # never fall back to a path-based deletion after a capability gap.
            continue


@dataclass(frozen=True)
class RecoveryConfig:
    local_root: Path
    cold_root: Path | None
    capacity_bytes: int
    retention_buckets_seconds: tuple[int, ...] = (3600, 10800, 86400, 259200)
    degraded_rpo_seconds: int = 300
    token_file: Path | None = None

    def __post_init__(self) -> None:
        _safe_directory(self.local_root, create=True)
        if self.cold_root is not None:
            _safe_directory(self.cold_root, create=True)
        if type(self.capacity_bytes) is not int or not 1 <= self.capacity_bytes <= MAX_TOTAL_BYTES:
            raise RecoveryError("capacity must be a bounded positive integer")
        if type(self.degraded_rpo_seconds) is not int or not 1 <= self.degraded_rpo_seconds <= 86400:
            raise RecoveryError("RPO bound is invalid")
        if (not self.retention_buckets_seconds or any(type(item) is not int or item <= 0 for item in self.retention_buckets_seconds)
                or tuple(sorted(set(self.retention_buckets_seconds))) != self.retention_buckets_seconds):
            raise RecoveryError("retention buckets must be sorted positive seconds")
        if self.token_file is not None:
            _safe_existing_token(self.token_file)


class RecoveryService:
    """Single-writer local recovery catalogue; cold work is explicit only."""

    def __init__(self, configuration: RecoveryConfig, *, clock: callable = _now):
        self.config = configuration
        self.clock = clock
        self._policy_path = self.config.local_root / "recovery-policy.json"
        self._queue_path = self.config.local_root / "cold-copy-queue.json"
        self._cold_root_identity = None
        if self.config.cold_root is not None:
            information = os.stat(self.config.cold_root, follow_symlinks=False)
            self._cold_root_identity = (int(information.st_dev), int(information.st_ino))

    @contextmanager
    def _bound_local_root(self):
        """Hold the configured catalogue root for one public operation.

        On POSIX all catalogue names are subsequently resolved relative to this
        descriptor.  This is important when an operator (or an attacker) swaps
        the configured pathname while a journal operation is in flight.
        """
        if os.name == "posix":
            flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
            try:
                descriptor = os.open(self.config.local_root, flags)
                information = os.fstat(descriptor)
                current = os.stat(self.config.local_root, follow_symlinks=False)
                if (int(information.st_dev), int(information.st_ino)) != (int(current.st_dev), int(current.st_ino)):
                    raise RecoveryError("recovery root was replaced")
            except (OSError, RecoveryError) as error:
                try:
                    os.close(descriptor)
                except (UnboundLocalError, OSError):
                    pass
                raise RecoveryError("recovery root is unavailable") from error
            try:
                yield descriptor
            finally:
                os.close(descriptor)
        else:
            _safe_directory(self.config.local_root)
            yield None

    @staticmethod
    def _read_json_fd_with_identity(descriptor: int, name: str,
                                    default: Mapping[str, Any]) -> tuple[dict[str, Any], tuple[int, int] | None]:
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
        try:
            handle = os.open(name, flags, dir_fd=descriptor)
        except FileNotFoundError:
            return dict(default), None
        except OSError as error:
            raise RecoveryError("recovery journal is unsafe") from error
        try:
            opened = os.fstat(handle)
            named = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
            if (not stat.S_ISREG(opened.st_mode)
                    or (int(opened.st_dev), int(opened.st_ino)) !=
                    (int(named.st_dev), int(named.st_ino))):
                raise RecoveryError("recovery journal was replaced")
            with os.fdopen(handle, "r", encoding="utf-8", closefd=True) as stream:
                handle = -1
                value = json.load(stream)
        except RecoveryError:
            raise
        except (OSError, ValueError) as error:
            raise RecoveryError("recovery journal is malformed") from error
        finally:
            if handle != -1:
                os.close(handle)
        if not isinstance(value, dict):
            raise RecoveryError("recovery journal is malformed")
        return value, (int(opened.st_dev), int(opened.st_ino))

    @staticmethod
    def _read_json_fd(descriptor: int, name: str, default: Mapping[str, Any]) -> dict[str, Any]:
        return RecoveryService._read_json_fd_with_identity(descriptor, name, default)[0]

    @staticmethod
    def _write_json_fd(descriptor: int, name: str, value: Mapping[str, Any],
                       expected_identity: tuple[int, int] | None = None) -> None:
        payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        temporary = f".{name}.{uuid4().hex}.pending"
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
        fd = os.open(temporary, flags, 0o600, dir_fd=descriptor)
        try:
            with os.fdopen(fd, "wb", closefd=True) as stream:
                fd = -1
                stream.write(payload)
                stream.flush(); os.fsync(stream.fileno())
            if os.name == "posix":
                _posix_publish_json(descriptor, temporary, name, expected_identity)
            else:
                if expected_identity is not None:
                    try:
                        current = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
                    except OSError as error:
                        raise RecoveryError("recovery journal publication target was replaced") from error
                    if (int(current.st_dev), int(current.st_ino)) != expected_identity:
                        raise RecoveryError("recovery journal publication target was replaced")
                else:
                    try:
                        os.stat(name, dir_fd=descriptor, follow_symlinks=False)
                    except FileNotFoundError:
                        pass
                    except OSError as error:
                        raise RecoveryError("recovery journal publication target was replaced") from error
                    else:
                        raise RecoveryError("recovery journal publication target was replaced")
                os.replace(temporary, name, src_dir_fd=descriptor, dst_dir_fd=descriptor)
            os.fsync(descriptor)
        finally:
            if fd != -1:
                os.close(fd)
            try:
                os.unlink(temporary, dir_fd=descriptor)
            except FileNotFoundError:
                pass
            except OSError:
                pass

    @contextmanager
    def _journal_lock(self, name: str, root_descriptor: int | None = None):
        """Fail closed across processes; a stale lock is explicit reconciliation."""
        path = self.config.local_root / f".{name}.lock"
        lock_name = f".{name}.lock"
        try:
            if root_descriptor is not None:
                descriptor = os.open(lock_name, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600, dir_fd=root_descriptor)
            else:
                descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as error:
            raise RecoveryError("recovery journal writer is active or needs reconciliation") from error
        try:
            opened = os.fstat(descriptor)
            lock_identity = (int(opened.st_dev), int(opened.st_ino))
            os.write(descriptor, self.clock().encode("ascii")); os.fsync(descriptor)
            yield
        finally:
            named = None
            try:
                try:
                    if root_descriptor is not None:
                        named = os.stat(lock_name, dir_fd=root_descriptor, follow_symlinks=False)
                    else:
                        named = os.stat(path, follow_symlinks=False)
                except FileNotFoundError:
                    named = None
                except OSError as error:
                    raise RecoveryError("recovery journal lock cannot be inspected safely") from error
                if named is not None:
                    named_identity = (int(named.st_dev), int(named.st_ino))
                    bound = os.fstat(descriptor)
                    bound_identity = (int(bound.st_dev), int(bound.st_ino))
                    if named_identity != lock_identity or bound_identity != lock_identity:
                        raise RecoveryError("recovery journal lock was replaced")
            finally:
                os.close(descriptor)
            if named is not None:
                try:
                    if root_descriptor is not None:
                        os.unlink(lock_name, dir_fd=root_descriptor)
                    else:
                        os.unlink(path)
                except FileNotFoundError:
                    pass
                except OSError as error:
                    raise RecoveryError("recovery journal lock cleanup failed") from error

    def _read_json(self, path: Path, default: Mapping[str, Any]) -> dict[str, Any]:
        if not path.exists():
            return dict(default)
        if path.is_symlink() or not path.is_file():
            raise RecoveryError("recovery journal is unsafe")
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise RecoveryError("recovery journal is malformed") from error
        if not isinstance(value, dict):
            raise RecoveryError("recovery journal is malformed")
        return value

    def _policy(self) -> dict[str, Any]:
        policy = self._read_json(self._policy_path, {"projects": {}, "issued_challenges": {}, "used_challenges": []})
        if set(policy) != {"projects", "issued_challenges", "used_challenges"} or not isinstance(policy["projects"], dict) or not isinstance(policy["issued_challenges"], dict) or not isinstance(policy["used_challenges"], list):
            raise RecoveryError("recovery policy is malformed")
        return policy

    def _policy_bound(self, descriptor: int) -> dict[str, Any]:
        policy = self._read_json_fd(descriptor, "recovery-policy.json", {"projects": {}, "issued_challenges": {}, "used_challenges": []})
        if set(policy) != {"projects", "issued_challenges", "used_challenges"} or not isinstance(policy["projects"], dict) or not isinstance(policy["issued_challenges"], dict) or not isinstance(policy["used_challenges"], list):
            raise RecoveryError("recovery policy is malformed")
        return policy

    def _policy_bound_with_identity(self, descriptor: int) -> tuple[dict[str, Any], tuple[int, int] | None]:
        policy, identity = self._read_json_fd_with_identity(
            descriptor, "recovery-policy.json",
            {"projects": {}, "issued_challenges": {}, "used_challenges": []})
        if (set(policy) != {"projects", "issued_challenges", "used_challenges"}
                or not isinstance(policy["projects"], dict)
                or not isinstance(policy["issued_challenges"], dict)
                or not isinstance(policy["used_challenges"], list)):
            raise RecoveryError("recovery policy is malformed")
        return policy, identity

    def issue_skull_challenge(self, project_id: str, *, actor: str) -> str:
        _identifier(project_id)
        if actor != "human":
            raise RecoveryError("only a human may issue skull confirmation")
        with self._bound_local_root() as root_descriptor, self._journal_lock("policy", root_descriptor):
            proof = hashlib.sha256(f"{project_id}:{self.clock()}:{uuid4().hex}".encode("utf-8")).hexdigest()
            policy, journal_identity = (self._policy_bound_with_identity(root_descriptor)
                                        if root_descriptor is not None else (self._policy(), None))
            policy["issued_challenges"][proof] = project_id
            if root_descriptor is not None: self._write_json_fd(root_descriptor, "recovery-policy.json", policy, journal_identity)
            else: _write_json(self._policy_path, policy)
            return proof

    def set_project_policy(self, project_id: str, *, classification: str = "AVG", priority: int = 100, actor: str, skull_proof: str | None = None) -> dict[str, Any]:
        _identifier(project_id)
        if actor not in {"human", "codex"}:
            raise RecoveryError("only a human or Codex may change project policy")
        if classification == "skull" and actor != "human":
            raise RecoveryError("skull classification is human-only")
        if classification not in _CLASSIFICATIONS or type(priority) is not int or priority < 1:
            raise RecoveryError("classification or priority is invalid")
        with self._bound_local_root() as root_descriptor, self._journal_lock("policy", root_descriptor):
            policy, journal_identity = (self._policy_bound_with_identity(root_descriptor)
                                        if root_descriptor is not None else (self._policy(), None))
            previous = policy["projects"].get(project_id, {"classification": "AVG", "priority": 100, "pinned": []})
            if previous.get("classification") == "skull" and actor != "human":
                raise RecoveryError("skull classification is human-only")
            if previous["classification"] != "skull" and classification == "skull":
                if actor != "human" or not isinstance(skull_proof, str) or not re.fullmatch(r"[0-9a-f]{64}", skull_proof) or skull_proof in policy["used_challenges"] or policy["issued_challenges"].get(skull_proof) != project_id:
                    raise RecoveryError("one-use human skull confirmation is required")
                policy["used_challenges"].append(skull_proof)
                del policy["issued_challenges"][skull_proof]
            policy["projects"][project_id] = {"classification": classification, "priority": priority, "pinned": previous.get("pinned", [])}
            if root_descriptor is not None: self._write_json_fd(root_descriptor, "recovery-policy.json", policy, journal_identity)
            else: _write_json(self._policy_path, policy)
            return dict(policy["projects"][project_id])

    def pin_milestone(self, project_id: str, set_id: str, *, actor: str) -> None:
        if actor not in {"human", "codex", "project_orchestrator"}:
            raise RecoveryError("actor cannot pin a recovery milestone")
        _identifier(project_id); _identifier(set_id)
        with self._bound_local_root() as root_descriptor, self._journal_lock("policy", root_descriptor):
            policy, journal_identity = (self._policy_bound_with_identity(root_descriptor)
                                        if root_descriptor is not None else (self._policy(), None)); project = policy["projects"].setdefault(project_id, {"classification": "AVG", "priority": 100, "pinned": []})
            if set_id not in project["pinned"]: project["pinned"].append(set_id)
            if root_descriptor is not None: self._write_json_fd(root_descriptor, "recovery-policy.json", policy, journal_identity)
            else: _write_json(self._policy_path, policy)

    def unpin_milestone(self, project_id: str, set_id: str, *, actor: str) -> None:
        if actor not in {"human", "codex"}:
            raise RecoveryError("only human or Codex may unpin")
        with self._bound_local_root() as root_descriptor, self._journal_lock("policy", root_descriptor):
            policy, journal_identity = (self._policy_bound_with_identity(root_descriptor)
                                        if root_descriptor is not None else (self._policy(), None)); project = policy["projects"].get(project_id)
            if project and set_id in project.get("pinned", []):
                project["pinned"].remove(set_id)
                if root_descriptor is not None: self._write_json_fd(root_descriptor, "recovery-policy.json", policy, journal_identity)
                else: _write_json(self._policy_path, policy)

    def _project_directory(self, project_id: str) -> Path:
        return _child(self.config.local_root, "sets", project_id, create=True)

    def _trusted_destination_root(self, destination: Path) -> Path | None:
        """Return the deepest configured root containing a destination parent."""
        candidates: list[Path] = []
        for root in (self.config.local_root, self.config.cold_root):
            if root is None:
                continue
            try:
                destination.parent.relative_to(root)
            except ValueError:
                continue
            candidates.append(root)
        return max(candidates, key=lambda item: len(item.parts)) if candidates else None

    def _cleanup_secret(self) -> bytes | None:
        if self.config.token_file is None:
            return None
        try:
            secret = _open_validated_token(self.config.token_file)
        except (OSError, RecoveryError) as error:
            raise RecoveryError("cleanup authentication material is unavailable") from error
        if not secret:
            raise RecoveryError("cleanup authentication material is empty")
        return secret

    def _require_cleanup_secret(self) -> bytes:
        secret = self._cleanup_secret()
        if secret is None:
            raise RecoveryError("cleanup authentication material is required")
        return secret

    @_close_cleanup_descriptors
    def reconcile_failed_stage(self, project_id: str, set_id: str) -> dict[str, Any]:
        """Acknowledge a quarantined failed stage without traversing it."""
        if os.name != "nt":
            raise RecoveryError("failed-stage reconciliation is only required on Windows")
        secret = self._cleanup_secret()
        if secret is None:
            raise RecoveryError("cleanup authentication material is required")
        _identifier(project_id); _identifier(set_id)
        parent = self._project_directory(project_id)
        stage = parent / f".{set_id}.pending"
        quarantine, record, reconciled = _cleanup_names(stage)
        if not _entry_present(record) and (_entry_present(quarantine) or _entry_present(reconciled)):
            raise RecoveryError("cleanup ownership evidence is missing")
        if _entry_present(record):
            try:
                with _open_verified_cleanup_record(record) as (record_fd, record_identity):
                    state = _read_cleanup_record_fd(record_fd, secret)
                    # Keep an independent descriptor for the transition phase;
                    # it remains bound to the authenticated object after the
                    # short reader context closes.
                    record_fd = _OwnedDescriptor(os.dup(record_fd))
            except OSError as error:
                raise RecoveryError("cleanup record is malformed") from error
            recorded_identity = state.get("identity") if isinstance(state, dict) else None
            if (not isinstance(state, dict) or state.get("quarantine") not in {quarantine.name, reconciled.name}
                    or not isinstance(recorded_identity, list) or len(recorded_identity) != 2
                    or any(type(item) is not int for item in recorded_identity)):
                raise RecoveryError("cleanup record is malformed")
            expected_mac = _cleanup_mac(secret, state["state"], state["quarantine"], tuple(recorded_identity))
            if not isinstance(state.get("mac"), str) or not hmac.compare_digest(state["mac"], expected_mac):
                raise RecoveryError("cleanup authentication failed")
            if state.get("state") == "reconciled":
                try:
                    stage_present = _entry_present(stage)
                    inconsistent = _entry_present(quarantine) or not reconciled.is_dir() or reconciled.is_symlink()
                except OSError as error:
                    raise RecoveryError("cleanup state is inconsistent") from error
                if stage_present:
                    raise RecoveryError("foreign failed-stage replacement requires operator reconciliation")
                if inconsistent:
                    raise RecoveryError("cleanup state is inconsistent")
                try:
                    observed = reconciled.stat()
                except OSError as error:
                    raise RecoveryError("cleanup state is inconsistent") from error
                if [int(observed.st_dev), int(observed.st_ino)] != recorded_identity:
                    raise RecoveryError("cleanup ownership evidence changed")
                return {"state": "reconciled", "quarantine": reconciled.name}
            if state.get("state") == "foreign_replacement":
                raise RecoveryError("foreign failed-stage replacement requires operator reconciliation")
            if state.get("state") == "quarantine_pending":
                if _entry_present(stage) and _entry_present(quarantine):
                    raise RecoveryError("foreign failed-stage replacement requires operator reconciliation")
                observed_path = stage if _entry_present(stage) and not _entry_present(quarantine) else quarantine
                if not _entry_present(observed_path):
                    raise RecoveryError("cleanup state is inconsistent")
                try:
                    observed = observed_path.stat()
                except OSError as error:
                    raise RecoveryError("cleanup state is inconsistent") from error
                if [int(observed.st_dev), int(observed.st_ino)] != state.get("identity"):
                    raise RecoveryError("failed-stage ownership changed")
                if observed_path == stage:
                    if not _windows_move_noreplace(stage, quarantine):
                        raise RecoveryError("cleanup reconciliation is busy")
                state = {**state, "state": "reconciliation_required"}
                state["mac"] = _cleanup_mac(
                    secret, "reconciliation_required", quarantine.name, tuple(recorded_identity)
                )
                try:
                    _write_json_cleanup_record(record_fd, record, record_identity, state)
                except RecoveryError:
                    raise
                except OSError:
                    pass
            else:
                # The quarantine may already have been moved successfully
                # before the authenticated final record write.  On restart,
                # converge from that durable destination instead of treating
                # the now-absent quarantine as missing evidence.
                try:
                    stage_present = _entry_present(stage)
                    can_converge = (state.get("state") == "reconciliation_required" and reconciled.is_dir()
                                    and not reconciled.is_symlink() and not _entry_present(quarantine))
                except OSError as error:
                    raise RecoveryError("cleanup state is inconsistent") from error
                if state.get("state") == "reconciliation_required" and stage_present:
                    raise RecoveryError("foreign failed-stage replacement requires operator reconciliation")
                if can_converge:
                    try:
                        observed = reconciled.stat()
                    except OSError as error:
                        raise RecoveryError("cleanup state is inconsistent") from error
                    if [int(observed.st_dev), int(observed.st_ino)] != recorded_identity:
                        raise RecoveryError("cleanup ownership evidence changed")
                    updated = {**state, "state": "reconciled", "quarantine": reconciled.name}
                    updated["mac"] = _cleanup_mac(secret, "reconciled", reconciled.name, tuple(recorded_identity))
                    _write_json_cleanup_record(record_fd, record, record_identity, updated)
                    return {"state": "reconciled", "quarantine": reconciled.name}
                try:
                    observed = quarantine.stat()
                except OSError as error:
                    raise RecoveryError("cleanup state is inconsistent") from error
                if [int(observed.st_dev), int(observed.st_ino)] != recorded_identity:
                    raise RecoveryError("cleanup ownership evidence changed")
            try:
                inconsistent = (state.get("state") != "reconciliation_required" or not quarantine.is_dir()
                                or quarantine.is_symlink())
            except OSError as error:
                raise RecoveryError("cleanup state is inconsistent") from error
            if inconsistent:
                raise RecoveryError("cleanup state is inconsistent")
            if not _windows_move_noreplace(quarantine, reconciled):
                raise RecoveryError("cleanup reconciliation is busy")
            # The source name can be swapped after the ownership check but
            # before the no-replace move.  Fence the moved tree again before
            # authenticating it as the recorded quarantine.
            try:
                observed = reconciled.stat()
            except OSError as error:
                raise RecoveryError("cleanup state is inconsistent") from error
            if [int(observed.st_dev), int(observed.st_ino)] != recorded_identity:
                raise RecoveryError("cleanup ownership evidence changed")
            updated = {**state, "state": "reconciled", "quarantine": reconciled.name}
            updated["mac"] = _cleanup_mac(secret, "reconciled", reconciled.name, tuple(recorded_identity))
            _write_json_cleanup_record(record_fd, record, record_identity, updated)
            return {"state": "reconciled", "quarantine": reconciled.name}
        if quarantine.is_dir() and not quarantine.is_symlink():
            raise RecoveryError("cleanup ownership evidence is missing")
        if _entry_present(quarantine) or _entry_present(stage):
            raise RecoveryError("failed stage requires reconciliation record")
        return {"state": "none"}

    def _manifest(self, directory: Path) -> dict[str, Any]:
        path = directory / "recovery-set.json"
        if path.is_symlink() or not path.is_file():
            raise RecoveryError("recovery set manifest is unavailable")
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise RecoveryError("recovery set manifest is malformed") from error
        if not isinstance(value, dict) or set(value) != {"format", "project_id", "set_id", "created_at", "dependencies", "provenance", "files"} or value.get("format") != "agentstack.recovery-set":
            raise RecoveryError("recovery set manifest schema is invalid")
        if not all(isinstance(value.get(key), str) and SAFE.fullmatch(value[key]) for key in ("project_id", "set_id")) or not isinstance(value["dependencies"], list) or any(not isinstance(item, str) or not SAFE.fullmatch(item) for item in value["dependencies"]):
            raise RecoveryError("recovery set identity is invalid")
        try:
            timestamp = datetime.fromisoformat(value["created_at"].replace("Z", "+00:00"))
        except (TypeError, ValueError) as error:
            raise RecoveryError("recovery set timestamp is invalid") from error
        if timestamp.tzinfo is None or not isinstance(value["provenance"], Mapping) or set(value["provenance"]) != {"code_checkpoint", "runtime_checkpoint", "receipts", "config_refs"}:
            raise RecoveryError("recovery provenance is invalid")
        try:
            encoded = json.dumps(value["provenance"], sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        except (TypeError, ValueError) as error:
            raise RecoveryError("recovery provenance is invalid") from error
        if len(encoded) > 64 * 1024:
            raise RecoveryError("recovery provenance exceeds bound")
        return value

    def _verify(self, directory: Path) -> dict[str, Any]:
        manifest = self._manifest(directory)
        stage_name = "." + manifest["set_id"] + ".pending"
        if directory.name not in {manifest["set_id"], stage_name} or directory.parent.name != manifest["project_id"]:
            raise RecoveryError("recovery manifest does not match namespace")
        if not isinstance(manifest["files"], list) or not 1 <= len(manifest["files"]) <= MAX_FILES:
            raise RecoveryError("recovery file list is invalid")
        seen: set[str] = set(); total = 0
        for entry in manifest["files"]:
            if not isinstance(entry, Mapping) or set(entry) != {"path", "sha256", "size"}:
                raise RecoveryError("recovery file entry is invalid")
            relative = _manifest_relative_path(entry["path"], directory)
            if entry["path"] in seen or not re.fullmatch(r"[0-9a-f]{64}", str(entry["sha256"])) or type(entry["size"]) is not int or not 0 <= entry["size"] <= MAX_FILE_BYTES:
                raise RecoveryError("recovery file entry is unsafe")
            seen.add(entry["path"]); source = directory / relative
            if source.is_symlink() or not source.is_file() or source.stat().st_size != entry["size"] or _digest(source) != entry["sha256"]:
                raise RecoveryError("recovery file integrity failure")
            total += entry["size"]
        if total > MAX_TOTAL_BYTES:
            raise RecoveryError("recovery set exceeds maximum")
        return manifest

    @staticmethod
    def _assert_bound_root(root_descriptor: int, configured_root: Path) -> None:
        """Ensure the configured name still denotes the held root object."""
        try:
            bound = os.fstat(root_descriptor)
            current = os.stat(configured_root, follow_symlinks=False)
        except OSError as error:
            raise RecoveryError("recovery root was replaced") from error
        if (int(bound.st_dev), int(bound.st_ino)) != (int(current.st_dev), int(current.st_ino)):
            raise RecoveryError("recovery root was replaced")

    @staticmethod
    def _assert_bound_source(project_descriptor: int, set_id: str,
                             source_identity: tuple[int, int]) -> None:
        """Ensure the source name still denotes the descriptor being verified."""
        try:
            current = os.stat(set_id, dir_fd=project_descriptor, follow_symlinks=False)
        except OSError as error:
            raise RecoveryError("recovery source was replaced") from error
        if (int(current.st_dev), int(current.st_ino)) != source_identity:
            raise RecoveryError("recovery source was replaced")

    def _verify_bound_source(self, source_descriptor: int, project_id: str,
                             set_id: str) -> dict[str, Any]:
        """Verify a recovery set using only the already-held source descriptor."""
        try:
            manifest_raw = self._read_json_fd(source_descriptor, "recovery-set.json", {})
        except RecoveryError:
            raise
        manifest = manifest_raw
        if (set(manifest) != {"format", "project_id", "set_id", "created_at", "dependencies", "provenance", "files"}
                or manifest.get("format") != "agentstack.recovery-set"):
            raise RecoveryError("recovery set manifest schema is invalid")
        if (manifest.get("project_id") != project_id or manifest.get("set_id") != set_id
                or not isinstance(project_id, str) or not SAFE.fullmatch(project_id)
                or not isinstance(set_id, str) or not SAFE.fullmatch(set_id)):
            raise RecoveryError("recovery manifest does not match namespace")
        if (not isinstance(manifest["dependencies"], list)
                or any(not isinstance(item, str) or not SAFE.fullmatch(item)
                       for item in manifest["dependencies"])):
            raise RecoveryError("recovery set identity is invalid")
        try:
            timestamp = datetime.fromisoformat(manifest["created_at"].replace("Z", "+00:00"))
        except (TypeError, ValueError) as error:
            raise RecoveryError("recovery set timestamp is invalid") from error
        if (timestamp.tzinfo is None or not isinstance(manifest["provenance"], Mapping)
                or set(manifest["provenance"]) != {"code_checkpoint", "runtime_checkpoint", "receipts", "config_refs"}):
            raise RecoveryError("recovery provenance is invalid")
        try:
            encoded = json.dumps(manifest["provenance"], sort_keys=True,
                                 separators=(",", ":"), allow_nan=False).encode("utf-8")
        except (TypeError, ValueError) as error:
            raise RecoveryError("recovery provenance is invalid") from error
        if len(encoded) > 64 * 1024:
            raise RecoveryError("recovery provenance exceeds bound")
        if not isinstance(manifest["files"], list) or not 1 <= len(manifest["files"] ) <= MAX_FILES:
            raise RecoveryError("recovery file list is invalid")
        seen: set[str] = set()
        total = 0
        for entry in manifest["files"]:
            if not isinstance(entry, Mapping) or set(entry) != {"path", "sha256", "size"}:
                raise RecoveryError("recovery file entry is invalid")
            if not isinstance(entry["path"], str):
                raise RecoveryError("recovery file entry is unsafe")
            relative = _manifest_relative_path(entry["path"])
            if (entry["path"] in seen or not re.fullmatch(r"[0-9a-f]{64}", str(entry["sha256"]))
                    or type(entry["size"]) is not int or not 0 <= entry["size"] <= MAX_FILE_BYTES):
                raise RecoveryError("recovery file entry is unsafe")
            seen.add(entry["path"])
            descriptor = _posix_open_regular_file_from_directory(source_descriptor, relative)
            try:
                opened = os.fstat(descriptor)
                size, digest = _posix_digest_regular_file(descriptor)
                after = os.fstat(descriptor)
            finally:
                os.close(descriptor)
            identity = (int(opened.st_dev), int(opened.st_ino))
            if identity != (int(after.st_dev), int(after.st_ino)):
                raise RecoveryError("recovery file was replaced")
            if size != entry["size"] or digest != entry["sha256"]:
                raise RecoveryError("recovery file integrity failure")
            total += size
        if total > MAX_TOTAL_BYTES:
            raise RecoveryError("recovery set exceeds maximum")
        return manifest

    def create_set(self, project_id: str, set_id: str, source_root: Path, *, dependencies: Sequence[str] = (), provenance: Mapping[str, Any]) -> dict[str, Any]:
        _identifier(project_id); _identifier(set_id); source_root = _safe_directory(source_root)
        policy = self._policy(); project = policy["projects"].get(project_id, {"classification": "AVG", "priority": 100, "pinned": []})
        if project["classification"] == "skull":
            raise RecoveryError("skull projects are excluded from automated recovery sets")
        if not isinstance(provenance, Mapping) or set(provenance) != {"code_checkpoint", "runtime_checkpoint", "receipts", "config_refs"}:
            raise RecoveryError("dependency-complete provenance is required")
        if any(not isinstance(item, str) or not SAFE.fullmatch(item) for item in dependencies):
            raise RecoveryError("dependency identifier is invalid")
        project_directory = self._project_directory(project_id)
        for dependency in dependencies:
            self._verify(_child(project_directory, dependency))
        destination = _child(project_directory, set_id)
        if destination.exists():
            existing = self._verify(destination)
            if existing["dependencies"] != list(dependencies) or existing["provenance"] != provenance:
                raise RecoveryError("existing recovery set differs")
            return existing
        stage = project_directory / f".{set_id}.pending"
        cleanup, cleanup_record, _ = _cleanup_names(stage)
        if _entry_present(cleanup) or _entry_present(cleanup_record):
            try:
                record = _read_cleanup_record_path(cleanup_record, self._cleanup_secret())
            except RecoveryError:
                raise RecoveryError("failed stage requires explicit reconciliation")
            if record.get("state") != "reconciled":
                raise RecoveryError("failed stage requires explicit reconciliation")
            _, _, reconciled = _cleanup_names(stage)
            recorded_identity = record.get("identity")
            try:
                invalid_reconciled = (record.get("quarantine") != reconciled.name or _entry_present(cleanup)
                                      or not reconciled.is_dir() or reconciled.is_symlink())
            except OSError as error:
                raise RecoveryError("failed stage requires explicit reconciliation") from error
            if (invalid_reconciled or not isinstance(recorded_identity, list) or len(recorded_identity) != 2
                    or any(type(item) is not int for item in recorded_identity)):
                raise RecoveryError("failed stage requires explicit reconciliation")
            secret = self._cleanup_secret()
            if secret is None or not isinstance(record.get("mac"), str) or not hmac.compare_digest(
                record["mac"], _cleanup_mac(secret, "reconciled", reconciled.name, tuple(recorded_identity))
            ):
                raise RecoveryError("failed stage requires explicit reconciliation")
            try:
                observed = reconciled.stat()
            except OSError as error:
                raise RecoveryError("failed stage requires explicit reconciliation") from error
            if [int(observed.st_dev), int(observed.st_ino)] != recorded_identity:
                raise RecoveryError("failed stage requires explicit reconciliation")
        if _entry_present(stage):
            raise RecoveryError("interrupted recovery set requires reconciliation")
        if os.name == "nt":
            self._require_cleanup_secret()
        posix_guard: _PosixStageGuard | None = None
        if os.name == "posix":
            posix_guard = _PosixStageGuard.create(
                stage, destination, self.config.local_root, self.config.local_root,
            )
            if posix_guard.stage_identity is None:
                raise RecoveryError("recovery stage cannot be established")
            stage_identity = posix_guard.stage_identity
        else:
            try:
                stage.mkdir(mode=0o700)
                stage_stat = stage.stat()
                stage_identity = (int(stage_stat.st_dev), int(stage_stat.st_ino))
            except OSError as error:
                # No identity was established, so the stage cannot be safely
                # removed. Preserve any entry and require explicit reconciliation.
                raise RecoveryError("recovery stage cannot be established") from error
        entries: list[dict[str, Any]] = []
        try:
            try:
                sources = sorted(source_root.rglob("*"))
            except OSError as error:
                raise RecoveryError("recovery source is unavailable") from error
            for source in sources:
                try:
                    source_is_symlink = source.is_symlink()
                    source_is_file = source.is_file()
                    source_is_directory = source.is_dir()
                except OSError as error:
                    raise RecoveryError("recovery source is unavailable") from error
                if source_is_symlink or (not source_is_file and not source_is_directory):
                    raise RecoveryError("source contains unsupported filesystem entry")
                if not source_is_file:
                    continue
                relative = source.relative_to(source_root)
                if len(relative.parts) > 16 or len(relative.as_posix().encode("utf-8")) > 512:
                    raise RecoveryError("source path exceeds portable bound")
                try:
                    source_size = source.stat().st_size
                except OSError as error:
                    raise RecoveryError("recovery source is unavailable") from error
                if source_size > MAX_FILE_BYTES:
                    raise RecoveryError("source file exceeds recovery bound")
                if posix_guard is not None:
                    size, digest = _copy_to_posix_stage(source, posix_guard, relative)
                else:
                    try:
                        target = stage / relative; target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                        shutil.copyfile(source, target)
                    except OSError as error:
                        raise RecoveryError("recovery source is unavailable") from error
                    try:
                        with target.open("r+b") as handle: os.fsync(handle.fileno())
                        size, digest = target.stat().st_size, _digest(target)
                    except OSError as error:
                        raise RecoveryError("recovery output is unavailable") from error
                entries.append({"path": relative.as_posix(), "sha256": digest, "size": size})
                if len(entries) > MAX_FILES or sum(item["size"] for item in entries) > MAX_TOTAL_BYTES:
                    raise RecoveryError("source exceeds recovery capacity")
            if not entries:
                raise RecoveryError("recovery source is empty")
            manifest = {"format": "agentstack.recovery-set", "project_id": project_id, "set_id": set_id, "created_at": self.clock(), "dependencies": list(dependencies), "provenance": dict(provenance), "files": entries}
            if posix_guard is not None:
                _write_json_posix_stage(posix_guard, Path("recovery-set.json"), manifest)
                posix_guard.validate()
                self._verify(stage)
                posix_guard.validate()
                if posix_guard.stage_descriptor is None:
                    raise RecoveryError("recovery stage is unavailable")
                os.fsync(posix_guard.stage_descriptor)
                _publish_directory_noreplace(_GuardedPosixStagePath(stage, posix_guard), destination)
            else:
                _write_json(stage / "recovery-set.json", manifest); self._verify(stage); _fsync_directory(stage); _publish_directory_noreplace(stage, destination); _fsync_directory(destination.parent)
            return manifest
        except Exception:
            if posix_guard is not None:
                posix_guard.cleanup()
            else:
                _remove_owned_stage(stage, stage_identity, self._cleanup_secret())
            raise
        finally:
            if posix_guard is not None:
                posix_guard.close()

    def _materialize_posix_bound(
        self, project_id: str, set_id: str, destination: Path, root_descriptor: int,
    ) -> dict[str, Any]:
        sets_descriptor = project_descriptor = source_descriptor = None
        posix_guard: _PosixStageGuard | None = None
        try:
            self._assert_bound_root(root_descriptor, self.config.local_root)
            sets_descriptor = _posix_open_directory_child(root_descriptor, "sets")
            project_descriptor = _posix_open_directory_child(sets_descriptor, project_id)
            source_descriptor = _posix_open_directory_child(project_descriptor, set_id)
            source_stat = os.fstat(source_descriptor)
            source_identity = (int(source_stat.st_dev), int(source_stat.st_ino))
            self._assert_bound_root(root_descriptor, self.config.local_root)
            self._assert_bound_source(project_descriptor, set_id, source_identity)
            manifest = self._verify_bound_source(source_descriptor, project_id, set_id)
            self._assert_bound_source(project_descriptor, set_id, source_identity)
            self._assert_bound_root(root_descriptor, self.config.local_root)

            if destination.exists() or destination.is_symlink() or not destination.is_absolute() or any(parent.is_symlink() for parent in destination.parents):
                raise RecoveryError("materialize destination must be a fresh safe directory")
            stage = destination.parent / f".{destination.name}.pending"
            if _entry_present(stage): raise RecoveryError("pending materialization requires reconciliation")
            self._assert_bound_source(project_descriptor, set_id, source_identity)
            self._assert_bound_root(root_descriptor, self.config.local_root)
            trusted_destination_root = self._trusted_destination_root(destination)
            posix_guard = _PosixStageGuard.create(
                stage, destination, trusted_destination_root,
                # Named temporary files are hard-linked into the output's
                # verified parent.  Keep the fallback on that filesystem;
                # using local_root here makes arbitrary destinations fail
                # with EXDEV even though the destination itself is safe.
                destination.parent,
                trusted_root_descriptor=(
                    root_descriptor if trusted_destination_root == self.config.local_root else None
                ),
            )
            if posix_guard.stage_identity is None:
                raise RecoveryError("recovery stage cannot be established")
            try:
                for entry in manifest["files"]:
                    size, digest = _copy_bound_file_to_posix_stage(
                        source_descriptor, posix_guard, Path(entry["path"]),
                    )
                    if size != entry["size"] or digest != entry["sha256"]:
                        raise RecoveryError("materialized checksum failure")
                    self._assert_bound_source(project_descriptor, set_id, source_identity)
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                self._assert_bound_source(project_descriptor, set_id, source_identity)
                self._assert_bound_root(root_descriptor, self.config.local_root)
                _write_json_posix_stage(posix_guard, Path("recovery-set.json"), manifest)
                self._assert_bound_source(project_descriptor, set_id, source_identity)
                self._assert_bound_root(root_descriptor, self.config.local_root)
                posix_guard.validate()
                if posix_guard.stage_descriptor is None:
                    raise RecoveryError("recovery stage is unavailable")
                os.fsync(posix_guard.stage_descriptor)
                self._assert_bound_source(project_descriptor, set_id, source_identity)
                self._assert_bound_root(root_descriptor, self.config.local_root)
                _publish_directory_noreplace(_GuardedPosixStagePath(stage, posix_guard), destination)
                self._assert_bound_source(project_descriptor, set_id, source_identity)
                self._assert_bound_root(root_descriptor, self.config.local_root)
                return manifest
            except Exception:
                posix_guard.cleanup()
                raise
        finally:
            if posix_guard is not None:
                posix_guard.close()
            for descriptor in (source_descriptor, project_descriptor, sets_descriptor):
                if descriptor is not None:
                    os.close(descriptor)

    def materialize(self, project_id: str, set_id: str, destination: Path) -> dict[str, Any]:
        if os.name == "posix":
            with self._bound_local_root() as root_descriptor:
                return self._materialize_posix_bound(project_id, set_id, destination, root_descriptor)

        source = _child(self._project_directory(project_id), set_id)
        manifest = self._verify(source)
        if destination.exists() or destination.is_symlink() or not destination.is_absolute() or any(parent.is_symlink() for parent in destination.parents):
            raise RecoveryError("materialize destination must be a fresh safe directory")
        stage = destination.parent / f".{destination.name}.pending"
        if _entry_present(stage): raise RecoveryError("pending materialization requires reconciliation")
        if os.name == "nt":
            self._require_cleanup_secret()
        try:
            stage.mkdir(mode=0o700)
            stage_stat = stage.stat()
            stage_identity = (int(stage_stat.st_dev), int(stage_stat.st_ino))
        except OSError as error:
            # Without a verified identity, cleanup could target a replacement;
            # preserve the evidence and fail closed for explicit reconciliation.
            raise RecoveryError("recovery stage cannot be established") from error
        try:
            for entry in manifest["files"]:
                source_file = source / entry["path"]
                output = stage / entry["path"]; output.parent.mkdir(mode=0o700, parents=True, exist_ok=True); shutil.copyfile(source_file, output)
                with output.open("r+b") as handle: os.fsync(handle.fileno())
                if _digest(output) != entry["sha256"]: raise RecoveryError("materialized checksum failure")
            _write_json(stage / "recovery-set.json", manifest); _fsync_directory(stage); _publish_directory_noreplace(stage, destination); _fsync_directory(destination.parent)
            return manifest
        except Exception:
            _remove_owned_stage(stage, stage_identity, self._cleanup_secret())
            raise

    def request_cold_copy(self, project_id: str, set_id: str, *, actor: str, explicit: bool) -> dict[str, Any]:
        if actor != "human" or not explicit or self.config.cold_root is None:
            raise RecoveryError("cold copy requires an explicit human command")
        _identifier(project_id); _identifier(set_id)
        with self._bound_local_root() as root_descriptor, self._journal_lock("queue", root_descriptor):
            if root_descriptor is not None:
                # Resolve every source component from the held root.  The
                # pathname may be swapped while verification runs, but none
                # of these descriptors can be redirected to the replacement.
                self._assert_bound_root(root_descriptor, self.config.local_root)
                sets_descriptor = _posix_open_directory_child(root_descriptor, "sets")
                project_descriptor: int | None = None
                source_descriptor: int | None = None
                try:
                    project_descriptor = _posix_open_directory_child(sets_descriptor, project_id)
                    source_descriptor = _posix_open_directory_child(project_descriptor, set_id)
                    source_stat = os.fstat(source_descriptor)
                    source_identity = (int(source_stat.st_dev), int(source_stat.st_ino))
                    # This is the last root/source check before the first
                    # source byte is read.  A replacement at either mutable
                    # name therefore fails closed without touching the queue.
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    self._assert_bound_source(project_descriptor, set_id, source_identity)
                    self._verify_bound_source(source_descriptor, project_id, set_id)
                    # Fence both capabilities after verification and before
                    # reading or publishing the queue journal.
                    self._assert_bound_source(project_descriptor, set_id, source_identity)
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                finally:
                    if source_descriptor is not None:
                        os.close(source_descriptor)
                    if project_descriptor is not None:
                        os.close(project_descriptor)
                    os.close(sets_descriptor)
                queue, journal_identity = self._read_json_fd_with_identity(root_descriptor, "cold-copy-queue.json", {"items": {}})
            else:
                source = _child(self._project_directory(project_id), set_id)
                self._verify(source)
                queue = self._read_json(self._queue_path, {"items": {}})
            if set(queue) != {"items"} or not isinstance(queue["items"], dict): raise RecoveryError("cold queue is malformed")
            key = f"{project_id}/{set_id}"
            queue["items"].setdefault(key, {"project_id": project_id, "set_id": set_id, "state": "pending", "requested_at": self.clock()})
            if root_descriptor is not None: self._write_json_fd(root_descriptor, "cold-copy-queue.json", queue, journal_identity)
            else: _write_json(self._queue_path, queue)
            if root_descriptor is not None: self._assert_bound_root(root_descriptor, self.config.local_root)
            return dict(queue["items"][key])

    def run_cold_copy(self, project_id: str, set_id: str, *, actor: str, explicit: bool, dry_run: bool = True) -> dict[str, Any]:
        if actor != "human" or not explicit: raise RecoveryError("cold copy requires explicit human authorization")
        if self.config.cold_root is None: raise RecoveryError("cold copy requires an explicit authorized command")
        _identifier(project_id); _identifier(set_id)
        with self._bound_local_root() as root_descriptor, self._journal_lock("queue", root_descriptor):
            source_descriptor = project_descriptor = sets_descriptor = cold_descriptor = None
            target_parent_descriptor = None
            try:
                if root_descriptor is not None:
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    cold_descriptor, _ = _posix_open_directory_path(self.config.cold_root)
                    self._assert_bound_root(cold_descriptor, self.config.cold_root)
                    sets_descriptor = _posix_open_directory_child(root_descriptor, "sets")
                    project_descriptor = _posix_open_directory_child(sets_descriptor, project_id)
                    source_descriptor = _posix_open_directory_child(project_descriptor, set_id)
                    source_stat = os.fstat(source_descriptor)
                    source_identity = (int(source_stat.st_dev), int(source_stat.st_ino))
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    self._assert_bound_source(project_descriptor, set_id, source_identity)
                    manifest = self._verify_bound_source(source_descriptor, project_id, set_id)
                    self._assert_bound_source(project_descriptor, set_id, source_identity)
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    queue, queue_identity = self._read_json_fd_with_identity(root_descriptor, "cold-copy-queue.json", {"items": {}})
                else:
                    source = _child(self._project_directory(project_id), set_id)
                    manifest = self._verify(source)
                    queue, queue_identity = self._read_json(self._queue_path, {"items": {}}), None
                if set(queue) != {"items"} or not isinstance(queue["items"], dict): raise RecoveryError("cold queue is malformed")
                key = f"{project_id}/{set_id}"
                queue["items"].setdefault(key, {"project_id": project_id, "set_id": set_id, "state": "pending", "requested_at": self.clock()})
                queued = dict(queue["items"][key])
                if dry_run:
                    if root_descriptor is not None: self._assert_bound_root(root_descriptor, self.config.local_root)
                    return {**queued, "dry_run": True}
                if root_descriptor is not None:
                    self._write_json_fd(root_descriptor, "cold-copy-queue.json", queue, queue_identity)
                else: _write_json(self._queue_path, queue)
                if root_descriptor is not None:
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    self._assert_bound_root(cold_descriptor, self.config.cold_root)
                    target_parent = self.config.cold_root / "sets" / project_id
                    target_parent_descriptor, _ = _posix_open_directory_from_root(
                        cold_descriptor, self.config.cold_root, target_parent, create=True,
                    )
                    target = target_parent / set_id
                    try:
                        target_stat = os.stat(set_id, dir_fd=target_parent_descriptor, follow_symlinks=False)
                    except FileNotFoundError:
                        target_stat = None
                    if target_stat is not None:
                        target_descriptor = _posix_open_directory_child(target_parent_descriptor, set_id)
                        try:
                            self._verify_bound_source(target_descriptor, project_id, set_id)
                        finally:
                            os.close(target_descriptor)
                    else:
                        stage = target_parent / f".{set_id}.pending"
                        try:
                            os.stat(stage.name, dir_fd=target_parent_descriptor, follow_symlinks=False)
                        except FileNotFoundError:
                            pass
                        else:
                            raise RecoveryError("cold copy pending; reconcile before retry")
                        guard = _PosixStageGuard.create(
                            stage, target, self.config.cold_root, self.config.cold_root,
                            trusted_root_descriptor=cold_descriptor,
                            parent_descriptor=target_parent_descriptor,
                            temporary_root_descriptor=cold_descriptor,
                        )
                        try:
                            for entry in manifest["files"]:
                                size, digest = _copy_bound_file_to_posix_stage(
                                    source_descriptor, guard, Path(entry["path"]),
                                )
                                if size != entry["size"] or digest != entry["sha256"]:
                                    raise RecoveryError("cold-copy checksum failure")
                                self._assert_bound_root(root_descriptor, self.config.local_root)
                                self._assert_bound_root(cold_descriptor, self.config.cold_root)
                            _write_json_posix_stage(guard, Path("recovery-set.json"), manifest)
                            guard.validate()
                            if guard.stage_descriptor is None:
                                raise RecoveryError("recovery stage is unavailable")
                            self._verify_bound_source(guard.stage_descriptor, project_id, set_id)
                            guard.validate()
                            os.fsync(guard.stage_descriptor)
                            _publish_directory_noreplace(_GuardedPosixStagePath(stage, guard), target)
                        except Exception:
                            guard.cleanup()
                            raise
                        finally:
                            guard.close()
                else:
                    target_parent = _child(self.config.cold_root, "sets", project_id, create=True); target = _child(target_parent, set_id)
                    if target.exists(): self._verify(target)
                    else:
                        stage = target_parent / f".{set_id}.pending"
                        if _entry_present(stage): raise RecoveryError("cold copy pending; reconcile before retry")
                        shutil.copytree(source, stage, copy_function=shutil.copyfile); self._verify(stage); _fsync_directory(stage); os.replace(stage, target); _fsync_directory(target_parent)
                if root_descriptor is not None:
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    self._assert_bound_root(cold_descriptor, self.config.cold_root)
                    queue, identity = self._read_json_fd_with_identity(root_descriptor, "cold-copy-queue.json", {"items": {}})
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    self._assert_bound_root(cold_descriptor, self.config.cold_root)
                    item = queue.get("items", {}).get(key)
                    if not isinstance(item, dict) or item.get("state") not in {"pending", "complete"}: raise RecoveryError("cold copy queue transition is unsafe")
                    if item["state"] == "pending":
                        item.update({"state": "complete", "completed_at": self.clock()}); self._write_json_fd(root_descriptor, "cold-copy-queue.json", queue, identity)
                    self._assert_bound_root(root_descriptor, self.config.local_root)
                    self._assert_bound_root(cold_descriptor, self.config.cold_root)
                else:
                    queue = self._read_json(self._queue_path, {"items": {}})
                    item = queue.get("items", {}).get(key)
                    if not isinstance(item, dict) or item.get("state") not in {"pending", "complete"}: raise RecoveryError("cold copy queue transition is unsafe")
                    if item["state"] == "pending":
                        item.update({"state": "complete", "completed_at": self.clock()}); _write_json(self._queue_path, queue)
                return dict(queue["items"][key])
            finally:
                for descriptor in (source_descriptor, project_descriptor, sets_descriptor, target_parent_descriptor, cold_descriptor):
                    if descriptor is not None:
                        os.close(descriptor)

    def apply_cold_retention(self, project_id: str, operation_id: str,
                             receipts: Sequence[Mapping[str, Any]], *, actor: str,
                             explicit: bool) -> dict[str, Any]:
        """Prune cold copies after an independently durable replacement proof.

        The receipt is deliberately an input to this boundary, rather than a
        status inferred from the local catalogue.  The apply journal is stored
        in the cold namespace and is the retry authority; the local catalogue
        and project files are never mutation targets of this operation.
        """
        if actor != "human" or not explicit:
            raise RecoveryError("cold retention apply requires explicit human authorization")
        if self.config.cold_root is None:
            raise RecoveryError("cold retention apply requires an authorized cold root")
        _identifier(project_id); _identifier(operation_id)
        if not isinstance(receipts, Sequence) or isinstance(receipts, (str, bytes)) or not receipts:
            raise RecoveryError("replacement receipts are required")

        cold_project = _child(self.config.cold_root / "sets", project_id, create=False)
        journal_path = self.config.cold_root / "retention-apply" / project_id / f"{operation_id}.json"
        existing_journal = _entry_present(journal_path)
        policy = self._policy()
        pinned = set(policy.get("projects", {}).get(project_id, {}).get("pinned", []))
        normalized: list[dict[str, Any]] = []
        obsolete: set[str] = set()
        obsolete_identity: dict[str, tuple[int, int]] = {}
        cold_descriptor = cold_sets_descriptor = cold_project_descriptor = None
        windows_root_handle = windows_sets_handle = windows_project_handle = None
        if os.name == "posix":
            cold_descriptor, cold_identity = _posix_open_directory_path(self.config.cold_root)
            if cold_identity != self._cold_root_identity:
                os.close(cold_descriptor)
                raise RecoveryError("cold retention root was replaced")
            try:
                cold_sets_descriptor = _posix_open_directory_child(cold_descriptor, "sets")
                cold_project_descriptor = _posix_open_directory_child(cold_sets_descriptor, project_id)
            except Exception:
                for descriptor in (cold_sets_descriptor, cold_descriptor):
                    if descriptor is not None:
                        os.close(descriptor)
                raise

        def verify_cold_set(set_id: str) -> dict[str, Any]:
            if os.name != "posix":
                return self._verify(_child(cold_project, set_id, create=False))
            descriptor = _posix_open_directory_child(cold_project_descriptor, set_id)
            try:
                return self._verify_bound_source(descriptor, project_id, set_id)
            finally:
                os.close(descriptor)

        def digest_cold_manifest(set_id: str) -> str:
            if os.name != "posix":
                return _digest(_child(cold_project, set_id) / "recovery-set.json")
            descriptor = _posix_open_directory_child(cold_project_descriptor, set_id)
            manifest_descriptor = None
            try:
                manifest_descriptor = _posix_open_regular_file_from_directory(descriptor, Path("recovery-set.json"))
                _size, digest = _posix_digest_regular_file(manifest_descriptor)
                return digest
            finally:
                if manifest_descriptor is not None:
                    os.close(manifest_descriptor)
                os.close(descriptor)

        for receipt in receipts:
            if not isinstance(receipt, Mapping) or set(receipt) != {
                    "project_id", "obsolete_set_id", "replacement_set_id",
                    "replacement_manifest_sha256", "dependency_closure", "state", "receipt_id"}:
                raise RecoveryError("replacement verification receipt schema is invalid")
            if (receipt["project_id"] != project_id or receipt["state"] != "verified"
                    or not isinstance(receipt["receipt_id"], str)):
                raise RecoveryError("replacement verification receipt is not verified")
            old_id = _identifier(receipt["obsolete_set_id"])
            replacement_id = _identifier(receipt["replacement_set_id"])
            if old_id == replacement_id or old_id in obsolete or old_id in pinned:
                raise RecoveryError("protected or duplicate cold copy cannot be pruned")
            if not isinstance(receipt["replacement_manifest_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", receipt["replacement_manifest_sha256"]):
                raise RecoveryError("replacement verification receipt digest is invalid")
            closure = receipt["dependency_closure"]
            if (not isinstance(closure, Sequence) or isinstance(closure, (str, bytes)) or not closure):
                raise RecoveryError("replacement dependency closure is invalid")
            closure_by_id: dict[str, str] = {}
            for item in closure:
                if (not isinstance(item, Mapping) or set(item) != {"set_id", "manifest_sha256"}
                        or not isinstance(item["manifest_sha256"], str)
                        or not re.fullmatch(r"[0-9a-f]{64}", item["manifest_sha256"])):
                    raise RecoveryError("replacement dependency closure is invalid")
                closure_by_id[_identifier(item["set_id"])] = item["manifest_sha256"]
            if replacement_id not in closure_by_id:
                raise RecoveryError("replacement dependency closure does not include replacement")
            verify_cold_set(replacement_id)
            replacement_digest = digest_cold_manifest(replacement_id)
            if replacement_digest != receipt["replacement_manifest_sha256"] or replacement_digest != closure_by_id[replacement_id]:
                raise RecoveryError("replacement verification receipt does not match cold copy")

            expected: set[str] = set()
            visiting: set[str] = set()
            def add_closure(set_id: str) -> None:
                if set_id in expected:
                    return
                if set_id in visiting:
                    raise RecoveryError("replacement dependency closure is cyclic")
                visiting.add(set_id)
                manifest = verify_cold_set(set_id)
                expected.add(set_id)
                for dependency in manifest["dependencies"]:
                    add_closure(dependency)
                visiting.remove(set_id)
            add_closure(replacement_id)
            if set(closure_by_id) != expected:
                raise RecoveryError("replacement dependency closure is incomplete")
            for set_id, digest in closure_by_id.items():
                if digest_cold_manifest(set_id) != digest:
                    raise RecoveryError("replacement dependency receipt is stale")
            old = _child(cold_project, old_id, create=False)
            if os.name == "posix":
                try:
                    old_stat = os.stat(old_id, dir_fd=cold_project_descriptor, follow_symlinks=False)
                except FileNotFoundError:
                    old_stat = None
                except OSError as error:
                    raise RecoveryError("obsolete cold copy cannot be inspected") from error
                if old_stat is not None:
                    if not stat.S_ISDIR(old_stat.st_mode):
                        raise RecoveryError("obsolete cold copy is unsafe")
                    if not existing_journal:
                        old_descriptor = _posix_open_directory_child(cold_project_descriptor, old_id)
                        try:
                            self._verify_bound_source(old_descriptor, project_id, old_id)
                        finally:
                            os.close(old_descriptor)
                    obsolete_identity[old_id] = (int(old_stat.st_dev), int(old_stat.st_ino))
                elif not existing_journal:
                    raise RecoveryError("obsolete cold copy is unavailable")
            else:
                if not _entry_present(old) and not existing_journal:
                    raise RecoveryError("obsolete cold copy is unavailable")
                if _entry_present(old):
                    if old.is_symlink() or not old.is_dir():
                        raise RecoveryError("obsolete cold copy is unsafe")
                    if not existing_journal:
                        self._verify(old)
                    old_stat = os.stat(old, follow_symlinks=False)
                    obsolete_identity[old_id] = (int(old_stat.st_dev), int(old_stat.st_ino))
            normalized.append(dict(receipt)); obsolete.add(old_id)

        if os.name == "nt":
            windows_root_handle, cold_identity = _windows_open_directory(self.config.cold_root)
            if cold_identity != self._cold_root_identity:
                _windows_close_handle(windows_root_handle)
                raise RecoveryError("cold retention root was replaced")
            try:
                windows_sets_handle, _ = _windows_open_directory(self.config.cold_root / "sets")
                windows_project_handle, _ = _windows_open_directory(cold_project)
            except Exception:
                for handle in (windows_project_handle, windows_sets_handle, windows_root_handle):
                    if handle is not None:
                        _windows_close_handle(handle)
                raise
        journal_parent_descriptor = None
        windows_journal_parent_handle = None
        journal_identity = None
        try:
            if os.name == "posix":
                journal_parent_descriptor, _ = _posix_open_directory_from_root(
                    cold_descriptor, self.config.cold_root,
                    self.config.cold_root / "retention-apply" / project_id, create=True,
                )
                state, journal_identity = self._read_json_fd_with_identity(
                    journal_parent_descriptor, f"{operation_id}.json", {},
                )
                journal_exists = journal_identity is not None
            else:
                journal_parent = _child(self.config.cold_root, "retention-apply", project_id, create=True)
                # Bind the journal namespace before reading or publishing it.
                # The configured pathname is not a sufficient authority on
                # Windows because a reparse point can redirect it between
                # operations.
                windows_journal_parent_handle, _ = _windows_open_directory(journal_parent)
                journal = _windows_handle_path(windows_journal_parent_handle) / f"{operation_id}.json"
                journal_exists = _entry_present(journal)
                if journal_exists:
                    if _is_reparse_point(journal) or not journal.is_file():
                        raise RecoveryError("cold retention apply journal is unsafe")
                    try:
                        state = json.loads(journal.read_text(encoding="utf-8"))
                    except (OSError, ValueError) as error:
                        raise RecoveryError("cold retention apply journal is malformed") from error

            def write_state() -> None:
                if os.name == "posix":
                    self._write_json_fd(
                        journal_parent_descriptor, f"{operation_id}.json", state, journal_identity,
                    )
                else:
                    _write_json(journal, state)

            if journal_exists:
                if (not isinstance(state, dict) or state.get("operation_id") != operation_id
                        or state.get("project_id") != project_id or state.get("receipts") != normalized):
                    raise RecoveryError("cold retention apply operation replay conflicts")
                recorded_identities = state.get("obsolete_identities")
                if (not isinstance(recorded_identities, dict)
                        or any(set_id not in recorded_identities for set_id in obsolete)):
                    raise RecoveryError("cold retention apply ownership evidence is unavailable")
                for set_id in obsolete:
                    recorded = recorded_identities[set_id]
                    if (not isinstance(recorded, list) or len(recorded) != 2
                            or any(type(item) is not int for item in recorded)
                            or (set_id in obsolete_identity
                                and tuple(recorded) != obsolete_identity[set_id])):
                        raise RecoveryError("obsolete cold copy ownership changed")
                    # On replay the durable journal, rather than this
                    # invocation's receipt lookup, supplies the identity used
                    # by the destructive step.  A missing target is therefore
                    # a completed sub-step, while a present target is checked
                    # against this recorded identity below.
                    obsolete_identity[set_id] = tuple(recorded)
            else:
                state = {"operation_id": operation_id, "project_id": project_id,
                         "receipts": normalized, "remaining": sorted(obsolete),
                         "obsolete_identities": {
                             set_id: list(identity) for set_id, identity in obsolete_identity.items()
                         },
                         "state": "prepared", "recorded_at": self.clock()}
                write_state()
                if os.name == "posix":
                    _ignored, journal_identity = self._read_json_fd_with_identity(
                        journal_parent_descriptor, f"{operation_id}.json", {},
                    )

            remaining = list(state.get("remaining", []))
            if state.get("state") == "complete":
                return dict(state)
            if not isinstance(remaining, list) or any(item not in obsolete for item in remaining):
                raise RecoveryError("cold retention apply journal is malformed")
            for set_id in remaining[:]:
                if os.name == "posix":
                    try:
                        target_stat = os.stat(set_id, dir_fd=cold_project_descriptor, follow_symlinks=False)
                    except FileNotFoundError:
                        target_stat = None
                    except OSError as error:
                        raise RecoveryError("obsolete cold copy cannot be inspected") from error
                    if target_stat is None:
                        remaining.remove(set_id)
                        state["remaining"] = remaining
                        write_state()
                        continue
                    if (not stat.S_ISDIR(target_stat.st_mode)
                            or (int(target_stat.st_dev), int(target_stat.st_ino)) != obsolete_identity.get(set_id)):
                        raise RecoveryError("obsolete cold copy was replaced")
                    target_descriptor = _posix_open_directory_child(cold_project_descriptor, set_id)
                    try:
                        if _cleanup_owned_posix_directory(target_descriptor, cold_project / set_id):
                            raise RecoveryError("obsolete cold copy cleanup cannot be proven")
                    finally:
                        os.close(target_descriptor)
                    if not _posix_retire_owned_entry(
                            cold_project_descriptor, set_id,
                            obsolete_identity[set_id], target_stat.st_mode):
                        raise RecoveryError("obsolete cold copy cleanup cannot be proven")
                else:
                    target = _child(cold_project, set_id, create=False)
                    if not _entry_present(target):
                        remaining.remove(set_id)
                        state["remaining"] = remaining
                        write_state()
                        continue
                    _windows_remove_bound_directory(target, obsolete_identity.get(set_id, (-1, -1)))
                remaining.remove(set_id)
                state["remaining"] = remaining
                write_state()
            state.update({"state": "complete", "completed_at": self.clock(), "remaining": []})
            write_state()
            return dict(state)
        finally:
            if journal_parent_descriptor is not None:
                os.close(journal_parent_descriptor)
            for descriptor in (cold_project_descriptor, cold_sets_descriptor, cold_descriptor):
                if descriptor is not None:
                    os.close(descriptor)
            if windows_journal_parent_handle is not None:
                _windows_close_handle(windows_journal_parent_handle)
            for handle in (windows_project_handle, windows_sets_handle):
                if handle is not None:
                    _windows_close_handle(handle)
            if windows_root_handle is not None:
                _windows_close_handle(windows_root_handle)

    def retention_plan(self, project_id: str, *, now: datetime | None = None) -> dict[str, Any]:
        _identifier(project_id)
        directory = _child(self.config.local_root, "sets", project_id)
        rows: list[tuple[datetime, dict[str, Any]]] = []
        if directory.exists():
            if directory.is_symlink() or not directory.is_dir():
                raise RecoveryError("recovery project namespace is unsafe")
            try:
                children = list(directory.iterdir())
            except OSError as error:
                raise RecoveryError("recovery namespace cannot be inspected") from error
            for child in children:
                if child.name.startswith(".") or not child.is_dir() or child.is_symlink():
                    continue
                manifest = self._verify(child)
                rows.append((self._selection_timestamp(manifest["created_at"], "recovery set created_at"), manifest))
        rows.sort(key=lambda row: row[0], reverse=True)
        by_id = {manifest["set_id"]: manifest for _, manifest in rows}
        observed_at = now or datetime.now(timezone.utc)
        if observed_at.tzinfo is None:
            raise RecoveryError("retention time must include a timezone")
        observed_at = observed_at.astimezone(timezone.utc)

        complete: dict[str, set[str]] = {}
        incomplete: dict[str, dict[str, Any]] = {}
        visiting: set[str] = set()

        def closure(set_id: str) -> set[str] | None:
            if set_id in complete:
                return complete[set_id]
            if set_id in visiting:
                incomplete.setdefault(set_id, {"reason": "dependency_cycle", "missing_dependencies": []})
                return None
            manifest = by_id.get(set_id)
            if manifest is None:
                return None
            visiting.add(set_id)
            result = {set_id}
            missing: set[str] = set()
            cyclic = False
            for dependency in manifest["dependencies"]:
                dependency_closure = closure(dependency)
                if dependency_closure is None:
                    if dependency not in by_id:
                        missing.add(dependency)
                    else:
                        dependency_detail = incomplete.get(dependency, {})
                        missing.update(dependency_detail.get("missing_dependencies", []))
                        cyclic = cyclic or dependency_detail.get("reason") == "dependency_cycle"
                else:
                    result.update(dependency_closure)
            visiting.remove(set_id)
            if missing or cyclic:
                detail = incomplete.setdefault(set_id, {"reason": "dependency_incomplete", "missing_dependencies": []})
                detail["missing_dependencies"] = sorted(set(detail["missing_dependencies"]) | missing)
                if cyclic:
                    detail["reason"] = "dependency_cycle"
                return None
            complete[set_id] = result
            return result

        complete_ids = [set_id for set_id in by_id if closure(set_id) is not None]
        complete_rows = [row for row in rows if row[1]["set_id"] in complete_ids]
        keep: set[str] = set(incomplete)
        if complete_rows:
            keep.update(complete[complete_rows[0][1]["set_id"]])
        policy = self._policy()
        project_policy = policy["projects"].get(project_id, {})
        pinned = set(project_policy.get("pinned", []))
        for bucket in self.config.retention_buckets_seconds:
            candidates = [
                item for item in complete_rows
                if (timedelta(0) <= observed_at - item[0] <= timedelta(seconds=bucket)
                        and item[1]["set_id"] not in pinned)
            ]
            if candidates:
                keep.update(complete[candidates[0][1]["set_id"]])

        missing_pins = sorted(pinned - set(by_id))
        for set_id in pinned & set(by_id):
            keep.add(set_id)
            if set_id in complete:
                keep.update(complete[set_id])
            else:
                detail = incomplete.setdefault(set_id, {"reason": "dependency_incomplete", "missing_dependencies": []})
                detail["protected"] = True

        classification = project_policy.get("classification", "AVG")
        if classification == "skull":
            keep.update(by_id)
        used = sum(
            sum(entry["size"] for entry in manifest["files"])
            for set_id, manifest in by_id.items() if set_id in keep
        )
        latest_age = None if not complete_rows else max(
            0.0, (observed_at - complete_rows[0][0]).total_seconds()
        )
        return {
            "keep": sorted(keep),
            "evict": [set_id for set_id in by_id if set_id not in keep],
            "missing_pins": missing_pins,
            "incomplete_sets": incomplete,
            "classification": classification,
            "used_bytes": used,
            "overflow": used > self.config.capacity_bytes,
            "latest_complete_age_seconds": latest_age,
            "rpo_degraded": latest_age is None or latest_age > self.config.degraded_rpo_seconds,
            "weighting_policy": "explicit configuration required; AVG vs numbered is not inferred",
        }

    @staticmethod
    def _selection_timestamp(value: Any, field: str) -> datetime:
        if not isinstance(value, str):
            raise RecoveryError(f"{field} must be an ISO-8601 timestamp")
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as error:
            raise RecoveryError(f"{field} must be an ISO-8601 timestamp") from error
        if parsed.tzinfo is None:
            raise RecoveryError(f"{field} must include a timezone")
        return parsed.astimezone(timezone.utc)

    @staticmethod
    def _selection_manifest_timestamp(manifest: Mapping[str, Any]) -> datetime:
        return RecoveryService._selection_timestamp(manifest.get("created_at"), "recovery set created_at")

    @staticmethod
    def _normalize_selection_evidence(project: Mapping[str, Any]) -> tuple[dict[str, Any], str | None]:
        """Normalize completion aliases and reject contradictory evidence."""
        missing = object()
        completion_value = project.get("completion", missing)
        if completion_value is missing:
            completion: Mapping[str, Any] = {}
        elif isinstance(completion_value, Mapping):
            completion = completion_value
        else:
            return {}, "completion_evidence_invalid"

        def aliases(keys: tuple[str, ...]) -> list[tuple[str, Any]]:
            values: list[tuple[str, Any]] = []
            for container, prefix in ((project, ""), (completion, "completion.")):
                for key in keys:
                    if key in container:
                        values.append((f"{prefix}{key}", container[key]))
            return values

        def consistent(values: list[tuple[str, Any]], normalize: Any) -> tuple[Any, bool]:
            if not values:
                return missing, False
            normalized = [normalize(value) for _, value in values]
            first = normalized[0]
            return first, any(value != first for value in normalized[1:])

        def status_value(value: Any) -> Any:
            if isinstance(value, str) and value in {"completed", "complete"}:
                return "completed"
            return ("status", type(value).__name__, repr(value))

        status_values = aliases(("status", "completion_status"))
        status, status_conflict = consistent(status_values, status_value)
        if status_conflict:
            return {}, "completion_evidence_conflict"

        def accepted_value(value: Any) -> Any:
            if type(value) is bool:
                return ("bool", value)
            return ("invalid", type(value).__name__, repr(value))

        accepted_values = aliases(("human_accepted", "accepted_by_human"))
        accepted, accepted_conflict = consistent(accepted_values, accepted_value)
        if accepted_conflict:
            return {}, "completion_evidence_conflict"

        delivery_values: list[tuple[str, Mapping[str, Any]]] = []
        for container, prefix in ((project, ""), (completion, "completion.")):
            for key in ("git_delivery", "delivery"):
                if key not in container:
                    continue
                value = container[key]
                if not isinstance(value, Mapping):
                    return {}, "completion_evidence_invalid"
                delivery_values.append((f"{prefix}{key}", value))
        if not delivery_values and isinstance(project.get("git"), Mapping):
            delivery_values.append(("git", project["git"]))

        confirmation_claims: list[bool] = []
        for _, delivery in delivery_values:
            if "confirmed" in delivery:
                confirmation_claims.append(delivery["confirmed"] is True)
            if "status" in delivery:
                status_value = delivery["status"]
                confirmation_claims.append(isinstance(status_value, str) and status_value in {"confirmed", "uploaded"})
            if "uploaded" in delivery:
                confirmation_claims.append(delivery["uploaded"] is True)
        for _, value in aliases(("git_delivery_confirmed",)):
            confirmation_claims.append(value is True)
        if confirmation_claims and any(value != confirmation_claims[0] for value in confirmation_claims[1:]):
            return {}, "completion_evidence_conflict"
        confirmed = confirmation_claims[0] if confirmation_claims else False

        source_values: list[tuple[str, Any]] = []
        for path, delivery in delivery_values:
            for key in ("source_revision", "accepted_revision"):
                if key in delivery:
                    source_values.append((f"{path}.{key}", delivery[key]))
        source_values.extend(aliases(("source_revision", "accepted_revision")))

        def source_value(value: Any) -> Any:
            if isinstance(value, str) and value.strip():
                return ("value", value.strip())
            return ("invalid", type(value).__name__, repr(value))

        source, source_conflict = consistent(source_values, source_value)
        if source_conflict:
            return {}, "completion_evidence_conflict"
        source_revision = None if source is missing or source[0] != "value" else source[1]

        freshness_values: list[tuple[str, Any]] = []
        for path, delivery in delivery_values:
            if "freshness" in delivery:
                freshness_values.append((f"{path}.freshness", delivery["freshness"]))
        freshness_values.extend(aliases(("freshness",)))

        def freshness_value(value: Any) -> Any:
            if not isinstance(value, Mapping):
                return ("invalid", type(value).__name__, repr(value))
            state = value.get("state", missing)
            if isinstance(state, str) and state in {"fresh", "current"}:
                normalized_state: Any = "fresh"
            elif state is missing:
                normalized_state = ("missing",)
            else:
                normalized_state = ("state", type(state).__name__, repr(state))
            observed_at = value.get("observed_at", missing)
            if observed_at is missing:
                normalized_observed: Any = ("missing",)
            else:
                try:
                    normalized_observed = ("value", RecoveryService._selection_timestamp(observed_at, "freshness.observed_at"))
                except RecoveryError:
                    normalized_observed = ("invalid", type(observed_at).__name__, repr(observed_at))
            return ("mapping", normalized_state, normalized_observed)

        freshness, freshness_conflict = consistent(freshness_values, freshness_value)
        if freshness_conflict:
            return {}, "completion_evidence_conflict"
        freshness_record = None if freshness is missing or freshness_values == [] else freshness_values[0][1]

        return {
            "status": "completed" if status == "completed" else None,
            "accepted": None if accepted is missing else (accepted[1] if accepted[0] == "bool" else accepted_values[0][1]),
            "confirmed": confirmed,
            "source_revision": source_revision,
            "freshness": freshness_record,
        }, None

    @staticmethod
    def _selection_evidence(project: Mapping[str, Any], now: datetime) -> tuple[bool, str]:
        """Return whether completion is authoritative enough for exclusion.

        Completion is deliberately fail-closed: a project is only excluded when
        all human acceptance, Git delivery, source revision and freshness facts
        are explicit and internally consistent.
        """
        normalized, normalization_reason = RecoveryService._normalize_selection_evidence(project)
        if normalization_reason is not None:
            return False, normalization_reason
        status = normalized["status"]
        accepted = normalized["accepted"]
        confirmed = normalized["confirmed"]
        source_revision = normalized["source_revision"]
        freshness = normalized["freshness"]
        if status not in {"completed", "complete"} or accepted is not True:
            return False, "unfinished_or_not_human_accepted"
        if confirmed is not True:
            return False, "git_delivery_not_confirmed"
        if not isinstance(source_revision, str) or not source_revision.strip():
            return False, "completion_source_revision_missing"
        freshness_state = freshness.get("state") if isinstance(freshness, Mapping) else None
        if not isinstance(freshness_state, str) or freshness_state not in {"fresh", "current"}:
            return False, "completion_freshness_missing_or_stale"
        observed_at = freshness.get("observed_at")
        try:
            observed = RecoveryService._selection_timestamp(observed_at, "freshness.observed_at")
        except RecoveryError:
            return False, "completion_freshness_invalid"
        if observed > now:
            return False, "completion_freshness_invalid"
        return True, "completed_git_delivery"

    @staticmethod
    def _selection_activity(project: Mapping[str, Any], activity_policy: Mapping[str, Any] | None) -> tuple[float, str | None]:
        activity = project.get("activity")
        if not isinstance(activity, Mapping):
            activity = {}
        policy = activity_policy if isinstance(activity_policy, Mapping) else {}
        if "descending" in policy and not isinstance(policy["descending"], bool):
            raise RecoveryError("activity policy direction is invalid")
        field = policy.get("field", "last_activity_at")
        value = activity.get(field, project.get(field))
        if value is None and field != "last_activity_at":
            value = activity.get("last_activity_at", project.get("last_activity_at"))
        if value is None:
            return 0.0, None
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return float(value), str(value)
        if isinstance(value, str):
            return RecoveryService._selection_timestamp(value, "activity timestamp").timestamp(), value
        raise RecoveryError("activity value is invalid")

    def _selection_projects(self, project_evidence: Sequence[Mapping[str, Any]] | Mapping[str, Mapping[str, Any]]) -> list[dict[str, Any]]:
        if isinstance(project_evidence, Mapping):
            if "project_id" in project_evidence:
                records = [dict(project_evidence)]
            else:
                records = []
                for project_id, value in project_evidence.items():
                    if not isinstance(value, Mapping):
                        raise RecoveryError("project evidence is invalid")
                    records.append({"project_id": project_id, **dict(value)})
        elif isinstance(project_evidence, Sequence) and not isinstance(project_evidence, (str, bytes, bytearray)):
            records = [dict(item) for item in project_evidence if isinstance(item, Mapping)]
            if len(records) != len(project_evidence):
                raise RecoveryError("project evidence is invalid")
        else:
            raise RecoveryError("project evidence is invalid")
        result = []
        seen: set[str] = set()
        for record in records:
            project_id = record.get("project_id")
            _identifier(project_id)
            if project_id in seen:
                raise RecoveryError("project evidence contains duplicate project")
            seen.add(project_id)
            result.append(record)
        return result

    def _selection_sets(self, project_id: str) -> tuple[dict[str, dict[str, Any]], dict[str, int]]:
        directory = _child(self.config.local_root, "sets", project_id)
        manifests: dict[str, dict[str, Any]] = {}
        sizes: dict[str, int] = {}
        if not directory.exists():
            return manifests, sizes
        if directory.is_symlink() or not directory.is_dir():
            raise RecoveryError("recovery project namespace is unsafe")
        for child in directory.iterdir():
            if child.name.startswith(".") or not child.is_dir() or child.is_symlink():
                continue
            manifest = self._verify(child)
            manifests[manifest["set_id"]] = manifest
            sizes[manifest["set_id"]] = sum(entry["size"] for entry in manifest["files"])
        return manifests, sizes

    def cold_selection_plan(
        self,
        project_evidence: Sequence[Mapping[str, Any]] | Mapping[str, Mapping[str, Any]],
        *,
        capacity_bytes: int | None = None,
        now: datetime | None = None,
        activity_policy: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Plan cold sets from explicit project evidence without writing files.

        The planner does not copy, prune or mutate projects.  It reserves the
        newest dependency-complete set (and configured pins) for each selected
        project, then considers additional complete history in newest-first
        order.  Capacity is a scheduling input, never a deletion threshold.
        """
        if capacity_bytes is None:
            capacity_bytes = self.config.capacity_bytes
        if type(capacity_bytes) is not int or capacity_bytes < 1:
            raise RecoveryError("cold selection capacity is invalid")
        observed_at = now or datetime.now(timezone.utc)
        if observed_at.tzinfo is None:
            raise RecoveryError("selection time must include a timezone")
        observed_at = observed_at.astimezone(timezone.utc)
        records = self._selection_projects(project_evidence)
        policy = self._policy()
        prepared: list[dict[str, Any]] = []
        skipped: dict[str, dict[str, Any]] = {}
        skipped_sets: dict[str, dict[str, Any]] = {}
        for record in records:
            project_id = record["project_id"]
            excluded, evidence_reason = self._selection_evidence(record, observed_at)
            if excluded:
                skipped[project_id] = {"reason": evidence_reason}
                continue
            classification = policy["projects"].get(project_id, {}).get("classification", "AVG")
            priority = policy["projects"].get(project_id, {}).get("priority", 100)
            if classification not in _CLASSIFICATIONS or type(priority) is not int or priority < 1:
                raise RecoveryError("stored project policy is invalid")
            activity_score, activity_value = self._selection_activity(record, activity_policy)
            activity_descending = True if not isinstance(activity_policy, Mapping) else activity_policy.get("descending", True)
            manifests, sizes = self._selection_sets(project_id)
            complete: dict[str, set[str]] = {}
            visiting: set[str] = set()

            def closure(set_id: str) -> set[str] | None:
                if set_id in complete:
                    return complete[set_id]
                if set_id in visiting or set_id not in manifests:
                    return None
                visiting.add(set_id)
                dependencies: set[str] = {set_id}
                for dependency in manifests[set_id]["dependencies"]:
                    child = closure(dependency)
                    if child is None:
                        visiting.remove(set_id)
                        return None
                    dependencies.update(child)
                visiting.remove(set_id)
                complete[set_id] = dependencies
                return dependencies

            complete_ids = [set_id for set_id in manifests if closure(set_id) is not None]
            complete_ids.sort(key=lambda set_id: self._selection_manifest_timestamp(manifests[set_id]), reverse=True)
            for set_id in set(manifests) - set(complete_ids):
                skipped_sets[f"{project_id}/{set_id}"] = {"reason": "dependency_incomplete"}
            pinned = policy["projects"].get(project_id, {}).get("pinned", [])
            for set_id in pinned:
                if set_id not in manifests:
                    skipped_sets[f"{project_id}/{set_id}"] = {"reason": "pinned_milestone_missing"}
                elif set_id not in complete_ids:
                    skipped_sets[f"{project_id}/{set_id}"] = {
                        "reason": "pinned_milestone_incomplete",
                        "detail": "dependency_incomplete",
                    }
            if not complete_ids:
                skipped[project_id] = {"reason": "no_dependency_complete_set"}
                continue
            pinned_ids = [set_id for set_id in pinned if set_id in complete_ids]
            protected_ids = [complete_ids[0]] + [set_id for set_id in pinned_ids if set_id != complete_ids[0]]
            protected_ids.sort(key=lambda set_id: (set_id != complete_ids[0], self._selection_manifest_timestamp(manifests[set_id])), reverse=False)
            protected_set: set[str] = set()
            for set_id in protected_ids:
                protected_set.update(closure(set_id) or ())
            protected_size = sum(sizes[set_id] for set_id in protected_set)
            prepared.append({"project_id": project_id, "classification": classification, "priority": priority,
                             "activity_score": activity_score if activity_descending else -activity_score, "activity": activity_value, "manifests": manifests,
                             "sizes": sizes, "complete": complete, "complete_ids": complete_ids, "protected_ids": protected_ids,
                             "protected_set": protected_set, "protected_size": protected_size,
                             "evidence_reason": evidence_reason})
        prepared.sort(key=lambda item: (item["classification"] != "numbered",
                                        item["priority"] if item["classification"] == "numbered" else 0,
                                        -item["activity_score"], item["project_id"]))
        selected: list[dict[str, Any]] = []
        selected_projects: list[dict[str, Any]] = []
        allocated: dict[str, set[str]] = {}
        used = 0
        overflow = False
        protected_overflow = False
        overflow_reason: list[str] = []
        for item in prepared:
            required = item["protected_size"]
            available = max(0, capacity_bytes - used)
            if required > available:
                overflow = True
                protected_overflow = True
                overflow_reason.append("protected")
                if selected:
                    overflow_reason.append("protected_sets_do_not_fit")
                    skipped[item["project_id"]] = {"reason": "protected_sets_do_not_fit", "required_bytes": required,
                                                    "available_bytes": available}
                    continue
                overflow_reason.append("protected_sets_exceed_capacity")
            selected.append(item)
            allocated[item["project_id"]] = set()
            selected_projects.append({"project_id": item["project_id"], "classification": item["classification"],
                                      "priority": item["priority"], "activity": item["activity"],
                                      "protected_bytes": required, "evidence_reason": item["evidence_reason"]})
            used += required
            for set_id in item["protected_ids"]:
                if set_id in item["protected_set"]:
                    selected.append({"project_id": item["project_id"], "set_id": set_id, "size_bytes": item["sizes"][set_id], "reason": "protected" if set_id == item["complete_ids"][0] else "pinned", "dependencies": list(item["manifests"][set_id]["dependencies"])})
            for set_id in sorted(item["protected_set"] - set(item["protected_ids"]), key=lambda value: self._selection_manifest_timestamp(item["manifests"][value]), reverse=True):
                selected.append({"project_id": item["project_id"], "set_id": set_id, "size_bytes": item["sizes"][set_id], "reason": "dependency", "dependencies": list(item["manifests"][set_id]["dependencies"])})
            allocated[item["project_id"]].update(item["protected_set"])
        # Extra history is considered only after every selected project's
        # protected closure has been reserved.
        extras: list[tuple[datetime, dict[str, Any], int]] = []
        for item in selected_projects:
            prepared_item = next(value for value in prepared if value["project_id"] == item["project_id"])
            for set_id in prepared_item["complete_ids"]:
                if set_id not in allocated[item["project_id"]]:
                    closure_ids = prepared_item["complete"].get(set_id, {set_id})
                    extras.append((self._selection_manifest_timestamp(prepared_item["manifests"][set_id]), {"project_id": item["project_id"], "set_id": set_id, "reason": "history", "dependencies": list(prepared_item["manifests"][set_id]["dependencies"]), "_closure": closure_ids}, 0))
        extras.sort(key=lambda value: value[0], reverse=True)
        for _, candidate, _ in extras:
            project_id = candidate["project_id"]
            closure_ids = candidate.pop("_closure")
            project = next(item for item in prepared if item["project_id"] == project_id)
            size = sum(project["sizes"][set_id] for set_id in closure_ids if set_id not in allocated[project_id])
            if used + size > capacity_bytes:
                skipped_sets[f"{project_id}/{candidate['set_id']}"] = {"reason": "capacity", "required_bytes": size,
                                                                       "available_bytes": max(0, capacity_bytes - used)}
                continue
            for set_id in sorted(closure_ids, key=lambda value: self._selection_manifest_timestamp(project["manifests"][value]), reverse=True):
                if set_id in allocated[project_id]:
                    continue
                selected.append({"project_id": project_id, "set_id": set_id, "size_bytes": project["sizes"][set_id], "reason": "history" if set_id == candidate["set_id"] else "dependency", "dependencies": list(project["manifests"][set_id]["dependencies"])})
                allocated[project_id].add(set_id)
            used += size
        return {"planning_only": True, "capacity_bytes": capacity_bytes, "used_bytes": used,
                "remaining_bytes": max(0, capacity_bytes - used), "overflow": overflow,
                "overflow_reason": overflow_reason, "selected_projects": selected_projects,
                "protected_overflow": protected_overflow, "selected_sets": [item for item in selected if "set_id" in item],
                "skipped_projects": skipped, "skipped_sets": skipped_sets,
                "deletion_performed": False, "write_performed": False}

    # Names retained as small public aliases for operator/integration callers.
    plan_cold_selection = cold_selection_plan
    plan_cold_backups = cold_selection_plan
