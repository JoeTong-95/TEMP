"""Loopback HTTP transport for immutable complete runtime bundles.

The storage core owns durability and verification. This adapter only moves a
bounded base64 representation across a local authenticated HTTP boundary; it
never executes receipts. Streaming and cross-machine transfer are deliberately
out of scope for this v1 transport.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import hmac
import json
import os
from pathlib import Path
import ssl
import stat
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Mapping
from urllib.parse import unquote, urlsplit

from shared.contracts.storage_runtime_bundle import (
    MAX_BODY_BYTES,
    MAX_FILES,
    MAX_FILE_BYTES,
    RuntimeBundleHttpClient,
    ServiceError,
    UnknownRuntimeBundleOutcome,
    _decode_files,
    _encode_files,
    _identifier,
    _safe_existing_path,
    _safe_relative_file,
    _token,
)
from .storage_runtime_bundles import RuntimeBundleError, materialize, publish


MAX_PATH_BYTES = 256
MAX_PATH_DEPTH = 8


def _reject_json_constant(_: str) -> None:
    raise ValueError("non-finite JSON values are unsupported")


def _load_json(raw: bytes) -> Any:
    return json.loads(raw.decode("utf-8"), parse_constant=_reject_json_constant)


def _safe_private_file(path: Path) -> Path:
    path = _safe_existing_path(path, directory=False)
    if os.name != "nt" and stat.S_IMODE(path.stat().st_mode) & 0o077:
        raise ServiceError("private file mode is too broad")
    return path


def _scope_map(value: Mapping[str, frozenset[str]]) -> dict[str, frozenset[str]]:
    if not isinstance(value, Mapping) or not value:
        raise ServiceError("credential scopes are invalid")
    copied: dict[str, frozenset[str]] = {}
    for project, agents in value.items():
        _identifier(project)
        if not isinstance(agents, frozenset) or not agents:
            raise ServiceError("credential scopes are invalid")
        copied[project] = frozenset(_identifier(agent) for agent in agents)
    return copied


@dataclass(frozen=True)
class Config:
    storage_root: Path
    temporary_root: Path
    credentials: Mapping[str, Mapping[str, frozenset[str]]] = field(repr=False)
    host: str = "127.0.0.1"
    port: int = 0
    max_body_bytes: int = MAX_BODY_BYTES
    tls_certificate_file: Path | None = None
    tls_private_key_file: Path | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.host, str) or not self.host or type(self.port) is not int or not 0 <= self.port <= 65535:
            raise ServiceError("service address is invalid")
        loopback = self.host in {"127.0.0.1", "::1", "localhost"}
        if (self.tls_certificate_file is None) != (self.tls_private_key_file is None):
            raise ServiceError("TLS certificate and key must be supplied together")
        if not loopback and self.tls_certificate_file is None:
            raise ServiceError("non-loopback service requires TLS")
        if self.tls_certificate_file is not None:
            certificate = _safe_existing_path(Path(self.tls_certificate_file), directory=False)
            key = _safe_existing_path(Path(self.tls_private_key_file), directory=False)
            if os.name != "nt" and stat.S_IMODE(key.stat().st_mode) & 0o077:
                raise ServiceError("TLS private key mode is too broad")
            object.__setattr__(self, "tls_certificate_file", certificate)
            object.__setattr__(self, "tls_private_key_file", key)
        if type(self.max_body_bytes) is not int or not 1024 <= self.max_body_bytes <= MAX_BODY_BYTES:
            raise ServiceError("body limit is invalid")
        _safe_existing_path(self.storage_root, directory=True)
        _safe_existing_path(self.temporary_root, directory=True)
        if not isinstance(self.credentials, Mapping) or not self.credentials:
            raise ServiceError("credentials are required")
        clean: dict[str, dict[str, frozenset[str]]] = {}
        for supplied, scopes in self.credentials.items():
            token = _token(supplied)
            if token in clean:
                raise ServiceError("duplicate credential")
            clean[token] = _scope_map(scopes)
        object.__setattr__(self, "credentials", clean)


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, configuration: Config):
        self.config = configuration
        super().__init__((configuration.host, configuration.port), Handler)
        if configuration.tls_certificate_file is not None:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(str(configuration.tls_certificate_file), str(configuration.tls_private_key_file))
            self.socket = context.wrap_socket(self.socket, server_side=True)


class Handler(BaseHTTPRequestHandler):
    server: Server

    def log_message(self, *_: Any) -> None:
        return

    def _route(self) -> tuple[str, str, str, bool] | None:
        parsed = urlsplit(self.path)
        if parsed.query or parsed.fragment:
            return None
        pieces = parsed.path.strip("/").split("/")
        is_materialize = len(pieces) == 7 and pieces[-1] == "materialize"
        if len(pieces) not in {6, 7} or pieces[:1] != ["projects"] or pieces[2:3] != ["agents"] or pieces[4:5] != ["runtime-bundles"]:
            return None
        if len(pieces) == 7 and not is_materialize:
            return None
        try:
            return _identifier(unquote(pieces[1])), _identifier(unquote(pieces[3])), _identifier(unquote(pieces[5])), is_materialize
        except (ServiceError, UnicodeError):
            return None

    def _authorized(self, project_id: str, agent_id: str) -> bool:
        header = self.headers.get("Authorization", "")
        presented = header[7:] if header.startswith("Bearer ") else ""
        return any(hmac.compare_digest(presented, token) and agent_id in scopes.get(project_id, frozenset()) for token, scopes in self.server.config.credentials.items())

    def _reply(self, status: int, value: Mapping[str, Any]) -> None:
        raw = json.dumps(value, separators=(",", ":"), allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(raw)

    def _body(self, *, empty_object: bool = False) -> Mapping[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError as error:
            raise ServiceError("invalid content length") from error
        if self.headers.get("Content-Type", "").split(";", 1)[0] != "application/json" or not 0 <= length <= self.server.config.max_body_bytes:
            raise ServiceError("bounded JSON required")
        value = _load_json(self.rfile.read(length))
        if not isinstance(value, Mapping):
            raise ServiceError("JSON object required")
        if empty_object:
            if value:
                raise ServiceError("materialize body must be empty")
        elif set(value) - {"files", "sha256"} or "files" not in value or not isinstance(value["files"], list):
            raise ServiceError("exact file list required")
        elif "sha256" in value and not isinstance(value["sha256"], Mapping):
            raise ServiceError("invalid file integrity manifest")
        return value

    def do_POST(self) -> None:
        route = self._route()
        if route is None:
            self._reply(404, {"error": "not_found"})
            return
        project_id, agent_id, checkpoint_id, is_materialize = route
        if not self._authorized(project_id, agent_id):
            self._reply(401, {"error": "unauthorized"})
            return
        try:
            if is_materialize:
                self._body(empty_object=True)
                with tempfile.TemporaryDirectory(dir=self.server.config.temporary_root) as temporary:
                    target = Path(temporary) / "bundle"
                    record = materialize(self.server.config.storage_root, project_id, agent_id, checkpoint_id, target)
                    value = _encode_files(target, self.server.config.max_body_bytes, record["files"])
                    self._reply(200, {"checkpoint_id": checkpoint_id, **value})
                return
            body = self._body()
            with tempfile.TemporaryDirectory(dir=self.server.config.temporary_root) as temporary:
                source = Path(temporary)
                _decode_files(body["files"], source, self.server.config.max_body_bytes, body.get("sha256"))
                result = publish(self.server.config.storage_root, source, project_id, agent_id, checkpoint_id)
            self._reply(200, {"checkpoint_id": checkpoint_id, "files": sorted(result["files"]), "sha256": result["files"]})
        except (OSError, RuntimeBundleError, ServiceError, ValueError):
            self._reply(409, {"error": "rejected"})

    def do_GET(self) -> None:
        route = self._route()
        if route is None or route[3]:
            self._reply(404, {"error": "not_found"})
            return
        project_id, agent_id, checkpoint_id, _ = route
        if not self._authorized(project_id, agent_id):
            self._reply(401, {"error": "unauthorized"})
            return
        try:
            with tempfile.TemporaryDirectory(dir=self.server.config.temporary_root) as temporary:
                target = Path(temporary) / "bundle"
                record = materialize(self.server.config.storage_root, project_id, agent_id, checkpoint_id, target)
                value = _encode_files(target, self.server.config.max_body_bytes, record["files"])
                self._reply(200, {"checkpoint_id": checkpoint_id, **value})
        except (OSError, RuntimeBundleError, ServiceError):
            self._reply(409, {"error": "rejected"})


def serve(configuration: Config) -> Server:
    return Server(configuration)


def load_configuration(path: str | Path) -> Config:
    config_path = _safe_private_file(Path(path))
    try:
        raw = _load_json(config_path.read_bytes())
    except (OSError, ValueError, UnicodeError) as error:
        raise ServiceError("configuration is invalid") from error
    required = {"storage_root", "temporary_root", "credentials"}
    optional = {"host", "port", "max_body_bytes", "tls_certificate_file", "tls_private_key_file"}
    if not isinstance(raw, Mapping) or set(raw) - (required | optional) or not required.issubset(raw) or not isinstance(raw["credentials"], list):
        raise ServiceError("configuration schema is invalid")
    for field_name in ("storage_root", "temporary_root", "tls_certificate_file", "tls_private_key_file"):
        if field_name in raw and not isinstance(raw[field_name], str):
            raise ServiceError("configuration path is invalid")
    credentials: dict[str, dict[str, frozenset[str]]] = {}
    for entry in raw["credentials"]:
        if not isinstance(entry, Mapping) or set(entry) != {"token_file", "scopes"} or not isinstance(entry["token_file"], str) or not isinstance(entry["scopes"], Mapping):
            raise ServiceError("credential entry is invalid")
        token_path = _safe_private_file(Path(entry["token_file"]))
        try:
            token = _token(token_path.read_text(encoding="ascii").strip())
        except (OSError, UnicodeError, ServiceError) as error:
            raise ServiceError("credential token is invalid") from error
        if token in credentials:
            raise ServiceError("duplicate credential")
        scopes: dict[str, frozenset[str]] = {}
        for project, agents in entry["scopes"].items():
            _identifier(project)
            if not isinstance(agents, list) or not agents:
                raise ServiceError("credential scopes are invalid")
            scopes[project] = frozenset(_identifier(agent) for agent in agents)
        credentials[token] = scopes
    return Config(Path(raw["storage_root"]), Path(raw["temporary_root"]), credentials, raw.get("host", "127.0.0.1"), raw.get("port", 0), raw.get("max_body_bytes", MAX_BODY_BYTES), Path(raw["tls_certificate_file"]) if "tls_certificate_file" in raw else None, Path(raw["tls_private_key_file"]) if "tls_private_key_file" in raw else None)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--check", action="store_true")
    arguments = parser.parse_args(argv)
    configuration = load_configuration(arguments.config)
    if arguments.check:
        print("configuration validated; listener was not started")
        return 0
    server = serve(configuration)
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
