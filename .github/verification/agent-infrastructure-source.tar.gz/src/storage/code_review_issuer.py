"""Independent verifier-side bridge from completed test evidence to review receipts."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .code_review_receipts import CodeReviewReceiptError, CodeReviewReceiptStore
from .verification_service import VerificationService, VerificationServiceError


class CodeReviewIssuerError(ValueError):
    pass


@dataclass(frozen=True)
class ReviewCommand:
    evaluator_revision: str


class CodeReviewIssuer:
    """Only independent verification owns this write-side receipt capability."""

    def __init__(self, verification: VerificationService, store: CodeReviewReceiptStore, reviewer_id: str, commands: Mapping[str, ReviewCommand]):
        if not isinstance(verification, VerificationService) or not isinstance(store, CodeReviewReceiptStore) or store.read_only:
            raise CodeReviewIssuerError("review issuer dependencies are invalid")
        if not isinstance(reviewer_id, str) or not reviewer_id or any(char.isspace() for char in reviewer_id) or not commands:
            raise CodeReviewIssuerError("review issuer configuration is invalid")
        if any(not isinstance(key, str) or not key or not isinstance(value, ReviewCommand) or not value.evaluator_revision for key, value in commands.items()):
            raise CodeReviewIssuerError("review command configuration is invalid")
        self.verification, self.store, self.reviewer_id, self.commands = verification, store, reviewer_id, dict(commands)

    def issue(self, verification_operation_id: str, project_id: str, subject: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(subject, Mapping) or set(subject) != {"repo_alias", "pull_number", "head_sha"}:
            raise CodeReviewIssuerError("review subject schema is invalid")
        try:
            evidence = self.verification.operation(verification_operation_id, project_id)
        except VerificationServiceError as error:
            raise CodeReviewIssuerError("verification evidence is unavailable") from error
        result = evidence.get("result")
        command = self.commands.get(evidence.get("command_id"))
        if (command is None or evidence.get("state") != "completed" or not isinstance(result, Mapping)
                or result.get("result") != "passed" or result.get("exit_code") != 0):
            raise CodeReviewIssuerError("verification is not an approved successful review command")
        receipt = {
            "operation_id": verification_operation_id, "project_id": project_id,
            "command_id": evidence["command_id"], "evaluator_revision": command.evaluator_revision,
            "state": "passed", "reviewer_id": self.reviewer_id, "subject": dict(subject),
        }
        try:
            return self.store.issue(receipt)
        except CodeReviewReceiptError as error:
            raise CodeReviewIssuerError("review receipt could not be issued") from error
