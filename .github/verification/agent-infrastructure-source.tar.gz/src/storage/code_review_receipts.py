"""Durable independent code-review receipts used by the merge authority.

This store knows nothing about Gitea statuses.  Production grants the merge
process its narrow read-only ``get`` capability, never the ``issue`` capability.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3
from contextlib import closing
from typing import Any, Mapping


class CodeReviewReceiptError(ValueError):
    pass


def _safe_database(path: Path) -> None:
    if not path.is_absolute() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise CodeReviewReceiptError("receipt database path is unsafe")
    if not path.parent.is_dir():
        raise CodeReviewReceiptError("receipt database parent is missing")


def _nonempty_string(value: object, label: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 256 or any(char.isspace() for char in value):
        raise CodeReviewReceiptError(f"{label} is invalid")
    return value


def _validate_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    required = {"operation_id", "project_id", "command_id", "evaluator_revision", "state", "reviewer_id", "subject"}
    if not isinstance(receipt, Mapping) or set(receipt) != required:
        raise CodeReviewReceiptError("code review receipt schema is invalid")
    for field in required - {"subject"}:
        _nonempty_string(receipt.get(field), field)
    if receipt["state"] not in {"passed", "failed"}:
        raise CodeReviewReceiptError("receipt state is invalid")
    subject = receipt["subject"]
    if not isinstance(subject, Mapping) or set(subject) != {"repo_alias", "pull_number", "head_sha"}:
        raise CodeReviewReceiptError("receipt subject schema is invalid")
    _nonempty_string(subject.get("repo_alias"), "receipt repository alias")
    if type(subject.get("pull_number")) is not int or subject["pull_number"] < 1:
        raise CodeReviewReceiptError("receipt pull number is invalid")
    head = subject.get("head_sha")
    if not isinstance(head, str) or len(head) != 40 or any(char not in "0123456789abcdef" for char in head):
        raise CodeReviewReceiptError("receipt head SHA is invalid")
    return json.loads(json.dumps(dict(receipt), sort_keys=True, separators=(",", ":")))


class CodeReviewReceiptStore:
    """Write-side store owned by independent verification, not Gitea clients."""

    def __init__(self, database: str | Path, *, read_only: bool = False):
        self.database = Path(database)
        _safe_database(self.database)
        self.read_only = read_only
        if os.name == "posix" and self.database.exists() and self.database.stat().st_mode & 0o077:
            raise CodeReviewReceiptError("receipt database must not be group/world accessible")
        if read_only:
            if not self.database.is_file():
                raise CodeReviewReceiptError("read-only receipt database is missing")
        else:
            # sqlite otherwise creates with the process umask, which may be too
            # broad for a later narrow read-only merge provider on POSIX.
            if not self.database.exists():
                descriptor = os.open(self.database, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                os.close(descriptor)
            if os.name == "posix":
                os.chmod(self.database, 0o600)
            with closing(sqlite3.connect(self.database)) as connection:
                connection.execute("CREATE TABLE IF NOT EXISTS code_review_receipts(operation_id TEXT PRIMARY KEY,receipt TEXT NOT NULL)")
                connection.commit()

    def _connect(self) -> sqlite3.Connection:
        if self.read_only:
            return sqlite3.connect(f"file:{self.database.as_posix()}?mode=ro", uri=True)
        return sqlite3.connect(self.database)

    def issue(self, receipt: Mapping[str, Any]) -> dict[str, Any]:
        if self.read_only:
            raise CodeReviewReceiptError("read-only receipt provider cannot issue receipts")
        normalized = _validate_receipt(receipt)
        encoded = json.dumps(normalized, sort_keys=True, separators=(",", ":"))
        with closing(self._connect()) as connection:
            old = connection.execute("SELECT receipt FROM code_review_receipts WHERE operation_id=?", (normalized["operation_id"],)).fetchone()
            if old is not None and old[0] != encoded:
                raise CodeReviewReceiptError("receipt operation replay conflicts")
            if old is None:
                connection.execute("INSERT INTO code_review_receipts VALUES(?,?)", (normalized["operation_id"], encoded))
            connection.commit()
        return normalized

    def get(self, operation_id: str) -> dict[str, Any]:
        _nonempty_string(operation_id, "receipt operation id")
        with closing(self._connect()) as connection:
            row = connection.execute("SELECT receipt FROM code_review_receipts WHERE operation_id=?", (operation_id,)).fetchone()
        if row is None:
            raise CodeReviewReceiptError("receipt not found")
        return _validate_receipt(json.loads(row[0]))


class ReadOnlyReceiptProvider:
    """Narrow same-process provider; only configured project receipts can be read."""

    def __init__(self, store: CodeReviewReceiptStore, allowed_projects: frozenset[str]):
        if not isinstance(store, CodeReviewReceiptStore) or not allowed_projects:
            raise CodeReviewReceiptError("read-only receipt provider configuration is invalid")
        self._store = store
        self._allowed_projects = frozenset(_nonempty_string(project, "allowed project") for project in allowed_projects)

    def get(self, operation_id: str) -> dict[str, Any]:
        receipt = self._store.get(operation_id)
        if receipt["project_id"] not in self._allowed_projects:
            raise CodeReviewReceiptError("receipt project is outside provider scope")
        return receipt
