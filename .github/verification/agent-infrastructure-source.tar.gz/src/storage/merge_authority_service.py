"""Minimal JSON-lines service wrapper for the Storage merge authority.

This is intentionally a private local process contract.  A future authenticated
Management endpoint may call it, but it must not expose the merge token or the
receipt write capability.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
from typing import Any, Mapping

from .code_review_receipts import CodeReviewReceiptStore, ReadOnlyReceiptProvider
from .gitea_merge_authority import ForgeTransportRegistry, MergeAuthority, MergeAuthorityConfig, MergeAuthorityError, RepoBinding, build_forge_transport
from shared.contracts.forge import normalize_forge_provider


def _private_config(path: Path) -> Mapping[str, Any]:
    if not path.is_absolute() or not path.is_file() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise MergeAuthorityError("merge authority config path is unsafe")
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise MergeAuthorityError("merge authority config must be root/service-private")
    loaded = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, Mapping):
        raise MergeAuthorityError("merge authority config must be an object")
    return loaded


def build_from_config(path: str | Path) -> MergeAuthority:
    config_path = Path(path)
    raw = _private_config(config_path)
    required = {"database", "merge_token_file", "merge_principal", "receipt_database", "repositories"}
    allowed = required | {"forge_provider", "forge_origin", "gitea_origin", "github_origin"}
    if not required <= set(raw) or set(raw) - allowed or not isinstance(raw["repositories"], Mapping):
        raise MergeAuthorityError("merge authority config schema is invalid")
    configured_provider = raw.get("forge_provider")
    if configured_provider is None:
        # Existing local deployments named only gitea_origin.  Keep those
        # configs compatible while all new configs default to GitHub.
        configured_provider = "gitea" if "gitea_origin" in raw else "github"
    try:
        configured_provider = normalize_forge_provider(configured_provider)
    except ValueError as error:
        raise MergeAuthorityError(str(error)) from error
    origin = raw.get("forge_origin", raw.get("github_origin", raw.get("gitea_origin")))
    if configured_provider == "gitea" and not isinstance(origin, str):
        raise MergeAuthorityError("Gitea origin is required for the optional Gitea adapter")
    repositories: dict[str, RepoBinding] = {}
    providers: set[str] = set()
    for alias, value in raw["repositories"].items():
        binding_required = {"owner", "repository", "base", "project_id", "command_id", "evaluator_revision"}
        if (not isinstance(value, Mapping) or set(value) - (binding_required | {"forge_provider", "repository_url"})
                or not binding_required <= set(value)):
            raise MergeAuthorityError("repository binding config schema is invalid")
        item = dict(value)
        item.setdefault("forge_provider", configured_provider)
        repositories[alias] = RepoBinding(**item)
        providers.add(repositories[alias].forge_provider)
    authority_config = MergeAuthorityConfig(Path(raw["database"]), Path(raw["merge_token_file"]), raw["merge_principal"], repositories)
    provider = ReadOnlyReceiptProvider(CodeReviewReceiptStore(Path(raw["receipt_database"]), read_only=True), frozenset(binding.project_id for binding in repositories.values()))
    adapters = {}
    for name in providers:
        adapter_origin = origin
        if name == "github":
            adapter_origin = raw.get("github_origin", adapter_origin)
        elif name == "gitea":
            adapter_origin = raw.get("gitea_origin", adapter_origin)
        adapters[name] = build_forge_transport(name, adapter_origin)
    return MergeAuthority(authority_config, ForgeTransportRegistry(adapters), provider.get)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="private receipt-gated Gitea merge authority")
    parser.add_argument("--config", required=True, help="absolute, service-private JSON config")
    args = parser.parse_args(argv)
    authority = build_from_config(args.config)
    for line in sys.stdin:
        try:
            envelope = json.loads(line)
            if not isinstance(envelope, Mapping) or set(envelope) != {"operation", "request"}:
                raise MergeAuthorityError("request envelope schema is invalid")
            if envelope["operation"] == "merge":
                result = authority.request(envelope["request"])
            elif envelope["operation"] == "reconcile" and isinstance(envelope["request"], Mapping) and set(envelope["request"]) == {"operation_id"}:
                result = authority.reconcile(envelope["request"]["operation_id"])
            else:
                raise MergeAuthorityError("unsupported merge authority operation")
            print(json.dumps({"ok": True, "result": result}, sort_keys=True), flush=True)
        except (MergeAuthorityError, ValueError) as error:
            print(json.dumps({"ok": False, "error": str(error)}, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
