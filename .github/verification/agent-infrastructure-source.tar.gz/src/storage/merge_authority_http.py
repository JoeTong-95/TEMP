"""Authenticated loopback HTTP boundary for receipt-gated merge authority."""
from __future__ import annotations

import hmac
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from typing import Any, Mapping

from .gitea_merge_authority import MergeAuthority, MergeAuthorityError


MAX_BODY = 16 * 1024


class MergeAuthorityHttpServer(ThreadingHTTPServer):
    def __init__(self, address: tuple[str, int], authority: MergeAuthority, token_projects: Mapping[str, frozenset[str]]):
        if address[0] != "127.0.0.1" or not token_projects:
            raise MergeAuthorityError("merge HTTP server must be loopback with explicit scopes")
        if any(not isinstance(token, str) or not token or not isinstance(projects, frozenset) or not projects for token, projects in token_projects.items()):
            raise MergeAuthorityError("merge HTTP token scopes are invalid")
        self.authority, self.token_projects = authority, dict(token_projects)
        super().__init__(address, make_handler(self))


def make_handler(server: MergeAuthorityHttpServer):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _reply(self, status: HTTPStatus, value: Mapping[str, Any]) -> None:
            raw = json.dumps(dict(value), separators=(",", ":"), allow_nan=False).encode()
            self.send_response(status); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(raw))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(raw)

        def _authorized(self, project_id: str) -> bool:
            header = self.headers.get("Authorization", "")
            supplied = header[7:] if header.startswith("Bearer ") else ""
            return any(hmac.compare_digest(supplied, token) and project_id in projects for token, projects in server.token_projects.items())

        def _body(self) -> Mapping[str, Any] | None:
            try:
                length = int(self.headers.get("Content-Length", "-1"))
                if not 0 <= length <= MAX_BODY:
                    raise ValueError
                body = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(body, Mapping):
                    raise ValueError
                return body
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                self._reply(HTTPStatus.BAD_REQUEST, {"error": "invalid_request"})
                return None

        def do_POST(self) -> None:
            parts=[part for part in self.path.split("/") if part]
            if len(parts)==3 and parts[0]=="merges" and parts[2]=="retry":
                try:
                    project=server.authority.operation_project(parts[1])
                    if not self._authorized(project): self._reply(HTTPStatus.FORBIDDEN,{"error":"not_permitted"}); return
                    self._reply(HTTPStatus.OK,server.authority.retry_unknown(parts[1])); return
                except MergeAuthorityError as error: self._reply(HTTPStatus.CONFLICT,{"error":str(error)}); return
            if self.path != "/merges":
                self._reply(HTTPStatus.NOT_FOUND, {"error": "not_found"}); return
            body = self._body()
            if body is None:
                return
            alias = body.get("repo_alias")
            binding = server.authority.config.repositories.get(alias) if isinstance(alias, str) else None
            if binding is None or not self._authorized(binding.project_id):
                self._reply(HTTPStatus.FORBIDDEN, {"error": "not_permitted"}); return
            try:
                result = server.authority.request(body)
                self._reply(HTTPStatus.OK, result)
            except MergeAuthorityError as error:
                self._reply(HTTPStatus.CONFLICT, {"error": str(error)})

        def do_GET(self) -> None:
            parts = [part for part in self.path.split("/") if part]
            if len(parts) != 2 or parts[0] != "merges":
                self._reply(HTTPStatus.NOT_FOUND, {"error": "not_found"}); return
            try:
                project = server.authority.operation_project(parts[1])
                if not self._authorized(project):
                    self._reply(HTTPStatus.FORBIDDEN, {"error": "not_permitted"}); return
                self._reply(HTTPStatus.OK, server.authority.reconcile(parts[1]))
            except MergeAuthorityError as error:
                self._reply(HTTPStatus.NOT_FOUND, {"error": str(error)})
    return Handler


def serve(authority: MergeAuthority, token_projects: Mapping[str, frozenset[str]], address: tuple[str, int] = ("127.0.0.1", 0)) -> MergeAuthorityHttpServer:
    return MergeAuthorityHttpServer(address, authority, token_projects)
