"""Ephemeral two-phase acceptance harness; no historical service mutation."""
from __future__ import annotations

from dataclasses import dataclass, replace
import json
from pathlib import Path
import threading
import urllib.error
import urllib.request
from typing import Any, Mapping

from .code_review_issuer import CodeReviewIssuer, ReviewCommand
from .code_review_issuer_http import serve as review_serve
from .code_review_receipts import CodeReviewReceiptStore
from .gitea_acceptance_driver import AcceptanceConfig, GiteaAcceptanceDriver
from .gitea_merge_authority import HttpGiteaTransport, MergeAuthority, MergeAuthorityConfig, RepoBinding
from .merge_authority_http import serve as merge_serve
from .verification_service import VerificationResources, VerificationService, VerificationServiceConfiguration, serve as verification_serve


@dataclass(frozen=True)
class LiveHarnessConfig:
    acceptance: AcceptanceConfig
    state_dir: Path

    def __post_init__(self) -> None:
        if (not self.state_dir.is_absolute() or self.state_dir.exists() or self.state_dir.is_symlink()
                or not self.state_dir.parent.is_dir()):
            raise ValueError("state directory must be an absent explicit child")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request: Any, fp: Any, code: int, message: str, headers: Any, newurl: str) -> None:
        return None


class HarnessHttp:
    """Bounded local HTTP client: proxies and redirects are deliberately disabled."""

    def request(self, method: str, url: str, headers: Mapping[str, str], body: Mapping[str, Any] | None = None) -> tuple[int, Mapping[str, Any]]:
        data = None if body is None else json.dumps(body, separators=(",", ":"), allow_nan=False).encode("utf-8")
        request = urllib.request.Request(url, data=data, method=method, headers=dict(headers))
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
        try:
            with opener.open(request, timeout=20) as response:
                raw = response.read(64 * 1024 + 1)
                return response.status, self._json(raw)
        except urllib.error.HTTPError as error:
            raw = error.read(64 * 1024 + 1)
            return error.code, self._json(raw)

    @staticmethod
    def _json(raw: bytes) -> Mapping[str, Any]:
        if len(raw) > 64 * 1024:
            raise ValueError("acceptance HTTP response exceeds limit")
        try:
            value = json.loads(raw or b"{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError("acceptance HTTP response is invalid") from error
        if not isinstance(value, Mapping):
            raise ValueError("acceptance HTTP response is invalid")
        return value


def _start(server: Any) -> threading.Thread:
    thread = threading.Thread(target=server.serve_forever, name="gitea-acceptance-authority")
    thread.start()
    return thread


def _stop(servers: tuple[Any, ...], threads: tuple[threading.Thread, ...]) -> None:
    if threads:
        for server in servers:
            server.shutdown()
    for server in servers:
        server.server_close()
    for thread in threads:
        thread.join(timeout=10)
        if thread.is_alive():
            raise RuntimeError("acceptance authority did not stop")


def run(config: LiveHarnessConfig) -> dict[str, Any]:
    """Run only an isolated, uniquely named local acceptance PR."""
    config.state_dir.mkdir(mode=0o700)
    acceptance = config.acceptance
    root = acceptance.acceptance_root
    if root is None:
        raise ValueError("acceptance root is required")

    # The checkout destination must be absent until prepare_checkout. Bind the
    # listener to a dedicated empty child first; it is rebound before verification.
    bootstrap_workspace = root / ".gitea-acceptance-bootstrap"
    if bootstrap_workspace.exists() or bootstrap_workspace.is_symlink():
        raise ValueError("acceptance bootstrap workspace must be absent")
    bootstrap_workspace.mkdir(mode=0o700)
    servers: list[Any] = []
    threads: list[threading.Thread] = []
    try:
        verification_token = acceptance.verification_token_file.read_text(encoding="utf-8").strip()
        verification = VerificationService(VerificationServiceConfiguration(
            root, config.state_dir / "verification.sqlite", config.state_dir,
            {acceptance.project_id: {acceptance.verification_workspace_id: bootstrap_workspace.name}},
            {acceptance.verification_command_id: VerificationResources()},
            {verification_token: frozenset({acceptance.project_id})},
        ))
        verification_server = verification_serve(verification); servers.append(verification_server)
        receipts = CodeReviewReceiptStore(config.state_dir / "receipts.sqlite")
        issuer = CodeReviewIssuer(verification, receipts, "independent-reviewer", {
            acceptance.verification_command_id: ReviewCommand("acceptance-policy"),
        })
        review_token = acceptance.review_token_file.read_text(encoding="utf-8").strip()
        review_server = review_serve(issuer, {review_token: frozenset({acceptance.project_id})}); servers.append(review_server)
        merge_token = acceptance.merge_token_file.read_text(encoding="utf-8").strip()
        binding = RepoBinding(acceptance.owner, acceptance.repository, "main", acceptance.project_id,
                              acceptance.verification_command_id, "acceptance-policy")
        authority = MergeAuthority(MergeAuthorityConfig(
            config.state_dir / "merge.sqlite", acceptance.merge_token_file, "synthetic-merge",
            {acceptance.project_id: binding},
        ), HttpGiteaTransport(acceptance.gitea_origin), receipts.get)
        merge_server = merge_serve(authority, {merge_token: frozenset({acceptance.project_id})}); servers.append(merge_server)
        threads.extend(_start(server) for server in servers)
        live_acceptance = replace(
            acceptance,
            verification_origin=f"http://127.0.0.1:{verification_server.server_address[1]}",
            review_origin=f"http://127.0.0.1:{review_server.server_address[1]}",
            merge_origin=f"http://127.0.0.1:{merge_server.server_address[1]}",
        )
        driver = GiteaAcceptanceDriver(live_acceptance, HarnessHttp())
        prepared = driver.prepare_checkout()
        relative = Path(prepared.checkout_path).relative_to(root).as_posix()
        verification.config = replace(verification.config, project_workspaces={
            live_acceptance.project_id: {live_acceptance.verification_workspace_id: relative},
        })
        return driver.execute_prepared(prepared)
    finally:
        _stop(tuple(servers), tuple(threads))
