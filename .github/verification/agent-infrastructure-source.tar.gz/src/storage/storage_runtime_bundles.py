"""Immutable storage for complete portable Hermes checkpoint bundles.

This is a filesystem core only: it never executes operation receipts or starts
runtime processes. HTTP streaming and cross-machine soak remain later work.
"""
from __future__ import annotations
import hashlib, json, os, re, shutil, tempfile
from pathlib import Path
from typing import Any, Mapping

SAFE=re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$"); MAX_FILES=64; MAX_FILE_BYTES=16*1024*1024; MAX_TOTAL_BYTES=64*1024*1024
class RuntimeBundleError(ValueError): pass
def digest(p:Path)->str:
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
def root(p:str|Path,create=False)->Path:
 p=Path(p).absolute(); c=Path(p.anchor)
 for part in p.parts[1:]:
  c/=part
  if c.exists() and c.is_symlink():raise RuntimeBundleError("symlinked root ancestor")
 if create:p.mkdir(parents=True,exist_ok=True)
 if not p.is_dir() or p.is_symlink():raise RuntimeBundleError("safe directory required")
 return p
def namespace(*v:str):
 if not all(isinstance(x,str) and SAFE.fullmatch(x) for x in v):raise RuntimeBundleError("unsafe bundle namespace")
def child(base:Path,*parts:str,create=False)->Path:
 current=base
 for part in parts:
  current=current/part
  if current.exists() and current.is_symlink():raise RuntimeBundleError("symlinked bundle ancestor")
  if create and not current.exists():current.mkdir(mode=0o700)
  if create and (not current.is_dir() or current.is_symlink()):raise RuntimeBundleError("unsafe bundle ancestor")
 return current
def fsync_dir(p:Path):
 try:
  fd=os.open(p,os.O_RDONLY)
  try:os.fsync(fd)
  finally:os.close(fd)
 except PermissionError:
  if os.name!="nt":raise
def files(source:Path,bundle:Mapping[str,Any],stored:bool=False)->dict[str,str]:
 if set(bundle)!={"format","session_id","native","pause_state","semantic_handoff","files"} or bundle.get("format")!="agentstack.hermes.checkpoint.v1" or not isinstance(bundle.get("session_id"),str) or not isinstance(bundle.get("native"),Mapping) or not isinstance(bundle.get("files"),Mapping) or bundle.get("pause_state") not in {"idle","paused"} or not isinstance(bundle.get("semantic_handoff"),Mapping) or set(bundle["semantic_handoff"])-{"last_outcome","last_finished_at"}:raise RuntimeBundleError("bundle schema invalid")
 manifests=list(source.glob("*.manifest.json"))
 if len(manifests)!=1:raise RuntimeBundleError("exactly one native manifest required")
 native=bundle["native"]; manifest=manifests[0]
 try: native_file=json.loads(manifest.read_text())
 except (OSError,ValueError) as e:raise RuntimeBundleError("native manifest invalid") from e
 if native_file!=native or native.get("session_id")!=bundle["session_id"] or not isinstance(native.get("database"),str) or Path(native["database"]).name!=native["database"] or not re.fullmatch(r"[0-9a-f]{64}",str(native.get("sha256"))):raise RuntimeBundleError("native identity invalid")
 declared={"bundle.json",manifest.name,native["database"]}; hashes={manifest.name:digest(manifest)}
 db=source/native["database"]
 if not db.is_file() or db.is_symlink() or digest(db)!=native["sha256"]:raise RuntimeBundleError("native database checksum")
 hashes[db.name]=digest(db)
 for name,expected in bundle["files"].items():
  if not isinstance(name,str):raise RuntimeBundleError("declared file invalid")
  p=Path(name)
  if p.is_absolute() or ".." in p.parts or not name or name in declared or name==".storage.json" or not isinstance(expected,str) or not re.fullmatch(r"[0-9a-f]{64}",expected):raise RuntimeBundleError("declared file invalid")
  declared.add(name); item=source/p
  if item.is_symlink() or not item.is_file() or digest(item)!=expected:raise RuntimeBundleError("declared file checksum")
  hashes[name]=expected
 actual=set()
 for item in source.rglob("*"):
  relative=item.relative_to(source).as_posix()
  if item.is_symlink() or (not item.is_file() and not item.is_dir()):raise RuntimeBundleError("bundle special file")
  if item.is_file():actual.add(relative)
 if stored: actual.discard(".storage.json")
 if actual!=declared or len(actual)>MAX_FILES:raise RuntimeBundleError("bundle files missing or extra")
 total=0
 for name in actual:
  size=(source/name).stat().st_size
  if size>MAX_FILE_BYTES:raise RuntimeBundleError("bundle file exceeds bound")
  total+=size
 if total>MAX_TOTAL_BYTES:raise RuntimeBundleError("bundle exceeds bound")
 hashes["bundle.json"]=digest(source/"bundle.json"); return hashes
def copy_checked(source:Path,target:Path,hashes:Mapping[str,str]):
 for name,expected in hashes.items():
  out=target/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,out)
  with out.open("r+b") as f:os.fsync(f.fileno())
  if digest(out)!=expected:raise RuntimeBundleError("copy checksum")
def publish(storage_root,source_root,project_id,agent_id,checkpoint_id):
 namespace(project_id,agent_id,checkpoint_id); storage,source=root(storage_root,True),root(source_root); bundle_path=source/"bundle.json"
 if bundle_path.is_symlink() or not bundle_path.is_file():raise RuntimeBundleError("bundle.json unavailable")
 try:bundle=json.loads(bundle_path.read_text())
 except (OSError,ValueError) as e:raise RuntimeBundleError("bundle.json invalid") from e
 if not isinstance(bundle,Mapping):raise RuntimeBundleError("bundle.json invalid")
 hashes=files(source,bundle); parent=child(storage,project_id,agent_id,create=True); final=child(parent,checkpoint_id); stage=child(parent,"."+checkpoint_id+".pending")
 if final.exists():
  if final.is_symlink():raise RuntimeBundleError("existing bundle unsafe")
  existing=verify(final,project_id,agent_id,checkpoint_id)
  if existing["files"]!=hashes:raise RuntimeBundleError("existing bundle differs")
  return existing
 if stage.exists():raise RuntimeBundleError("pending bundle requires reconciliation")
 stage.mkdir(mode=0o700);
 try:
  copy_checked(source,stage,hashes); record={"project_id":project_id,"agent_id":agent_id,"checkpoint_id":checkpoint_id,"files":hashes}
  fd,temp=tempfile.mkstemp(dir=stage,prefix=".record-")
  with os.fdopen(fd,"w") as f:f.write(json.dumps(record,sort_keys=True,separators=(",",":")));f.flush();os.fsync(f.fileno())
  os.replace(temp,stage/".storage.json");fsync_dir(stage);os.replace(stage,final);fsync_dir(parent);return verify(final,project_id,agent_id,checkpoint_id)
 except Exception:raise
def verify(bundle:Path,project,agent,checkpoint):
 if bundle.is_symlink() or not bundle.is_dir():raise RuntimeBundleError("bundle unsafe")
 record=bundle/".storage.json"
 try:data=json.loads(record.read_text())
 except (OSError,ValueError) as e:raise RuntimeBundleError("storage record invalid") from e
 if data.get("project_id")!=project or data.get("agent_id")!=agent or data.get("checkpoint_id")!=checkpoint or not isinstance(data.get("files"),Mapping):raise RuntimeBundleError("storage identity invalid")
 bundle_json=bundle/"bundle.json"
 try: declared=json.loads(bundle_json.read_text())
 except (OSError,ValueError) as e:raise RuntimeBundleError("stored bundle invalid") from e
 if not isinstance(declared,Mapping):raise RuntimeBundleError("stored bundle invalid")
 hashes=files(bundle,declared,stored=True)
 if hashes!=data["files"]:raise RuntimeBundleError("stored hashes changed")
 if set(x.relative_to(bundle).as_posix() for x in bundle.rglob("*") if x.is_file())!=set(hashes)|{".storage.json"}:raise RuntimeBundleError("stored extras")
 return {"project_id":project,"agent_id":agent,"checkpoint_id":checkpoint,"files":hashes,"bundle":declared}
def materialize(storage_root,project_id,agent_id,checkpoint_id,destination):
 namespace(project_id,agent_id,checkpoint_id); storage=root(storage_root); dest=Path(destination).absolute()
 if dest.exists() or any(p.is_symlink() for p in dest.parents):raise RuntimeBundleError("fresh safe destination required")
 record=verify(child(storage,project_id,agent_id,checkpoint_id),project_id,agent_id,checkpoint_id); stage=dest.parent/("."+dest.name+".pending")
 if stage.exists():raise RuntimeBundleError("pending materialization")
 stage.mkdir(mode=0o700);copy_checked(child(storage,project_id,agent_id,checkpoint_id),stage,record["files"]);fsync_dir(stage);os.replace(stage,dest);fsync_dir(dest.parent);return record
