"""Check-first Gitea acceptance flow using independent HTTP authorities only."""
from __future__ import annotations
from dataclasses import dataclass
import argparse
import base64,hashlib,json,os,stat,time
from pathlib import Path
from typing import Any,Mapping,Protocol
from .gitea_acceptance_checkout import LocalCheckoutAdapter

class AcceptanceError(ValueError):pass
class Http(Protocol):
 def request(self,method:str,url:str,headers:Mapping[str,str],body:Mapping[str,Any]|None=None)->tuple[int,Mapping[str,Any]]:...
def _token(path:Path)->str:
 p=Path(path)
 if not p.is_absolute() or p.is_symlink() or any(x.is_symlink() for x in p.parents) or not p.is_file() or (os.name=="posix" and (p.stat().st_mode&0o077)):raise AcceptanceError("token file is not root-private")
 value=p.read_text(encoding="utf-8").strip()
 if not value or any(x.isspace() for x in value):raise AcceptanceError("token is invalid")
 return value
@dataclass(frozen=True)
class AcceptanceConfig:
 gitea_origin:str; owner:str; repository:str; project_id:str; run_id:str
 author_token_file:Path; verification_token_file:Path; review_token_file:Path; merge_token_file:Path
 verification_origin:str; review_origin:str; merge_origin:str
 repo_url:str|None=None; acceptance_root:Path|None=None
 verification_workspace_id:str="acceptance"; verification_command_id:str="python-unittest"
 def __post_init__(self):
  if not all(isinstance(x,str) and x and x.startswith("http") for x in (self.gitea_origin,self.verification_origin,self.review_origin,self.merge_origin)) or not all(isinstance(x,str) and x and len(x)<=128 for x in (self.owner,self.repository,self.project_id,self.run_id)):raise AcceptanceError("acceptance configuration is invalid")
  for path in (self.author_token_file,self.verification_token_file,self.review_token_file,self.merge_token_file):_token(Path(path))
@dataclass(frozen=True)
class PreparedAcceptance:
 run_id:str; branch:str; pull_number:int; head_sha:str; checkout_path:str; checkout_commit:str; input_tree_sha256:str; fingerprint:str
class GiteaAcceptanceDriver:
 def __init__(self,config:AcceptanceConfig,http:Http,checkout:LocalCheckoutAdapter|None=None):self.c,self.http,self.checkout=config,http,checkout or LocalCheckoutAdapter(http_authorization="token "+_token(config.author_token_file))
 def _call(self,method,url,token,body=None,*,ok=frozenset({200,201})):
  headers={"Authorization":"Bearer "+token,"Content-Type":"application/json"}
  if url.startswith(self.c.verification_origin+"/operations/"):headers["X-Project-Id"]=self.c.project_id
  status,value=self.http.request(method,url,headers,body)
  if status not in ok:raise AcceptanceError("acceptance HTTP step failed")
  return value
 def dry_run(self)->dict[str,Any]:return {"run_id":self.c.run_id,"state":"validated","network":False}
 def prepare_checkout(self)->PreparedAcceptance:
  c=self.c;author=_token(c.author_token_file);merge=_token(c.merge_token_file);base=f"{c.gitea_origin}/api/v1/repos/{c.owner}/{c.repository}";branch="task/acceptance-"+c.run_id;path="acceptance-"+c.run_id+".txt";content="acceptance "+c.run_id;test_path="test_acceptance_"+hashlib.sha256(c.run_id.encode()).hexdigest()[:16]+".py";test_content="import unittest\n\nclass Acceptance(unittest.TestCase):\n def test_unique_change(self): self.assertTrue(True)\n"
  self._call("POST",base+"/branches",author,{"new_branch_name":branch,"old_branch_name":"main"})
  commit=self._call("POST",base+"/contents/"+path,author,{"branch":branch,"content":__import__("base64").b64encode(content.encode()).decode(),"message":"acceptance "+c.run_id})
  self._call("POST",base+"/contents/"+test_path,author,{"branch":branch,"content":__import__("base64").b64encode(test_content.encode()).decode(),"message":"acceptance verification "+c.run_id})
  pull=self._call("POST",base+"/pulls",author,{"title":"acceptance "+c.run_id,"head":branch,"base":"main"});number=pull.get("number");head=pull.get("head",{}).get("sha")
  if type(number) is not int or not isinstance(head,str) or not head:raise AcceptanceError("pull response is invalid")
  premature,_=self.http.request("POST",c.merge_origin+"/merges",{"Authorization":"Bearer "+merge},{"operation_id":"premature-"+c.run_id,"repo_alias":c.project_id,"pull_number":number,"head_sha":head,"verification_operation_id":"missing"})
  if premature<400:raise AcceptanceError("premature merge was accepted")
  if c.repo_url is None or c.acceptance_root is None:raise AcceptanceError("explicit local checkout evidence is required")
  try:evidence=self.checkout.checkout(c.repo_url,c.acceptance_root,c.run_id,head)
  except ValueError as error:raise AcceptanceError("exact checkout evidence is unavailable") from error
  manifest={"run_id":c.run_id,"branch":branch,"pull_number":number,"head_sha":head,"checkout_path":evidence.path,"checkout_commit":evidence.commit,"input_tree_sha256":evidence.input_tree_sha256};fingerprint=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(",",":")).encode()).hexdigest()
  return PreparedAcceptance(**manifest,fingerprint=fingerprint)
 def execute_prepared(self, prepared:PreparedAcceptance)->dict[str,Any]:
  c=self.c;author=_token(c.author_token_file);verify=_token(c.verification_token_file);review=_token(c.review_token_file);merge=_token(c.merge_token_file);base=f"{c.gitea_origin}/api/v1/repos/{c.owner}/{c.repository}";path="acceptance-"+c.run_id+".txt";content="acceptance "+c.run_id
  manifest={"run_id":prepared.run_id,"branch":prepared.branch,"pull_number":prepared.pull_number,"head_sha":prepared.head_sha,"checkout_path":prepared.checkout_path,"checkout_commit":prepared.checkout_commit,"input_tree_sha256":prepared.input_tree_sha256}
  if prepared.run_id!=c.run_id or prepared.checkout_commit!=prepared.head_sha or __import__("re").fullmatch(r"[0-9a-f]{64}",prepared.input_tree_sha256) is None or hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(",",":")).encode()).hexdigest()!=prepared.fingerprint:raise AcceptanceError("prepared acceptance manifest is invalid")
  number,head,tree_hash=prepared.pull_number,prepared.head_sha,prepared.input_tree_sha256
  operation="verify-"+c.run_id;verification=self._call("POST",c.verification_origin+"/operations",verify,{"operation_id":operation,"project_id":c.project_id,"workspace_id":c.verification_workspace_id,"command_id":c.verification_command_id,"expected_input_tree_sha256":tree_hash},ok=frozenset({200,202}))
  for _ in range(50):
   if verification.get("state")=="completed":break
   if verification.get("state") not in {"accepted","running"}:raise AcceptanceError("verification did not accept exact tree")
   time.sleep(0.1)
   verification=self._call("GET",c.verification_origin+"/operations/"+operation,verify)
  if verification.get("state")!="completed":raise AcceptanceError("verification did not reach terminal completion")
  receipt=self._call("POST",c.review_origin+"/review-receipts",review,{"verification_operation_id":operation,"project_id":c.project_id,"subject":{"repo_alias":c.project_id,"pull_number":number,"head_sha":head}})
  self._call("POST",base+"/pulls/"+str(number)+"/reviews",review,{"event":"APPROVED","body":"independent receipt accepted"})
  self._call("POST",base+"/statuses/"+head,merge,{"state":"success","context":"independent-qc","description":"independent receipt accepted"})
  merge_result=self._call("POST",c.merge_origin+"/merges",merge,{"operation_id":"merge-"+c.run_id,"repo_alias":c.project_id,"pull_number":number,"head_sha":head,"verification_operation_id":operation})
  deadline=time.monotonic()+5
  while merge_result.get("state")=="unknown" and time.monotonic()<deadline:
   time.sleep(.25);merge_result=self._call("POST",c.merge_origin+"/merges/merge-"+c.run_id+"/retry",merge,{})
  if merge_result.get("state")!="merged":raise AcceptanceError("receipt-gated merge was not confirmed")
  main=self._call("GET",base+"/contents/"+path,author)
  try:main_content=base64.b64decode(main.get("content",""),validate=True).decode("utf-8")
  except (ValueError,UnicodeDecodeError):raise AcceptanceError("main content is not bounded base64") from None
  pull=self._call("GET",base+"/pulls/"+str(number),author)
  if main.get("path")!=path or main_content!=content or pull.get("merged") is not True or pull.get("head",{}).get("sha")!=head:raise AcceptanceError("main does not contain exact merged head content")
  return {"run_id":c.run_id,"branch":prepared.branch,"pull_number":number,"head_sha256":hashlib.sha256(head.encode()).hexdigest(),"tree_sha256":tree_hash,"checkout_path":prepared.checkout_path,"checkout_commit":prepared.checkout_commit,"verification_operation_id":operation,"review_receipt_id":receipt.get("receipt_id"),"merge_state":merge_result.get("state"),"premature_merge":"denied"}
 def run(self)->dict[str,Any]:return self.execute_prepared(self.prepare_checkout())
def load_config(path: Path) -> AcceptanceConfig:
 p=Path(path)
 if not p.is_absolute() or p.is_symlink() or not p.is_file():raise AcceptanceError("configuration file is unsafe")
 try:raw=json.loads(p.read_text(encoding="utf-8"))
 except (OSError,UnicodeDecodeError,json.JSONDecodeError) as error:raise AcceptanceError("configuration is invalid") from error
 if not isinstance(raw,Mapping):raise AcceptanceError("configuration is invalid")
 try:return AcceptanceConfig(**{key:(Path(value) if key.endswith("_token_file") else value) for key,value in raw.items()})
 except (TypeError,ValueError) as error:raise AcceptanceError("configuration is invalid") from error
def main(argv:list[str]|None=None)->int:
 parser=argparse.ArgumentParser(description="Validate a local Gitea acceptance run without network activity.");parser.add_argument("--config",required=True);parser.add_argument("--dry-run",action="store_true");args=parser.parse_args(argv)
 config=load_config(Path(args.config));print(json.dumps({"run_id":config.run_id,"state":"validated","network":False},sort_keys=True));return 0
if __name__=="__main__":raise SystemExit(main())
