#!/usr/bin/env python3
"""Record reviewed Network B Gitea UI reachability metadata; never handles credentials."""
from __future__ import annotations
import argparse, json
from datetime import datetime, timezone
from pathlib import Path

def main() -> int:
    p=argparse.ArgumentParser(); p.add_argument("--apply",action="store_true"); p.add_argument("--evidence-file",type=Path,required=True); p.add_argument("--endpoint",required=True); p.add_argument("--remote-client",required=True); p.add_argument("--proof-reference",required=True); a=p.parse_args()
    if not a.apply or a.endpoint != "https://192.168.8.100:3443" or not all(x and "\n" not in x for x in (a.remote_client,a.proof_reference)) or not a.evidence_file.is_absolute() or a.evidence_file.is_symlink(): return 64
    a.evidence_file.parent.mkdir(parents=True,exist_ok=True)
    if a.evidence_file.exists(): return 1
    value={"version":1,"recorded_at":datetime.now(timezone.utc).isoformat().replace("+00:00","Z"),"endpoint":a.endpoint,"test_kind":"user-attested-network-b-gitea-ui-reachability","remote_client":a.remote_client,"proof_reference":a.proof_reference}
    temporary=a.evidence_file.with_suffix(".new"); temporary.write_text(json.dumps(value,sort_keys=True)+"\n",encoding="utf-8"); temporary.chmod(0o644); temporary.replace(a.evidence_file); return 0
if __name__=="__main__": raise SystemExit(main())
