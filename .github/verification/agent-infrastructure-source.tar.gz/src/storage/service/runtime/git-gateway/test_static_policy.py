import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parent


class StorageGitGatewayPolicyTests(unittest.TestCase):
    def test_release_is_pinned_to_official_https_asset_and_sha512(self):
        lock = json.loads((ROOT / "caddy-release.lock.json").read_text(encoding="utf-8"))
        self.assertEqual(lock["version"], "2.11.4")
        self.assertEqual(len(lock["sha512"]), 128)
        self.assertTrue(lock["download_url"].startswith("https://github.com/caddyserver/caddy/releases/download/v2.11.4/"))

    def test_gitea_stays_loopback_behind_internal_tls(self):
        caddy = (ROOT / "Caddyfile.template").read_text(encoding="utf-8")
        self.assertIn("https://__LAN_IP__:3443", caddy)
        self.assertIn("tls internal", caddy)
        self.assertIn("skip_install_trust", caddy)
        self.assertIn("default_sni __LAN_IP__", caddy)
        self.assertIn("reverse_proxy 127.0.0.1:3000", caddy)
        self.assertIn("header_up X-Forwarded-Proto https", caddy)
        self.assertIn("header_up X-Forwarded-Host {host}", caddy)
        self.assertIn("health_uri /api/healthz", caddy)
        self.assertNotIn("tls_insecure_skip_verify", caddy)

    def test_storage_binds_to_declared_git_services(self):
        setup = (ROOT / "setup-storage-git-gateway.sh").read_text(encoding="utf-8")
        self.assertIn('--enable-gitea', setup)
        self.assertIn('Gitea is optional; select it explicitly', setup)
        self.assertIn('install -d -o root -g stack-git-gateway -m 0750 "$secret"', setup)
        dropin = (ROOT / "storage-role.conf").read_text(encoding="utf-8")
        self.assertIn("BindsTo=gitea.service agent-stack-storage-git-gateway.service", dropin)
        unit = (ROOT / "agent-stack-storage-git-gateway.service").read_text(encoding="utf-8")
        self.assertIn("Requires=gitea.service", unit)
        self.assertIn("PartOf=agent-stack-composed-storage.service", unit)
        self.assertIn("ProtectSystem=strict", unit)
        provider = (ROOT / "agent-stack-storage-provider.service").read_text(encoding="utf-8")
        self.assertIn("LoadCredential=storage-provider.token", provider)
        self.assertIn("PartOf=agent-stack-composed-storage.service", provider)
        self.assertIn("User=stack-storage-provider", provider)
        self.assertIn("agent-stack-storage-provider.service", dropin)
        self.assertIn("storage-provider.token", setup)
        self.assertIn("stack-management:stack-management:600", setup)
        self.assertIn("/usr/local/lib/agent-stack/storage-provider-runtime.py", provider)
        self.assertIn('install -o root -g root -m 0644 "$script_dir/storage_provider_runtime.py" "$provider_runtime"', setup)

    def test_core_storage_unit_does_not_pull_in_optional_gitea(self):
        core = (ROOT / ".." / ".." / "agent-stack-composed-storage.service").resolve()
        text = core.read_text(encoding="utf-8")
        self.assertNotIn("gitea.service", text)
        self.assertNotIn("agent-stack-storage-git-gateway.service", text)

    def test_windows_bridge_is_network_b_scoped_and_requires_admin(self):
        launcher = (ROOT / "Start-StorageRole.ps1").read_text(encoding="utf-8")
        self.assertIn("192.168.8.0/24", launcher)
        self.assertIn("IsInRole", launcher)
        self.assertIn("--exec', '/usr/bin/sleep', 'infinity", launcher)
        self.assertIn("Get-NetFirewallPortFilter", launcher)
        self.assertIn("Get-NetFirewallAddressFilter", launcher)
        self.assertIn("BEGIN CERTIFICATE", launcher)
        self.assertIn("--cacert", launcher)
        self.assertIn("--ssl-revoke-best-effort", launcher)
        self.assertIn("$previousProxy", launcher)
        self.assertIn("network_b_acceptance_configured", (ROOT / "Get-StorageRoleStatus.ps1").read_text(encoding="utf-8"))
        self.assertIn("local_ready", (ROOT / "Get-StorageRoleStatus.ps1").read_text(encoding="utf-8"))
        status = (ROOT / "Get-StorageRoleStatus.ps1").read_text(encoding="utf-8")
        self.assertIn("network_b_acceptance_proven", status)
        self.assertIn("user-attested-network-b-gitea-ui-reachability", status)
        self.assertIn("ConvertFrom-Json", status)
        self.assertNotIn("sslVerify=false", launcher)
        self.assertNotIn("0.0.0.0/0", launcher)

    def test_git_smoke_uses_token_file_without_weakening_tls(self):
        smoke = (ROOT / "smoke-git-gateway.sh").read_text(encoding="utf-8")
        askpass = (ROOT / "git-askpass-token-file.sh").read_text(encoding="utf-8")
        self.assertIn("http.sslCAInfo", smoke)
        self.assertIn("http.curloptResolve", smoke)
        self.assertIn("GIT_TERMINAL_PROMPT=0", smoke)
        self.assertNotIn("sslVerify=false", smoke)
        self.assertIn('cat "$AGENT_STACK_GIT_TOKEN_FILE"', askpass)
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        self.assertIn("http.sslBackend=openssl", readme)


if __name__ == "__main__":
    unittest.main()
