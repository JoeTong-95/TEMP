"""Storage provider lease worker.

The worker owns no Git credential and makes no Git request.  Its only
authority is an injected, provider-scoped Management bearer used to register
one manifest and renew that manifest's health lease.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import http.client
import json
from pathlib import Path
import ssl
import sys
import time
from typing import Any, Mapping
from urllib.parse import urlsplit

MAX_RESPONSE_BYTES = 32768


class StorageProviderError(ValueError):
    pass


def safe_chain(path: Path) -> bool:
    path = path.absolute()
    while True:
        if path.is_symlink():
            return False
        if path == path.parent:
            return True
        path = path.parent


def _origin(value: object, *, loopback_http: bool) -> tuple[str, str, int | None]:
    parsed = urlsplit(value if isinstance(value, str) else "")
    loopback = parsed.hostname in {"127.0.0.1", "localhost", "::1"}
    allowed = {"https"} | ({"http"} if loopback_http and loopback else set())
    if parsed.scheme not in allowed or not parsed.hostname or parsed.path not in {"", "/"} or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise StorageProviderError("endpoint must be an HTTPS origin (or loopback HTTP Management origin)")
    return parsed.scheme, parsed.hostname, parsed.port


def _read_private(path: Path) -> str:
    if not path.is_absolute() or not safe_chain(path) or not path.is_file():
        raise StorageProviderError("private token file is unsafe")
    value = path.read_text(encoding="utf-8").strip()
    if not value or not value.isascii() or len(value) > 4096 or any(char.isspace() for char in value):
        raise StorageProviderError("private token file is invalid")
    return value


def load_config(path: Path, token_file: Path) -> dict[str, Any]:
    if not path.is_absolute() or not safe_chain(path) or not path.is_file():
        raise StorageProviderError("configuration file is unsafe")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise StorageProviderError("configuration must be UTF-8 JSON") from error
    allowed = {"management_endpoint", "provider_manifest", "gateway_health_url", "gateway_ca_file", "acceptance_evidence_file", "heartbeat_interval_seconds", "lease_seconds", "expected_generation"}
    required = allowed - {"expected_generation"}
    if not isinstance(value, Mapping) or set(value) - allowed or not required.issubset(value):
        raise StorageProviderError("configuration keys are invalid")
    _origin(value["management_endpoint"], loopback_http=True)
    _origin(value["gateway_health_url"], loopback_http=False)
    manifest = value["provider_manifest"]
    if not isinstance(manifest, Mapping) or manifest.get("role") != "storage" or manifest.get("provider_id") is None or "token" in json.dumps(manifest, sort_keys=True).lower():
        raise StorageProviderError("storage provider manifest is invalid")
    if not isinstance(value["gateway_ca_file"], str):
        raise StorageProviderError("gateway CA file is required")
    ca = Path(value["gateway_ca_file"])
    if not ca.is_absolute() or not safe_chain(ca) or not ca.is_file():
        raise StorageProviderError("gateway CA file is unsafe")
    evidence = Path(value["acceptance_evidence_file"])
    if not evidence.is_absolute() or not safe_chain(evidence):
        raise StorageProviderError("Network B acceptance evidence path is unsafe")
    for name, lower, upper in (("heartbeat_interval_seconds", 1, 300), ("lease_seconds", 5, 300)):
        number = value[name]
        if type(number) is not int or not lower <= number <= upper:
            raise StorageProviderError(f"{name} is invalid")
    if value["heartbeat_interval_seconds"] >= value["lease_seconds"]:
        raise StorageProviderError("heartbeat interval must be less than lease")
    if "expected_generation" in value and (type(value["expected_generation"]) is not int or value["expected_generation"] <= 0):
        raise StorageProviderError("expected generation is invalid")
    _read_private(token_file)
    return dict(value)


class Client:
    def __init__(self, endpoint: str, token_file: Path, *, timeout_seconds: float = 5.0):
        self.scheme, self.host, self.port = _origin(endpoint, loopback_http=True)
        self.token_file, self.timeout = token_file, timeout_seconds

    def post(self, route: str, body: Mapping[str, Any]) -> dict[str, Any]:
        raw = json.dumps(dict(body), separators=(",", ":"), allow_nan=False).encode("utf-8")
        if not route.startswith("/") or len(raw) > MAX_RESPONSE_BYTES:
            raise StorageProviderError("Management request is invalid")
        connection = http.client.HTTPSConnection(self.host, self.port, timeout=self.timeout) if self.scheme == "https" else http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        try:
            connection.request("POST", route, raw, {"Authorization": "Bearer " + _read_private(self.token_file), "Accept": "application/json", "Content-Type": "application/json", "Content-Length": str(len(raw))})
            response = connection.getresponse()
            payload = response.read(MAX_RESPONSE_BYTES + 1)
            if response.status != 200 or len(payload) > MAX_RESPONSE_BYTES:
                raise StorageProviderError("Management request was not accepted")
            value = json.loads(payload.decode("utf-8"))
            if not isinstance(value, Mapping):
                raise StorageProviderError("Management response is invalid")
            return dict(value)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise StorageProviderError("Management transport is unavailable") from error
        finally:
            connection.close()


def gateway_healthy(url: str, ca_file: str) -> bool:
    scheme, host, port = _origin(url, loopback_http=False)
    assert scheme == "https"
    connection = http.client.HTTPSConnection(host, port, timeout=5.0, context=ssl.create_default_context(cafile=ca_file))
    try:
        connection.request("GET", "/api/healthz", headers={"Accept": "application/json"})
        response = connection.getresponse()
        response.read(1024)
        return response.status == 200
    except (OSError, ssl.SSLError):
        return False
    finally:
        connection.close()


def accepted_network_b_evidence(path: str, endpoint: str) -> bool:
    """A local marker is evidence metadata, never a credential or a probe substitute."""
    candidate = Path(path)
    try:
        value = json.loads(candidate.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return False
    required = {"version", "recorded_at", "endpoint", "test_kind", "remote_client", "proof_reference"}
    if not isinstance(value, Mapping) or set(value) != required or value.get("version") != 1 or value.get("endpoint") != endpoint or value.get("test_kind") != "user-attested-network-b-gitea-ui-reachability":
        return False
    if not all(isinstance(value.get(name), str) and value[name] for name in ("recorded_at", "remote_client", "proof_reference")):
        return False
    try:
        datetime.fromisoformat(value["recorded_at"].replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def run(config: Mapping[str, Any], token_file: Path, *, once: bool = False) -> None:
    manifest = dict(config["provider_manifest"])
    provider_id = manifest["provider_id"]
    client = Client(config["management_endpoint"], token_file)
    registration: dict[str, Any] = {"manifest": manifest}
    if "expected_generation" in config:
        registration["expected_generation"] = config["expected_generation"]
    enrolled = client.post("/providers/register", registration)
    if enrolled.get("provider_id") != provider_id or type(enrolled.get("generation")) is not int:
        raise StorageProviderError("provider registration acknowledgement is invalid")
    generation = enrolled["generation"]
    while True:
        status = "healthy" if gateway_healthy(config["gateway_health_url"], config["gateway_ca_file"]) and accepted_network_b_evidence(config["acceptance_evidence_file"], config["gateway_health_url"]) else "unhealthy"
        client.post(f"/providers/{provider_id}/health", {"status": status, "observed_at": timestamp(), "expected_generation": generation, "host_boot_id": manifest["host_boot_id"], "lease_seconds": config["lease_seconds"]})
        if once:
            return
        time.sleep(config["heartbeat_interval_seconds"])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Renew a Storage provider health lease without exposing credentials.")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--token-file", type=Path, required=True)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args(argv)
    try:
        run(load_config(args.config, args.token_file), args.token_file, once=args.once)
    except StorageProviderError as error:
        print(f"storage provider worker failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
