import importlib.util
import json
import subprocess
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parent
specification = importlib.util.spec_from_file_location("storage_provider_runtime", ROOT / "storage_provider_runtime.py")
runtime = importlib.util.module_from_spec(specification)
assert specification and specification.loader
specification.loader.exec_module(runtime)


def manifest():
    return {"provider_id": "storage-git-steven", "hardware_node_id": "steven", "host_boot_id": "boot-a", "role": "storage", "capabilities": ["storage.git"], "build_digest": "git-gateway-v1", "configuration_hash": "gateway-config-v1", "compatibility_fingerprint": "storage-git-v1", "private_endpoint": "https://192.168.8.100:3443"}


class StorageProviderRuntimeTests(unittest.TestCase):
    def test_acceptance_marker_requires_exact_nonsecret_network_b_ui_reachability_metadata(self):
        with tempfile.TemporaryDirectory() as directory:
            marker = Path(directory) / "acceptance.json"
            self.assertFalse(runtime.accepted_network_b_evidence(str(marker), "https://192.168.8.100:3443"))
            marker.write_text(json.dumps({"version": 1, "recorded_at": "2026-09-05T15:00:00Z", "endpoint": "https://192.168.8.100:3443", "test_kind": "user-attested-network-b-gitea-ui-reachability", "remote_client": "blade", "proof_reference": "user-attested browser receipt 2026-09-05"}))
            self.assertTrue(runtime.accepted_network_b_evidence(str(marker), "https://192.168.8.100:3443"))

    def test_recorder_writes_a_nonsecret_marker_readable_by_the_provider(self):
        with tempfile.TemporaryDirectory() as directory:
            marker = Path(directory) / "acceptance.json"
            recorder = ROOT / "record-network-b-git-acceptance.py"
            self.assertEqual(0, subprocess.run(["python", str(recorder), "--apply", "--evidence-file", str(marker.resolve()), "--endpoint", "https://192.168.8.100:3443", "--remote-client", "blade", "--proof-reference", "user attestation"], check=False).returncode)
            self.assertEqual(0o444, marker.stat().st_mode & 0o444)
    def test_config_is_explicit_and_token_is_separate(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); token = root / "token"; ca = root / "ca.crt"; config = root / "config.json"
            token.write_text("scoped-token"); ca.write_text("certificate")
            body = {"management_endpoint": "http://127.0.0.1:14320", "provider_manifest": manifest(), "gateway_health_url": "https://192.168.8.100:3443", "gateway_ca_file": str(ca), "acceptance_evidence_file": str(root / "acceptance.json"), "heartbeat_interval_seconds": 10, "lease_seconds": 30}
            config.write_text(json.dumps(body))
            self.assertEqual("storage-git-steven", runtime.load_config(config, token)["provider_manifest"]["provider_id"])
            body["provider_manifest"]["token"] = "must-not-appear"
            config.write_text(json.dumps(body))
            with self.assertRaises(runtime.StorageProviderError):
                runtime.load_config(config, token)

    def test_once_registers_then_reports_gateway_health_with_generation(self):
        config = {"management_endpoint": "http://127.0.0.1:14320", "provider_manifest": manifest(), "gateway_health_url": "https://192.168.8.100:3443", "gateway_ca_file": "/unused", "acceptance_evidence_file": "/unused", "heartbeat_interval_seconds": 10, "lease_seconds": 30}
        calls = []
        original_post, original_health = runtime.Client.post, runtime.gateway_healthy
        def post(_, route, body):
            calls.append((route, dict(body)))
            return {"provider_id": "storage-git-steven", "generation": 4} if route == "/providers/register" else {"provider_id": "storage-git-steven"}
        runtime.Client.post = post; runtime.gateway_healthy = lambda *_: True; original_acceptance = runtime.accepted_network_b_evidence; runtime.accepted_network_b_evidence = lambda *_: True
        try:
            runtime.run(config, Path("/unused"), once=True)
        finally:
            runtime.Client.post, runtime.gateway_healthy, runtime.accepted_network_b_evidence = original_post, original_health, original_acceptance
        self.assertEqual("/providers/register", calls[0][0])
        self.assertEqual("/providers/storage-git-steven/health", calls[1][0])
        self.assertEqual("healthy", calls[1][1]["status"])
        self.assertEqual(4, calls[1][1]["expected_generation"])
        self.assertNotIn("scoped-token", repr(calls))


if __name__ == "__main__":
    unittest.main()
