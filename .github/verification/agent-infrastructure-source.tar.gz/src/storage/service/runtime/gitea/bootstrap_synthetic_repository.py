#!/usr/bin/env python3
"""Create the one synthetic Gitea repository with root-held BasicAuth only.

Actor tokens deliberately lack write:user and cannot use /user/repos.  This
one-time bootstrap uses the operator's root-only password, records no
authorization material, and reconciles an uncertain POST by exact identity.
"""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import stat
import sys
import urllib.error
import urllib.parse
import urllib.request


BASE = "http://127.0.0.1:3000"
OWNER = "synthetic-operator"
REPOSITORY = "synthetic-merge-gate"
PAYLOAD = {"name": REPOSITORY, "private": True, "auto_init": True, "default_branch": "main"}
SECRET_DIR = Path("/srv/agent-stack/secrets/gitea/synthetic-fixture")
STATE_DIR = Path("/srv/agent-stack/state/gitea/synthetic-repository-bootstrap")
MAX_RESPONSE_BYTES = 64 * 1024


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        return None


def _private_json(path: Path, value: object) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as output:
        json.dump(value, output, sort_keys=True, separators=(",", ":"))
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())


def _password() -> str:
    path = SECRET_DIR / f"{OWNER}.password"
    metadata = path.lstat()
    if path.is_symlink() or not stat.S_ISREG(metadata.st_mode) or metadata.st_mode & 0o077:
        raise RuntimeError("operator password path is unsafe")
    password = path.read_text(encoding="utf-8").strip()
    if not password or any(character.isspace() for character in password):
        raise RuntimeError("operator password is malformed")
    return password


def _request(method: str, path: str, payload: object | None = None) -> tuple[int, object]:
    auth = base64.b64encode(f"{OWNER}:{_password()}".encode("utf-8")).decode("ascii")
    body = None if payload is None else json.dumps(payload, separators=(",", ":")).encode("utf-8")
    call = urllib.request.Request(BASE + path, data=body, method=method, headers={"Authorization": f"Basic {auth}", "Accept": "application/json", **({"Content-Type": "application/json"} if body else {})})
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect()).open(call, timeout=10) as response:
            content, status = response.read(MAX_RESPONSE_BYTES + 1), response.status
    except urllib.error.HTTPError as error:
        content, status = error.read(MAX_RESPONSE_BYTES + 1), error.code
    except urllib.error.URLError as error:
        raise RuntimeError("repository bootstrap outcome is unknown") from error
    if len(content) > MAX_RESPONSE_BYTES:
        raise RuntimeError("repository bootstrap response exceeds bound")
    try:
        return status, json.loads(content.decode("utf-8") or "null")
    except json.JSONDecodeError:
        return status, None


def _identity(value: object) -> dict[str, object] | None:
    if not isinstance(value, dict) or not isinstance(value.get("owner"), dict):
        return None
    identity = {"owner": value["owner"].get("login"), "name": value.get("name"), "private": value.get("private"), "default_branch": value.get("default_branch"), "id": value.get("id")}
    if identity["owner"] != OWNER or identity["name"] != REPOSITORY or identity["private"] is not True or identity["default_branch"] != "main" or not isinstance(identity["id"], int):
        return None
    return identity


def main() -> int:
    if os.geteuid() != 0:
        print("Run synthetic repository bootstrap only as root.", file=sys.stderr)
        return 64
    if STATE_DIR.exists() and (STATE_DIR.is_symlink() or not STATE_DIR.is_dir()):
        print("Synthetic bootstrap state path is unsafe.", file=sys.stderr)
        return 1
    STATE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    request_receipt = STATE_DIR / "request.json"
    result_receipt = STATE_DIR / "result.json"
    try:
        if not request_receipt.exists():
            _private_json(request_receipt, {"operation": "create_repository", "owner": OWNER, "repository": REPOSITORY, "payload": PAYLOAD})
        if result_receipt.exists():
            print("Synthetic repository bootstrap already completed; refusing rerun.", file=sys.stderr)
            return 1
        status, response = _request("POST", "/api/v1/user/repos", PAYLOAD)
        identity = _identity(response) if status in {200, 201} else None
        if identity is None and status in {409, 500, 502, 503, 504}:
            lookup_status, lookup = _request("GET", "/api/v1/repos/" + urllib.parse.quote(OWNER, safe="") + "/" + urllib.parse.quote(REPOSITORY, safe=""))
            identity = _identity(lookup) if lookup_status == 200 else None
        if identity is None:
            raise RuntimeError("synthetic repository creation is not confirmed")
        _private_json(result_receipt, {"operation": "create_repository", "http_status": status, "identity": identity})
    except Exception:
        print("Synthetic repository bootstrap stopped; root-only receipt retained; no credentials were printed.", file=sys.stderr)
        return 1
    print("Synthetic repository bootstrap completed; response evidence is root-only.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
