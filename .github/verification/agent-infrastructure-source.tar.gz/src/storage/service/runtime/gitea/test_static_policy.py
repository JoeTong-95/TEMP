"""Offline checks for the pre-deployment local Gitea package."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import importlib.util
import subprocess
import sys
import tempfile
import threading
import unittest
from contextlib import redirect_stdout
from io import StringIO
from types import SimpleNamespace
from unittest import mock


ROOT = Path(__file__).resolve().parent


def _renderer_module():
    specification = importlib.util.spec_from_file_location("gitea_renderer", ROOT / "render_app_ini.py")
    assert specification and specification.loader
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def _module(filename: str, name: str):
    specification = importlib.util.spec_from_file_location(name, ROOT / filename)
    assert specification and specification.loader
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


class GiteaStaticPolicyTests(unittest.TestCase):
    def test_release_lock_is_pinned_to_official_digest_and_sigstore_bundle(self) -> None:
        lock = json.loads((ROOT / "gitea-release.lock.json").read_text(encoding="utf-8"))
        self.assertEqual("1.27.3", lock["version"])
        self.assertEqual("linux-amd64", lock["platform"])
        self.assertTrue(lock["download_url"].startswith("https://dl.gitea.com/"))
        self.assertEqual(
            "4da93c2c10b6980c359bcb86d5573ebfd7770e2e151756534edee24c8c12d971",
            lock["sha256"],
        )
        self.assertEqual(
            lock["download_url"] + ".sha256",
            lock["sha256_source_url"],
        )
        self.assertTrue(lock["sigstore_bundle_url"].endswith(".sigstore.json"))
        self.assertTrue(lock["gpg_signature_url"].endswith(".asc"))
        self.assertEqual("7C9E68152594688862D62AF62D9AE806EC1592E2", lock["gpg"]["fingerprint"])

    def test_unit_is_loopback_hardened_and_uses_external_state(self) -> None:
        unit = (ROOT / "gitea.service").read_text(encoding="utf-8")
        for required in (
            "User=stack-gitea",
            "GITEA_WORK_DIR=/srv/agent-stack/state/gitea",
            "LoadCredential=app.ini:/srv/agent-stack/secrets/gitea/app.ini",
            "--config %d/app.ini",
            "ProtectSystem=strict",
            "IPAddressDeny=any",
            "IPAddressAllow=127.0.0.0/8",
        ):
            self.assertIn(required, unit)
        self.assertNotIn("OneDrive", unit)

    def test_setup_requires_explicit_apply_and_preserves_disabled_startup(self) -> None:
        setup = (ROOT / "setup-local-gitea.sh").read_text(encoding="utf-8")
        self.assertIn("Refusing provisioning without --apply.", setup)
        self.assertIn("Loopback TCP port 3000 is already in use", setup)
        self.assertIn("root:root:600", setup)
        self.assertIn("Existing gitea unit differs; no replacement made.", setup)
        self.assertNotIn("enable --now", setup)

    def test_synthetic_account_bootstrap_is_explicit_and_external_secret_only(self) -> None:
        source = (ROOT / "create_synthetic_accounts.py").read_text(encoding="utf-8")
        self.assertIn('Refusing synthetic account creation without --apply.', source)
        self.assertIn('os.O_CREAT | os.O_EXCL', source)
        self.assertIn('timeout=20', source)
        self.assertIn('"--collect"', source)
        self.assertIn('.create.receipt', source)
        self.assertIn('.token.receipt', source)
        self.assertIn('retry blocked', source)
        self.assertIn('"--token-name", "synthetic-fixture"', source)
        self.assertIn('"--scopes", "write:repository", "--raw"', source)
        self.assertIn('/srv/agent-stack/secrets/gitea/synthetic-fixture', source)
        self.assertNotIn('print(password', source)
        self.assertNotIn('print(token', source)

    def test_synthetic_receipt_parser_accepts_one_value_and_rejects_ambiguous_output(self) -> None:
        module_path = ROOT / "create_synthetic_accounts.py"
        specification = importlib.util.spec_from_file_location("gitea_accounts", module_path)
        assert specification and specification.loader
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        self.assertEqual(
            "fixture-token",
            module.parse_generated_credential("fixture-token\n", r"^(\S+)$", "token"),
        )
        with self.assertRaises(RuntimeError):
            module.parse_generated_credential("one\ntwo\n", r"^(\S+)$", "token")
        with self.assertRaises(RuntimeError):
            module.parse_generated_credential("random password: has whitespace\n", r"^.*random password.*?:\s*(\S+)\s*$", "password")
        with self.assertRaises(RuntimeError):
            module.parse_generated_credential("credential created\n", r"^token-(\S+)$", "token")
        self.assertEqual(
            "fixture-password",
            module.parse_generated_password("New user 'synthetic-author' has been successfully created!\nGenerated random password 'fixture-password'\n"),
        )
        with self.assertRaises(RuntimeError):
            module.parse_generated_password("random password 'one'\nrandom password 'two'\n")

    def test_synthetic_secret_directory_rejects_symlinks_and_enforces_private_mode(self) -> None:
        module_path = ROOT / "create_synthetic_accounts.py"
        specification = importlib.util.spec_from_file_location("gitea_accounts_directory", module_path)
        assert specification and specification.loader
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            receipt_dir = Path(directory) / "receipts"
            module.prepare_secret_directory(receipt_dir)
            if os.name != "nt":
                self.assertEqual(0o700, receipt_dir.stat().st_mode & 0o777)
            link = Path(directory) / "link"
            try:
                link.symlink_to(receipt_dir, target_is_directory=True)
            except OSError as exc:
                self.skipTest(f"symlinks unavailable: {exc}")
            with self.assertRaises(RuntimeError):
                module.prepare_secret_directory(link)

    def test_synthetic_helper_writes_private_fsynced_receipts_without_stdout(self) -> None:
        module_path = ROOT / "create_synthetic_accounts.py"
        specification = importlib.util.spec_from_file_location("gitea_accounts_receipts", module_path)
        assert specification and specification.loader
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        fsync_calls: list[int] = []

        def fake_run(command: list[str], *, stdout: object, **_: object) -> SimpleNamespace:
            assert "--collect" in command
            stdout.write("synthetic CLI receipt\n")  # type: ignore[attr-defined]
            return SimpleNamespace(returncode=0)

        with tempfile.TemporaryDirectory() as directory:
            receipt = Path(directory) / "receipt"
            secret = Path(directory) / "secret"
            captured = StringIO()
            with mock.patch.object(module.subprocess, "run", side_effect=fake_run), mock.patch.object(module.os, "fsync", side_effect=fsync_calls.append), redirect_stdout(captured):
                self.assertEqual("synthetic CLI receipt\n", module.run_cli("synthetic-author", "create", [], receipt))
                module.write_secret(secret, "synthetic-secret")
            self.assertEqual("", captured.getvalue())
            self.assertEqual("synthetic CLI receipt\n", receipt.read_text(encoding="utf-8"))
            self.assertEqual("synthetic-secret\n", secret.read_text(encoding="utf-8"))
            self.assertEqual(2, len(fsync_calls))
            if os.name != "nt":
                self.assertEqual(0o600, receipt.stat().st_mode & 0o777)
                self.assertEqual(0o600, secret.stat().st_mode & 0o777)

    def test_synthetic_recovery_never_repeats_create_after_exact_identity_check(self) -> None:
        module_path = ROOT / "create_synthetic_accounts.py"
        specification = importlib.util.spec_from_file_location("gitea_accounts_recovery", module_path)
        assert specification and specification.loader
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            secret_dir = Path(directory) / "receipts"
            secret_dir.mkdir()
            (secret_dir / "synthetic-operator.create.receipt").write_text(
                "New user 'synthetic-operator' has been successfully created!\nGenerated random password 'fixture-password'\n",
                encoding="utf-8",
            )
            database_path = Path(directory) / "gitea.db"
            database = sqlite3.connect(database_path)
            database.execute("CREATE TABLE user (lower_name TEXT, email TEXT)")
            database.execute("INSERT INTO user VALUES (?, ?)", ("synthetic-operator", "synthetic-operator@example.invalid"))
            database.commit()
            database.close()
            calls: list[str] = []

            def token_only(principal: str, operation: str, arguments: list[str], receipt: Path) -> str:
                calls.append(operation)
                self.assertEqual("token", operation)
                receipt.write_text("fixture-token\n", encoding="utf-8")
                return "fixture-token\n"

            with mock.patch.object(module, "SECRET_DIR", secret_dir), mock.patch.object(module, "GITEA_DB", database_path), mock.patch.object(module, "run_cli", side_effect=token_only):
                module.recover_create_receipt_only("synthetic-operator")
            self.assertEqual(["token"], calls)
            self.assertEqual("fixture-password\n", (secret_dir / "synthetic-operator.password").read_text(encoding="utf-8"))
            self.assertEqual("fixture-token\n", (secret_dir / "synthetic-operator.token").read_text(encoding="utf-8"))

    def test_synthetic_recovery_rejects_mismatched_identity_or_extra_receipts(self) -> None:
        module_path = ROOT / "create_synthetic_accounts.py"
        specification = importlib.util.spec_from_file_location("gitea_accounts_recovery_reject", module_path)
        assert specification and specification.loader
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            secret_dir = Path(directory) / "receipts"
            secret_dir.mkdir()
            (secret_dir / "synthetic-operator.create.receipt").write_text("Generated random password 'fixture-password'\n", encoding="utf-8")
            (secret_dir / "unexpected").write_text("x", encoding="utf-8")
            database_path = Path(directory) / "gitea.db"
            database = sqlite3.connect(database_path)
            database.execute("CREATE TABLE user (lower_name TEXT, email TEXT)")
            database.execute("INSERT INTO user VALUES (?, ?)", ("different", "synthetic-operator@example.invalid"))
            database.commit()
            database.close()
            with mock.patch.object(module, "SECRET_DIR", secret_dir), mock.patch.object(module, "GITEA_DB", database_path), mock.patch.object(module, "run_cli") as runner:
                with self.assertRaises(RuntimeError):
                    module.recover_create_receipt_only("synthetic-operator")
            runner.assert_not_called()

    def test_synthetic_single_principal_creation_preserves_prior_principal_state(self) -> None:
        module_path = ROOT / "create_synthetic_accounts.py"
        specification = importlib.util.spec_from_file_location("gitea_accounts_create_one", module_path)
        assert specification and specification.loader
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            secret_dir = Path(directory) / "receipts"
            secret_dir.mkdir()
            (secret_dir / "synthetic-operator.token").write_text("prior-secret\n", encoding="utf-8")
            with mock.patch.object(module, "SECRET_DIR", secret_dir), mock.patch.object(module, "create", return_value=("new-password", "new-token")) as creator:
                module.create_principal_once("synthetic-author")
            creator.assert_called_once_with("synthetic-author")
            self.assertEqual("prior-secret\n", (secret_dir / "synthetic-operator.token").read_text(encoding="utf-8"))
            self.assertEqual("new-token\n", (secret_dir / "synthetic-author.token").read_text(encoding="utf-8"))
            with mock.patch.object(module, "SECRET_DIR", secret_dir), mock.patch.object(module, "create") as creator:
                with self.assertRaises(RuntimeError):
                    module.create_principal_once("synthetic-author")
            creator.assert_not_called()

    def test_synthetic_rotation_deletes_old_metadata_before_one_v2_receipt(self) -> None:
        module_path = ROOT / "create_synthetic_accounts.py"
        specification = importlib.util.spec_from_file_location("gitea_accounts_rotate", module_path)
        assert specification and specification.loader
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            secret_dir = Path(directory) / "receipts"
            secret_dir.mkdir()
            for suffix, content in (("create.receipt", "Generated random password 'fixture-password'\n"), ("password", "fixture-password\n"), ("token", "old-token\n"), ("token.receipt", "old-token\n")):
                (secret_dir / f"synthetic-author.{suffix}").write_text(content, encoding="utf-8")
            database_path = Path(directory) / "gitea.db"
            database = sqlite3.connect(database_path)
            database.execute("CREATE TABLE user (id INTEGER, lower_name TEXT, email TEXT)")
            database.execute("CREATE TABLE access_token (uid INTEGER, name TEXT)")
            database.execute("INSERT INTO user VALUES (1, ?, ?)", ("synthetic-author", "synthetic-author@example.invalid"))
            database.execute("INSERT INTO access_token VALUES (1, ?)", ("synthetic-fixture",))
            database.commit()
            database.close()
            def delete_token(principal: str, password: str) -> int:
                self.assertEqual(("synthetic-author", "fixture-password"), (principal, password))
                database = sqlite3.connect(database_path)
                database.execute("DELETE FROM access_token WHERE name = 'synthetic-fixture'")
                database.commit()
                database.close()
                return 204
            def create_v2(principal: str, operation: str, arguments: list[str], receipt: Path) -> str:
                self.assertEqual("token-v2", operation)
                self.assertIn("write:repository,read:user", arguments)
                receipt.write_text("v2-token\n", encoding="utf-8")
                database = sqlite3.connect(database_path)
                database.execute("INSERT INTO access_token VALUES (1, ?)", ("synthetic-fixture-v2",))
                database.commit()
                database.close()
                return "v2-token\n"
            with mock.patch.object(module, "SECRET_DIR", secret_dir), mock.patch.object(module, "GITEA_DB", database_path), mock.patch.object(module, "_delete_token_with_password", side_effect=delete_token), mock.patch.object(module, "run_cli", side_effect=create_v2), mock.patch.object(module, "_remove_revoked_secret", side_effect=lambda path: path.unlink()):
                module.rotate_principal_token("synthetic-author")
            self.assertFalse((secret_dir / "synthetic-author.token").exists())
            self.assertFalse((secret_dir / "synthetic-author.token.receipt").exists())
            self.assertEqual("v2-token\n", (secret_dir / "synthetic-author.token-v2").read_text(encoding="utf-8"))
            self.assertTrue((secret_dir / "synthetic-author.token-v2-delete.receipt.json").exists())

    def test_root_basic_bootstrap_sanitizes_identity_and_never_prints_authentication(self) -> None:
        module = _module("bootstrap_synthetic_repository.py", "gitea_repo_bootstrap")
        response = {"id": 7, "name": "synthetic-merge-gate", "private": True, "default_branch": "main", "owner": {"login": "synthetic-operator"}}
        self.assertEqual({"id": 7, "name": "synthetic-merge-gate", "private": True, "default_branch": "main", "owner": "synthetic-operator"}, module._identity(response))
        self.assertIsNone(module._identity({**response, "private": False}))

        class FakeResponse:
            status = 201
            def read(self, _: int) -> bytes:
                return b'{"id":7}'
            def __enter__(self): return self
            def __exit__(self, *args): return False

        seen_headers: list[dict[str, str]] = []
        class FakeOpener:
            def open(self, request, timeout: int):
                seen_headers.append(dict(request.header_items()))
                return FakeResponse()

        captured = StringIO()
        with mock.patch.object(module, "_password", return_value="test-only-credential"), mock.patch.object(module.urllib.request, "build_opener", return_value=FakeOpener()), redirect_stdout(captured):
            status, value = module._request("POST", "/api/v1/user/repos", {"name": "synthetic-merge-gate"})
        self.assertEqual((201, {"id": 7}), (status, value))
        self.assertEqual("", captured.getvalue())
        self.assertTrue(any(key.lower() == "authorization" for key in seen_headers[0]))

    def test_receipt_gate_rejects_a_tampered_head_binding(self) -> None:
        module = _module("run_synthetic_merge_gate.py", "gitea_merge_gate")
        with tempfile.TemporaryDirectory() as directory:
            state = Path(directory) / "gate"
            state.mkdir()
            with mock.patch.object(module, "STATE_DIR", state):
                receipt = module.issue_receipt(11, "a" * 64, "synthetic-reviewer")
                module.validate_receipt(receipt, 11, "a" * 64, "synthetic-reviewer")
                document = json.loads(receipt.read_text(encoding="utf-8"))
                document["payload"]["head_sha"] = "b" * 64
                receipt.write_text(json.dumps(document), encoding="utf-8")
                with self.assertRaises(module.FixtureFailure):
                    module.validate_receipt(receipt, 11, "b" * 64, "synthetic-reviewer")

    def test_template_disables_registration_and_builtin_ssh(self) -> None:
        config = (ROOT / "app.ini.template").read_text(encoding="utf-8")
        for required in ("WORK_PATH = /srv/agent-stack/state/gitea", "HTTP_ADDR = 127.0.0.1", "ROOT_URL = https://192.168.8.100:3443/", "DOMAIN = 192.168.8.100", "COOKIE_SECURE = true", "DISABLE_SSH = true", "DISABLE_REGISTRATION = true", "INSTALL_LOCK = true"):
            self.assertIn(required, config)
        setup = (ROOT / "setup-local-gitea.sh").read_text(encoding="utf-8")
        self.assertIn("Existing app.ini has an unreviewed public-origin configuration", setup)
        for marker in ("__GITEA_SECRET_KEY__", "__GITEA_INTERNAL_TOKEN__", "__GITEA_LFS_JWT_SECRET__", "__GITEA_OAUTH2_JWT_SECRET__"):
            self.assertIn(marker, config)

    def test_renderer_binds_distinct_fixture_values_without_markers(self) -> None:
        renderer = _renderer_module()
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "app.ini"
            values = {
                "GITEA_SECRET_KEY": "fixture-secret-key",
                "GITEA_INTERNAL_TOKEN": "fixture-internal-token",
                "GITEA_LFS_JWT_SECRET": "fixture-lfs-jwt-secret",
                "GITEA_OAUTH2_JWT_SECRET": "fixture-oauth2-jwt-secret",
            }
            renderer.render(ROOT / "app.ini.template", output, values)
            rendered = output.read_text(encoding="utf-8")
        for value in values.values():
            self.assertEqual(1, rendered.count(value))
        self.assertNotIn("__GITEA_", rendered)

    def test_renderer_rejects_duplicate_fixture_values(self) -> None:
        renderer = _renderer_module()
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                renderer.render(
                    ROOT / "app.ini.template",
                    Path(directory) / "app.ini",
                    {
                        "GITEA_SECRET_KEY": "same",
                        "GITEA_INTERNAL_TOKEN": "same",
                        "GITEA_LFS_JWT_SECRET": "different",
                        "GITEA_OAUTH2_JWT_SECRET": "another",
                    },
                )

    def test_bootstrap_default_is_dry_run_and_policy_denies_direct_push(self) -> None:
        command = [
            sys.executable,
            str(ROOT / "bootstrap-repository-policy.py"),
            "--url", "http://127.0.0.1:3000",
            "--token-file", "/not/read/during/dry-run",
            "--owner", "storage",
            "--repository", "workspace",
            "--author-user", "author-bot",
            "--review-user", "review-bot",
            "--merge-user", "merge-bot",
        ]
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["dry_run"])
        self.assertFalse(payload["policy"]["enable_push"])
        self.assertEqual(["independent-qc"], payload["policy"]["status_check_contexts"])
        self.assertEqual(1, payload["policy"]["required_approvals"])
        self.assertTrue(payload["policy"]["enable_approvals_whitelist"])
        self.assertEqual(["review-bot"], payload["policy"]["approvals_whitelist_username"])
        self.assertTrue(payload["policy"]["block_on_outdated_branch"])

    def test_bootstrap_refuses_non_loopback_and_insecure_token_mode(self) -> None:
        bad_url = subprocess.run(
            [sys.executable, str(ROOT / "bootstrap-repository-policy.py"), "--url", "http://localhost:3000", "--token-file", "x", "--owner", "o", "--repository", "r", "--author-user", "a", "--review-user", "q", "--merge-user", "m"],
            capture_output=True,
            text=True,
        )
        self.assertNotEqual(0, bad_url.returncode)
        userinfo_url = subprocess.run(
            [sys.executable, str(ROOT / "bootstrap-repository-policy.py"), "--url", "http://user@127.0.0.1:3000", "--token-file", "x", "--owner", "o", "--repository", "r", "--author-user", "a", "--review-user", "q", "--merge-user", "m"],
            capture_output=True,
            text=True,
        )
        self.assertNotEqual(0, userinfo_url.returncode)
        with tempfile.TemporaryDirectory() as directory:
            token = Path(directory) / "token"
            token.write_text("not-a-real-token", encoding="utf-8")
            token.chmod(0o644)
            insecure = subprocess.run(
                [sys.executable, str(ROOT / "bootstrap-repository-policy.py"), "--apply", "--url", "http://127.0.0.1:3000", "--token-file", str(token), "--owner", "o", "--repository", "r", "--author-user", "a", "--review-user", "q", "--merge-user", "m"],
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(0, insecure.returncode)
            self.assertNotIn("not-a-real-token", insecure.stdout + insecure.stderr)

    def test_apply_refuses_redirect_without_contacting_redirect_target(self) -> None:
        target_hits: list[str] = []

        class TargetHandler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                target_hits.append(self.path)
                self.send_response(200)
                self.end_headers()

            def log_message(self, format: str, *args: object) -> None:
                return

        target = ThreadingHTTPServer(("127.0.0.1", 0), TargetHandler)
        target_thread = threading.Thread(target=target.serve_forever, daemon=True)
        target_thread.start()

        class RedirectHandler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                self.send_response(302)
                self.send_header("Location", f"http://127.0.0.1:{target.server_port}/captured")
                self.end_headers()

            def log_message(self, format: str, *args: object) -> None:
                return

        redirector = ThreadingHTTPServer(("127.0.0.1", 0), RedirectHandler)
        redirect_thread = threading.Thread(target=redirector.serve_forever, daemon=True)
        redirect_thread.start()
        try:
            with tempfile.TemporaryDirectory() as directory:
                token = Path(directory) / "token"
                token.write_text("test-token-must-not-leak", encoding="utf-8")
                token.chmod(0o600)
                result = subprocess.run(
                    [sys.executable, str(ROOT / "bootstrap-repository-policy.py"), "--apply", "--url", f"http://127.0.0.1:{redirector.server_port}", "--token-file", str(token), "--owner", "storage", "--repository", "workspace", "--author-user", "author-role", "--review-user", "review-role", "--merge-user", "merge-role"],
                    capture_output=True,
                    text=True,
                )
            self.assertNotEqual(0, result.returncode)
            self.assertEqual([], target_hits)
            self.assertNotIn("test-token-must-not-leak", result.stdout + result.stderr)
        finally:
            redirector.shutdown()
            target.shutdown()
            redirector.server_close()
            target.server_close()


if __name__ == "__main__":
    unittest.main()
