#!/usr/bin/env python3
"""Explicitly opt-in Gitea repository/protected-branch bootstrap.

No request is made without --apply.  Credentials are read only from an external
regular 0600 token file and are never printed.  This module assumes Gitea's
1.27.x-compatible REST API; re-review it for a version change.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import stat
import sys
import urllib.error
import urllib.parse
import urllib.request


EXPECTED_API_PREFIX = "1.27."
REQUIRED_STATUS = "independent-qc"
MAX_RESPONSE_BYTES = 64 * 1024


def _identifier(value: str, label: str) -> str:
    if not value or len(value) > 128 or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_." for ch in value):
        raise ValueError(f"invalid {label}")
    return value


def _loopback_base_url(value: str) -> str:
    parsed = urllib.parse.urlparse(value)
    if parsed.scheme not in {"http", "https"} or parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise ValueError("Gitea URL must be an origin only")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Gitea URL must not contain user information")
    if parsed.hostname not in {"127.0.0.1", "::1"}:
        raise ValueError("bootstrap only permits literal loopback Gitea URLs")
    return value.rstrip("/")


def _token(path: Path) -> str:
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise ValueError("token path must be a regular non-symlink file")
    if info.st_mode & 0o077:
        raise ValueError("token file must not be group/world accessible")
    value = path.read_text(encoding="utf-8").strip()
    if not value or len(value) > 4096 or any(ch.isspace() for ch in value):
        raise ValueError("token file is empty or malformed")
    return value


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Fail closed so an Authorization header never follows a redirect."""

    def redirect_request(self, request, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        return None


def _request(base: str, token: str, method: str, path: str, payload: object | None = None) -> object:
    body = None if payload is None else json.dumps(payload, separators=(",", ":")).encode("utf-8")
    request = urllib.request.Request(
        base + path,
        data=body,
        method=method,
        headers={"Authorization": f"token {token}", "Accept": "application/json", **({"Content-Type": "application/json"} if body else {})},
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    with opener.open(request, timeout=10) as response:
        content = response.read(MAX_RESPONSE_BYTES + 1)
    if len(content) > MAX_RESPONSE_BYTES:
        raise ValueError("Gitea response exceeds the bootstrap limit")
    return json.loads(content.decode("utf-8") or "null")


def _policy(branch: str, merge_user: str, review_user: str) -> dict[str, object]:
    return {
        "branch_name": branch,
        "enable_push": False,
        "enable_push_whitelist": False,
        "enable_merge_whitelist": True,
        "merge_whitelist_usernames": [merge_user],
        "enable_approvals_whitelist": True,
        "approvals_whitelist_username": [review_user],
        "enable_status_check": True,
        "status_check_contexts": [REQUIRED_STATUS],
        "required_approvals": 1,
        "block_on_rejected_reviews": True,
        "block_on_outdated_branch": True,
        "block_on_official_review_requests": True,
        "block_admin_merge_override": True,
        "dismiss_stale_approvals": True,
        "require_signed_commits": False,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--url", required=True)
    parser.add_argument("--token-file", type=Path, required=True)
    parser.add_argument("--owner", required=True)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--author-user", required=True)
    parser.add_argument("--review-user", required=True)
    parser.add_argument("--merge-user", required=True)
    parser.add_argument("--branch", default="main")
    args = parser.parse_args(argv)
    try:
        base = _loopback_base_url(args.url)
        owner = _identifier(args.owner, "owner")
        repository = _identifier(args.repository, "repository")
        author_user = _identifier(args.author_user, "author user")
        review_user = _identifier(args.review_user, "review user")
        merge_user = _identifier(args.merge_user, "merge user")
        branch = _identifier(args.branch, "branch")
        if len({author_user, review_user, merge_user}) != 3:
            raise ValueError("author, independent reviewer, and merge user must be distinct")
        policy = _policy(branch, merge_user, review_user)
    except ValueError as exc:
        parser.error(str(exc))
    if not args.apply:
        print(json.dumps({"dry_run": True, "owner": owner, "repository": repository, "policy": policy}, sort_keys=True))
        return 0
    try:
        token = _token(args.token_file)
        version = _request(base, token, "GET", "/api/v1/version")
        if not isinstance(version, dict) or not str(version.get("version", "")).startswith(EXPECTED_API_PREFIX):
            raise ValueError("Gitea API version is not the reviewed 1.27.x line")
        encoded = f"/api/v1/repos/{urllib.parse.quote(owner, safe='')}/{urllib.parse.quote(repository, safe='')}"
        repository_response = _request(base, token, "GET", encoded)
        response_owner = repository_response.get("owner") if isinstance(repository_response, dict) else None
        if (
            not isinstance(repository_response, dict)
            or repository_response.get("name") != repository
            or not isinstance(response_owner, dict)
            or response_owner.get("login") != owner
        ):
            raise ValueError("Gitea repository response does not match the requested owner/name")
        existing = _request(base, token, "GET", encoded + "/branch_protections")
        if not isinstance(existing, list):
            raise ValueError("Gitea returned an invalid branch-protection list")
        if any(item.get("branch_name") == branch for item in existing if isinstance(item, dict)):
            raise ValueError("branch protection already exists; refuse implicit replacement")
        _request(base, token, "POST", encoded + "/branch_protections", policy)
    except (OSError, ValueError, urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError):
        print("bootstrap refused; inspect local operator logs without printing credentials or remote response bodies", file=sys.stderr)
        return 1
    print("protected branch policy created; verify status checks and review roles before first merge")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
