#!/usr/bin/env python3
"""Render the Gitea configuration from field-specific external secrets.

Secrets are deliberately supplied through the process environment, never command
arguments or standard output.  This is called only by the root-only setup helper
after it has generated values as the dedicated Gitea account.
"""

from __future__ import annotations

import os
from pathlib import Path
import sys


MARKERS = {
    "__GITEA_SECRET_KEY__": "GITEA_SECRET_KEY",
    "__GITEA_INTERNAL_TOKEN__": "GITEA_INTERNAL_TOKEN",
    "__GITEA_LFS_JWT_SECRET__": "GITEA_LFS_JWT_SECRET",
    "__GITEA_OAUTH2_JWT_SECRET__": "GITEA_OAUTH2_JWT_SECRET",
}


def render(template: Path, destination: Path, environment: dict[str, str]) -> None:
    contents = template.read_text(encoding="utf-8")
    values = [environment.get(variable, "") for variable in MARKERS.values()]
    if any(not value or "\n" in value or "\r" in value for value in values):
        raise ValueError("Gitea secret values must be nonempty single lines")
    if len(set(values)) != len(values):
        raise ValueError("Gitea secret values must be distinct")
    for marker, variable in MARKERS.items():
        if contents.count(marker) != 1:
            raise ValueError(f"template marker mismatch for {variable}")
        contents = contents.replace(marker, environment[variable])
    if any(marker in contents for marker in MARKERS):
        raise ValueError("unreplaced Gitea secret marker")
    destination.write_text(contents, encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    arguments = sys.argv[1:] if argv is None else argv
    if len(arguments) != 2:
        print("Usage: render_app_ini.py TEMPLATE DESTINATION", file=sys.stderr)
        return 64
    try:
        render(Path(arguments[0]), Path(arguments[1]), dict(os.environ))
    except (OSError, ValueError) as exc:
        print(f"refused to render app.ini: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
