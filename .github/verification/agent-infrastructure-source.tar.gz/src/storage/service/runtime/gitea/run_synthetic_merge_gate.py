#!/usr/bin/env python3
"""Run the isolated local Gitea author/reviewer/merge-gate fixture.

This is intentionally a root-only, one-shot fixture runner.  Synthetic actor
tokens stay in the external 0700 fixture directory.  The only merge credential
is consumed here, after verifying a root-only HMAC receipt bound to the exact
pull-request head SHA; a forgeable Gitea status label is never sufficient.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request


BASE = "http://127.0.0.1:3000"
OWNER = "synthetic-operator"
REPOSITORY = "synthetic-merge-gate"
BRANCH = "main"
FIXTURE_DIR = Path("/srv/agent-stack/secrets/gitea/synthetic-fixture")
STATE_DIR = Path("/srv/agent-stack/state/gitea/synthetic-merge-gate-run6")
MAX_RESPONSE_BYTES = 64 * 1024


class FixtureFailure(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        return None


def _token(actor: str) -> str:
    path = FIXTURE_DIR / f"{actor}.token-v2"
    metadata = path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode) or metadata.st_mode & 0o077:
        raise FixtureFailure("synthetic token file is unsafe")
    token = path.read_text(encoding="utf-8").strip()
    if not token or any(character.isspace() for character in token):
        raise FixtureFailure("synthetic token is malformed")
    return token


def request(actor: str, method: str, path: str, payload: object | None = None, *, allow_error: bool = False) -> tuple[int, object]:
    body = None if payload is None else json.dumps(payload, separators=(",", ":")).encode("utf-8")
    call = urllib.request.Request(
        BASE + path,
        data=body,
        method=method,
        headers={"Authorization": f"token {_token(actor)}", "Accept": "application/json", **({"Content-Type": "application/json"} if body else {})},
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    try:
        with opener.open(call, timeout=10) as response:
            content = response.read(MAX_RESPONSE_BYTES + 1)
            status = response.status
    except urllib.error.HTTPError as error:
        content = error.read(MAX_RESPONSE_BYTES + 1)
        status = error.code
        if not allow_error:
            raise FixtureFailure(f"Gitea request failed with HTTP {status}") from error
    except urllib.error.URLError as error:
        raise FixtureFailure("Gitea loopback request failed") from error
    if len(content) > MAX_RESPONSE_BYTES:
        raise FixtureFailure("Gitea response exceeded bound")
    try:
        decoded = json.loads(content.decode("utf-8") or "null")
    except json.JSONDecodeError:
        decoded = None
    return status, decoded


def require_ok(actor: str, method: str, path: str, payload: object | None = None) -> object:
    status, response = request(actor, method, path, payload)
    if not 200 <= status < 300:
        raise FixtureFailure("unexpected Gitea response")
    return response


def _private_file(path: Path, content: bytes) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as output:
        output.write(content)
        output.flush()
        os.fsync(output.fileno())


def _stage(name: str) -> None:
    """Persist a nonsecret progress marker for interrupted fixture evidence."""
    path = STATE_DIR / "progress.json"
    temporary = STATE_DIR / "progress.next"
    with temporary.open("w", encoding="utf-8") as output:
        json.dump({"stage": name}, output, sort_keys=True)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, path)


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def issue_receipt(pull_number: int, head_sha: str, reviewer: str) -> Path:
    key_path = STATE_DIR / "independent-qc.key"
    if key_path.exists():
        raise FixtureFailure("fixture signing key already exists; no implicit rerun")
    _private_file(key_path, secrets.token_bytes(32))
    payload = {"owner": OWNER, "repository": REPOSITORY, "pull_number": pull_number, "head_sha": head_sha, "reviewer": reviewer, "check": "synthetic-fixture-content-v1"}
    signature = hmac.new(key_path.read_bytes(), _canonical(payload), hashlib.sha256).hexdigest()
    receipt = STATE_DIR / "independent-qc.receipt.json"
    _private_file(receipt, _canonical({"payload": payload, "signature": signature}) + b"\n")
    return receipt


def validate_receipt(receipt: Path, pull_number: int, head_sha: str, reviewer: str) -> None:
    try:
        document = json.loads(receipt.read_text(encoding="utf-8"))
        payload = document["payload"]
        signature = document["signature"]
    except (OSError, KeyError, TypeError, json.JSONDecodeError) as error:
        raise FixtureFailure("independent receipt is invalid") from error
    expected = {"owner": OWNER, "repository": REPOSITORY, "pull_number": pull_number, "head_sha": head_sha, "reviewer": reviewer, "check": "synthetic-fixture-content-v1"}
    if payload != expected or not isinstance(signature, str):
        raise FixtureFailure("independent receipt does not bind this pull head")
    key = (STATE_DIR / "independent-qc.key").read_bytes()
    actual = hmac.new(key, _canonical(payload), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(actual, signature):
        raise FixtureFailure("independent receipt signature mismatch")


def _git_author_branch(worktree: Path) -> str:
    askpass = STATE_DIR / "author-askpass.sh"
    askpass.write_text("#!/bin/sh\ncase \"$1\" in *Username*) printf '%s\\n' synthetic-author ;; *) cat /srv/agent-stack/secrets/gitea/synthetic-fixture/synthetic-author.token-v2 ;; esac\n", encoding="utf-8")
    askpass.chmod(0o700)
    environment = {**os.environ, "GIT_ASKPASS": str(askpass), "GIT_TERMINAL_PROMPT": "0", "NO_PROXY": "127.0.0.1,localhost"}
    remote = f"{BASE}/{OWNER}/{REPOSITORY}.git"
    def git(*arguments: str, expect: bool = True) -> subprocess.CompletedProcess[str]:
        result = subprocess.run(["git", *arguments], cwd=worktree, env=environment, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True, timeout=20, check=False)
        if expect and result.returncode:
            raise FixtureFailure("controlled synthetic git operation failed")
        return result
    git("clone", remote, ".")
    git("config", "user.name", "Synthetic Author")
    git("config", "user.email", "synthetic-author@example.invalid")
    (worktree / "direct-main.txt").write_text("must not reach protected main\n", encoding="utf-8")
    git("add", "direct-main.txt")
    git("commit", "-m", "synthetic direct-main attempt")
    direct_push = git("push", "origin", "HEAD:main", expect=False)
    if direct_push.returncode == 0:
        raise FixtureFailure("protected main accepted author direct push")
    git("reset", "--hard", "origin/main")
    git("switch", "-c", "task/synthetic-gate")
    (worktree / "approved-change.txt").write_text("synthetic independently verified change\n", encoding="utf-8")
    git("add", "approved-change.txt")
    git("commit", "-m", "synthetic reviewed change")
    git("push", "origin", "HEAD:task/synthetic-gate")
    return "task/synthetic-gate"


def main() -> int:
    if os.geteuid() != 0:
        print("Run the synthetic fixture only as root.", file=sys.stderr)
        return 64
    if STATE_DIR.exists():
        print("Synthetic fixture state already exists; refusing implicit rerun.", file=sys.stderr)
        return 1
    STATE_DIR.mkdir(mode=0o700, parents=True)
    try:
        _stage("verify_repository")
        repository = require_ok("synthetic-operator", "GET", f"/api/v1/repos/{OWNER}/{REPOSITORY}")
        if not isinstance(repository, dict) or repository.get("name") != REPOSITORY:
            raise FixtureFailure("synthetic repository response mismatch")
        prefix = f"/api/v1/repos/{OWNER}/{REPOSITORY}"
        _stage("add_collaborators")
        for actor in ("synthetic-author", "synthetic-reviewer", "synthetic-merge"):
            require_ok("synthetic-operator", "PUT", prefix + "/collaborators/" + actor, {"permission": "write"})
        _stage("protect_main")
        protections = require_ok("synthetic-operator", "GET", prefix + "/branch_protections")
        if not isinstance(protections, list):
            raise FixtureFailure("synthetic branch-policy response is invalid")
        if not any(isinstance(item, dict) and item.get("branch_name") == BRANCH for item in protections):
            policy_script = Path(__file__).with_name("bootstrap-repository-policy.py")
            policy = subprocess.run([sys.executable, str(policy_script), "--apply", "--url", BASE, "--token-file", str(FIXTURE_DIR / "synthetic-operator.token-v2"), "--owner", OWNER, "--repository", REPOSITORY, "--author-user", "synthetic-author", "--review-user", "synthetic-reviewer", "--merge-user", "synthetic-merge"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, check=False)
            if policy.returncode:
                raise FixtureFailure("synthetic branch-policy bootstrap failed")
        _stage("push_author_branch")
        with tempfile.TemporaryDirectory(dir=STATE_DIR) as temporary:
            branch = _git_author_branch(Path(temporary))
        pull = require_ok("synthetic-author", "POST", prefix + "/pulls", {"title": "synthetic protected merge", "head": branch, "base": BRANCH})
        if not isinstance(pull, dict) or not isinstance(pull.get("number"), int) or not isinstance(pull.get("head"), dict) or not isinstance(pull["head"].get("sha"), str):
            raise FixtureFailure("synthetic pull response mismatch")
        number = pull["number"]
        head_sha = pull["head"]["sha"]
        _stage("prove_denials")
        self_review, _ = request("synthetic-author", "POST", prefix + f"/pulls/{number}/reviews", {"event": "APPROVED", "body": "self approval must fail"}, allow_error=True)
        missing_preconditions, _ = request("synthetic-merge", "POST", prefix + f"/pulls/{number}/merge", {"Do": "merge"}, allow_error=True)
        if self_review < 400 or missing_preconditions < 400:
            raise FixtureFailure("Gitea accepted a forbidden self-review or premature merge")
        forged_status, _ = request("synthetic-author", "POST", prefix + f"/statuses/{head_sha}", {"state": "success", "context": "independent-qc", "description": "untrusted actor attempt"}, allow_error=True)
        author_merge, _ = request("synthetic-author", "POST", prefix + f"/pulls/{number}/merge", {"Do": "merge"}, allow_error=True)
        if author_merge < 400:
            raise FixtureFailure("author bypassed merge whitelist")
        _stage("review_and_receipt")
        require_ok("synthetic-reviewer", "POST", prefix + f"/pulls/{number}/reviews", {"event": "APPROVED", "body": "independent synthetic review"})
        receipt = issue_receipt(number, head_sha, "synthetic-reviewer")
        validate_receipt(receipt, number, head_sha, "synthetic-reviewer")
        _stage("receipt_gated_merge")
        require_ok("synthetic-merge", "POST", prefix + f"/statuses/{head_sha}", {"state": "success", "context": "independent-qc", "description": "root-only signed fixture receipt"})
        require_ok("synthetic-merge", "POST", prefix + f"/pulls/{number}/merge", {"Do": "merge"})
        _stage("passed")
    except (FixtureFailure, OSError, subprocess.TimeoutExpired, ValueError):
        print("Synthetic merge-gate fixture failed; retained root-only state/evidence; no credentials were printed.", file=sys.stderr)
        return 1
    print(json.dumps({"synthetic_fixture": "passed", "author_status_write_accepted": 200 <= forged_status < 300, "direct_main_push": "denied", "self_review": "denied", "premature_merge": "denied", "author_merge": "denied", "merge": "receipt-gated"}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
