"""Live V1 contract test; requires the installed private services on STEVEN."""

from __future__ import annotations

import json
import socket
import subprocess
import time
import unittest
from pathlib import Path

import httpx

URL = "http://127.0.0.1:18080/mcp"
SECRETS = Path("/srv/agent-stack/state/memory/secrets")
RAW_SOCKET = "/srv/agent-stack/state/memory/run/backend.sock"


def rpc_result(response: httpx.Response) -> dict:
    """Extract JSON-RPC data from the upstream Streamable HTTP SSE response."""
    response.raise_for_status()
    for line in response.text.splitlines():
        if line.startswith("data: "):
            return json.loads(line[6:])
    raise AssertionError(f"no JSON-RPC data in response: {response.text[:200]!r}")


class Client:
    def __init__(self, token_file: str) -> None:
        self.http = httpx.Client(timeout=30)
        self.headers = {"Authorization": f"Bearer {(SECRETS / token_file).read_text().strip()}"}
        self.session: str | None = None

    def call(self, method: str, params: dict | None = None, request_id: int = 1) -> httpx.Response:
        headers = dict(self.headers)
        if self.session:
            headers["MCP-Session-Id"] = self.session
        response = self.http.post(
            URL,
            headers=headers,
            json={"jsonrpc": "2.0", "id": request_id, "method": method, "params": params or {}},
        )
        self.session = response.headers.get("mcp-session-id", self.session)
        return response

    def initialize(self) -> None:
        response = self.call(
            "initialize",
            {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "v1-test", "version": "1"}},
        )
        response.raise_for_status()
        self.assert_session()
        self.http.post(URL, headers={**self.headers, "MCP-Session-Id": self.session}, json={"jsonrpc": "2.0", "method": "notifications/initialized"}).raise_for_status()

    def assert_session(self) -> None:
        if not self.session:
            raise AssertionError("initialize did not establish an MCP session")


class MemoryV1Integration(unittest.TestCase):
    def test_live_shared_restricted_memory(self) -> None:
        a, b = Client("hermes-a.token"), Client("hermes-b.token")
        self.addCleanup(a.http.close)
        self.addCleanup(b.http.close)
        self.assertEqual(401, httpx.post(URL, json={"jsonrpc": "2.0", "id": 1, "method": "initialize"}).status_code)
        a.initialize()
        listed = rpc_result(a.call("tools/list"))["result"]["tools"]
        names = {tool["name"] for tool in listed}
        self.assertNotIn("delete_note", names)
        self.assertNotIn("delete_project", names)
        self.assertIn("write_note", names)

        title = f"Synthetic Trust Cell {time.time_ns()}"
        created = a.call("tools/call", {"name": "write_note", "arguments": {"title": title, "content": "revision one", "directory": "trust-cells-a", "output_format": "json"}}, 3)
        self.assertIn("result", rpc_result(created))
        self.assertFalse(rpc_result(created)["result"].get("isError", False))
        b.initialize()
        found = b.call("tools/call", {"name": "read_note", "arguments": {"identifier": title, "output_format": "json"}}, 4)
        self.assertIn("result", rpc_result(found))
        self.assertIn("revision one", found.text)
        corrected = b.call("tools/call", {"name": "edit_note", "arguments": {"identifier": title, "operation": "find_replace", "find_text": "revision one", "content": "revision two", "expected_replacements": 1, "output_format": "json"}}, 5)
        self.assertIn("result", rpc_result(corrected))
        self.assertFalse(rpc_result(corrected)["result"].get("isError", False))

        # A reconnect is a fresh authenticated client, not reuse of an old session.
        reconnect = Client("hermes-a.token")
        self.addCleanup(reconnect.http.close)
        reconnect.initialize()
        revised = reconnect.call("tools/call", {"name": "read_note", "arguments": {"identifier": title, "output_format": "json"}}, 6)
        self.assertIn("revision two", rpc_result(revised)["result"]["content"][0]["text"])
        wrong_scope = reconnect.call("tools/call", {"name": "read_note", "arguments": {"identifier": title, "project": "personal"}}, 7)
        self.assertEqual(403, wrong_scope.status_code)
        deletion = reconnect.call("tools/call", {"name": "delete_note", "arguments": {"identifier": title}}, 8)
        self.assertEqual(403, deletion.status_code)
        management = reconnect.call("tools/call", {"name": "list_memory_projects", "arguments": {}}, 9)
        self.assertEqual(403, management.status_code)
        resource = reconnect.call("resources/list", {}, 10)
        self.assertEqual(403, resource.status_code)
        absolute = reconnect.call("tools/call", {"name": "read_note", "arguments": {"identifier": "/etc/passwd"}}, 11)
        self.assertNotIn("root:", absolute.text)
        traversal = reconnect.call("tools/call", {"name": "write_note", "arguments": {"title": "blocked traversal", "content": "no", "directory": "../../outside"}}, 12)
        self.assertIn("paths must stay within project boundaries", traversal.text)
        self.assertFalse(Path("/srv/agent-stack/knowledge/outside").exists())

    def test_raw_tcp_and_agent_socket_are_denied(self) -> None:
        with self.assertRaises(OSError):
            socket.create_connection(("127.0.0.1", 18081), timeout=1)
        result = subprocess.run(
            ["runuser", "-u", "stack-agent-a", "--", "python3", "-c", f"import socket; s=socket.socket(socket.AF_UNIX); s.connect({RAW_SOCKET!r})"],
            capture_output=True,
            text=True,
        )
        self.assertNotEqual(0, result.returncode, result.stdout + result.stderr)
        self.assertIn("PermissionError", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
