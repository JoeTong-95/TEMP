"""Private Unix-socket launcher for the pinned Basic Memory MCP server.

This deliberately does not open a TCP listener.  The public gateway is the
only process that can reach this socket; agents use its authenticated endpoint.
"""

from __future__ import annotations

import asyncio
import os
import socket
import stat
from pathlib import Path

import uvicorn


async def main() -> None:
    socket_path = Path(os.environ["MEMORY_BACKEND_SOCKET"])
    socket_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if socket_path.exists() or socket_path.is_symlink():
        if not stat.S_ISSOCK(socket_path.lstat().st_mode):
            raise RuntimeError(f"refusing to replace non-socket {socket_path}")
        socket_path.unlink()

    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.bind(str(socket_path))
    socket_path.chmod(0o600)
    listener.listen(128)
    listener.setblocking(False)

    # Register upstream tools exactly as its CLI does, without its HTTP launcher.
    import basic_memory.mcp.prompts  # noqa: F401
    import basic_memory.mcp.resources  # noqa: F401
    import basic_memory.mcp.tools  # noqa: F401
    from basic_memory.config import init_mcp_logging
    from basic_memory.mcp.server import mcp

    init_mcp_logging()
    app = mcp.http_app(path="/mcp", transport="streamable-http")
    server = uvicorn.Server(
        uvicorn.Config(app, log_config=None, access_log=False, lifespan="on")
    )
    try:
        await server.serve(sockets=[listener])
    finally:
        listener.close()
        socket_path.unlink(missing_ok=True)


if __name__ == "__main__":
    asyncio.run(main())
