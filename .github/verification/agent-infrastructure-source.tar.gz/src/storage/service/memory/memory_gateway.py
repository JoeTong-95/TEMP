"""Authenticated, deletion-free Streamable HTTP boundary for Basic Memory."""

from __future__ import annotations

import asyncio
import hmac
import json
import os
from pathlib import Path
from typing import Any

import httpx
import uvicorn
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse
from starlette.routing import Route

ALLOWED_TOOLS = frozenset(
    {
        "write_note",
        "edit_note",
        "read_note",
        "view_note",
        "search_notes",
        "recent_activity",
        "list_directory",
        "build_context",
    }
)
DENIED_TOOLS = frozenset({"delete_note", "delete_project"})
ALLOWED_PROJECT = "platform-canary"
ALLOWED_METHODS = frozenset({"initialize", "notifications/initialized", "ping", "tools/list", "tools/call"})
MAX_BODY_BYTES = 1_048_576
MAX_DISCOVERY_BYTES = 1_048_576


def _tokens() -> tuple[str, ...]:
    token_dir = Path(os.environ["MEMORY_GATEWAY_TOKEN_DIR"])
    values = tuple(
        p.read_text(encoding="utf-8").strip()
        for p in sorted(token_dir.glob("*.token"))
        if p.is_file()
    )
    if not values or any(not value for value in values):
        raise RuntimeError("no usable gateway tokens")
    return values


def _authorized(request: Request) -> bool:
    value = request.headers.get("authorization", "")
    if not value.startswith("Bearer "):
        return False
    presented = value[7:]
    return any(hmac.compare_digest(presented, expected) for expected in _tokens())


def _reject(message: str, request_id: Any = None) -> JSONResponse:
    return JSONResponse(
        {"jsonrpc": "2.0", "id": request_id, "error": {"code": -32601, "message": message}},
        status_code=403,
    )


def _policy(payload: Any) -> tuple[str | None, Any]:
    if not isinstance(payload, dict):
        return "batch and non-object JSON-RPC requests are disabled", None
    request_id = payload.get("id")
    method = payload.get("method")
    if method not in ALLOWED_METHODS:
        return "JSON-RPC method is outside the restricted allowlist", request_id
    if method != "tools/call":
        return None, request_id
    params = payload.get("params", {})
    if not isinstance(params, dict):
        return "invalid tool parameters", request_id
    tool_name = params.get("name")
    if tool_name in DENIED_TOOLS:
        return "this deployment permanently disables deletion tools", request_id
    if tool_name not in ALLOWED_TOOLS:
        return "tool is outside the restricted platform-canary allowlist", request_id
    arguments = params.get("arguments", {})
    if not isinstance(arguments, dict):
        return "tool arguments must be an object", request_id
    if "project" in arguments:
        if arguments["project"] != ALLOWED_PROJECT:
            return "project is restricted to platform-canary", request_id
    if any(
        key in arguments for key in ("workspace", "project_id", "workspace_id")
    ):
        return "workspace and project-id routing are disabled", request_id
    return None, request_id


async def mcp(request: Request) -> Response:
    if not _authorized(request):
        return Response(status_code=401, headers={"WWW-Authenticate": "Bearer"})
    chunks: list[bytes] = []
    size = 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > MAX_BODY_BYTES:
            return Response("request exceeds gateway limit", status_code=413)
        chunks.append(chunk)
    body = b"".join(chunks)
    # Streamable HTTP session recovery uses authenticated GET/DELETE requests
    # without JSON-RPC bodies. They cannot invoke a tool and are forwarded intact.
    if request.method in {"GET", "DELETE"}:
        payload = None
    else:
        try:
            payload = json.loads(body) if body else None
        except json.JSONDecodeError:
            return Response("invalid JSON", status_code=400)
        denied, request_id = _policy(payload)
        if denied:
            return _reject(denied, request_id)

    headers = {
        key: value
        for key, value in request.headers.items()
        if key.lower() not in {"authorization", "host", "content-length"}
    }
    transport = httpx.AsyncHTTPTransport(uds=os.environ["MEMORY_BACKEND_SOCKET"])
    client = httpx.AsyncClient(transport=transport, timeout=60.0)
    upstream_request = client.build_request(
        request.method, "http://memory-backend/mcp", headers=headers, content=body
    )
    try:
        upstream = await client.send(upstream_request, stream=True)
    except httpx.HTTPError:
        await client.aclose()
        return Response("memory backend unavailable", status_code=503)

    # Keep denied tools out of discovery as well as rejecting direct calls.
    if isinstance(payload, dict) and payload.get("method") == "tools/list":
        try:
            chunks = []
            size = 0
            async for chunk in upstream.aiter_raw():
                size += len(chunk)
                if size > MAX_DISCOVERY_BYTES:
                    raise ValueError("discovery response too large")
                chunks.append(chunk)
            content = b"".join(chunks)
            def filter_result(response_payload: Any) -> Any:
                tools = response_payload.get("result", {}).get("tools")
                if not isinstance(tools, list):
                    raise ValueError("not a tools/list response")
                response_payload["result"]["tools"] = [tool for tool in tools if tool.get("name") in ALLOWED_TOOLS]
                return response_payload
            content_type = upstream.headers.get("content-type", "")
            if content_type.startswith("application/json"):
                content = json.dumps(filter_result(json.loads(content)), separators=(",", ":")).encode()
            else:
                filtered, seen = [], False
                for line in content.decode("utf-8").splitlines(keepends=True):
                    if line.startswith("data: "):
                        line = "data: " + json.dumps(filter_result(json.loads(line[6:])), separators=(",", ":")) + "\r\n"
                        seen = True
                    filtered.append(line)
                if not seen:
                    raise ValueError("missing JSON-RPC tools/list data")
                content = "".join(filtered).encode()
        except (AttributeError, TypeError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
            await upstream.aclose()
            await client.aclose()
            return Response("gateway refused unfilterable tool discovery", status_code=502)
        status_code = upstream.status_code
        response_headers = {
            key: value for key, value in upstream.headers.items()
            if key.lower() not in {"content-length", "connection", "transfer-encoding"}
        }
        await upstream.aclose()
        await client.aclose()
        return Response(content, status_code=status_code, headers=response_headers)

    async def stream() -> Any:
        try:
            async for chunk in upstream.aiter_raw():
                yield chunk
        finally:
            await upstream.aclose()
            await client.aclose()

    response_headers = {
        key: value
        for key, value in upstream.headers.items()
        if key.lower() not in {"content-length", "connection", "transfer-encoding"}
    }
    return StreamingResponse(stream(), status_code=upstream.status_code, headers=response_headers)


app = Starlette(routes=[Route("/mcp", mcp, methods=["POST", "GET", "DELETE"])])


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=18080, log_config=None, access_log=False)
