"""Offline guardrails for the scoped Basic Memory/Hermes deployment source."""

from __future__ import annotations

import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parent


class StaticPolicyTests(unittest.TestCase):
    def test_pins_name_only_official_runtime_packages(self) -> None:
        pins = json.loads((ROOT / "pins.json").read_text(encoding="utf-8"))
        self.assertEqual("basic-memory==0.23.2", pins["basic_memory"]["distribution"])
        self.assertEqual("hermes-agent==0.19.0", pins["hermes"]["distribution"])
        self.assertEqual("hermes", pins["hermes"]["not_this_package"])
        self.assertIn("NousResearch/hermes-agent", pins["hermes"]["upstream_repository"])

    def test_readme_requires_loopback_and_separate_identities(self) -> None:
        text = (ROOT / "README.md").read_text(encoding="utf-8")
        for required in (
            "127.0.0.1:18081",
            "127.0.0.1:18080",
            "stack-memory",
            "stack-agent-a",
            "stack-agent-b",
            "/srv/agent-stack/state/hermes-a",
            "/srv/agent-stack/state/hermes-b",
        ):
            self.assertIn(required, text)
        self.assertNotIn("0.0.0.0", text)

    def test_readme_has_no_credential_or_cloud_fallback_configuration(self) -> None:
        text = (ROOT / "README.md").read_text(encoding="utf-8").lower()
        for forbidden in ("openai_api_key=", "nous_api_key=", "nous portal", "tool gateway"):
            self.assertNotIn(forbidden, text)
        for required in ("portal setup", "oauth", "out of\nscope"):
            self.assertIn(required, text)

    def test_precheck_evidence_requires_explicit_policy_decision(self) -> None:
        report = json.loads((ROOT / "precheck-basic-memory.json").read_text(encoding="utf-8"))
        self.assertEqual("connect-with-rule", report["verdict"]["suggested"])
        self.assertEqual(
            ["delete_note", "delete_project"], report["verdict"]["flaggedTools"]
        )
        self.assertTrue(report["verdict"]["attention"])


if __name__ == "__main__":
    unittest.main()
