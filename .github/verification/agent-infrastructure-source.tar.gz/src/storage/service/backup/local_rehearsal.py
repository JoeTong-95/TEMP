"""One-action, local-only online export/queue/restore rehearsal; run as WSL root."""
from __future__ import annotations
import hashlib,json,os,shutil,sqlite3,subprocess,sys,uuid
from datetime import datetime,timezone
from pathlib import Path
from backup_queue import copy_plan,plan
ROOT=Path('/srv/agent-stack'); STATE=ROOT/'state/backup'
EXCLUDE=('.env','token','secret','cache','log','raw','weights')
def stamp():return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(uuid.uuid4())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def run(*a,**kw):return subprocess.run(a,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,**kw)
def runb(*a):return subprocess.run(a,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
def pg_snapshot_query(db,snapshot,sql):
 safe=snapshot.replace("'","''")
 return run('runuser','-u','postgres','--','psql','-h','/var/run/postgresql','-p','15432','-d',db,'-At','-F','\t','-q','-c',"begin isolation level repeatable read; set transaction snapshot '"+safe+"'; "+sql+"; commit").stdout.splitlines()
def snapshot_dump(db,out):
 """Keep the export owner open while pg_dump and count queries use its exact snapshot."""
 owner=subprocess.Popen(['runuser','-u','postgres','--','psql','-h','/var/run/postgresql','-p','15432','-d',db,'-Atq'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  owner.stdin.write('begin isolation level repeatable read; select pg_export_snapshot();\n');owner.stdin.flush();snapshot=owner.stdout.readline().strip()
  if not snapshot: raise RuntimeError('could not export PostgreSQL snapshot')
  names=pg_snapshot_query(db,snapshot,"select n.nspname,c.relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.relkind='r' and n.nspname not in ('pg_catalog','information_schema') order by 1,2")
  counts={}
  for row in names:
   schema,table=row.split('\t',1);q=lambda x:'"'+x.replace('"','""')+'"'
   counts[schema+'.'+table]=int(pg_snapshot_query(db,snapshot,'select count(*) from '+q(schema)+'.'+q(table))[0])
  out.write_bytes(runb('runuser','-u','postgres','--','pg_dump','-h','/var/run/postgresql','-p','15432','-Fc','--no-owner','--no-privileges','--snapshot='+snapshot,db))
  return counts
 finally:
  if owner.stdin: owner.stdin.write('rollback;\\q\n');owner.stdin.close()
  owner.wait(timeout=20)
def sqlite_backup(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 with sqlite3.connect(src) as a,sqlite3.connect(dst) as b:a.backup(b)
 with sqlite3.connect(dst) as b:
  if b.execute('pragma integrity_check').fetchone()[0]!='ok':raise RuntimeError('sqlite integrity failed')
def add(unit,src,rel):
 dst=unit/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def main():
 if os.geteuid()!=0:raise SystemExit('run as WSL root; no sudo/ownership changes are performed')
 ident=stamp(); work=STATE/'local-rehearsals'/ident; stage=work/'stage'; target=work/'target'; restore=work/'restore';unit=stage/'v1-online'
 unit.mkdir(parents=True); files=[]; catalog={}
 # Native online SQLite backups only; no WAL/SHM file copies and no service pause.
 sqlite_sources={'pilot-control':'state/pilot/pilot-control.sqlite3','pilot-fixture':'state/pilot/fixture/fixture-receipts.sqlite3','bridge':'state/prefect/bridge-journal.sqlite3','canary':'state/prefect/neutral-fixture/platform-canary-a/fixture-receipts.sqlite3','memory':'state/memory/basic-memory/memory.db','hermes-a':'state/hermes-a/pilot-receipts.sqlite3','hermes-b':'state/hermes-b/pilot-receipts.sqlite3'}
 for name,rel in sqlite_sources.items():
  src=ROOT/rel
  if src.is_file():
   out=unit/'sqlite'/(name+'.sqlite3');sqlite_backup(src,out)
   with sqlite3.connect(out) as db:catalog['sqlite:'+name]={'tables':sorted(x[0] for x in db.execute("select name from sqlite_master where type='table'"))}
 # PostgreSQL online consistent custom dumps and role definitions without role passwords.
 dbs=run('runuser','-u','postgres','--','psql','-p','15432','-Atqc',"select datname from pg_database where datistemplate=false order by 1").stdout.splitlines()
 (unit/'postgres').mkdir();(unit/'postgres/roles.sql').write_bytes(runb('runuser','-u','postgres','--','pg_dumpall','-p','15432','--roles-only','--no-role-passwords'))
 for db in dbs:
  out=unit/'postgres'/(db+'.dump');catalog['postgres:'+db]={'row_counts':snapshot_dump(db,out)}
 # Source/config are hashes only; raw env/auth/model/cache/log material is never copied.
 hashed=[]
 for p in sorted((ROOT/'source/agent-infrastructure').rglob('*')):
  if p.is_file() and not any(x in p.name.lower() for x in EXCLUDE):hashed.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p)})
 (unit/'metadata').mkdir();(unit/'metadata/catalog.json').write_text(json.dumps(catalog,sort_keys=True));(unit/'metadata/source-hashes.json').write_text(json.dumps(hashed,sort_keys=True));
 for p in sorted(unit.rglob('*')):
  if p.is_file():files.append({'path':str(p.relative_to(unit)),'bytes':p.stat().st_size,'sha256':sha(p)})
 manifest={'schema':'agent-stack.backup-queue.v1','status':'immutable','unit_id':'v1-online','importance':100,'irreplaceability':100,'created_utc':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'files':files};(unit/'manifest.json').write_text(json.dumps(manifest,sort_keys=True))
 total=sum(x['bytes'] for x in files)+len((unit/'manifest.json').read_bytes())+4096; target.mkdir();p=plan(stage,work/'queue-state',total+1048576,1048576);copy_plan(stage,target,work/'queue-state',p)
 final=next((target/'units'/'v1-online').iterdir());shutil.copytree(final,restore/'unit',dirs_exist_ok=False)
 # Restore validation is isolated: SQLite open/integrity and pg_restore catalog listing; no live replacement.
 for p in (restore/'unit/sqlite').glob('*.sqlite3'):
  with sqlite3.connect(p) as db:
   if db.execute('pragma integrity_check').fetchone()[0]!='ok':raise RuntimeError('restored sqlite corrupt')
 for p in (restore/'unit/postgres').glob('*.dump'):run('pg_restore','--list',str(p))
 evidence={'schema':'agent-stack.local-backup-rehearsal.v1','id':ident,'passed':True,'unit_manifest_sha256':sha(restore/'unit/manifest.json'),'target':str(target),'restore_root':str(restore),'limitations':['PostgreSQL dumps were catalog-validated with pg_restore --list only; no temporary PostgreSQL server/data-count restore was started.','No encryption, FNOS/offsite transfer, reboot, retention/prune, or live-service quiesce was tested.']}
 (work/'evidence.json').write_text(json.dumps(evidence,sort_keys=True)+'\n');print(json.dumps(evidence,sort_keys=True))
if __name__=='__main__':main()
