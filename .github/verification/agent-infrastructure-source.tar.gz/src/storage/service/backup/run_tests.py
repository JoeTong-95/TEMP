"""Run disconnected queue tests and emit a redacted machine-readable report."""
import json,os,sys,unittest,uuid
from datetime import datetime,timezone
from pathlib import Path
suite=unittest.defaultTestLoader.loadTestsFromName('test_backup_queue')
result=unittest.TextTestRunner(verbosity=2).run(suite)
report={'schema':'agent-stack.backup-test-report.v1','created_utc':datetime.now(timezone.utc).isoformat(),'passed':result.wasSuccessful(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'scope':'synthetic disconnected source-to-local-target only'}
report_dir=Path(os.environ.get('AGENT_STACK_BACKUP_REPORT_DIR','/srv/agent-stack/state/backup/test-reports'))
out=report_dir/('queue-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(uuid.uuid4())+'.json');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,sort_keys=True)+'\n');print(json.dumps(report));sys.exit(not result.wasSuccessful())
