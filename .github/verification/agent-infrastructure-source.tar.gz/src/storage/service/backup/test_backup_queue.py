import hashlib,json,tempfile,unittest
from pathlib import Path
from backup_queue import BackupError,InterruptedCopy,copy_plan,digest,plan
def make(root,name,data,importance=1,path='payload.bin'):
 d=root/name;d.mkdir();p=d/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 (d/'manifest.json').write_text(json.dumps({'schema':'agent-stack.backup-queue.v1','status':'immutable','unit_id':name,'importance':importance,'irreplaceability':importance,'created_utc':'2026-01-01T00:00:00Z','files':[{'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}]}))
class TestQueue(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.r=Path(self.t.name);self.s=self.r/'stage';self.d=self.r/'destination';self.q=self.r/'state';self.s.mkdir();self.d.mkdir()
 def tearDown(self):self.t.cleanup()
 def test_interrupt_resume_full_restore_manifest_and_replay(self):
  make(self.s,'alpha',b'a'*2000000,3);p=plan(self.s,self.q,3000000,0)
  with self.assertRaises(InterruptedCopy):copy_plan(self.s,self.d,self.q,p,1000000)
  self.assertTrue(list((self.d/'partials').rglob('*.part')))
  self.assertEqual(copy_plan(self.s,self.d,self.q,p)['outcomes'][0]['outcome'],'copied_verified')
  final=next((self.d/'units'/'alpha').iterdir());self.assertTrue((final/'manifest.json').is_file());self.assertEqual(digest(final/'manifest.json'),p['selected'][0]['manifest_sha256'])
  self.assertEqual(copy_plan(self.s,self.d,self.q,p)['outcomes'][0]['outcome'],'unchanged_replay')
  (final/'payload.bin').write_bytes(b'broken')
  with self.assertRaises(BackupError):copy_plan(self.s,self.d,self.q,p)
 def test_capacity_metadata_and_source_or_plan_mutation(self):
  make(self.s,'high',b'a'*20,9);make(self.s,'low',b'b'*20,1);p=plan(self.s,self.q,5000,0);self.assertEqual(p['selected'][0]['unit_id'],'high');self.assertGreater(p['selected'][0]['bytes'],20)
  bad=dict(p);bad['selected']=[]
  with self.assertRaises(BackupError):copy_plan(self.s,self.d,self.q,bad)
  (self.s/'high'/'payload.bin').write_bytes(b'bad')
  with self.assertRaises(BackupError):copy_plan(self.s,self.d,self.q,p)
 def test_root_nested_source_and_destination_links_are_rejected(self):
  make(self.s,'good',b'x')
  link=self.r/'source-link';link.symlink_to(self.s,target_is_directory=True)
  with self.assertRaises(BackupError):plan(link,self.q,9999,0)
  nested=self.s/'good'/'nested';nested.symlink_to(self.r,target_is_directory=True)
  self.assertEqual(plan(self.s,self.q,9999,0)['selected'],[])
  nested.unlink();p=plan(self.s,self.q,9999,0)
  (self.d/'units').symlink_to(self.r,target_is_directory=True)
  with self.assertRaises(BackupError):copy_plan(self.s,self.d,self.q,p)
 def test_reserved_and_unlisted_payloads_are_rejected(self):
  make(self.s,'badmanifest',b'x',path='manifest.json')
  make(self.s,'extra',b'x');(self.s/'extra'/'unlisted.txt').write_text('x')
  make(self.s,'reserved',b'x',path='nested/complete.json')
  p=plan(self.s,self.q,99999,0);self.assertEqual(p['selected'],[])
 def test_corrupt_partial_and_unverified_final_are_never_promoted(self):
  make(self.s,'alpha',b'a'*100);p=plan(self.s,self.q,99999,0);pid=p['plan_id'];partial=self.d/'partials'/pid/'alpha';partial.mkdir(parents=True);(partial/'payload.bin.part').write_bytes(b'wrong')
  with self.assertRaises(BackupError):copy_plan(self.s,self.d,self.q,p)
  (partial/'payload.bin.part').unlink();final=self.d/'units'/'alpha'/p['selected'][0]['manifest_sha256'];final.mkdir(parents=True)
  with self.assertRaises(BackupError):copy_plan(self.s,self.d,self.q,p)
if __name__=='__main__':unittest.main()
