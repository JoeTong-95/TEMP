"""Restore an existing local rehearsal's PostgreSQL dumps into a socket-only temp cluster."""
from __future__ import annotations
import json,os,shutil,subprocess,sys
from pathlib import Path

PORT='25432'
def run(*args, text=True):
 result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=text)
 if result.returncode: raise RuntimeError('command failed: '+str(result.stderr).strip())
 return result
def pguser(*args, text=True): return run('runuser','-u','postgres','--',*args,text=text)
def qident(value): return '"'+value.replace('"','""')+'"'
def tables(host,port,database):
 out=pguser('psql','-h',host,'-p',port,'-d',database,'-At','-F','\t','-c',"select n.nspname,c.relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.relkind='r' and n.nspname not in ('pg_catalog','information_schema') order by 1,2").stdout.splitlines()
 return [tuple(row.split('\t',1)) for row in out if '\t' in row]
def counts(host,port,database):
 return {schema+'.'+table:int(pguser('psql','-h',host,'-p',port,'-d',database,'-Atqc','select count(*) from '+qident(schema)+'.'+qident(table)).stdout.strip()) for schema,table in tables(host,port,database)}
def main(rehearsal):
 if os.geteuid()!=0: raise SystemExit('run as WSL root')
 import pwd,grp
 root=Path(rehearsal).resolve(); evidence=json.loads((root/'evidence.json').read_text()); dumps=root/'restore/unit/postgres'
 if not evidence.get('passed') or not dumps.is_dir(): raise SystemExit('requires a successful local_rehearsal snapshot')
 temp=root/'postgres-row-proof'; data=temp/'data'; sock=Path('/tmp')/('aspg-'+evidence['id'].split('-',1)[1]); temp.mkdir(); os.chown(temp,pwd.getpwnam('postgres').pw_uid,grp.getgrnam('postgres').gr_gid)
 # os.getpwnam/getgrnam live in pwd/grp, intentionally keep this cluster private to postgres.
 os.mkdir(data);os.mkdir(sock)
 uid,gid=pwd.getpwnam('postgres').pw_uid,grp.getgrnam('postgres').gr_gid
 for p in (data,sock):os.chown(p,uid,gid)
 bindir=run('pg_config','--bindir').stdout.strip(); initdb=bindir+'/initdb'; ctl=bindir+'/pg_ctl'
 catalog=json.loads((root/'restore/unit/metadata/catalog.json').read_text()); result={'schema':'agent-stack.postgres-row-rehearsal.v1','snapshot_id':evidence['id'],'passed':False,'socket_only':True,'databases':{}}
 started=False
 try:
  pguser(initdb,'-D',str(data),'--auth-local=trust','--auth-host=reject')
  pguser(ctl,'-D',str(data),'-l',str(temp/'postgres.log'),'-o',"-k "+str(sock)+" -p "+PORT+" -c listen_addresses=''",'-w','start');started=True
  roles=dumps/'roles.sql'
  # A fresh initdb already owns postgres; continue past that expected duplicate only.
  if roles.is_file(): pguser('psql','-h',str(sock),'-p',PORT,'-d','postgres','-v','ON_ERROR_STOP=0','-f',str(roles))
  for dump in sorted(dumps.glob('*.dump')):
   db=dump.stem
   if db!='postgres': pguser('createdb','-h',str(sock),'-p',PORT,db)
   pguser('pg_restore','-h',str(sock),'-p',PORT,'-d',db,'--exit-on-error',str(dump))
   before=catalog['postgres:'+db]['row_counts']; after=counts(str(sock),PORT,db)
   if before!=after:
    result['databases'][db]={'bound_snapshot_row_counts':before,'restored_row_counts':after}
    raise RuntimeError('schema/table row-count mismatch for '+db)
   result['databases'][db]={'tables':len(before),'bound_snapshot_row_counts':before}
  result['passed']=True
 finally:
  if started: pguser(ctl,'-D',str(data),'-m','fast','-w','stop')
  # Evidence is written outside this exact disposable cluster; preserve it even on failure.
  (root/'postgres-row-counts.json').write_text(json.dumps(result,sort_keys=True)+'\n')
  if result['passed']:
   shutil.rmtree(temp); shutil.rmtree(sock)
 print(json.dumps(result,sort_keys=True))
 if not result['passed']: raise SystemExit(1)
if __name__=='__main__': main(sys.argv[1])
