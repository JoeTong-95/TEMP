"""Disconnected whole-unit cold-backup queue; no network, pruning, or credentials."""
from __future__ import annotations
import hashlib,json,os,re,stat,tempfile
from contextlib import contextmanager
from datetime import datetime,timezone
from pathlib import Path
SCHEMA='agent-stack.backup-queue.v1'; SAFE=re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$')
RESERVED={'manifest.json','complete.json'}; MARKER_RESERVE_BYTES=4096
class BackupError(RuntimeError): pass
class InterruptedCopy(BackupError): pass
def now(): return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(p,limit=None):
 h=hashlib.sha256(); left=limit
 with p.open('rb') as f:
  while True:
   b=f.read(min(1048576,left) if left is not None else 1048576)
   if not b: break
   h.update(b)
   if left is not None:
    left-=len(b)
    if not left: break
 return h.hexdigest()
def _abs(p): return Path(os.path.abspath(os.fspath(p)))
def _dir(p,create=False):
 """Reject links before resolution; every path component is a real directory."""
 p=_abs(p); cur=Path(p.anchor)
 for part in p.parts[1:]:
  cur/=part
  try: mode=os.lstat(cur).st_mode
  except FileNotFoundError:
   if not create: raise BackupError('missing safe directory')
   cur.mkdir(); mode=os.lstat(cur).st_mode
  if stat.S_ISLNK(mode) or not stat.S_ISDIR(mode): raise BackupError('unsafe directory path')
 return p
def root(p,create=False): return _dir(p,create)
def _rel(base,rel):
 if not isinstance(rel,str) or not rel or Path(rel).is_absolute() or '..' in Path(rel).parts: raise BackupError('unsafe relative path')
 cur=base
 for part in Path(rel).parts:
  if part in ('','.','manifest.json','complete.json') or part.endswith('.part'): raise BackupError('reserved payload path')
  cur/=part
  if cur.exists() and stat.S_ISLNK(os.lstat(cur).st_mode): raise BackupError('symlink path')
 return cur
def _atomic(p,v):
 _dir(p.parent,True); fd,tmp=tempfile.mkstemp(dir=p.parent,prefix='.new-')
 try:
  with os.fdopen(fd,'wb') as f: f.write(canon(v));f.flush();os.fsync(f.fileno())
  os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
@contextmanager
def _lock(state,name):
 import fcntl
 d=_dir(state/'locks',True); p=d/(name+'.lock')
 if p.exists() and p.is_symlink(): raise BackupError('unsafe lock')
 with p.open('a+') as f:
  fcntl.flock(f,fcntl.LOCK_EX)
  try:yield
  finally:fcntl.flock(f,fcntl.LOCK_UN)
def _files(base):
 out=set()
 def walk(d,prefix):
  with os.scandir(d) as it:
   for e in it:
    r=(prefix/e.name).as_posix()
    if e.is_symlink():raise BackupError('symlink in unit')
    if e.is_dir(follow_symlinks=False):walk(Path(e.path),prefix/e.name)
    elif e.is_file(follow_symlinks=False):out.add(r)
    else:raise BackupError('non-regular entry in unit')
 walk(base,Path(''));return out
def unit(source,name):
 if not isinstance(name,str) or not SAFE.fullmatch(name):raise BackupError('invalid unit id')
 d=_rel(source,name);m=d/'manifest.json'
 if not d.is_dir() or d.is_symlink() or not m.is_file() or m.is_symlink():raise BackupError('unsafe unit')
 try:x=json.loads(m.read_text())
 except Exception as e:raise BackupError('invalid manifest') from e
 if x.get('schema')!=SCHEMA or x.get('status')!='immutable' or x.get('unit_id')!=name or not isinstance(x.get('files'),list):raise BackupError('unit not immutable')
 total=0;seen=set()
 for q in x['files']:
  if not isinstance(q,dict) or set(q)!={'path','bytes','sha256'}:raise BackupError('bad payload')
  rel=q['path'];f=_rel(d,rel)
  if (not isinstance(q.get('bytes'),int) or q['bytes']<0 or not isinstance(q.get('sha256'),str) or not re.fullmatch('[0-9a-f]{64}',q['sha256']) or rel in seen or not f.is_file() or f.is_symlink() or f.stat().st_size!=q['bytes'] or digest(f)!=q['sha256']):raise BackupError('source mutation or unsafe payload')
  seen.add(rel);total+=q['bytes']
 if _files(d)!=seen|{'manifest.json'}:raise BackupError('unlisted payload file')
 return d,x,digest(m),total,m.stat().st_size
def _bare(p):return {k:v for k,v in p.items() if k not in {'plan_id','plan_sha256'}}
def _check_plan(p):
 if not isinstance(p,dict) or p.get('schema')!=SCHEMA or p.get('kind')!='plan' or not isinstance(p.get('selected'),list):raise BackupError('invalid plan')
 b=_bare(p);pid=hashlib.sha256(canon(b)).hexdigest()[:24]
 if p.get('plan_id')!=pid or p.get('plan_sha256')!=hashlib.sha256(canon({**b,'plan_id':pid})).hexdigest():raise BackupError('plan identity mismatch')
 return pid
def plan(source,state,capacity,reserve):
 source=root(source);state=root(state,True)
 if not isinstance(capacity,int) or not isinstance(reserve,int) or reserve<0 or capacity<reserve:raise BackupError('invalid capacity')
 with _lock(state,'planner'):
  good=[];omit=[]
  for z in sorted(source.iterdir(),key=lambda q:q.name):
   if z.is_symlink():omit.append({'unit_id':z.name,'reason':'unsafe unit'});continue
   try:good.append(unit(source,z.name))
   except BackupError as e:omit.append({'unit_id':z.name,'reason':str(e)})
  good.sort(key=lambda z:(-int(z[1].get('importance',0)),-int(z[1].get('irreplaceability',0)),-int(re.sub(r'\D','',str(z[1].get('created_utc','0')))or 0),z[0].name));left=capacity-reserve;sel=[]
  for d,m,h,n,mb in good:
   need=n+mb+MARKER_RESERVE_BYTES;e={'unit_id':d.name,'manifest_sha256':h,'payload_bytes':n,'manifest_bytes':mb,'bytes':need}
   if need<=left:e['reason']='selected_whole_restorable_unit';sel.append(e);left-=need
   else:omit.append({'unit_id':d.name,'bytes':need,'reason':'capacity_or_reserve'})
  r={'schema':SCHEMA,'kind':'plan','created_utc':now(),'capacity_bytes':capacity,'reserve_bytes':reserve,'selected':sel,'omitted':omit,'used_bytes':capacity-reserve-left};r['plan_id']=hashlib.sha256(canon(r)).hexdigest()[:24];r['plan_sha256']=hashlib.sha256(canon(r)).hexdigest();_atomic(state/'plans'/(r['plan_id']+'.json'),r);return r
def _stored(state,p):
 pid=_check_plan(p);f=state/'plans'/(pid+'.json')
 if not f.is_file() or f.is_symlink():raise BackupError('persisted plan missing')
 try:s=json.loads(f.read_text())
 except Exception as e:raise BackupError('persisted plan corrupt') from e
 if canon(s)!=canon(p) or _check_plan(s)!=pid:raise BackupError('supplied plan does not match persisted plan')
 return pid,s
def _copy(s,part,size,w):
 off=part.stat().st_size if part.exists() else 0
 if off>size or(off and digest(s,off)!=digest(part)):raise BackupError('partial corruption')
 with s.open('rb') as a,part.open('ab') as b:
  a.seek(off)
  while block:=a.read(1048576):
   b.write(block);w[0]+=len(block)
   if w[1] is not None and w[0]>=w[1]:b.flush();os.fsync(b.fileno());raise InterruptedCopy('test interruption')
  b.flush();os.fsync(b.fileno())
def _verify_final(d,m,h,plan_sha=None):
 mark=d/'complete.json';manifest=d/'manifest.json'
 if d.is_symlink() or not d.is_dir() or not mark.is_file() or mark.is_symlink() or not manifest.is_file() or manifest.is_symlink() or digest(manifest)!=h:raise BackupError('destination corruption')
 try:x=json.loads(mark.read_text())
 except Exception as e:raise BackupError('destination corruption') from e
 if x.get('schema')!=SCHEMA or x.get('manifest_sha256')!=h or (plan_sha is not None and x.get('plan_sha256')!=plan_sha):raise BackupError('destination corruption')
 for q in m['files']:
  z=_rel(d,q['path'])
  if not z.is_file() or z.stat().st_size!=q['bytes'] or digest(z)!=q['sha256']:raise BackupError('destination corruption')
 if _files(d)!={q['path'] for q in m['files']}|{'manifest.json','complete.json'}:raise BackupError('destination corruption')
def copy_plan(source,target,state,p,interrupt_after=None):
 source=root(source);target=root(target,True);state=root(state,True)
 if source==target:raise BackupError('target equals source')
 with _lock(state,'copy'):
  pid,p=_stored(state,p);out=[];w=[0,interrupt_after]
  for e in p['selected']:
   if set(e)!={'unit_id','manifest_sha256','payload_bytes','manifest_bytes','bytes','reason'}:raise BackupError('invalid plan entry')
   d,m,h,n,mb=unit(source,e['unit_id'])
   if h!=e['manifest_sha256'] or n!=e['payload_bytes'] or mb!=e['manifest_bytes'] or e['bytes']!=n+mb+MARKER_RESERVE_BYTES:raise BackupError('source changed since planning')
   final=target/'units'/d.name/h;_dir(final.parent,True)
   if final.exists():_verify_final(final,m,h,p['plan_sha256']);out.append({'unit_id':d.name,'outcome':'unchanged_replay'});continue
   partial=target/'partials'/pid/d.name;_dir(partial,True)
   bind=target/'partials'/pid/'.bindings'/(d.name+'.json');binding={'schema':SCHEMA,'plan_id':pid,'plan_sha256':p['plan_sha256'],'unit_id':d.name,'manifest_sha256':h}
   _dir(bind.parent,True)
   if bind.exists():
    if bind.is_symlink():raise BackupError('unsafe partial binding')
    try:old=json.loads(bind.read_text())
    except Exception as x:raise BackupError('partial binding corrupt') from x
    if old!=binding:raise BackupError('partial belongs to another plan')
   else:
    if _files(partial):raise BackupError('unbound partial corruption')
    _atomic(bind,binding)
   mp=partial/'manifest.json.part';_copy(d/'manifest.json',mp,mb,w)
   if mp.stat().st_size!=mb or digest(mp)!=h:raise BackupError('manifest copy verification failed')
   os.replace(mp,partial/'manifest.json')
   for q in m['files']:
    s=_rel(d,q['path']);z=_rel(partial,q['path']);_dir(z.parent,True);part=Path(str(z)+'.part')
    if part.exists() and part.is_symlink():raise BackupError('unsafe partial path')
    _copy(s,part,q['bytes'],w)
    if part.stat().st_size!=q['bytes'] or digest(part)!=q['sha256']:raise BackupError('verification failed')
    os.replace(part,z)
   _,_,h2,n2,mb2=unit(source,d.name)
   if (h2,n2,mb2)!=(h,n,mb):raise BackupError('source changed during copy')
   _atomic(partial/'complete.json',{'schema':SCHEMA,'unit_id':d.name,'manifest_sha256':h,'plan_sha256':p['plan_sha256'],'completed_utc':now()});_verify_final(partial,m,h,p['plan_sha256'])
   if final.exists():raise BackupError('unverified destination final already exists')
   os.replace(partial,final);_verify_final(final,m,h);out.append({'unit_id':d.name,'outcome':'copied_verified'})
  r={'schema':SCHEMA,'kind':'copy','plan_id':pid,'plan_sha256':p['plan_sha256'],'completed_utc':now(),'outcomes':out};_atomic(state/'reports'/(pid+'-'+hashlib.sha256(canon(r)).hexdigest()[:12]+'.json'),r);return r
