"""Storage-owned composition entry point for the Management pilot API."""
from __future__ import annotations

import os
from pathlib import Path

from management.pilot_api import create_app
from storage import create_pilot_3d_artifact_store, create_pilot_audio_artifact_store, create_pilot_video_artifact_store


def build_app():
    state_dir = Path(os.environ.get("PILOT_STATE_DIR", "/srv/agent-stack/state/pilot"))
    audio_store = create_pilot_audio_artifact_store(
        state_dir / "pilot-artifacts.sqlite3",
        legacy_path=state_dir / "pilot-control.sqlite3",
    )
    video_store = create_pilot_video_artifact_store(state_dir / "pilot-video-artifacts.sqlite3")
    three_d_store = create_pilot_3d_artifact_store(state_dir / "pilot-3d-artifacts.sqlite3")
    return create_app(
        state_dir,
        operator_token=os.environ.get("PILOT_OPERATOR_TOKEN"),
        audio_store=audio_store,
        video_store=video_store,
        three_d_store=three_d_store,
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(build_app(), host="127.0.0.1", port=14300)
