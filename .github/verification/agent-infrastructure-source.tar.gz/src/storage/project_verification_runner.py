"""Run one server-defined project verification command in a transient systemd jail.

This is deliberately not a terminal tool.  The only selectable input is a
command identifier from ``_COMMAND_TEMPLATES``; neither a model nor a project
can supply an executable, arguments, environment, or sandbox properties.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
from typing import Callable, Iterable
from uuid import uuid4

from shared.contracts.project_verification import MAX_VERIFICATION_OUTPUT_BYTES


class ProjectVerificationError(ValueError):
    pass


class SandboxUnavailable(ProjectVerificationError):
    """The required isolation primitive could not be started; never fall back."""


_COMMAND_TEMPLATES: dict[str, tuple[str, ...]] = {
    "python-unittest": ("/usr/bin/python3", "-m", "unittest", "discover", "-s", "/project", "-p", "test_*.py"),
}
_MAX_TIMEOUT_SECONDS = 300
_MAX_OUTPUT_BYTES = MAX_VERIFICATION_OUTPUT_BYTES
_MAX_INPUT_BYTES = 64 * 1024 * 1024
_MAX_INPUT_FILES = 10_000
_MAX_INPUT_FILE_BYTES = 16 * 1024 * 1024


def _safe_directory(path: Path, label: str) -> None:
    if not path.is_absolute() or path.is_symlink() or not path.is_dir() or any(parent.is_symlink() for parent in path.parents):
        raise ProjectVerificationError(f"{label} must be an existing absolute non-symlink directory")


def _walk_files(root: Path) -> Iterable[tuple[str, Path]]:
    if root.is_symlink():
        raise ProjectVerificationError("project tree cannot contain symlinks")
    for directory, names, files in os.walk(root, followlinks=False):
        current = Path(directory)
        names.sort(); files.sort()
        if current.is_symlink() or any((current / name).is_symlink() for name in names + files):
            raise ProjectVerificationError("project tree cannot contain symlinks")
        for name in sorted(files):
            path = current / name
            if not path.is_file():
                raise ProjectVerificationError("project tree contains a non-regular file")
            yield path.relative_to(root).as_posix(), path


def input_tree_digest(project_root: str | Path, *, max_input_bytes: int = _MAX_INPUT_BYTES, max_input_files: int = _MAX_INPUT_FILES, max_input_file_bytes: int = _MAX_INPUT_FILE_BYTES) -> str:
    """Hash paths and bytes, so provenance is unambiguous across equal content."""
    root = Path(project_root)
    _safe_directory(root, "project root")
    if any(type(value) is not int or value < 1 for value in (max_input_bytes, max_input_files, max_input_file_bytes)):
        raise ProjectVerificationError("input staging limits are invalid")
    digest = hashlib.sha256()
    total_bytes = file_count = 0
    # Empty directories are part of the staged tree too, not invisible metadata.
    for directory, names, _ in os.walk(root, followlinks=False):
        current = Path(directory)
        names.sort()
        if current.is_symlink() or any((current / name).is_symlink() for name in names):
            raise ProjectVerificationError("project tree cannot contain symlinks")
        if current != root:
            encoded = current.relative_to(root).as_posix().encode("utf-8")
            digest.update(b"D"); digest.update(len(encoded).to_bytes(8, "big")); digest.update(encoded)
    for relative, path in _walk_files(root):
        # Check limits before opening, and recheck through the opened descriptor
        # below on POSIX to avoid following a post-validation substitution.
        before = path.stat()
        size = before.st_size
        file_count += 1; total_bytes += size
        if file_count > max_input_files or size > max_input_file_bytes or total_bytes > max_input_bytes:
            raise ProjectVerificationError("project input exceeds staging limits")
        encoded = relative.encode("utf-8")
        digest.update(b"F"); digest.update(len(encoded).to_bytes(8, "big")); digest.update(encoded)
        digest.update(size.to_bytes(8, "big"))
        if os.name == "posix":
            fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
            try:
                opened = os.fstat(fd)
                if not stat.S_ISREG(opened.st_mode) or (opened.st_dev, opened.st_ino, opened.st_size) != (before.st_dev, before.st_ino, size):
                    raise ProjectVerificationError("project file changed while hashing")
                while chunk := os.read(fd, 1024 * 1024): digest.update(chunk)
            finally: os.close(fd)
        else:
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
    return digest.hexdigest()


def _copy_read_only(source: Path, destination: Path, *, max_input_bytes: int = _MAX_INPUT_BYTES, max_input_files: int = _MAX_INPUT_FILES, max_input_file_bytes: int = _MAX_INPUT_FILE_BYTES) -> None:
    # Verify first on every platform.  Linux then copies from directory FDs so a
    # path substituted after validation cannot redirect a copy outside project.
    list(_walk_files(source))
    if os.name != "posix":
        shutil.copytree(source, destination, dirs_exist_ok=True, ignore_dangling_symlinks=False)
        for directory, names, files in os.walk(destination, topdown=False):
            for name in files: (Path(directory) / name).chmod(0o444)
            Path(directory).chmod(0o555)
        return
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    directory_flag = getattr(os, "O_DIRECTORY", 0)
    copied_bytes = copied_files = 0
    def copy_directory(source_fd: int, target: Path) -> None:
        nonlocal copied_bytes, copied_files
        target.mkdir(mode=0o755, exist_ok=True)
        for name in sorted(os.listdir(source_fd)):
            before = os.stat(name, dir_fd=source_fd, follow_symlinks=False)
            if stat.S_ISLNK(before.st_mode):
                raise ProjectVerificationError("project tree changed to contain a symlink while staging")
            child = target / name
            if stat.S_ISDIR(before.st_mode):
                child_fd = os.open(name, os.O_RDONLY | directory_flag | nofollow, dir_fd=source_fd)
                try:
                    after = os.fstat(child_fd)
                    if (after.st_dev, after.st_ino) != (before.st_dev, before.st_ino):
                        raise ProjectVerificationError("project directory changed while staging")
                    copy_directory(child_fd, child)
                finally:
                    os.close(child_fd)
            elif stat.S_ISREG(before.st_mode):
                copied_files += 1; copied_bytes += before.st_size
                if copied_files > max_input_files or before.st_size > max_input_file_bytes or copied_bytes > max_input_bytes:
                    raise ProjectVerificationError("project input exceeds staging limits")
                file_fd = os.open(name, os.O_RDONLY | nofollow, dir_fd=source_fd)
                try:
                    after = os.fstat(file_fd)
                    if not stat.S_ISREG(after.st_mode) or (after.st_dev, after.st_ino) != (before.st_dev, before.st_ino):
                        raise ProjectVerificationError("project file changed while staging")
                    target_fd = os.open(child, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o444)
                    try:
                        written = 0
                        while chunk := os.read(file_fd, 1024 * 1024):
                            written += len(chunk)
                            if written > before.st_size: raise ProjectVerificationError("project file changed while staging")
                            view = memoryview(chunk)
                            while view: view = view[os.write(target_fd, view):]
                    finally:
                        os.close(target_fd)
                finally:
                    os.close(file_fd)
            else:
                raise ProjectVerificationError("project tree contains a non-regular file")
        target.chmod(0o555)
    root_fd = os.open(source, os.O_RDONLY | directory_flag | nofollow)
    try: copy_directory(root_fd, destination)
    finally: os.close(root_fd)


@dataclass(frozen=True)
class VerificationResult:
    command_id: str
    input_tree_sha256: str
    exit_code: int
    result: str
    output: str
    output_sha256: str


class ProjectVerificationRunner:
    """A fail-closed systemd transient-service verifier for a project tree."""

    def __init__(
        self,
        project_root: str | Path,
        sandbox_parent: str | Path,
        *,
        systemd_run: str | Path = "/usr/bin/systemd-run",
        timeout_seconds: int = 60,
        max_output_bytes: int = _MAX_OUTPUT_BYTES,
        memory_max_bytes: int = 128 * 1024 * 1024,
        tasks_max: int = 64,
        cpu_quota_percent: int = 50,
        max_input_bytes: int = _MAX_INPUT_BYTES,
        max_input_files: int = _MAX_INPUT_FILES,
        max_input_file_bytes: int = _MAX_INPUT_FILE_BYTES,
        runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    ) -> None:
        self.project_root, self.sandbox_parent = Path(project_root), Path(sandbox_parent)
        _safe_directory(self.project_root, "project root"); _safe_directory(self.sandbox_parent, "sandbox parent")
        project_real, sandbox_real = self.project_root.resolve(), self.sandbox_parent.resolve()
        if project_real == sandbox_real or project_real in sandbox_real.parents or sandbox_real in project_real.parents:
            raise ProjectVerificationError("sandbox parent must be disjoint from the project root")
        self.systemd_run = Path(systemd_run)
        if not self.systemd_run.is_absolute() or self.systemd_run.name != "systemd-run":
            raise ProjectVerificationError("systemd-run path is invalid")
        if type(timeout_seconds) is not int or not 1 <= timeout_seconds <= _MAX_TIMEOUT_SECONDS:
            raise ProjectVerificationError("verification timeout is invalid")
        if type(max_output_bytes) is not int or not 1 <= max_output_bytes <= _MAX_OUTPUT_BYTES:
            raise ProjectVerificationError("verification output bound is invalid")
        if type(memory_max_bytes) is not int or not 16 * 1024 * 1024 <= memory_max_bytes <= 1024 * 1024 * 1024 or type(tasks_max) is not int or not 1 <= tasks_max <= 256 or type(cpu_quota_percent) is not int or not 1 <= cpu_quota_percent <= 100:
            raise ProjectVerificationError("verification resource limits are invalid")
        if any(type(value) is not int or value < 1 for value in (max_input_bytes, max_input_files, max_input_file_bytes)):
            raise ProjectVerificationError("input staging limits are invalid")
        self.timeout_seconds, self.max_output_bytes, self.memory_max_bytes, self.tasks_max, self.cpu_quota_percent = timeout_seconds, max_output_bytes, memory_max_bytes, tasks_max, cpu_quota_percent
        self.max_input_bytes, self.max_input_files, self.max_input_file_bytes, self._runner = max_input_bytes, max_input_files, max_input_file_bytes, runner

    def _command(self, command_id: str) -> tuple[str, ...]:
        command = _COMMAND_TEMPLATES.get(command_id)
        if command is None:
            raise ProjectVerificationError("verification command is not approved")
        return command

    def _systemd_command(self, unit: str, rootfs: Path, staged: Path, output: Path, command: tuple[str, ...]) -> list[str]:
        properties = [
            f"RootDirectory={rootfs}",
            f"BindReadOnlyPaths={staged}:/project",
            "BindReadOnlyPaths=/usr:/usr",
            "BindReadOnlyPaths=/lib:/lib",
            "BindReadOnlyPaths=/lib64:/lib64",
            "TemporaryFileSystem=/tmp:mode=1777",
            "DynamicUser=yes", "NoNewPrivileges=yes", "PrivateNetwork=yes", "PrivateDevices=yes",
            "CapabilityBoundingSet=", "AmbientCapabilities=", "ProtectSystem=strict", "ProtectHome=yes",
            "ProtectKernelTunables=yes", "ProtectKernelModules=yes", "ProtectControlGroups=yes",
            "ProtectProc=invisible", "ProcSubset=pid", "RestrictAddressFamilies=AF_UNIX",
            "RestrictNamespaces=yes", "RestrictSUIDSGID=yes", "LockPersonality=yes",
            "MemoryDenyWriteExecute=yes", f"RuntimeMaxSec={self.timeout_seconds}",
            f"MemoryMax={self.memory_max_bytes}", f"TasksMax={self.tasks_max}", f"CPUQuota={self.cpu_quota_percent}%",
            f"LimitFSIZE={self.max_output_bytes}", f"StandardOutput=file:{output}",
            f"StandardError=append:{output}", "UnsetEnvironment=HERMES_MANAGED_API_KEY",
        ]
        args = [str(self.systemd_run), "--wait", "--collect", "--quiet", f"--unit={unit}", "--working-directory=/project", "--setenv=PYTHONDONTWRITEBYTECODE=1", "--setenv=PYTHONNOUSERSITE=1", "--setenv=PYTHONPATH="]
        args.extend(f"--property={property_value}" for property_value in properties)
        return args + list(command)

    def verify(self, command_id: str) -> VerificationResult:
        command = self._command(command_id)
        if not self.systemd_run.is_file() or self.systemd_run.is_symlink():
            raise SandboxUnavailable("systemd-run is unavailable; verification was not run")
        original_digest = input_tree_digest(self.project_root, max_input_bytes=self.max_input_bytes, max_input_files=self.max_input_files, max_input_file_bytes=self.max_input_file_bytes)
        work = Path(tempfile.mkdtemp(prefix="agent-stack-verify-", dir=self.sandbox_parent)); work.chmod(0o755)
        cleanup = True
        try:
            staged, rootfs, output = work / "project", work / "rootfs", work / "output.txt"
            staged.mkdir(mode=0o755); _copy_read_only(self.project_root, staged, max_input_bytes=self.max_input_bytes, max_input_files=self.max_input_files, max_input_file_bytes=self.max_input_file_bytes)
            staged_digest = input_tree_digest(staged, max_input_bytes=self.max_input_bytes, max_input_files=self.max_input_files, max_input_file_bytes=self.max_input_file_bytes)
            if staged_digest != original_digest:
                raise ProjectVerificationError("project changed while verification input was staged")
            for directory in (rootfs / "usr", rootfs / "lib", rootfs / "lib64", rootfs / "project", rootfs / "tmp"):
                directory.mkdir(mode=0o755, parents=True, exist_ok=True)
            output.touch(mode=0o600); output.chmod(0o600)
            unit = f"agent-stack-project-verify-{uuid4().hex}.service"
            try:
                completed = self._runner(self._systemd_command(unit, rootfs, staged, output, command), text=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=self.timeout_seconds + 15, check=False)
            except subprocess.TimeoutExpired as error:
                # The unit name is generated here; stopping it cannot affect any
                # unrelated workload.  Cleanup happens only after this attempt.
                try:
                    self._runner(["/usr/bin/systemctl", "stop", unit], text=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15, check=False)
                    state = self._runner(["/usr/bin/systemctl", "show", "--property=ActiveState", "--value", unit], text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=15, check=False)
                    inactive = (state.stdout or "").strip() in {"inactive", "failed"}
                except (OSError, subprocess.TimeoutExpired): inactive = False
                if not inactive:
                    cleanup = False
                    raise SandboxUnavailable(f"systemd sandbox timeout cleanup is unknown; retained {work}") from error
                raise SandboxUnavailable("systemd sandbox timed out and was stopped; verification was not run") from error
            except OSError as error:
                raise SandboxUnavailable("systemd sandbox did not start; verification was not run") from error
            controller_output = completed.stderr or ""
            with output.open("rb") as handle: raw_output = handle.read(self.max_output_bytes + 1)
            if len(raw_output) > self.max_output_bytes:
                raise SandboxUnavailable("sandbox output exceeded the configured bound")
            if "Failed to start transient service unit" in controller_output or "Interactive authentication required" in controller_output:
                raise SandboxUnavailable("systemd sandbox authorization is unavailable; verification was not run")
            text = raw_output.decode("utf-8", "replace")
            return VerificationResult(command_id, staged_digest, completed.returncode, "passed" if completed.returncode == 0 else "failed", text, hashlib.sha256(raw_output).hexdigest())
        finally:
            if cleanup: shutil.rmtree(work, ignore_errors=True)
