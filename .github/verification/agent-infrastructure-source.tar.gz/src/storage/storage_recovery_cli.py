"""Explicit operator entry point for recovery sets; it never schedules itself."""
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping

from .storage_recovery import RecoveryConfig, RecoveryError, RecoveryService


def load_config(path: str | Path) -> RecoveryConfig:
    path = Path(path)
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise RecoveryError("recovery configuration is unavailable")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise RecoveryError("recovery configuration is invalid") from error
    required = {"local_root", "capacity_bytes", "retention_buckets_seconds", "degraded_rpo_seconds"}
    optional = {"cold_root", "token_file"}
    if not isinstance(raw, Mapping) or set(raw) - (required | optional) or not required.issubset(raw):
        raise RecoveryError("recovery configuration schema is invalid")
    return RecoveryConfig(Path(raw["local_root"]), Path(raw["cold_root"]) if raw.get("cold_root") else None, raw["capacity_bytes"], tuple(raw["retention_buckets_seconds"]), raw["degraded_rpo_seconds"], Path(raw["token_file"]) if raw.get("token_file") else None)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Explicit Storage recovery-set operator command")
    parser.add_argument("--config", required=True)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--cold-plan", metavar="PROJECT_OR_EVIDENCE", help="print a retention or evidence-driven cold plan")
    parser.add_argument("--project-evidence", metavar="EVIDENCE", help="print a read-only cold-selection plan from project-evidence JSON")
    parser.add_argument("--capacity-bytes", type=int, help="override planning capacity")
    parser.add_argument("--now", help="planning time as an ISO-8601 timestamp")
    parser.add_argument("--cold-project")
    parser.add_argument("--cold-set")
    parser.add_argument("--execute", action="store_true", help="perform an explicitly human-authorized cold copy; default is dry-run")
    parser.add_argument("--actor", choices=("human",), default="human")
    arguments = parser.parse_args(argv)

    has_copy_target = bool(arguments.cold_project or arguments.cold_set)
    has_plan = arguments.cold_plan is not None or arguments.project_evidence is not None
    if arguments.check and (has_plan or has_copy_target or arguments.execute):
        parser.error("--check cannot be combined with a cold plan or cold copy options")
    if has_plan and (has_copy_target or arguments.execute):
        parser.error("--cold-plan cannot be combined with cold copy options")
    if arguments.cold_plan is not None and arguments.project_evidence is not None:
        parser.error("--cold-plan and --project-evidence cannot be combined")
    if bool(arguments.cold_project) != bool(arguments.cold_set):
        parser.error("--cold-project and --cold-set are required together")
    if arguments.execute and not has_copy_target:
        parser.error("--execute requires --cold-project and --cold-set")
    if not (arguments.check or has_plan or has_copy_target):
        parser.error("choose --check, --cold-plan, or an explicit cold-copy target")

    config = load_config(arguments.config)
    if arguments.check:
        print("recovery configuration validated; no recovery or cold copy was started")
        return 0
    if has_plan:
        evidence_path = arguments.project_evidence or arguments.cold_plan
        candidate = Path(evidence_path)
        if arguments.project_evidence is not None or candidate.is_absolute() and candidate.is_file():
            if not candidate.is_absolute() or candidate.is_symlink() or not candidate.is_file():
                raise RecoveryError("project evidence is unavailable")
            try:
                evidence = json.loads(candidate.read_text(encoding="utf-8"))
            except (OSError, ValueError) as error:
                raise RecoveryError("project evidence is invalid") from error
            now = None
            if arguments.now:
                try:
                    now = datetime.fromisoformat(arguments.now.replace("Z", "+00:00"))
                except ValueError as error:
                    raise RecoveryError("planning time is invalid") from error
            result = RecoveryService(config).cold_selection_plan(
                evidence, capacity_bytes=arguments.capacity_bytes, now=now,
            )
        else:
            result = RecoveryService(config).retention_plan(arguments.cold_plan)
        print(json.dumps(result, sort_keys=True))
        return 0
    result = RecoveryService(config).run_cold_copy(arguments.cold_project, arguments.cold_set, actor=arguments.actor, explicit=True, dry_run=not arguments.execute)
    print(json.dumps({key: value for key, value in result.items() if key != "token"}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
