"""Storage-owned persistence for the controlled pilot audio capability."""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import secrets
import sqlite3
from typing import Iterator

from shared.contracts.pilot_artifact import AudioJobRequest, StoredAudioArtifact, ThreeDArtifact, ThreeDCapability, ThreeDJobRequest, VideoArtifact, VideoCapability, VideoJobRequest


class PilotAudioArtifactService:
    """Persist audio bytes and their immutable request identity in Storage."""

    _LEGACY_FINGERPRINT_PREFIX = "legacy:"

    def __init__(self, path: str | Path, *, legacy_path: str | Path | None = None):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS pilot_audio_artifacts(
                    job_id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL,
                    request_id TEXT UNIQUE NOT NULL,
                    request_fingerprint TEXT NOT NULL,
                    modality TEXT NOT NULL,
                    format TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    status TEXT NOT NULL,
                    progress INTEGER NOT NULL,
                    artifact_sha256 TEXT NOT NULL,
                    artifact_bytes BLOB NOT NULL,
                    created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
        if legacy_path is not None:
            self._migrate_legacy_audio_jobs(legacy_path)

    @contextmanager
    def _db(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    @staticmethod
    def _fingerprint(request: AudioJobRequest) -> str:
        encoded = json.dumps(asdict(request), sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(encoded).hexdigest()

    @staticmethod
    def _record(row: sqlite3.Row) -> StoredAudioArtifact:
        return StoredAudioArtifact(
            job_id=row["job_id"],
            project_id=row["project_id"],
            request_id=row["request_id"],
            modality=row["modality"],
            format=row["format"],
            mode=row["mode"],
            status=row["status"],
            progress=row["progress"],
            artifact_sha256=row["artifact_sha256"],
        )

    @staticmethod
    def _checked_bytes(row: sqlite3.Row) -> tuple[bytes, str]:
        try:
            content = bytes(row["artifact_bytes"])
        except (TypeError, ValueError) as exc:
            raise ValueError("audio artifact integrity check failed") from exc
        digest = hashlib.sha256(content).hexdigest()
        if digest != row["artifact_sha256"]:
            raise ValueError("audio artifact integrity check failed")
        return content, digest

    @classmethod
    def _legacy_fingerprint(cls, artifact_sha256: str) -> str:
        return f"{cls._LEGACY_FINGERPRINT_PREFIX}{artifact_sha256}"

    @staticmethod
    def _legacy_row(row: sqlite3.Row) -> dict[str, object]:
        try:
            content = bytes(row["artifact_bytes"])
            artifact_sha256 = row["artifact_hash"]
        except (IndexError, KeyError, TypeError, ValueError) as exc:
            raise ValueError("legacy audio artifact record is invalid") from exc
        if not isinstance(artifact_sha256, str) or hashlib.sha256(content).hexdigest() != artifact_sha256:
            raise ValueError("legacy audio artifact integrity check failed")
        return {
            "job_id": row["job_id"],
            "project_id": row["project_id"],
            "request_id": row["request_id"],
            "modality": row["modality"],
            "format": row["format"],
            "mode": row["mode"],
            "status": row["status"],
            "progress": row["progress"],
            "artifact_sha256": artifact_sha256,
            "artifact_bytes": content,
            "created": row["created"] if "created" in row.keys() else None,
        }

    def _migrate_legacy_audio_jobs(self, legacy_path: str | Path) -> None:
        legacy = Path(legacy_path)
        if not legacy.exists() or legacy.resolve() == Path(self.path).resolve():
            return

        source = sqlite3.connect(str(legacy))
        source.row_factory = sqlite3.Row
        try:
            table = source.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='pilot_audio_jobs'"
            ).fetchone()
            if not table:
                return
            rows = source.execute("SELECT * FROM pilot_audio_jobs").fetchall()
            records = [self._legacy_row(row) for row in rows]
        finally:
            source.close()

        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            for record in records:
                by_job = connection.execute(
                    "SELECT * FROM pilot_audio_artifacts WHERE job_id=?",
                    (record["job_id"],),
                ).fetchone()
                by_request = connection.execute(
                    "SELECT * FROM pilot_audio_artifacts WHERE request_id=?",
                    (record["request_id"],),
                ).fetchone()
                existing = by_job or by_request
                if existing:
                    same_record = (
                        by_job is not None
                        and by_request is not None
                        and by_job["job_id"] == by_request["job_id"]
                        and all(
                            existing[field] == record[field]
                            for field in (
                                "project_id",
                                "request_id",
                                "modality",
                                "format",
                                "mode",
                                "status",
                                "progress",
                                "artifact_sha256",
                            )
                        )
                        and bytes(existing["artifact_bytes"]) == record["artifact_bytes"]
                    )
                    if not same_record:
                        raise ValueError("legacy audio artifact conflicts with Storage record")
                    self._checked_bytes(existing)
                    continue

                columns = (
                    "job_id, project_id, request_id, request_fingerprint, modality, "
                    "format, mode, status, progress, artifact_sha256, artifact_bytes"
                )
                values: tuple[object, ...] = (
                    record["job_id"],
                    record["project_id"],
                    record["request_id"],
                    self._legacy_fingerprint(record["artifact_sha256"]),
                    record["modality"],
                    record["format"],
                    record["mode"],
                    record["status"],
                    record["progress"],
                    record["artifact_sha256"],
                    sqlite3.Binary(record["artifact_bytes"]),
                )
                if record["created"] is not None:
                    columns += ", created"
                    values += (record["created"],)
                placeholders = ",".join("?" for _ in values)
                connection.execute(
                    f"INSERT INTO pilot_audio_artifacts({columns}) VALUES({placeholders})",
                    values,
                )

    def store_audio(self, request: AudioJobRequest, content: bytes) -> StoredAudioArtifact:
        if not isinstance(request, AudioJobRequest) or not isinstance(content, bytes) or not content:
            raise ValueError("audio artifact payload is invalid")
        fingerprint = self._fingerprint(request)
        digest = hashlib.sha256(content).hexdigest()
        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT * FROM pilot_audio_artifacts WHERE request_id=?",
                (request.request_id,),
            ).fetchone()
            if existing:
                if (
                    existing["project_id"] != request.project_id
                    or existing["request_fingerprint"] != fingerprint
                    or existing["artifact_sha256"] != digest
                ):
                    if (
                        existing["project_id"] != request.project_id
                        or existing["artifact_sha256"] != digest
                        or existing["request_fingerprint"] != self._legacy_fingerprint(existing["artifact_sha256"])
                        or existing["modality"] != request.modality
                        or existing["format"] != request.format
                        or existing["mode"] != request.mode
                    ):
                        raise ValueError("request id conflicts with immutable audio artifact")
                self._checked_bytes(existing)
                return self._record(existing)
            job_id = secrets.token_urlsafe(18)
            connection.execute(
                """
                INSERT INTO pilot_audio_artifacts(
                    job_id, project_id, request_id, request_fingerprint,
                    modality, format, mode, status, progress,
                    artifact_sha256, artifact_bytes
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    job_id,
                    request.project_id,
                    request.request_id,
                    fingerprint,
                    request.modality,
                    request.format,
                    request.mode,
                    "completed",
                    100,
                    digest,
                    sqlite3.Binary(content),
                ),
            )
            return self._record(
                connection.execute(
                    "SELECT * FROM pilot_audio_artifacts WHERE job_id=?", (job_id,)
                ).fetchone()
            )

    def _scoped(self, job_id: str, project_id: str) -> sqlite3.Row:
        with self._db() as connection:
            row = connection.execute(
                "SELECT * FROM pilot_audio_artifacts WHERE job_id=?", (job_id,)
            ).fetchone()
        if not row:
            raise KeyError("unknown audio artifact")
        if row["project_id"] != project_id:
            raise PermissionError("audio artifact is outside this project scope")
        return row

    def audio_job(self, job_id: str, project_id: str) -> StoredAudioArtifact:
        return self._record(self._scoped(job_id, project_id))

    def read_audio(self, project_id: str, job_id: str) -> tuple[bytes, str]:
        return self._checked_bytes(self._scoped(job_id, project_id))


__all__ = ("PilotAudioArtifactService",)


class PilotVideoArtifactService:
    """Persist one declared asynchronous video operation and its scoped result."""

    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as connection:
            connection.execute("""CREATE TABLE IF NOT EXISTS pilot_video_artifacts(
                job_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, request_id TEXT UNIQUE NOT NULL,
                request_fingerprint TEXT NOT NULL, modality TEXT NOT NULL, format TEXT NOT NULL,
                mode TEXT NOT NULL, status TEXT NOT NULL, progress INTEGER NOT NULL,
                artifact_sha256 TEXT NOT NULL, artifact_bytes BLOB NOT NULL,
                created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
            columns = {row[1] for row in connection.execute("PRAGMA table_info(pilot_video_artifacts)")}
            if "lifecycle" not in columns:
                connection.execute("ALTER TABLE pilot_video_artifacts ADD COLUMN lifecycle TEXT NOT NULL DEFAULT 'asynchronous'")
            if "statuses" not in columns:
                connection.execute("ALTER TABLE pilot_video_artifacts ADD COLUMN statuses TEXT NOT NULL DEFAULT '[\"queued\",\"running\",\"completed\"]'")

    @contextmanager
    def _db(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    @staticmethod
    def _fingerprint(request: VideoJobRequest) -> str:
        return hashlib.sha256(json.dumps(asdict(request), sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    @staticmethod
    def _record(row: sqlite3.Row) -> VideoArtifact:
        return VideoArtifact(row["job_id"], row["project_id"], row["request_id"], row["modality"], row["format"], row["mode"], row["status"], row["progress"], f'/v1/projects/{row["project_id"]}/artifacts/{row["job_id"]}', row["artifact_sha256"])

    def submit_video(self, request: VideoJobRequest, content: bytes) -> VideoArtifact:
        if not isinstance(request, VideoJobRequest) or not isinstance(content, bytes) or not content:
            raise ValueError("video artifact payload is invalid")
        VideoCapability(lifecycle=request.lifecycle, statuses=request.statuses)
        fingerprint = self._fingerprint(request)
        digest = hashlib.sha256(content).hexdigest()
        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT * FROM pilot_video_artifacts WHERE request_id=?", (request.request_id,)).fetchone()
            if existing:
                if existing["project_id"] != request.project_id or existing["request_fingerprint"] != fingerprint or existing["artifact_sha256"] != digest:
                    raise ValueError("request id conflicts with immutable video operation")
                return self._record(existing)
            job_id = secrets.token_urlsafe(18)
            initial_status = request.statuses[0]
            initial_progress = 100 if request.lifecycle == "synchronous" else 0
            connection.execute("""INSERT INTO pilot_video_artifacts(
                job_id,project_id,request_id,request_fingerprint,modality,format,mode,status,progress,artifact_sha256,artifact_bytes,lifecycle,statuses)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", (job_id, request.project_id, request.request_id, fingerprint, request.modality, request.format, request.mode, initial_status, initial_progress, digest, sqlite3.Binary(content), request.lifecycle, json.dumps(request.statuses)))
            return self._record(connection.execute("SELECT * FROM pilot_video_artifacts WHERE job_id=?", (job_id,)).fetchone())

    def _scoped(self, job_id: str, project_id: str) -> sqlite3.Row:
        with self._db() as connection:
            row = connection.execute("SELECT * FROM pilot_video_artifacts WHERE job_id=?", (job_id,)).fetchone()
        if not row:
            raise KeyError("unknown video artifact")
        if row["project_id"] != project_id:
            raise PermissionError("video artifact is outside this project scope")
        return row

    def video_job(self, job_id: str, project_id: str) -> VideoArtifact:
        row = self._scoped(job_id, project_id)
        statuses = tuple(json.loads(row["statuses"]))
        try:
            next_status = statuses[statuses.index(row["status"]) + 1]
        except (ValueError, IndexError):
            next_status = None
        if next_status is not None:
            progress = round(100 * statuses.index(next_status) / (len(statuses) - 1))
            with self._db() as connection:
                connection.execute("UPDATE pilot_video_artifacts SET status=?,progress=? WHERE job_id=? AND status=?", (next_status, progress, job_id, row["status"]))
            row = self._scoped(job_id, project_id)
        return self._record(row)

    def read_video(self, project_id: str, job_id: str) -> tuple[bytes, str]:
        row = self._scoped(job_id, project_id)
        if row["status"] != "completed":
            raise PermissionError("video artifact is not ready")
        content = bytes(row["artifact_bytes"])
        digest = hashlib.sha256(content).hexdigest()
        if digest != row["artifact_sha256"]:
            raise ValueError("video artifact integrity check failed")
        return content, digest


class PilotThreeDArtifactService:
    """Persist the controlled 3D fixture and its declared lifecycle metadata."""

    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as connection:
            connection.execute("""CREATE TABLE IF NOT EXISTS pilot_3d_artifacts(
                job_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, request_id TEXT UNIQUE NOT NULL,
                request_fingerprint TEXT NOT NULL, modality TEXT NOT NULL, format TEXT NOT NULL,
                mode TEXT NOT NULL, status TEXT NOT NULL, progress INTEGER NOT NULL,
                artifact_sha256 TEXT NOT NULL, artifact_bytes BLOB NOT NULL,
                lifecycle TEXT NOT NULL, statuses TEXT NOT NULL,
                created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")

    @contextmanager
    def _db(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    @staticmethod
    def _fingerprint(request: ThreeDJobRequest) -> str:
        return hashlib.sha256(json.dumps(asdict(request), sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    @staticmethod
    def _record(row: sqlite3.Row) -> ThreeDArtifact:
        return ThreeDArtifact(row["job_id"], row["project_id"], row["request_id"], row["modality"], row["format"], row["mode"], row["status"], row["progress"], f'/v1/projects/{row["project_id"]}/artifacts/{row["job_id"]}', row["artifact_sha256"], row["lifecycle"], tuple(json.loads(row["statuses"])))

    def submit_3d(self, request: ThreeDJobRequest, content: bytes) -> ThreeDArtifact:
        if not isinstance(request, ThreeDJobRequest) or not isinstance(content, bytes) or not content:
            raise ValueError("3D artifact payload is invalid")
        ThreeDCapability(lifecycle=request.lifecycle, statuses=request.statuses)
        fingerprint = self._fingerprint(request)
        digest = hashlib.sha256(content).hexdigest()
        with self._db() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT * FROM pilot_3d_artifacts WHERE request_id=?", (request.request_id,)).fetchone()
            if existing:
                if existing["project_id"] != request.project_id or existing["request_fingerprint"] != fingerprint or existing["artifact_sha256"] != digest:
                    raise ValueError("request id conflicts with immutable 3D operation")
                return self._record(existing)
            job_id = secrets.token_urlsafe(18)
            status = request.statuses[0]
            progress = 100 if request.lifecycle == "synchronous" else 0
            connection.execute("""INSERT INTO pilot_3d_artifacts(job_id,project_id,request_id,request_fingerprint,modality,format,mode,status,progress,artifact_sha256,artifact_bytes,lifecycle,statuses)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", (job_id, request.project_id, request.request_id, fingerprint, request.modality, request.format, request.mode, status, progress, digest, sqlite3.Binary(content), request.lifecycle, json.dumps(request.statuses)))
            return self._record(connection.execute("SELECT * FROM pilot_3d_artifacts WHERE job_id=?", (job_id,)).fetchone())

    def _scoped(self, job_id: str, project_id: str) -> sqlite3.Row:
        with self._db() as connection:
            row = connection.execute("SELECT * FROM pilot_3d_artifacts WHERE job_id=?", (job_id,)).fetchone()
        if not row:
            raise KeyError("unknown 3D artifact")
        if row["project_id"] != project_id:
            raise PermissionError("3D artifact is outside this project scope")
        return row

    def three_d_job(self, job_id: str, project_id: str) -> ThreeDArtifact:
        row = self._scoped(job_id, project_id)
        statuses = tuple(json.loads(row["statuses"]))
        try:
            next_status = statuses[statuses.index(row["status"]) + 1]
        except (ValueError, IndexError):
            next_status = None
        if next_status is not None:
            progress = round(100 * statuses.index(next_status) / (len(statuses) - 1))
            with self._db() as connection:
                connection.execute("UPDATE pilot_3d_artifacts SET status=?,progress=? WHERE job_id=? AND status=?", (next_status, progress, job_id, row["status"]))
            row = self._scoped(job_id, project_id)
        return self._record(row)

    def read_3d(self, project_id: str, job_id: str) -> tuple[bytes, str]:
        row = self._scoped(job_id, project_id)
        if row["status"] != "completed":
            raise PermissionError("3D artifact is not ready")
        content = bytes(row["artifact_bytes"])
        digest = hashlib.sha256(content).hexdigest()
        if digest != row["artifact_sha256"]:
            raise ValueError("3D artifact integrity check failed")
        return content, digest


__all__ = ("PilotAudioArtifactService", "PilotVideoArtifactService", "PilotThreeDArtifactService")
