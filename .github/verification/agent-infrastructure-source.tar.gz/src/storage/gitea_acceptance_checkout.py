"""Safe detached checkout evidence for the Gitea acceptance driver."""
from __future__ import annotations
from dataclasses import dataclass
import os,re,subprocess
from pathlib import Path
from urllib.parse import urlsplit
from .project_verification_runner import input_tree_digest

class CheckoutError(ValueError):pass
_SAFE=re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
@dataclass(frozen=True)
class CheckoutEvidence:
 path: str
 commit: str
 input_tree_sha256: str
class LocalCheckoutAdapter:
 def __init__(self, *, git_binary:str="git", allow_file_url_for_test:bool=False, http_authorization:str|None=None):
  if http_authorization is not None and (not isinstance(http_authorization,str) or not http_authorization or "\r" in http_authorization or "\n" in http_authorization):raise CheckoutError("checkout authorization is unsafe")
  self.git_binary,self.allow_file_url_for_test,self.http_authorization=git_binary,allow_file_url_for_test,http_authorization
 def checkout(self, repo_url:str, root:Path, run_id:str, head_commit:str)->CheckoutEvidence:
  parsed=urlsplit(repo_url)
  permitted=(parsed.scheme=="https" and parsed.hostname and not parsed.username and not parsed.password) or (parsed.scheme=="http" and parsed.hostname in {"127.0.0.1","::1"} and not parsed.username and not parsed.password) or (self.allow_file_url_for_test and parsed.scheme=="file")
  root=Path(root);destination=root/("acceptance-"+run_id)
  if not permitted or not _SAFE.fullmatch(run_id) or not re.fullmatch(r"[0-9a-f]{40,64}",head_commit) or not root.is_absolute() or not root.is_dir() or root.is_symlink() or any(parent.is_symlink() for parent in root.parents) or destination.exists() or destination.is_symlink():raise CheckoutError("checkout configuration is unsafe")
  env={**os.environ,"GIT_TERMINAL_PROMPT":"0","GIT_CONFIG_NOSYSTEM":"1","GIT_ASKPASS":"/bin/false" if os.name!="nt" else "NUL","NO_PROXY":"127.0.0.1,localhost","no_proxy":"127.0.0.1,localhost","HTTPS_PROXY":"","HTTP_PROXY":"","ALL_PROXY":""}
  if self.http_authorization is not None:env.update({"GIT_CONFIG_COUNT":"1","GIT_CONFIG_KEY_0":"http.extraHeader","GIT_CONFIG_VALUE_0":"Authorization: "+self.http_authorization})
  def git(*args:str):
   result=subprocess.run([self.git_binary,"-c","credential.helper=",*args],cwd=root,env=env,capture_output=True,text=True,timeout=60,check=False)
   if result.returncode:raise CheckoutError("controlled git checkout failed")
   return result.stdout.strip()
  git("clone","--no-checkout",repo_url,str(destination))
  git("-C",str(destination),"fetch","--no-tags","origin",head_commit)
  actual=git("-C",str(destination),"rev-parse","FETCH_HEAD")
  if actual!=head_commit:raise CheckoutError("fetched commit does not match requested head")
  git("-C",str(destination),"checkout","--detach",head_commit)
  return CheckoutEvidence(str(destination),actual,input_tree_digest(destination))
