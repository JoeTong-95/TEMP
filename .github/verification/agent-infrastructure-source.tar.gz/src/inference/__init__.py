"""Inference layer: authenticated model data plane and measured capacity."""

__all__ = ("Gateway", "GatewayError", "make_handler")


def __getattr__(name: str):
    if name not in __all__:
        raise AttributeError(name)
    from . import gateway
    return getattr(gateway, name)
