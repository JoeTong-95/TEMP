import http.client, importlib.util, json, socket, sys, tempfile, threading, unittest, subprocess
from datetime import datetime
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

MODULE = Path(__file__).parents[4] / "gateway.py"
spec = importlib.util.spec_from_file_location("gateway", MODULE)
gateway = importlib.util.module_from_spec(spec); sys.modules[spec.name] = gateway; spec.loader.exec_module(gateway)

class Admission:
    def __init__(self): self.acquires=[]; self.releases=[]; self.quarantines=[]
    def acquire(self, request_id): self.acquires.append(request_id); return {"grant_id":request_id}
    def release(self, grant): self.releases.append(grant)
    def quarantine(self, grant, reason): self.quarantines.append((grant,reason))

class Backend(BaseHTTPRequestHandler):
    token_count=20; malformed_count=False
    completed=True; chunks=1; block=None; pause_after_first=None; started=None; oversize=False; disconnect=False; redirect=False; large_after_pause=0; usage=False
    def log_message(self,*_): pass
    def do_POST(self):
        self.server.seen_auth=self.headers.get("Authorization")
        self.server.seen_payload=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path.endswith("/input_tokens"):
            self.server.count_path=self.path
            self.server.count_payload=self.server.seen_payload
            self.send_response(200); self.send_header("Content-Type","application/json"); self.end_headers()
            self.wfile.write(b'{"input_tokens":true}' if self.malformed_count else json.dumps({"object":"response.input_tokens","input_tokens":self.token_count}).encode())
            return
        self.server.generation_calls=getattr(self.server,"generation_calls",0)+1
        if self.started: self.started.set()
        if self.block: self.block.wait(3)
        if self.redirect: self.send_response(302); self.send_header("Location","http://127.0.0.1:9/"); self.end_headers(); return
        self.send_response(200); self.send_header("Content-Type","text/event-stream" if self.chunks>1 else "application/json")
        self.end_headers()
        if self.chunks>1:
            for index in range(self.chunks):
                self.wfile.write(b'data: {"choices":[{"finish_reason":null}]}\n\n'); self.wfile.flush()
                if index == 0 and self.pause_after_first: self.pause_after_first.wait(3)
                if index == 0 and self.large_after_pause:
                    self.wfile.write(b'data: {"choices":[{"finish_reason":null}],"padding":"'+b"x"*self.large_after_pause+b'"}\n\n'); self.wfile.flush()
                    return
            if self.disconnect: return
            if self.completed:
                self.wfile.write(b'data: {"choices":[{"finish_reason":"stop"}]}\n\n')
                if self.usage: self.wfile.write(b'data: {"choices":[],"usage":{"prompt_tokens":2,"completion_tokens":3,"total_tokens":5}}\n\n')
                self.wfile.write(b'data: [DONE]\n\n')
        elif self.oversize: self.wfile.write(b"x"*(gateway.MAX_RESPONSE+1))
        else: self.wfile.write(json.dumps({"choices":[{"finish_reason":"stop" if self.completed else None}]}).encode())

class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); root=Path(self.tmp.name)
        (root/"tokens.json").write_text(json.dumps({"tokens":["caller-token"]}))
        (root/"backend.key").write_text("private-backend-key")
        (root/"profile.json").write_text(json.dumps({"profile_id":"local-tool-calling","status":"measured","model_sha256":"a"*64,"max_context_tokens":8192,"max_output_tokens":32,"max_concurrency":1,"incremental_vram_mib":4096,"incremental_ram_mib":4096}))
        self.backend=ThreadingHTTPServer(("127.0.0.1",0),Backend); threading.Thread(target=self.backend.serve_forever,daemon=True).start()
        self.admission=Admission(); app=gateway.Gateway(root/"tokens.json",root/"backend.key",root/"profile.json",self.admission,f"http://127.0.0.1:{self.backend.server_port}")
        self.server=ThreadingHTTPServer(("127.0.0.1",0),gateway.make_handler(app)); threading.Thread(target=self.server.serve_forever,daemon=True).start()
    def tearDown(self):
        Backend.token_count=20; Backend.malformed_count=False
        Backend.completed=True; Backend.chunks=1; Backend.block=None; Backend.pause_after_first=None; Backend.started=None; Backend.oversize=False; Backend.disconnect=False; Backend.redirect=False; Backend.large_after_pause=0; Backend.usage=False
        self.server.shutdown(); self.server.server_close(); self.backend.shutdown(); self.backend.server_close(); self.tmp.cleanup()
    def request(self, method,path,body=None,auth="Bearer caller-token"):
        c=http.client.HTTPConnection("127.0.0.1",self.server.server_port,timeout=3); headers={}
        if auth: headers["Authorization"]=auth
        if body is not None: headers["Content-Type"]="application/json"
        c.request(method,path,body=json.dumps(body) if body is not None else None,headers=headers); r=c.getresponse(); data=r.read(); c.close(); return r.status,data
    def payload(self, **extra):
        value={"model":"local-tool-calling","messages":[{"role":"user","content":"hi"}],"max_tokens":8}; value.update(extra); return value
    def test_gateway_banner_has_stable_unversioned_identity(self):
        handler=self.server.RequestHandlerClass
        self.assertEqual(handler.server_version,"AgentInferenceGateway")
        self.assertEqual(handler.sys_version,"")
    def test_authenticated_capacity_is_fresh_and_minimal(self):
        with patch.object(gateway, "_nvidia_total_vram_mib", return_value=24576), patch.object(gateway, "_total_physical_memory_bytes", return_value=64 * 1024 * 1024 * 1024), patch.object(gateway.os, "cpu_count", return_value=16):
            status, data = self.request("GET", "/agent-stack/capacity")
        self.assertEqual(status, 200)
        payload = json.loads(data)
        self.assertEqual(set(payload), {"quantities", "observed_at"})
        self.assertEqual(payload["quantities"], {"cpu_cores": 16, "incremental_ram_mib": 65536, "incremental_vram_mib": 24576})
        self.assertIsNotNone(datetime.fromisoformat(payload["observed_at"].replace("Z", "+00:00")).tzinfo)
        self.assertEqual(self.request("GET", "/agent-stack/capacity", auth="Bearer wrong")[0], 401)
        self.assertEqual(self.request("GET", "/agent-stack/capacity?x=1")[0], 404)
    def test_capacity_fails_closed_for_ambiguous_gpu_output(self):
        completed = subprocess.CompletedProcess([], 0, stdout=b"24576\n24576\n", stderr=b"")
        with patch.object(gateway.subprocess, "run", return_value=completed), patch.object(gateway, "_total_physical_memory_bytes", return_value=64 * 1024 * 1024 * 1024):
            status, data = self.request("GET", "/agent-stack/capacity")
        self.assertEqual(status, 503)
        self.assertEqual(json.loads(data)["error"]["code"], "capacity_unavailable")
    def test_capacity_gpu_command_is_bounded_and_shell_free(self):
        completed = subprocess.CompletedProcess([], 0, stdout=b"24576\n", stderr=b"")
        with patch.object(gateway.subprocess, "run", return_value=completed) as run, patch.object(gateway, "_total_physical_memory_bytes", return_value=64 * 1024 * 1024 * 1024), patch.object(gateway.os, "cpu_count", return_value=16):
            self.assertEqual(self.request("GET", "/agent-stack/capacity")[0], 200)
        kwargs = run.call_args.kwargs
        self.assertFalse(kwargs["shell"])
        self.assertEqual(kwargs["timeout"], gateway.CAPACITY_COMMAND_TIMEOUT)
        self.assertEqual(run.call_args.args[0], ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"])
    def test_denied_routes_auth_and_model_have_no_side_effect(self):
        self.assertEqual(self.request("GET","/api/models/unload")[0],404)
        self.assertEqual(self.request("GET","/v1/models",auth="Bearer wrong")[0],401)
        self.assertEqual(self.request("POST","/v1/chat/completions",self.payload(model="other"))[0],400)
        self.assertEqual(self.request("POST","/v1/chat/completions",self.payload(n=2))[0],400)
        self.assertEqual(self.request("POST","/v1/chat/completions",self.payload(stream="true"))[0],400)
        self.assertEqual(self.request("POST","/v1/chat/completions",self.payload(tools=["not-an-object"]))[0],413)
        self.assertEqual(self.request("POST","/v1/chat/completions",{"model":"local-tool-calling","messages":[{"role":"user"}]})[0],400)
        self.assertEqual(self.request("POST","/v1/chat/completions",self.payload(messages=[{"role":"user","content":"x","extra":{"nested":"x"*10000}}]))[0],400)
        self.assertEqual(self.request("POST","/v1/chat/completions?url=http://evil",self.payload())[0],404)
        self.assertFalse(self.admission.acquires)
    def test_completed_backend_releases_exactly_one_grant(self):
        request=self.payload(messages=[{"role":"assistant","content":None,"tool_calls":[{"id":"x","type":"function","function":{"name":"f","arguments":"{"}}]}]); del request["max_tokens"]
        self.assertEqual(self.request("POST","/v1/chat/completions",request)[0],200)
        self.assertEqual(len(self.admission.acquires),1); self.assertEqual(self.admission.releases,self.admission.acquires); self.assertFalse(self.admission.quarantines)
        self.assertEqual(self.backend.seen_auth,"Bearer private-backend-key")
        self.assertEqual(self.backend.seen_payload["max_tokens"],32)
    def test_sse_truncation_has_correlated_error_and_no_done(self):
        Backend.completed=False; Backend.chunks=2
        status, data=self.request("POST","/v1/chat/completions",self.payload(stream=True))
        self.assertEqual(status,200); self.assertIn(b"event: error",data); self.assertIn(b'"request_id"',data); self.assertNotIn(b"data: [DONE]",data)
        self.assertEqual(len(self.admission.acquires),1); self.assertFalse(self.admission.releases); self.assertEqual(len(self.admission.quarantines),1)
        Backend.completed=True; Backend.chunks=1
    def test_sse_done_releases_grant(self):
        Backend.chunks=2
        status, data=self.request("POST","/v1/chat/completions",self.payload(stream=True))
        self.assertEqual(status,200); self.assertIn(b"event: gateway.completion",data); self.assertTrue(data.endswith(b"data: [DONE]\n\n"))
        self.assertEqual(self.admission.releases,self.admission.acquires)
    def test_crlf_sse_frame_parser(self):
        first,remaining=gateway.pop_sse_frame(b'data: {"choices":[]}\r\n\r\ndata: [DONE]\r\n\r\n')
        self.assertEqual(first,b'data: {"choices":[]}')
        second,remaining=gateway.pop_sse_frame(remaining)
        self.assertEqual(second,b'data: [DONE]'); self.assertEqual(remaining,b'')
    def test_sse_usage_only_frame_requires_opt_in_and_has_sdk_envelope(self):
        Backend.chunks=2; Backend.usage=True
        status,data=self.request("POST","/v1/chat/completions",self.payload(stream=True,stream_options={"include_usage":True}))
        self.assertEqual(status,200); self.assertIn(b'"choices":[]',data); self.assertIn(b'"total_tokens":5',data)
        self.assertIn(b'event: gateway.completion',data); self.assertIn(b'"object":"chat.completion.chunk"',data)
        self.assertTrue(gateway.valid_stream_usage({"prompt_tokens":2,"completion_tokens":3,"total_tokens":5,"prompt_tokens_details":{"cached_tokens":1}}))
        self.assertFalse(gateway.valid_stream_usage({"prompt_tokens":2,"completion_tokens":3,"total_tokens":5,"prompt_tokens_details":{"cached_tokens":3}}))
        self.assertFalse(gateway.valid_stream_usage({"prompt_tokens":2,"completion_tokens":3,"total_tokens":5,"extra":0}))
    def test_pinned_openai_sdk_parses_fake_gateway_stream(self):
        """Fake-only SDK parser compatibility; no listener, credentials, or model."""
        code='''import httpx,json
from openai import OpenAI
frames=[{"id":"x","object":"chat.completion.chunk","created":1,"model":"local-tool-calling","choices":[{"index":0,"delta":{"content":"ok"},"finish_reason":None}]},{"id":"x","object":"chat.completion.chunk","created":1,"model":"local-tool-calling","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]},{"id":"x","object":"chat.completion.chunk","created":1,"model":"local-tool-calling","choices":[],"usage":{"prompt_tokens":2,"completion_tokens":1,"total_tokens":3}}]
raw=b"".join(b"data: "+json.dumps(x).encode()+b"\\n\\n" for x in frames)+b"event: gateway.completion\\ndata: "+json.dumps({"id":"x","object":"chat.completion.chunk","created":1,"model":"local-tool-calling","choices":[]}).encode()+b"\\n\\ndata: [DONE]\\n\\n"
c=OpenAI(api_key="fake",base_url="http://fake/v1",http_client=httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(200,headers={"content-type":"text/event-stream"},content=raw))))
assert sum(1 for _ in c.chat.completions.create(model="local-tool-calling",messages=[{"role":"user","content":"x"}],stream=True)) >= 3
'''
        result=subprocess.run(["/srv/agent-stack/cache/memory-runtime/hermes-agent-0.19.0-venv/bin/python","-c",code],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
    def test_json_truncation_returns_502_without_partial_success(self):
        Backend.completed=False
        status, data=self.request("POST","/v1/chat/completions",self.payload())
        body=json.loads(data); self.assertEqual(status,502); self.assertEqual(body["error"]["code"],"completion_evidence_missing"); self.assertIn("request_id",body["error"])
        self.assertEqual(body["error"]["request_id"], self.admission.acquires[0])
        self.assertFalse(self.admission.releases); self.assertEqual(self.admission.quarantines[0][1],"completion_evidence_missing")
    def test_json_oversize_returns_correlated_error(self):
        Backend.oversize=True
        status, data=self.request("POST","/v1/chat/completions",self.payload())
        body=json.loads(data); self.assertEqual(status,502); self.assertEqual(body["error"]["code"],"response_limit"); self.assertIn("request_id",body["error"])
        self.assertEqual(self.admission.quarantines[0][1],"response_limit")
    def test_release_failure_never_publishes_final_success(self):
        def fail_release(_grant):
            raise gateway.GatewayError(503, "release_unconfirmed", "Admission release failed.")
        self.admission.release = fail_release
        for streaming in (False, True):
            Backend.chunks = 2 if streaming else 1
            status, data = self.request("POST", "/v1/chat/completions", self.payload(stream=streaming))
            self.assertEqual(status, 200 if streaming else 503)
            self.assertIn(b"release_unconfirmed", data)
            self.assertNotIn(b"data: [DONE]", data)
            self.assertNotIn(b"event: gateway.completion", data)
        self.assertEqual(len(self.admission.quarantines), 2)
    def test_sse_upstream_disconnect_quarantines_and_omits_done(self):
        Backend.chunks=2; Backend.disconnect=True
        status, data=self.request("POST","/v1/chat/completions",self.payload(stream=True))
        self.assertEqual(status,200); self.assertIn(b"event: error",data); self.assertNotIn(b"data: [DONE]",data)
        self.assertEqual(self.admission.quarantines[0][1],"completion_evidence_missing")
    def test_sse_oversize_has_correlated_error_and_no_done(self):
        Backend.chunks=2; Backend.large_after_pause=gateway.MAX_RESPONSE+1
        status, data=self.request("POST","/v1/chat/completions",self.payload(stream=True))
        self.assertEqual(status,200); self.assertIn(b'"response_limit"',data); self.assertIn(b'"request_id"',data); self.assertNotIn(b"data: [DONE]",data)
        self.assertEqual(self.admission.quarantines[0][1],"response_limit")
    def test_client_disconnect_quarantines_unknown_completion(self):
        class DisconnectingGateway(gateway.Gateway):
            writes=0
            def stream_write(self, writer, raw):
                self.writes += 1
                if self.writes == 2: raise BrokenPipeError("fake caller disconnected")
                return super().stream_write(writer, raw)
        Backend.chunks=2; admission=Admission()
        app=DisconnectingGateway(Path(self.tmp.name)/"tokens.json",Path(self.tmp.name)/"backend.key",Path(self.tmp.name)/"profile.json",admission,f"http://127.0.0.1:{self.backend.server_port}")
        direct=ThreadingHTTPServer(("127.0.0.1",0),gateway.make_handler(app)); threading.Thread(target=direct.serve_forever,daemon=True).start()
        c=http.client.HTTPConnection("127.0.0.1",direct.server_port,timeout=3); c.request("POST","/v1/chat/completions",json.dumps(self.payload(stream=True)),{"Authorization":"Bearer caller-token","Content-Type":"application/json"}); self.assertEqual(c.getresponse().status,200); c.close()
        direct.shutdown(); direct.server_close()
        self.assertEqual(admission.quarantines[0][1],"client-disconnected-completion-unknown")
    def test_backend_redirect_is_not_followed(self):
        Backend.redirect=True
        status, data=self.request("POST","/v1/chat/completions",self.payload())
        self.assertEqual(status,502); self.assertEqual(json.loads(data)["error"]["code"],"backend_error")
        self.assertEqual(self.admission.quarantines[0][1],"backend_http_error")
    def test_proxy_environment_cannot_select_backend_route(self):
        with patch.dict("os.environ", {"HTTP_PROXY":"http://127.0.0.1:1", "HTTPS_PROXY":"http://127.0.0.1:1", "NO_PROXY":"", "no_proxy":""}):
            self.assertEqual(self.request("POST","/v1/chat/completions",self.payload())[0],200)
        self.assertFalse(any(isinstance(handler, gateway.ProxyHandler) for handler in gateway.NO_REDIRECT_OPENER.handlers))
    def test_invalid_profile_is_503_without_admission(self):
        path=Path(self.tmp.name)/"profile.json"
        valid=json.loads(path.read_text())
        for field,value in (("model_sha256","not-a-hash"),("profile_id","../other"),("max_context_tokens",True),("max_output_tokens",129),("max_concurrency",True)):
            data=dict(valid); data[field]=value; path.write_text(json.dumps(data))
            self.assertEqual(self.request("GET","/v1/models")[0],503)
        path.write_text("{")
        self.assertEqual(self.request("GET","/v1/models")[0],503)
        path.unlink()
        self.assertEqual(self.request("GET","/v1/models")[0],503)
        self.assertFalse(self.admission.acquires)
    def test_context_uses_native_tokens_not_utf8_byte_estimate(self):
        marker="synthetic-private-marker"
        request=self.payload(messages=[{"role":"user","content":marker+" synthetic "*1400}])
        Backend.token_count=7000
        self.assertEqual(self.request("POST","/v1/chat/completions",request)[0],200)
        self.assertEqual(self.backend.count_path,"/upstream/local-tool-calling/v1/chat/completions/input_tokens")
        self.assertEqual(self.backend.count_payload,self.backend.seen_payload)
        self.assertEqual(self.backend.count_payload["chat_template_kwargs"],{"enable_thinking":False})
        self.assertEqual(len(self.admission.acquires),1)
        audit_path=Path(self.tmp.name)/"last-context-audit.json"
        audit=json.loads(audit_path.read_text())
        self.assertEqual(audit["input_tokens"],7000)
        self.assertEqual(audit["message_count"],1)
        self.assertEqual(audit["tool_count"],0)
        self.assertTrue(audit["within_limit"])
        self.assertNotIn(marker,audit_path.read_text())
        self.assertNotIn("caller-token",audit_path.read_text())
    def test_response_format_is_only_json_object_and_reaches_both_native_calls(self):
        request=self.payload(response_format={"type":"json_object"})
        self.assertEqual(self.request("POST","/v1/chat/completions",request)[0],200)
        self.assertEqual(self.backend.count_payload["response_format"],{"type":"json_object"})
        self.assertEqual(self.backend.seen_payload["response_format"],{"type":"json_object"})
        for rejected in ({"type":"json_schema"},{"type":"json_object","schema":{}},"json_object"):
            self.assertEqual(self.request("POST","/v1/chat/completions",self.payload(response_format=rejected))[0],400)
    def test_context_overflow_never_generates_and_releases(self):
        Backend.token_count=8190
        status,data=self.request("POST","/v1/chat/completions",self.payload())
        self.assertEqual(status,413); self.assertIn(b"context_limit",data)
        self.assertFalse(getattr(self.backend,"generation_calls",0))
        self.assertEqual(self.admission.releases,self.admission.acquires)
        self.assertFalse(self.admission.quarantines)
    def test_invalid_native_count_fails_closed(self):
        Backend.malformed_count=True
        status,data=self.request("POST","/v1/chat/completions",self.payload())
        self.assertEqual(status,502); self.assertIn(b"token_count_invalid",data)
        self.assertFalse(getattr(self.backend,"generation_calls",0))
        self.assertFalse(self.admission.releases)
        self.assertEqual(self.admission.quarantines[0][1],"token_count_invalid")
    def test_max_one_request_at_gateway(self):
        class One(Admission):
            active=False
            def acquire(s,request_id):
                if s.active: raise gateway.GatewayError(503,"admission_denied","single slot held")
                s.active=True; return super().acquire(request_id)
            def release(s,grant): s.active=False; super().release(grant)
        admission=One(); app=gateway.Gateway(Path(self.tmp.name)/"tokens.json",Path(self.tmp.name)/"backend.key",Path(self.tmp.name)/"profile.json",admission,f"http://127.0.0.1:{self.backend.server_port}")
        held=threading.Event(); Backend.started=held; Backend.block=threading.Event()
        direct=ThreadingHTTPServer(("127.0.0.1",0),gateway.make_handler(app)); threading.Thread(target=direct.serve_forever,daemon=True).start()
        def call():
            c=http.client.HTTPConnection("127.0.0.1",direct.server_port,timeout=5); c.request("POST","/v1/chat/completions",json.dumps(self.payload()),{"Authorization":"Bearer caller-token","Content-Type":"application/json"}); c.getresponse().read(); c.close()
        first=threading.Thread(target=call,daemon=True); first.start(); self.assertTrue(held.wait(2))
        c=http.client.HTTPConnection("127.0.0.1",direct.server_port,timeout=3); c.request("POST","/v1/chat/completions",json.dumps(self.payload()),{"Authorization":"Bearer caller-token","Content-Type":"application/json"}); self.assertEqual(c.getresponse().status,503); c.close()
        Backend.block.set(); first.join(3); direct.shutdown(); direct.server_close(); self.assertEqual(len(admission.acquires),1)
    def test_handler_thread_cap_rejects_second_stalled_connection(self):
        app=gateway.Gateway(Path(self.tmp.name)/"tokens.json",Path(self.tmp.name)/"backend.key",Path(self.tmp.name)/"profile.json",Admission(),f"http://127.0.0.1:{self.backend.server_port}")
        capped=gateway.BoundedHTTPServer(("127.0.0.1",0),gateway.make_handler(app),max_handlers=1)
        threading.Thread(target=capped.serve_forever,daemon=True).start()
        first=socket.create_connection(("127.0.0.1",capped.server_port),timeout=2); first.sendall(b"POST /v1/chat/completions HTTP/1.1\r\n")
        second=socket.create_connection(("127.0.0.1",capped.server_port),timeout=2); second.settimeout(2)
        self.assertEqual(second.recv(1),b"")
        first.close(); second.close(); capped.shutdown(); capped.server_close()

if __name__ == "__main__": unittest.main()
