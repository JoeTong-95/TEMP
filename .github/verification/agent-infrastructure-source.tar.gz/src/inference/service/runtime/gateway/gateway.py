"""Compatibility launcher for the canonical Inference layer gateway.

Existing Windows service scripts execute this file directly.  New deployments
may use ``python -m inference.gateway`` with
``AGENT_INFERENCE_DEPLOYMENT_ROOT`` set to this role's deployment directory.
"""
from __future__ import annotations

import sys
from pathlib import Path

_PLATFORM_ROOT = Path(__file__).resolve().parents[3]
_SOURCE_ROOT = _PLATFORM_ROOT / "src"
if str(_SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(_SOURCE_ROOT))

from inference.gateway import *  # noqa: F401,F403,E402
from inference import gateway as _implementation  # noqa: E402


if __name__ == "__main__":
    _implementation.serve(Path(__file__).resolve().parents[1])
