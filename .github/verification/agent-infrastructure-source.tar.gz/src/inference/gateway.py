"""Loopback-only inference data-plane gateway; standard-library implementation."""
from __future__ import annotations

import ctypes, hmac, json, os, re, subprocess, threading, time, uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

BACKEND = "http://127.0.0.1:18090"
MAX_BODY = 1_048_576
MAX_RESPONSE = 2_097_152
MAX_HANDLER_THREADS = 16
UPSTREAM_DEADLINE = 240
UPSTREAM_READ_TIMEOUT = 5
TOKEN_COUNT_TIMEOUT = 30
CAPACITY_COMMAND_TIMEOUT = 3
MAX_CAPACITY_COMMAND_OUTPUT = 4096

class NoRedirect(HTTPRedirectHandler):
    """The fixed backend must never be able to select another destination."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

# Neither environment proxies nor Windows Internet Settings may route private
# prompts and credentials outside the fixed loopback backend.
NO_REDIRECT_OPENER = build_opener(ProxyHandler({}), NoRedirect)

class BoundedHTTPServer(ThreadingHTTPServer):
    """Caps accepted handler threads before a connection can consume headers/body."""
    daemon_threads = True
    def __init__(self, address, handler, max_handlers=MAX_HANDLER_THREADS):
        super().__init__(address, handler)
        self._handler_slots = threading.BoundedSemaphore(max_handlers)
    def process_request(self, request, client_address):
        if not self._handler_slots.acquire(blocking=False):
            try: request.shutdown(2)
            except OSError: pass
            request.close()
            return
        super().process_request(request, client_address)
    def process_request_thread(self, request, client_address):
        try: super().process_request_thread(request, client_address)
        finally: self._handler_slots.release()

class GatewayError(Exception):
    def __init__(self, status: int, code: str, message: str): self.status, self.code, self.message = status, code, message

def _total_physical_memory_bytes() -> int | None:
    """Return host physical RAM without invoking a shell or a platform utility."""
    if os.name == "nt":
        class MemoryStatusEx(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]
        status = MemoryStatusEx()
        status.dwLength = ctypes.sizeof(status)
        try:
            if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return None
        except (AttributeError, OSError):
            return None
        return int(status.ullTotalPhys) or None
    try:
        pages = os.sysconf("SC_PHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
    except (AttributeError, OSError, ValueError):
        return None
    if type(pages) is not int or type(page_size) is not int or pages <= 0 or page_size <= 0:
        return None
    return pages * page_size

def _nvidia_total_vram_mib() -> int:
    """Read exactly one GPU's total VRAM, failing closed for ambiguity or bad data."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=CAPACITY_COMMAND_TIMEOUT,
            check=False,
            shell=False,
        )
    except (OSError, subprocess.SubprocessError):
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.") from None
    if result.returncode != 0:
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
    raw = result.stdout
    if isinstance(raw, bytes):
        if len(raw) > MAX_CAPACITY_COMMAND_OUTPUT:
            raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
        try:
            raw = raw.decode("ascii")
        except UnicodeDecodeError:
            raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.") from None
    if not isinstance(raw, str) or len(raw.encode("utf-8")) > MAX_CAPACITY_COMMAND_OUTPUT:
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
    rows = [line.strip() for line in raw.splitlines() if line.strip()]
    if len(rows) != 1 or not re.fullmatch(r"[0-9]+", rows[0]):
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
    vram_mib = int(rows[0])
    if not 1 <= vram_mib <= 1 << 30:
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
    return vram_mib

def measured_capacity() -> dict:
    """Return only fresh host totals needed by provider registration."""
    cpu_cores = os.cpu_count()
    ram_bytes = _total_physical_memory_bytes()
    vram_mib = _nvidia_total_vram_mib()
    if type(cpu_cores) is not int or not 1 <= cpu_cores <= 4096:
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
    if type(ram_bytes) is not int or ram_bytes < 1:
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
    ram_mib = ram_bytes // (1024 * 1024)
    if not 1 <= ram_mib <= 1 << 30:
        raise GatewayError(503, "capacity_unavailable", "Measured capacity is unavailable.")
    return {
        "quantities": {
            "cpu_cores": cpu_cores,
            "incremental_ram_mib": ram_mib,
            "incremental_vram_mib": vram_mib,
        },
        "observed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }

@dataclass(frozen=True)
class Profile:
    profile_id: str; context: int; output: int
    @classmethod
    def load(cls, path: Path) -> "Profile":
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, ValueError):
            raise GatewayError(503, "profile_unavailable", "Reviewed profile cannot be read.") from None
        if not isinstance(data, dict) or data.get("status") != "measured":
            raise GatewayError(503, "profile_unavailable", "No measured reviewed profile is active.")
        if (not isinstance(data.get("model_sha256"), str)
            or not re.fullmatch(r"[a-f0-9]{64}", data["model_sha256"])
            or not isinstance(data.get("profile_id"), str)
            or not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,79}", data["profile_id"])
            or type(data.get("max_concurrency")) is not int or data["max_concurrency"] != 1
            or type(data.get("max_context_tokens")) is not int
            or not 1 <= data["max_context_tokens"] <= 8192
            or type(data.get("max_output_tokens")) is not int
            or not 1 <= data["max_output_tokens"] <= 128):
            raise GatewayError(503, "profile_invalid", "Reviewed profile violates gateway bounds.")
        return cls(data["profile_id"], data["max_context_tokens"], data["max_output_tokens"])

class PowerShellAdmission:
    """Production path; no network request can enable synthetic admission inputs."""
    def __init__(self, script: Path): self.script = script
    def _run(self, action: str, **args):
        command = [os.environ.get("POWERSHELL_EXE", "powershell.exe"), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(self.script), "-Action", action]
        for key, value in args.items():
            if value is not None: command += [f"-{key}", str(value)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=20)
        if result.returncode: raise GatewayError(503, "admission_denied", "Provider admission denied or is unavailable.")
        return json.loads(result.stdout)
    def acquire(self, request_id: str): return self._run("Acquire", RequestId=request_id, LeaseSeconds=300)["grant"]
    def release(self, grant_id: str): self._run("Release", GrantId=grant_id)
    def quarantine(self, grant_id: str, reason: str): self._run("Quarantine", GrantId=grant_id, Reason=reason)

class Gateway:
    def __init__(self, token_path: Path, backend_key_path: Path, profile_path: Path, admission, backend: str = BACKEND):
        self.tokens = set(json.loads(token_path.read_text(encoding="utf-8"))["tokens"])
        self.backend_key = backend_key_path.read_text(encoding="utf-8").strip()
        if not self.tokens or any(not isinstance(token,str) or not token for token in self.tokens): raise ValueError("gateway token file has invalid tokens")
        if not self.backend_key: raise ValueError("gateway backend key file is empty")
        self.token_path, self.profile_path, self.admission, self.backend = token_path, profile_path, admission, backend.rstrip("/")
        self.slot = threading.BoundedSemaphore(1)
        self.audit_path = token_path.parent / "last-context-audit.json"
        self.audit_lock = threading.Lock()
    def stream_write(self, writer, raw: bytes):
        """Single seam for SSE writes; socket errors must preserve unknown completion."""
        writer.write(raw); writer.flush()
    def authenticate(self, value: str | None):
        supplied=value[7:] if value and value.startswith("Bearer ") else ""
        if not any(hmac.compare_digest(supplied, token) for token in self.tokens): raise GatewayError(401, "unauthorized", "Bearer token required.")
    def profile(self): return Profile.load(self.profile_path)
    def models(self):
        profile = self.profile()
        return {"object":"list","data":[{"id":profile.profile_id,"object":"model"}]}
    def capacity(self): return measured_capacity()
    def completion(self, payload: dict):
        profile = self.profile()
        allowed={"model","messages","max_tokens","stream","tools","tool_choice","temperature","stream_options","response_format"}
        if set(payload)-allowed: raise GatewayError(400,"field_not_allowed","Request contains a non-allowlisted field.")
        if payload.get("model") != profile.profile_id: raise GatewayError(400, "model_not_allowed", "Model override is not allowed.")
        if "stream" in payload and type(payload["stream"]) is not bool: raise GatewayError(400,"invalid_request","stream must be boolean.")
        if "temperature" in payload and (type(payload["temperature"]) not in (int,float) or isinstance(payload["temperature"],bool) or not 0 <= payload["temperature"] <= 2): raise GatewayError(400,"invalid_request","temperature must be within reviewed bounds.")
        if "stream_options" in payload:
            options=payload["stream_options"]
            if not isinstance(options,dict) or set(options)!={"include_usage"} or type(options["include_usage"]) is not bool: raise GatewayError(400,"invalid_request","stream_options is restricted to include_usage.")
        if "response_format" in payload and payload["response_format"] != {"type":"json_object"}:
            raise GatewayError(400,"invalid_request","response_format is restricted to json_object.")
        if not isinstance(payload.get("messages"), list) or not payload["messages"]: raise GatewayError(400, "invalid_request", "messages must be a non-empty array.")
        if len(payload["messages"]) > 64: raise GatewayError(400,"invalid_request","Too many messages.")
        for message in payload["messages"]:
            allowed_message={"role","content","name","tool_calls","tool_call_id"}
            if not isinstance(message,dict) or set(message)-allowed_message or message.get("role") not in {"system","developer","user","assistant","tool"}: raise GatewayError(400,"invalid_request","Message shape or role is not allowed.")
            content=message.get("content")
            calls=message.get("tool_calls")
            if content is None and not (message["role"]=="assistant" and isinstance(calls,list)): raise GatewayError(400,"invalid_request","content is required except assistant tool calls.")
            if content is not None and not isinstance(content,str): raise GatewayError(400,"invalid_request","content must be a string or allowed null.")
            if calls is not None:
                if message["role"]!="assistant" or not isinstance(calls,list) or len(calls)>8: raise GatewayError(400,"invalid_request","tool_calls are only allowed on assistant messages.")
                for call in calls:
                    function=call.get("function") if isinstance(call,dict) else None
                    if not isinstance(call,dict) or set(call)!={"id","type","function"} or call.get("type")!="function" or not isinstance(function,dict) or set(function)!={"name","arguments"} or not isinstance(function["name"],str) or not isinstance(function["arguments"],str): raise GatewayError(400,"invalid_request","tool call shape is not allowed.")
        tool_bytes=len(json.dumps(payload.get("tools",[]),separators=(",",":"),ensure_ascii=False).encode())
        if not isinstance(payload.get("tools",[]),list) or any(not isinstance(tool,dict) for tool in payload.get("tools",[])) or len(payload.get("tools",[]))>8 or tool_bytes>65536: raise GatewayError(413,"tool_limit","Tool schemas exceed the reviewed bound.")
        if "tool_choice" in payload and not isinstance(payload["tool_choice"],(str,dict)): raise GatewayError(400,"tool_limit","tool_choice must be a string or object.")
        if "max_tokens" in payload and (type(payload["max_tokens"]) is not int or not 1 <= payload["max_tokens"] <= profile.output):
            raise GatewayError(400, "output_limit", "Output exceeds the reviewed bound.")
        if "response_format" in payload and payload["response_format"] != {"type":"json_object"}:
            raise GatewayError(400,"response_format_not_allowed","Only exact json_object response format is allowed.")
        payload.setdefault("max_tokens",profile.output)
        # Pin the exact Qwen template in both the native counting and generation calls.
        # It is injected after allowlist validation, so a client cannot override it.
        payload["chat_template_kwargs"]={"enable_thinking":False}
        return profile
    def check_context(self, payload, profile, request_id=None):
        """Count the exact native chat template and tools under an acquired slot.

        b10797 implements this native non-generation route. It remains private:
        a client cannot select the path, model, template or remote destination.
        llama-swap may load the single model, so admission must precede this call.
        """
        route=f"/upstream/{profile.profile_id}/v1/chat/completions/input_tokens"
        request=Request(self.backend+route, data=json.dumps(payload).encode(),
                        headers={"Content-Type":"application/json", "Authorization":"Bearer "+self.backend_key}, method="POST")
        with NO_REDIRECT_OPENER.open(request, timeout=TOKEN_COUNT_TIMEOUT) as response:
            raw=response.read(4097)
            if response.status != 200 or len(raw)>4096:
                raise GatewayError(502,"token_count_invalid","Native token counting failed.")
            try: value=json.loads(raw)
            except (ValueError,UnicodeError):
                raise GatewayError(502,"token_count_invalid","Native token counting failed.") from None
        if (not isinstance(value,dict) or value.get("object")!="response.input_tokens"
            or type(value.get("input_tokens")) is not int or value["input_tokens"]<1):
            raise GatewayError(502,"token_count_invalid","Native token counting failed.")
        tool_bytes=len(json.dumps(payload.get("tools",[]),separators=(",",":"),ensure_ascii=False).encode())
        body_bytes=len(json.dumps(payload,separators=(",",":"),ensure_ascii=False).encode())
        audit={
            "request_id": request_id,
            "input_tokens": value["input_tokens"],
            "output_tokens": payload["max_tokens"],
            "context_limit": profile.context,
            "within_limit": value["input_tokens"] + payload["max_tokens"] <= profile.context,
            "body_bytes": body_bytes,
            "message_count": len(payload.get("messages",[])),
            "tool_count": len(payload.get("tools",[])),
            "tool_schema_bytes": tool_bytes,
        }
        # The diagnostic contains counts only: never prompt, schema, auth, or response data.
        with self.audit_lock:
            temporary=self.audit_path.with_suffix(".tmp")
            temporary.write_text(json.dumps(audit,separators=(",",":")),encoding="utf-8")
            os.replace(temporary,self.audit_path)
        return audit["within_limit"]

def completed_json(raw: bytes) -> bool:
    try:
        value=json.loads(raw)
        return isinstance(value,dict) and isinstance(value.get("choices"),list) and bool(value["choices"]) and value["choices"][0].get("finish_reason") in {"stop","length","tool_calls"}
    except (ValueError,AttributeError,IndexError): return False
def sse_event(data: bytes) -> tuple[bool, bool]:
    """Validate one deliberately narrow SSE event: a JSON chunk or final DONE."""
    if data == b"[DONE]":
        return False, True
    try:
        value = json.loads(data)
        choices = value["choices"]
        choice = choices[0]
        finish = choice.get("finish_reason")
    except (ValueError, KeyError, IndexError, TypeError, AttributeError):
        raise GatewayError(502, "sse_malformed", "Backend SSE event violates the completion contract.")
    if not isinstance(value, dict) or not isinstance(choices, list) or not choices or not isinstance(choice, dict):
        raise GatewayError(502, "sse_malformed", "Backend SSE event violates the completion contract.")
    if finish is not None and finish not in {"stop", "length", "tool_calls"}:
        raise GatewayError(502, "sse_malformed", "Backend SSE finish reason is not allowed.")
    return finish is not None, False

def pop_sse_frame(pending: bytes) -> tuple[bytes | None, bytes]:
    """Pop one LF or CRLF-delimited SSE frame without normalizing its data."""
    candidates=[(pending.find(delimiter),delimiter) for delimiter in (b"\r\n\r\n",b"\n\n")]
    candidates=[entry for entry in candidates if entry[0]>=0]
    if not candidates: return None,pending
    index,delimiter=min(candidates,key=lambda entry:entry[0])
    return pending[:index],pending[index+len(delimiter):]

def valid_stream_usage(usage) -> bool:
    if not isinstance(usage,dict): return False
    required={"prompt_tokens","completion_tokens","total_tokens"}
    if not required.issubset(usage) or set(usage)-required-{"prompt_tokens_details"}: return False
    if not all(type(usage[key]) is int and usage[key]>=0 for key in required): return False
    if usage["total_tokens"] != usage["prompt_tokens"]+usage["completion_tokens"]: return False
    details=usage.get("prompt_tokens_details")
    return details is None or (isinstance(details,dict) and set(details)=={"cached_tokens"} and type(details["cached_tokens"]) is int and 0<=details["cached_tokens"]<=usage["prompt_tokens"])

def make_handler(gateway: Gateway):
    class Handler(BaseHTTPRequestHandler):
        # Stable gateway identity. Running source/build revision belongs in
        # deployment provenance and status, not the node-facing HTTP banner.
        server_version = "AgentInferenceGateway"
        sys_version = ""
        def log_message(self, *_): pass  # never emit auth/header/body values
        def setup(self):
            super().setup(); self.connection.settimeout(5)
        def reply(self, status, data, request_id=None):
            if request_id is not None and isinstance(data.get("error"), dict): data["error"]["request_id"] = request_id
            raw=json.dumps(data).encode()
            try:
                self.send_response(status); self.send_header("Content-Type","application/json")
                self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
            except OSError: pass
        def fail(self, error, request_id=None): self.reply(error.status, {"error":{"code":error.code,"message":error.message}}, request_id)
        def sse_failure(self, error, request_id):
            raw=json.dumps({"error":{"code":error.code,"message":error.message,"request_id":request_id}}, separators=(",", ":")).encode()
            try:
                self.wfile.write(b"event: error\ndata: "+raw+b"\n\n"); self.wfile.flush()
            except OSError: pass
        def route(self):
            if self.path not in ("/v1/models", "/v1/chat/completions", "/agent-stack/capacity"): raise GatewayError(404,"route_not_allowed","Route is not allowlisted.")
            if "%" in self.path or "?" in self.path: raise GatewayError(404,"route_not_allowed","Encoded or query routes are not allowed.")
            gateway.authenticate(self.headers.get("Authorization"))
        def do_GET(self):
            try:
                self.route()
                if self.path == "/v1/models":
                    self.reply(200,gateway.models())
                elif self.path == "/agent-stack/capacity":
                    self.reply(200,gateway.capacity())
                else:
                    raise GatewayError(405,"method_not_allowed","Only GET /v1/models or GET /agent-stack/capacity is allowed.")
            except GatewayError as e: self.fail(e)
        def do_POST(self):
            grant=None; slot_acquired=False; response_started=False; request_id=str(uuid.uuid4())
            try:
                self.route()
                if self.path != "/v1/chat/completions": raise GatewayError(405,"method_not_allowed","Only POST chat completions is allowed.")
                if self.headers.get("Content-Type","").split(";",1)[0].lower() != "application/json": raise GatewayError(415,"content_type","application/json required.")
                try: length=int(self.headers.get("Content-Length","-1"))
                except ValueError: raise GatewayError(400,"content_length","Valid Content-Length required.")
                if length < 0 or length > MAX_BODY: raise GatewayError(413,"body_limit","Request body is not bounded.")
                body=self.rfile.read(length)
                if len(body)!=length: raise GatewayError(400,"incomplete_body","Request body ended early.")
                payload=json.loads(body)
                if not isinstance(payload,dict): raise GatewayError(400,"invalid_request","JSON object required.")
                profile=gateway.completion(payload)
                if not gateway.slot.acquire(blocking=False): raise GatewayError(503,"concurrency_limit","Single provider slot is busy.")
                slot_acquired=True
                grant=gateway.admission.acquire(request_id)
                if not gateway.check_context(payload, profile, request_id):
                    # Token counting did not generate or invoke a tool. Reject
                    # this oversized request without poisoning known-idle capacity.
                    gateway.admission.release(grant["grant_id"]); grant=None
                    raise GatewayError(413,"context_limit","Native token count plus output exceeds the reviewed bound.")
                request=Request(gateway.backend+"/v1/chat/completions", data=json.dumps(payload).encode(), headers={"Content-Type":"application/json","Authorization":"Bearer "+gateway.backend_key}, method="POST")
                deadline=time.monotonic()+UPSTREAM_DEADLINE
                with NO_REDIRECT_OPENER.open(request, timeout=UPSTREAM_READ_TIMEOUT) as upstream:
                    if upstream.status != 200: raise GatewayError(502,"backend_status","Backend returned a non-200 response.")
                    content_type=upstream.headers.get("Content-Type", "").split(";",1)[0].lower()
                    if payload.get("stream",False):
                        if content_type != "text/event-stream": raise GatewayError(502,"backend_content_type","Backend did not provide SSE.")
                        pending=b""; total=0; saw_finish=False; saw_done=False; saw_usage=False
                        include_usage=bool(payload.get("stream_options",{}).get("include_usage",False))
                        self.send_response(200); self.send_header("Content-Type","text/event-stream"); self.send_header("Cache-Control","no-cache"); self.send_header("X-Request-Id",request_id); self.end_headers(); response_started=True
                        while True:
                            if time.monotonic() >= deadline: raise GatewayError(502,"upstream_deadline","Backend exceeded the request deadline.")
                            # read1 preserves SSE progress; read(n) may wait for n bytes.
                            chunk=upstream.read1(8192) if hasattr(upstream, "read1") else upstream.read(8192)
                            if not chunk: break
                            total += len(chunk)
                            if total > MAX_RESPONSE: raise GatewayError(502,"response_limit","Backend response exceeded bound.")
                            pending += chunk
                            while True:
                                frame,pending=pop_sse_frame(pending)
                                if frame is None: break
                                lines=frame.splitlines()
                                if len(lines) != 1 or not lines[0].startswith(b"data: "):
                                    raise GatewayError(502,"sse_frame_shape","Backend SSE frame violates the completion contract.")
                                event_data=lines[0][6:]
                                # OpenAI permits one usage-only chunk after the terminal
                                # choice and before [DONE], but only when requested.
                                try: parsed=json.loads(event_data)
                                except (ValueError,UnicodeError): parsed=None
                                if isinstance(parsed,dict) and parsed.get("choices")==[]:
                                    usage=parsed.get("usage")
                                    valid_usage=valid_stream_usage(usage)
                                    if not (include_usage and saw_finish and not saw_done and not saw_usage and valid_usage): raise GatewayError(502,"sse_usage_order","Backend SSE usage ordering violates the completion contract.")
                                    saw_usage=True; gateway.stream_write(self.wfile,b"data: "+event_data+b"\n\n"); continue
                                finished, done=sse_event(event_data)
                                if done:
                                    if not saw_finish or saw_done: raise GatewayError(502,"completion_evidence_missing","Backend SSE ended without valid completion evidence.")
                                    saw_done=True
                                    continue  # Never relay a backend-controlled terminal marker.
                                if saw_finish: raise GatewayError(502,"sse_after_finish","Backend emitted data after final completion.")
                                saw_finish = saw_finish or finished
                                gateway.stream_write(self.wfile, b"data: "+lines[0][6:]+b"\n\n")
                        if pending or not (saw_finish and saw_done): raise GatewayError(502,"completion_evidence_missing","Backend SSE ended without valid completion evidence.")
                        # Publish final success only after the known-complete
                        # backend request has released its admission record.
                        gateway.admission.release(grant["grant_id"]); grant=None
                        gateway.stream_write(self.wfile, b"event: gateway.completion\ndata: "+json.dumps({"id":"chatcmpl-"+request_id,"object":"chat.completion.chunk","created":int(time.time()),"model":profile.profile_id,"choices":[]},separators=(",", ":")).encode()+b"\n\ndata: [DONE]\n\n")
                    else:
                        if content_type != "application/json": raise GatewayError(502,"backend_content_type","Backend did not provide JSON.")
                        captured=b""
                        while True:
                            if time.monotonic() >= deadline: raise GatewayError(502,"upstream_deadline","Backend exceeded the request deadline.")
                            chunk=upstream.read(8192)
                            if not chunk: break
                            captured += chunk
                            if len(captured)>MAX_RESPONSE: raise GatewayError(502,"response_limit","Backend response exceeded bound.")
                        if not completed_json(captured): raise GatewayError(502,"completion_evidence_missing","Backend JSON ended without valid completion evidence.")
                        gateway.admission.release(grant["grant_id"]); grant=None
                        self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(captured))); self.send_header("X-Request-Id",request_id); self.end_headers(); response_started=True; self.wfile.write(captured)
            except (BrokenPipeError, ConnectionResetError):
                if grant: gateway.admission.quarantine(grant["grant_id"],"client-disconnected-completion-unknown"); grant=None
            except (GatewayError, HTTPError, URLError, ValueError, json.JSONDecodeError, OSError, subprocess.SubprocessError) as e:
                reason=e.code if isinstance(e,GatewayError) else ("backend_http_error" if isinstance(e,HTTPError) else "backend_transport_error")
                if grant: gateway.admission.quarantine(grant["grant_id"],reason)
                grant=None
                error=e if isinstance(e,GatewayError) else GatewayError(502,"backend_error","Backend did not provide completion evidence.")
                if response_started and payload.get("stream",False): self.sse_failure(error,request_id)
                elif not response_started: self.fail(error,request_id)
            finally:
                if grant:
                    try: gateway.admission.quarantine(grant["grant_id"],"gateway-unexpected-exit-before-completion-evidence")
                    except Exception: pass
                if slot_acquired: gateway.slot.release()
    return Handler

def serve(deployment_root: str | Path | None = None):
    """Serve the role from an explicit deployment root or the source checkout.

    The root owns the reviewed profile and admission script.  Keeping it an
    argument makes the Python layer package independent of its source-tree
    location while preserving the existing deployment wrapper.
    """
    configured = deployment_root or os.environ.get("AGENT_INFERENCE_DEPLOYMENT_ROOT")
    root=Path(configured).resolve() if configured else Path(__file__).resolve().parents[3]/"deployment"/"inference"
    token=Path(os.environ.get("AGENT_GATEWAY_TOKEN_FILE", r"E:\agent-infrastructure-windows-storage\state\gateway\tokens.json"))
    backend_key=Path(os.environ.get("AGENT_GATEWAY_BACKEND_KEY_FILE", r"E:\agent-infrastructure-windows-storage\state\gateway\backend-api-key.txt"))
    gateway=Gateway(token, backend_key, root/"reviewed-profile.json", PowerShellAdmission(root/"Invoke-InferenceAdmission.ps1"))
    BoundedHTTPServer(("127.0.0.1",18092),make_handler(gateway)).serve_forever()
if __name__ == "__main__": serve()
