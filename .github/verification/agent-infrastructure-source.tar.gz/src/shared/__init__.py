"""Neutral interfaces shared across deployable layers."""
