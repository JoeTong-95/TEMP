"""Shared bounds for the project verification evidence contract."""

MAX_VERIFICATION_ENVELOPE_BYTES = 64 * 1024
# JSON escaping can expand arbitrary UTF-8 diagnostics.  This budget leaves
# enough room for the fixed identity/result envelope while keeping the whole
# serialized response within the public 64 KiB limit.
MAX_VERIFICATION_OUTPUT_BYTES = 8 * 1024
