"""Stable inter-layer contracts and authenticated clients.

This package may define wire validation and clients, but it must not import or
host any layer service implementation.
"""

__all__: tuple[str, ...] = ()
