"""Neutral authenticated client for the stable runtime-bundle Storage contract.

This module intentionally contains transport and wire validation only.  It does
not import the Storage implementation, execute checkpoint receipts, or own a
runtime's local state.  Storage exposes the same client from its historical
module as a compatibility import.
"""
from __future__ import annotations

import base64
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import re
import shutil
import ssl
from typing import Any, Mapping
from urllib.parse import quote, urlsplit


MAX_BODY_BYTES = 16 * 1024 * 1024
MAX_FILES = 64
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_PATH_BYTES = 256
MAX_PATH_DEPTH = 8
MAX_TOKEN_BYTES = 4096
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")


class ServiceError(ValueError):
    """The configured client or a response failed contract validation."""


class UnknownRuntimeBundleOutcome(RuntimeError):
    """A publish may have reached Storage and must be reconciled with fetch."""


def _reject_json_constant(_: str) -> None:
    raise ValueError("non-finite JSON values are unsupported")


def _load_json(raw: bytes) -> Any:
    return json.loads(raw.decode("utf-8"), parse_constant=_reject_json_constant)


def _safe_existing_path(path: Path, *, directory: bool) -> Path:
    if not path.is_absolute():
        raise ServiceError("path must be absolute")
    current = Path(path.anchor)
    for component in path.parts[1:]:
        current /= component
        if current.exists() and current.is_symlink():
            raise ServiceError("symlinked path ancestor is unsafe")
    if path.is_symlink() or (not path.is_dir() if directory else not path.is_file()):
        raise ServiceError("safe local path is unavailable")
    return path


def _token(value: str) -> str:
    if not isinstance(value, str) or not value or any(char.isspace() for char in value):
        raise ServiceError("credential token is invalid")
    try:
        encoded = value.encode("ascii", "strict")
    except UnicodeError as error:
        raise ServiceError("credential token is invalid") from error
    if len(encoded) > MAX_TOKEN_BYTES:
        raise ServiceError("credential token is invalid")
    return value


def _identifier(value: str) -> str:
    if not isinstance(value, str) or not _IDENTIFIER.fullmatch(value):
        raise ServiceError("unsafe route identifier")
    return value


def _safe_relative_file(value: str) -> Path:
    if not isinstance(value, str) or not value or len(value.encode("utf-8")) > MAX_PATH_BYTES:
        raise ServiceError("file path is invalid")
    path = Path(value)
    if path.is_absolute() or ".." in path.parts or len(path.parts) > MAX_PATH_DEPTH:
        raise ServiceError("file path is unsafe")
    return path


def _decode_files(items: Any, destination: Path, max_body_bytes: int, expected_hashes: Mapping[str, str] | None = None) -> None:
    if not isinstance(items, list) or not 1 <= len(items) <= MAX_FILES:
        raise ServiceError("file count is invalid")
    seen: set[str] = set()
    observed: dict[str, str] = {}
    total = 0
    for item in items:
        if not isinstance(item, Mapping) or set(item) != {"path", "base64"}:
            raise ServiceError("file entry is invalid")
        relative = _safe_relative_file(item["path"])
        name = relative.as_posix()
        if name in seen or not isinstance(item["base64"], str):
            raise ServiceError("duplicate or invalid file entry")
        seen.add(name)
        try:
            decoded = base64.b64decode(item["base64"], validate=True)
        except (TypeError, ValueError) as error:
            raise ServiceError("invalid base64") from error
        if len(decoded) > MAX_FILE_BYTES:
            raise ServiceError("file exceeds transport bound")
        total += len(decoded)
        if total > max_body_bytes:
            raise ServiceError("decoded bundle exceeds transport bound")
        target = destination / relative
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        if target.parent.is_symlink() or target.exists() or target.is_symlink():
            raise ServiceError("temporary bundle path is unsafe")
        with target.open("xb") as handle:
            handle.write(decoded)
            handle.flush()
            os.fsync(handle.fileno())
        observed[name] = hashlib.sha256(decoded).hexdigest()
    if expected_hashes is not None:
        if not isinstance(expected_hashes, Mapping) or set(expected_hashes) != set(observed):
            raise ServiceError("response integrity manifest is invalid")
        for name, expected in expected_hashes.items():
            if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected) or observed[name] != expected:
                raise ServiceError("response integrity check failed")


def _encode_files(directory: Path, max_body_bytes: int, expected_hashes: Mapping[str, str] | None = None) -> dict[str, Any]:
    _safe_existing_path(directory, directory=True)
    entries: list[dict[str, str]] = []
    hashes: dict[str, str] = {}
    total = 0
    for source in sorted(directory.rglob("*")):
        if source.is_symlink():
            raise ServiceError("bundle contains a symlink")
        if source.is_dir():
            continue
        if not source.is_file():
            raise ServiceError("bundle contains a special file")
        relative = source.relative_to(directory).as_posix()
        if relative == ".storage.json":
            continue
        _safe_relative_file(relative)
        raw = source.read_bytes()
        if len(raw) > MAX_FILE_BYTES:
            raise ServiceError("file exceeds transport bound")
        total += len(raw)
        if total > max_body_bytes or len(entries) >= MAX_FILES:
            raise ServiceError("bundle exceeds transport bound")
        entries.append({"path": relative, "base64": base64.b64encode(raw).decode("ascii")})
        hashes[relative] = hashlib.sha256(raw).hexdigest()
    if not entries:
        raise ServiceError("bundle has no files")
    if expected_hashes is not None and dict(expected_hashes) != hashes:
        raise ServiceError("bundle integrity check failed")
    payload: dict[str, Any] = {"files": entries, "sha256": hashes}
    if len(json.dumps(payload, separators=(",", ":"), allow_nan=False).encode("utf-8")) > max_body_bytes:
        raise ServiceError("encoded bundle exceeds transport bound")
    return payload


class RuntimeBundleHttpClient:
    """Authenticated client for publish, reconciliation/fetch, and restore."""

    def __init__(self, base_url: str, token: str, *, timeout_seconds: float = 10.0, max_body_bytes: int = MAX_BODY_BYTES, ca_file: str | Path | None = None):
        parsed = urlsplit(base_url)
        try:
            parsed.port
        except ValueError as error:
            raise ServiceError("unsafe runtime bundle client configuration") from error
        loopback = parsed.hostname in {"127.0.0.1", "::1", "localhost"}
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname or (not loopback and parsed.scheme != "https") or parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment or parsed.path not in {"", "/"} or not isinstance(timeout_seconds, (int, float)) or isinstance(timeout_seconds, bool) or not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 60 or type(max_body_bytes) is not int or not 1024 <= max_body_bytes <= MAX_BODY_BYTES):
            raise ServiceError("unsafe runtime bundle client configuration")
        if ca_file is not None and parsed.scheme != "https":
            raise ServiceError("TLS CA is only valid for HTTPS")
        ca_path = _safe_existing_path(Path(ca_file), directory=False) if ca_file is not None else None
        _token(token)
        self._base, self._token, self._timeout, self._limit = parsed, token, float(timeout_seconds), max_body_bytes
        self._context = ssl.create_default_context(cafile=str(ca_path) if ca_path is not None else None) if parsed.scheme == "https" else None

    def _path(self, project_id: str, agent_id: str, checkpoint_id: str, materialize_route: bool = False) -> str:
        values = (_identifier(project_id), _identifier(agent_id), _identifier(checkpoint_id))
        path = "/projects/{}/agents/{}/runtime-bundles/{}".format(*(quote(value, safe="") for value in values))
        return path + ("/materialize" if materialize_route else "")

    def _request(self, method: str, path: str, body: Mapping[str, Any] | None) -> Mapping[str, Any]:
        raw = None if body is None else json.dumps(body, separators=(",", ":"), allow_nan=False).encode("utf-8")
        if raw is not None and len(raw) > self._limit:
            raise ServiceError("request exceeds client bound")
        connection_type = http.client.HTTPSConnection if self._base.scheme == "https" else http.client.HTTPConnection
        if self._context is None:
            connection = connection_type(self._base.hostname, self._base.port, timeout=self._timeout)
        else:
            connection = connection_type(self._base.hostname, self._base.port, timeout=self._timeout, context=self._context)
        try:
            headers = {"Authorization": f"Bearer {self._token}", "Connection": "close"}
            if raw is not None:
                headers["Content-Type"] = "application/json"
            connection.request(method, path, body=raw, headers=headers)
            response = connection.getresponse()
            payload = response.read(self._limit + 1)
            if len(payload) > self._limit:
                raise ServiceError("response exceeds client bound")
            if 300 <= response.status < 400:
                raise ServiceError("redirect refused")
            if response.status != 200:
                raise ServiceError("runtime bundle request rejected")
            value = _load_json(payload)
            if not isinstance(value, Mapping):
                raise ServiceError("runtime bundle response is invalid")
            return value
        finally:
            connection.close()

    def publish(self, source: Path, project_id: str, agent_id: str, checkpoint_id: str) -> Mapping[str, Any]:
        try:
            value = self._request("POST", self._path(project_id, agent_id, checkpoint_id), _encode_files(source, self._limit))
            if value.get("checkpoint_id", checkpoint_id) != checkpoint_id or "files" not in value:
                raise ServiceError("runtime bundle publish receipt is invalid")
            return value
        except (OSError, http.client.HTTPException, TimeoutError) as error:
            raise UnknownRuntimeBundleOutcome("publish outcome is unknown; reconcile before retry") from error

    def fetch(self, project_id: str, agent_id: str, checkpoint_id: str) -> Mapping[str, Any]:
        value = self._request("GET", self._path(project_id, agent_id, checkpoint_id), None)
        if value.get("checkpoint_id", checkpoint_id) != checkpoint_id or "files" not in value:
            raise ServiceError("runtime bundle fetch receipt is invalid")
        return value

    def reconcile(self, project_id: str, agent_id: str, checkpoint_id: str) -> Mapping[str, Any]:
        """Read the durable checkpoint after an unknown publish outcome."""
        return self.fetch(project_id, agent_id, checkpoint_id)

    def materialize(self, project_id: str, agent_id: str, checkpoint_id: str, destination: Path) -> None:
        if not destination.is_absolute() or destination.exists() or destination.is_symlink():
            raise ServiceError("client materialize destination must be absent")
        parent = Path(destination.anchor)
        for component in destination.parent.parts[1:]:
            parent /= component
            if parent.exists() and parent.is_symlink():
                raise ServiceError("client materialize destination has a symlinked ancestor")
        if not destination.parent.is_dir():
            raise ServiceError("client materialize parent is unavailable")
        response = self._request("POST", self._path(project_id, agent_id, checkpoint_id, True), {})
        if response.get("checkpoint_id", checkpoint_id) != checkpoint_id:
            raise ServiceError("runtime bundle materialize receipt is invalid")
        stage = destination.parent / ("." + destination.name + ".pending")
        if stage.exists() or stage.is_symlink():
            raise ServiceError("client materialize has a pending destination")
        stage.mkdir(mode=0o700)
        try:
            _decode_files(response.get("files"), stage, self._limit, response.get("sha256"))
            os.replace(stage, destination)
        except Exception:
            shutil.rmtree(stage, ignore_errors=True)
            raise


__all__ = ("RuntimeBundleHttpClient", "RuntimeBundleClientError", "ServiceError", "UnknownRuntimeBundleOutcome")
RuntimeBundleClientError = ServiceError
