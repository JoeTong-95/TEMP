"""Narrow Management-to-Storage loopback client for typed merge actions."""
from __future__ import annotations

from dataclasses import dataclass
import http.client
import json
import os
from pathlib import Path
from typing import Any, Mapping


class MergeAuthorityClientError(ValueError):
    pass


@dataclass(frozen=True)
class MergeAuthorityClientConfiguration:
    host: str
    port: int
    bearer_token_file: Path
    timeout_seconds: float = 2.0

    def __post_init__(self) -> None:
        path = Path(self.bearer_token_file)
        if self.host != "127.0.0.1" or type(self.port) is not int or not 1 <= self.port <= 65535 or not path.is_absolute() or not path.is_file() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
            raise MergeAuthorityClientError("merge client must name a loopback endpoint and safe token file")
        if os.name == "posix" and path.stat().st_mode & 0o077:
            raise MergeAuthorityClientError("merge client token file must be private")


def build_merge_submitter(configuration: MergeAuthorityClientConfiguration):
    token = configuration.bearer_token_file.read_text(encoding="utf-8").strip()
    if not token or not token.isascii() or any(char.isspace() for char in token):
        raise MergeAuthorityClientError("merge client token is invalid")
    required = {"operation_id", "repo_alias", "pull_number", "head_sha", "verification_operation_id"}
    def submit(request: Mapping[str, Any]) -> Mapping[str, Any]:
        if not isinstance(request, Mapping) or set(request) != required:
            raise MergeAuthorityClientError("merge request schema is invalid")
        raw = json.dumps(dict(request), separators=(",", ":")).encode()
        connection = http.client.HTTPConnection(configuration.host, configuration.port, timeout=configuration.timeout_seconds)
        try:
            connection.request("POST", "/merges", raw, {"Authorization": "Bearer " + token, "Content-Type": "application/json", "Content-Length": str(len(raw))})
            response = connection.getresponse(); payload = response.read(16 * 1024 + 1)
            if response.status != 200 or len(payload) > 16 * 1024:
                raise MergeAuthorityClientError("merge authority rejected request")
            value = json.loads(payload.decode("utf-8"))
            if not isinstance(value, Mapping):
                raise MergeAuthorityClientError("merge authority returned invalid result")
            return dict(value)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
            raise MergeAuthorityClientError("merge authority unavailable") from error
        finally:
            connection.close()
    return submit
