"""Bounded, fail-closed readers for injected secret files."""
from __future__ import annotations

from pathlib import Path


MAX_SECRET_BYTES = 4096
class SecretValidationError(ValueError):
    """Secret contents failed the bounded credential contract."""


def validate_bounded_secret(value: str, *, max_bytes: int = MAX_SECRET_BYTES) -> str:
    """Validate one already-decoded injected secret without normalization."""
    if not isinstance(value, str) or len(value.encode("utf-8")) > max_bytes:
        raise SecretValidationError("secret is invalid")
    if any(ord(character) < 0x20 or ord(character) == 0x7F for character in value):
        raise SecretValidationError("secret contains control characters")
    if not value or not value.isascii() or any(character.isspace() for character in value):
        raise SecretValidationError("secret is invalid")
    return value


def read_bounded_secret(path: Path, *, max_bytes: int = MAX_SECRET_BYTES) -> str:
    """Read one UTF-8 secret while retaining at most ``max_bytes + 1`` bytes.

    Validation happens before trimming so ASCII controls (including newlines)
    can never be normalized into an authorization value.
    """
    with path.open("rb") as stream:
        raw = stream.read(max_bytes + 1)
    if len(raw) > max_bytes:
        raise SecretValidationError("secret file exceeds byte limit")
    value = raw.decode("utf-8")
    return validate_bounded_secret(value)
