"""Authenticated, allowlisted Agent Runtime turn client.

The configured binding owns its base URL, bearer credential, and session id.
Project input can select neither a destination nor a session.  POST outcomes that
may have reached the runtime are deliberately reported as unknown; callers must
reconcile through the read-only operation lookup before considering any retry.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import hashlib
import math
import re
import time
from typing import Any, Callable, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_STATES = frozenset({"running", "completed", "failed", "unknown"})
_MAX_PUBLIC_EFFECT_RESULT_BYTES = 256 * 1024
_FENCE_KEYS = frozenset({"assignment_id", "repository", "issue_number", "approved_spec", "project_revision", "immutable_revision", "ancestry", "frontier_version", "lease_id", "lease_expires_at"})


class RuntimeClientError(ValueError):
    """The configured runtime binding or a definitive runtime rejection is invalid."""


class RuntimeAdmissionRejected(RuntimeClientError):
    """Runtime refused admission with a durable, deterministic reason."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


class RuntimeOutcomeUnknown(RuntimeError):
    """A POST may have reached the runtime; reconcile through ``operation`` first."""


def validate_submission_fence(value: Any, *, now: float | None = None, check_expiry: bool = True) -> dict[str, Any]:
    """Validate and normalize the exact Management assignment frontier fence."""
    if not isinstance(value, Mapping) or set(value) != _FENCE_KEYS:
        raise RuntimeClientError("runtime submission fence is missing or malformed")
    if (not isinstance(value["assignment_id"], str) or _IDENTIFIER.fullmatch(value["assignment_id"]) is None
            or not isinstance(value["repository"], str) or not value["repository"].startswith("https://github.com/")
            or any(type(value[key]) is not int or value[key] < 1 for key in ("issue_number", "approved_spec", "project_revision", "frontier_version"))
            or not isinstance(value["immutable_revision"], str) or re.fullmatch(r"[0-9a-f]{40,64}", value["immutable_revision"]) is None
            or not isinstance(value["ancestry"], list) or not value["ancestry"] or any(type(item) is not int or item < 1 for item in value["ancestry"]) or value["ancestry"][-1] != value["issue_number"]
            or not isinstance(value["lease_id"], str) or _IDENTIFIER.fullmatch(value["lease_id"]) is None):
        raise RuntimeClientError("runtime submission fence identity is invalid")
    expires = value["lease_expires_at"]
    if isinstance(expires, bool): parsed = None
    elif isinstance(expires, (int, float)) and math.isfinite(expires): parsed = float(expires)
    elif isinstance(expires, str):
        try: parsed = datetime.fromisoformat(expires.replace("Z", "+00:00")).astimezone(timezone.utc).timestamp()
        except (TypeError, ValueError, OverflowError): parsed = None
    else: parsed = None
    if parsed is None or (check_expiry and parsed <= (time.time() if now is None else now)):
        raise RuntimeClientError("runtime submission fence lease is expired")
    return json.loads(json.dumps(dict(value), sort_keys=True, separators=(",", ":"), allow_nan=False))


def validate_public_effect_receipt(value: Any, attempt_id: str) -> dict[str, Any] | None:
    """Validate the bounded, non-private effect schema crossing into Runtime."""
    if not isinstance(value, Mapping) or not isinstance(attempt_id, str) or not _IDENTIFIER.fullmatch(attempt_id):
        return None
    state = value.get("state")
    if state == "unknown":
        if set(value) != {"attempt_id", "tool_id", "state"}:
            return None
        if value.get("attempt_id") != attempt_id or not isinstance(value.get("tool_id"), str) or not _IDENTIFIER.fullmatch(value["tool_id"]):
            return None
        return {"attempt_id": attempt_id, "tool_id": value["tool_id"], "state": state}
    if state not in {"completed", "rejected"} or set(value) != {"attempt_id", "tool_id", "state", "result", "result_sha256"}:
        return None
    if value.get("attempt_id") != attempt_id or not isinstance(value.get("tool_id"), str) or not _IDENTIFIER.fullmatch(value["tool_id"]) or not isinstance(value.get("result"), Mapping) or not isinstance(value.get("result_sha256"), str) or re.fullmatch(r"[0-9a-f]{64}", value["result_sha256"]) is None:
        return None
    try:
        canonical = json.dumps(value["result"], sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError):
        return None
    if len(canonical) > _MAX_PUBLIC_EFFECT_RESULT_BYTES or hashlib.sha256(canonical).hexdigest() != value["result_sha256"]:
        return None
    return {"attempt_id": attempt_id, "tool_id": value["tool_id"], "state": state, "result": dict(value["result"]), "result_sha256": value["result_sha256"]}


@dataclass(frozen=True)
class RuntimeBinding:
    """Operator-configured route and credential for one selected runtime session."""

    binding_id: str
    base_url: str
    session_id: str
    token: str = field(repr=False)
    timeout_seconds: float = 5.0

    def __post_init__(self) -> None:
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (self.binding_id, self.session_id)):
            raise RuntimeClientError("binding_id and session_id must be safe configured identifiers")
        if not isinstance(self.token, str) or not self.token:
            raise RuntimeClientError("runtime token is required")
        if isinstance(self.timeout_seconds, bool) or not isinstance(self.timeout_seconds, (int, float)) or not math.isfinite(self.timeout_seconds) or self.timeout_seconds <= 0:
            raise RuntimeClientError("runtime timeout must be positive")
        parsed = urlsplit(self.base_url)
        loopback = parsed.hostname in {"127.0.0.1", "::1", "localhost"}
        if parsed.scheme not in {"http", "https"} or (parsed.scheme == "http" and not loopback):
            raise RuntimeClientError("runtime URL must use HTTPS or loopback HTTP")
        if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path.rstrip("/"):
            raise RuntimeClientError("runtime URL must be a configured origin without credentials or a path")


@dataclass(frozen=True)
class HttpResponse:
    status: int
    body: bytes


Transport = Callable[[str, str, Mapping[str, str], bytes | None, float], HttpResponse]


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, request: Request, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> None:
        return None


def _transport(method: str, url: str, headers: Mapping[str, str], body: bytes | None, timeout: float) -> HttpResponse:
    request = Request(url, data=body, headers=dict(headers), method=method)
    try:
        with build_opener(ProxyHandler({}), _NoRedirect()).open(request, timeout=timeout) as response:
            return HttpResponse(status=response.status, body=response.read(64 * 1024 + 1))
    except HTTPError as error:
        return HttpResponse(status=error.code, body=error.read(64 * 1024 + 1))
    except (OSError, URLError) as error:
        raise RuntimeOutcomeUnknown("runtime transport outcome is unknown") from error


def _json_object(value: bytes) -> dict[str, Any]:
    if len(value) > 64 * 1024:
        raise RuntimeOutcomeUnknown("runtime response exceeded the bounded size")
    try:
        decoded = json.loads(value.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RuntimeOutcomeUnknown("runtime response was malformed") from error
    if not isinstance(decoded, dict):
        raise RuntimeOutcomeUnknown("runtime response must be an object")
    return decoded


class RuntimeClient:
    """One-attempt turn submitter with an explicit, read-only reconciliation path."""

    def __init__(self, bindings: Mapping[str, RuntimeBinding], *, transport: Transport = _transport) -> None:
        if not isinstance(bindings, Mapping) or not bindings:
            raise RuntimeClientError("at least one configured runtime binding is required")
        self._bindings = dict(bindings)
        if any(key != binding.binding_id for key, binding in self._bindings.items()) or not all(isinstance(binding, RuntimeBinding) for binding in self._bindings.values()):
            raise RuntimeClientError("runtime bindings must be keyed by their configured binding_id")
        self._transport = transport

    def _binding(self, binding_id: str) -> RuntimeBinding:
        if not isinstance(binding_id, str) or binding_id not in self._bindings:
            raise RuntimeClientError("runtime binding is not configured")
        return self._bindings[binding_id]

    def binding_identity(self, binding_id: str) -> dict[str, str]:
        binding = self._binding(binding_id)
        return {"binding_id": binding.binding_id, "base_url": binding.base_url, "session_id": binding.session_id}

    @staticmethod
    def _receipt(value: Mapping[str, Any], *, request_id: str, project_id: str, revision_id: str, session_id: str, message_sha256: str, attempt_id: str | None = None, immutable_revision: str | None = None, submission_fence: Mapping[str, Any] | None = None) -> dict[str, Any]:
        if (value.get("request_id") != request_id or value.get("project_id") != project_id or value.get("revision_id") != revision_id or value.get("session_id") != session_id):
            raise RuntimeOutcomeUnknown("runtime receipt does not bind the submitted operation")
        state = value.get("state")
        if state not in _STATES or value.get("message_sha256") != message_sha256:
            raise RuntimeOutcomeUnknown("runtime receipt state is invalid")
        if attempt_id is not None and submission_fence is None:
            raise RuntimeOutcomeUnknown("prepared runtime receipt is missing its submission fence")
        if submission_fence is not None:
            try: expected_fence = validate_submission_fence(submission_fence, check_expiry=False)
            except RuntimeClientError as error: raise RuntimeOutcomeUnknown("runtime submission fence is invalid") from error
            if value.get("frontier_fence") != expected_fence: raise RuntimeOutcomeUnknown("runtime receipt frontier fence is invalid")
        if attempt_id is not None:
            source = value.get("source_identity")
            if not isinstance(source, Mapping) or source.get("attempt_id") != attempt_id or source.get("immutable_revision") != immutable_revision:
                raise RuntimeOutcomeUnknown("runtime receipt source identity is invalid")
            effects = value.get("effect_receipts")
            if not isinstance(effects, list) or len(effects) > 32 or any(validate_public_effect_receipt(effect, attempt_id) is None for effect in effects):
                raise RuntimeOutcomeUnknown("runtime receipt effects are invalid")
        return json.loads(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False))

    @staticmethod
    def _headers(binding: RuntimeBinding) -> dict[str, str]:
        return {"Authorization": f"Bearer {binding.token}", "Content-Type": "application/json", "Accept": "application/json"}

    @staticmethod
    def _admission_rejection(response: HttpResponse) -> RuntimeAdmissionRejected | None:
        """Decode only the Runtime's explicit deterministic rejection envelope."""
        try:
            value = _json_object(response.body)
        except RuntimeOutcomeUnknown:
            return None
        reason = value.get("reason")
        if (set(value) != {"error", "reason"} or not isinstance(reason, str)
                or re.fullmatch(r"[a-z][a-z0-9_.-]{0,63}", reason) is None
                or value.get("error") != "runtime admission blocked: " + reason):
            return None
        return RuntimeAdmissionRejected(reason)

    def prepare_assignment_attempt(self, binding_id: str, *, project_id: str, revision_id: str, immutable_revision: str, assignment_id: str, submission_fence: Mapping[str, Any]) -> dict[str, Any]:
        binding = self._binding(binding_id)
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (project_id, revision_id, assignment_id)) or not isinstance(immutable_revision, str) or re.fullmatch(r"[0-9a-f]{40,64}", immutable_revision) is None:
            raise RuntimeClientError("prepared attempt request is invalid")
        fence = validate_submission_fence(submission_fence)
        if fence["assignment_id"] != assignment_id or fence["immutable_revision"] != immutable_revision or fence["project_revision"] != int(revision_id):
            raise RuntimeClientError("prepared attempt fence does not match request")
        payload = {"project_id": project_id, "revision_id": revision_id, "immutable_revision": immutable_revision, "assignment_id": assignment_id, "submission_fence": fence}
        response = self._transport("POST", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/attempts", self._headers(binding), json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8"), binding.timeout_seconds)
        if response.status in {401, 403, 409}:
            raise RuntimeClientError("runtime rejected prepared attempt")
        if response.status < 200 or response.status >= 300:
            raise RuntimeOutcomeUnknown("prepared attempt outcome is unknown")
        value = _json_object(response.body)
        required = {"attempt_id", "assignment_id", "project_id", "revision_id", "immutable_revision", "workspace", "runtime_home", "receipt_id", "state", "submission_fence"}
        try: returned_fence = validate_submission_fence(value.get("submission_fence"), check_expiry=False)
        except RuntimeClientError as error: raise RuntimeOutcomeUnknown("prepared attempt receipt fence is invalid") from error
        if set(value) != required or returned_fence != fence or any(value.get(key) != expected for key, expected in (("assignment_id", assignment_id), ("project_id", project_id), ("revision_id", revision_id), ("immutable_revision", immutable_revision), ("state", "prepared"))) or not all(isinstance(value.get(key), str) and _IDENTIFIER.fullmatch(value[key]) for key in ("attempt_id", "receipt_id")) or not all(isinstance(value.get(key), str) and value[key] for key in ("workspace", "runtime_home")):
            raise RuntimeOutcomeUnknown("prepared attempt receipt is invalid")
        return json.loads(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False))

    def submit_turn(self, binding_id: str, *, request_id: str, project_id: str, revision_id: str, message: str, attempt_id: str | None = None, immutable_revision: str | None = None, submission_fence: Mapping[str, Any] | None = None) -> dict[str, Any]:
        binding = self._binding(binding_id)
        if not all(isinstance(value, str) and value for value in (request_id, project_id, revision_id, message)) or len(message) > 32 * 1024:
            raise RuntimeClientError("runtime turn fields must be bounded non-empty strings")
        if (attempt_id is None) != (immutable_revision is None) or (attempt_id is not None and (not isinstance(attempt_id, str) or _IDENTIFIER.fullmatch(attempt_id) is None or not isinstance(immutable_revision, str) or re.fullmatch(r"[0-9a-f]{40,64}", immutable_revision) is None or submission_fence is None)):
            raise RuntimeClientError("prepared attempt identity is invalid")
        payload = {"request_id": request_id, "project_id": project_id, "revision_id": revision_id, "message": message}
        if attempt_id is not None:
            payload["attempt_id"] = attempt_id
        if attempt_id is not None:
            fence = validate_submission_fence(submission_fence)
            if fence["immutable_revision"] != immutable_revision: raise RuntimeClientError("prepared attempt fence does not match source revision")
            payload["submission_fence"] = fence
        message_sha256 = hashlib.sha256(message.encode("utf-8")).hexdigest()
        response = self._transport("POST", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/turn", self._headers(binding), json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8"), binding.timeout_seconds)
        if response.status in {401, 403}:
            raise RuntimeClientError("runtime rejected the turn request")
        if response.status == 409:
            rejection = self._admission_rejection(response)
            if rejection is not None:
                raise rejection
            raise RuntimeOutcomeUnknown("runtime turn may have a durable receipt; reconcile it first")
        if 400 <= response.status < 500:
            raise RuntimeOutcomeUnknown("runtime turn may have a durable receipt; reconcile it first")
        if response.status < 200 or response.status >= 300:
            raise RuntimeOutcomeUnknown("runtime submit response is unavailable")
        return self._receipt(_json_object(response.body), request_id=request_id, project_id=project_id, revision_id=revision_id, session_id=binding.session_id, message_sha256=message_sha256, attempt_id=attempt_id, immutable_revision=immutable_revision, submission_fence=submission_fence)

    def operation(self, binding_id: str, *, request_id: str, project_id: str, revision_id: str, message: str, attempt_id: str | None = None, immutable_revision: str | None = None, submission_fence: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        binding = self._binding(binding_id)
        if not all(isinstance(value, str) and value for value in (request_id, project_id, revision_id, message)) or (attempt_id is None) != (immutable_revision is None) or (attempt_id is not None and submission_fence is None):
            raise RuntimeClientError("operation lookup fields are required")
        if attempt_id is not None and validate_submission_fence(submission_fence, check_expiry=False)["immutable_revision"] != immutable_revision:
            raise RuntimeClientError("prepared operation fence does not match source revision")
        response = self._transport("GET", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/operations/" + quote(request_id, safe=""), self._headers(binding), None, binding.timeout_seconds)
        if response.status == 404:
            return None
        if response.status == 409:
            rejection = self._admission_rejection(response)
            if rejection is not None:
                raise rejection
            raise RuntimeOutcomeUnknown("runtime operation conflict is not authoritative")
        if response.status in {401, 403} or 400 <= response.status < 500:
            raise RuntimeClientError("runtime rejected operation lookup")
        if response.status < 200 or response.status >= 300:
            raise RuntimeOutcomeUnknown("runtime lookup response is unavailable")
        return self._receipt(_json_object(response.body), request_id=request_id, project_id=project_id, revision_id=revision_id, session_id=binding.session_id, message_sha256=hashlib.sha256(message.encode("utf-8")).hexdigest(), attempt_id=attempt_id, immutable_revision=immutable_revision, submission_fence=submission_fence)

    def operation_by_fingerprint(self, binding_id: str, *, request_id: str, project_id: str, revision_id: str, message_sha256: str, attempt_id: str | None = None, immutable_revision: str | None = None, submission_fence: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        """Reconcile a persisted operation without retaining injected plaintext."""
        if not isinstance(message_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", message_sha256): raise RuntimeClientError("operation fingerprint is invalid")
        if (attempt_id is None) != (immutable_revision is None) or (attempt_id is not None and submission_fence is None): raise RuntimeClientError("prepared operation identity is invalid")
        if attempt_id is not None and validate_submission_fence(submission_fence, check_expiry=False)["immutable_revision"] != immutable_revision: raise RuntimeClientError("prepared operation fence does not match source revision")
        binding = self._binding(binding_id)
        response = self._transport("GET", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/operations/" + quote(request_id, safe=""), self._headers(binding), None, binding.timeout_seconds)
        if response.status == 404: return None
        if response.status == 409:
            rejection = self._admission_rejection(response)
            if rejection is not None:
                raise rejection
            raise RuntimeOutcomeUnknown("runtime operation conflict is not authoritative")
        if response.status in {401, 403} or 400 <= response.status < 500: raise RuntimeClientError("runtime rejected operation lookup")
        if response.status < 200 or response.status >= 300: raise RuntimeOutcomeUnknown("runtime lookup response is unavailable")
        return self._receipt(_json_object(response.body), request_id=request_id, project_id=project_id, revision_id=revision_id, session_id=binding.session_id, message_sha256=message_sha256, attempt_id=attempt_id, immutable_revision=immutable_revision, submission_fence=submission_fence)

    def binding_operation(self, binding_id: str, *, operation_id: str) -> dict[str, Any] | None:
        binding = self._binding(binding_id)
        if not isinstance(operation_id, str) or _IDENTIFIER.fullmatch(operation_id) is None:
            raise RuntimeClientError("binding operation identity is invalid")
        response = self._transport("GET", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/binding-operations/" + quote(operation_id, safe=""), self._headers(binding), None, binding.timeout_seconds)
        if response.status == 404: return None
        if response.status in {401, 403} or 400 <= response.status < 500: raise RuntimeClientError("runtime rejected binding operation lookup")
        if response.status < 200 or response.status >= 300: raise RuntimeOutcomeUnknown("runtime binding lookup response is unavailable")
        value = _json_object(response.body)
        required = {"session_id", "operation_id", "fingerprint", "expected_revision", "generation", "state", "old_binding_id", "new_binding_id", "checkpoint_id", "project_id", "current_binding_id", "current_revision"}
        if set(value) != required or value.get("operation_id") != operation_id or value.get("session_id") != binding.session_id:
            raise RuntimeOutcomeUnknown("runtime binding operation receipt is invalid")
        expected_fingerprint = hashlib.sha256(json.dumps({"binding_id": value.get("new_binding_id"), "expected_revision": value.get("expected_revision"), "session_id": binding.session_id}, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        if (value.get("old_binding_id") != binding.binding_id
                or not isinstance(value.get("fingerprint"), str) or re.fullmatch(r"[0-9a-f]{64}", value["fingerprint"]) is None or value["fingerprint"] != expected_fingerprint
                or any(not isinstance(value.get(key), str) or _IDENTIFIER.fullmatch(value[key]) is None for key in ("session_id", "operation_id", "old_binding_id", "new_binding_id", "project_id", "current_binding_id"))
                or any(type(value.get(key)) is not int or value[key] < 1 for key in ("expected_revision", "generation", "current_revision"))
                or value["generation"] != value["expected_revision"] + 1):
            raise RuntimeOutcomeUnknown("runtime binding operation receipt is invalid")
        state = value["state"]
        if state == "prepared":
            valid_state = value["checkpoint_id"] is None and value["current_binding_id"] == value["old_binding_id"] and value["current_revision"] == value["expected_revision"]
        elif state == "applied":
            valid_state = (isinstance(value["checkpoint_id"], str) and _IDENTIFIER.fullmatch(value["checkpoint_id"]) is not None
                           and value["current_binding_id"] == value["new_binding_id"] and value["current_revision"] == value["generation"])
        else:
            valid_state = False
        if not valid_state:
            raise RuntimeOutcomeUnknown("runtime binding operation receipt is invalid")
        return value

    def binding_operation_identity(self, identity: Mapping[str, Any], *, operation_id: str) -> dict[str, Any] | None:
        if not isinstance(identity, Mapping) or set(identity) != {"binding_id", "base_url", "session_id"}:
            raise RuntimeClientError("runtime route identity is invalid")
        binding_id = identity.get("binding_id")
        configured = self.binding_identity(binding_id) if isinstance(binding_id, str) else None
        if configured != dict(identity): raise RuntimeClientError("persisted runtime route identity is not configured")
        return self.binding_operation(binding_id, operation_id=operation_id)

    def status(self, binding_id: str) -> dict[str, Any]:
        binding = self._binding(binding_id)
        response = self._transport("GET", binding.base_url + "/sessions/" + quote(binding.session_id, safe=""), self._headers(binding), None, binding.timeout_seconds)
        if response.status in {401, 403} or not 200 <= response.status < 300:
            raise RuntimeClientError("runtime rejected session status")
        return _json_object(response.body)

    def pause(self, binding_id: str) -> dict[str, Any]:
        binding = self._binding(binding_id)
        response = self._transport("POST", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/pause", self._headers(binding), b"{}", binding.timeout_seconds)
        if response.status in {401, 403} or not 200 <= response.status < 300:
            raise RuntimeOutcomeUnknown("runtime pause must be reconciled")
        value = _json_object(response.body)
        if value.get("state") != "paused":
            raise RuntimeOutcomeUnknown("runtime pause receipt is invalid")
        return value

    def resume(self, binding_id: str) -> dict[str, Any]:
        return self._simple(binding_id, "resume", "idle")

    def checkpoint(self, binding_id: str) -> dict[str, Any]:
        binding=self._binding(binding_id); response=self._transport("POST",binding.base_url+"/sessions/"+quote(binding.session_id,safe="")+"/checkpoint",self._headers(binding),b"{}",binding.timeout_seconds)
        if not 200<=response.status<300: raise RuntimeOutcomeUnknown("runtime checkpoint must be reconciled")
        value=_json_object(response.body)
        if not isinstance(value.get("checkpoint_id"),str):raise RuntimeOutcomeUnknown("runtime checkpoint receipt is invalid")
        return value

    def compact(self, binding_id: str, *, operation_id: str, expected_context_revision: int, guidance: str, compaction_tokens: int | None = None) -> dict[str, Any]:
        binding = self._binding(binding_id)
        if not isinstance(operation_id, str) or _IDENTIFIER.fullmatch(operation_id) is None or type(expected_context_revision) is not int or expected_context_revision < 0 or not isinstance(guidance, str) or not guidance.strip() or len(guidance.encode()) > 64 * 1024:
            raise RuntimeClientError("compaction fields are invalid")
        if compaction_tokens is not None and (type(compaction_tokens) is not int or compaction_tokens < 1):
            raise RuntimeClientError("compaction budget is invalid")
        payload = {"operation_id": operation_id, "expected_context_revision": expected_context_revision, "guidance": guidance}
        if compaction_tokens is not None: payload["compaction_tokens"] = compaction_tokens
        response = self._transport("POST", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/compact", self._headers(binding), json.dumps(payload, sort_keys=True, separators=(",", ":")).encode(), binding.timeout_seconds)
        if response.status in {401, 403, 409}: raise RuntimeClientError("runtime rejected compaction")
        if not 200 <= response.status < 300: raise RuntimeOutcomeUnknown("runtime compaction outcome is unknown")
        value = _json_object(response.body)
        previous = value.get("previous_context_revision", value.get("from_revision"))
        new = value.get("new_context_revision", value.get("to_revision"))
        token_proof = (type(value.get("before_tokens")) is int and value["before_tokens"] >= 0
                       and type(value.get("after_tokens")) is int and value["after_tokens"] >= 0)
        receipt_proof = (isinstance(value.get("native_receipt_id"), str) and bool(value["native_receipt_id"].strip())
                         and isinstance(value.get("native_state"), str) and value["native_state"] in {"compacted", "completed"})
        token_fields = {"before_tokens", "after_tokens"} & set(value)
        receipt_fields = {"native_receipt_id", "native_state"} & set(value)
        if (value.get("state") != "compacted" or value.get("session_id") != binding.session_id
                or value.get("operation_id") != operation_id or value.get("expected_context_revision") != expected_context_revision
                or type(previous) is not int or type(new) is not int or previous != expected_context_revision
                or new != expected_context_revision + 1 or not (token_proof or receipt_proof)
                or (token_fields and not token_proof) or (receipt_fields and not receipt_proof)):
            raise RuntimeOutcomeUnknown("runtime compaction receipt is invalid")
        return value

    def _simple(self,binding_id: str, action: str, expected: str) -> dict[str,Any]:
        binding=self._binding(binding_id);response=self._transport("POST",binding.base_url+"/sessions/"+quote(binding.session_id,safe="")+"/"+action,self._headers(binding),b"{}",binding.timeout_seconds)
        if not 200<=response.status<300:raise RuntimeOutcomeUnknown("runtime operation must be reconciled")
        value=_json_object(response.body)
        if value.get("state")!=expected:raise RuntimeOutcomeUnknown("runtime operation receipt is invalid")
        return value

    def update_binding(self, binding_id: str, *, new_binding_id: str, operation_id: str, expected_revision: int) -> dict[str, Any]:
        """Ask the actual Hermes owner to checkpoint and change a logical binding."""
        binding = self._binding(binding_id)
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (new_binding_id, operation_id)) or type(expected_revision) is not int or expected_revision < 1:
            raise RuntimeClientError("binding update fields are invalid")
        fingerprint = hashlib.sha256(json.dumps({"binding_id": new_binding_id, "expected_revision": expected_revision, "session_id": binding.session_id}, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        payload = {"binding_id":new_binding_id,"operation_id":operation_id,"fingerprint":fingerprint,"expected_revision":expected_revision}
        response = self._transport("POST", binding.base_url + "/sessions/" + quote(binding.session_id, safe="") + "/binding", self._headers(binding), json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"), binding.timeout_seconds)
        if response.status in {401, 403}:
            raise RuntimeClientError("runtime rejected binding update")
        if not 200 <= response.status < 300:
            raise RuntimeOutcomeUnknown("runtime binding update must be reconciled")
        value = _json_object(response.body)
        required = {"state", "session_id", "binding_id", "revision", "operation_id", "checkpoint_id", "reconciled"}
        if (set(value) != required or value.get("state") != "updated" or value.get("session_id") != binding.session_id
                or value.get("binding_id") != new_binding_id or value.get("operation_id") != operation_id
                or type(value.get("revision")) is not int or value["revision"] != expected_revision + 1
                or not isinstance(value.get("checkpoint_id"), str) or _IDENTIFIER.fullmatch(value["checkpoint_id"]) is None
                or type(value.get("reconciled")) is not bool):
            raise RuntimeOutcomeUnknown("runtime binding update receipt is invalid")
        return value
