"""Typed contracts for the narrowly supported pilot media capabilities."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import re
from typing import Any, Literal, Mapping, Protocol


ImageModality = Literal["image"]
ImageFormat = Literal["svg"]
ImageMode = Literal["controlled"]
AudioModality = Literal["audio"]
AudioFormat = Literal["wav"]
AudioMode = Literal["controlled"]
VideoModality = Literal["video"]
VideoFormat = Literal["mp4"]
VideoMode = Literal["controlled"]
VideoLifecycle = Literal["asynchronous", "synchronous"]
VideoStatus = Literal["queued", "running", "completed"]
ThreeDModality = Literal["3d"]
ThreeDFormat = Literal["glb"]
ThreeDMode = Literal["controlled"]
ThreeDLifecycle = Literal["asynchronous", "synchronous", "streaming"]
ThreeDStatus = Literal["queued", "running", "completed"]

_PROJECT_ID = re.compile(r"^[a-z][a-z0-9-]{0,63}$")
_REQUEST_ID = re.compile(r"^[A-Za-z0-9._-]{1,80}$")


@dataclass(frozen=True)
class ImageCapability:
    """The one image capability admitted by the v1 pilot."""

    modality: ImageModality = "image"
    format: ImageFormat = "svg"
    mode: ImageMode = "controlled"
    max_prompt_chars: int = 256
    max_width: int = 1024
    max_height: int = 1024


CONTROLLED_IMAGE_CAPABILITY = ImageCapability()


@dataclass(frozen=True)
class ImageJobRequest:
    """Validated request crossing the Management image-job boundary."""

    project_id: str
    request_id: str
    modality: ImageModality
    format: ImageFormat
    mode: ImageMode
    prompt: str
    width: int
    height: int

    @classmethod
    def from_values(
        cls,
        *,
        project_id: object,
        request_id: object,
        modality: object,
        format: object,
        mode: object,
        prompt: object,
        width: object,
        height: object,
        capability: ImageCapability = CONTROLLED_IMAGE_CAPABILITY,
    ) -> "ImageJobRequest":
        if not isinstance(project_id, str) or _PROJECT_ID.fullmatch(project_id) is None:
            raise ValueError("invalid project id")
        if not isinstance(request_id, str) or _REQUEST_ID.fullmatch(request_id) is None:
            raise ValueError("invalid request id")
        if (modality, format, mode) != (capability.modality, capability.format, capability.mode):
            raise ValueError("unsupported image modality, format, or mode")
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= capability.max_prompt_chars:
            raise ValueError(f"prompt must be 1-{capability.max_prompt_chars} characters")
        if any(isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= limit
               for value, limit in ((width, capability.max_width), (height, capability.max_height))):
            raise ValueError(f"image dimensions must be integers from 1 to {max(capability.max_width, capability.max_height)}")
        return cls(project_id, request_id, modality, format, mode, prompt, width, height)


@dataclass(frozen=True)
class ImageArtifact:
    """Stable public image-job response; all successful responses share this shape."""

    job_id: str
    project_id: str
    request_id: str
    modality: ImageModality
    format: ImageFormat
    mode: ImageMode
    status: str
    progress: int
    artifact_reference: str
    artifact_sha256: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AudioCapability:
    """The one audio capability admitted by the v1 pilot."""

    modality: AudioModality = "audio"
    format: AudioFormat = "wav"
    mode: AudioMode = "controlled"
    max_prompt_chars: int = 256
    max_duration_seconds: int = 30


CONTROLLED_AUDIO_CAPABILITY = AudioCapability()


@dataclass(frozen=True)
class AudioJobRequest:
    """Validated request crossing the Management audio-job boundary."""

    project_id: str
    request_id: str
    modality: AudioModality
    format: AudioFormat
    mode: AudioMode
    prompt: str
    duration_seconds: int

    @classmethod
    def from_values(
        cls,
        *,
        project_id: object,
        request_id: object,
        modality: object,
        format: object,
        mode: object,
        prompt: object,
        duration_seconds: object,
        capability: AudioCapability = CONTROLLED_AUDIO_CAPABILITY,
    ) -> "AudioJobRequest":
        if not isinstance(project_id, str) or _PROJECT_ID.fullmatch(project_id) is None:
            raise ValueError("invalid project id")
        if not isinstance(request_id, str) or _REQUEST_ID.fullmatch(request_id) is None:
            raise ValueError("invalid request id")
        if (modality, format, mode) != (capability.modality, capability.format, capability.mode):
            raise ValueError("unsupported audio modality, format, or mode")
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= capability.max_prompt_chars:
            raise ValueError(f"prompt must be 1-{capability.max_prompt_chars} characters")
        if (isinstance(duration_seconds, bool) or not isinstance(duration_seconds, int)
                or not 1 <= duration_seconds <= capability.max_duration_seconds):
            raise ValueError(f"audio duration must be an integer from 1 to {capability.max_duration_seconds} seconds")
        return cls(project_id, request_id, modality, format, mode, prompt, duration_seconds)


@dataclass(frozen=True)
class AudioArtifact:
    """Stable public audio-job response; all successful responses share this shape."""

    job_id: str
    project_id: str
    request_id: str
    modality: AudioModality
    format: AudioFormat
    mode: AudioMode
    status: str
    progress: int
    artifact_reference: str
    artifact_sha256: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class VideoCapability:
    """The one asynchronous video capability admitted by the v1 pilot."""

    modality: VideoModality = "video"
    format: VideoFormat = "mp4"
    mode: VideoMode = "controlled"
    lifecycle: VideoLifecycle = "asynchronous"
    statuses: tuple[VideoStatus, ...] = ("queued", "running", "completed")
    max_prompt_chars: int = 256
    max_width: int = 1920
    max_height: int = 1080
    max_duration_seconds: int = 10

    def __post_init__(self) -> None:
        if self.lifecycle not in ("asynchronous", "synchronous"):
            raise ValueError("video capability declares an unsupported lifecycle")
        if not isinstance(self.statuses, tuple) or not self.statuses:
            raise ValueError("video capability statuses must be a non-empty tuple")
        if self.lifecycle == "synchronous" and self.statuses != ("completed",):
            raise ValueError("synchronous video capabilities must expose only completed")
        if self.lifecycle == "asynchronous":
            if not self.statuses or self.statuses[0] != "queued" or self.statuses[-1] != "completed":
                raise ValueError("asynchronous video capabilities must start queued and end completed")
        if any(status not in ("queued", "running", "completed") for status in self.statuses):
            raise ValueError("video capability declares an unsupported status")
        if tuple(dict.fromkeys(self.statuses)) != self.statuses:
            raise ValueError("video capability statuses must be ordered and unique")


CONTROLLED_VIDEO_CAPABILITY = VideoCapability()


@dataclass(frozen=True)
class VideoJobRequest:
    """Validated request crossing the Management asynchronous video boundary."""

    project_id: str
    request_id: str
    modality: VideoModality
    format: VideoFormat
    mode: VideoMode
    prompt: str
    width: int
    height: int
    duration_seconds: int
    lifecycle: VideoLifecycle = "asynchronous"
    statuses: tuple[VideoStatus, ...] = ("queued", "running", "completed")

    @classmethod
    def from_values(cls, *, project_id: object, request_id: object, modality: object,
                    format: object, mode: object, prompt: object, width: object,
                    height: object, duration_seconds: object,
                    lifecycle: object | None = None, statuses: object | None = None,
                    capability: VideoCapability = CONTROLLED_VIDEO_CAPABILITY) -> "VideoJobRequest":
        if lifecycle is not None or statuses is not None:
            capability = VideoCapability(
                lifecycle=capability.lifecycle if lifecycle is None else lifecycle,  # type: ignore[arg-type]
                statuses=capability.statuses if statuses is None else tuple(statuses),  # type: ignore[arg-type]
                max_prompt_chars=capability.max_prompt_chars,
                max_width=capability.max_width,
                max_height=capability.max_height,
                max_duration_seconds=capability.max_duration_seconds,
            )
        if not isinstance(project_id, str) or _PROJECT_ID.fullmatch(project_id) is None:
            raise ValueError("invalid project id")
        if not isinstance(request_id, str) or _REQUEST_ID.fullmatch(request_id) is None:
            raise ValueError("invalid request id")
        if (modality, format, mode) != (capability.modality, capability.format, capability.mode):
            raise ValueError("unsupported video modality, format, or mode")
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= capability.max_prompt_chars:
            raise ValueError(f"prompt must be 1-{capability.max_prompt_chars} characters")
        if any(isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= limit
               for value, limit in ((width, capability.max_width), (height, capability.max_height))):
            raise ValueError("video dimensions exceed the advertised limits")
        if (isinstance(duration_seconds, bool) or not isinstance(duration_seconds, int)
                or not 1 <= duration_seconds <= capability.max_duration_seconds):
            raise ValueError(f"video duration must be an integer from 1 to {capability.max_duration_seconds} seconds")
        return cls(project_id, request_id, modality, format, mode, prompt, width, height, duration_seconds,
                   capability.lifecycle, capability.statuses)


@dataclass(frozen=True)
class VideoArtifact:
    job_id: str
    project_id: str
    request_id: str
    modality: VideoModality
    format: VideoFormat
    mode: VideoMode
    status: VideoStatus
    progress: int
    artifact_reference: str
    artifact_sha256: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class PilotVideoArtifactStore(Protocol):
    """Narrow Storage-owned interface for durable asynchronous video artifacts."""

    def submit_video(self, request: VideoJobRequest, content: bytes) -> VideoArtifact: ...
    def video_job(self, job_id: str, project_id: str) -> VideoArtifact: ...
    def read_video(self, project_id: str, job_id: str) -> tuple[bytes, str]: ...


@dataclass(frozen=True)
class ThreeDCapability:
    """The one controlled 3D capability admitted by the v1 pilot."""

    modality: ThreeDModality = "3d"
    format: ThreeDFormat = "glb"
    mode: ThreeDMode = "controlled"
    lifecycle: ThreeDLifecycle = "asynchronous"
    statuses: tuple[ThreeDStatus, ...] = ("queued", "running", "completed")
    max_prompt_chars: int = 256

    def __post_init__(self) -> None:
        if self.lifecycle not in ("asynchronous", "synchronous", "streaming"):
            raise ValueError("3D capability declares an unsupported lifecycle")
        if not isinstance(self.statuses, tuple) or not self.statuses:
            raise ValueError("3D capability statuses must be a non-empty tuple")
        if self.lifecycle == "synchronous" and self.statuses != ("completed",):
            raise ValueError("synchronous 3D capabilities must expose only completed")
        if self.lifecycle in ("asynchronous", "streaming") and (
            self.statuses[0] != "queued" or self.statuses[-1] != "completed"
        ):
            raise ValueError(f"{self.lifecycle} 3D capabilities must start queued and end completed")
        if any(status not in ("queued", "running", "completed") for status in self.statuses):
            raise ValueError("3D capability declares an unsupported status")
        if tuple(dict.fromkeys(self.statuses)) != self.statuses:
            raise ValueError("3D capability statuses must be ordered and unique")


CONTROLLED_3D_CAPABILITY = ThreeDCapability()


@dataclass(frozen=True)
class ThreeDJobRequest:
    """Validated request crossing the Management controlled 3D boundary."""

    project_id: str
    request_id: str
    modality: ThreeDModality
    format: ThreeDFormat
    mode: ThreeDMode
    prompt: str
    lifecycle: ThreeDLifecycle = "asynchronous"
    statuses: tuple[ThreeDStatus, ...] = ("queued", "running", "completed")

    @classmethod
    def from_values(cls, *, project_id: object, request_id: object, modality: object,
                    format: object, mode: object, prompt: object,
                    lifecycle: object | None = None, statuses: object | None = None,
                    capability: ThreeDCapability = CONTROLLED_3D_CAPABILITY) -> "ThreeDJobRequest":
        if lifecycle is not None or statuses is not None:
            capability = ThreeDCapability(
                modality=capability.modality, format=capability.format, mode=capability.mode,
                lifecycle=capability.lifecycle if lifecycle is None else lifecycle,  # type: ignore[arg-type]
                statuses=capability.statuses if statuses is None else tuple(statuses),  # type: ignore[arg-type]
                max_prompt_chars=capability.max_prompt_chars,
            )
        if not isinstance(project_id, str) or _PROJECT_ID.fullmatch(project_id) is None:
            raise ValueError("invalid project id")
        if not isinstance(request_id, str) or _REQUEST_ID.fullmatch(request_id) is None:
            raise ValueError("invalid request id")
        if (modality, format, mode) != (capability.modality, capability.format, capability.mode):
            raise ValueError("unsupported 3D modality, format, or mode")
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= capability.max_prompt_chars:
            raise ValueError(f"prompt must be 1-{capability.max_prompt_chars} characters")
        return cls(project_id, request_id, modality, format, mode, prompt,
                   capability.lifecycle, capability.statuses)


@dataclass(frozen=True)
class ThreeDArtifact:
    job_id: str
    project_id: str
    request_id: str
    modality: ThreeDModality
    format: ThreeDFormat
    mode: ThreeDMode
    status: ThreeDStatus
    progress: int
    artifact_reference: str
    artifact_sha256: str
    lifecycle: ThreeDLifecycle = "asynchronous"
    statuses: tuple[ThreeDStatus, ...] = ("queued", "running", "completed")

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class PilotThreeDArtifactStore(Protocol):
    """Narrow Storage-owned interface for durable controlled 3D artifacts."""

    def submit_3d(self, request: ThreeDJobRequest, content: bytes) -> ThreeDArtifact: ...
    def three_d_job(self, job_id: str, project_id: str) -> ThreeDArtifact: ...
    def read_3d(self, project_id: str, job_id: str) -> tuple[bytes, str]: ...


@dataclass(frozen=True)
class StoredAudioArtifact:
    """Storage receipt without a Management-owned HTTP reference."""

    job_id: str
    project_id: str
    request_id: str
    modality: AudioModality
    format: AudioFormat
    mode: AudioMode
    status: str
    progress: int
    artifact_sha256: str


class PilotAudioArtifactStore(Protocol):
    """Narrow Storage-owned interface for durable pilot audio artifacts."""

    def store_audio(self, request: AudioJobRequest, content: bytes) -> StoredAudioArtifact: ...

    def audio_job(self, job_id: str, project_id: str) -> StoredAudioArtifact: ...

    def read_audio(self, project_id: str, job_id: str) -> tuple[bytes, str]: ...


def image_job_payload(value: Mapping[str, Any]) -> ImageJobRequest:
    """Convert an untrusted decoded JSON object to the typed request contract."""
    required = {"project_id", "request_id", "modality", "format", "mode", "prompt", "width", "height"}
    if set(value) != required:
        raise ValueError("image job requires exactly project_id, request_id, modality, format, mode, prompt, width, height")
    return ImageJobRequest.from_values(**value)


def audio_job_payload(value: Mapping[str, Any]) -> AudioJobRequest:
    """Convert an untrusted decoded JSON object to the typed audio request contract."""
    required = {"project_id", "request_id", "modality", "format", "mode", "prompt", "duration_seconds"}
    if set(value) != required:
        raise ValueError("audio job requires exactly project_id, request_id, modality, format, mode, prompt, duration_seconds")
    return AudioJobRequest.from_values(**value)


def video_job_payload(value: Mapping[str, Any]) -> VideoJobRequest:
    required = {"project_id", "request_id", "modality", "format", "mode", "prompt", "width", "height", "duration_seconds"}
    if set(value) != required:
        raise ValueError("video job requires exactly project_id, request_id, modality, format, mode, prompt, width, height, duration_seconds")
    return VideoJobRequest.from_values(**value)


def three_d_job_payload(value: Mapping[str, Any]) -> ThreeDJobRequest:
    required = {"project_id", "request_id", "modality", "format", "mode", "prompt"}
    optional = {"lifecycle", "statuses"}
    if not set(value).issubset(required | optional) or not required.issubset(value):
        raise ValueError("3D job requires project_id, request_id, modality, format, mode, prompt")
    return ThreeDJobRequest.from_values(**value)
