"""Secret-free project reference and storage policy contracts."""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from urllib.parse import parse_qsl, urlsplit
from typing import Any

_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_SENSITIVE_KEYS = frozenset({"secret", "token", "bearer", "password", "passwd", "credential", "private_key", "pem", "api_key", "auth_token", "access_token", "refresh_token", "authorization", "client_secret", "api_secret", "secret_key", "access_key", "private_key"})
PORTABLE_PROJECT_FIELDS = frozenset({"prd_reference", "agents", "resource_requested_envelope", "resource_pool_id", "binding_references", "storage_binding", "forge_binding", "github_frontier", "project_kind", "model_policy", "start_policy", "storage_policy", "provider_reference", "hardware_reference", "repository", "repository_url", "prd", "relationships", "relationship", "skills", "skill", "files", "file", "scope", "resources", "resource", "storage", "default_branch", "issue_tracker", "bootstrap_documents", "bootstrap_document_paths", "checkout_policy", "temporary_checkout_policy"})
PORTABLE_AGENT_FIELDS = frozenset({"id", "role", "capability_bindings", "model_binding", "system_prompt"})
_PEM = re.compile(r"-----BEGIN [^-\r\n]+-----", re.I)
_MODEL_BINDING = _IDENTIFIER
_MAX_AGENT_BINDINGS = 32
_MAX_SYSTEM_PROMPT_BYTES = 16 * 1024

def _sensitive_key(value: str) -> bool:
    normalized = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
    if normalized in _SENSITIVE_KEYS:
        return True
    # Catch conventional secret aliases (x-api-key, oauth_access_token,
    # service_client_secret) while leaving benign words such as tokenizer or
    # accessibility untouched.
    parts = normalized.split("_")
    secret_words = {"secret", "token", "bearer", "password", "passwd", "credential", "authorization", "pem"}
    if any(part in secret_words for part in parts):
        return True
    return any(normalized.endswith("_" + suffix) for suffix in ("api_key", "access_key", "private_key"))


def validate_identifier(value: Any, label: str = "identifier") -> None:
    if not isinstance(value, str) or _IDENTIFIER.fullmatch(value) is None:
        raise ValueError(f"{label} must be a safe identifier")


def validate_reference(value: Any, label: str = "reference") -> None:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError(f"{label} must be a relative POSIX reference")
    parts = value.split("/")
    if any(not part or part in {".", ".."} for part in parts) or value.startswith("/"):
        raise ValueError(f"{label} must be a relative POSIX reference")
    if len(value) > 512:
        raise ValueError(f"{label} is too long")


def _secret_free(value: Any, path: str = "payload", seen: set[int] | None = None) -> None:
    seen = set() if seen is None else seen
    if isinstance(value, Mapping):
        if id(value) in seen:
            raise ValueError("payload contains a cyclic value")
        seen.add(id(value))
        for key, child in value.items():
            if not isinstance(key, str) or not key or len(key) > 128:
                raise ValueError(f"{path} contains an invalid field name")
            if _sensitive_key(key):
                raise ValueError(f"{path}.{key} cannot contain secret material")
            _secret_free(child, f"{path}.{key}", seen)
        seen.remove(id(value))
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        if id(value) in seen:
            raise ValueError("payload contains a cyclic value")
        seen.add(id(value))
        for index, child in enumerate(value):
            _secret_free(child, f"{path}[{index}]", seen)
        seen.remove(id(value))
    elif isinstance(value, str):
        if _PEM.search(value) or re.search(r"\bBearer\s+\S+", value, re.I):
            raise ValueError(f"{path} cannot contain secret material")
        try:
            parsed = urlsplit(value)
            if parsed.scheme and (parsed.username is not None or parsed.password is not None):
                raise ValueError(f"{path} URL cannot contain credentials")
            if any(_sensitive_key(key) for key, _ in parse_qsl(parsed.query, keep_blank_values=True)):
                raise ValueError(f"{path} URL cannot contain secret material")
        except ValueError as error:
            if "secret material" in str(error) or "credentials" in str(error):
                raise


def validate_secret_free(value: Any) -> None:
    """Reject credentials and secret-like material recursively."""
    _secret_free(value)


def validate_agent_definition(value: Any) -> None:
    """Validate the portable agent shape before a draft can be persisted.

    This is shared by the durable save boundary and the orchestrator snapshot
    boundary so optional metadata cannot be accepted by one and rejected by
    the other.
    """
    if not isinstance(value, Mapping) or not set(value).issubset(PORTABLE_AGENT_FIELDS):
        raise ValueError("agent definition contains unsupported fields")
    validate_identifier(value.get("id"), "agent id")
    validate_identifier(value.get("role"), "agent role")
    bindings = value.get("capability_bindings")
    if not isinstance(bindings, list) or not 1 <= len(bindings) <= _MAX_AGENT_BINDINGS:
        raise ValueError("agent capability_bindings must be a non-empty list")
    if any(not isinstance(binding, str) for binding in bindings) or len(set(bindings)) != len(bindings):
        raise ValueError("agent capability_bindings must contain unique strings")
    for binding in bindings:
        validate_identifier(binding, "agent capability binding")
    if "model_binding" in value:
        model_binding = value["model_binding"]
        if not isinstance(model_binding, str) or _MODEL_BINDING.fullmatch(model_binding) is None:
            raise ValueError("agent model_binding must be a safe identifier")
    if "system_prompt" in value:
        system_prompt = value["system_prompt"]
        if not isinstance(system_prompt, str) or not 1 <= len(system_prompt.encode()) <= _MAX_SYSTEM_PROMPT_BYTES:
            raise ValueError("agent system_prompt must be a non-empty string no longer than 16 KiB")


def validate_storage_policy(value: Any) -> None:
    if not isinstance(value, (str, Mapping)) or (isinstance(value, str) and not value.strip()):
        raise ValueError("storage_policy must be a non-empty string or object")
    validate_secret_free(value)


def validate_project_infrastructure_references(value: Mapping[str, Any]) -> None:
    """Validate optional provider and hardware references in a project payload.

    Registration membership is supplied by the owning Management boundary; this
    helper keeps the identifier shape check shared by persistence and
    orchestrator admission.
    """
    if not isinstance(value, Mapping):
        raise ValueError("project payload must be an object")
    if "provider_reference" in value:
        validate_identifier(value["provider_reference"], "provider_reference")
    if "hardware_reference" in value:
        validate_identifier(value["hardware_reference"], "hardware_reference")
