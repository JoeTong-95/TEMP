"""Scoped shared-memory client boundary.

This module deliberately owns no endpoint, socket, bearer token, or ambient
credential lookup.  A deployment injects an already-authenticated transport
(for example, one backed by the restricted Basic Memory gateway).  The adapter
checks the caller's configured grants before every operation; recalled text and
record-provided grants are data, never authority.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import re
from typing import Any, Callable, Mapping


_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_SCOPE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$")
_SENSITIVITIES = frozenset({"normal", "sensitive", "restricted"})
_FRESHNESS = frozenset({"fresh", "stale", "unknown"})
_OPERATIONS = frozenset({"propose", "publish", "read", "correct", "handoff"})
_MAX_CONTENT = 16 * 1024
_MAX_METADATA = 8 * 1024


class SharedMemoryError(ValueError):
    """A caller request, transport response, or scoped-memory policy is invalid."""


class SharedMemoryDenied(SharedMemoryError):
    """The injected caller grant does not authorize this scoped operation."""


@dataclass(frozen=True)
class Provenance:
    source_runtime: str
    actor_id: str


@dataclass(frozen=True)
class RecordGrants:
    """Explicit record policy data, separate from the caller's effective grants."""

    read: tuple[str, ...]
    write: tuple[str, ...]
    disclose: tuple[str, ...]


@dataclass(frozen=True)
class ScopeGrant:
    scope: str
    read: bool = False
    write: bool = False
    disclose: bool = False
    # ``write`` remains the compatibility spelling for publication. New
    # configurations may separate proposal from publication explicitly.
    propose: bool = False
    publish: bool = False


@dataclass(frozen=True)
class AuthenticatedCaller:
    """Identity and grants supplied by trusted service configuration, not content."""

    caller_id: str
    grants: tuple[ScopeGrant, ...]
    project_ids: tuple[str, ...] = ()
    agent_id: str | None = None


@dataclass(frozen=True)
class SharedMemoryRecord:
    record_id: str
    scope: str
    revision: int
    provenance: Provenance
    sensitivity: str
    observed_at: str
    updated_at: str
    freshness: str
    correction_of: str | None
    supersedes: str | None
    deletion_provenance: dict[str, Any]
    grants: RecordGrants
    content: str
    metadata: dict[str, Any]


@dataclass(frozen=True)
class HandoffRead:
    record: SharedMemoryRecord | None
    stale: bool
    incomplete: bool


@dataclass(frozen=True)
class MemoryRequest:
    operation: str
    payload: dict[str, Any]


AuthenticatedTransport = Callable[[MemoryRequest], Mapping[str, Any]]


def _safe_id(value: object, name: str) -> str:
    if not isinstance(value, str) or not _ID.fullmatch(value):
        raise SharedMemoryError(f"{name} must be a safe bounded identifier")
    return value


def _timestamp(value: object, name: str) -> str:
    if not isinstance(value, str) or len(value) > 64:
        raise SharedMemoryError(f"{name} must be an RFC3339 timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise SharedMemoryError(f"{name} must be an RFC3339 timestamp") from error
    if parsed.tzinfo is None:
        raise SharedMemoryError(f"{name} must include a timezone")
    return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _scope(value: object) -> tuple[str, str | None]:
    if not isinstance(value, str):
        raise SharedMemoryError("scope must be a string")
    if value in {"personal.preferences", "personal.history"}:
        return value, None
    for prefix in ("project.", "handoffs."):
        if value.startswith(prefix) and _SCOPE_ID.fullmatch(value[len(prefix):]):
            return value, value[len(prefix):]
    if value.startswith("agent.") and value.endswith(".private"):
        agent_id = value[len("agent."):-len(".private")]
        if _SCOPE_ID.fullmatch(agent_id):
            return value, agent_id
    raise SharedMemoryError("scope is outside the stable allowlist")


def _json_mapping(value: object, name: str, limit: int) -> dict[str, Any]:
    if not isinstance(value, Mapping) or type(value) is not dict:
        raise SharedMemoryError(f"{name} must be a plain object")
    try:
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as error:
        raise SharedMemoryError(f"{name} must be JSON data") from error
    if len(encoded.encode("utf-8")) > limit:
        raise SharedMemoryError(f"{name} exceeds its bounded size")
    decoded = json.loads(encoded)
    if not isinstance(decoded, dict):  # Defensive: retain a copied mapping.
        raise SharedMemoryError(f"{name} must be a plain object")
    return decoded


def _grant_names(value: object, name: str) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)) or len(value) > 64:
        raise SharedMemoryError(f"{name} grant list is invalid")
    names = tuple(_safe_id(item, name) for item in value)
    if len(set(names)) != len(names):
        raise SharedMemoryError(f"{name} grant list has duplicates")
    return names


def _record_grants(value: object) -> RecordGrants:
    if not isinstance(value, Mapping) or set(value) != {"read", "write", "disclose"}:
        raise SharedMemoryError("record grants must have read/write/disclose only")
    return RecordGrants(read=_grant_names(value["read"], "read"), write=_grant_names(value["write"], "write"), disclose=_grant_names(value["disclose"], "disclose"))


def _record(value: object) -> SharedMemoryRecord:
    if not isinstance(value, Mapping) or set(value) != {"record_id", "scope", "revision", "provenance", "sensitivity", "observed_at", "updated_at", "freshness", "correction_of", "supersedes", "deletion_provenance", "grants", "content", "metadata"}:
        raise SharedMemoryError("memory response record schema is invalid")
    record_id = _safe_id(value["record_id"], "record_id")
    scope, _ = _scope(value["scope"])
    if isinstance(value["revision"], bool) or not isinstance(value["revision"], int) or value["revision"] < 1:
        raise SharedMemoryError("record revision is invalid")
    if not isinstance(value["provenance"], Mapping) or set(value["provenance"]) != {"source_runtime", "actor_id"}:
        raise SharedMemoryError("record provenance is invalid")
    provenance = Provenance(_safe_id(value["provenance"]["source_runtime"], "source_runtime"), _safe_id(value["provenance"]["actor_id"], "actor_id"))
    if value["sensitivity"] not in _SENSITIVITIES or value["freshness"] not in _FRESHNESS:
        raise SharedMemoryError("record sensitivity or freshness is invalid")
    if not isinstance(value["content"], str) or len(value["content"].encode("utf-8")) > _MAX_CONTENT:
        raise SharedMemoryError("record content is invalid")
    for name in ("correction_of", "supersedes"):
        if value[name] is not None:
            _safe_id(value[name], name)
    deletion_provenance = _json_mapping(value["deletion_provenance"], "deletion_provenance", _MAX_METADATA)
    if deletion_provenance != {"policy": "append_only", "public_delete": False, "state": "retained"}:
        raise SharedMemoryError("memory deletion provenance is invalid")
    return SharedMemoryRecord(record_id=record_id, scope=scope, revision=value["revision"], provenance=provenance, sensitivity=value["sensitivity"], observed_at=_timestamp(value["observed_at"], "observed_at"), updated_at=_timestamp(value["updated_at"], "updated_at"), freshness=value["freshness"], correction_of=value["correction_of"], supersedes=value["supersedes"], deletion_provenance=deletion_provenance, grants=_record_grants(value["grants"]), content=value["content"], metadata=_json_mapping(value["metadata"], "metadata", _MAX_METADATA))


class SharedMemoryAdapter:
    """Stable scoped client; it cannot route around an injected gateway transport."""

    def __init__(self, transport: AuthenticatedTransport) -> None:
        if not callable(transport):
            raise SharedMemoryError("an injected authenticated transport is required")
        self._transport = transport

    @staticmethod
    def _caller(caller: AuthenticatedCaller) -> AuthenticatedCaller:
        if not isinstance(caller, AuthenticatedCaller):
            raise SharedMemoryDenied("an authenticated caller is required")
        _safe_id(caller.caller_id, "caller_id")
        if not isinstance(caller.grants, tuple) or not caller.grants:
            raise SharedMemoryDenied("caller must have explicit configured grants")
        for project_id in caller.project_ids:
            _safe_id(project_id, "project_id")
        if caller.agent_id is not None:
            _safe_id(caller.agent_id, "agent_id")
        for grant in caller.grants:
            if not isinstance(grant, ScopeGrant):
                raise SharedMemoryDenied("caller grants are invalid")
            _scope(grant.scope)
            if not all(isinstance(permission, bool) for permission in (grant.read, grant.write, grant.disclose, grant.propose, grant.publish)):
                raise SharedMemoryDenied("caller grants are invalid")
        return caller

    @classmethod
    def _authorize(cls, caller: AuthenticatedCaller, scope: str, permission: str) -> None:
        caller = cls._caller(caller)
        _, scoped_id = _scope(scope)
        if scope.startswith(("project.", "handoffs.")) and scoped_id not in caller.project_ids:
            raise SharedMemoryDenied("caller is not configured for this project scope")
        if scope.startswith("agent.") and scoped_id != caller.agent_id:
            raise SharedMemoryDenied("caller is not configured for this private agent scope")
        permission = "publish" if permission == "write" else permission
        if not any(grant.scope == scope and (getattr(grant, permission) or (permission == "publish" and grant.write)) for grant in caller.grants):
            raise SharedMemoryDenied(f"caller lacks {permission} grant for scope")

    def _call(self, operation: str, payload: dict[str, Any]) -> Mapping[str, Any]:
        if operation not in _OPERATIONS:
            raise SharedMemoryError("raw routes and unrecognized memory operations are denied")
        response = self._transport(MemoryRequest(operation=operation, payload=_json_mapping(payload, "request", _MAX_CONTENT + _MAX_METADATA)))
        if not isinstance(response, Mapping) or type(response) is not dict:
            raise SharedMemoryError("authenticated transport response is invalid")
        return response

    @staticmethod
    def _returned_record(response: Mapping[str, Any], payload: Mapping[str, Any]) -> SharedMemoryRecord:
        record = _record(response.get("record"))
        if record.record_id != payload["record_id"] or record.scope != payload["scope"]:
            raise SharedMemoryError("transport returned a record outside the requested scope")
        expected_revision = payload["expected_revision"]
        if expected_revision is not None and record.revision <= expected_revision:
            raise SharedMemoryError("transport did not advance the requested revision")
        expected_provenance = payload["provenance"]
        expected_grants = payload["grants"]
        if (
            record.provenance != Provenance(expected_provenance["source_runtime"], expected_provenance["actor_id"])
            or record.sensitivity != payload["sensitivity"]
            or record.observed_at != payload["observed_at"]
            or record.freshness != payload["freshness"]
            or record.correction_of != payload["correction_of"]
            or record.supersedes != payload["supersedes"]
            or record.content != payload["content"]
            or record.metadata != payload["metadata"]
            or record.grants != RecordGrants(
                read=tuple(expected_grants["read"]),
                write=tuple(expected_grants["write"]),
                disclose=tuple(expected_grants["disclose"]),
            )
        ):
            raise SharedMemoryError("transport changed immutable submitted record data")
        return record

    @staticmethod
    def _write_payload(*, record_id: str, scope: str, expected_revision: int | None, idempotency_key: str, provenance: Provenance, sensitivity: str, observed_at: str, freshness: str, grants: RecordGrants, content: str, metadata: Mapping[str, Any], correction_of: str | None, supersedes: str | None) -> dict[str, Any]:
        _safe_id(record_id, "record_id"); _scope(scope); _safe_id(idempotency_key, "idempotency_key")
        if expected_revision is not None and (isinstance(expected_revision, bool) or not isinstance(expected_revision, int) or expected_revision < 1):
            raise SharedMemoryError("expected_revision must be null or a positive integer")
        if not isinstance(provenance, Provenance): raise SharedMemoryError("provenance is required")
        _safe_id(provenance.source_runtime, "source_runtime"); _safe_id(provenance.actor_id, "actor_id")
        if sensitivity not in _SENSITIVITIES or freshness not in _FRESHNESS: raise SharedMemoryError("sensitivity or freshness is invalid")
        observed_at = _timestamp(observed_at, "observed_at")
        if not isinstance(grants, RecordGrants): raise SharedMemoryError("explicit record grants are required")
        encoded_grants = {"read": list(_grant_names(grants.read, "read")), "write": list(_grant_names(grants.write, "write")), "disclose": list(_grant_names(grants.disclose, "disclose"))}
        if not isinstance(content, str) or len(content.encode("utf-8")) > _MAX_CONTENT: raise SharedMemoryError("content exceeds its bounded size")
        for name, value in (("correction_of", correction_of), ("supersedes", supersedes)):
            if value is not None: _safe_id(value, name)
        if (correction_of is None) != (supersedes is None) or correction_of != supersedes:
            raise SharedMemoryError("correction provenance must be absent or name one superseded record")
        return {"record_id": record_id, "scope": scope, "expected_revision": expected_revision, "idempotency_key": idempotency_key, "provenance": {"source_runtime": provenance.source_runtime, "actor_id": provenance.actor_id}, "sensitivity": sensitivity, "observed_at": observed_at, "freshness": freshness, "grants": encoded_grants, "content": content, "metadata": _json_mapping(metadata, "metadata", _MAX_METADATA), "correction_of": correction_of, "supersedes": supersedes}

    def publish(self, caller: AuthenticatedCaller, **kwargs: Any) -> SharedMemoryRecord:
        scope = kwargs.get("scope"); self._authorize(caller, scope, "write")
        payload = self._write_payload(**kwargs)
        return self._returned_record(self._call("publish", payload), payload)

    def propose(self, caller: AuthenticatedCaller, **kwargs: Any) -> SharedMemoryRecord:
        scope = kwargs.get("scope"); self._authorize(caller, scope, "propose")
        payload = self._write_payload(**kwargs)
        return self._returned_record(self._call("propose", payload), payload)

    def correct(self, caller: AuthenticatedCaller, **kwargs: Any) -> SharedMemoryRecord:
        scope = kwargs.get("scope"); self._authorize(caller, scope, "write")
        payload = self._write_payload(**kwargs)
        if payload["correction_of"] is None or payload["supersedes"] != payload["correction_of"]:
            raise SharedMemoryError("a correction must supersede its correction source")
        return self._returned_record(self._call("correct", payload), payload)

    def read(self, caller: AuthenticatedCaller, *, record_id: str, scope: str) -> SharedMemoryRecord | None:
        _safe_id(record_id, "record_id"); _scope(scope); self._authorize(caller, scope, "read"); self._authorize(caller, scope, "disclose")
        response = self._call("read", {"record_id": record_id, "scope": scope})
        value = response.get("record")
        if value is None: return None
        record = _record(value)
        chain = response.get("supersession_chain")
        if not isinstance(chain,list) or not chain or len(chain)>128 or record.scope != scope: raise SharedMemoryError("transport returned a record outside the requested scope")
        chain_ids=[]
        for link in chain:
            if not isinstance(link,Mapping) or set(link)!={"record_id","supersedes"}: raise SharedMemoryError("transport resolution chain is invalid")
            link_id=_safe_id(link["record_id"], "resolution record_id"); supersedes=link["supersedes"]
            if supersedes is not None: _safe_id(supersedes, "resolution supersedes")
            chain_ids.append(link_id)
        if chain_ids[0]!=record_id or chain_ids[-1]!=record.record_id or len(set(chain_ids))!=len(chain_ids) or chain[-1]["supersedes"]!=record.supersedes or any(chain[index]["supersedes"]!=chain_ids[index-1] for index in range(1,len(chain))): raise SharedMemoryError("transport returned a record outside the requested scope")
        if caller.caller_id not in record.grants.read or caller.caller_id not in record.grants.disclose:
            raise SharedMemoryDenied("record grants do not authorize content disclosure to this caller")
        return record

    def handoff(self, caller: AuthenticatedCaller, *, project_id: str, complete: bool, progress: Mapping[str, Any], **kwargs: Any) -> SharedMemoryRecord:
        _safe_id(project_id, "project_id")
        scope = f"handoffs.{project_id}"
        if kwargs.get("scope") != scope or not isinstance(complete, bool): raise SharedMemoryError("handoff scope and completion marker are required")
        self._authorize(caller, scope, "write")
        metadata = _json_mapping(kwargs.get("metadata", {}), "metadata", _MAX_METADATA)
        metadata["handoff_complete"] = complete; metadata["progress"] = _json_mapping(progress, "progress", _MAX_METADATA // 2)
        kwargs["metadata"] = metadata
        payload = self._write_payload(**kwargs)
        return self._returned_record(self._call("handoff", payload), payload)

    def read_handoff(self, caller: AuthenticatedCaller, *, project_id: str, record_id: str) -> HandoffRead:
        scope = f"handoffs.{_safe_id(project_id, 'project_id')}"; record = self.read(caller, record_id=record_id, scope=scope)
        if record is None: return HandoffRead(record=None, stale=True, incomplete=True)
        return HandoffRead(record=record, stale=record.freshness != "fresh", incomplete=record.metadata.get("handoff_complete") is not True)
