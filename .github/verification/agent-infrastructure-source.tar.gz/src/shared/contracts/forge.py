"""Provider-neutral forge selection shared by project management/provisioning.

GitHub is the platform default for a new project binding.  Gitea remains a
supported local provider, but it is opt-in and must be named by that project's
binding before any Gitea-only service or provisioning path is considered.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import urlsplit

DEFAULT_FORGE_PROVIDER = "github"
SUPPORTED_FORGE_PROVIDERS = frozenset({"github", "gitea"})


def normalize_forge_provider(value: Any = None) -> str:
    """Return a validated provider name, defaulting absent values to GitHub."""
    provider = DEFAULT_FORGE_PROVIDER if value is None else value
    if not isinstance(provider, str) or provider not in SUPPORTED_FORGE_PROVIDERS:
        raise ValueError("forge provider must be github or gitea")
    return provider


def normalize_project_forge_binding(value: Any) -> dict[str, str]:
    """Validate one project's explicit forge URL and non-secret identity.

    This is intentionally a project payload contract: there is no stack-wide
    repository or forge endpoint.  Credentials are referenced by the identity
    name and are never accepted in the project payload.
    """
    if not isinstance(value, dict):
        raise ValueError("forge_binding must be an object")
    allowed = {"provider", "repository_url", "identity"}
    if set(value) - allowed or not isinstance(value.get("repository_url"), str) or not value["repository_url"]:
        raise ValueError("forge_binding requires repository_url and identity")
    try:
        provider = normalize_forge_provider(value.get("provider"))
    except ValueError as error:
        raise ValueError(str(error)) from error
    parsed = urlsplit(value["repository_url"])
    if parsed.scheme not in {"https", "ssh"} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path in {"", "/"}:
        raise ValueError("forge_binding repository_url must be an explicit HTTPS or SSH repository URL")
    identity = value.get("identity")
    if not isinstance(identity, str) or not identity or any(char.isspace() for char in identity) or len(identity) > 128:
        raise ValueError("forge_binding identity must be a non-secret identifier")
    if provider == "gitea" and parsed.hostname in {"github.com", "api.github.com"}:
        raise ValueError("gitea forge_binding cannot target GitHub")
    return {"provider": provider, "repository_url": value["repository_url"], "identity": identity}


def validate_project_forge_binding(value: Any) -> None:
    """Validate one project's explicit forge binding without mutating it."""
    normalize_project_forge_binding(value)
