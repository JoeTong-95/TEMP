"""Explicit external-token shared memory client usable by Hermes and Codex."""
from __future__ import annotations
import http.client,json,os
from dataclasses import dataclass
from pathlib import Path
from typing import Any,Mapping
from .shared_memory import MemoryRequest,SharedMemoryAdapter,SharedMemoryError,AuthenticatedCaller,SharedMemoryRecord,_record

@dataclass(frozen=True)
class SharedMemoryClientConfig:
 host:str;port:int;token_file:Path;caller:AuthenticatedCaller
 def __post_init__(self):
  p=Path(self.token_file)
  if self.host!='127.0.0.1' or type(self.port)is not int or not 1<=self.port<=65535 or not p.is_absolute() or not p.is_file() or p.is_symlink() or any(x.is_symlink() for x in p.parents):raise SharedMemoryError('memory client config invalid')
  if os.name=='posix' and p.stat().st_mode&0o077:raise SharedMemoryError('memory token file is unsafe')
class SharedMemoryHttpClient:
 def __init__(self,config:SharedMemoryClientConfig):
  self.c=config;self.token=config.token_file.read_text(encoding='utf-8').strip()
  if not self.token or not self.token.isascii() or any(x.isspace() for x in self.token):raise SharedMemoryError('memory token invalid')
  self.adapter=SharedMemoryAdapter(self.transport)
 def transport(self,request:MemoryRequest)->Mapping[str,Any]:
  conn=http.client.HTTPConnection(self.c.host,self.c.port,timeout=3);raw=json.dumps({'operation':request.operation,**request.payload},separators=(',',':')).encode()
  try:
   if request.operation=='read':conn.request('GET','/records/'+request.payload['scope']+'/'+request.payload['record_id'],headers={'Authorization':'Bearer '+self.token})
   else:conn.request('POST','/records',raw,{'Authorization':'Bearer '+self.token,'Content-Type':'application/json','Content-Length':str(len(raw))})
   response=conn.getresponse();data=response.read(64*1024+1)
   if response.status!=200 or len(data)>64*1024:raise SharedMemoryError('memory write outcome unknown')
   value=json.loads(data.decode());
   if not isinstance(value,Mapping):raise SharedMemoryError('memory response invalid')
   return dict(value)
  except (OSError,UnicodeDecodeError,json.JSONDecodeError) as e:raise SharedMemoryError('memory transport unavailable') from e
  finally:conn.close()
 def reconcile(self,idempotency_key:str)->Mapping[str,Any]:
  conn=http.client.HTTPConnection(self.c.host,self.c.port,timeout=3)
  try:
   conn.request('GET','/operations/'+idempotency_key,headers={'Authorization':'Bearer '+self.token});res=conn.getresponse();data=res.read(64*1024+1)
   if res.status!=200:raise SharedMemoryError('memory operation pending or unavailable')
   value=json.loads(data.decode());
   if not isinstance(value,Mapping):raise SharedMemoryError('memory reconcile invalid')
   return dict(value)
  finally:conn.close()
 def context(self,scope:str,limit:int=8)->list[SharedMemoryRecord]:
  conn=http.client.HTTPConnection(self.c.host,self.c.port,timeout=3);raw=json.dumps({'scope':scope,'limit':limit}).encode()
  try:
   conn.request('POST','/context',raw,{'Authorization':'Bearer '+self.token,'Content-Type':'application/json','Content-Length':str(len(raw))});res=conn.getresponse();data=res.read(64*1024+1)
   if res.status!=200:raise SharedMemoryError('memory context unavailable')
   value=json.loads(data.decode());return [_record(x) for x in value['records']]
  finally:conn.close()
