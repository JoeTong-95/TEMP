"""Bridge adapter for the Agent Runtime's custom Sandcastle provider.

The adapter starts only the checked-in Node bridge.  It never falls back to a
host process and passes the launch policy over a private stdin control message,
not command-line arguments.  The bridge is responsible for constructing the
Docker/Sandcastle container and emitting the Hermes JSON protocol unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import subprocess
from typing import Any, Mapping, Sequence

from .sandbox_runner import SandboxLaunchSpec, SandboxRunnerError


_DIGEST_PINNED_IMAGE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,190}@sha256:[0-9a-f]{64}\Z")


@dataclass(frozen=True)
class SandcastleBridgeConfiguration:
    node: str
    bridge_path: Path
    package_root: Path
    image: str


class SandcastleBackend:
    """Callable backend accepted by :class:`SandboxRunner`.

    The bridge must already be built from the pinned package manifest.  Missing
    or symlinked bridge assets fail closed; no package manager or installer is
    invoked by this adapter.
    """

    def __init__(self, configuration: SandcastleBridgeConfiguration) -> None:
        self.configuration = configuration
        bridge = configuration.bridge_path
        package_root = configuration.package_root
        if bridge.is_symlink() or not bridge.is_file() or not bridge.is_absolute():
            raise SandboxRunnerError("Sandcastle bridge is unavailable or unsafe")
        if package_root.is_symlink() or not package_root.is_dir() or not package_root.is_absolute() or package_root.resolve() not in bridge.resolve().parents:
            raise SandboxRunnerError("Sandcastle package root is unavailable or unsafe")
        if not isinstance(configuration.image, str) or _DIGEST_PINNED_IMAGE.fullmatch(configuration.image) is None:
            raise SandboxRunnerError("Sandcastle image must be digest-pinned")

    @staticmethod
    def control_request(spec: SandboxLaunchSpec, command: Sequence[str], input: str, env: Mapping[str, str]) -> str:
        if not command or any(not isinstance(item, str) or not item for item in command):
            raise SandboxRunnerError("Sandcastle command is invalid")
        if any(not isinstance(key, str) or not key or not isinstance(value, str) for key, value in env.items()):
            raise SandboxRunnerError("Sandcastle environment is invalid")
        payload = {
            "spec": {
                "profile_id": spec.profile_id,
                "workspace": str(spec.workspace), "home": str(spec.home), "source_root": str(spec.source_root),
                "allowed_network_routes": list(spec.allowed_network_routes),
                "memory_limit_mb": spec.memory_limit_mb, "cpu_limit_seconds": spec.cpu_limit_seconds,
                "pids_limit": spec.pids_limit, "disk_limit_mb": spec.disk_limit_mb,
                "writable_mounts": [str(path) for path in spec.writable_mounts],
                "read_only_mounts": [str(path) for path in spec.read_only_mounts],
                "host_mounts": [], "docker_socket": False, "privileged": False, "windows_interop": False,
            },
            "command": list(command), "input": input, "env": dict(env),
        }
        return json.dumps(payload, separators=(",", ":"))

    def __call__(self, spec: SandboxLaunchSpec, command: Sequence[str], *, input: str, env: Mapping[str, str]):
        request = self.control_request(spec, command, input, env)
        bridge = self.configuration.bridge_path
        launch_env = {"PATH": os.environ.get("PATH", ""), "SYSTEMROOT": os.environ.get("SYSTEMROOT", ""), "AGENT_STACK_SANDBOX_IMAGE": self.configuration.image}
        process = subprocess.Popen(
            [self.configuration.node, str(bridge)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, cwd=str(spec.workspace), env=launch_env,
            start_new_session=(os.name != "nt"),
        )
        # SandboxRunner recognizes this tuple and supplies the control payload
        # to the bridge process instead of the inner Hermes request.
        return process, request
