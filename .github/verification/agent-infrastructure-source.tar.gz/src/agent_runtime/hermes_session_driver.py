"""Local-native Hermes session lifecycle driver without the unsafe one-shot API."""
from __future__ import annotations

import hashlib
import inspect
import json
import os
import re
import sqlite3
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping


_SKILL_VERSION_IDENTIFIER = r"(?:0|[1-9]\d*|[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*)"
_SAFE_SKILL = re.compile(rf"(?:v)?(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-{_SKILL_VERSION_IDENTIFIER}(?:\.{_SKILL_VERSION_IDENTIFIER})*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?\Z")
_SAFE_SKILL_COMMIT = re.compile(r"[0-9a-f]{40}\Z")


def _validated_skills(value: Any, permissions: tuple[str, ...]) -> tuple[dict[str, Any], ...]:
    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        raise HermesSessionError("selected skills are invalid")
    result = []
    for item in value:
        if not isinstance(item, Mapping):
            raise HermesSessionError("selected skill metadata is invalid")
        required = {"project_id", "name", "version", "source", "path", "digest", "tree_digest", "metadata", "permissions", "grants_credentials"}
        if set(item) != required:
            raise HermesSessionError("selected skill metadata is invalid")
        project_id, name, version, source, path = (item[key] for key in ("project_id", "name", "version", "source", "path"))
        if (not isinstance(project_id, str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", project_id) is None
                or not isinstance(name, str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", name) is None
                or not isinstance(version, str) or _SAFE_SKILL.fullmatch(version) is None
                or not isinstance(source, Mapping) or set(source) != {"tag", "commit"}
                or not isinstance(source["tag"], str) or not source["tag"]
                or not isinstance(source["commit"], str) or _SAFE_SKILL_COMMIT.fullmatch(source["commit"]) is None
                or not isinstance(path, str) or not Path(path).is_absolute()):
            raise HermesSessionError("selected skill identity is invalid")
        if Path(path).is_symlink() or Path(path).name != version or Path(path).parent.name != name or Path(path).parent.parent.name != project_id:
            raise HermesSessionError("selected skill projection is invalid")
        digest, tree_digest, metadata, skill_permissions = (item[key] for key in ("digest", "tree_digest", "metadata", "permissions"))
        if (not isinstance(digest, Mapping) or not isinstance(tree_digest, Mapping)
                or not isinstance(metadata, Mapping) or metadata.get("name") != name
                or metadata.get("version") != version or not isinstance(skill_permissions, list)
                or any(not isinstance(permission, str) or permission not in permissions for permission in skill_permissions)
                or item["grants_credentials"] is not False):
            raise HermesSessionError("selected skill permissions or metadata are invalid")
        try:
            copied = json.loads(json.dumps(dict(item), sort_keys=True))
        except (TypeError, ValueError) as error:
            raise HermesSessionError("selected skill metadata is not JSON") from error
        result.append(copied)
    names = [item["name"] for item in result]
    if len(set(names)) != len(names):
        raise HermesSessionError("selected skill identities are duplicated")
    return tuple(result)


class HermesSessionError(ValueError):
    pass


def _require_compaction_contract(method: Callable[..., Any]) -> None:
    """Fail closed unless the native API can enforce both CAS and replay identity.

    A catch-all ``**kwargs`` is intentionally insufficient: it cannot prove that
    the native implementation uses either value before mutating its database.
    """
    try:
        parameters = inspect.signature(method).parameters
    except (TypeError, ValueError) as error:
        raise HermesSessionError("native compaction contract is unavailable") from error
    for name in ("expected_context_revision", "operation_id"):
        parameter = parameters.get(name)
        if parameter is None or parameter.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.VAR_POSITIONAL):
            raise HermesSessionError("native compaction cannot enforce its request contract")


def _validated_compaction_outcome(result: Any, session_id: str, expected_context_revision: int, operation_id: str) -> dict[str, Any]:
    """Require native evidence that this session's persisted context changed."""
    if not isinstance(result, Mapping) or "message" in result:
        raise HermesSessionError("native compaction result is invalid")
    value = dict(result)
    required = {"session_id", "operation_id", "expected_context_revision", "previous_context_revision", "new_context_revision", "before_tokens", "after_tokens", "native_receipt_id", "native_state"}
    if set(value) != required:
        raise HermesSessionError("native compaction result is invalid")
    previous = value["previous_context_revision"]
    new = value["new_context_revision"]
    if (value.get("session_id") != session_id or value.get("operation_id") != operation_id
            or type(value.get("expected_context_revision")) is not int or value["expected_context_revision"] != expected_context_revision
            or type(previous) is not int or type(new) is not int
            or previous != expected_context_revision or new != expected_context_revision + 1):
        raise HermesSessionError("native compaction did not prove a context mutation")
    token_proof = type(value.get("before_tokens")) is int and value["before_tokens"] >= 0 and type(value.get("after_tokens")) is int and value["after_tokens"] >= 0
    receipt_proof = isinstance(value.get("native_receipt_id"), str) and bool(value["native_receipt_id"].strip()) and isinstance(value.get("native_state"), str) and value["native_state"] in {"compacted", "completed"}
    token_fields = {"before_tokens", "after_tokens"} & set(value)
    receipt_fields = {"native_receipt_id", "native_state"} & set(value)
    if (not (token_proof or receipt_proof)
            or (token_fields and not token_proof)
            or (receipt_fields and not receipt_proof)):
        raise HermesSessionError("native compaction receipt lacks mutation evidence")
    return value

AUTH_MODE_API_KEY = "api_key"
AUTH_MODE_SUBSCRIPTION = "subscription"
AUTH_MODES = frozenset({AUTH_MODE_API_KEY, AUTH_MODE_SUBSCRIPTION})


class HermesProviderOutcome(HermesSessionError):
    """A provider response that can be shown without retrying another provider."""

    def __init__(self, category: str, message: str = "provider request was not completed") -> None:
        super().__init__(message)
        self.category = category


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _atomic_json(path: Path, value: Any) -> None:
    fd, pending = tempfile.mkstemp(dir=path.parent, prefix=".pending-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(value, sort_keys=True))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(pending, path)
    finally:
        if os.path.exists(pending):
            os.unlink(pending)


class HermesSessionDriver:
    def __init__(self, home: str | Path, session_id: str, identity: Mapping[str, Any], permissions: list[str], binding: Mapping[str, Any], *, max_iterations: int = 10, max_tokens: int = 128, execution_profile: str = "legacy-hermes", agent_factory: Callable[..., Any] | None = None, skills: list[Mapping[str, Any]] | tuple[Mapping[str, Any], ...] | None = None):
        if not isinstance(session_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", session_id) or not isinstance(permissions, list) or any(not isinstance(item, str) or not item for item in permissions):
            raise HermesSessionError("safe session identity and explicit permissions are required")
        if not isinstance(execution_profile, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", execution_profile):
            raise HermesSessionError("execution profile is unsafe")
        iteration_limit, token_limit = ((10, 128) if execution_profile == "legacy-hermes" else (1000, 1_000_000))
        if not isinstance(max_iterations, int) or isinstance(max_iterations, bool) or not 1 <= max_iterations <= iteration_limit:
            raise HermesSessionError(f"max iterations must be an integer from 1 through {iteration_limit}")
        if not isinstance(max_tokens, int) or isinstance(max_tokens, bool) or not 1 <= max_tokens <= token_limit:
            raise HermesSessionError(f"max tokens must be an integer from 1 through {token_limit}")
        self.home, self.session_id = Path(home), session_id
        self.identity = json.loads(json.dumps(identity))
        self.permissions, self.binding = tuple(permissions), self._binding(binding)
        self.skills = _validated_skills(skills, self.permissions)
        self.execution_profile = execution_profile
        self.max_iterations, self.max_tokens = max_iterations, max_tokens
        self.factory = agent_factory or self._native_factory
        if self.home.exists() and self.home.is_symlink():
            raise HermesSessionError("session home cannot be a symlink")
        self.home.mkdir(parents=True, exist_ok=True)
        self.db, self.meta = self.home / "session.sqlite3", self.home / "session-metadata.json"
        if self.db.is_symlink() or self.meta.is_symlink():
            raise HermesSessionError("session database and metadata cannot be symlinks")
        self._lock, self.active, self.state = threading.Lock(), False, "idle"
        self.last_error: dict[str, str] | None = None
        self._write_or_check_metadata()

    def _write_or_check_metadata(self, *, allow_binding_change: bool = False, expected_existing_binding: Mapping[str, Any] | None = None) -> None:
        record = {"session_id": self.session_id, "identity": self.identity, "permissions": list(self.permissions), "binding": self.binding, "execution_profile": self.execution_profile, "skills": list(self.skills)}
        if self.meta.exists():
            old = json.loads(self.meta.read_text(encoding="utf-8"))
            if expected_existing_binding is not None and old.get("binding") != expected_existing_binding:
                raise HermesSessionError("persisted session binding was tampered with")
            if (old.get("session_id") != record["session_id"]
                    or old.get("identity") != record["identity"]
                    or old.get("permissions") != record["permissions"]
                    or (not allow_binding_change and old.get("binding") != record["binding"])
                    or old.get("execution_profile", "legacy-hermes") != record["execution_profile"]
                    or old.get("skills", []) != record["skills"]):
                raise HermesSessionError("session identity, permissions, or binding are immutable")
        _atomic_json(self.meta, record)

    def run_turn(self, message: str) -> Any:
        with self._lock:
            if self.state != "idle":
                raise HermesSessionError("session is not accepting turns")
            self.active, self.state = True, "running"
        agent: Any | None = None
        try:
            try:
                factory_kwargs = {"session_id": self.session_id, "session_db": self.db, "enabled_toolsets": list(self.permissions), "binding": dict(self.binding), "max_iterations": self.max_iterations, "max_tokens": self.max_tokens, "skip_context_files": True, "skip_memory": True, "fallback_model": None}
                if self.skills:
                    factory_kwargs["enabled_skills"] = list(self.skills)
                agent = self.factory(**factory_kwargs)
            except Exception as error:
                outcome = self._provider_outcome(error)
                if outcome is None:
                    raise
                self.last_error = self._error_record(outcome, error)
                return self._failed_result(self.last_error)
            try:
                system_message = "Managed session identity: " + json.dumps(self.identity, sort_keys=True)
                if self.skills:
                    system_message += "\nSelected Hermes skills: " + json.dumps(list(self.skills), sort_keys=True)
                result = agent.run_conversation(user_message=message, system_message=system_message, conversation_history=None)
            except Exception as error:
                outcome = self._provider_outcome(error)
                if outcome is None:
                    raise
                self.last_error = self._error_record(outcome, error)
                return self._failed_result(self.last_error)
            self.last_error = None
            return result
        finally:
            try:
                if "agent" in locals() and hasattr(agent, "close"):
                    agent.close()
            finally:
                with self._lock:
                    self.active, self.state = False, "paused" if self.state == "pausing" else "idle"

    def compact(self, *, guidance: str, max_tokens: int, expected_context_revision: int, operation_id: str) -> Any:
        """Ask the native session owner to compact its persisted context.

        Compaction is deliberately a native operation; there is no transcript
        rewrite fallback.  This keeps subsequent turns on the same Hermes
        session/database and fails closed for unsupported Hermes releases.
        """
        if (not isinstance(guidance, str) or not guidance.strip() or type(max_tokens) is not int or max_tokens < 1
                or not isinstance(operation_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", operation_id)
                or type(expected_context_revision) is not int or expected_context_revision < 0):
            raise HermesSessionError("compaction configuration is invalid")
        with self._lock:
            if self.state != "idle":
                raise HermesSessionError("session is not accepting compaction")
            self.active, self.state = True, "running"
        try:
            factory_kwargs = {"session_id": self.session_id, "session_db": self.db, "enabled_toolsets": list(self.permissions), "binding": dict(self.binding), "max_iterations": self.max_iterations, "max_tokens": self.max_tokens, "skip_context_files": True, "skip_memory": True, "fallback_model": None}
            if self.skills:
                factory_kwargs["enabled_skills"] = list(self.skills)
            agent = self.factory(**factory_kwargs)
            method = next((getattr(agent, name, None) for name in ("compact_context", "compact_session", "compact") if callable(getattr(agent, name, None))), None)
            if method is None:
                raise HermesSessionError("native Hermes runtime does not support compaction")
            _require_compaction_contract(method)
            result = method(guidance=guidance, max_tokens=max_tokens,
                            expected_context_revision=expected_context_revision,
                            operation_id=operation_id)
            return _validated_compaction_outcome(result, self.session_id, expected_context_revision, operation_id)
        finally:
            try:
                if "agent" in locals() and hasattr(agent, "close"):
                    agent.close()
            finally:
                with self._lock:
                    self.active, self.state = False, "paused" if self.state == "pausing" else "idle"

    def _failed_result(self, error: Mapping[str, str]) -> dict[str, Any]:
        return {"completed": False, "failed": True, "interrupted": False, "partial": False,
                "auth_mode": self.binding.get("auth_mode", AUTH_MODE_API_KEY),
                "last_error": dict(error), "error": dict(error)}

    def _error_record(self, outcome: HermesProviderOutcome, error: Exception) -> dict[str, str]:
        # Keep provider diagnostics structured and non-secret.  In particular,
        # do not serialize upstream messages, which may contain credentials.
        return {"auth_mode": self.binding.get("auth_mode", AUTH_MODE_API_KEY),
                "category": outcome.category, "type": type(error).__name__}

    def request_pause(self) -> str:
        with self._lock:
            if self.active:
                self.state = "pausing"
                return "draining"
            self.state = "paused"
            return "paused"

    def resume(self) -> None:
        with self._lock:
            if self.active or self.state != "paused":
                raise HermesSessionError("resume requires a paused idle session")
            self.state = "idle"

    def update_binding(self, binding: Mapping[str, Any], required_capabilities: list[str]) -> None:
        with self._lock:
            if self.active or self.state not in {"idle", "paused"}:
                raise HermesSessionError("binding changes require an idle or paused boundary")
            if not set(required_capabilities).issubset(set(binding.get("capabilities", []))):
                raise HermesSessionError("new binding lacks required capabilities")
            prior_binding = self.binding
            self.binding = self._binding(binding)
            try:
                self._write_or_check_metadata(allow_binding_change=True, expected_existing_binding=prior_binding)
            except BaseException:
                self.binding = prior_binding
                raise

    def status(self) -> dict[str, Any]:
        """Return the selected provider and auth mode at the attended boundary."""
        with self._lock:
            return {"session_id": self.session_id, "state": self.state,
                    "provider": self.binding["provider"], "model": self.binding["model"],
                    "auth_mode": self.binding.get("auth_mode", AUTH_MODE_API_KEY),
                    "skills": list(self.skills),
                    "last_error": dict(self.last_error) if self.last_error else None}

    def checkpoint(self, directory: str | Path) -> dict[str, Any]:
        with self._lock:
            if self.active or self.state not in {"idle", "paused"}:
                raise HermesSessionError("checkpoint requires idle or paused session")
            raw_target = Path(directory)
            if raw_target.is_symlink():
                raise HermesSessionError("checkpoint directory must be a separate non-symlink directory")
            target = raw_target.resolve()
            if not target.exists() or not target.is_dir() or target == self.home.resolve() or self.home.resolve() in target.parents:
                raise HermesSessionError("checkpoint directory must be a separate non-symlink directory")
            out, manifest = target / f"{self.session_id}.sqlite3", target / f"{self.session_id}.manifest.json"
            if out.exists() or manifest.exists() or out.is_symlink() or manifest.is_symlink():
                raise HermesSessionError("checkpoint target must not overwrite an existing file")
            if not self.db.exists():
                sqlite3.connect(self.db).close()
            source, destination = sqlite3.connect(self.db), sqlite3.connect(out)
            try:
                source.backup(destination)
            finally:
                destination.close()
                source.close()
            result = {"session_id": self.session_id, "identity": self.identity, "permissions": list(self.permissions), "binding": self.binding, "execution_profile": self.execution_profile, "skills": list(self.skills), "database": f"{self.session_id}.sqlite3", "sha256": _hash(out), "created_at": _now()}
            _atomic_json(manifest, result)
            return result

    @classmethod
    def restore(cls, checkpoint_dir: str | Path, new_home: str | Path, *, agent_factory: Callable[..., Any] | None = None):
        raw_root, homes = Path(checkpoint_dir), Path(new_home)
        if raw_root.is_symlink():
            raise HermesSessionError("restore requires one safe manifest and an absent new home")
        root, manifests = raw_root.resolve(), list(raw_root.resolve().glob("*.manifest.json"))
        if root.is_symlink() or len(manifests) != 1 or homes.exists() or manifests[0].is_symlink():
            raise HermesSessionError("restore requires one safe manifest and an absent new home")
        data = json.loads(manifests[0].read_text(encoding="utf-8"))
        source = root / data["database"]
        if not isinstance(data.get("database"), str) or Path(data["database"]).name != data["database"] or source.is_symlink() or not source.is_file() or _hash(source) != data["sha256"]:
            raise HermesSessionError("checkpoint hash mismatch")
        homes.mkdir(parents=True)
        destination = homes / "session.sqlite3"
        src, dst = sqlite3.connect(source), sqlite3.connect(destination)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        check = sqlite3.connect(destination)
        try:
            if check.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise HermesSessionError("restored SQLite is inconsistent")
        finally:
            check.close()
        return cls(homes, data["session_id"], data["identity"], data["permissions"], data["binding"], execution_profile=data.get("execution_profile", "legacy-hermes"), agent_factory=agent_factory, skills=data.get("skills", []))

    @staticmethod
    def _binding(binding: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(binding, Mapping) or set(binding) - {"model", "base_url", "provider", "capabilities", "auth_mode", "auth_type"}:
            raise HermesSessionError("binding contains unsupported or secret-bearing fields")
        result = json.loads(json.dumps(binding))
        if not all(isinstance(result.get(name), str) and result[name].strip() for name in ("model", "provider", "base_url")):
            raise HermesSessionError("binding requires explicit nonempty model, provider, and base_url")
        declared_mode = result.get("auth_mode")
        declared_type = result.get("auth_type")
        if (("auth_mode" in result and not isinstance(declared_mode, str))
                or ("auth_type" in result and not isinstance(declared_type, str))):
            raise HermesSessionError("binding auth_mode and auth_type must be strings")
        if declared_mode is not None and declared_type is not None:
            mode_value = AUTH_MODE_SUBSCRIPTION if declared_mode == "oauth" else declared_mode
            type_value = AUTH_MODE_SUBSCRIPTION if declared_type == "oauth" else declared_type
            if mode_value != type_value:
                raise HermesSessionError("binding auth_mode and auth_type conflict")
            mode = mode_value
        else:
            mode = declared_mode if declared_mode is not None else (declared_type if declared_type is not None else AUTH_MODE_API_KEY)
            if mode == "oauth":
                mode = AUTH_MODE_SUBSCRIPTION
        if mode not in AUTH_MODES:
            raise HermesSessionError("binding auth_mode must be api_key or subscription")
        if "auth_mode" in result or "auth_type" in result or mode == AUTH_MODE_SUBSCRIPTION:
            result["auth_mode"] = mode
        result.pop("auth_type", None)
        if "?" in result["base_url"] or "@" in result["base_url"]:
            raise HermesSessionError("binding URL may not contain credentials or query data")
        return result

    @staticmethod
    def _provider_outcome(error: Exception) -> HermesProviderOutcome | None:
        """Map only recognizable upstream auth/model responses; never retry/fallback."""
        status = getattr(error, "status_code", getattr(error, "status", None))
        if isinstance(status, str) and status.isdigit():
            status = int(status)
        text = str(error).lower()
        name = type(error).__name__.lower()
        # The HTTP status is authoritative.  An upstream 5xx must remain an
        # availability failure even when a response body/class includes auth
        # language such as "logged out" or "malformed refresh".
        if isinstance(status, int) and 500 <= status <= 599:
            return HermesProviderOutcome("provider_unavailable")
        if "refresh" in text and any(token in text for token in ("malformed", "invalid response", "unexpected")):
            return HermesProviderOutcome("auth_refresh_failed")
        if any(token in text or token in name for token in ("logged out", "log out", "logout", "signed out", "signout")):
            return HermesProviderOutcome("auth_logged_out")
        if status in {401, 403} or any(token in text or token in name for token in ("unauthorized", "authentication", "invalid token", "token expired", "expired token")):
            return HermesProviderOutcome("auth_expired")
        if status == 429 or "rate limit" in text or "ratelimit" in name:
            return HermesProviderOutcome("rate_limited")
        # Transport failures are provider availability failures regardless of
        # their message.  Check the explicit exception classes first so a
        # custom/opaque message cannot hide a reset, timeout, or disconnect.
        if isinstance(error, (TimeoutError, ConnectionError)) or status is not None and isinstance(status, int) and 500 <= status <= 599 or any(token in text or token in name for token in (
                "socket timeout", "sockettimedout", "timed out", "timeout",
                "connection reset", "connectionreset", "connection refused",
                "connectionrefused", "broken pipe", "brokenpipe", "provider unavailable",
                "service unavailable", "temporarily unavailable")):
            return HermesProviderOutcome("provider_unavailable")
        if status == 404 or "model" in text and any(token in text for token in ("not found", "unavailable", "does not exist")):
            return HermesProviderOutcome("model_unavailable")
        return None

    @staticmethod
    def _native_factory(**kwargs: Any) -> Any:
        if any(os.environ.get(name) for name in ("HERMES_YOLO_MODE", "HERMES_ACCEPT_HOOKS", "HERMES_KANBAN_TASK")):
            raise HermesSessionError("unsafe Hermes environment flags are forbidden")
        home = os.environ.get("HERMES_HOME")
        if not home or Path(home).resolve() != Path(kwargs["session_db"]).parent.resolve():
            raise HermesSessionError("native adapter requires externally launched isolated HERMES_HOME")
        try:
            from run_agent import AIAgent
            from hermes_state import SessionDB
        except ImportError as error:
            raise HermesSessionError("pinned Hermes native dependency is unavailable; inject an adapter for tests") from error
        return _NativeAdapter(AIAgent, SessionDB, **kwargs)


class _NativeAdapter:
    """Small wrapper around the pinned top-level Hermes APIs only."""
    def __init__(self, agent_type: Any, db_type: Any, *, session_id: str, session_db: str | Path, enabled_toolsets: list[str], binding: Mapping[str, Any], max_iterations: int, max_tokens: int, skip_context_files: bool, skip_memory: bool, fallback_model: Any, enabled_skills: list[Mapping[str, Any]] | None = None) -> None:
        self.db, self.session_id = db_type(db_path=Path(session_db)), session_id
        # Subscription providers resolve their human-enrolled OAuth credential
        # through Hermes' supported auth store. Never pass an API key into that
        # mode, and never configure a fallback model that could bill another path.
        api_key = None if binding.get("auth_mode") == AUTH_MODE_SUBSCRIPTION else os.environ.get("HERMES_MANAGED_API_KEY")
        kwargs = {"base_url": binding.get("base_url"), "api_key": api_key, "provider": binding.get("provider"), "model": binding.get("model", ""), "max_iterations": max_iterations, "max_tokens": max_tokens, "session_id": session_id, "session_db": self.db, "enabled_toolsets": enabled_toolsets, "verbose_logging": False, "quiet_mode": True, "skip_context_files": skip_context_files, "load_soul_identity": False, "skip_memory": skip_memory, "fallback_model": None}
        if enabled_skills:
            kwargs["enabled_skills"] = enabled_skills
        try:
            self.agent = agent_type(**kwargs)
        except Exception:
            close = getattr(self.db, "close", None)
            if callable(close):
                close()
            raise

    def run_conversation(self, *, user_message: Any, system_message: str, conversation_history: Any) -> Any:
        history = self.db.get_messages_as_conversation(self.session_id, include_ancestors=True, repair_alternation=True)
        return self.agent.run_conversation(user_message=user_message, system_message=system_message, conversation_history=history)

    def compact_context(self, *, guidance: str, max_tokens: int, expected_context_revision: int, operation_id: str) -> Mapping[str, Any]:
        method = next((getattr(self.agent, name, None) for name in ("compact_context", "compact_session", "compact") if callable(getattr(self.agent, name, None))), None)
        if method is None:
            raise HermesSessionError("pinned Hermes native API does not expose compaction")
        _require_compaction_contract(method)
        result = method(guidance=guidance, max_tokens=max_tokens,
                        expected_context_revision=expected_context_revision,
                        operation_id=operation_id)
        return _validated_compaction_outcome(result, self.session_id, expected_context_revision, operation_id)

    def close(self) -> None:
        close = getattr(self.agent, "close", None)
        try:
            if callable(close):
                close()
        finally:
            close = getattr(self.db, "close", None)
            if callable(close):
                close()
