"""Durable logical-agent session registry with no runtime side effects."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
import re
from typing import Any, Iterator, Mapping


class RuntimeSessionRegistryError(ValueError): pass
class RuntimeSessionRegistryConflict(RuntimeSessionRegistryError): pass


_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_STATUSES = {"active", "paused", "retired"}


def _has_symlink_ancestor(path: Path, *, include_leaf: bool = False) -> bool:
    """Do not let a durable registry escape through a substituted ancestor."""
    candidate = path if include_leaf else path.parent
    while True:
        if candidate.is_symlink():
            return True
        if candidate.parent == candidate:
            return False
        candidate = candidate.parent


class RuntimeSessionRegistry:
    """Store logical session metadata; callers perform all runtime activation separately."""

    def __init__(self, database: str | Path, *, allowed_binding_ids: frozenset[str], allowed_workspaces: Mapping[str, frozenset[str]]) -> None:
        self.database = Path(database)
        if self.database.is_symlink() or _has_symlink_ancestor(self.database) or not self.database.parent.is_dir() or not isinstance(allowed_binding_ids, frozenset) or not allowed_binding_ids or any(not isinstance(value, str) or not _SAFE.fullmatch(value) for value in allowed_binding_ids): raise RuntimeSessionRegistryError("approved binding identifiers are required")
        if not isinstance(allowed_workspaces, Mapping) or any(not isinstance(project, str) or not _SAFE.fullmatch(project) or not isinstance(workspaces, frozenset) or not workspaces or any(not self._workspace(value) for value in workspaces) for project, workspaces in allowed_workspaces.items()): raise RuntimeSessionRegistryError("approved project workspaces are required")
        self.allowed_binding_ids = frozenset(allowed_binding_ids); self.allowed_workspaces = {project: frozenset(workspaces) for project, workspaces in allowed_workspaces.items()}
        with self._connection() as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS runtime_sessions(session_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,agent_identity TEXT NOT NULL,binding_id TEXT NOT NULL,workspace TEXT NOT NULL,owner_id TEXT NOT NULL,desired_status TEXT NOT NULL,revision INTEGER NOT NULL,native_home_id TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(runtime_sessions)")}
            if "desired_status" not in columns and "status" in columns:
                connection.execute("ALTER TABLE runtime_sessions RENAME COLUMN status TO desired_status")
            elif "desired_status" not in columns:
                raise RuntimeSessionRegistryError("runtime session schema is incompatible")
            connection.execute("CREATE TABLE IF NOT EXISTS binding_operations(session_id TEXT NOT NULL,operation_id TEXT NOT NULL,fingerprint TEXT NOT NULL,expected_revision INTEGER NOT NULL,generation INTEGER NOT NULL,state TEXT NOT NULL,old_binding_id TEXT NOT NULL,new_binding_id TEXT NOT NULL,checkpoint_id TEXT,PRIMARY KEY(session_id,operation_id), UNIQUE(session_id,generation))")

    def has_session(self, session_id: str) -> bool:
        """Existence check used only to prevent a static/dynamic identity collision."""
        if not isinstance(session_id, str) or not _SAFE.fullmatch(session_id):
            return False
        with self._connection() as connection:
            return connection.execute("SELECT 1 FROM runtime_sessions WHERE session_id=?", (session_id,)).fetchone() is not None

    def remove(self, session_id: str, *, actor_role: str, caller_projects: frozenset[str]) -> None:
        """Forget a session whose creation was abandoned before its descriptor became durable."""
        if not isinstance(session_id, str) or not _SAFE.fullmatch(session_id):
            raise RuntimeSessionRegistryError("logical session identity is invalid")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT project_id FROM runtime_sessions WHERE session_id=?", (session_id,)).fetchone()
            if row is None:
                return
            self._scope(row["project_id"], actor_role, caller_projects)
            connection.execute("DELETE FROM runtime_sessions WHERE session_id=?", (session_id,))

    @staticmethod
    def _workspace(value: object) -> bool:
        return isinstance(value, str) and bool(value) and "\\" not in value and not value.startswith("/") and not re.match(r"^[A-Za-z]:", value) and all(part not in {"", ".", ".."} for part in value.split("/"))

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.database); connection.row_factory = sqlite3.Row
        try:
            with connection: yield connection
        finally: connection.close()

    @staticmethod
    def _scope(project_id: str, actor_role: str, caller_projects: frozenset[str]) -> None:
        if actor_role not in {"operator", "controller"} or not isinstance(caller_projects, frozenset) or project_id not in caller_projects: raise RuntimeSessionRegistryError("caller is not scoped for this project")

    def register(self, session_id: str, project_id: str, agent_identity: Mapping[str, Any], binding_id: str, workspace: str, owner_id: str, *, actor_role: str, caller_projects: frozenset[str], expected_revision: int | None = None) -> dict[str, Any]:
        if not isinstance(session_id, str) or not isinstance(project_id, str) or not _SAFE.fullmatch(session_id) or not _SAFE.fullmatch(project_id) or not isinstance(owner_id, str) or not owner_id or binding_id not in self.allowed_binding_ids or workspace not in self.allowed_workspaces.get(project_id, frozenset()) or not isinstance(agent_identity, Mapping) or any(key in agent_identity for key in ("tools", "permissions", "observed_status")):
            raise RuntimeSessionRegistryError("logical session declaration is invalid")
        self._scope(project_id, actor_role, caller_projects)
        if expected_revision is not None: raise RuntimeSessionRegistryConflict("new logical session requires null expected revision")
        identity = json.dumps(agent_identity, sort_keys=True, separators=(",", ":"), allow_nan=False)
        native_home_id = session_id
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if connection.execute("SELECT 1 FROM runtime_sessions WHERE session_id=?", (session_id,)).fetchone(): raise RuntimeSessionRegistryConflict("logical session already exists")
            connection.execute("INSERT INTO runtime_sessions(session_id,project_id,agent_identity,binding_id,workspace,owner_id,desired_status,revision,native_home_id) VALUES(?,?,?,?,?,?, 'active',1,?)", (session_id, project_id, identity, binding_id, workspace, owner_id, native_home_id))
        return self.get(session_id, actor_role=actor_role, caller_projects=caller_projects)

    def update_status(self, session_id: str, status: str, *, actor_role: str, caller_projects: frozenset[str], expected_revision: int) -> dict[str, Any]:
        if status not in _STATUSES or type(expected_revision) is not int or expected_revision < 1: raise RuntimeSessionRegistryError("status or revision is invalid")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE"); row = connection.execute("SELECT project_id,revision FROM runtime_sessions WHERE session_id=?", (session_id,)).fetchone()
            if row is None: raise RuntimeSessionRegistryError("unknown logical session")
            self._scope(row["project_id"], actor_role, caller_projects)
            if row["revision"] != expected_revision: raise RuntimeSessionRegistryConflict("stale logical session revision")
            connection.execute("UPDATE runtime_sessions SET desired_status=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE session_id=?", (status, session_id))
        return self.get(session_id, actor_role=actor_role, caller_projects=caller_projects)

    def begin_binding_operation(self, session_id: str, binding_id: str, operation_id: str, fingerprint: str, *, actor_role: str, caller_projects: frozenset[str], expected_revision: int) -> dict[str, Any]:
        """Durably claim an idempotent binding change before its checkpoint.

        A prepared row survives a process restart; callers can safely resume the
        same operation, but a different request can never overwrite it.
        """
        if binding_id not in self.allowed_binding_ids or type(expected_revision) is not int or expected_revision < 1 or not all(isinstance(value, str) and _SAFE.fullmatch(value) for value in (operation_id, fingerprint)):
            raise RuntimeSessionRegistryError("binding operation is invalid")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE"); row=connection.execute("SELECT project_id,revision,binding_id FROM runtime_sessions WHERE session_id=?",(session_id,)).fetchone()
            if row is None: raise RuntimeSessionRegistryError("unknown logical session")
            self._scope(row["project_id"],actor_role,caller_projects)
            existing=connection.execute("SELECT * FROM binding_operations WHERE session_id=? AND operation_id=?",(session_id,operation_id)).fetchone()
            if existing is not None:
                if existing["fingerprint"] != fingerprint or existing["new_binding_id"] != binding_id or existing["expected_revision"] != expected_revision: raise RuntimeSessionRegistryConflict("binding operation identity conflicts")
                return dict(existing)
            if row["revision"]!=expected_revision: raise RuntimeSessionRegistryConflict("stale logical session revision")
            connection.execute("INSERT INTO binding_operations(session_id,operation_id,fingerprint,expected_revision,generation,state,old_binding_id,new_binding_id,checkpoint_id) VALUES(?,?,?,?,?,'prepared',?,?,NULL)",(session_id,operation_id,fingerprint,expected_revision,expected_revision+1,row["binding_id"],binding_id))
        return {"session_id":session_id,"operation_id":operation_id,"fingerprint":fingerprint,"expected_revision":expected_revision,"generation":expected_revision+1,"state":"prepared","old_binding_id":row["binding_id"],"new_binding_id":binding_id,"checkpoint_id":None}

    def apply_binding_operation(self, session_id: str, operation_id: str, fingerprint: str, checkpoint_id: str, *, actor_role: str, caller_projects: frozenset[str]) -> dict[str, Any]:
        if not all(isinstance(value, str) and _SAFE.fullmatch(value) for value in (operation_id, fingerprint, checkpoint_id)): raise RuntimeSessionRegistryError("binding operation is invalid")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE"); row=connection.execute("SELECT project_id,revision,binding_id FROM runtime_sessions WHERE session_id=?",(session_id,)).fetchone()
            if row is None: raise RuntimeSessionRegistryError("unknown logical session")
            self._scope(row["project_id"],actor_role,caller_projects); op=connection.execute("SELECT * FROM binding_operations WHERE session_id=? AND operation_id=?",(session_id,operation_id)).fetchone()
            if op is None or op["fingerprint"] != fingerprint: raise RuntimeSessionRegistryConflict("binding operation identity conflicts")
            if op["state"] == "applied": return {"binding_id": op["new_binding_id"], "revision": op["generation"], "checkpoint_id": op["checkpoint_id"], "state": "applied", "operation_id": operation_id}
            if row["revision"] != op["expected_revision"] or row["binding_id"] != op["old_binding_id"]: raise RuntimeSessionRegistryConflict("binding operation is stale")
            connection.execute("UPDATE runtime_sessions SET binding_id=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE session_id=?",(op["new_binding_id"],session_id)); connection.execute("UPDATE binding_operations SET state='applied',checkpoint_id=? WHERE session_id=? AND operation_id=?",(checkpoint_id,session_id,operation_id))
        return {"binding_id": op["new_binding_id"], "revision": op["generation"], "checkpoint_id": checkpoint_id, "state":"applied", "operation_id":operation_id}

    def binding_operation(self, session_id: str, operation_id: str, *, actor_role: str, caller_projects: frozenset[str]) -> dict[str, Any]:
        if not isinstance(operation_id, str) or not _SAFE.fullmatch(operation_id): raise RuntimeSessionRegistryError("binding operation is invalid")
        with self._connection() as connection:
            row = connection.execute("SELECT * FROM binding_operations WHERE session_id=? AND operation_id=?", (session_id, operation_id)).fetchone()
        if row is None: raise RuntimeSessionRegistryError("binding operation not found")
        session = self.get(session_id, actor_role=actor_role, caller_projects=caller_projects)
        value = dict(row)
        value.update({"project_id": session["project_id"], "current_binding_id": session["binding_id"], "current_revision": session["revision"]})
        return value

    def get(self, session_id: str, *, actor_role: str, caller_projects: frozenset[str]) -> dict[str, Any]:
        with self._connection() as connection: row = connection.execute("SELECT * FROM runtime_sessions WHERE session_id=?", (session_id,)).fetchone()
        if row is None: raise RuntimeSessionRegistryError("unknown logical session")
        self._scope(row["project_id"], actor_role, caller_projects)
        value = dict(row); value["agent_identity"] = json.loads(value["agent_identity"]); return value

    def list(self, *, actor_role: str, caller_projects: frozenset[str]) -> list[dict[str, Any]]:
        if actor_role not in {"operator", "controller"} or not isinstance(caller_projects, frozenset): raise RuntimeSessionRegistryError("caller is not scoped")
        with self._connection() as connection: rows = connection.execute("SELECT * FROM runtime_sessions WHERE project_id IN (%s) ORDER BY session_id" % ",".join("?" for _ in caller_projects), tuple(sorted(caller_projects))).fetchall() if caller_projects else []
        return [{**dict(row), "agent_identity": json.loads(row["agent_identity"])} for row in rows]
