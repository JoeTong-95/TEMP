"""Explicit loopback host for configured attended chat sessions.

The browser boundary is attended-only.  This entrypoint does not discover a
runtime, create a session, or turn a Management action into a runtime action.
"""
from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from .attended_chat import AttendedChat, AttendedChatConfig, AttendedSession
from shared.contracts.agent_runtime import RuntimeBinding, RuntimeClient
from .runtime_session_registry import RuntimeSessionRegistry


class AttendedChatServiceError(ValueError):
    pass


def _private_file(value: object, label: str) -> Path:
    path = Path(value) if isinstance(value, (str, Path)) else Path()
    if not path.is_absolute() or not path.is_file() or path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise AttendedChatServiceError(f"{label} is unsafe")
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise AttendedChatServiceError(f"{label} must be owner-only")
    return path


@dataclass(frozen=True)
class AttendedChatServiceConfig:
    host: str
    port: int
    state_root: Path
    static_root: Path
    browser_token_file: Path
    runtime_bindings: Mapping[str, RuntimeBinding]
    registry_database: Path
    allowed_workspaces: Mapping[str, frozenset[str]]
    sessions: Mapping[str, AttendedSession]
    secure_cookie: bool = False
    authorization_database: Path | None = None
    project_contexts: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.host != "127.0.0.1" or type(self.port) is not int or not 1 <= self.port <= 65535:
            raise AttendedChatServiceError("attended chat must bind one explicit loopback port")
        if not self.sessions or any(session.runtime_binding_id not in self.runtime_bindings for session in self.sessions.values()):
            raise AttendedChatServiceError("attended sessions must name configured runtime bindings")
        if not self.static_root.is_absolute() or not self.static_root.is_dir() or self.static_root.is_symlink() or any(parent.is_symlink() for parent in self.static_root.parents):
            raise AttendedChatServiceError("attended UI static root is unsafe")


def load_configuration(path: str | Path) -> AttendedChatServiceConfig:
    source = _private_file(path, "attended chat configuration")
    try:
        raw = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise AttendedChatServiceError("attended chat configuration is invalid") from error
    required = {"host", "port", "state_root", "static_root", "browser_token_file", "runtime_bindings", "registry_database", "allowed_workspaces", "sessions"}
    if not isinstance(raw, Mapping) or not required.issubset(raw) or not set(raw).issubset(required | {"secure_cookie", "max_history", "authorization_database", "project_contexts"}):
        raise AttendedChatServiceError("attended chat configuration schema is invalid")
    bindings: dict[str, RuntimeBinding] = {}
    try:
        for binding_id, value in raw["runtime_bindings"].items():
            if not isinstance(value, Mapping) or set(value) - {"base_url", "session_id", "token_file", "timeout_seconds"} or not isinstance(value.get("token_file"), str):
                raise AttendedChatServiceError("attended runtime binding is invalid")
            token = _private_file(value["token_file"], "attended runtime token").read_text(encoding="utf-8").strip()
            bindings[binding_id] = RuntimeBinding(binding_id, value["base_url"], value["session_id"], token, value.get("timeout_seconds", 5.0))
        workspaces = {project: frozenset(values) for project, values in raw["allowed_workspaces"].items()}
        sessions = {key: AttendedSession(**value) for key, value in raw["sessions"].items()}
        contexts = raw.get("project_contexts", {})
        if not isinstance(contexts, Mapping) or any(not isinstance(key, str) or not isinstance(value, Mapping) for key, value in contexts.items()):
            raise AttendedChatServiceError("attended project contexts are invalid")
        return AttendedChatServiceConfig(raw["host"], raw["port"], Path(raw["state_root"]), Path(raw["static_root"]), _private_file(raw["browser_token_file"], "attended browser token"), bindings, Path(raw["registry_database"]), workspaces, sessions, raw.get("secure_cookie", False), Path(raw["authorization_database"]) if raw.get("authorization_database") else None, contexts)
    except (AttributeError, TypeError, ValueError, OSError) as error:
        if isinstance(error, AttendedChatServiceError):
            raise
        raise AttendedChatServiceError("attended chat configuration is invalid") from error


def build(config: AttendedChatServiceConfig):
    # Keep configuration validation importable while the optional browser
    # boundary is independently developed.
    from .attended_chat_api import AttendedChatHttpService
    registry = RuntimeSessionRegistry(config.registry_database, allowed_binding_ids=frozenset(config.runtime_bindings), allowed_workspaces=config.allowed_workspaces)
    resolver = (lambda project_id: config.project_contexts[project_id]) if config.project_contexts else None
    chat = AttendedChat(AttendedChatConfig(config.state_root, config.sessions), RuntimeClient(config.runtime_bindings), registry=registry, project_context_resolver=resolver)
    return AttendedChatHttpService(chat, config.browser_token_file, secure_cookie=config.secure_cookie, static_root=config.static_root, authorization_database=config.authorization_database)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="serve explicitly configured attended chat on loopback")
    parser.add_argument("--config", required=True)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args(argv)
    config = load_configuration(args.config)
    if args.check:
        print("attended chat configuration validated; listener was not started")
        return 0
    from .attended_chat_api import serve
    server = serve(build(config), (config.host, config.port))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
