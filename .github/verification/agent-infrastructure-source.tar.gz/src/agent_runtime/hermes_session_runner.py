"""One-turn, one-process launcher for isolated native Hermes sessions.

The caller owns process creation and supplies an already isolated ``HERMES_HOME``.
This module deliberately neither fixes the environment nor starts a model server.
"""
from __future__ import annotations

import argparse
import contextlib
import json
import os
from pathlib import Path
import re
import stat
import sys
from typing import Any, Callable, Mapping, TextIO
from urllib.parse import urlparse

from .execution_profiles import APPROVED_EXECUTION_PROFILES_ENV, LEGACY_HERMES_PROFILE, STANDALONE_LOCAL_ATTENDED_PROFILE
from .hermes_session_driver import AUTH_MODE_API_KEY, AUTH_MODE_SUBSCRIPTION, HermesSessionDriver, HermesSessionError, _validated_compaction_outcome
from .hermes_workspace_tools import HermesWorkspaceTools, HermesWorkspaceToolError, register_hermes_workspace_toolset
from .skill_releases import SkillReleaseError, SkillReleaseLibrary

MAX_REQUEST_BYTES = 64 * 1024
MAX_ITERATIONS = 10
MAX_TOKENS = 128
SKILL_LIBRARY_ENVIRONMENT = "HERMES_SKILL_RELEASE_LIBRARY"
PROFILE_MAX_ITERATIONS = 1000
PROFILE_MAX_TOKENS = 1_000_000
_UNSAFE_ENVIRONMENT = ("HERMES_YOLO_MODE", "HERMES_ACCEPT_HOOKS", "HERMES_KANBAN_TASK")
_STANDALONE_MANAGED_CLAIM_FIELDS = frozenset(("source_identity", "effect_receipts", "effect_receipt"))


class HermesSessionRunnerError(ValueError):
    """A request or process boundary did not meet the runner contract."""


def _pid_alive(pid: int) -> bool:
    """Return whether a PID is provably live; unknown errors fail closed."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError as error:
        raise HermesSessionRunnerError("runner lock liveness is ambiguous") from error
    return True


def _reconcile_lock(path: Path) -> bool:
    """Remove a runner marker only when its exact PID is provably dead."""
    try:
        if path.is_symlink() or not path.is_file():
            raise HermesSessionRunnerError("runner lock marker is unsafe")
        raw = path.read_bytes()
    except HermesSessionRunnerError:
        raise
    except OSError as error:
        raise HermesSessionRunnerError("runner lock marker is unreadable") from error
    if not raw or not re.fullmatch(rb"[1-9][0-9]{0,9}", raw):
        raise HermesSessionRunnerError("runner lock PID marker is malformed")
    if _pid_alive(int(raw)):
        raise HermesSessionRunnerError("session already has an active or unreconciled runner lock")
    try:
        path.unlink()
        try:
            directory_fd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except PermissionError:
            if os.name != "nt":
                raise
    except OSError as error:
        raise HermesSessionRunnerError("runner lock stale marker could not be reconciled") from error
    return True


class _SessionLock:
    def __init__(self, home: Path) -> None:
        # HermesSessionDriver currently keeps one native database per home, so
        # this lock intentionally serializes every session sharing that home.
        self.path = home / ".turn.lock"
        self._fd: int | None = None

    def __enter__(self) -> "_SessionLock":
        try:
            self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError as error:
            _reconcile_lock(self.path)
            try:
                self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError as retry_error:
                raise HermesSessionRunnerError("session already has an active or unreconciled runner lock") from retry_error
            except OSError as retry_error:
                raise HermesSessionRunnerError("could not acquire session runner lock") from retry_error
        except OSError as error:
            raise HermesSessionRunnerError("could not acquire session runner lock") from error
        payload = str(os.getpid()).encode("ascii")
        try:
            if os.write(self._fd, payload) != len(payload):
                raise OSError("short runner lock write")
            os.fsync(self._fd)
        except OSError as error:
            os.close(self._fd); self._fd = None
            try: self.path.unlink()
            except OSError: pass
            raise HermesSessionRunnerError("could not write session runner lock") from error
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None
            try:
                raw = self.path.read_bytes()
                if raw != str(os.getpid()).encode("ascii"):
                    raise HermesSessionRunnerError("runner lock ownership changed")
                self.path.unlink()
            except HermesSessionRunnerError:
                raise
            except OSError as error:
                raise HermesSessionRunnerError("runner lock cleanup failed") from error


class _DiscardOutput:
    """Do not allow native diagnostics to disclose managed credentials."""

    def write(self, value: str) -> int:
        return len(value)

    def flush(self) -> None:
        return None


def _safe_existing_directory(value: str | Path, label: str) -> Path:
    path = Path(value)
    # Resolve only after proving every existing component is a real directory.
    # In particular, resolving first would silently accept a junction or
    # symlinked ancestor and move the native process outside its authority.
    if not path.is_absolute() or any(_is_reparse_point(component) or component.is_symlink() for component in (path, *path.parents)) or not path.exists() or not path.is_dir():
        raise HermesSessionRunnerError(f"{label} must be an existing non-symlink directory")
    return path


def _is_reparse_point(path: Path) -> bool:
    try:
        return bool(getattr(os.lstat(path), "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    except FileNotFoundError:
        return False
    except OSError:
        return True


def _directory_identity(path: Path) -> tuple[tuple[str, int, int], ...]:
    """Capture directory identities so validation and chdir share authority."""
    result = []
    current = path
    while True:
        try:
            info = os.lstat(current)
        except OSError as error:
            raise HermesSessionRunnerError("directory changed during validation") from error
        if not stat.S_ISDIR(info.st_mode) or _is_reparse_point(current):
            raise HermesSessionRunnerError("directory changed during validation")
        result.append((os.path.normcase(os.path.abspath(os.fspath(current))),
                       int(getattr(info, "st_dev", 0)), int(getattr(info, "st_ino", 0))))
        parent = current.parent
        if parent == current:
            return tuple(result)
        current = parent


def _assert_directory_identity(identity: tuple[tuple[str, int, int], ...]) -> None:
    for name, device, inode in identity:
        try:
            info = os.lstat(name)
        except OSError as error:
            raise HermesSessionRunnerError("directory changed during launch") from error
        if (not stat.S_ISDIR(info.st_mode) or _is_reparse_point(Path(name))
                or (int(getattr(info, "st_dev", 0)), int(getattr(info, "st_ino", 0))) != (device, inode)):
            raise HermesSessionRunnerError("directory changed during launch")


def _read_request(stream: TextIO) -> Mapping[str, Any]:
    raw = stream.read(MAX_REQUEST_BYTES + 1)
    if not isinstance(raw, str):
        raise HermesSessionRunnerError("request input must be text JSON")
    encoded = raw.encode("utf-8")
    if len(encoded) > MAX_REQUEST_BYTES:
        raise HermesSessionRunnerError("request exceeds 64 KiB")
    try:
        request = json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"invalid JSON constant: {value}")))
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise HermesSessionRunnerError("request must be one JSON object") from error
    if not isinstance(request, Mapping):
        raise HermesSessionRunnerError("request must be one JSON object")
    return request


def _configured_execution_profiles() -> frozenset[str]:
    raw = os.environ.get(APPROVED_EXECUTION_PROFILES_ENV)
    if raw is None:
        return frozenset()
    try:
        values = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise HermesSessionRunnerError("configured execution profiles are invalid") from error
    if (not isinstance(values, list)
            or any(not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", value) for value in values)
            or len(set(values)) != len(values)):
        raise HermesSessionRunnerError("configured execution profiles are invalid")
    return frozenset(values)


def _validate_environment(home: Path) -> frozenset[str]:
    if any(os.environ.get(name) for name in _UNSAFE_ENVIRONMENT):
        raise HermesSessionRunnerError("unsafe Hermes environment flags are forbidden")
    value = os.environ.get("HERMES_HOME")
    if not value or Path(value).resolve() != home:
        raise HermesSessionRunnerError("HERMES_HOME must equal the explicit session home")
    return _configured_execution_profiles()


def _skill_library_from_environment() -> SkillReleaseLibrary | None:
    raw = os.environ.get(SKILL_LIBRARY_ENVIRONMENT)
    if raw is None:
        return None
    if len(raw.encode("utf-8")) > MAX_REQUEST_BYTES:
        raise HermesSessionRunnerError("configured skill library is too large")
    required = {"repository_root", "projection_root", "state_path", "runtime_version", "approved_releases", "project_releases"}
    try:
        value = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise HermesSessionRunnerError("configured skill library is invalid") from error
    if (not isinstance(value, Mapping)
            or set(value) - (required | {"proposal_root"})
            or not required.issubset(value)
            or any(not isinstance(value[field], str) or not value[field]
                   for field in ("repository_root", "projection_root", "state_path", "runtime_version"))):
        raise HermesSessionRunnerError("configured skill library is invalid")
    try:
        return SkillReleaseLibrary(
            value["repository_root"], value["projection_root"], value["state_path"],
            runtime_version=value["runtime_version"], approved_releases=value["approved_releases"],
            project_releases=value["project_releases"], proposal_root=value.get("proposal_root"),
        )
    except (SkillReleaseError, OSError, TypeError, ValueError) as error:
        raise HermesSessionRunnerError("configured skill library is invalid") from error


def _validate_request(request: Mapping[str, Any], *, approved_execution_profiles: frozenset[str] | None = None) -> dict[str, Any]:
    required = {"session_id", "identity", "permissions", "binding", "message"}
    optional = {"max_iterations", "max_tokens", "execution_profile", "source_identity", "project_id", "skills"}
    if set(request) - (required | optional) or not required.issubset(request):
        raise HermesSessionRunnerError("request has unsupported or missing fields")
    if not isinstance(request["identity"], Mapping):
        raise HermesSessionRunnerError("identity must be an object")
    session_id = request["session_id"]
    if not isinstance(session_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", session_id):
        raise HermesSessionRunnerError("session_id is unsafe")
    permissions = request["permissions"]
    if not isinstance(permissions, list) or (permissions and (len(permissions) != 1 or not isinstance(permissions[0], str) or not re.fullmatch(r"agentstack_workspace_[A-Za-z0-9_-]{3,63}", permissions[0]))):
        raise HermesSessionRunnerError("native runner permits only one configured workspace toolset")
    if not isinstance(request["message"], str):
        raise HermesSessionRunnerError("message must be a string")
    project_id = request.get("project_id")
    skills = request.get("skills", {})
    if project_id is not None and (not isinstance(project_id, str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", project_id) is None):
        raise HermesSessionRunnerError("project_id is unsafe")
    skill_identifier = r"(?:0|[1-9]\d*|[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*)"
    skill_version = rf"(?:v)?(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-{skill_identifier}(?:\.{skill_identifier})*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?"
    if (not isinstance(skills, Mapping) or any(
            not isinstance(skill_id, str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", skill_id) is None
            or not isinstance(version, str) or re.fullmatch(skill_version, version) is None
            for skill_id, version in skills.items())):
        raise HermesSessionRunnerError("skills must be a mapping of safe IDs to exact versions")
    if skills and project_id is None:
        raise HermesSessionRunnerError("skills require a project_id")
    binding = request["binding"]
    if not isinstance(binding, Mapping):
        raise HermesSessionRunnerError("binding must be an object")
    model, provider, base_url = (binding.get(name) for name in ("model", "provider", "base_url"))
    if not all(isinstance(item, str) and item.strip() for item in (model, provider, base_url)):
        raise HermesSessionRunnerError("binding requires explicit nonempty model, provider, and base_url")
    parsed = urlparse(base_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise HermesSessionRunnerError("binding base_url must be a credential-free HTTP(S) origin")
    declared_mode = binding.get("auth_mode")
    declared_type = binding.get("auth_type")
    if (("auth_mode" in binding and not isinstance(declared_mode, str))
            or ("auth_type" in binding and not isinstance(declared_type, str))):
        raise HermesSessionRunnerError("binding auth_mode and auth_type must be strings")
    if declared_mode is not None and declared_type is not None:
        mode_value = AUTH_MODE_SUBSCRIPTION if declared_mode == "oauth" else declared_mode
        type_value = AUTH_MODE_SUBSCRIPTION if declared_type == "oauth" else declared_type
        if mode_value != type_value:
            raise HermesSessionRunnerError("binding auth_mode and auth_type conflict")
        auth_mode = mode_value
    else:
        auth_mode = declared_mode if declared_mode is not None else (declared_type if declared_type is not None else AUTH_MODE_API_KEY)
        if auth_mode == "oauth":
            auth_mode = AUTH_MODE_SUBSCRIPTION
    if auth_mode not in {AUTH_MODE_API_KEY, AUTH_MODE_SUBSCRIPTION}:
        raise HermesSessionRunnerError("binding auth_mode must be api_key or subscription")
    # Subscription credentials belong to the explicit local attended profile.
    # Managed/automated requests carry an execution profile (and, for managed
    # work, a source identity); neither may ever select a user's subscription.
    execution_profile = request.get("execution_profile", "legacy-hermes")
    if auth_mode == AUTH_MODE_SUBSCRIPTION and execution_profile != STANDALONE_LOCAL_ATTENDED_PROFILE:
        raise HermesSessionRunnerError("subscription auth requires the attended execution profile")
    normalized_binding = dict(binding)
    if "auth_mode" in binding or "auth_type" in binding or auth_mode == AUTH_MODE_SUBSCRIPTION:
        normalized_binding["auth_mode"] = auth_mode
    normalized_binding.pop("auth_type", None)
    if not isinstance(execution_profile, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", execution_profile):
        raise HermesSessionRunnerError("execution_profile is unsafe")
    configured_profiles = _configured_execution_profiles() if approved_execution_profiles is None else approved_execution_profiles
    if (execution_profile not in {LEGACY_HERMES_PROFILE.profile_id, STANDALONE_LOCAL_ATTENDED_PROFILE}
            and execution_profile not in configured_profiles):
        raise HermesSessionRunnerError("execution profile is not approved")
    max_iterations = request.get("max_iterations", MAX_ITERATIONS)
    iteration_limit = MAX_ITERATIONS if execution_profile == "legacy-hermes" else PROFILE_MAX_ITERATIONS
    if not isinstance(max_iterations, int) or isinstance(max_iterations, bool) or not 1 <= max_iterations <= iteration_limit:
        raise HermesSessionRunnerError(f"max_iterations must be an integer from 1 through {iteration_limit}")
    max_tokens = request.get("max_tokens", MAX_TOKENS)
    token_limit = MAX_TOKENS if execution_profile == "legacy-hermes" else PROFILE_MAX_TOKENS
    if not isinstance(max_tokens, int) or isinstance(max_tokens, bool) or not 1 <= max_tokens <= token_limit:
        raise HermesSessionRunnerError(f"max_tokens must be an integer from 1 through {token_limit}")
    source_identity = request.get("source_identity")
    if source_identity is not None and (not isinstance(source_identity, Mapping) or set(source_identity) != {"attempt_id", "immutable_revision"} or not isinstance(source_identity["attempt_id"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", source_identity["attempt_id"]) or not isinstance(source_identity["immutable_revision"], str) or re.fullmatch(r"[0-9a-f]{40,64}", source_identity["immutable_revision"]) is None):
        raise HermesSessionRunnerError("source identity is invalid")
    if execution_profile == STANDALONE_LOCAL_ATTENDED_PROFILE and source_identity is not None:
        raise HermesSessionRunnerError("standalone execution must not provide source identity")
    if execution_profile not in {"legacy-hermes", STANDALONE_LOCAL_ATTENDED_PROFILE} and source_identity is None:
        raise HermesSessionRunnerError("non-legacy execution requires source identity")
    return {"session_id": session_id, "identity": dict(request["identity"]), "permissions": permissions, "binding": normalized_binding, "message": request["message"], "execution_profile": execution_profile, "max_iterations": max_iterations, "max_tokens": max_tokens, "source_identity": dict(source_identity) if source_identity is not None else None, "project_id": project_id, "skills": dict(skills)}


def _validate_compaction_request(request: Mapping[str, Any], *, approved_execution_profiles: frozenset[str] | None = None) -> dict[str, Any]:
    """Validate the compaction protocol independently from the turn protocol."""
    if not isinstance(request, Mapping):
        raise HermesSessionRunnerError("compaction request must be an object")
    required = {"operation", "operation_id", "session_id", "identity", "permissions", "binding", "guidance", "expected_context_revision"}
    optional = {"compaction_tokens", "execution_profile", "max_iterations", "max_tokens"}
    if set(request) - (required | optional) or not required.issubset(request) or request.get("operation") != "compact":
        raise HermesSessionRunnerError("compaction request has unsupported or missing fields")
    if type(request["expected_context_revision"]) is not int or request["expected_context_revision"] < 0:
        raise HermesSessionRunnerError("expected context revision is invalid")
    if not isinstance(request["operation_id"], str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", request["operation_id"]) is None:
        raise HermesSessionRunnerError("operation_id is unsafe")
    guidance = request["guidance"]
    if not isinstance(guidance, str) or not guidance.strip() or len(guidance.encode()) > MAX_REQUEST_BYTES:
        raise HermesSessionRunnerError("compaction guidance is invalid")
    if "compaction_tokens" in request and (type(request["compaction_tokens"]) is not int or request["compaction_tokens"] < 1):
        raise HermesSessionRunnerError("compaction budget is invalid")
    # Validate the required binding/session identity fields without allowing a
    # turn-shaped message or managed claim fields into this protocol.
    base = {key: value for key, value in request.items() if key not in {"operation", "operation_id", "guidance", "expected_context_revision", "compaction_tokens"}}
    base["message"] = ""
    data = _validate_request(base, approved_execution_profiles=approved_execution_profiles)
    if data["skills"] or data["project_id"] is not None:
        raise HermesSessionRunnerError("compaction does not select skills")
    data.update({"operation_id": request["operation_id"], "guidance": guidance, "expected_context_revision": request["expected_context_revision"], "compaction_tokens": request.get("compaction_tokens")})
    return data


def run_one_turn(home: str | Path, workspace: str | Path, request: Mapping[str, Any], *, driver_factory: Callable[..., Any] = HermesSessionDriver, stderr: TextIO | None = None, skill_library: SkillReleaseLibrary | None = None) -> Any:
    """Validate and execute exactly one turn, sending native library chatter to stderr."""
    safe_home = _safe_existing_directory(home, "home")
    safe_workspace = _safe_existing_directory(workspace, "workspace")
    approved_execution_profiles = _validate_environment(safe_home)
    if skill_library is None:
        skill_library = _skill_library_from_environment()
    data = _validate_request(request, approved_execution_profiles=approved_execution_profiles)
    workspace_identity = _directory_identity(safe_workspace)
    # The native package has had logging paths that include API-key fragments.
    # Its stdout/stderr are therefore not forwarded by this JSON protocol.
    del stderr
    discarded = _DiscardOutput()
    with _SessionLock(safe_home):
        with contextlib.redirect_stdout(discarded), contextlib.redirect_stderr(discarded):
            previous = Path.cwd()
            try:
                os.chdir(safe_workspace)
                # chdir is pathname based on Windows and can race a directory
                # replacement.  Revalidate every ancestor immediately after
                # it, before importing/registering tools or launching native
                # Hermes, so the launch remains bound to validated identity.
                _assert_directory_identity(workspace_identity)
                workspace_tools = None
                before: set[tuple[str, str]] = set()
                if data["permissions"]:
                    toolset = data["permissions"][0]
                    workspace_tools = HermesWorkspaceTools(safe_workspace, safe_home)
                    before = {(item["tool_id"], item["state"]) for item in workspace_tools.effect_receipts()}
                    register_hermes_workspace_toolset(tools=workspace_tools, toolset_name=toolset)
                driver_kwargs = {"max_iterations": data["max_iterations"], "max_tokens": data["max_tokens"]}
                if data["execution_profile"] != "legacy-hermes":
                    driver_kwargs["execution_profile"] = data["execution_profile"]
                if data["skills"] or (data["project_id"] is not None and skill_library is not None):
                    if not isinstance(skill_library, SkillReleaseLibrary):
                        raise HermesSessionRunnerError("selected skills require the configured skill library")
                    try:
                        if data["skills"]:
                            projections = tuple(
                                skill_library.install(skill_id, version, project_id=data["project_id"], requested=True)
                                for skill_id, version in sorted(data["skills"].items())
                            )
                        else:
                            projections = skill_library.install_declared(data["project_id"])
                    except SkillReleaseError as error:
                        raise HermesSessionRunnerError("selected skill release was rejected") from error
                    if projections:
                        driver_kwargs["skills"] = [projection.invocation for projection in projections]
                driver = driver_factory(safe_home, data["session_id"], data["identity"], data["permissions"], data["binding"], **driver_kwargs)
                source_identity = data["source_identity"]
                try:
                    result = driver.run_turn(data["message"])
                except BaseException as error:
                    if source_identity is None:
                        raise
                    # A retained workspace lock is durable evidence of an
                    # interrupted write, even when the native driver cannot
                    # serialize its own exception.
                    result = {"completed": False, "failed": False, "interrupted": True, "partial": False,
                              "error": {"category": "native_exception", "type": type(error).__name__}}
                if source_identity is None:
                    if data["execution_profile"] == STANDALONE_LOCAL_ATTENDED_PROFILE and isinstance(result, Mapping):
                        result = {key: value for key, value in result.items() if key not in _STANDALONE_MANAGED_CLAIM_FIELDS}
                    # The legacy protocol is consumed by existing callers and
                    # must preserve the native result mapping byte-for-byte
                    # (selected auth is exposed by the owning adapter/status
                    # boundary instead).  Versioned profiles may advertise
                    # their normalized auth mode in their result envelope.
                    if data["execution_profile"] != LEGACY_HERMES_PROFILE.profile_id and isinstance(result, Mapping):
                        result = {**result, "auth_mode": data["binding"].get("auth_mode", AUTH_MODE_API_KEY)}
                    return result
                if not isinstance(result, Mapping):
                    raise HermesSessionRunnerError("non-legacy turn result is invalid")
                if workspace_tools is None: raise HermesSessionRunnerError("non-legacy turn requires workspace tools")
                effects = [{**item, "attempt_id": source_identity["attempt_id"]} for item in workspace_tools.effect_receipts() if (item["tool_id"], item["state"]) not in before]
                return {**result, "auth_mode": data["binding"].get("auth_mode", AUTH_MODE_API_KEY), "source_identity": source_identity, "effect_receipts": effects}
            finally:
                os.chdir(previous)


def run_one_compaction(home: str | Path, workspace: str | Path, request: Mapping[str, Any], *, driver_factory: Callable[..., Any] = HermesSessionDriver, stderr: TextIO | None = None) -> Any:
    """Execute one native compaction against the existing session home."""
    safe_home = _safe_existing_directory(home, "home")
    safe_workspace = _safe_existing_directory(workspace, "workspace")
    approved = _validate_environment(safe_home)
    base = _validate_compaction_request(request, approved_execution_profiles=approved)
    guidance, max_tokens = base["guidance"], base["compaction_tokens"] or base["max_tokens"]
    del stderr
    with _SessionLock(safe_home):
        discarded = _DiscardOutput()
        with contextlib.redirect_stdout(discarded), contextlib.redirect_stderr(discarded):
            previous = Path.cwd()
            try:
                os.chdir(safe_workspace)
                driver_kwargs = {"max_iterations": base["max_iterations"], "max_tokens": base["max_tokens"]}
                if base["execution_profile"] != "legacy-hermes": driver_kwargs["execution_profile"] = base["execution_profile"]
                driver = driver_factory(safe_home, base["session_id"], base["identity"], base["permissions"], base["binding"], **driver_kwargs)
                result = driver.compact(guidance=guidance, max_tokens=max_tokens, expected_context_revision=base["expected_context_revision"], operation_id=base["operation_id"])
                return _validated_compaction_outcome(result, base["session_id"], base["expected_context_revision"], base["operation_id"])
            finally:
                os.chdir(previous)


def _write_result(stream: TextIO, value: Mapping[str, Any]) -> None:
    stream.write(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n")
    stream.flush()


def main(argv: list[str] | None = None, *, stdin: TextIO | None = None, stdout: TextIO | None = None, stderr: TextIO | None = None, driver_factory: Callable[..., Any] = HermesSessionDriver) -> int:
    parser = argparse.ArgumentParser(description="Run one isolated native Hermes turn")
    parser.add_argument("--home", required=True)
    parser.add_argument("--workspace", required=True)
    args = parser.parse_args(argv)
    input_stream, output_stream, error_stream = stdin or sys.stdin, stdout or sys.stdout, stderr or sys.stderr
    try:
        request = _read_request(input_stream)
        if request.get("operation") == "compact":
            result = run_one_compaction(args.home, args.workspace, request, driver_factory=driver_factory, stderr=error_stream)
        else:
            result = run_one_turn(args.home, args.workspace, request, driver_factory=driver_factory, stderr=error_stream)
        _write_result(output_stream, {"ok": True, "result": result})
        return 0
    except (HermesSessionRunnerError, HermesSessionError, HermesWorkspaceToolError, ValueError):
        _write_result(output_stream, {"ok": False, "error": {"code": "invalid_request", "message": "request rejected"}})
        return 2
    except Exception:
        _write_result(output_stream, {"ok": False, "error": {"code": "turn_failed", "message": "turn failed"}})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
