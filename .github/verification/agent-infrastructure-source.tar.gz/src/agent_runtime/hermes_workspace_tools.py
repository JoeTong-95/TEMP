"""Narrow, workspace-only Hermes file tools.

No shell, terminal, process, network, deletion, or built-in Hermes filesystem
toolset is enabled here.  Registration uses Hermes' native ``tools.registry``
and ``toolsets.create_custom_toolset`` APIs only when a runtime explicitly calls
``register_hermes_workspace_toolset``.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import stat
from pathlib import Path, PurePosixPath
from typing import Any, Mapping


MAX_TEXT_BYTES = 256 * 1024
MAX_LIST_ENTRIES = 100
_OPERATION_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_TOOLSET_NAME = re.compile(r"[A-Za-z][A-Za-z0-9_-]{2,63}\Z")


class HermesWorkspaceToolError(ValueError):
    """The bounded workspace-file contract was not met."""


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


class HermesWorkspaceTools:
    """File operations confined to one injected workspace and state directory."""

    def __init__(self, workspace_root: str | Path, runtime_state_root: str | Path):
        self.workspace_root = self._existing_directory(workspace_root, "workspace root")
        self._runtime_state_path = Path(runtime_state_root).absolute()
        state_root = self._existing_directory(runtime_state_root, "runtime state root")
        self._runtime_state_root = state_root
        if self._contains(self.workspace_root, state_root) or self._contains(state_root, self.workspace_root):
            raise HermesWorkspaceToolError("runtime state root must be disjoint from workspace root")
        self.receipt_root = state_root / "workspace-tool-receipts"
        if self.receipt_root.exists():
            if self.receipt_root.is_symlink() or not self.receipt_root.is_dir():
                raise HermesWorkspaceToolError("workspace receipt root is invalid")
        else:
            self.receipt_root.mkdir(mode=0o700)
        self.receipt_root = self.receipt_root.resolve(strict=True)

    @staticmethod
    def _existing_directory(value: str | Path, label: str) -> Path:
        path = Path(value)
        absolute = path.absolute()
        current = Path(absolute.anchor)
        for part in absolute.parts[1:]:
            current = current / part
            if current.is_symlink():
                raise HermesWorkspaceToolError(f"{label} contains a symlink ancestor")
        if path.is_symlink() or not path.is_dir():
            raise HermesWorkspaceToolError(f"{label} must be an existing non-symlink directory")
        return path.resolve(strict=True)

    @staticmethod
    def _contains(parent: Path, child: Path) -> bool:
        try:
            child.relative_to(parent)
            return True
        except ValueError:
            return False

    def list_text_files(self, relative_directory: str = "", limit: int = MAX_LIST_ENTRIES) -> dict[str, Any]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_LIST_ENTRIES:
            raise HermesWorkspaceToolError("list limit is invalid")
        directory, _ = self._path(relative_directory, must_exist=True, directory=True)
        results: list[dict[str, Any]] = []
        with os.scandir(directory) as entries:
            for entry in sorted(entries, key=lambda item: item.name):
                if entry.is_symlink():
                    continue
                path = Path(entry.path)
                if entry.is_file(follow_symlinks=False):
                    self._validate_existing_path(path, directory=False)
                    size = path.stat().st_size
                    if size <= MAX_TEXT_BYTES:
                        results.append({"path": path.relative_to(self.workspace_root).as_posix(), "size": size})
                elif entry.is_dir(follow_symlinks=False):
                    self._validate_existing_path(path, directory=True)
                    results.append({"path": path.relative_to(self.workspace_root).as_posix() + "/", "size": None})
                if len(results) >= limit:
                    break
        return {"entries": results, "truncated": len(results) >= limit}

    def read_text_file(self, relative_path: str) -> dict[str, Any]:
        path, canonical = self._path(relative_path, must_exist=True, directory=False)
        raw = self._read_workspace_file(canonical)
        try:
            content = raw.decode("utf-8")
        except UnicodeDecodeError as error:
            raise HermesWorkspaceToolError("workspace file is not UTF-8 text") from error
        return {"path": path.relative_to(self.workspace_root).as_posix(), "content": content,
                "sha256": _sha256(raw), "size": len(raw)}

    def create_or_cas_update_text(self, *, relative_path: str, content: str,
                                  expected_sha256: str | None, operation_id: str) -> dict[str, Any]:
        """Create only when absent, or atomically replace an exact expected hash.

        A duplicate operation receipt returns the original result without another
        write.  A crash after write but before receipt intentionally leaves a
        lock for explicit operator reconciliation rather than replaying the edit.
        """
        if not isinstance(content, str):
            raise HermesWorkspaceToolError("content must be text")
        raw = content.encode("utf-8")
        if len(raw) > MAX_TEXT_BYTES:
            raise HermesWorkspaceToolError("content exceeds workspace text limit")
        if expected_sha256 is not None and (not isinstance(expected_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_sha256)):
            raise HermesWorkspaceToolError("expected SHA-256 is invalid")
        if not isinstance(operation_id, str) or not _OPERATION_ID.fullmatch(operation_id):
            raise HermesWorkspaceToolError("operation ID is invalid")
        path, canonical_path = self._path(relative_path, must_exist=False, directory=False)
        request_hash = _sha256(_canonical_json({"path": canonical_path, "content": content,
                                           "expected_sha256": expected_sha256}))
        receipt_path, lock_path = self._operation_paths(operation_id)
        path_lock = self.receipt_root / f"path-{_sha256(canonical_path.encode('utf-8'))}.lock"
        existing = self._receipt(receipt_path, request_hash)
        if existing is not None:
            return {**existing, "duplicate": True}
        self._acquire_lock(lock_path, _canonical_json({"tool_id": operation_id, "state": "active"}))
        completed = False
        write_started = False
        path_lock_acquired = False
        try:
            existing = self._receipt(receipt_path, request_hash)
            if existing is not None:
                return {**existing, "duplicate": True}
            if lock_path.exists() is False:  # defensive: lock loss is never safe to ignore
                raise HermesWorkspaceToolError("operation lock was lost")
            self._acquire_lock(path_lock, b"workspace path lock\\n")
            path_lock_acquired = True
            parent_fd, filename = self._open_workspace_parent(canonical_path)
            try:
                current_raw = self._read_at(parent_fd, filename, absent_ok=True)
                current = _sha256(current_raw) if current_raw is not None else None
                if expected_sha256 is None:
                    if current is not None:
                        raise HermesWorkspaceToolError("file already exists; expected SHA-256 is required")
                elif current != expected_sha256:
                    raise HermesWorkspaceToolError("compare-and-swap hash did not match")
                write_started = True
                self._atomic_write_at(parent_fd, filename, raw)
            finally:
                os.close(parent_fd)
            result = {"path": path.relative_to(self.workspace_root).as_posix(), "sha256": _sha256(raw),
                      "size": len(raw), "created": current is None}
            self._atomic_receipt(receipt_path, {"request_sha256": request_hash, "tool_id": operation_id, "state": "completed", "result": result, "result_sha256": _sha256(_canonical_json(result))})
            completed = True
            return {**result, "duplicate": False}
        finally:
            # A successful receipt makes retry safe. A normal validation failure
            # may retry. An interrupted/write failure retains the lock for review.
            if completed or not write_started:
                lock_path.unlink(missing_ok=True)
                if path_lock_acquired:
                    path_lock.unlink(missing_ok=True)
                self._fsync_directory(self.receipt_root)

    def _path(self, relative_path: str, *, must_exist: bool, directory: bool) -> tuple[Path, str]:
        if not isinstance(relative_path, str) or len(relative_path) > 512 or "\\" in relative_path or "\x00" in relative_path or ":" in relative_path:
            raise HermesWorkspaceToolError("workspace path is invalid")
        if relative_path == "" and directory:
            return self.workspace_root, ""
        candidate = PurePosixPath(relative_path)
        canonical = candidate.as_posix()
        if relative_path != canonical or candidate.is_absolute() or not candidate.parts or any(part in {"", ".", "..", ".git", ".env"} for part in candidate.parts):
            raise HermesWorkspaceToolError("workspace path is outside allowed scope")
        path = self.workspace_root.joinpath(*candidate.parts)
        parent = path.parent
        self._validate_existing_path(parent, directory=True)
        if must_exist:
            self._validate_existing_path(path, directory=directory)
        elif path.exists() or path.is_symlink():
            self._validate_existing_path(path, directory=False)
        return path, canonical

    def _validate_existing_path(self, path: Path, *, directory: bool) -> None:
        try:
            relative = path.relative_to(self.workspace_root)
        except ValueError as error:
            raise HermesWorkspaceToolError("workspace path escapes root") from error
        current = self.workspace_root
        if current.is_symlink():
            raise HermesWorkspaceToolError("workspace root is a symlink")
        for part in relative.parts:
            current = current / part
            if current.is_symlink():
                raise HermesWorkspaceToolError("workspace path contains a symlink")
        if not path.exists() or (directory and not path.is_dir()) or (not directory and not path.is_file()):
            raise HermesWorkspaceToolError("workspace path does not have the required type")
        resolved = path.resolve(strict=True)
        try:
            resolved.relative_to(self.workspace_root)
        except ValueError as error:
            raise HermesWorkspaceToolError("workspace path escapes root") from error

    @staticmethod
    def _read_bounded(path: Path) -> bytes:
        try:
            with path.open("rb") as handle:
                raw = handle.read(MAX_TEXT_BYTES + 1)
        except OSError as error:
            raise HermesWorkspaceToolError("workspace file could not be read") from error
        if len(raw) > MAX_TEXT_BYTES:
            raise HermesWorkspaceToolError("workspace file exceeds text limit")
        return raw

    def _open_workspace_parent(self, canonical_path: str) -> tuple[int, str]:
        """Hold every ancestor directory open with O_NOFOLLOW (POSIX only)."""
        if os.name != "posix" or not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
            raise HermesWorkspaceToolError("workspace operations require POSIX openat/O_NOFOLLOW confinement")
        parts = PurePosixPath(canonical_path).parts
        descriptor = os.open(self.workspace_root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            for part in parts[:-1]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
                os.close(descriptor)
                descriptor = child
            return descriptor, parts[-1]
        except OSError as error:
            os.close(descriptor)
            raise HermesWorkspaceToolError("workspace ancestor could not be opened safely") from error

    def _read_workspace_file(self, canonical_path: str) -> bytes:
        parent_fd, filename = self._open_workspace_parent(canonical_path)
        try:
            value = self._read_at(parent_fd, filename, absent_ok=False)
            assert value is not None
            return value
        finally:
            os.close(parent_fd)

    @staticmethod
    def _read_at(parent_fd: int, filename: str, *, absent_ok: bool) -> bytes | None:
        try:
            descriptor = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
        except FileNotFoundError:
            if absent_ok:
                return None
            raise HermesWorkspaceToolError("workspace file is absent")
        except OSError as error:
            raise HermesWorkspaceToolError("workspace file could not be opened safely") from error
        try:
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode):
                raise HermesWorkspaceToolError("workspace path does not name a regular file")
            raw = os.read(descriptor, MAX_TEXT_BYTES + 1)
            if len(raw) > MAX_TEXT_BYTES:
                raise HermesWorkspaceToolError("workspace file exceeds text limit")
            return raw
        finally:
            os.close(descriptor)

    @staticmethod
    def _atomic_write_at(parent_fd: int, filename: str, raw: bytes) -> None:
        temporary = f".{filename}.{secrets.token_hex(12)}.tmp"
        descriptor: int | None = None
        try:
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600,
                                 dir_fd=parent_fd)
            with os.fdopen(descriptor, "wb") as handle:
                descriptor = None
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, filename, src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
            os.fsync(parent_fd)
        except OSError as error:
            try:
                os.unlink(temporary, dir_fd=parent_fd)
            except OSError:
                pass
            raise HermesWorkspaceToolError("workspace file could not be written safely") from error
        finally:
            if descriptor is not None:
                os.close(descriptor)

    def _operation_paths(self, operation_id: str) -> tuple[Path, Path]:
        digest = _sha256(operation_id.encode("utf-8"))
        return self.receipt_root / f"{digest}.json", self.receipt_root / f"{digest}.lock"

    def _verified_receipt_root(self) -> Path:
        """Return the original receipt directory only while its ancestry holds."""
        state = self._runtime_state_path
        root = state / "workspace-tool-receipts"
        if state.is_symlink() or root.is_symlink() or not state.is_dir() or not root.is_dir():
            raise HermesWorkspaceToolError("workspace receipt root is unsafe")
        try:
            resolved_state = state.resolve(strict=True)
            resolved_root = root.resolve(strict=True)
        except OSError as error:
            raise HermesWorkspaceToolError("workspace receipt root is unsafe") from error
        if resolved_state != self._runtime_state_root or resolved_root != self.receipt_root:
            raise HermesWorkspaceToolError("workspace receipt root changed")
        try:
            resolved_root.relative_to(resolved_state)
        except ValueError as error:
            raise HermesWorkspaceToolError("workspace receipt root escapes state") from error
        return resolved_root

    def _receipt_entry(self, root: Path, name: str) -> bytes | None:
        """Read one regular receipt without following a POSIX final symlink."""
        path = root / name
        if path.is_symlink() or not path.is_file():
            return None
        if os.name == "posix" and hasattr(os, "O_NOFOLLOW") and hasattr(os, "O_DIRECTORY"):
            directory = descriptor = None
            try:
                directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                descriptor = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory)
                if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                    return None
                raw = os.read(descriptor, MAX_TEXT_BYTES + 1)
                return raw if len(raw) <= MAX_TEXT_BYTES else None
            except OSError:
                return None
            finally:
                if descriptor is not None: os.close(descriptor)
                if directory is not None: os.close(directory)
        # Windows has no portable O_NOFOLLOW equivalent in this runtime; reject
        # reparse/symlink paths and recheck their resolved containment.
        try:
            if path.resolve(strict=True).parent != root:
                return None
            return self._read_bounded(path)
        except (OSError, HermesWorkspaceToolError):
            return None

    @staticmethod
    def _effect_from_receipt(name: str, raw: bytes) -> dict[str, Any] | None:
        if not re.fullmatch(r"[0-9a-f]{64}\.json", name): return None
        try: value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError): return None
        if not isinstance(value, Mapping) or value.get("state") not in {"completed", "rejected"}: return None
        required = {"tool_id", "state", "result", "result_sha256"}
        if value["state"] == "completed": required.add("request_sha256")
        if set(value) != required or not isinstance(value.get("tool_id"), str) or not _OPERATION_ID.fullmatch(value["tool_id"]): return None
        if _sha256(value["tool_id"].encode("utf-8")) + ".json" != name: return None
        if value["state"] == "completed" and (not isinstance(value.get("request_sha256"), str) or re.fullmatch(r"[0-9a-f]{64}", value["request_sha256"]) is None): return None
        if not isinstance(value.get("result"), Mapping) or not isinstance(value.get("result_sha256"), str) or re.fullmatch(r"[0-9a-f]{64}", value["result_sha256"]) is None: return None
        canonical = _canonical_json(value["result"])
        if _sha256(canonical) != value["result_sha256"]: return None
        return {"tool_id": value["tool_id"], "state": value["state"], "result": dict(value["result"]), "result_sha256": value["result_sha256"]}

    @staticmethod
    def _effect_from_lock(name: str, raw: bytes) -> dict[str, Any] | None:
        if not re.fullmatch(r"[0-9a-f]{64}\.lock", name): return None
        try: value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError): return None
        if not isinstance(value, Mapping) or set(value) != {"tool_id", "state"} or value.get("state") != "active" or not isinstance(value.get("tool_id"), str) or not _OPERATION_ID.fullmatch(value["tool_id"]): return None
        if _sha256(value["tool_id"].encode("utf-8")) + ".lock" != name: return None
        return {"tool_id": value["tool_id"], "state": "unknown"}

    def effect_receipts(self) -> list[dict[str, Any]]:
        root = self._verified_receipt_root()
        effects: list[dict[str, Any]] = []
        try: names = sorted(entry.name for entry in os.scandir(root) if entry.name.endswith((".json", ".lock")))
        except OSError as error: raise HermesWorkspaceToolError("workspace receipt root is unsafe") from error
        for name in names:
            raw = self._receipt_entry(root, name)
            if raw is None: continue
            effect = self._effect_from_receipt(name, raw) if name.endswith(".json") else self._effect_from_lock(name, raw)
            if effect is not None: effects.append(effect)
        return effects

    def record_rejected_effect(self, operation_id: str) -> None:
        if not isinstance(operation_id, str) or not _OPERATION_ID.fullmatch(operation_id): return
        receipt, _ = self._operation_paths(operation_id)
        if not receipt.exists(): self._atomic_receipt(receipt, {"tool_id": operation_id, "state": "rejected", "result": {}, "result_sha256": _sha256(b"{}")})

    @staticmethod
    def _acquire_lock(lock_path: Path, initial: bytes) -> None:
        try:
            descriptor = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            os.write(descriptor, initial)
            os.fsync(descriptor)
            os.close(descriptor)
            HermesWorkspaceTools._fsync_directory(lock_path.parent)
        except FileExistsError as error:
            raise HermesWorkspaceToolError("operation is active or needs reconciliation") from error
        except OSError as error:
            raise HermesWorkspaceToolError("could not record workspace operation") from error

    @staticmethod
    def _receipt(path: Path, expected_request_hash: str) -> dict[str, Any] | None:
        if not path.exists():
            return None
        if path.is_symlink() or not path.is_file():
            raise HermesWorkspaceToolError("operation receipt is invalid")
        raw = HermesWorkspaceTools._read_bounded(path)
        try:
            receipt = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise HermesWorkspaceToolError("operation receipt is invalid") from error
        if not isinstance(receipt, Mapping) or receipt.get("request_sha256") != expected_request_hash or not isinstance(receipt.get("result"), Mapping):
            raise HermesWorkspaceToolError("operation ID conflicts with a different request")
        return dict(receipt["result"])

    @staticmethod
    def _atomic_write(path: Path, raw: bytes) -> None:
        temporary = path.parent / f".{path.name}.{secrets.token_hex(12)}.tmp"
        try:
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
            HermesWorkspaceTools._fsync_directory(path.parent)
        except OSError as error:
            temporary.unlink(missing_ok=True)
            raise HermesWorkspaceToolError("workspace file could not be written") from error

    @staticmethod
    def _atomic_receipt(path: Path, value: Mapping[str, Any]) -> None:
        HermesWorkspaceTools._atomic_write(path, json.dumps(value, sort_keys=True, separators=(",", ":"),
                                                              ensure_ascii=False).encode("utf-8"))

    @staticmethod
    def _fsync_directory(directory: Path) -> None:
        """Persist a rename/create/unlink directory entry where the platform supports it."""
        if os.name == "nt":
            return
        try:
            descriptor = os.open(directory, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        except OSError as error:
            raise HermesWorkspaceToolError("workspace directory durability could not be confirmed") from error


def register_hermes_workspace_toolset(*, tools: HermesWorkspaceTools, toolset_name: str) -> dict[str, str]:
    """Register only these three handlers into one explicitly named native toolset.

    The caller must pass the returned name in ``enabled_toolsets``. This function
    never enables any global/built-in toolset.
    """
    if (not isinstance(tools, HermesWorkspaceTools) or not isinstance(toolset_name, str)
            or not _TOOLSET_NAME.fullmatch(toolset_name) or not toolset_name.startswith("agentstack_workspace_")):
        raise HermesWorkspaceToolError("workspace toolset registration is invalid")
    try:
        from tools.registry import registry  # type: ignore[import-not-found]
        import toolsets  # type: ignore[import-not-found]
    except ImportError as error:
        raise HermesWorkspaceToolError("pinned Hermes native registry is unavailable") from error
    names = {"list": f"{toolset_name}_list", "read": f"{toolset_name}_read", "write": f"{toolset_name}_write"}
    if toolset_name in toolsets.TOOLSETS or any(name in registry.get_all_tool_names() for name in names.values()):
        raise HermesWorkspaceToolError("workspace toolset or tool name already exists")
    schemas = {
        "list": {"name": names["list"], "description": "List immediate entries under the approved workspace only.", "parameters": {"type": "object", "properties": {"relative_directory": {"type": "string"}, "limit": {"type": "integer"}}}},
        "read": {"name": names["read"], "description": "Read a bounded UTF-8 text file in the approved workspace only.", "parameters": {"type": "object", "properties": {"relative_path": {"type": "string"}}, "required": ["relative_path"]}},
        "write": {"name": names["write"], "description": "Create or compare-and-swap update one bounded UTF-8 workspace file.", "parameters": {"type": "object", "properties": {"relative_path": {"type": "string"}, "content": {"type": "string"}, "expected_sha256": {"type": ["string", "null"]}, "operation_id": {"type": "string"}}, "required": ["relative_path", "content", "expected_sha256", "operation_id"]}},
    }
    def handler(callable_):
        def wrapped(arguments: Mapping[str, Any], **_: Any) -> str:
            try:
                return json.dumps(callable_(**dict(arguments)), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            except (HermesWorkspaceToolError, TypeError, ValueError):
                return json.dumps({"error": "workspace operation rejected"})
        return wrapped
    def write_handler(arguments: Mapping[str, Any], **_: Any) -> str:
        try:
            return json.dumps(tools.create_or_cas_update_text(**dict(arguments)), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        except (HermesWorkspaceToolError, TypeError, ValueError):
            tools.record_rejected_effect(arguments.get("operation_id") if isinstance(arguments, Mapping) else "")
            return json.dumps({"error": "workspace operation rejected"})
    registry.register(name=names["list"], toolset=toolset_name, schema=schemas["list"], handler=handler(tools.list_text_files), check_fn=lambda: True)
    registry.register(name=names["read"], toolset=toolset_name, schema=schemas["read"], handler=handler(tools.read_text_file), check_fn=lambda: True)
    registry.register(name=names["write"], toolset=toolset_name, schema=schemas["write"], handler=write_handler, check_fn=lambda: True)
    toolsets.create_custom_toolset(toolset_name, "Scoped AgentStack workspace text-file operations", tools=list(names.values()), includes=[])
    return names
