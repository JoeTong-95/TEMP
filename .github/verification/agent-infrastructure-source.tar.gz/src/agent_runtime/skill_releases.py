"""Immutable Git-backed skill release selection for the Agent Runtime.

The Git repository is the canonical source.  A projection is a disposable,
read-only copy with a recorded digest; the runtime verifies both the Git
identity and the copy before using it.  This module deliberately contains no
credential or permission grant mechanism.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
from dataclasses import dataclass, field
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
import time
from typing import Any, Mapping

if os.name == "nt":
    import msvcrt
else:
    import fcntl


class SkillReleaseError(ValueError):
    """A skill release is unavailable, incompatible, unauthorized, or altered."""


_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_VERSION_IDENTIFIER = r"(?:0|[1-9]\d*|[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*)"
_VERSION = re.compile(
    rf"^(?:v)?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    rf"(?:-({_VERSION_IDENTIFIER}(?:\.{_VERSION_IDENTIFIER})*))?"
    rf"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)
_SHA = re.compile(r"^[0-9a-f]{40}$")
_AUTHORIZATION_FORMAT = "project-git-v1"
_SELECTION_TOMBSTONE_PREFIX = "refs/skill-release-tombstones"
_STATE_LOCKS: dict[str, threading.RLock] = {}
_STATE_LOCKS_GUARD = threading.Lock()


def _version(value: str) -> tuple[int, int, int, str, str]:
    match = _VERSION.fullmatch(value) if isinstance(value, str) else None
    if match is None:
        raise SkillReleaseError("semantic version is invalid")
    return (int(match.group(1)), int(match.group(2)), int(match.group(3)),
            match.group(4) or "", match.group(5) or "")


def _version_text(value: str) -> str:
    major, minor, patch, prerelease, build = _version(value)
    result = f"{major}.{minor}.{patch}" + (f"-{prerelease}" if prerelease else "")
    return result + (f"+{build}" if build else "")


def _safe_path(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise SkillReleaseError("skill path is unsafe")
    target = root / relative
    if root.resolve() not in target.resolve().parents:
        raise SkillReleaseError("skill path escapes its root")
    return target


def _is_link_like(path: Path) -> bool:
    """Identify links, including Windows junctions/reparse points."""
    if path.is_symlink():
        return True
    checker = getattr(path, "is_junction", None)
    if checker is not None and checker():
        return True
    checker = getattr(os.path, "isjunction", None)
    if checker is not None:
        return bool(checker(path))
    # Python 3.11 has no public isjunction API, but Windows exposes the
    # reparse-point bit without following the entry.
    try:
        attributes = path.stat(follow_symlinks=False).st_file_attributes
    except (AttributeError, OSError):
        return False
    return bool(attributes & 0x400)


def _assert_path_ancestors_clear(path: Path) -> None:
    """Reject link-like components, including dangling links, in a path."""
    for component in (path, *path.parents):
        if _is_link_like(component):
            raise SkillReleaseError("skill storage contains a symlink or junction")


def _digest_files(root: Path) -> dict[str, str]:
    if _is_link_like(root) or not root.is_dir():
        raise SkillReleaseError("skill projection is unavailable")
    result: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root).as_posix()
        if _is_link_like(path):
            raise SkillReleaseError("skill projection contains a symlink or junction")
        if path.is_dir():
            continue
        if not path.is_file():
            raise SkillReleaseError("skill projection contains an unsupported entry")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        result[relative] = digest
    return result


def _tree_digest(root: Path) -> dict[str, str]:
    """Digest the complete projection tree, including empty dirs and modes."""
    if _is_link_like(root) or not root.is_dir():
        raise SkillReleaseError("skill projection is unavailable")
    result: dict[str, str] = {".": f"dir:{root.stat().st_mode & 0o7777:04o}"}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root).as_posix()
        if _is_link_like(path):
            raise SkillReleaseError("skill projection contains a symlink or junction")
        if path.is_dir():
            result[relative] = f"dir:{path.stat().st_mode & 0o7777:04o}"
        elif path.is_file():
            result[relative] = f"file:{path.stat().st_mode & 0o7777:04o}"
        else:
            raise SkillReleaseError("skill projection contains an unsupported entry")
    return result


def _validate_tree_digest(value: Any) -> dict[str, str]:
    if not isinstance(value, Mapping) or not value:
        raise SkillReleaseError("selected skill release tree metadata is malformed")
    result = dict(value)
    if any(
        not isinstance(path, str)
        or not path
        or not isinstance(entry, str)
        or re.fullmatch(r"(?:file|dir):[0-7]{4}", entry) is None
        for path, entry in result.items()
    ) or "." not in result:
        raise SkillReleaseError("selected skill release tree metadata is malformed")
    return result


def _parse_frontmatter(raw: bytes) -> dict[str, Any]:
    text = raw.decode("utf-8").replace("\r\n", "\n")
    if not text.startswith("---\n"):
        raise SkillReleaseError("skill release frontmatter is missing")
    end = text.find("\n---", 4)
    if end < 0:
        raise SkillReleaseError("skill release frontmatter is malformed")
    metadata: dict[str, Any] = {}
    for line in text[4:end].splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            raise SkillReleaseError("skill release frontmatter is malformed")
        key, value = line.split(":", 1)
        key, value = key.strip(), value.strip()
        if not _IDENTIFIER.fullmatch(key):
            raise SkillReleaseError("skill release metadata key is invalid")
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
            value = value[1:-1]
        metadata[key] = value
    return metadata


def _skill_permissions(metadata: Mapping[str, Any]) -> tuple[str, ...]:
    raw = metadata.get("permissions", "")
    if not isinstance(raw, str):
        raise SkillReleaseError("skill release permissions are invalid")
    values = tuple(item.strip() for item in raw.split(",") if item.strip())
    if any(_IDENTIFIER.fullmatch(item) is None for item in values):
        raise SkillReleaseError("skill release permissions are invalid")
    grants = metadata.get("grants_credentials", "false")
    if not isinstance(grants, str) or grants.lower() not in {"true", "false"}:
        raise SkillReleaseError("skill release credential metadata is invalid")
    if grants.lower() == "true":
        raise SkillReleaseError("skill releases cannot grant credentials")
    return values


def _compatible(constraint: Any, runtime_version: str) -> bool:
    if constraint is None:
        return True
    if isinstance(constraint, list):
        return any(_compatible(item, runtime_version) for item in constraint)
    if not isinstance(constraint, str) or not constraint.strip():
        raise SkillReleaseError("skill release compatibility is invalid")
    current = _version(runtime_version)[:3]
    for item in (part.strip() for part in constraint.split(",")):
        match = re.fullmatch(r"(>=|<=|>|<|=|~\s*|\^\s*)?\s*(v?\d+\.\d+(?:\.\d+)?)", item)
        if match is None:
            raise SkillReleaseError("skill release compatibility is invalid")
        numbers = tuple(int(part) for part in match.group(2).lstrip("v").split("."))
        target = numbers + ((0,) if len(numbers) == 2 else ())
        operator = (match.group(1) or "=").strip()
        if operator == "^":
            if target[0] > 0:
                upper = (target[0] + 1, 0, 0)
            elif target[1] > 0:
                upper = (0, target[1] + 1, 0)
            else:
                upper = (0, 0, target[2] + 1)
            passed = current >= target and current < upper
        elif operator == "~":
            passed = current >= target and current < (target[0], target[1] + 1, 0)
        elif operator == ">=": passed = current >= target
        elif operator == "<=": passed = current <= target
        elif operator == ">": passed = current > target
        elif operator == "<": passed = current < target
        else: passed = current == target
        if not passed:
            return False
    return True


@dataclass(frozen=True)
class SkillRelease:
    skill_id: str
    version: str
    tag: str
    commit: str
    skill_path: str
    runtime_version: str
    compatibility: Any
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def source(self) -> dict[str, str]:
        return {"tag": self.tag, "commit": self.commit, "path": self.skill_path}


@dataclass(frozen=True)
class SkillProjection:
    skill_id: str
    project_id: str
    version: str
    tag: str
    commit: str
    path: Path
    digest: Mapping[str, str]
    tree_digest: Mapping[str, str] = ()
    permissions: tuple[str, ...] = ()
    grants_credentials: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def source(self) -> dict[str, str]:
        return {"tag": self.tag, "commit": self.commit}

    @property
    def invocation(self) -> dict[str, Any]:
        """The non-authoritative, verified skill input for native Hermes."""
        return {
            "project_id": self.project_id,
            "name": self.skill_id,
            "version": self.version,
            "source": self.source,
            "path": str(self.path),
            "digest": dict(self.digest),
            "tree_digest": dict(self.tree_digest),
            "metadata": dict(self.metadata),
            "permissions": list(self.permissions),
            "grants_credentials": self.grants_credentials,
        }


class SkillReleaseLibrary:
    """Resolve, install, persist, and verify explicitly selected releases."""

    def __init__(self, repository_root: str | Path, projection_root: str | Path, state_path: str | Path, *, runtime_version: str, approved_releases: Mapping[str, Any] | None = None, project_releases: Mapping[str, Mapping[str, str]] | None = None, proposal_root: str | Path | None = None):
        self.repository_root = Path(repository_root)
        self.projection_root = Path(projection_root)
        self.state_path = Path(state_path)
        # Kept as a compatibility attribute for installations produced by the
        # previous candidate.  It is deliberately never used as authorization:
        # writable JSON is not an independent trust source.
        self.authorization_path = self.state_path.with_name(self.state_path.name + ".authorizations")
        self.state_lock_path = self.state_path.with_name(self.state_path.name + ".lock")
        self.proposal_root = Path(proposal_root) if proposal_root is not None else self.projection_root.parent / "skill-proposals"
        self.staging_root = self.projection_root.parent / f".{self.projection_root.name}.staging"
        if not all(path.is_absolute() and not _is_link_like(path) for path in (self.repository_root, self.projection_root, self.state_path, self.authorization_path, self.state_lock_path, self.proposal_root, self.staging_root)):
            raise SkillReleaseError("skill library paths must be absolute non-symlink paths")
        for path in (self.repository_root, self.projection_root, self.state_path, self.authorization_path, self.state_lock_path, self.proposal_root, self.staging_root):
            _assert_path_ancestors_clear(path)
        if not self.repository_root.is_dir() or not (self.repository_root / ".git").exists():
            raise SkillReleaseError("skill library repository is unavailable")
        _version(runtime_version)
        self.runtime_version = _version_text(runtime_version)
        self._approval_policy_configured = approved_releases is not None
        self._project_policy_configured = project_releases is not None
        if approved_releases is not None and not isinstance(approved_releases, Mapping):
            raise SkillReleaseError("approved skill releases are invalid")
        if project_releases is not None and (not isinstance(project_releases, Mapping) or any(not isinstance(values, Mapping) for values in project_releases.values())):
            raise SkillReleaseError("project skill releases are invalid")
        self.approved_releases = {}
        for skill, values in (approved_releases or {}).items():
            if isinstance(values, str) or not isinstance(values, (list, tuple, set, frozenset)):
                raise SkillReleaseError("approved skill releases are invalid")
            self.approved_releases[str(skill)] = tuple(str(item) for item in values)
        self.project_releases = {str(project): {str(skill): str(version) for skill, version in values.items()} for project, values in (project_releases or {}).items()}
        for skill, versions in self.approved_releases.items():
            if not _IDENTIFIER.fullmatch(skill): raise SkillReleaseError("skill identifier is unsafe")
            for version in versions: _version(version)
        for project, releases in self.project_releases.items():
            if not _IDENTIFIER.fullmatch(project): raise SkillReleaseError("project identifier is unsafe")
            for skill, version in releases.items():
                if not _IDENTIFIER.fullmatch(skill): raise SkillReleaseError("skill identifier is unsafe")
                _version(version)
        self._assert_case_distinct(self.project_releases)
        self._assert_storage_roots_disjoint(
            self.repository_root, self.projection_root, self.proposal_root, self.staging_root
        )
        self.projection_root.mkdir(parents=True, exist_ok=True)
        self.proposal_root.mkdir(parents=True, exist_ok=True)
        self.staging_root.mkdir(parents=True, exist_ok=True)
        self._state_lock_depth = threading.local()
        self._assert_project_identities()

    @contextmanager
    def _state_transaction(self):
        """Serialize Git bindings and shared state read-modify-write cycles.

        The state file is shared by all projects and Git updates also contend
        on repository lock files on Windows.  One lock therefore protects the
        complete per-project install transaction, including projection
        publication and the final merged state write.  The thread lock covers
        concurrent library instances in one process; the file lock covers
        independent runtime processes.
        """
        depth = getattr(self._state_lock_depth, "value", 0)
        if depth:
            self._state_lock_depth.value = depth + 1
            try:
                yield
            finally:
                self._state_lock_depth.value = depth
            return
        lock_key = str(self.state_lock_path).casefold()
        with _STATE_LOCKS_GUARD:
            process_lock = _STATE_LOCKS.setdefault(lock_key, threading.RLock())
        process_lock.acquire()
        descriptor = -1
        try:
            self.state_lock_path.parent.mkdir(parents=True, exist_ok=True)
            descriptor = os.open(str(self.state_lock_path), os.O_CREAT | os.O_RDWR, 0o600)
            if os.name == "nt":
                os.lseek(descriptor, 0, os.SEEK_SET)
                while True:
                    try:
                        msvcrt.locking(descriptor, msvcrt.LK_NBLCK, 1)
                        break
                    except OSError:
                        time.sleep(0.01)
                        os.lseek(descriptor, 0, os.SEEK_SET)
            else:
                fcntl.flock(descriptor, fcntl.LOCK_EX)
            self._state_lock_depth.value = 1
            try:
                yield
            finally:
                self._state_lock_depth.value = 0
                if os.name == "nt":
                    os.lseek(descriptor, 0, os.SEEK_SET)
                    msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            if descriptor != -1:
                os.close(descriptor)
            process_lock.release()

    def _git(self, *args: str) -> str:
        try:
            result = subprocess.run(("git", "--no-replace-objects", "-C", str(self.repository_root), *args), check=True, capture_output=True, text=True)
        except (OSError, subprocess.CalledProcessError) as error:
            raise SkillReleaseError("skill library Git operation failed") from error
        return result.stdout.strip()

    def _git_bytes(self, *args: str) -> bytes:
        try:
            result = subprocess.run(("git", "--no-replace-objects", "-C", str(self.repository_root), *args), check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError) as error:
            raise SkillReleaseError("skill library Git operation failed") from error
        return result.stdout

    @staticmethod
    def _assert_case_distinct(project_ids: Mapping[str, Any] | tuple[str, ...] | list[str]) -> None:
        seen: dict[str, str] = {}
        for project_id in project_ids:
            if not isinstance(project_id, str):
                raise SkillReleaseError("skill project identity is malformed")
            folded = project_id.casefold()
            previous = seen.get(folded)
            if previous is not None and previous != project_id:
                raise SkillReleaseError("skill project identity has a case-fold collision")
            seen[folded] = project_id

    def _assert_project_identities(self, extra: tuple[str, ...] = ()) -> None:
        """Reject project aliases that collide on case-insensitive stores.

        Git loose refs and Windows projection directories both fold case.  A
        raw project ID is retained in state and paths for compatibility, so a
        case variant must fail closed before it can share either resource.
        """
        identities = list(self.project_releases) + list(extra)
        for root in (self.projection_root, self.staging_root, self.proposal_root):
            try:
                if root.is_dir():
                    identities.extend(child.name for child in root.iterdir())
            except OSError as error:
                raise SkillReleaseError("skill project storage is unavailable") from error
        for prefix in ("refs/skill-release-authorizations", _SELECTION_TOMBSTONE_PREFIX):
            refs = self._git("for-each-ref", "--format=%(refname)", prefix).splitlines()
            for ref in refs:
                parts = ref.split("/")
                # Project-scoped authorization refs have
                # refs/<namespace>/<project>/<skill>/<version>/<tag>; the
                # older projectless refs have one fewer path component and do
                # not participate in project case-fold isolation.
                minimum_parts = 6 if prefix == "refs/skill-release-authorizations" else 5
                if len(parts) >= minimum_parts and parts[0] == "refs" and parts[1] == prefix.split("/", 1)[1]:
                    identities.append(parts[2])
        self._assert_case_distinct(tuple(identities))

    @staticmethod
    def _assert_storage_roots_disjoint(*roots: Path) -> None:
        """Reject aliases and nesting between trusted and writable roots."""
        resolved = [path.resolve(strict=False) for path in roots]
        for index, root in enumerate(resolved):
            for other in resolved[index + 1:]:
                try:
                    common = Path(os.path.commonpath((str(root), str(other))))
                except ValueError as error:
                    raise SkillReleaseError("skill storage roots are invalid") from error
                folded_common = os.path.normcase(str(common))
                if folded_common in {os.path.normcase(str(root)), os.path.normcase(str(other))}:
                    raise SkillReleaseError("skill storage roots must be separate")

    @staticmethod
    def _tag_candidates(skill_id: str, version: str) -> frozenset[str]:
        canonical = _version_text(version)
        return frozenset({f"{skill_id}/v{canonical}", f"{skill_id}/{canonical}", f"{skill_id}@v{canonical}", f"{skill_id}@{canonical}", f"skills/{skill_id}/v{canonical}", f"skills/{skill_id}/{canonical}", f"skill/{skill_id}/v{canonical}", f"v{canonical}", canonical})

    def _tags(self, skill_id: str, version: str) -> list[str]:
        candidates = self._tag_candidates(skill_id, version)
        return sorted(tag for tag in self._git("tag", "--list").splitlines() if tag in candidates)

    def _assert_expected_tag(self, skill_id: str, version: str, tag: str) -> None:
        if tag not in self._tag_candidates(skill_id, version):
            raise SkillReleaseError("skill release authorization tag is unauthorized")

    def _assert_authorized(self, skill_id: str, version: str) -> None:
        if not self._approval_policy_configured:
            raise SkillReleaseError("skill release is unauthorized")
        allowed = self.approved_releases.get(skill_id)
        if allowed is None or version not in {_version_text(item) for item in allowed}:
            raise SkillReleaseError("skill release is unauthorized")

    def _assert_project_authorized(self, project_id: str, skill_id: str, version: str) -> None:
        if not isinstance(project_id, str) or not _IDENTIFIER.fullmatch(project_id):
            raise SkillReleaseError("skill project identifier is unsafe")
        self._assert_project_identities((project_id,))
        declared = self.project_releases.get(project_id, {}).get(skill_id)
        if (
            not self._project_policy_configured
            or declared is None
            or _version_text(declared) != _version_text(version)
        ):
            raise SkillReleaseError("skill release is not authorized for this project")

    def _release_at_commit(self, skill_id: str, version: str, tag: str, commit: str) -> SkillRelease | None:
        self._assert_expected_tag(skill_id, version, tag)
        if not _SHA.fullmatch(commit):
            return None
        paths = self._git("ls-tree", "-r", "--name-only", commit).splitlines()
        candidates = [f"skills/{skill_id}/SKILL.md", f"{skill_id}/SKILL.md", "SKILL.md"]
        manifest_path = next((item for item in candidates if item in paths), None)
        if manifest_path is None:
            return None
        metadata = _parse_frontmatter(self._git_bytes("show", f"{commit}:{manifest_path}"))
        if metadata.get("name") != skill_id or _version_text(str(metadata.get("version", ""))) != version:
            return None
        compatibility = metadata.get("runtime_compatibility", metadata.get("compatibility", metadata.get("runtime")))
        if not _compatible(compatibility, self.runtime_version):
            raise SkillReleaseError("skill release is incompatible with this runtime")
        skill_path = "" if manifest_path == "SKILL.md" else manifest_path.removesuffix("/SKILL.md")
        _skill_permissions(metadata)
        return SkillRelease(skill_id, version, tag, commit, skill_path, self.runtime_version, compatibility, metadata)

    def _tag_commit(self, tag: str) -> str:
        """Resolve only the exact tag namespace, never a same-named branch."""
        if not isinstance(tag, str) or not tag or "\x00" in tag:
            raise SkillReleaseError("skill release tag is malformed")
        try:
            commit = self._git("rev-parse", "--verify", f"refs/tags/{tag}^{{commit}}")
        except SkillReleaseError as error:
            raise SkillReleaseError("skill release tag is unavailable") from error
        if not _SHA.fullmatch(commit):
            raise SkillReleaseError("skill release tag is malformed")
        return commit

    def _release_files(self, release: SkillRelease) -> tuple[tuple[str, str], ...]:
        """Return source/blob paths, always anchored to the resolved commit."""
        tree_args = (release.commit,) if not release.skill_path else (release.commit, "--", release.skill_path)
        files = tuple(path for path in self._git("ls-tree", "-r", "--name-only", *tree_args).splitlines() if path)
        if not files:
            raise SkillReleaseError("skill release has no files")
        result: list[tuple[str, str]] = []
        for source in files:
            if release.skill_path:
                prefix = f"{release.skill_path}/"
                if not source.startswith(prefix):
                    raise SkillReleaseError("skill release tree is malformed")
                relative = source[len(prefix):]
            else:
                relative = source
            _safe_path(Path("/skill-release"), relative)
            result.append((source, relative))
        return tuple(result)

    def _release_digest(self, release: SkillRelease) -> dict[str, str]:
        digest: dict[str, str] = {}
        for source, relative in self._release_files(release):
            digest[relative] = hashlib.sha256(self._git_bytes("show", f"{release.commit}:{source}")).hexdigest()
        return digest

    def _release_tree_digest(self, release: SkillRelease) -> dict[str, str]:
        result: dict[str, str] = {".": "dir:0555"}
        for _, relative in self._release_files(release):
            parts = relative.split("/")
            for index in range(1, len(parts)):
                result["/".join(parts[:index])] = "dir:0555"
            result[relative] = "file:0444"
        return result

    def resolve(self, skill_id: str, version: str) -> SkillRelease:
        if not isinstance(skill_id, str) or not _IDENTIFIER.fullmatch(skill_id): raise SkillReleaseError("skill identifier is unsafe")
        requested = _version_text(version)
        self._assert_authorized(skill_id, requested)
        for tag in self._tags(skill_id, requested):
            commit = self._tag_commit(tag)
            release = self._release_at_commit(skill_id, requested, tag, commit)
            if release is not None:
                return release
        raise SkillReleaseError("requested skill release was not found")

    def _state(self) -> dict[str, Any]:
        if not self.state_path.exists(): return {"selections": {}}
        try: value = json.loads(self.state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error: raise SkillReleaseError("skill selection state is malformed") from error
        if not isinstance(value, Mapping) or not isinstance(value.get("selections"), Mapping): raise SkillReleaseError("skill selection state is malformed")
        selections = value["selections"]
        if any(not isinstance(project_id, str) for project_id in selections):
            raise SkillReleaseError("skill selection state is malformed")
        self._assert_project_identities(tuple(selections))
        return {"selections": dict(selections)}

    def _save_state(self, state: Mapping[str, Any]) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        encoded = json.dumps(state, sort_keys=True, separators=(",", ":"))
        descriptor, pending_name = tempfile.mkstemp(prefix=f".{self.state_path.name}.", suffix=".pending", dir=str(self.state_path.parent))
        pending = Path(pending_name)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                descriptor = -1
                handle.write(encoded)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(pending, self.state_path)
        finally:
            if descriptor != -1:
                os.close(descriptor)
            try:
                pending.unlink()
            except FileNotFoundError:
                pass

    @staticmethod
    def _encoded_tag(tag: str) -> str:
        if not isinstance(tag, str) or not tag or "\x00" in tag:
            raise SkillReleaseError("skill release tag is malformed")
        encoded = base64.urlsafe_b64encode(tag.encode("utf-8")).decode("ascii").rstrip("=")
        if not encoded:
            raise SkillReleaseError("skill release tag is malformed")
        return encoded

    @staticmethod
    def _decoded_tag(encoded: str) -> str:
        try:
            raw = base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4))
            tag = raw.decode("utf-8")
        except (ValueError, UnicodeDecodeError) as error:
            raise SkillReleaseError("skill release authorization ref is malformed") from error
        if not tag:
            raise SkillReleaseError("skill release authorization ref is malformed")
        return tag

    def _authorization_ref(self, project_id: str, skill_id: str, version: str, tag: str) -> str:
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (project_id, skill_id)):
            raise SkillReleaseError("skill release authorization identity is unsafe")
        self._assert_project_identities((project_id,))
        self._assert_expected_tag(skill_id, version, tag)
        return f"refs/skill-release-authorizations/{project_id}/{skill_id}/{_version_text(version)}/{self._encoded_tag(tag)}"

    def _legacy_authorization_ref(self, skill_id: str, version: str, tag: str) -> str:
        """Return the trusted pre-project-scoped authorization ref shape."""
        if not isinstance(skill_id, str) or not _IDENTIFIER.fullmatch(skill_id):
            raise SkillReleaseError("skill release authorization identity is unsafe")
        self._assert_expected_tag(skill_id, version, tag)
        return f"refs/skill-release-authorizations/{skill_id}/{_version_text(version)}/{self._encoded_tag(tag)}"

    def _authorization_commit(self, ref: str) -> str | None:
        """Return a commit only when *ref* directly names a commit object.

        ``rev-parse <ref>^{commit}`` follows symbolic refs and annotated tags.
        Those indirections are unsafe for the durable authorization binding:
        they can change what a previously accepted ref means without changing
        the ref name.  Inspect the ref itself instead and fail closed when it
        is symbolic or names any non-commit object.
        """
        try:
            result = self._git(
                "for-each-ref",
                "--format=%(refname)%00%(objectname)%00%(objecttype)%00%(symref)",
                ref,
            )
        except SkillReleaseError:
            return None
        if not result:
            return None
        fields = result.split("\x00")
        if len(fields) != 4 or fields[0] != ref or fields[3] or fields[2] != "commit" or not _SHA.fullmatch(fields[1]):
            raise SkillReleaseError("skill release authorization ref is malformed")
        return fields[1]

    def _rollback_bindings(self, bindings: list[tuple[str, str]]) -> None:
        """Remove only refs created by the transaction when it cannot commit."""
        for ref, commit in reversed(bindings):
            try:
                self._git("update-ref", "--no-deref", "-d", ref, commit)
            except SkillReleaseError as error:
                # The expected-old-value guard means a pre-existing or
                # concurrently changed ref is never overwritten or deleted.
                if self._authorization_commit(ref) is None:
                    continue
                raise SkillReleaseError("skill release binding rollback failed") from error

    def _bind_authorization(self, project_id: str, skill_id: str, version: str, tag: str, commit: str, *, created_bindings: list[tuple[str, str]] | None = None) -> str:
        ref = self._authorization_ref(project_id, skill_id, version, tag)
        existing = self._authorization_commit(ref)
        created: list[tuple[str, str]] = []
        try:
            if existing is not None:
                if existing != commit:
                    raise SkillReleaseError("skill release authorization binding changed")
            else:
                try:
                    self._git("update-ref", "--no-deref", ref, commit, "0" * 40)
                except SkillReleaseError:
                    existing = self._authorization_commit(ref)
                    if existing != commit:
                        raise SkillReleaseError("skill release authorization binding could not be established")
                else:
                    created.append((ref, commit))
            self._bind_selection_tombstone(project_id, skill_id, version, commit, created_bindings=created)
        except BaseException:
            self._rollback_bindings(created)
            raise
        if created_bindings is not None:
            created_bindings.extend(created)
        return ref

    def _authorization_bindings(self, project_id: str, skill_id: str, version: str) -> tuple[tuple[str, str], ...]:
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (project_id, skill_id)):
            raise SkillReleaseError("skill release authorization identity is unsafe")
        self._assert_project_identities((project_id,))
        prefix = f"refs/skill-release-authorizations/{project_id}/{skill_id}/{_version_text(version)}/"
        try:
            refs = self._git("for-each-ref", "--format=%(refname)", prefix).splitlines()
        except SkillReleaseError:
            return ()
        bindings: list[tuple[str, str]] = []
        for ref in refs:
            if not ref.startswith(prefix):
                raise SkillReleaseError("skill release authorization ref is malformed")
            encoded = ref[len(prefix):]
            if not encoded or "/" in encoded:
                raise SkillReleaseError("skill release authorization ref is malformed")
            tag = self._decoded_tag(encoded)
            self._assert_expected_tag(skill_id, version, tag)
            if self._encoded_tag(tag) != encoded:
                raise SkillReleaseError("skill release authorization ref is malformed")
            commit = self._authorization_commit(ref)
            if commit is None:
                raise SkillReleaseError("skill release authorization ref is unavailable")
            bindings.append((tag, commit))
        return tuple(bindings)

    def _selection_tombstone_ref(self, project_id: str, skill_id: str, version: str) -> str:
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (project_id, skill_id)):
            raise SkillReleaseError("skill release authorization identity is unsafe")
        self._assert_project_identities((project_id,))
        return f"{_SELECTION_TOMBSTONE_PREFIX}/{project_id}/{skill_id}/{_version_text(version)}"

    def _selection_tombstone_commit(self, project_id: str, skill_id: str, version: str) -> str | None:
        ref = self._selection_tombstone_ref(project_id, skill_id, version)
        try:
            result = self._git(
                "for-each-ref",
                "--format=%(refname)%00%(objectname)%00%(objecttype)%00%(symref)",
                ref,
            )
        except SkillReleaseError:
            return None
        if not result:
            return None
        fields = result.split("\x00")
        if len(fields) != 4 or fields[0] != ref or fields[3] or fields[2] != "commit" or not _SHA.fullmatch(fields[1]):
            raise SkillReleaseError("skill release tombstone is malformed")
        return fields[1]

    def _bind_selection_tombstone(self, project_id: str, skill_id: str, version: str, commit: str, *, created_bindings: list[tuple[str, str]] | None = None) -> None:
        ref = self._selection_tombstone_ref(project_id, skill_id, version)
        existing = self._selection_tombstone_commit(project_id, skill_id, version)
        if existing is not None:
            if existing != commit:
                raise SkillReleaseError("skill release selection tombstone changed")
            return
        try:
            self._git("update-ref", "--no-deref", ref, commit, "0" * 40)
        except SkillReleaseError:
            existing = self._selection_tombstone_commit(project_id, skill_id, version)
            if existing != commit:
                raise SkillReleaseError("skill release selection tombstone could not be established")
        else:
            if created_bindings is not None:
                created_bindings.append((ref, commit))

    def _release_from_binding(self, skill_id: str, version: str, tag: str, commit: str) -> SkillRelease:
        self._assert_authorized(skill_id, _version_text(version))
        release = self._release_at_commit(skill_id, _version_text(version), tag, commit)
        if release is None:
            raise SkillReleaseError("skill release authorization source is unavailable")
        return release

    @staticmethod
    def _record(state: Mapping[str, Any], project_id: str, skill_id: str) -> Mapping[str, Any] | None:
        selections = state.get("selections")
        if not isinstance(selections, Mapping):
            raise SkillReleaseError("skill selection state is malformed")
        projects = selections.get(project_id)
        if projects is not None and not isinstance(projects, Mapping):
            raise SkillReleaseError("skill selection state is malformed")
        record = projects.get(skill_id) if isinstance(projects, Mapping) else None
        if record is not None and not isinstance(record, Mapping):
            raise SkillReleaseError("skill selection state is malformed")
        return record if isinstance(record, Mapping) else None

    def _set_record(self, state: dict[str, Any], project_id: str, skill_id: str, record: Mapping[str, Any]) -> None:
        selections = state.setdefault("selections", {})
        if not isinstance(selections, dict):
            raise SkillReleaseError("skill selection state is malformed")
        projects = selections.setdefault(project_id, {})
        if not isinstance(projects, dict):
            raise SkillReleaseError("skill selection state is malformed")
        projects[skill_id] = dict(record)

    def _projection_path(self, project_id: str, skill_id: str, version: str) -> Path:
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (project_id, skill_id)):
            raise SkillReleaseError("projection identity is unsafe")
        return self.projection_root / project_id / skill_id / _version_text(version)

    def _staging_path(self, project_id: str, skill_id: str, version: str) -> Path:
        return self.staging_root / project_id / skill_id / _version_text(version)

    def _remove_tree(self, path: Path) -> None:
        if not path.exists() and not path.is_symlink():
            return
        if _is_link_like(path) or path.is_file():
            path.unlink()
            return
        for child in sorted(path.rglob("*"), key=lambda item: len(item.parts), reverse=True):
            try:
                if _is_link_like(child):
                    child.unlink()
                    continue
                if child.is_file():
                    child.chmod(0o600)
                elif child.is_dir():
                    child.chmod(0o700)
            except OSError:
                pass
        try:
            path.chmod(0o700)
        except OSError:
            pass
        shutil.rmtree(path)

    def _cleanup_staging(self, project_id: str, skill_id: str, version: str) -> None:
        path = self._staging_path(project_id, skill_id, version)
        if path.exists() or path.is_symlink():
            self._remove_tree(path)

    @staticmethod
    def _set_read_only(root: Path) -> None:
        for path in root.rglob("*"):
            if path.is_file():
                path.chmod(0o444)
            elif path.is_dir():
                path.chmod(0o555)
        root.chmod(0o555)

    def _materialize(self, release: SkillRelease, stage: Path) -> dict[str, str]:
        expected: dict[str, str] = {}
        for source, relative in self._release_files(release):
            content = self._git_bytes("show", f"{release.commit}:{source}")
            target = _safe_path(stage, relative)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
            expected[relative] = hashlib.sha256(content).hexdigest()
        if _digest_files(stage) != expected:
            raise SkillReleaseError("skill release projection could not be verified")
        self._set_read_only(stage)
        return expected

    def _publish_stage(self, stage: Path, destination: Path) -> None:
        self._assert_no_links(self.projection_root, destination.parent)
        destination.parent.mkdir(parents=True, exist_ok=True)
        os.replace(stage, destination)

    @staticmethod
    def _assert_no_links(root: Path, target: Path) -> None:
        """Ensure publication/proposal parents cannot redirect through links."""
        if _is_link_like(root):
            raise SkillReleaseError("skill storage contains a symlink or junction")
        try:
            relative = target.relative_to(root)
        except ValueError as error:
            raise SkillReleaseError("skill storage path escapes its root") from error
        current = root
        for part in relative.parts:
            current = current / part
            if _is_link_like(current):
                raise SkillReleaseError("skill storage contains a symlink or junction")

    def _selection_from_record(self, state: dict[str, Any], project_id: str, skill_id: str, record: Mapping[str, Any]) -> tuple[SkillRelease, SkillProjection]:
        if not all(isinstance(value, str) and _IDENTIFIER.fullmatch(value) for value in (project_id, skill_id)):
            raise SkillReleaseError("skill selection identity is unsafe")
        version = record.get("version")
        tag = record.get("tag")
        commit = record.get("commit")
        if not isinstance(version, str) or not isinstance(tag, str) or not isinstance(commit, str):
            raise SkillReleaseError("selected skill release identity is malformed")
        requested = _version_text(version)
        self._assert_authorized(skill_id, requested)
        self._assert_project_authorized(project_id, skill_id, requested)
        record_path = record.get("path")
        if not isinstance(record_path, str) or self._projection_path(project_id, skill_id, requested) != Path(record_path):
            raise SkillReleaseError("selected skill release identity changed")
        if not _SHA.fullmatch(commit):
            raise SkillReleaseError("selected skill release identity is malformed")
        ref = self._authorization_ref(project_id, skill_id, requested, tag)
        trusted_commit = self._authorization_commit(ref)
        if trusted_commit is not None and trusted_commit != commit:
            raise SkillReleaseError("selected skill release authorization changed")
        authorization_ref = record.get("authorization_ref")
        authorization_format = record.get("authorization_format")
        if authorization_format is not None and authorization_format != _AUTHORIZATION_FORMAT:
            raise SkillReleaseError("selected skill release authorization format is malformed")
        legacy_migration = False
        if authorization_format == _AUTHORIZATION_FORMAT:
            if authorization_ref != ref or trusted_commit is None:
                raise SkillReleaseError("selected skill release authorization is unavailable")
        elif authorization_ref is not None:
            if not isinstance(authorization_ref, str):
                raise SkillReleaseError("selected skill release authorization is malformed")
            if authorization_ref == ref:
                # This is the project-scoped predecessor format written before
                # the explicit format marker was introduced.
                if any(key in record for key in ("resolved_source", "publication")):
                    raise SkillReleaseError("selected skill release authorization changed")
                if trusted_commit is None:
                    raise SkillReleaseError("selected skill release authorization is unavailable")
                legacy_migration = True
            else:
                old_ref = self._legacy_authorization_ref(skill_id, requested, tag)
                if authorization_ref != old_ref:
                    raise SkillReleaseError("selected skill release authorization changed")
                old_commit = self._authorization_commit(old_ref)
                if old_commit is None:
                    raise SkillReleaseError("selected skill release authorization is unavailable")
                if old_commit != commit:
                    raise SkillReleaseError("selected skill release authorization changed")
                if trusted_commit is not None and trusted_commit != old_commit:
                    raise SkillReleaseError("selected skill release authorization changed")
                legacy_migration = True
        elif trusted_commit is not None:
            # A record that lost its authorization_ref cannot be distinguished
            # from a forged current record, even when a project ref remains.
            # Only the exact old ref shape or a complete tag-only legacy record
            # may enter migration.
            raise SkillReleaseError("selected skill release authorization is unavailable")
        elif any(key in record for key in ("resolved_source", "publication", "authorization_format")):
            # Modern mutable metadata without its old trusted ref cannot be
            # downgraded into the weak tag-only migration path.
            raise SkillReleaseError("selected skill release authorization is unavailable")
        if legacy_migration and self._selection_tombstone_commit(project_id, skill_id, requested) is not None:
            raise SkillReleaseError("selected skill release legacy authorization was already migrated")
        resolved_source = record.get("resolved_source")
        if resolved_source is not None and (
            not isinstance(resolved_source, Mapping)
            or resolved_source.get("tag") != tag
            or resolved_source.get("commit") != commit
        ):
            raise SkillReleaseError("selected skill release authorization is malformed")
        publication = record.get("publication")
        if publication is not None and publication not in {"pending", "complete"}:
            raise SkillReleaseError("selected skill release publication state is malformed")
        release = self._release_at_commit(skill_id, requested, tag, commit)
        if release is None:
            raise SkillReleaseError("selected skill release is unavailable")
        expected_digest = self._release_digest(release)
        expected_tree_digest = self._release_tree_digest(release)
        digest = record.get("digest")
        if not isinstance(digest, Mapping) or dict(digest) != expected_digest:
            raise SkillReleaseError("selected skill release metadata changed")
        raw_tree_digest = record.get("tree_digest")
        if legacy_migration and raw_tree_digest is None:
            tree_digest = None
        else:
            tree_digest = _validate_tree_digest(raw_tree_digest)
        if tree_digest is not None and tree_digest != expected_tree_digest:
            raise SkillReleaseError("selected skill release tree metadata changed")
        if legacy_migration or (trusted_commit is None and authorization_ref is None):
            if not legacy_migration:
                if self._selection_tombstone_commit(project_id, skill_id, requested) is not None:
                    raise SkillReleaseError("selected skill release authorization is unavailable")
                if self._authorization_bindings(project_id, skill_id, requested):
                    raise SkillReleaseError("selected skill release authorization changed")
                # A pre-authorization-format state may be migrated only when
                # the Git tag still names the exact commit and both source/
                # projection bytes match the source. Mutable JSON evidence is
                # never enough.
                try:
                    tag_commit = self._tag_commit(tag)
                except SkillReleaseError as error:
                    raise SkillReleaseError("selected skill release authorization is unavailable") from error
                if tag_commit != commit:
                    raise SkillReleaseError("selected skill release authorization changed")
            path = self._projection_path(project_id, skill_id, requested)
            if not path.exists() or _is_link_like(path):
                projection = self._install_release(release, project_id=project_id, state=state, previous_record=record)
                return release, projection
            if _digest_files(path) != expected_digest or _tree_digest(path) != expected_tree_digest:
                raise SkillReleaseError("skill projection was tampered")
            created_bindings: list[tuple[str, str]] = []
            ref = self._bind_authorization(
                project_id,
                skill_id,
                requested,
                tag,
                commit,
                created_bindings=created_bindings,
            )
            try:
                migrated = dict(record)
                migrated.update({
                    "version": requested,
                    "tag": tag,
                    "commit": commit,
                    "path": str(path),
                    "digest": expected_digest,
                    "tree_digest": expected_tree_digest,
                    "resolved_source": {"tag": tag, "commit": commit},
                    "authorization_ref": ref,
                    "authorization_format": _AUTHORIZATION_FORMAT,
                })
                self._set_record(state, project_id, skill_id, migrated)
                self._save_state(state)
            except BaseException:
                # A legacy record remains the source of truth until its
                # migrated state is durable.  Remove only bindings created by
                # this migration so a failed write can be retried after a
                # restart without disturbing older authorization refs.
                self._rollback_bindings(created_bindings)
                raise
            record = migrated
        elif trusted_commit is not None:
            # Existing bindings must establish the durable rollback guard only
            # after every persisted metadata and projection check succeeds.
            # This also backfills refs created before tombstones were introduced
            # without leaving a tombstone behind for a rejected legacy record.
            self._bind_selection_tombstone(project_id, skill_id, requested, trusted_commit)
        else:
            raise SkillReleaseError("selected skill release authorization is unavailable")
        path = self._projection_path(project_id, skill_id, release.version)
        permissions = _skill_permissions(release.metadata)
        return release, SkillProjection(
            skill_id, project_id, release.version, release.tag, release.commit,
            path, expected_digest, dict(tree_digest or expected_tree_digest),
            permissions, False, dict(release.metadata),
        )

    def _install_release(self, release: SkillRelease, *, project_id: str, state: dict[str, Any], previous_record: Mapping[str, Any] | None = None) -> SkillProjection:
        _assert_path_ancestors_clear(self.projection_root)
        _assert_path_ancestors_clear(self.staging_root)
        destination = self._projection_path(project_id, release.skill_id, release.version)
        self._assert_no_links(self.projection_root, destination.parent)
        stage_parent = self._staging_path(project_id, release.skill_id, release.version)
        self._assert_no_links(self.staging_root, stage_parent)
        if _is_link_like(destination):
            raise SkillReleaseError("skill projection destination is a symlink or junction")
        if destination.exists() or destination.is_symlink():
            legacy_recovery = previous_record is not None and previous_record.get("authorization_format") is None
            if previous_record is not None and previous_record.get("publication") != "pending" and not legacy_recovery:
                raise SkillReleaseError("skill projection was tampered")
            self._remove_tree(destination)
        self._cleanup_staging(project_id, release.skill_id, release.version)
        stage_parent.mkdir(parents=True, exist_ok=True)
        stage = Path(tempfile.mkdtemp(prefix="attempt-", dir=str(stage_parent)))
        published = False
        try:
            ref = self._bind_authorization(project_id, release.skill_id, release.version, release.tag, release.commit)
            digest = self._materialize(release, stage)
            tree_digest = _tree_digest(stage)
            selection = {
                "version": release.version,
                "tag": release.tag,
                "commit": release.commit,
                "path": str(destination),
                "digest": digest,
                "tree_digest": tree_digest,
                "resolved_source": {"tag": release.tag, "commit": release.commit},
                "authorization_ref": ref,
                "authorization_format": _AUTHORIZATION_FORMAT,
                "publication": "pending",
            }
            self._set_record(state, project_id, release.skill_id, selection)
            # Persist the complete metadata before publication.  The record is
            # an install journal; use() still requires the Git ref and exact
            # projection bytes.  A retry can therefore finish after a crash
            # between these two atomic operations.
            self._save_state(state)
            self._publish_stage(stage, destination)
            published = True
            permissions = _skill_permissions(release.metadata)
            projection = SkillProjection(
                release.skill_id, project_id, release.version, release.tag,
                release.commit, destination, digest, tree_digest, permissions,
                False, dict(release.metadata),
            )
            self._verify(projection)
            selection["publication"] = "complete"
            self._set_record(state, project_id, release.skill_id, selection)
            self._save_state(state)
            return projection
        finally:
            if not published and (stage.exists() or stage.is_symlink()):
                self._remove_tree(stage)
            cleanup = stage_parent
            while cleanup != self.staging_root and cleanup.exists() and not any(cleanup.iterdir()):
                cleanup.rmdir()
                cleanup = cleanup.parent

    def install(self, skill_id: str, version: str, *, project_id: str, requested: bool = True) -> SkillProjection:
        _assert_path_ancestors_clear(self.projection_root)
        _assert_path_ancestors_clear(self.staging_root)
        requested_version = _version_text(version)
        with self._state_transaction():
            self._assert_project_authorized(project_id, skill_id, requested_version)
            # A project declaration is an approved selection in its own right.
            # It may be installed automatically, but only after the same
            # project-scoped authorization check above.  An unrequested
            # release with no declaration must remain fail-closed.
            if not requested:
                declared = self.project_releases.get(project_id, {}).get(skill_id)
                if declared is None or _version_text(declared) != requested_version:
                    raise SkillReleaseError("skill release installation requires an explicit request")
            state = self._state()
            record = self._record(state, project_id, skill_id)
            if record is not None:
                release, existing = self._selection_from_record(state, project_id, skill_id, record)
                if release.version != requested_version:
                    raise SkillReleaseError("a different skill release is already selected")
                if existing.path.exists():
                    try:
                        self._verify(existing)
                    except SkillReleaseError:
                        if record.get("publication") != "pending":
                            raise
                        return self._install_release(release, project_id=project_id, state=state, previous_record=record)
                    if record.get("publication") != "complete":
                        completed = dict(record)
                        completed["publication"] = "complete"
                        self._set_record(state, project_id, skill_id, completed)
                        self._save_state(state)
                    return existing
                # Recover a journaled selection without consulting the current tag.
                return self._install_release(release, project_id=project_id, state=state, previous_record=record)
            # A pre-existing project binding is still subordinate to the
            # global explicit approval policy; Git history cannot grant it.
            self._assert_authorized(skill_id, requested_version)
            bindings = self._authorization_bindings(project_id, skill_id, requested_version)
            if len(bindings) > 1:
                raise SkillReleaseError("skill release authorization is ambiguous")
            if bindings:
                release = self._release_from_binding(skill_id, requested_version, *bindings[0])
            else:
                release = self.resolve(skill_id, requested_version)
            return self._install_release(release, project_id=project_id, state=state)

    def selected(self, project_id: str, skill_id: str) -> SkillProjection:
        with self._state_transaction():
            _assert_path_ancestors_clear(self.projection_root)
            state = self._state()
            record = self._record(state, project_id, skill_id)
            if record is None:
                raise SkillReleaseError("skill release is not selected")
            recorded_path = record.get("path")
            if isinstance(recorded_path, str):
                self._assert_no_links(self.projection_root, Path(recorded_path))
            _, projection = self._selection_from_record(state, project_id, skill_id, record)
            return projection

    def selected_for_project(self, project_id: str) -> tuple[SkillProjection, ...]:
        with self._state_transaction():
            records = self._state()["selections"].get(project_id, {})
            if not isinstance(records, Mapping):
                raise SkillReleaseError("skill selection state is malformed")
            return tuple(self.selected(project_id, skill_id) for skill_id in sorted(records))

    def install_declared(self, project_id: str) -> tuple[SkillProjection, ...]:
        """Install every release declared for a project and return its inputs."""
        if not self._project_policy_configured:
            raise SkillReleaseError("project skill declarations are unavailable")
        declared = self.project_releases.get(project_id)
        if declared is None:
            raise SkillReleaseError("project skill declarations are unavailable")
        return tuple(
            self.install(skill_id, version, project_id=project_id, requested=False)
            for skill_id, version in sorted(declared.items())
        )

    def invocation_for_project(self, project_id: str) -> tuple[dict[str, Any], ...]:
        """Return verified normal skill metadata for a native Hermes session."""
        return tuple(projection.invocation for projection in self.selected_for_project(project_id))

    def _verify(self, projection: SkillProjection) -> None:
        if not projection.path.exists() or _is_link_like(projection.path):
            raise SkillReleaseError("skill projection is unavailable")
        if _digest_files(projection.path) != dict(projection.digest): raise SkillReleaseError("skill projection was tampered")
        if projection.tree_digest and _tree_digest(projection.path) != dict(projection.tree_digest):
            raise SkillReleaseError("skill projection tree was tampered")

    def use(self, project_id: str, skill_id: str) -> SkillProjection:
        projection = self.selected(project_id, skill_id)
        self._verify(projection)
        return projection

    def propose_edit(self, project_id: str, skill_id: str, relative_path: str, content: str) -> Path:
        with self._state_transaction():
            _assert_path_ancestors_clear(self.proposal_root)
            projection = self.selected(project_id, skill_id)
            proposal_base = self.proposal_root / project_id / skill_id / projection.version
            self._assert_no_links(self.proposal_root, proposal_base)
            target = _safe_path(proposal_base, relative_path)
            self._assert_no_links(proposal_base, target.parent)
            if _is_link_like(target):
                raise SkillReleaseError("skill proposal target is a symlink or junction")
            target.parent.mkdir(parents=True, exist_ok=True)
            if _is_link_like(target):
                raise SkillReleaseError("skill proposal target is a symlink or junction")
            descriptor, pending_name = tempfile.mkstemp(
                prefix=f".{target.name}.", suffix=".pending", dir=str(target.parent)
            )
            pending = Path(pending_name)
            try:
                with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                    descriptor = -1
                    handle.write(content)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(pending, target)
            finally:
                if descriptor != -1:
                    os.close(descriptor)
                try:
                    pending.unlink()
                except FileNotFoundError:
                    pass
            return target


__all__ = ("SkillRelease", "SkillProjection", "SkillReleaseError", "SkillReleaseLibrary")
