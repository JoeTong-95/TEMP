"""Authenticated local HTTP boundary for configured no-tool Hermes sessions.

This is a runtime owner, not Management authority: callers can submit a turn to
an already configured session but cannot select paths, models, tools, or keys.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
import argparse
from datetime import datetime, timezone
import hmac
import hashlib
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import subprocess
import threading
import contextlib
import ctypes
from typing import Any, Callable, Mapping
from urllib.parse import urlsplit
from uuid import uuid4

from .hermes_session_driver import HermesSessionDriver
from .hermes_workspace_tools import HermesWorkspaceTools, HermesWorkspaceToolError
from shared.contracts.agent_runtime import RuntimeClientError, validate_public_effect_receipt, validate_submission_fence
from .runtime_session_registry import RuntimeSessionRegistry, RuntimeSessionRegistryError
from .execution_profiles import APPROVED_EXECUTION_PROFILES_ENV, ExecutionProfile, ExecutionProfileError, LEGACY_HERMES_PROFILE, copy_profiles
from .sandbox_runner import SandboxRunner, SandboxRunnerError
from .sandcastle_backend import SandcastleBackend, SandcastleBridgeConfiguration
from .skill_releases import SkillReleaseError, SkillReleaseLibrary
from shared.contracts.storage_runtime_bundle import RuntimeBundleHttpClient, ServiceError as RuntimeBundleServiceError, UnknownRuntimeBundleOutcome
from .attended_chat_api import (
    AttendedChatApiError,
    _current_process_sid,
    _default_windows_acl_create,
    _default_windows_acl_query,
    validate_windows_authorization_custody,
)

_NON_LEASE_FENCE_KEYS = frozenset({"assignment_id", "repository", "issue_number", "approved_spec", "project_revision", "immutable_revision", "ancestry", "frontier_version"})


def _same_submission_fence(left: Mapping[str, Any] | None, right: Mapping[str, Any] | None) -> bool:
    """Compare assignment identity while allowing an explicitly renewed lease."""
    if not isinstance(left, Mapping) or not isinstance(right, Mapping):
        return left is right
    return all(left.get(key) == right.get(key) for key in _NON_LEASE_FENCE_KEYS)


def _exact_submission_fence(left: Mapping[str, Any] | None, right: Mapping[str, Any] | None) -> bool:
    """Compare the complete authenticated fence, including its lease."""
    return left == right

MAX_BODY = 64 * 1024
_SAFE_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_MISSING = object()
_PREPARED_CLEANUP_FIELDS = frozenset({"attempt_id", "session_id", "workspace", "runtime_home", "metadata", "phase", "state", "error", "created_at"})
_PREPARED_CLEANUP_OPTIONAL_FIELDS = frozenset({"project_id", "assignment_id", "submission_request_id", "compatibility_preparation", "offending_metadata_path"})


def _windows_create_json_noreplace(parent: Path, name: str, payload: bytes) -> bool:
    """Create *name* below an already selected Windows directory handle.

    Win32 has no descriptor-relative ``open`` equivalent.  NtCreateFile does,
    however: RootDirectory binds the create to the directory handle, so a
    junction/reparse replacement of the directory entry after validation cannot
    redirect this write.  This is deliberately kept behind a small seam so the
    race contract can be tested on non-Windows hosts.
    """
    if os.name != "nt":
        raise OSError("Windows handle-relative creation is unavailable")
    if not isinstance(name, str) or not name or "\\" in name or "/" in name:
        raise OSError("unsafe metadata name")
    if not parent.is_dir() or _is_reparse_point(parent):
        raise OSError("evidence parent is a reparse point")
    # Tests can force the Windows policy branch on POSIX.  Keep that seam
    # descriptor-relative as well; this is not a path-based fallback.
    if not hasattr(ctypes, "WinDLL"):
        directory = os.open(parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0))
        try:
            try:
                descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600, dir_fd=directory)
            except FileExistsError:
                return False
            try:
                os.write(descriptor, payload); os.fsync(descriptor)
            finally:
                os.close(descriptor)
            os.fsync(directory)
            return True
        finally:
            os.close(directory)
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    ntdll = ctypes.WinDLL("ntdll")
    INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
    FILE_LIST_DIRECTORY = 0x0001
    FILE_ADD_FILE = 0x0002
    FILE_WRITE_DATA = 0x0002
    FILE_SHARE_READ = 0x1; FILE_SHARE_WRITE = 0x2; FILE_SHARE_DELETE = 0x4
    OPEN_EXISTING = 3
    FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
    FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000
    FILE_ATTRIBUTE_NORMAL = 0x80
    FILE_CREATE = 2
    FILE_NON_DIRECTORY_FILE = 0x40
    FILE_SYNCHRONOUS_IO_NONALERT = 0x20
    SYNCHRONIZE = 0x00100000

    class _UnicodeString(ctypes.Structure):
        _fields_ = [("Length", ctypes.c_ushort), ("MaximumLength", ctypes.c_ushort),
                    ("Buffer", ctypes.c_wchar_p)]
    class _ObjectAttributes(ctypes.Structure):
        _fields_ = [("Length", ctypes.c_ulong), ("RootDirectory", ctypes.c_void_p),
                    ("ObjectName", ctypes.POINTER(_UnicodeString)), ("Attributes", ctypes.c_ulong),
                    ("SecurityDescriptor", ctypes.c_void_p), ("SecurityQualityOfService", ctypes.c_void_p)]
    class _IoStatus(ctypes.Structure):
        _fields_ = [("Status", ctypes.c_long), ("Information", ctypes.c_size_t)]

    k32.CreateFileW.restype = ctypes.c_void_p
    k32.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_void_p,
                                ctypes.c_ulong, ctypes.c_ulong, ctypes.c_void_p]
    k32.CloseHandle.argtypes = [ctypes.c_void_p]
    k32.WriteFile.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong,
                              ctypes.POINTER(ctypes.c_ulong), ctypes.c_void_p]
    k32.FlushFileBuffers.argtypes = [ctypes.c_void_p]
    ntdll.NtCreateFile.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_ulong, ctypes.POINTER(_ObjectAttributes),
                                   ctypes.POINTER(_IoStatus), ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong,
                                   ctypes.c_ulong, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong]
    ntdll.NtCreateFile.restype = ctypes.c_long
    # Open the parent itself with OPEN_REPARSE_POINT.  The resulting handle is
    # the authority for the entire create operation and remains open throughout.
    parent_handle = k32.CreateFileW(str(parent), FILE_LIST_DIRECTORY | FILE_ADD_FILE | SYNCHRONIZE,
                                    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                                    None, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, None)
    if not parent_handle or parent_handle == INVALID_HANDLE_VALUE:
        raise OSError(ctypes.get_last_error(), "cannot open evidence parent")
    try:
        encoded = name.encode("utf-16-le")
        filename = ctypes.create_unicode_buffer(name)
        unicode_name = _UnicodeString(len(encoded), len(encoded) + 2, ctypes.cast(filename, ctypes.c_wchar_p))
        # OBJ_DONT_REPARSE (0x1000) is required to prevent reparsing during
        # the relative lookup.  0x2000 is not a valid OBJECT_ATTRIBUTES flag
        # and makes NtCreateFile fail with STATUS_INVALID_PARAMETER.
        attributes = _ObjectAttributes(ctypes.sizeof(_ObjectAttributes), parent_handle,
                                       ctypes.pointer(unicode_name), 0x40 | 0x1000, None, None)
        status = _IoStatus(); file_handle = ctypes.c_void_p()
        result = ntdll.NtCreateFile(ctypes.byref(file_handle), FILE_WRITE_DATA | SYNCHRONIZE,
                                    ctypes.byref(attributes), ctypes.byref(status), None, FILE_ATTRIBUTE_NORMAL,
                                    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, FILE_CREATE,
                                    FILE_NON_DIRECTORY_FILE | FILE_SYNCHRONOUS_IO_NONALERT, None, 0)
        if result != 0:
            # STATUS_OBJECT_NAME_COLLISION is the expected idempotency result.
            if ctypes.c_ulong(result).value == 0xC0000035:
                return False
            raise OSError(f"NtCreateFile failed: 0x{ctypes.c_ulong(result).value:08x}")
        try:
            written = ctypes.c_ulong()
            buffer = ctypes.create_string_buffer(payload)
            if not k32.WriteFile(file_handle, buffer, len(payload), ctypes.byref(written), None) or written.value != len(payload) or not k32.FlushFileBuffers(file_handle):
                raise OSError(ctypes.get_last_error(), "evidence write failed")
        finally:
            k32.CloseHandle(file_handle)
        # Flush the directory handle after the file flush so the new name is
        # durable as well as the file contents.  Failure is explicit: callers
        # must preserve foreign state and enter reconciliation rather than
        # treating an unverified evidence write as success.
        if not k32.FlushFileBuffers(parent_handle):
            raise OSError(ctypes.get_last_error(), "evidence directory flush failed")
        return True
    finally:
        k32.CloseHandle(parent_handle)


def _windows_final_path_inside_root(final_path: str, expected_root: Path) -> bool:
    """Check a native final path without consulting a replaceable pathname."""
    def clean(value: str) -> str:
        value = os.path.normcase(value.rstrip("\\/"))
        for prefix in ("\\\\?\\", "\\\\.\\"):
            if value.startswith(prefix):
                value = value[len(prefix):]
        return value
    final = clean(final_path)
    root = clean(os.fspath(expected_root))
    if not final or not root:
        return False
    return final == root or final.startswith(root + "\\")


def _windows_native_handle_path(handle: Any, ctypes: Any, kernel32: Any) -> str:
    kernel32.GetFinalPathNameByHandleW.restype = ctypes.c_uint32
    size = 512
    while size <= 32768:
        buffer = ctypes.create_unicode_buffer(size)
        length = kernel32.GetFinalPathNameByHandleW(handle, buffer, size, 0)
        if length == 0:
            raise OSError(ctypes.get_last_error(), "GetFinalPathNameByHandleW failed")
        if length < size:
            return buffer.value.rstrip("\\")
        size *= 2
    raise OSError("native path is too long")


def _windows_handle_identity(handle: Any, ctypes: Any, kernel32: Any) -> tuple[int, int, int]:
    class _FileTime(ctypes.Structure):
        _fields_ = [("dwLowDateTime", ctypes.c_uint32),
                    ("dwHighDateTime", ctypes.c_uint32)]

    # BY_HANDLE_FILE_INFORMATION is a DWORD-packed native record.  Modeling
    # FILETIME as c_uint64 changes the offsets on 64-bit Python and makes the
    # volume/file index values come from the wrong bytes.
    class _Info(ctypes.Structure):
        _fields_ = [("dwFileAttributes", ctypes.c_uint32),
                    ("ftCreationTime", _FileTime),
                    ("ftLastAccessTime", _FileTime),
                    ("ftLastWriteTime", _FileTime),
                    ("dwVolumeSerialNumber", ctypes.c_uint32),
                    ("nFileSizeHigh", ctypes.c_uint32),
                    ("nFileSizeLow", ctypes.c_uint32),
                    ("nNumberOfLinks", ctypes.c_uint32),
                    ("nFileIndexHigh", ctypes.c_uint32),
                    ("nFileIndexLow", ctypes.c_uint32)]
    assert ctypes.sizeof(_Info) == 52
    assert _Info.dwVolumeSerialNumber.offset == 28
    assert _Info.nFileIndexHigh.offset == 44
    assert _Info.nFileIndexLow.offset == 48
    info = _Info()
    kernel32.GetFileInformationByHandle.restype = ctypes.c_int
    if not kernel32.GetFileInformationByHandle(handle, ctypes.byref(info)):
        raise OSError(ctypes.get_last_error(), "GetFileInformationByHandle failed")
    return (info.dwVolumeSerialNumber, info.nFileIndexHigh, info.nFileIndexLow)


def _windows_open_parent(path: Path) -> tuple[Any, Any, Any, str]:
    ctypes = __import__("ctypes")
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateFileW.restype = ctypes.c_void_p
    handle = k32.CreateFileW(str(path), 0x80, 1 | 2 | 4, None, 3,
                             0x02000000 | 0x00200000, None)
    invalid = ctypes.c_void_p(-1).value
    raw = getattr(handle, "value", handle)
    if raw in (None, 0, -1, invalid):
        raise OSError(ctypes.get_last_error(), "cannot open metadata parent")
    try:
        return handle, ctypes, k32, _windows_native_handle_path(handle, ctypes, k32)
    except BaseException:
        k32.CloseHandle(handle)
        raise


class _WindowsJsonHandleTransaction:
    """One validated source handle, retained through read/archive/delete."""

    def __init__(self, handle: Any, ctypes_module: Any, kernel32: Any,
                 identity: tuple[int, int, int]) -> None:
        self.handle = handle
        self.ctypes = ctypes_module
        self.kernel32 = kernel32
        self.identity = identity
        self._closed = False

    def read(self) -> bytes:
        ctypes, k32 = self.ctypes, self.kernel32
        k32.GetFileSizeEx.restype = ctypes.c_int
        k32.GetFileSizeEx.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_longlong)]
        size = ctypes.c_longlong()
        if not k32.GetFileSizeEx(self.handle, ctypes.byref(size)) or size.value < 0 or size.value > MAX_BODY:
            raise OSError("metadata source is too large or unreadable")
        k32.ReadFile.restype = ctypes.c_int
        k32.ReadFile.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong,
                                 ctypes.POINTER(ctypes.c_ulong), ctypes.c_void_p]
        buffer = ctypes.create_string_buffer(int(size.value))
        read = ctypes.c_ulong()
        if size.value and (not k32.ReadFile(self.handle, buffer, int(size.value), ctypes.byref(read), None)
                           or read.value != size.value):
            raise OSError(ctypes.get_last_error(), "metadata source read failed")
        return buffer.raw[:read.value]

    def write(self, payload: bytes) -> None:
        ctypes, k32 = self.ctypes, self.kernel32
        k32.WriteFile.restype = ctypes.c_int
        k32.WriteFile.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong,
                                  ctypes.POINTER(ctypes.c_ulong), ctypes.c_void_p]
        buffer = ctypes.create_string_buffer(payload)
        written = ctypes.c_ulong()
        if (not k32.WriteFile(self.handle, buffer, len(payload), ctypes.byref(written), None)
                or written.value != len(payload) or not k32.FlushFileBuffers(self.handle)):
            raise OSError(ctypes.get_last_error(), "metadata source write failed")

    def delete(self) -> None:
        ctypes, k32 = self.ctypes, self.kernel32
        # FileDispositionInformation (13) takes BOOLEAN DeleteFile, while
        # FileDispositionInformationEx (64) takes the multi-flag structure.
        class _Disposition(ctypes.Structure):
            _fields_ = [("DeleteFile", ctypes.c_ubyte)]
        disposition = _Disposition(1)
        setter = k32.SetFileInformationByHandle
        setter.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong]
        setter.restype = ctypes.c_int
        if not setter(self.handle, 13, ctypes.byref(disposition), ctypes.sizeof(disposition)):
            raise OSError(ctypes.get_last_error(), "metadata removal failed")

    def close(self) -> None:
        if not self._closed:
            self.kernel32.CloseHandle(self.handle)
            self._closed = True


def _windows_open_json_identity_bound(parent: Path, name: str, *,
                                      expected_root: Path | None = None,
                                      access: int = 0x00010000 | 0x00040000) -> _WindowsJsonHandleTransaction:
    """Open, validate, and retain one non-reparse source object."""
    if os.name != "nt":
        raise OSError("Windows handle-relative removal is unavailable")
    if not isinstance(name, str) or not name or "\\" in name or "/" in name:
        raise OSError("unsafe metadata name")
    if _is_reparse_point(parent):
        raise OSError("metadata parent is a reparse point")
    if not hasattr(ctypes, "WinDLL"):
        raise OSError("Windows handle-relative removal is unavailable")
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    handle = k32.CreateFileW(
        str(parent / name), access,
        0x1 | 0x2 | 0x4, None, 3, 0x02000000 | 0x00200000, None,
    )
    invalid = ctypes.c_void_p(-1).value
    raw = getattr(handle, "value", handle)
    if raw in (None, 0, -1, invalid):
        raise OSError(ctypes.get_last_error(), "cannot open metadata for removal")
    try:
        final_path = _windows_native_handle_path(handle, ctypes, k32)
        if _windows_handle_is_reparse(handle, ctypes, k32):
            raise OSError("metadata source is a reparse point")
        if expected_root is not None and not _windows_final_path_inside_root(final_path, expected_root):
            raise OSError("metadata source escaped runtime root")
        source_path = Path(final_path)
        actual_parent, _, _, actual_parent_path = _windows_open_parent(source_path.parent)
        try:
            parent_identity = _windows_handle_identity(actual_parent, ctypes, k32)
            if expected_root is not None and not _windows_final_path_inside_root(actual_parent_path, expected_root):
                raise OSError("metadata parent escaped runtime root")
        finally:
            k32.CloseHandle(actual_parent)
        if parent_identity != _windows_handle_identity_from_path(parent, ctypes, k32):
            raise OSError("metadata parent was replaced")
        return _WindowsJsonHandleTransaction(
            handle, ctypes, k32, _windows_handle_identity(handle, ctypes, k32))
    except BaseException:
        k32.CloseHandle(handle)
        raise


def _windows_handle_identity_from_path(path: Path, ctypes: Any, kernel32: Any) -> tuple[int, int, int]:
    """Open a directory only for identity comparison, then close it."""
    opened, _, _, _ = _windows_open_parent(path)
    try:
        return _windows_handle_identity(opened, ctypes, kernel32)
    finally:
        kernel32.CloseHandle(opened)


def _windows_handle_is_reparse(handle: Any, ctypes: Any, kernel32: Any) -> bool:
    class _FileBasicInfo(ctypes.Structure):
        _fields_ = [("CreationTime", ctypes.c_int64),
                    ("LastAccessTime", ctypes.c_int64),
                    ("LastWriteTime", ctypes.c_int64),
                    ("ChangeTime", ctypes.c_int64),
                    ("FileAttributes", ctypes.c_uint32)]

    assert ctypes.sizeof(_FileBasicInfo) == 40
    assert _FileBasicInfo.FileAttributes.offset == 32
    basic = _FileBasicInfo()
    kernel32.GetFileInformationByHandleEx.restype = ctypes.c_int
    if not kernel32.GetFileInformationByHandleEx(
            handle, 0, ctypes.byref(basic), ctypes.sizeof(basic)):
        raise OSError(ctypes.get_last_error(), "GetFileInformationByHandleEx failed")
    return bool(basic.FileAttributes & 0x400)


def _windows_remove_json_identity_bound(parent: Path, name: str, *,
                                        expected_root: Path | None = None) -> None:
    txn = _windows_open_json_identity_bound(parent, name, expected_root=expected_root)
    try:
        txn.delete()
    finally:
        txn.close()


def _is_reparse_point(path: Path) -> bool:
    try:
        return bool(getattr(os.lstat(path), "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    except FileNotFoundError:
        return False
    except OSError:
        return True


def _unsafe_path_boundary(path: Path) -> bool:
    return (path.is_symlink() or _is_reparse_point(path) or
            any(parent.is_symlink() or _is_reparse_point(parent) for parent in path.parents))


def _prepared_directory_identity(path: Path) -> tuple[int, int] | None:
    """Return the identity of one non-reparse directory without following it."""
    try:
        value = os.lstat(path)
    except FileNotFoundError:
        return None
    except OSError as error:
        raise RuntimeServiceError("prepared attempt path is unavailable") from error
    if (not stat.S_ISDIR(value.st_mode) or path.is_symlink() or
            _is_reparse_point(path)):
        raise RuntimeServiceError("prepared attempt path is unsafe")
    return int(value.st_dev), int(value.st_ino)


def _move_directory_noreplace(source: Path, destination: Path) -> None:
    """Atomically move one directory without replacing an existing name."""
    if os.name == "nt":
        if not hasattr(ctypes, "WinDLL"):
            raise OSError("atomic no-replace directory move is unavailable")
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.MoveFileExW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32]
        kernel32.MoveFileExW.restype = ctypes.c_int
        # Omitting MOVEFILE_REPLACE_EXISTING gives the required no-replace
        # destination semantics.  WRITE_THROUGH makes the handoff durable.
        if not kernel32.MoveFileExW(str(source), str(destination), 0x00000008):
            error = ctypes.get_last_error()
            if error in (80, 183):
                raise FileExistsError(error, "quarantine destination exists")
            raise OSError(error, "prepared attempt quarantine move failed")
        return
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    source_parent_fd = os.open(source.parent, flags)
    destination_parent_fd = os.open(destination.parent, flags)
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        renameat2 = getattr(libc, "renameat2", None)
        if renameat2 is None:
            raise OSError("atomic no-replace directory move is unavailable")
        renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        renameat2.restype = ctypes.c_int
        if renameat2(source_parent_fd, os.fsencode(source.name), destination_parent_fd,
                     os.fsencode(destination.name), 2) != 0:  # RENAME_NOREPLACE
            error = ctypes.get_errno()
            if error == 17:
                raise FileExistsError(error, "quarantine destination exists")
            raise OSError(error, "prepared attempt quarantine move failed")
    finally:
        os.close(destination_parent_fd)
        os.close(source_parent_fd)


def _prepared_metadata_unlink_checkpoint(_path: Path, _stage: str) -> None:
    """Fault-injection seam immediately after the authenticated handoff."""
    return None


class RuntimeServiceError(ValueError):
    pass


class _RuntimeAdmissionBlocked(RuntimeServiceError):
    """A final admission decision rejected a prepared turn deterministically."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__("runtime admission blocked: " + reason)


class _TurnFenceExpired(RuntimeServiceError):
    """Private control flow for a lease expiring at an admission gate."""


@dataclass(frozen=True)
class PreparedAssignmentAttempt:
    """An operator-prepared, immutable source revision and private roots."""

    attempt_id: str
    session_id: str
    project_id: str
    revision_id: str
    immutable_revision: str
    workspace: str
    runtime_home: str
    assignment_id: str | None = None
    submission_fence: Mapping[str, Any] | None = None
    submission_request_id: str | None = None

    def __post_init__(self) -> None:
        if (not all(isinstance(value, str) and _SAFE_IDENTIFIER.fullmatch(value)
                    for value in (self.attempt_id, self.session_id, self.project_id, self.revision_id))
                or not isinstance(self.immutable_revision, str)
                or re.fullmatch(r"[0-9a-f]{40,64}", self.immutable_revision) is None):
            raise RuntimeServiceError("prepared attempt identity is invalid")
        for value in (self.workspace, self.runtime_home):
            path = Path(value)
            if not isinstance(value, str) or path.is_absolute() or ".." in path.parts or not path.parts:
                raise RuntimeServiceError("prepared attempt root is invalid")
        if self.assignment_id is not None and (not isinstance(self.assignment_id, str) or not _SAFE_IDENTIFIER.fullmatch(self.assignment_id)):
            raise RuntimeServiceError("prepared assignment identity is invalid")
        if self.submission_request_id is not None and (not isinstance(self.submission_request_id, str) or not _SAFE_IDENTIFIER.fullmatch(self.submission_request_id)):
            raise RuntimeServiceError("prepared submission request identity is invalid")
        if self.submission_fence is not None:
            try: fence = validate_submission_fence(self.submission_fence, check_expiry=False)
            except RuntimeClientError as error: raise RuntimeServiceError("prepared submission fence is invalid") from error
            if self.assignment_id is None or fence["assignment_id"] != self.assignment_id or fence["immutable_revision"] != self.immutable_revision:
                raise RuntimeServiceError("prepared submission fence does not match the assignment")
            object.__setattr__(self, "submission_fence", _copy_json(fence))


@dataclass(frozen=True)
class SessionConfiguration:
    identity: Mapping[str, Any]
    binding: Mapping[str, Any]
    workspace: str
    project_ids: frozenset[str]
    workspace_tools: bool = False
    execution_profile: str = "legacy-hermes"


@dataclass(frozen=True)
class RuntimeServiceConfiguration:
    runtime_root: Path
    workspace_root: Path
    checkpoint_root: Path
    python: str
    source_root: Path
    gateway_api_key: str = field(repr=False)
    bearer_scopes: Mapping[str, frozenset[str]] = field(repr=False)
    sessions: Mapping[str, SessionConfiguration]
    timeout_seconds: int = 180
    approved_bindings: Mapping[str, Mapping[str, Any]] = field(default_factory=dict, repr=False)
    bearer_project_scopes: Mapping[str, frozenset[str]] = field(default_factory=dict, repr=False)
    registry_database: Path | None = None
    project_workspaces: Mapping[str, frozenset[str]] = field(default_factory=dict, repr=False)
    project_workspace_tools: Mapping[str, frozenset[str]] = field(default_factory=dict, repr=False)
    execution_profiles: Mapping[str, ExecutionProfile] = field(default_factory=lambda: {LEGACY_HERMES_PROFILE.profile_id: LEGACY_HERMES_PROFILE}, repr=False)
    project_execution_profiles: Mapping[str, str] = field(default_factory=dict, repr=False)
    runtime_bundle_client: RuntimeBundleHttpClient | None = field(default=None, repr=False)
    runtime_bundle_bindings: Mapping[str, tuple[str, str]] = field(default_factory=dict, repr=False)
    sandbox_backend: SandcastleBridgeConfiguration | None = field(default=None, repr=False)
    prepared_attempts: Mapping[str, PreparedAssignmentAttempt] = field(default_factory=dict, repr=False)
    frontier_authority: "RuntimeFrontierAuthority | None" = field(default=None, repr=False)
    frontier_authority_required: bool = field(default=False, repr=False)
    skill_library: SkillReleaseLibrary | None = field(default=None, repr=False)


# The authority is deliberately a narrow, synchronous seam.  It receives the
# already-authenticated submission fence and returns a bounded admission
# decision immediately before Runtime launches a runner.
RuntimeFrontierAuthority = Callable[[Mapping[str, Any]], Mapping[str, Any]]


_FRONTIER_AUTHORITY_SCHEMA = "agent-stack.runtime-frontier-authority"
_FRONTIER_AUTHORITY_REASON = re.compile(r"[a-z][a-z0-9_.-]{0,63}")


def _open_authority_parent(path: Path) -> int:
    """Open an absolute authority parent as a retained no-follow directory."""
    if not path.is_absolute() or os.name != "posix":
        raise OSError("descriptor-relative authority parent unavailable")
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    current = os.open(os.sep, flags)
    try:
        relative = path.relative_to(Path(os.sep))
        for component in relative.parts:
            if not component:
                continue
            child = os.open(component, flags, dir_fd=current)
            os.close(current)
            current = child
        return current
    except BaseException:
        os.close(current)
        raise


def _authority_snapshot(path: Path) -> bytes:
    """Capture one stable, bounded, regular authority object.

    Validation and reading are deliberately descriptor/handle-bound.  The
    pathname checks at the end ensure the configured name still names the
    object that was parsed.
    """
    if not path.is_absolute() or _unsafe_path_boundary(path):
        raise OSError("authority path is unsafe")
    if os.name == "posix":
        parent_fd = _open_authority_parent(path.parent)
        final_fd = None
        try:
            parent_before = os.fstat(parent_fd)
            final_fd = os.open(path.name, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0), dir_fd=parent_fd)
            before = os.fstat(final_fd)
            if not stat.S_ISREG(before.st_mode):
                raise OSError("authority is not regular")
            chunks: list[bytes] = []
            remaining = MAX_BODY + 1
            while remaining:
                chunk = os.read(final_fd, min(65536, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            raw = b"".join(chunks)
            after = os.fstat(final_fd)
            parent_after = os.fstat(parent_fd)
            if len(raw) > MAX_BODY or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
                raise OSError("authority changed during read")
            if (parent_before.st_dev, parent_before.st_ino) != (parent_after.st_dev, parent_after.st_ino):
                raise OSError("authority parent changed during read")
            named = os.lstat(path)
            named_parent = os.lstat(path.parent)
            if ((named.st_dev, named.st_ino) != (after.st_dev, after.st_ino)
                    or (named_parent.st_dev, named_parent.st_ino) != (parent_after.st_dev, parent_after.st_ino)):
                raise OSError("authority pathname was rebound")
            return raw
        finally:
            if final_fd is not None:
                os.close(final_fd)
            os.close(parent_fd)
    if os.name != "nt":
        raise OSError("authority platform unavailable")
    # Windows has no descriptor-relative CRT open.  Native CreateFileW with
    # OPEN_REPARSE_POINT pins the final object; retain both handles through the
    # bounded read and verify canonical identity before returning.
    import msvcrt
    parent_handle, ctypes_module, kernel32, parent_name = _windows_open_parent(path.parent)
    final_handle = None
    fd = None
    try:
        parent_identity = _windows_handle_identity(parent_handle, ctypes_module, kernel32)
        kernel32.CreateFileW.restype = ctypes_module.c_void_p
        final_handle = kernel32.CreateFileW(str(path), 0x80000000, 1 | 2 | 4, None, 3, 0x02000000 | 0x00200000, None)
        invalid = ctypes_module.c_void_p(-1).value
        raw_handle = getattr(final_handle, "value", final_handle)
        if raw_handle in (None, 0, -1, invalid):
            final_handle = None
            raise OSError("authority final handle unavailable")
        if _windows_handle_is_reparse(final_handle, ctypes_module, kernel32):
            raise OSError("authority final handle unavailable")
        final_name = _windows_native_handle_path(final_handle, ctypes_module, kernel32)
        if not _windows_final_path_inside_root(final_name, path.parent):
            raise OSError("authority escaped configured parent")
        actual_parent, _, _, _ = _windows_open_parent(Path(final_name).parent)
        try:
            if _windows_handle_identity(actual_parent, ctypes_module, kernel32) != parent_identity:
                raise OSError("authority parent was replaced")
        finally:
            kernel32.CloseHandle(actual_parent)
        fd = msvcrt.open_osfhandle(int(getattr(final_handle, "value", final_handle)), os.O_RDONLY | os.O_BINARY)
        final_handle = None
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise OSError("authority is not regular")
        chunks: list[bytes] = []
        remaining = MAX_BODY + 1
        while remaining:
            chunk = os.read(fd, min(65536, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        raw = b"".join(chunks)
        after = os.fstat(fd)
        if len(raw) > MAX_BODY or (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
            raise OSError("authority changed during read")
        named = os.stat(path)
        if (named.st_ino, named.st_size, named.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
            raise OSError("authority pathname was rebound")
        return raw
    finally:
        if fd is not None:
            os.close(fd)
        if final_handle is not None:
            kernel32.CloseHandle(final_handle)
        kernel32.CloseHandle(parent_handle)


class FileRuntimeFrontierAuthority:
    """Read the Management-published, assignment-scoped frontier decision.

    Runtime does not compute or own the Project Frontier.  Management publishes
    a small authenticated-fence projection to this explicitly configured local
    source; Runtime rereads it at final admission so a revocation or frontier
    change is observed without mutating a live service object.
    """

    _IDENTITY_FIELDS = (
        "repository", "issue_number", "approved_spec", "project_revision",
        "immutable_revision", "ancestry", "frontier_version",
    )

    def __init__(self, state_file: str | Path) -> None:
        path = Path(state_file)
        if not path.is_absolute():
            raise RuntimeServiceError("runtime frontier authority source is invalid")
        self.state_file = path

    def _unavailable(self) -> Mapping[str, Any]:
        return {"eligible": False, "reason": "frontier_authority_unavailable"}

    def __call__(self, fence: Mapping[str, Any]) -> Mapping[str, Any]:
        try:
            if not isinstance(fence, Mapping):
                return self._unavailable()
            payload = json.loads(_authority_snapshot(self.state_file).decode("utf-8"))
            if (not isinstance(payload, Mapping)
                    or set(payload) != {"schema", "assignments"}
                    or payload.get("schema") != _FRONTIER_AUTHORITY_SCHEMA
                    or not isinstance(payload["assignments"], Mapping)):
                return self._unavailable()
            assignment_id = fence.get("assignment_id")
            record = payload["assignments"].get(assignment_id)
            if (not isinstance(assignment_id, str)
                    or not isinstance(record, Mapping)
                    or set(record) not in ({"fence", "status"}, {"fence", "status", "reason"})
                    or not isinstance(record.get("fence"), Mapping)):
                return self._unavailable()
            try:
                embedded_assignment_id = record["fence"].get("assignment_id")
                if (not isinstance(embedded_assignment_id, str)
                        or not _SAFE_IDENTIFIER.fullmatch(embedded_assignment_id)
                        or embedded_assignment_id != assignment_id):
                    return {"eligible": False, "reason": "frontier_identity_changed"}
                current = validate_submission_fence(record["fence"], check_expiry=False)
            except RuntimeClientError:
                return self._unavailable()
            if any(current.get(field) != fence.get(field) for field in self._IDENTITY_FIELDS):
                reason = ("frontier_version_changed"
                          if current.get("frontier_version") != fence.get("frontier_version")
                          else "frontier_identity_changed")
                return {"eligible": False, "reason": reason}
            if current.get("lease_id") != fence.get("lease_id"):
                return {"eligible": False, "reason": "lease_revoked"}
            status = record.get("status")
            if status == "eligible" and set(record) == {"fence", "status"}:
                return {"eligible": True}
            if status == "blocked" and set(record) == {"fence", "status", "reason"}:
                reason = record.get("reason")
                if isinstance(reason, str) and _FRONTIER_AUTHORITY_REASON.fullmatch(reason):
                    return {"eligible": False, "reason": reason}
            return self._unavailable()
        except Exception:
            return self._unavailable()


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _workspace_toolset_name(session_id: str) -> str:
    """Native toolset names are bounded and cannot safely embed arbitrary IDs."""
    return "agentstack_workspace_" + hashlib.sha256(session_id.encode("utf-8")).hexdigest()[:24]


_SKILL_LIBRARY_ENVIRONMENT = "HERMES_SKILL_RELEASE_LIBRARY"


def _skill_library_environment(library: SkillReleaseLibrary) -> str:
    """Serialize the startup-bound skill authority for the isolated CLI."""
    return json.dumps({
        "repository_root": str(library.repository_root),
        "projection_root": str(library.projection_root),
        "state_path": str(library.state_path),
        "runtime_version": library.runtime_version,
        "approved_releases": {skill: list(versions) for skill, versions in library.approved_releases.items()},
        "project_releases": {project: dict(releases) for project, releases in library.project_releases.items()},
        "proposal_root": str(library.proposal_root),
    }, sort_keys=True, separators=(",", ":"))


class HermesRuntimeService:
    def __init__(self, configuration: RuntimeServiceConfiguration, *, runner: Callable[..., subprocess.CompletedProcess[str]] | SandboxRunner | None = None, registry: RuntimeSessionRegistry | None = None, frontier_authority: RuntimeFrontierAuthority | None = None):
        # This service owns a stable, detached view of its managed allowlists.
        # A caller retaining the configuration object cannot broaden a live binding.
        try:
            profiles = copy_profiles(configuration.execution_profiles)
        except ExecutionProfileError as error:
            raise RuntimeServiceError(str(error)) from error
        self.config = replace(
            configuration,
            bearer_scopes={token: frozenset(scopes) for token, scopes in configuration.bearer_scopes.items()},
            sessions={session_id: SessionConfiguration(_copy_json(item.identity), _copy_json(item.binding), item.workspace, frozenset(item.project_ids), item.workspace_tools, item.execution_profile) for session_id, item in configuration.sessions.items()},
            approved_bindings={binding_id: _copy_json(binding) for binding_id, binding in configuration.approved_bindings.items()},
            bearer_project_scopes={token: frozenset(projects) for token, projects in configuration.bearer_project_scopes.items()},
            project_workspaces={project: frozenset(workspaces) for project, workspaces in configuration.project_workspaces.items()},
            project_workspace_tools={project: frozenset(workspaces) for project, workspaces in configuration.project_workspace_tools.items()},
            execution_profiles=profiles,
            project_execution_profiles=dict(configuration.project_execution_profiles),
            runtime_bundle_client=configuration.runtime_bundle_client,
            runtime_bundle_bindings=dict(configuration.runtime_bundle_bindings),
            sandbox_backend=configuration.sandbox_backend,
            prepared_attempts=dict(configuration.prepared_attempts),
            frontier_authority=configuration.frontier_authority,
            frontier_authority_required=configuration.frontier_authority_required,
        )
        if self.config.skill_library is not None and not isinstance(self.config.skill_library, SkillReleaseLibrary):
            raise RuntimeServiceError("skill library is invalid")
        self._skill_library_environment = (
            _skill_library_environment(self.config.skill_library)
            if self.config.skill_library is not None else None
        )
        # The default is a policy-aware compatibility runner.  It can execute
        # the legacy profile locally, but fails closed for coding profiles until
        # an enforcing container/Sandcastle adapter is supplied.
        self.runner = runner if runner is not None else SandboxRunner(
            backend=SandcastleBackend(self.config.sandbox_backend) if self.config.sandbox_backend is not None else None
        )
        configured_frontier_authority = frontier_authority if frontier_authority is not None else self.config.frontier_authority
        if configured_frontier_authority is not None and not callable(configured_frontier_authority):
            raise RuntimeServiceError("runtime frontier authority is invalid")
        if not isinstance(self.config.frontier_authority_required, bool):
            raise RuntimeServiceError("runtime frontier authority requirement is invalid")
        if configured_frontier_authority is None and self.config.frontier_authority_required:
            configured_frontier_authority = lambda _fence: {"eligible": False, "reason": "frontier_authority_unavailable"}
        # Capture the authority at construction.  Runtime admission must not
        # be broadened by mutating a live service after startup.
        self._frontier_authority = configured_frontier_authority
        if any(not isinstance(binding_id, str) or not _SAFE_IDENTIFIER.fullmatch(binding_id) or not isinstance(binding, Mapping) or _binding_has_sensitive_or_unsafe_fields(binding) for binding_id, binding in self.config.approved_bindings.items()):
            raise RuntimeServiceError("approved bindings are invalid")
        if any(not isinstance(project, str) or not isinstance(workspaces, frozenset) or (project in self.config.project_workspaces and not workspaces <= self.config.project_workspaces[project]) for project, workspaces in self.config.project_workspace_tools.items()):
            raise RuntimeServiceError("workspace tool project allowlists are invalid")
        if any(not isinstance(project, str) or not isinstance(profile_id, str) or profile_id not in self.config.execution_profiles for project, profile_id in self.config.project_execution_profiles.items()):
            raise RuntimeServiceError("project execution profile allowlist is invalid")
        if self.config.runtime_bundle_client is not None and any(not callable(getattr(self.config.runtime_bundle_client, name, None)) for name in ("publish", "reconcile", "materialize")):
            raise RuntimeServiceError("runtime bundle client is invalid")
        if any(not isinstance(session_id, str) or not _SAFE_IDENTIFIER.fullmatch(session_id) or not isinstance(scope, tuple) or len(scope) != 2 or any(not isinstance(value, str) or not _SAFE_IDENTIFIER.fullmatch(value) for value in scope) for session_id, scope in self.config.runtime_bundle_bindings.items()):
            raise RuntimeServiceError("runtime bundle bindings are invalid")
        if any(key != attempt.attempt_id or not isinstance(attempt, PreparedAssignmentAttempt)
               for key, attempt in self.config.prepared_attempts.items()):
            raise RuntimeServiceError("prepared attempts are invalid")
        self._prepared_attempts = dict(self.config.prepared_attempts)
        prepared_roots: list[Path] = []
        for attempt in self.config.prepared_attempts.values():
            workspace = self.config.workspace_root / attempt.workspace
            home = self.config.runtime_root / attempt.runtime_home
            if (workspace.is_symlink() or not workspace.is_dir() or home.is_symlink()
                    or not home.is_dir() or self.config.workspace_root.resolve() not in workspace.resolve().parents
                    or self.config.runtime_root.resolve() not in home.resolve().parents):
                raise RuntimeServiceError("prepared attempt roots are unavailable")
            prepared_roots.extend((workspace.resolve(), home.resolve()))
        if any(left == right or left in right.parents or right in left.parents
               for index, left in enumerate(prepared_roots) for right in prepared_roots[index + 1:]):
            raise RuntimeServiceError("prepared attempt roots must be distinct")
        self.registry = registry or (RuntimeSessionRegistry(self.config.registry_database, allowed_binding_ids=frozenset(self.config.approved_bindings), allowed_workspaces=self.config.project_workspaces) if self.config.registry_database is not None else None)
        for root, label in ((self.config.runtime_root, "runtime root"), (self.config.workspace_root, "workspace root"), (self.config.checkpoint_root, "checkpoint root"), (self.config.source_root, "source root")):
            if not root.is_absolute() or root.is_symlink() or not root.is_dir():
                raise RuntimeServiceError(f"{label} must be an existing non-symlink directory")
        if not (configuration.source_root / "agent_stack").is_dir() or (configuration.source_root / "agent_stack").is_symlink():
            raise RuntimeServiceError("source root must be the package source directory")
        if not self.config.gateway_api_key or self.config.timeout_seconds < 1 or self.config.timeout_seconds > 300:
            raise RuntimeServiceError("runtime service requires a bounded managed gateway credential and timeout")
        if any(not isinstance(token, str) or not token or not scopes for token, scopes in self.config.bearer_scopes.items()):
            raise RuntimeServiceError("runtime service requires non-empty bearer scopes")
        self._locks = {session_id: threading.RLock() for session_id in self.config.sessions}
        self._states = {session_id: {"state": "idle", "last_finished_at": None, "last_outcome": None} for session_id in self.config.sessions}
        self._preparation_lock = threading.RLock()
        self._prepared_assignment_ids: dict[str, str] = {}
        self._compatibility_provenance_key = self._load_compatibility_provenance_key()
        for session_id, item in self.config.sessions.items():
            if not isinstance(session_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", session_id) or not isinstance(item.workspace, str) or Path(item.workspace).is_absolute() or ".." in Path(item.workspace).parts:
                raise RuntimeServiceError("session configuration has an unsafe identifier or workspace")
            if not isinstance(item.identity, Mapping) or not isinstance(item.binding, Mapping) or not isinstance(item.workspace_tools, bool) or not item.project_ids or any(not isinstance(project_id, str) or not project_id for project_id in item.project_ids) or item.execution_profile not in self.config.execution_profiles:
                raise RuntimeServiceError("session configuration requires identity and binding objects")
            workspace = configuration.workspace_root / item.workspace
            if workspace.is_symlink() or not workspace.is_dir() or self.config.workspace_root.resolve() not in workspace.resolve().parents:
                raise RuntimeServiceError("configured session workspace is unavailable")
            if item.workspace_tools and not all(item.workspace in self.config.project_workspace_tools.get(project_id, frozenset()) for project_id in item.project_ids):
                raise RuntimeServiceError("workspace tools require explicit project allowlist")
        self._restore_prepared_attempt_receipts()
        self._discover_orphan_preparation_metadata()
        self._recover_prepared_cleanup_handoffs()
        if self.registry is not None and any(self.registry.has_session(session_id) for session_id in self.config.sessions):
            raise RuntimeServiceError("static session conflicts with an existing logical session")

    @property
    def frontier_authority(self) -> RuntimeFrontierAuthority | None:
        """Return the startup-bound frontier authority without exposing a setter."""
        return self._frontier_authority

    def _load_compatibility_provenance_key(self) -> bytes:
        """Load a runtime-owned secret used to authenticate ID-less preparation.

        The deterministic attempt/receipt identifiers are intentionally not an
        authorization primitive.  A separate, service-created key survives
        restart but cannot be supplied by a caller merely editing JSON.
        """
        path = self.config.runtime_root / ".compatibility-provenance"
        try:
            if _unsafe_path_boundary(path):
                raise RuntimeServiceError("compatibility provenance is unsafe")
            if os.name == "nt":
                # Creation installs the protected DACL before any bytes are
                # written.  A later custody query is mandatory; mode bits do
                # not prove Windows ACL ownership.
                try:
                    identity = _current_process_sid()
                    created = False
                    if not path.exists():
                        try:
                            _default_windows_acl_create(path, identity)
                            created = True
                        except FileExistsError:
                            # Creation lost a race; the winner is validated
                            # below through its ACL and reparse state.
                            pass
                    if _is_reparse_point(path):
                        raise RuntimeServiceError("compatibility provenance is unsafe")
                    entries, owner = _default_windows_acl_query(path)
                    if owner.upper() != identity.upper():
                        raise RuntimeServiceError("compatibility provenance custody is unsafe")
                    validate_windows_authorization_custody(entries, service_identity=identity)
                    key_txn = _windows_open_json_identity_bound(
                        path.parent, path.name, expected_root=self.config.runtime_root,
                        access=0x80000000 | 0x40000000)
                    try:
                        key = key_txn.read()
                        if len(key) != 32:
                            if not created:
                                raise RuntimeServiceError("compatibility provenance is invalid")
                            generated = secrets.token_bytes(32)
                            key_txn.write(generated)
                            key = generated
                    finally:
                        key_txn.close()
                    entries, owner = _default_windows_acl_query(path)
                    if owner.upper() != identity.upper():
                        raise RuntimeServiceError("compatibility provenance custody is unsafe")
                    validate_windows_authorization_custody(entries, service_identity=identity)
                    return key
                except (AttendedChatApiError, OSError, RuntimeServiceError) as error:
                    if isinstance(error, RuntimeServiceError):
                        raise
                    raise RuntimeServiceError("compatibility provenance custody is unavailable") from error
            key = secrets.token_bytes(32)
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
            try:
                fd = os.open(path, flags, 0o600)
            except FileExistsError:
                fd = None
            if fd is not None:
                try:
                    opened = os.fstat(fd)
                    if not stat.S_ISREG(opened.st_mode) or opened.st_uid != os.getuid() or opened.st_mode & 0o077:
                        raise RuntimeServiceError("compatibility provenance custody is unsafe")
                    if os.write(fd, key) != len(key):
                        raise OSError("short compatibility provenance write")
                    os.fsync(fd)
                finally:
                    os.close(fd)
                self._fsync_directory(path.parent)
                return key
            # O_EXCL lost the create race.  Open the winner without following
            # a symlink and bind all validation to the descriptor identity.
            fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0))
            try:
                opened = os.fstat(fd)
                if not stat.S_ISREG(opened.st_mode) or opened.st_uid != os.getuid() or opened.st_mode & 0o077:
                    raise RuntimeServiceError("compatibility provenance custody is unsafe")
                key = os.read(fd, 33)
                current = os.stat(path, follow_symlinks=False)
                if (opened.st_dev, opened.st_ino) != (current.st_dev, current.st_ino):
                    raise RuntimeServiceError("compatibility provenance ownership changed")
            finally:
                os.close(fd)
            if len(key) != 32:
                raise RuntimeServiceError("compatibility provenance is invalid")
            return key
        except (OSError, ValueError) as error:
            raise RuntimeServiceError("compatibility provenance is unavailable") from error

    def _compatibility_receipt_mac(self, value: Mapping[str, Any]) -> str:
        unsigned = {key: item for key, item in value.items() if key != "compatibility_receipt_mac"}
        payload = json.dumps(unsigned, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hmac.new(self._compatibility_provenance_key, payload, hashlib.sha256).hexdigest()

    def _quarantine_record_mac(self, value: Mapping[str, Any]) -> str:
        unsigned = {key: item for key, item in value.items() if key != "record_mac"}
        payload = json.dumps(unsigned, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hmac.new(self._compatibility_provenance_key, payload, hashlib.sha256).hexdigest()

    def _restore_prepared_attempt_receipts(self) -> None:
        quarantine_root = self.config.runtime_root / "prepared-attempt-quarantine"
        if quarantine_root.exists():
            if quarantine_root.is_symlink() or not quarantine_root.is_dir():
                raise RuntimeServiceError("prepared attempt quarantine is unsafe")
            for record_path in quarantine_root.glob("*.record.json"):
                attempt_id = record_path.name[:-len(".record.json")]
                if not _SAFE_IDENTIFIER.fullmatch(attempt_id) or record_path.is_symlink():
                    raise RuntimeServiceError("prepared attempt quarantine is invalid")
                try:
                    record = json.loads(record_path.read_text(encoding="utf-8"))
                except (OSError, ValueError) as error:
                    raise RuntimeServiceError("prepared attempt quarantine is invalid") from error
                archive_name = record.get("archive") if isinstance(record, Mapping) else None
                archive = quarantine_root / archive_name if isinstance(archive_name, str) else None
                try:
                    raw = archive.read_bytes() if archive is not None and archive.parent == quarantine_root and archive.name == archive_name and not archive.is_symlink() and archive.is_file() else None
                    archived = json.loads(raw.decode("utf-8")) if raw is not None else None
                    identity = record.get("receipt_identity") if isinstance(record, Mapping) else None
                    if (not isinstance(record, Mapping) or set(record) != {"attempt_id", "state", "reason", "archive", "receipt_sha256", "receipt_identity", "created_at", "record_mac"}
                            or record.get("attempt_id") != attempt_id or record.get("state") != "quarantined"
                            or not isinstance(record.get("record_mac"), str) or not hmac.compare_digest(record["record_mac"], self._quarantine_record_mac(record))
                            or not isinstance(raw, bytes) or hashlib.sha256(raw).hexdigest() != record.get("receipt_sha256")
                            or not isinstance(identity, Mapping) or archived != dict(archived)
                            or any(archived.get(key) != identity.get(key) for key in ("attempt_id", "receipt_id", "assignment_id", "project_id", "revision_id", "immutable_revision", "session_id"))
                            or identity.get("attempt_id") != attempt_id
                            or archived.get("state") != "prepared"):
                        raise RuntimeServiceError("prepared attempt quarantine archive is unauthenticated")
                except (OSError, ValueError, TypeError, UnicodeDecodeError, RuntimeServiceError) as error:
                    self._prepared_cleanup_early_reconciliation(attempt_id, str(error), offending_metadata_path=str(record_path))
                    continue
                self._prepared_attempts.pop(attempt_id, None)
                self._prepared_assignment_ids.pop(attempt_id, None)
        root = self.config.runtime_root / "prepared-attempts"
        if not root.exists():
            return
        if root.is_symlink() or not root.is_dir():
            raise RuntimeServiceError("prepared attempt receipt root is unsafe")
        restored: list[PreparedAssignmentAttempt] = []
        for path in sorted(root.glob("*.json")):
            if path.is_symlink() or path.parent != root or path.stat().st_size > MAX_BODY:
                raise RuntimeServiceError("prepared attempt receipt is unsafe")
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError) as error:
                raise RuntimeServiceError("prepared attempt receipt is invalid") from error
            required = {"attempt_id", "assignment_id", "project_id", "revision_id", "immutable_revision", "workspace", "runtime_home", "receipt_id", "state", "session_id", "created_at", "submission_fence"}
            if (isinstance(value, Mapping) and "submission_fence" in value
                    and "submission_request_id" not in value
                    and value.get("compatibility_preparation") is not True):
                self._quarantine_prepared_attempt_receipt(path, value)
                configured = self._prepared_attempts.get(path.stem)
                if configured is not None:
                    self._prepared_attempts.pop(path.stem, None)
                    self._prepared_assignment_ids.pop(path.stem, None)
                continue
            allowed = (required, required | {"submission_request_id"}, required | {"compatibility_preparation", "compatibility_receipt_mac"}, required | {"submission_request_id", "compatibility_preparation", "compatibility_receipt_mac"})
            compatibility_mac_valid = (not isinstance(value, Mapping) or "compatibility_receipt_mac" not in value
                                       or (isinstance(value.get("compatibility_receipt_mac"), str)
                                           and hmac.compare_digest(value["compatibility_receipt_mac"], self._compatibility_receipt_mac(value))))
            if (not isinstance(value, Mapping) or set(value) not in allowed or value.get("state") != "prepared"
                    or path.name != value.get("attempt_id", "") + ".json"
                    or not all(isinstance(value.get(key), str) and _SAFE_IDENTIFIER.fullmatch(value[key]) for key in ("attempt_id", "assignment_id", "project_id", "revision_id", "receipt_id", "session_id"))
                    or ("compatibility_preparation" in value and value["compatibility_preparation"] is not True)
                    or not compatibility_mac_valid):
                raise RuntimeServiceError("prepared attempt receipt is invalid")
            try:
                attempt = PreparedAssignmentAttempt(value["attempt_id"], value["session_id"], value["project_id"], value["revision_id"], value["immutable_revision"], value["workspace"], value["runtime_home"], value["assignment_id"], value.get("submission_fence"), value.get("submission_request_id"))
            except (RuntimeServiceError, KeyError, TypeError) as error:
                raise RuntimeServiceError("prepared attempt receipt is invalid") from error
            existing = self._prepared_attempts.get(attempt.attempt_id)
            if existing is not None and (existing.attempt_id, existing.session_id, existing.project_id, existing.revision_id, existing.immutable_revision, existing.workspace, existing.runtime_home, existing.assignment_id, existing.submission_fence, existing.submission_request_id) != (attempt.attempt_id, attempt.session_id, attempt.project_id, attempt.revision_id, attempt.immutable_revision, attempt.workspace, attempt.runtime_home, attempt.assignment_id, attempt.submission_fence, attempt.submission_request_id):
                raise RuntimeServiceError("prepared attempt receipt conflicts with configuration")
            restored.append(attempt)
            self._prepared_assignment_ids[attempt.attempt_id] = value["assignment_id"]
        for attempt in restored:
            self._prepared_attempt_roots(attempt)
            self._prepared_attempts[attempt.attempt_id] = attempt

    def _require_compatibility_preparation_receipt(self, attempt: PreparedAssignmentAttempt) -> Mapping[str, Any]:
        """Require a service-shaped durable receipt for omitted-ID preparation."""
        path = self._preparation_receipt_path(attempt.attempt_id)
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, UnicodeDecodeError) as error:
            raise RuntimeServiceError("prepared compatibility receipt is required") from error
        required = {"attempt_id", "assignment_id", "project_id", "revision_id", "immutable_revision",
                    "workspace", "runtime_home", "receipt_id", "state", "submission_fence",
                    "compatibility_preparation", "compatibility_receipt_mac", "session_id", "created_at"}
        expected_receipt_id = "preparation-" + hashlib.sha256(
            (attempt.attempt_id + attempt.immutable_revision).encode("utf-8")
        ).hexdigest()[:48]
        if (not isinstance(value, Mapping) or set(value) != required
                or value.get("compatibility_preparation") is not True
                or not isinstance(value.get("compatibility_receipt_mac"), str)
                or not hmac.compare_digest(value["compatibility_receipt_mac"], self._compatibility_receipt_mac(value))
                or value.get("state") != "prepared"
                or value.get("attempt_id") != attempt.attempt_id
                or value.get("assignment_id") != attempt.assignment_id
                or value.get("project_id") != attempt.project_id
                or value.get("revision_id") != attempt.revision_id
                or value.get("immutable_revision") != attempt.immutable_revision
                or value.get("workspace") != attempt.workspace
                or value.get("runtime_home") != attempt.runtime_home
                or value.get("receipt_id") != expected_receipt_id
                or value.get("session_id") != attempt.session_id
                or value.get("submission_fence") != attempt.submission_fence
                or not isinstance(value.get("created_at"), str) or not value["created_at"]):
            raise RuntimeServiceError("prepared compatibility receipt is invalid")
        return value

    def _read_authoritative_preparation_receipt(self, attempt: PreparedAssignmentAttempt) -> Mapping[str, Any]:
        """Read and fully authenticate the preparation receipt under the owner lock."""
        if attempt.submission_request_id is None:
            return self._require_compatibility_preparation_receipt(attempt)
        path = self._preparation_receipt_path(attempt.attempt_id)
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, UnicodeDecodeError) as error:
            raise RuntimeServiceError("prepared attempt receipt is invalid") from error
        required = {"attempt_id", "assignment_id", "project_id", "revision_id", "immutable_revision",
                    "workspace", "runtime_home", "receipt_id", "state", "submission_fence",
                    "submission_request_id", "session_id", "created_at"}
        expected_receipt_id = "preparation-" + hashlib.sha256(
            (attempt.attempt_id + attempt.immutable_revision).encode("utf-8")
        ).hexdigest()[:48]
        try:
            durable_fence = validate_submission_fence(value.get("submission_fence"), check_expiry=False)
        except (RuntimeClientError, AttributeError, TypeError, ValueError) as error:
            raise RuntimeServiceError("prepared attempt receipt is invalid") from error
        if (not isinstance(value, Mapping) or set(value) != required
                or value.get("attempt_id") != attempt.attempt_id
                or value.get("assignment_id") != attempt.assignment_id
                or value.get("project_id") != attempt.project_id
                or value.get("revision_id") != attempt.revision_id
                or value.get("immutable_revision") != attempt.immutable_revision
                or value.get("workspace") != attempt.workspace
                or value.get("runtime_home") != attempt.runtime_home
                or value.get("receipt_id") != expected_receipt_id
                or value.get("state") != "prepared"
                or value.get("submission_request_id") != attempt.submission_request_id
                or value.get("session_id") != attempt.session_id
                or not isinstance(value.get("created_at"), str) or not value["created_at"]
                or not _same_submission_fence(durable_fence, attempt.submission_fence)):
            raise RuntimeServiceError("prepared attempt receipt conflicts with the assignment")
        return {**value, "submission_fence": durable_fence}

    def _quarantine_prepared_attempt_receipt(self, path: Path, value: Mapping[str, Any]) -> None:
        """Remove an old receipt with no request identity from executable state."""
        attempt_id = path.stem
        if not _SAFE_IDENTIFIER.fullmatch(attempt_id):
            raise RuntimeServiceError("prepared attempt receipt is invalid")
        root = self.config.runtime_root / "prepared-attempt-quarantine"
        if root.is_symlink() or (root.exists() and not root.is_dir()):
            raise RuntimeServiceError("prepared attempt quarantine is unsafe")
        root.mkdir(mode=0o700, parents=True, exist_ok=True)
        if root.is_symlink():
            raise RuntimeServiceError("prepared attempt quarantine is unsafe")
        try:
            source_txn = None
            if os.name == "nt":
                # The source is opened exactly once and retained through the
                # archive write and handle-bound removal.  No later pathname
                # read/reopen can be redirected by a target replacement.
                source_txn = _windows_open_json_identity_bound(
                    path.parent, path.name, expected_root=self.config.runtime_root)
                raw = source_txn.read()
                source_identity = source_txn.identity
            else:
                source_identity = self._prepared_metadata_identity(path)
                if source_identity is None:
                    raise RuntimeServiceError("prepared receipt disappeared before quarantine")
            relative_parent = path.parent.relative_to(self.config.runtime_root)
            cursor = self.config.runtime_root
            source_ancestors = [list(map(int, (os.stat(cursor, follow_symlinks=False).st_dev,
                                                os.stat(cursor, follow_symlinks=False).st_ino)))]
            for component in relative_parent.parts:
                cursor = cursor / component
                stat_value = os.stat(cursor, follow_symlinks=False)
                source_ancestors.append([int(stat_value.st_dev), int(stat_value.st_ino)])
            if source_txn is None:
                raw = path.read_bytes()
            archived_value = json.loads(raw.decode("utf-8"))
        except (OSError, ValueError, UnicodeDecodeError, RuntimeServiceError) as error:
            if source_txn is not None:
                source_txn.close()
            raise RuntimeServiceError("prepared receipt quarantine source is unsafe") from error
        if not isinstance(archived_value, Mapping) or archived_value.get("attempt_id") != attempt_id:
            raise RuntimeServiceError("prepared receipt quarantine source identity is invalid")
        record = {
            "attempt_id": attempt_id,
            "state": "quarantined",
            "reason": "prepared receipt has no submission request identity",
            "receipt_sha256": hashlib.sha256(raw).hexdigest(),
            "archive": None,
            "receipt_identity": {key: archived_value.get(key) for key in ("attempt_id", "receipt_id", "assignment_id", "project_id", "revision_id", "immutable_revision", "session_id")},
            "created_at": _utc_now(),
        }
        target = root / f"{attempt_id}.json"
        if target.exists():
            existing = target.read_bytes()
            if existing != raw:
                target = root / f"{attempt_id}.{hashlib.sha256(raw).hexdigest()[:16]}.json"
        if not target.exists():
            if os.name == "nt":
                _windows_create_json_noreplace(root, target.name, raw)
            else:
                pending = target.with_name(f".{target.name}.{uuid4().hex}.pending")
                with pending.open("xb") as handle:
                    handle.write(raw)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(pending, target)
                self._fsync_directory(root)
        record["archive"] = target.name
        record["record_mac"] = self._quarantine_record_mac(record)
        record_path = root / f"{attempt_id}.record.json"
        if not record_path.exists():
            if os.name == "nt":
                payload = json.dumps(record, separators=(",", ":")).encode("utf-8")
                _windows_create_json_noreplace(root, record_path.name, payload)
            else:
                self._write_receipt(record_path, record)
        try:
            if os.name == "nt":
                if source_txn is None:
                    raise RuntimeServiceError("prepared receipt source handle is unavailable")
                source_txn.delete()
            else:
                parent_fd = self._open_trusted_metadata_parent(path, source_ancestors)
                try:
                    self._remove_prepared_metadata_file(path, expected_identity=source_identity, directory_fd=parent_fd)
                finally:
                    os.close(parent_fd)
            self._fsync_directory(path.parent)
        except (OSError, RuntimeServiceError) as error:
            raise RuntimeServiceError("prepared receipt quarantine could not be completed") from error
        finally:
            if source_txn is not None:
                source_txn.close()

    def _recover_prepared_cleanup_handoffs(self) -> None:
        """Replay runtime-owned cleanup handoffs discovered during startup."""
        root = self.config.runtime_root / "prepared-cleanup-handoffs"
        if not root.exists() or root.is_symlink() or not root.is_dir():
            return
        for handoff in sorted(root.glob("*.json")):
            if handoff.is_symlink() or handoff.parent != root:
                self._prepared_cleanup_early_reconciliation(
                    handoff.stem, f"foreign prepared cleanup handoff: {handoff}", handoff_path=str(handoff),
                    offending_metadata_path=str(handoff)
                )
                continue

            attempt_id = handoff.stem
            attempt = self._prepared_attempts.get(attempt_id)
            journal = None
            # Even a configured attempt does not authenticate a private file
            # that may have been replaced after handoff. Validate every
            # surviving receipt before cleanup can unlink it or its binding.
            try:
                if handoff.stat().st_size > MAX_BODY:
                    raise RuntimeServiceError("prepared cleanup handoff is too large")
                journal = json.loads(handoff.read_text(encoding="utf-8"))
                attempt = self._prepared_attempt_from_cleanup_receipt(attempt_id, journal, configured=attempt)
                self._prepared_attempt_roots(attempt)
                self._prepared_attempts[attempt_id] = attempt
            except (OSError, ValueError, KeyError, TypeError, RuntimeServiceError):
                self._prepared_cleanup_early_reconciliation(
                    attempt_id, f"prepared cleanup handoff is unrecoverable: {handoff}", handoff_path=str(handoff),
                    project_id=(journal.get("project_id") if isinstance(journal, Mapping) else None),
                    assignment_id=(journal.get("assignment_id") if isinstance(journal, Mapping) else None),
                    offending_metadata_path=str(handoff)
                )
                continue
            try:
                self._cleanup_prepared_installation(attempt_id, session_id=attempt.session_id)
            except RuntimeServiceError:
                # Cleanup persists reconciliation_required for owned failures;
                # startup must remain available for later explicit retry.
                continue

    def _discover_orphan_preparation_metadata(self) -> None:
        """Record atomic preparation files left without a cleanup journal."""
        pattern = re.compile(r"^\.([A-Za-z0-9][A-Za-z0-9._-]{0,127})\.json\.([0-9a-f]+)\.pending$")
        roots = (self.config.runtime_root / "prepared-attempts",
                 self.config.runtime_root / "prepared-attempt-bindings")
        for directory in roots:
            if not directory.exists() or directory.is_symlink() or _is_reparse_point(directory) or not directory.is_dir():
                continue
            try:
                candidates = sorted(directory.iterdir())
            except OSError:
                continue
            for path in candidates:
                match = pattern.fullmatch(path.name)
                if match is None:
                    continue
                attempt_id = match.group(1)
                configured = self._prepared_attempts.get(attempt_id)
                project_id = configured.project_id if configured is not None else None
                assignment_id = self._prepared_assignment_ids.get(attempt_id)
                try:
                    if path.is_symlink() or _is_reparse_point(path) or not path.is_file():
                        raise RuntimeServiceError("orphan preparation metadata is foreign")
                    if path.stat().st_size > MAX_BODY:
                        raise RuntimeServiceError("orphan preparation metadata is too large")
                    value = json.loads(path.read_text(encoding="utf-8"))
                    # Orphan metadata has no authenticated authority.  Even a
                    # well-shaped identifier in the untrusted bytes must not be
                    # copied into cleanup evidence; otherwise a forged file can
                    # manufacture project/assignment ownership claims.
                    if (not isinstance(value, Mapping) or value.get("attempt_id") != attempt_id
                            or not all(isinstance(value.get(key), str) and _SAFE_IDENTIFIER.fullmatch(value[key])
                                       for key in ("attempt_id", "assignment_id", "project_id", "revision_id", "session_id"))):
                        raise RuntimeServiceError("orphan preparation metadata is unauthenticated")
                    error = "orphan preparation metadata requires reconciliation"
                except (OSError, UnicodeDecodeError, ValueError, RuntimeServiceError) as exc:
                    error = str(exc)
                self._prepared_cleanup_early_reconciliation(
                    attempt_id, error, project_id=project_id, assignment_id=assignment_id,
                    offending_metadata_path=str(path),
                )

    def _prepared_attempt_from_cleanup_receipt(self, attempt_id: str, journal: Any, *, configured: PreparedAssignmentAttempt | None) -> PreparedAssignmentAttempt:
        """Authenticate a surviving preparation receipt before startup cleanup."""
        if (not isinstance(journal, Mapping) or not set(journal) <= (_PREPARED_CLEANUP_FIELDS | _PREPARED_CLEANUP_OPTIONAL_FIELDS)
                or not _PREPARED_CLEANUP_FIELDS <= set(journal)
                or any(key in journal and (type(journal[key]) is not bool if key == "compatibility_preparation" else not isinstance(journal[key], str))
                           for key in _PREPARED_CLEANUP_OPTIONAL_FIELDS)
                or journal.get("attempt_id") != attempt_id
                or journal.get("phase") not in {"handoff", "metadata_removed", "reconciliation_required"}
                or journal.get("state") not in {"active", "blocked", "completed"}):
            raise RuntimeServiceError("prepared cleanup handoff is invalid")
        members = journal.get("metadata")
        if not isinstance(members, list):
            raise RuntimeServiceError("prepared cleanup handoff is invalid")
        canonical = self.config.runtime_root / "prepared-attempts" / f"{attempt_id}.json"
        private = canonical.with_name(f".{canonical.name}.{attempt_id}.unlinking")
        binding = self.config.runtime_root / "prepared-attempt-bindings" / f"{attempt_id}.json"
        private_binding = binding.with_name(f".{binding.name}.{attempt_id}.unlinking")
        receipt_items = [item for item in members if isinstance(item, Mapping) and item.get("path") in {str(canonical), str(private)}]
        binding_items = [item for item in members if isinstance(item, Mapping) and item.get("path") in {str(binding), str(private_binding)}]
        if len(receipt_items) != 1 or len(binding_items) != 1:
            raise RuntimeServiceError("prepared cleanup receipt binding is invalid")
        receipt_path = Path(receipt_items[0]["path"])
        if not receipt_path.exists():
            if configured is not None and (receipt_items[0].get("deleted") is True or receipt_items[0].get("delete_intent") is True
                                           or journal.get("phase") == "reconciliation_required"):
                return configured
            raise RuntimeServiceError("prepared cleanup private receipt is missing")
        if receipt_path.is_symlink() or not receipt_path.is_file() or receipt_path.stat().st_size > MAX_BODY:
            raise RuntimeServiceError("prepared cleanup private receipt is unsafe")
        value = json.loads(receipt_path.read_text(encoding="utf-8"))
        required = {"attempt_id", "assignment_id", "project_id", "revision_id", "immutable_revision", "workspace", "runtime_home", "receipt_id", "state", "session_id", "created_at", "submission_fence"}
        identifier_fields = ("attempt_id", "assignment_id", "project_id", "revision_id", "receipt_id", "session_id")
        allowed_receipts = (required, required | {"submission_request_id"}, required | {"compatibility_preparation"}, required | {"submission_request_id", "compatibility_preparation"})
        if (not isinstance(value, Mapping) or set(value) not in allowed_receipts or value.get("state") != "prepared"
                or any(not isinstance(value.get(key), str) or _SAFE_IDENTIFIER.fullmatch(value[key]) is None for key in identifier_fields)
                or not isinstance(value.get("created_at"), str) or not value["created_at"]
                or value.get("attempt_id") != attempt_id
                or value.get("session_id") != journal.get("session_id")
                or value.get("workspace") != journal.get("workspace")
                or value.get("runtime_home") != journal.get("runtime_home")
                or ("compatibility_preparation" in journal and value.get("compatibility_preparation") != journal.get("compatibility_preparation"))
                or ("compatibility_preparation" in value and value.get("compatibility_preparation") is not True)
                or ("submission_request_id" in value and value.get("submission_request_id") != journal.get("submission_request_id"))):
            raise RuntimeServiceError("prepared cleanup private receipt does not match handoff")
        recovered = PreparedAssignmentAttempt(
            value["attempt_id"], value["session_id"], value["project_id"], value["revision_id"],
            value["immutable_revision"], value["workspace"], value["runtime_home"], value["assignment_id"], value["submission_fence"], value.get("submission_request_id"),
        )
        expected_attempt_id = self._preparation_attempt_id(
            recovered.session_id, recovered.project_id, recovered.revision_id,
            value["assignment_id"], recovered.immutable_revision,
        )
        expected_receipt_id = "preparation-" + hashlib.sha256((attempt_id + recovered.immutable_revision).encode("utf-8")).hexdigest()[:48]
        expected_workspace = str(Path("attempts") / attempt_id / "workspace")
        expected_runtime_home = str(Path("attempts") / attempt_id / "home")
        if (attempt_id != expected_attempt_id or value["receipt_id"] != expected_receipt_id
                or recovered.workspace != expected_workspace or recovered.runtime_home != expected_runtime_home):
            raise RuntimeServiceError("prepared cleanup private receipt identity is invalid")
        if configured is not None and configured != recovered:
            raise RuntimeServiceError("prepared cleanup private receipt conflicts with configuration")
        return recovered

    def register_session_intent(self, session_id: str, project_id: str, agent_identity: Mapping[str, Any], binding_id: str, workspace: str, owner_id: str, *, actor_role: str, caller_projects: frozenset[str]) -> dict[str, Any]:
        """Persist declarative metadata only; this does not create a runtime home or start work."""
        if self.registry is None or binding_id not in self.config.approved_bindings:
            raise RuntimeServiceError("dynamic session registration is unavailable")
        if session_id in self.config.sessions:
            raise RuntimeServiceError("dynamic session cannot replace a static session")
        try:
            record = self.registry.register(session_id, project_id, agent_identity, binding_id, workspace, owner_id, actor_role=actor_role, caller_projects=caller_projects)
        except RuntimeSessionRegistryError as error:
            raise RuntimeServiceError(str(error)) from error
        return {"session_id": record["session_id"], "project_id": record["project_id"], "desired_status": record["desired_status"], "revision": record["revision"]}

    def session_intent(self, session_id: str, *, actor_role: str, caller_projects: frozenset[str]) -> dict[str, Any]:
        if self.registry is None: raise RuntimeServiceError("dynamic session registry is unavailable")
        try: record = self.registry.get(session_id, actor_role=actor_role, caller_projects=caller_projects)
        except RuntimeSessionRegistryError as error: raise RuntimeServiceError(str(error)) from error
        return {"session_id": record["session_id"], "project_id": record["project_id"], "desired_status": record["desired_status"], "revision": record["revision"]}

    def _authorize(self, authorization: str | None, session_id: str) -> bool:
        supplied = authorization[7:] if authorization and authorization.startswith("Bearer ") else ""
        if session_id in self.config.sessions:
            return any(hmac.compare_digest(supplied, token) and session_id in scopes for token, scopes in self.config.bearer_scopes.items())
        if any(hmac.compare_digest(supplied, token) and session_id in scopes for token, scopes in self.config.bearer_scopes.items()): return True
        if self.registry is not None:
            try: project = self.registry.get(session_id, actor_role="controller", caller_projects=frozenset(self.registry.allowed_workspaces))["project_id"]
            except RuntimeSessionRegistryError: return False
            return any(hmac.compare_digest(supplied, token) and project in scopes for token, scopes in self.config.bearer_project_scopes.items())
        return False

    def _project_authorize(self, authorization: str | None, project_id: str) -> bool:
        supplied = authorization[7:] if authorization and authorization.startswith("Bearer ") else ""
        return any(hmac.compare_digest(supplied, token) and project_id in scopes for token, scopes in self.config.bearer_project_scopes.items())

    def _session_item(self, session_id: str) -> SessionConfiguration:
        item = self.config.sessions.get(session_id)
        if item is None and self.registry is not None:
            try:
                record = self.registry.get(session_id, actor_role="controller", caller_projects=frozenset(self.registry.allowed_workspaces))
            except RuntimeSessionRegistryError as error:
                raise RuntimeServiceError("unknown session") from error
            binding = self.config.approved_bindings.get(record["binding_id"])
            if not isinstance(binding, Mapping): raise RuntimeServiceError("registered session binding is unavailable")
            allowed = record["workspace"] in self.config.project_workspace_tools.get(record["project_id"], frozenset())
            profile_id = self.config.project_execution_profiles.get(record["project_id"], LEGACY_HERMES_PROFILE.profile_id)
            item = SessionConfiguration(record["agent_identity"], binding, record["workspace"], frozenset({record["project_id"]}), allowed, profile_id)
            self._locks.setdefault(session_id, threading.RLock()); self._states.setdefault(session_id, {"state": "idle", "last_finished_at": None, "last_outcome": None})
        if item is None:
            raise RuntimeServiceError("unknown session")
        if not isinstance(session_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", session_id):
            raise RuntimeServiceError("unsafe session")
        return item

    def _execution_profile(self, item: SessionConfiguration) -> ExecutionProfile:
        try:
            return self.config.execution_profiles[item.execution_profile]
        except KeyError as error:
            raise RuntimeServiceError("session execution profile is unavailable") from error

    def _session(self, session_id: str) -> tuple[SessionConfiguration, Path, Path]:
        item = self._session_item(session_id)
        home = self.config.runtime_root / session_id
        workspace = self.config.workspace_root / item.workspace
        home.mkdir(mode=0o700, exist_ok=True)
        if home.is_symlink() or not home.is_dir() or workspace.is_symlink() or not workspace.is_dir() or self.config.runtime_root.resolve() not in home.resolve().parents or self.config.workspace_root.resolve() not in workspace.resolve().parents:
            raise RuntimeServiceError("configured local session paths are unavailable")
        return item, home, workspace

    def _prepared_attempt_roots(self, attempt: PreparedAssignmentAttempt) -> tuple[Path, Path]:
        """Revalidate a configured prepared attempt before any filesystem use."""
        # Check the unresolved path before resolving it, then prove the result
        # remains under its configured root. This narrows filesystem TOCTOU
        # exposure but cannot make replacement races impossible cross-platform.
        def prepared_root(root: Path, relative: str, label: str) -> Path:
            if root.is_symlink() or not root.is_dir():
                raise RuntimeServiceError(f"{label} parent root is unavailable")
            raw = root / relative
            if raw.is_symlink() or not raw.is_dir():
                raise RuntimeServiceError(f"prepared {label} is unavailable")
            try:
                resolved = raw.resolve(strict=True)
                resolved.relative_to(root.resolve(strict=True))
            except (OSError, ValueError) as error:
                raise RuntimeServiceError(f"prepared {label} escapes its configured root") from error
            return resolved
        workspace = prepared_root(self.config.workspace_root, attempt.workspace, "workspace")
        home = prepared_root(self.config.runtime_root, attempt.runtime_home, "runtime home")
        if workspace == home or workspace in home.parents or home in workspace.parents:
            raise RuntimeServiceError("prepared attempt roots must be disjoint")
        return home, workspace

    def _reserve_prepared_attempt_parent(self, root: Path, attempt_id: str, label: str) -> tuple[Path, tuple[int, int]]:
        """Create and bind one deterministic attempt parent before its children."""
        attempts = root / "attempts"
        if (_unsafe_path_boundary(root) or root.is_symlink() or not root.is_dir() or
                _unsafe_path_boundary(attempts)):
            raise RuntimeServiceError(f"prepared {label} parent root is unsafe")
        try:
            attempts.mkdir(mode=0o700, exist_ok=True)
        except OSError as error:
            raise RuntimeServiceError(f"prepared {label} parent root is unavailable") from error
        if (_unsafe_path_boundary(attempts) or not attempts.is_dir()):
            raise RuntimeServiceError(f"prepared {label} parent root is unsafe")
        parent = attempts / attempt_id
        try:
            parent.mkdir(mode=0o700)
        except FileExistsError as error:
            raise RuntimeServiceError("prepared attempt roots already exist without a receipt") from error
        except OSError as error:
            raise RuntimeServiceError(f"prepared {label} reservation is unavailable") from error
        identity = _prepared_directory_identity(parent)
        if identity is None:
            raise RuntimeServiceError(f"prepared {label} reservation disappeared")
        return parent, identity

    @staticmethod
    def _prepared_child_identity(path: Path) -> tuple[int, int] | None:
        """Read a child directory identity without trusting marker contents."""
        return _prepared_directory_identity(path)

    def _quarantine_prepared_attempt_parent(
        self,
        parent: Path,
        parent_identity: tuple[int, int],
        child: Path,
        child_identity: tuple[int, int] | None,
        label: str,
    ) -> Path | None:
        """Claim an exact reserved parent and leave it as terminal evidence."""
        current_parent = _prepared_directory_identity(parent)
        if current_parent != parent_identity:
            return None
        current_child = self._prepared_child_identity(child)
        if current_child != child_identity:
            return None
        quarantine_root = parent.parent.parent / "prepared-attempt-quarantine"
        if (_unsafe_path_boundary(quarantine_root) or
                (quarantine_root.exists() and not quarantine_root.is_dir())):
            raise RuntimeServiceError(f"prepared {label} quarantine is unsafe")
        quarantine_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        if (_unsafe_path_boundary(quarantine_root) or not quarantine_root.is_dir()):
            raise RuntimeServiceError(f"prepared {label} quarantine is unsafe")
        destination = quarantine_root / f"{parent.name}-{uuid4().hex}"
        _move_directory_noreplace(parent, destination)

        # The move is terminal.  Validate only the moved directory and the
        # expected direct child; never walk, resolve, or recursively remove the
        # quarantine pathname.  A replacement at the quarantine name therefore
        # survives this failure path.
        moved_parent = _prepared_directory_identity(destination)
        moved_child = self._prepared_child_identity(destination / child.name)
        if moved_parent != parent_identity or moved_child != child_identity:
            # If the destination is still the exact object we moved, a child
            # replacement raced the claim.  Restore the whole parent only
            # while its canonical name is absent and the destination identity
            # is still authenticated.  This preserves the replacement at its
            # public path and never deletes or walks either object.
            if moved_parent == parent_identity and _prepared_directory_identity(parent) is None:
                try:
                    _move_directory_noreplace(destination, parent)
                except (OSError, RuntimeServiceError):
                    pass
            raise RuntimeServiceError(f"prepared {label} quarantine identity changed")
        return destination

    def _cleanup_failed_prepared_attempt(
        self,
        source: Path,
        workspace: Path,
        home: Path,
        reservations: tuple[tuple[Path, tuple[int, int], Path, tuple[int, int] | None, str], ...],
    ) -> None:
        """Quarantine only still-authenticated preparation roots."""
        failures: list[BaseException] = []
        workspace_quarantined = False
        for parent, parent_identity, child, child_identity, label in reservations:
            try:
                moved = self._quarantine_prepared_attempt_parent(
                    parent, parent_identity, child, child_identity, label)
                if moved is not None and label == "workspace":
                    workspace_quarantined = True
            except (OSError, RuntimeServiceError) as error:
                failures.append(error)

        # Git's administrative worktree entry is path-independent.  It may be
        # pruned only after the canonical workspace is absent; no quarantine
        # path is supplied to Git and no quarantine contents are inspected.
        if workspace_quarantined and self._prepared_child_identity(workspace) is None:
            try:
                subprocess.run(
                    ["git", "-C", str(source), "worktree", "prune"],
                    check=True, capture_output=True, text=True, timeout=30,
                )
            except (OSError, subprocess.SubprocessError) as error:
                failures.append(error)
        if failures:
            raise RuntimeServiceError("prepared attempt cleanup could not be completed") from failures[0]

    @staticmethod
    def _prepared_metadata_identity(path: Path) -> tuple[int, int] | None:
        if _unsafe_path_boundary(path):
            raise RuntimeServiceError("prepared metadata path is unsafe")
        try:
            # Path.exists() suppresses some Windows access errors and can
            # therefore turn an inaccessible replacement into an apparent
            # absence.  lstat gives recovery a fail-closed distinction.
            metadata = os.lstat(path)
        except FileNotFoundError:
            return None
        except OSError as error:
            raise RuntimeServiceError("prepared metadata path is unavailable") from error
        if not stat.S_ISREG(metadata.st_mode):
            raise RuntimeServiceError("prepared metadata path is not a regular file")
        return int(metadata.st_dev), int(metadata.st_ino)

    @staticmethod
    def _remove_prepared_metadata_file(path: Path, *, expected_identity: tuple[int, int] | None | object = _MISSING, directory_fd: int | None = None) -> None:
        if expected_identity is _MISSING:
            expected_identity = HermesRuntimeService._prepared_metadata_identity(path)
        current = HermesRuntimeService._prepared_metadata_identity(path)
        if current is None:
            if expected_identity is None:
                return
            raise RuntimeServiceError("prepared metadata path disappeared during cleanup")
        if expected_identity is None or current != expected_identity:
            raise RuntimeServiceError("prepared metadata ownership changed")
        if os.name != "posix":
            raise RuntimeServiceError("identity-bound metadata cleanup is unavailable")
        parent = path.parent
        flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
        try:
            parent_fd = directory_fd if directory_fd is not None else os.open(parent, flags)
            try:
                current_stat = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
                if (int(current_stat.st_dev), int(current_stat.st_ino)) != expected_identity:
                    raise RuntimeServiceError("prepared metadata ownership changed")
                os.unlink(path.name, dir_fd=parent_fd)
            finally:
                if directory_fd is None:
                    os.close(parent_fd)
        except FileNotFoundError:
            raise RuntimeServiceError("prepared metadata path disappeared during cleanup")
        HermesRuntimeService._fsync_directory(parent)

    def _open_trusted_metadata_parent(self, path: Path, expected_ancestors: list[list[int]] | None = None) -> int:
        """Open metadata's parent by no-follow traversal from runtime_root."""
        relative = path.parent.relative_to(self.config.runtime_root)
        flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
        if os.name != "posix" or not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
            raise RuntimeServiceError("identity-bound metadata cleanup is unavailable")
        root_stat = os.stat(self.config.runtime_root, follow_symlinks=False)
        expected = [tuple(item) for item in expected_ancestors] if expected_ancestors is not None else None
        if expected is not None and (not expected or tuple(map(int, (root_stat.st_dev, root_stat.st_ino))) != expected[0]):
            raise RuntimeServiceError("prepared metadata root ownership changed")
        fd = os.open(self.config.runtime_root, flags)
        try:
            opened_root = os.fstat(fd)
            if (int(root_stat.st_dev), int(root_stat.st_ino)) != (int(opened_root.st_dev), int(opened_root.st_ino)):
                raise RuntimeServiceError("prepared metadata root ownership changed")
            for index, component in enumerate(relative.parts, start=1):
                next_fd = os.open(component, flags, dir_fd=fd)
                if expected is not None:
                    opened = os.fstat(next_fd)
                    if index >= len(expected) or (int(opened.st_dev), int(opened.st_ino)) != expected[index]:
                        os.close(next_fd)
                        raise RuntimeServiceError("prepared metadata parent ownership changed")
                os.close(fd); fd = next_fd
            return fd
        except Exception:
            os.close(fd)
            raise

    def _prepared_cleanup_handoff_path(self, attempt_id: str) -> Path:
        if not _SAFE_IDENTIFIER.fullmatch(attempt_id):
            raise RuntimeServiceError("prepared attempt identity is invalid")
        return self.config.runtime_root / "prepared-cleanup-handoffs" / (attempt_id + ".json")

    @staticmethod
    def _prepared_canonical_metadata_path(path: Path, attempt_id: str) -> Path:
        """Return the canonical name represented by a private handoff path."""
        suffix = f".{attempt_id}.unlinking"
        if path.name.endswith(suffix):
            if not path.name.startswith("."):
                raise RuntimeServiceError("prepared metadata handoff name is malformed")
            basename = path.name[1:-len(suffix)]
            if not basename or (basename.startswith(".") and
                                re.fullmatch(rf"\.{re.escape(attempt_id)}\.json\.[0-9a-f]+\.pending", basename) is None):
                raise RuntimeServiceError("prepared metadata handoff name is malformed")
            return path.with_name(basename)
        return path

    @classmethod
    def _require_prepared_canonical_metadata_absent(cls, path: Path, attempt_id: str) -> None:
        """Fail closed if either represented cleanup name has been recreated."""
        canonical = cls._prepared_canonical_metadata_path(path, attempt_id)
        private = canonical.with_name(f".{canonical.name}.{attempt_id}.unlinking")
        # _prepared_metadata_identity rejects symlinks/reparse points and
        # non-regular files, and lstat preserves inaccessible-path failures.
        for represented in (canonical, private):
            try:
                present = cls._prepared_metadata_identity(represented)
            except RuntimeServiceError as error:
                raise RuntimeServiceError("prepared canonical metadata was recreated") from error
            if present is not None:
                raise RuntimeServiceError("prepared canonical metadata was recreated")

    @classmethod
    def _require_prepared_canonical_private_coexistence_absent(cls, path: Path, attempt_id: str) -> None:
        """Reject a canonical journal entry when both represented names exist."""
        canonical = cls._prepared_canonical_metadata_path(path, attempt_id)
        if path != canonical:
            return
        private = canonical.with_name(f".{canonical.name}.{attempt_id}.unlinking")
        if (cls._prepared_metadata_identity(canonical) is not None
                and cls._prepared_metadata_identity(private) is not None):
            raise RuntimeServiceError("prepared canonical metadata was recreated")

    def _prepared_cleanup_early_reconciliation(self, attempt_id: str, error: str, *, handoff_path: str | None = None,
                                               project_id: str | None = None, assignment_id: str | None = None,
                                               offending_metadata_path: str | None = None) -> None:
        """Best-effort durable evidence for failures before the journal exists."""
        try:
            # This evidence is itself a runtime-owned artifact.  Validate the
            # root before creating anything below it and reject reparse
            # components so a junction/symlink cannot redirect the write.
            runtime_root = self.config.runtime_root
            if (not runtime_root.is_absolute() or _unsafe_path_boundary(runtime_root)
                    or not runtime_root.is_dir()):
                return
            root = self.config.runtime_root / "prepared-cleanup-reconciliation"
            root.mkdir(mode=0o700, exist_ok=True)
            target = root / (attempt_id + ".json")
            resolved_root = runtime_root.resolve(strict=True)
            if (_unsafe_path_boundary(root) or target.is_symlink() or _is_reparse_point(target)
                    or target.resolve(strict=False).parent != root.resolve(strict=True)
                    or os.path.commonpath((str(resolved_root), str(target.resolve(strict=False)))) != str(resolved_root)):
                return
            value = {"attempt_id": attempt_id, "state": "reconciliation_required", "error": error, "created_at": _utc_now()}
            if handoff_path is not None:
                value["handoff_path"] = handoff_path
            if isinstance(project_id, str) and _SAFE_IDENTIFIER.fullmatch(project_id): value["project_id"] = project_id
            if isinstance(assignment_id, str) and _SAFE_IDENTIFIER.fullmatch(assignment_id): value["assignment_id"] = assignment_id
            if offending_metadata_path is not None: value["offending_metadata_path"] = offending_metadata_path
            # Never overwrite a foreign evidence object.  A deterministic
            # digest-derived sibling gives repeated restarts a stable target.
            if target.exists() or target.is_symlink() or _is_reparse_point(target):
                try:
                    existing = json.loads(target.read_text(encoding="utf-8")) if target.is_file() and not target.is_symlink() else None
                except (OSError, ValueError, UnicodeDecodeError):
                    existing = None
                if (isinstance(existing, Mapping) and existing.get("attempt_id") == attempt_id
                        and existing.get("state") == "reconciliation_required"
                        and existing.get("offending_metadata_path") == offending_metadata_path
                        and existing.get("handoff_path") == handoff_path):
                    return
                digest = hashlib.sha256((offending_metadata_path or handoff_path or error).encode("utf-8")).hexdigest()[:16]
                target = root / f"{attempt_id}.{digest}.json"
                for counter in range(100):
                    if not target.exists() and not target.is_symlink() and not _is_reparse_point(target):
                        break
                    try:
                        existing = json.loads(target.read_text(encoding="utf-8")) if target.is_file() and not target.is_symlink() else None
                    except (OSError, ValueError, UnicodeDecodeError):
                        existing = None
                    if (isinstance(existing, Mapping) and existing.get("attempt_id") == attempt_id
                            and existing.get("state") == "reconciliation_required"
                            and existing.get("offending_metadata_path") == offending_metadata_path
                            and existing.get("handoff_path") == handoff_path):
                        return
                    target = root / f"{attempt_id}.{digest}.{counter + 1}.json"
            if os.name == "posix" and hasattr(os, "O_NOFOLLOW") and hasattr(os, "O_DIRECTORY"):
                # Keep the trusted directory descriptor open across the
                # temporary write and rename; path checks alone are racy.
                directory_fd = self._open_trusted_metadata_parent(target)
                pending_name = f".{target.name}.{uuid4().hex}.pending"
                try:
                    pending_fd = os.open(pending_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory_fd)
                    try:
                        with os.fdopen(pending_fd, "w", encoding="utf-8") as handle:
                            json.dump(value, handle, separators=(",", ":")); handle.flush(); os.fsync(handle.fileno())
                    except BaseException:
                        with contextlib.suppress(OSError): os.unlink(pending_name, dir_fd=directory_fd)
                        raise
                    os.link(pending_name, target.name, src_dir_fd=directory_fd, dst_dir_fd=directory_fd)
                    os.unlink(pending_name, dir_fd=directory_fd)
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
            else:
                payload = json.dumps(value, separators=(",", ":")).encode("utf-8")
                if os.name == "nt":
                    # The native helper creates relative to the selected
                    # parent handle.  It is the only permitted Windows path;
                    # _claim_receipt is intentionally not a fallback because
                    # validate-then-open is vulnerable to a reparse swap.
                    _windows_create_json_noreplace(target.parent, target.name, payload)
                else:
                    self._claim_receipt(target, value)
        except (OSError, RuntimeServiceError, ValueError) as exc:
            # Evidence persistence is part of the startup/reconciliation
            # contract.  Do not silently continue when the trusted helper
            # could not create or durably flush the entry.
            raise RuntimeServiceError("prepared cleanup reconciliation evidence could not be persisted") from exc

    def _persist_cleanup_record(self, handoff: Path, record: Mapping[str, Any]) -> None:
        try:
            self._write_receipt(handoff, record)
        except OSError as error:
            self._prepared_cleanup_early_reconciliation(record.get("attempt_id", "unknown"), str(error))
            raise RuntimeServiceError("prepared cleanup handoff could not be persisted") from error

    def _validate_cleanup_metadata(self, record: Mapping[str, Any], attempt_id: str, receipt_path: Path, binding_path: Path, expected_pending: set[Path] | None = None) -> None:
        items = record.get("metadata")
        if not isinstance(items, list) or not items:
            raise RuntimeServiceError("prepared cleanup metadata set is invalid")
        canonical = {receipt_path.resolve(strict=False), binding_path.resolve(strict=False)}
        canonical_keys = {os.path.normcase(str(path)) for path in canonical}
        parent_keys = {os.path.normcase(str(receipt_path.parent.resolve(strict=False))), os.path.normcase(str(binding_path.parent.resolve(strict=False)))}
        seen: set[str] = set()
        pending_keys: set[str] = set()
        required_keys = {os.path.normcase(str(path)) for path in canonical}
        for item in items:
            if not isinstance(item, Mapping) or not isinstance(item.get("path"), str):
                raise RuntimeServiceError("prepared cleanup metadata set is invalid")
            path = Path(item["path"])
            resolved = path.resolve(strict=False)
            if (not path.is_absolute() or path != Path(os.path.normpath(str(path)))
                    or os.path.normcase(str(resolved.parent)) not in parent_keys):
                raise RuntimeServiceError("prepared cleanup metadata path is invalid")
            original = path
            suffix = f".{attempt_id}.unlinking"
            is_private = path.name.endswith(suffix)
            if is_private:
                # Private handoff names are exactly dot-prefixed versions of
                # the canonical basename (for example
                # .receipt.json.attempt.unlinking).  Missing the dot is
                # malformed, not an alias for the canonical name.
                original = self._prepared_canonical_metadata_path(path, attempt_id)
            pending_match = re.fullmatch(rf"\.{re.escape(attempt_id)}\.json\.[0-9a-f]+\.pending", original.name)
            # Pending atomics are themselves canonical dot-prefixed names.
            # Their private handoff therefore has two leading dots; validate
            # the represented canonical basename rather than rejecting every
            # derived name that starts with a dot.
            allowed_pending = pending_match is not None
            original_key = os.path.normcase(str(original.resolve(strict=False)))
            if original_key not in canonical_keys and not allowed_pending:
                raise RuntimeServiceError("prepared cleanup metadata path is not canonical")
            key = os.path.normcase(str(resolved))
            if key in seen:
                raise RuntimeServiceError("prepared cleanup metadata set contains duplicates")
            seen.add(key)
            if original_key in required_keys:
                required_keys.remove(original_key)
            if allowed_pending:
                # Compare pending coverage by the canonical name represented
                # by a private handoff.  A crash between rename and journal
                # update leaves the exact double-dot private name on disk.
                pending_keys.add(original_key)
            identity = item.get("identity")
            if not (identity is None or isinstance(identity, list) and len(identity) == 2 and all(type(value) is int and value >= 0 for value in identity)):
                raise RuntimeServiceError("prepared cleanup metadata identity is invalid")
            if "delete_intent" in item and type(item["delete_intent"]) is not bool:
                raise RuntimeServiceError("prepared cleanup delete intent is invalid")
            ancestors = item.get("ancestors")
            if not isinstance(ancestors, list) or not ancestors or any(not isinstance(value, list) or len(value) != 2 or any(type(part) is not int or part < 0 for part in value) for value in ancestors):
                raise RuntimeServiceError("prepared cleanup metadata ancestry is invalid")
        if required_keys:
            raise RuntimeServiceError("prepared cleanup receipt is missing")
        if expected_pending is not None and pending_keys != {os.path.normcase(str(path.resolve(strict=False))) for path in expected_pending}:
            raise RuntimeServiceError("prepared cleanup pending metadata coverage is invalid")

    def _cleanup_prepared_installation(self, attempt_id: str, *, session_id: str | None = None, receipt_path: Path | None = None, binding_path: Path | None = None, expected_root_identities: Any = None) -> dict[str, Any]:
        """Authenticated, idempotent metadata cleanup with a durable handoff journal."""
        attempt = self._prepared_attempts.get(attempt_id)
        if attempt is None or (session_id is not None and attempt.session_id != session_id):
            raise RuntimeServiceError("prepared attempt is not authorized")
        if receipt_path is None:
            receipt_path = self._preparation_receipt_path(attempt_id)
        if binding_path is None:
            binding_path = self.config.runtime_root / "prepared-attempt-bindings" / (attempt_id + ".json")
        if expected_root_identities is not None:
            try:
                if len(expected_root_identities) != 2:
                    raise ValueError
                for root, expected in zip(self._prepared_attempt_roots(attempt)[::-1], expected_root_identities):
                    current = os.stat(root, follow_symlinks=False)
                    if (int(current.st_dev), int(current.st_ino)) != tuple(expected):
                        raise RuntimeServiceError("prepared attempt root ownership changed")
            except (OSError, TypeError, ValueError) as error:
                raise RuntimeServiceError("prepared attempt root ownership changed") from error
        metadata = [receipt_path, binding_path]
        # Pending atomics are part of the authenticated metadata set.
        pending_metadata: set[Path] = set()
        for directory in (receipt_path.parent, binding_path.parent):
            if directory.is_dir() and not _unsafe_path_boundary(directory):
                discovered = sorted(directory.glob(f".{attempt_id}.json.*.pending"))
                metadata.extend(discovered)
                pending_metadata.update(discovered)
        handoff = self._prepared_cleanup_handoff_path(attempt_id)
        try:
            handoff.parent.mkdir(mode=0o700, exist_ok=True)
        except OSError as error:
            self._prepared_cleanup_early_reconciliation(attempt_id, str(error))
            raise RuntimeServiceError("prepared cleanup handoff directory is unavailable") from error
        if _unsafe_path_boundary(handoff.parent) or handoff.is_symlink():
            self._prepared_cleanup_early_reconciliation(attempt_id, "prepared cleanup handoff directory is unsafe")
            raise RuntimeServiceError("prepared cleanup handoff is unsafe")
        record = None
        if handoff.is_file() and not handoff.is_symlink():
            try:
                candidate = json.loads(handoff.read_text(encoding="utf-8"))
                valid = (isinstance(candidate, Mapping) and set(candidate) <= (_PREPARED_CLEANUP_FIELDS | _PREPARED_CLEANUP_OPTIONAL_FIELDS) and _PREPARED_CLEANUP_FIELDS <= set(candidate) and
                         all(key not in candidate or (type(candidate[key]) is bool if key == "compatibility_preparation" else isinstance(candidate[key], str)) for key in _PREPARED_CLEANUP_OPTIONAL_FIELDS) and
                         candidate.get("attempt_id") == attempt_id and candidate.get("session_id") == attempt.session_id and
                         candidate.get("workspace") == attempt.workspace and candidate.get("runtime_home") == attempt.runtime_home and
                         ("compatibility_preparation" not in candidate or candidate.get("compatibility_preparation") is True) and
                         candidate.get("phase") in {"handoff", "metadata_removed", "reconciliation_required"} and candidate.get("state") in {"active", "blocked", "completed"} and
                         isinstance(candidate.get("metadata"), list) and all(isinstance(item, Mapping) and set(item) <= {"path", "identity", "deleted", "delete_intent", "ancestors"} and {"path", "identity", "ancestors"} <= set(item) and ("deleted" not in item or type(item["deleted"]) is bool) and ("delete_intent" not in item or type(item["delete_intent"]) is bool) and isinstance(item.get("path"), str) and isinstance(item.get("ancestors"), list) and all(isinstance(v, list) and len(v) == 2 and all(type(n) is int and n >= 0 for n in v) for v in item["ancestors"]) and (item.get("identity") is None or isinstance(item.get("identity"), list) and len(item["identity"]) == 2 and all(type(v) is int and v >= 0 for v in item["identity"])) for item in candidate["metadata"]))
                if valid:
                    record = dict(candidate)
                else:
                    raise RuntimeServiceError("prepared cleanup handoff is invalid")
            except RuntimeServiceError as error:
                self._prepared_cleanup_early_reconciliation(attempt_id, str(error))
                raise
            except (OSError, ValueError):
                self._prepared_cleanup_early_reconciliation(attempt_id, "prepared cleanup handoff is invalid")
                raise RuntimeServiceError("prepared cleanup handoff is invalid")
        if record is None:
            record = {"attempt_id": attempt_id, "session_id": attempt.session_id, "workspace": attempt.workspace, "runtime_home": attempt.runtime_home,
                      **({"project_id": attempt.project_id, "assignment_id": attempt.assignment_id}
                         if attempt.assignment_id is not None else {}),
                      **({"submission_request_id": attempt.submission_request_id} if attempt.submission_request_id is not None else {"compatibility_preparation": True}),
                      "metadata": [{"path": str(path), "identity": None, "ancestors": []} for path in metadata],
                      "phase": "handoff", "state": "active", "error": "", "created_at": _utc_now()}
            try:
                for item in record["metadata"]:
                    identity = self._prepared_metadata_identity(Path(item["path"]))
                    item["identity"] = list(identity) if identity is not None else None
                    target = Path(item["path"])
                    relative = target.parent.relative_to(self.config.runtime_root)
                    cursor = self.config.runtime_root
                    ancestors = [list(map(int, (os.stat(cursor, follow_symlinks=False).st_dev, os.stat(cursor, follow_symlinks=False).st_ino)))]
                    for component in relative.parts:
                        cursor = cursor / component
                        stat_value = os.stat(cursor, follow_symlinks=False)
                        ancestors.append([int(stat_value.st_dev), int(stat_value.st_ino)])
                    item["ancestors"] = ancestors
                missing = [item for item in record["metadata"] if item["identity"] is None]
                if missing:
                    error = "prepared cleanup metadata is missing"
                    record.update(state="blocked", phase="reconciliation_required", error=error)
                    self._persist_cleanup_record(handoff, record)
                    raise RuntimeServiceError(error)
            except (RuntimeServiceError, OSError) as error:
                if record.get("phase") != "reconciliation_required":
                    record.update(state="blocked", phase="reconciliation_required", error=str(error))
                    self._persist_cleanup_record(handoff, record)
                raise RuntimeServiceError(str(error)) from error
        elif record.get("phase") == "reconciliation_required":
            # A partial initial scan is an authenticated stop point.  Do not
            # resume cleanup (and, in particular, do not remove the receipt)
            # while any member of the expected metadata set is still absent.
            # Once the complete set is present, bind any identity that could
            # not be observed during that initial scan before proceeding.
            rebound: list[tuple[dict[str, Any], list[int], list[list[int]]]] = []
            try:
                for item in record["metadata"]:
                    # A prior retry may have durably completed this entry and
                    # removed its path.  Its absence is expected; only
                    # entries still awaiting deletion must be present before
                    # any further cleanup mutation is allowed.
                    if item.get("deleted") is True:
                        # A durable marker proves only the prior operation's
                        # intent/completion.  Verify both canonical and
                        # private represented names before treating it as
                        # complete; recreated or inaccessible entries block
                        # recovery and remain untouched.
                        self._require_prepared_canonical_metadata_absent(Path(item["path"]), attempt_id)
                        continue
                    path = Path(item["path"])
                    self._require_prepared_canonical_private_coexistence_absent(path, attempt_id)
                    identity = self._prepared_metadata_identity(path)
                    if identity is None:
                        # The rename can complete before the journal records
                        # the private handoff name.  Recover only the exact
                        # private spelling for this attempt (including the
                        # double-dot spelling of a pending atomic), and bind
                        # the journal entry to that represented canonical
                        # identity before continuing.
                        suffix = f".{attempt_id}.unlinking"
                        private = path if path.name.endswith(suffix) else path.with_name(f".{path.name}.{attempt_id}.unlinking")
                        if self._prepared_canonical_metadata_path(private, attempt_id) == path:
                            private_identity = self._prepared_metadata_identity(private)
                            if private_identity is not None:
                                if item.get("identity") is not None and tuple(item["identity"]) != private_identity:
                                    raise RuntimeServiceError("prepared metadata ownership changed")
                                item["path"] = str(private)
                                if item.get("identity") is None:
                                    relative = private.parent.relative_to(self.config.runtime_root)
                                    cursor = self.config.runtime_root
                                    ancestors = [list(map(int, (os.stat(cursor, follow_symlinks=False).st_dev,
                                                                 os.stat(cursor, follow_symlinks=False).st_ino)))]
                                    for component in relative.parts:
                                        cursor = cursor / component
                                        stat_value = os.stat(cursor, follow_symlinks=False)
                                        ancestors.append([int(stat_value.st_dev), int(stat_value.st_ino)])
                                    rebound.append((item, list(private_identity), ancestors))
                                continue
                        # An absent path is success only when this journal
                        # entry durably recorded the identity-bound delete
                        # intent. Initial missing (or replacement) metadata
                        # has no such proof and remains fail-closed.
                        if (item.get("delete_intent") is True
                                and item.get("identity") is not None):
                            self._require_prepared_canonical_metadata_absent(path, attempt_id)
                            item["deleted"] = True
                            continue
                        raise RuntimeServiceError("prepared cleanup metadata is missing")
                    if item.get("identity") is None:
                        relative = path.parent.relative_to(self.config.runtime_root)
                        cursor = self.config.runtime_root
                        ancestors = [list(map(int, (os.stat(cursor, follow_symlinks=False).st_dev,
                                                     os.stat(cursor, follow_symlinks=False).st_ino)))]
                        for component in relative.parts:
                            cursor = cursor / component
                            stat_value = os.stat(cursor, follow_symlinks=False)
                            ancestors.append([int(stat_value.st_dev), int(stat_value.st_ino)])
                        rebound.append((item, list(identity), ancestors))
            except (OSError, ValueError, RuntimeServiceError) as error:
                raise RuntimeServiceError(str(error)) from error
            for item, identity, ancestors in rebound:
                item["identity"] = identity
                item["ancestors"] = ancestors
        try:
            self._validate_cleanup_metadata(record, attempt_id, receipt_path, binding_path,
                                            pending_metadata if record.get("phase") == "handoff" and record.get("created_at") else None)
        except (RuntimeServiceError, TypeError, ValueError) as error:
            self._prepared_cleanup_early_reconciliation(attempt_id, str(error))
            raise RuntimeServiceError(str(error)) from error
        try:
            self._write_receipt(handoff, record)
        except OSError as error:
            self._prepared_cleanup_early_reconciliation(attempt_id, str(error))
            raise RuntimeServiceError("prepared cleanup handoff could not be persisted") from error
        for item in record["metadata"]:
            if item.get("deleted") is True:
                # Deleted is durable evidence, not permission to stop
                # checking.  A recreated canonical or private represented
                # name must block every retry phase, including completed
                # metadata_removed journals.
                self._require_prepared_canonical_metadata_absent(Path(item["path"]), attempt_id)
                continue
            path = Path(item["path"]); expected = tuple(item["identity"]) if item["identity"] is not None else None
            try:
                if expected is None:
                    raise RuntimeServiceError("prepared cleanup metadata is missing")
                if expected is not None:
                    suffix = f".{attempt_id}.unlinking"
                    # A crash after the rename leaves this private pathname in
                    # the durable journal.  It is already the handoff name;
                    # wrapping it again would target a different file and can
                    # strand the original metadata forever.
                    private = (path if path.name.startswith(".") and path.name.endswith(suffix)
                               else path.with_name(f".{path.name}.{attempt_id}.unlinking"))
                    self._require_prepared_canonical_private_coexistence_absent(path, attempt_id)
                    if path.name.startswith(".") and path.name.endswith(suffix):
                        # A journal may already name the private handoff after
                        # a crash.  Its represented canonical name must still
                        # be absent before recovery advances this entry.
                        canonical = self._prepared_canonical_metadata_path(path, attempt_id)
                        if self._prepared_metadata_identity(canonical) is not None:
                            raise RuntimeServiceError("prepared canonical metadata was recreated")
                    if private.exists() or private.is_symlink() or _is_reparse_point(private):
                        private_identity = self._prepared_metadata_identity(private)
                        if private_identity != expected:
                            raise RuntimeServiceError("prepared metadata handoff ownership changed")
                    else:
                        current = self._prepared_metadata_identity(path)
                        if current != expected:
                            # A completed prior retry may have removed the
                            # private handoff already.  Treat that durable
                            # absence as success, never as a new ownership
                            # failure.
                            if current is None and not path.exists() and not path.is_symlink():
                                if item.get("delete_intent") is True:
                                    self._require_prepared_canonical_metadata_absent(path, attempt_id)
                                    item["deleted"] = True
                                    continue
                            raise RuntimeServiceError("prepared metadata ownership changed")
                        parent_fd = self._open_trusted_metadata_parent(path, item["ancestors"])
                        try:
                            parent_stat = os.fstat(parent_fd)
                            current_stat = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
                            if (int(current_stat.st_dev), int(current_stat.st_ino)) != expected:
                                raise RuntimeServiceError("prepared metadata ownership changed")
                            os.rename(path.name, private.name, src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
                            self._fsync_directory(path.parent)
                        finally:
                            os.close(parent_fd)
                        item["path"] = str(private)
                        self._write_receipt(handoff, record)
                    # Record intent before unlink so a crash after unlink but
                    # before the deleted marker can be recovered deterministically.
                    item["delete_intent"] = True
                    self._persist_cleanup_record(handoff, record)
                    _prepared_metadata_unlink_checkpoint(private, "after_handoff")
                    private_fd = self._open_trusted_metadata_parent(private, item["ancestors"])
                    try:
                        self._remove_prepared_metadata_file(private, expected_identity=expected, directory_fd=private_fd)
                    finally:
                        os.close(private_fd)
                    _prepared_metadata_unlink_checkpoint(private, "after_unlink")
                    item["deleted"] = True
                    self._persist_cleanup_record(handoff, record)
            except (RuntimeServiceError, OSError) as error:
                record.update(state="blocked", phase="reconciliation_required", error=str(error))
                # A fault in the recovery journal must not hide the original
                # authenticated mutation error (especially injected errors).
                try:
                    self._persist_cleanup_record(handoff, record)
                except (RuntimeServiceError, OSError):
                    pass
                raise
        record.update(phase="metadata_removed", state="completed"); self._write_receipt(handoff, record)
        return record

    def _attempt_paths(self, item: SessionConfiguration, session_id: str, request_id: str, project_id: str, revision_id: str, attempt_id: str | None) -> tuple[Path, Path, dict[str, str] | None]:
        if item.execution_profile == LEGACY_HERMES_PROFILE.profile_id:
            _, home, workspace = self._session(session_id)
            return home, workspace, None
        if not isinstance(attempt_id, str):
            raise RuntimeServiceError("non-legacy execution requires a prepared attempt")
        attempt = self._prepared_attempts.get(attempt_id)
        if (attempt is None or attempt.session_id != session_id or attempt.project_id != project_id or attempt.revision_id != revision_id
                or attempt_id != attempt.attempt_id
                or (attempt.submission_request_id is not None and request_id != attempt.submission_request_id)):
            raise RuntimeServiceError("prepared attempt is not authorized for this turn")
        if attempt.submission_request_id is None:
            self._require_compatibility_preparation_receipt(attempt)
        home, workspace = self._prepared_attempt_roots(attempt)
        try:
            head = subprocess.run(["git", "-C", str(workspace), "rev-parse", "HEAD"], check=True, capture_output=True, text=True, timeout=10).stdout.strip()
        except (OSError, subprocess.SubprocessError) as error:
            raise RuntimeServiceError("prepared workspace is not a verified Git checkout") from error
        if head != attempt.immutable_revision:
            raise RuntimeServiceError("prepared workspace revision is not immutable")
        return home, workspace, {"attempt_id": attempt.attempt_id, "immutable_revision": attempt.immutable_revision}

    @staticmethod
    def _preparation_attempt_id(session_id: str, project_id: str, revision_id: str, assignment_id: str, immutable_revision: str) -> str:
        identity = json.dumps({"session_id": session_id, "project_id": project_id, "revision_id": revision_id, "assignment_id": assignment_id, "immutable_revision": immutable_revision}, sort_keys=True, separators=(",", ":"))
        return "attempt-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:48]

    def _preparation_receipt_path(self, attempt_id: str) -> Path:
        if not isinstance(attempt_id, str) or not _SAFE_IDENTIFIER.fullmatch(attempt_id):
            raise RuntimeServiceError("prepared attempt identity is invalid")
        return self.config.runtime_root / "prepared-attempts" / (attempt_id + ".json")

    def prepare_assignment_attempt(self, session_id: str, project_id: str, revision_id: str, immutable_revision: str, assignment_id: str, submission_fence: Mapping[str, Any], submission_request_id: str | None = None) -> dict[str, Any]:
        """Materialize one assignment's immutable worktree and private home."""
        if (not all(isinstance(value, str) and _SAFE_IDENTIFIER.fullmatch(value) for value in (session_id, project_id, revision_id, assignment_id))
                or (submission_request_id is not None and (not isinstance(submission_request_id, str) or not _SAFE_IDENTIFIER.fullmatch(submission_request_id)))
                or not isinstance(immutable_revision, str) or re.fullmatch(r"[0-9a-f]{40,64}", immutable_revision) is None):
            raise RuntimeServiceError("prepared attempt request is invalid")
        try: normalized_fence = validate_submission_fence(submission_fence)
        except RuntimeClientError as error: raise RuntimeServiceError("prepared submission fence is invalid") from error
        if normalized_fence["assignment_id"] != assignment_id or normalized_fence["immutable_revision"] != immutable_revision or normalized_fence["project_revision"] != int(revision_id):
            raise RuntimeServiceError("prepared submission fence does not match request")
        item = self._session_item(session_id)
        if project_id not in item.project_ids or item.execution_profile == LEGACY_HERMES_PROFILE.profile_id:
            raise RuntimeServiceError("prepared attempt is not authorized for this session")
        attempt_id = self._preparation_attempt_id(session_id, project_id, revision_id, assignment_id, immutable_revision)
        workspace_relative = str(Path("attempts") / attempt_id / "workspace")
        home_relative = str(Path("attempts") / attempt_id / "home")
        receipt_id = "preparation-" + hashlib.sha256((attempt_id + immutable_revision).encode("utf-8")).hexdigest()[:48]
        expected = {"attempt_id": attempt_id, "assignment_id": assignment_id, "project_id": project_id, "revision_id": revision_id, "immutable_revision": immutable_revision, "workspace": workspace_relative, "runtime_home": home_relative, "receipt_id": receipt_id, "state": "prepared", "submission_fence": normalized_fence}
        if submission_request_id is not None:
            expected["submission_request_id"] = submission_request_id
        receipt_path = self._preparation_receipt_path(attempt_id)
        with self._preparation_lock:
            if receipt_path.exists():
                if receipt_path.is_symlink() or not receipt_path.is_file():
                    raise RuntimeServiceError("prepared attempt receipt is unsafe")
                try:
                    persisted = json.loads(receipt_path.read_text(encoding="utf-8"))
                except (OSError, ValueError) as error:
                    raise RuntimeServiceError("prepared attempt receipt is invalid") from error
                persisted_expected = {**expected, **({"compatibility_preparation": True} if submission_request_id is None else {})}
                persisted_mac_valid = (submission_request_id is not None or
                    isinstance(persisted, Mapping) and isinstance(persisted.get("compatibility_receipt_mac"), str)
                    and hmac.compare_digest(persisted["compatibility_receipt_mac"], self._compatibility_receipt_mac(persisted)))
                try:
                    persisted_fence = validate_submission_fence(persisted.get("submission_fence"), check_expiry=False)
                except RuntimeClientError as error:
                    raise RuntimeServiceError("prepared attempt conflicts with a durable receipt") from error
                same_request = persisted.get("submission_request_id") == submission_request_id
                same_identity = (isinstance(persisted, Mapping)
                                 and not set(persisted) - (set(persisted_expected) | {"session_id", "created_at", "compatibility_receipt_mac"})
                                 and all(persisted.get(key) == value for key, value in persisted_expected.items()
                                         if key not in {"submission_fence", "submission_request_id"})
                                 and _same_submission_fence(persisted_fence, normalized_fence))
                if (not same_identity or not same_request or not persisted_mac_valid):
                    raise RuntimeServiceError("prepared attempt conflicts with a durable receipt")
                if persisted_fence != normalized_fence:
                    persisted = {**persisted, "submission_fence": normalized_fence}
                    if submission_request_id is None:
                        persisted["compatibility_receipt_mac"] = self._compatibility_receipt_mac(persisted)
                    self._write_receipt(receipt_path, persisted)
                self._prepared_attempts[attempt_id] = PreparedAssignmentAttempt(attempt_id, session_id, project_id, revision_id, immutable_revision, workspace_relative, home_relative, assignment_id, normalized_fence, submission_request_id)
                self._prepared_assignment_ids[attempt_id] = assignment_id
                self._prepared_attempt_roots(self._prepared_attempts[attempt_id])
                return expected
            source = self.config.workspace_root / item.workspace
            if source.is_symlink() or not source.is_dir() or self.config.workspace_root.resolve() not in source.resolve().parents:
                raise RuntimeServiceError("managed source checkout is unavailable")
            workspace = self.config.workspace_root / workspace_relative
            home = self.config.runtime_root / home_relative
            reservations: list[list[Any]] = []
            workspace_parent_identity: tuple[int, int] | None = None
            workspace_identity: tuple[int, int] | None = None
            home_identity: tuple[int, int] | None = None
            try:
                # The deterministic parents are the ownership proof.  No
                # marker committed by the source tree, and no copied .git
                # metadata below a child, can manufacture this reservation.
                workspace_parent, workspace_parent_identity = self._reserve_prepared_attempt_parent(
                    self.config.workspace_root, attempt_id, "workspace")
                reservations.append([workspace_parent, workspace_parent_identity, workspace, None, "workspace"])
                home_parent, home_parent_identity = self._reserve_prepared_attempt_parent(
                    self.config.runtime_root, attempt_id, "runtime home")
                reservations.append([home_parent, home_parent_identity, home, None, "runtime home"])
                try:
                    home.mkdir(mode=0o700)
                except FileExistsError as error:
                    # A pre-existing sentinel is foreign; do not bind it by
                    # pathname or by a source-controlled marker name.
                    raise RuntimeServiceError("prepared runtime home already exists") from error
                home_identity = self._prepared_child_identity(home)
                if home_identity is None:
                    raise RuntimeServiceError("prepared runtime home reservation disappeared")
                reservations[1][3] = home_identity

                # Git owns creation of the workspace child.  Record whether a
                # real child appeared even when the command reports failure.
                if self._prepared_child_identity(workspace) is not None:
                    raise RuntimeServiceError("prepared workspace already exists")
                try:
                    subprocess.run(
                        ["git", "-C", str(source), "rev-parse", "--verify", immutable_revision + "^{commit}"],
                        check=True, capture_output=True, text=True, timeout=10,
                    )
                    result = subprocess.run(
                        ["git", "-C", str(source), "worktree", "add", "--detach", str(workspace), immutable_revision],
                        check=True, capture_output=True, text=True, timeout=30,
                    )
                    workspace_identity = self._prepared_child_identity(workspace)
                    if result.returncode != 0:
                        raise subprocess.CalledProcessError(result.returncode, result.args)
                except (OSError, subprocess.SubprocessError):
                    if _prepared_directory_identity(workspace.parent) == workspace_parent_identity:
                        workspace_identity = self._prepared_child_identity(workspace)
                    reservations[0][3] = workspace_identity
                    raise
                reservations[0][3] = workspace_identity
                if workspace_identity is None:
                    raise RuntimeServiceError("Git worktree was not materialized")
                if _prepared_directory_identity(workspace.parent) != workspace_parent_identity:
                    raise RuntimeServiceError("prepared workspace reservation changed")
                try:
                    head = subprocess.run(["git", "-C", str(workspace), "rev-parse", "HEAD"], check=True, capture_output=True, text=True, timeout=10).stdout.strip()
                finally:
                    # A replacement between Git materialization and
                    # verification is never authorized by the old pathname.
                    if _prepared_directory_identity(workspace.parent) != workspace_parent_identity:
                        raise RuntimeServiceError("prepared workspace reservation changed")
                    if self._prepared_child_identity(workspace) != workspace_identity:
                        raise RuntimeServiceError("prepared workspace ownership changed")
                if head != immutable_revision:
                    raise RuntimeServiceError("prepared workspace revision is not immutable")
            except (OSError, subprocess.SubprocessError, RuntimeServiceError) as error:
                try:
                    self._cleanup_failed_prepared_attempt(
                        source, workspace, home,
                        tuple((item[0], item[1], item[2], item[3], item[4]) for item in reservations),
                    )
                except RuntimeServiceError as cleanup_error:
                    raise cleanup_error from error
                if isinstance(error, RuntimeServiceError):
                    raise
                raise RuntimeServiceError("managed source checkout could not prepare the declared revision") from error
            attempt = PreparedAssignmentAttempt(attempt_id, session_id, project_id, revision_id, immutable_revision, workspace_relative, home_relative, assignment_id, normalized_fence, submission_request_id)
            self._prepared_attempt_roots(attempt)
            persisted = {**expected, **({"compatibility_preparation": True} if submission_request_id is None else {}), "session_id": session_id, "created_at": _utc_now()}
            if submission_request_id is None:
                persisted["compatibility_receipt_mac"] = self._compatibility_receipt_mac(persisted)
            self._write_receipt(receipt_path, persisted)
            self._prepared_attempts[attempt_id] = attempt
            self._prepared_assignment_ids[attempt_id] = assignment_id
            return expected

    @staticmethod
    def binding_fingerprint(session_id: str, binding_id: str, expected_revision: int) -> str:
        return hashlib.sha256(json.dumps({"binding_id": binding_id, "expected_revision": expected_revision, "session_id": session_id}, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()

    def update_binding(self, session_id: str, binding_id: str, operation_id: str, fingerprint: str, expected_revision: int, *, caller_projects: frozenset[str]) -> dict[str, Any]:
        """Checkpoint then atomically make the registry's approved binding current.

        There is deliberately no runtime binding cache: every later turn resolves
        its model from the registry.  A prepared operation is restart-reconcilable.
        """
        if self.registry is None or session_id in self.config.sessions or not isinstance(binding_id, str) or binding_id not in self.config.approved_bindings or type(expected_revision) is not int or expected_revision < 1 or not isinstance(operation_id, str) or not _SAFE_IDENTIFIER.fullmatch(operation_id) or not hmac.compare_digest(fingerprint, self.binding_fingerprint(session_id, binding_id, expected_revision)):
            raise RuntimeServiceError("binding update is invalid")
        item, home, _ = self._session(session_id)
        lock = self._locks[session_id]
        if not lock.acquire(False): raise RuntimeServiceError("binding update requires idle session")
        try:
            if self.status(session_id)["state"] not in {"idle", "paused"}: raise RuntimeServiceError("binding update requires safe boundary")
            target = self.config.approved_bindings[binding_id]
            if target.get("capabilities", []) != item.binding.get("capabilities", []): raise RuntimeServiceError("binding compatibility is invalid")
            try:
                operation = self.registry.begin_binding_operation(session_id, binding_id, operation_id, fingerprint, actor_role="controller", caller_projects=caller_projects, expected_revision=expected_revision)
            except RuntimeSessionRegistryError as error: raise RuntimeServiceError(str(error)) from error
            if operation["state"] == "applied":
                return {"state":"updated", "session_id":session_id, "binding_id":operation["new_binding_id"] if "new_binding_id" in operation else binding_id, "revision":operation["generation"], "operation_id":operation_id, "checkpoint_id":operation["checkpoint_id"], "reconciled":True}
            checkpoint = self.checkpoint(session_id)
            try:
                applied = self.registry.apply_binding_operation(session_id, operation_id, fingerprint, checkpoint["checkpoint_id"], actor_role="controller", caller_projects=caller_projects)
            except RuntimeSessionRegistryError as error: raise RuntimeServiceError(str(error)) from error
            receipt={"state":"updated","session_id":session_id,"binding_id":applied["binding_id"],"revision":applied["revision"],"operation_id":operation_id,"checkpoint_id":applied["checkpoint_id"],"reconciled":False}
            self._write_receipt(home / "binding-operations" / (operation_id + ".json"), receipt)
            return receipt
        finally: lock.release()

    def status(self, session_id: str) -> dict[str, Any]:
        _, home, _ = self._session(session_id)
        state = self._states[session_id]
        desired = None
        if self.registry is not None and session_id not in self.config.sessions:
            try:
                desired = self.registry.get(session_id, actor_role="controller", caller_projects=frozenset(self.registry.allowed_workspaces))["desired_status"]
            except RuntimeSessionRegistryError as error:
                raise RuntimeServiceError("unknown session") from error
        owner = home / ".service-owner.lock"
        if desired in {"paused", "retired"}: current = desired
        elif owner.exists(): current = "draining" if self._paused_path(home).exists() else "running" if state["state"] == "running" else "busy_or_unreconciled"
        elif self._paused_path(home).exists(): current = "paused"
        elif self._unresolved(home) or (home / ".turn.lock").exists(): current = "needs_reconciliation"
        else: current = "idle"
        return {"session_id": session_id, **state, "state": current}

    def _receipt_path(self, home: Path, request_id: str) -> Path:
        if not isinstance(request_id, str) or not request_id or len(request_id) > 128 or "/" in request_id or "\\" in request_id:
            raise RuntimeServiceError("request_id is unsafe")
        return home / "operations" / f"{request_id}.json"

    def operation(self, session_id: str, request_id: str) -> dict[str, Any]:
        item = self._session_item(session_id)
        if item.execution_profile == LEGACY_HERMES_PROFILE.profile_id:
            _, home, _ = self._session(session_id)
            path = self._receipt_path(home, request_id)
        else:
            # Validate every prepared root for this session before even testing
            # a receipt path. A swapped home must not redirect lookup to an
            # external forged operations directory.
            homes = [self._prepared_attempt_roots(attempt)[0]
                     for attempt in self._prepared_attempts.values()
                     if attempt.session_id == session_id]
            paths = [self._receipt_path(home, request_id) for home in homes
                     if self._receipt_path(home, request_id).exists()]
            if len(paths) != 1:
                raise RuntimeServiceError("operation not found")
            path = paths[0]
        value = self._read_operation(path)
        if not isinstance(value, dict): raise RuntimeServiceError("operation is malformed")
        required = {"request_id", "session_id", "project_id", "revision_id", "message_sha256", "source_identity", "state", "created_at"}
        allowed = required | {"frontier_fence", "finished_at", "diagnostic", "result", "effect_receipts", "effect_receipt"}
        if (set(value) - allowed or not required <= set(value)
                or value.get("request_id") != request_id or value.get("session_id") != session_id
                or value.get("state") not in {"accepted", "running", "completed", "unknown"}
                or not isinstance(value.get("project_id"), str) or not isinstance(value.get("revision_id"), str)
                or not isinstance(value.get("message_sha256"), str) or not isinstance(value.get("created_at"), str)
                or ("frontier_fence" in value and not isinstance(value["frontier_fence"], Mapping))):
            raise RuntimeServiceError("operation is malformed")
        if "frontier_fence" in value:
            try:
                validate_submission_fence(value["frontier_fence"], check_expiry=False)
            except (RuntimeClientError, TypeError, ValueError) as error:
                raise RuntimeServiceError("operation is malformed") from error
        return value

    @staticmethod
    def _read_operation(path: Path) -> Any:
        parent = path.parent
        def reparse(candidate: Path) -> bool:
            try: return bool(getattr(os.lstat(candidate), "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
            except OSError: return True
        if parent.is_symlink() or not parent.is_dir() or path.is_symlink() or reparse(parent) or reparse(path):
            raise RuntimeServiceError("operation not found")
        try:
            if os.name == "posix" and hasattr(os, "O_NOFOLLOW") and hasattr(os, "O_DIRECTORY"):
                directory = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                try:
                    descriptor = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory)
                    try:
                        if not stat.S_ISREG(os.fstat(descriptor).st_mode): raise RuntimeServiceError("operation not found")
                        raw = os.read(descriptor, MAX_BODY + 1)
                    finally: os.close(descriptor)
                finally: os.close(directory)
            else:
                # This runtime lacks a portable Windows open-with-no-reparse
                # API. Reject reparse paths and require the resolved parent to
                # remain stable before and after the bounded read.
                if path.resolve(strict=True).parent != parent.resolve(strict=True): raise RuntimeServiceError("operation not found")
                raw = path.read_bytes()
                if len(raw) > MAX_BODY or path.is_symlink() or reparse(path) or reparse(parent) or path.resolve(strict=True).parent != parent.resolve(strict=True): raise RuntimeServiceError("operation not found")
            if len(raw) > MAX_BODY: raise RuntimeServiceError("operation is malformed")
            return json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeDecodeError, ValueError) as error:
            if isinstance(error, RuntimeServiceError): raise
            raise RuntimeServiceError("operation is malformed") from error

    def _write_receipt(self, path: Path, value: Mapping[str, Any]) -> None:
        path.parent.mkdir(mode=0o700, exist_ok=True)
        if path.parent.is_symlink() or path.is_symlink(): raise RuntimeServiceError("receipt path is unsafe")
        pending = path.with_name(f".{path.name}.{uuid4().hex}.pending")
        if pending.is_symlink(): raise RuntimeServiceError("receipt path is unsafe")
        with pending.open("x", encoding="utf-8") as handle:
            json.dump(value, handle, separators=(",", ":")); handle.flush(); os.fsync(handle.fileno())
        os.replace(pending, path)
        self._fsync_directory(path.parent)

    @staticmethod
    def _fsync_directory(directory: Path) -> None:
        try:
            directory_fd = os.open(directory, os.O_RDONLY)
            try: os.fsync(directory_fd)
            finally: os.close(directory_fd)
        except PermissionError:
            if os.name != "nt": raise

    def _claim_receipt(self, path: Path, value: Mapping[str, Any]) -> bool:
        path.parent.mkdir(mode=0o700, exist_ok=True)
        if _unsafe_path_boundary(path) or path.parent.resolve(strict=True) != self.config.runtime_root.resolve(strict=True) and self.config.runtime_root.resolve(strict=True) not in path.parent.resolve(strict=True).parents:
            raise RuntimeServiceError("receipt path is unsafe")
        try:
            # O_EXCL is the only portable create-without-overwrite primitive
            # available here; unlike Path.open('x'), it lets us keep the
            # exclusive creation operation explicit for Windows callers.
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump(value, handle, separators=(",", ":")); handle.flush(); os.fsync(handle.fileno())
            except BaseException:
                with contextlib.suppress(OSError): path.unlink()
                raise
            self._fsync_directory(path.parent)
            return True
        except FileExistsError:
            return False

    def _paused_path(self, home: Path) -> Path:
        return home / ".paused"

    def _write_pause_marker(self, home: Path) -> None:
        path = self._paused_path(home)
        if path.is_symlink(): raise RuntimeServiceError("pause metadata is unsafe")
        fd = os.open(path, os.O_WRONLY | os.O_CREAT, 0o600)
        try: os.fsync(fd)
        finally: os.close(fd)
        self._fsync_directory(home)

    def _unresolved(self, home: Path, *, ignore_path: Path | None = None) -> bool:
        directory = home / "operations"
        if not directory.exists(): return False
        if directory.is_symlink(): return True
        for path in directory.glob("*.json"):
            if ignore_path is not None and path == ignore_path:
                continue
            try:
                if path.is_symlink() or not isinstance((value := json.loads(path.read_text(encoding="utf-8"))), Mapping) or value.get("state") in {"accepted", "running", "unknown"}: return True
            except (OSError, ValueError): return True
        return False

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError as error:
            raise RuntimeServiceError("runtime owner liveness is ambiguous") from error
        return True

    @classmethod
    def _reconcile_owner_lock(cls, path: Path) -> bool:
        try:
            if path.is_symlink() or not path.is_file():
                raise RuntimeServiceError("runtime owner marker is unsafe")
            raw = path.read_bytes()
        except RuntimeServiceError:
            raise
        except OSError as error:
            raise RuntimeServiceError("runtime owner marker is unreadable") from error
        if not raw or not re.fullmatch(rb"[1-9][0-9]{0,9}", raw):
            raise RuntimeServiceError("runtime owner PID marker is malformed")
        if cls._pid_alive(int(raw)):
            raise RuntimeServiceError("session has another runtime owner")
        try:
            path.unlink()
            cls._fsync_directory(path.parent)
        except OSError as error:
            raise RuntimeServiceError("runtime owner stale marker could not be reconciled") from error
        return True

    @classmethod
    def _reconcile_runner_lock(cls, path: Path) -> None:
        try:
            if path.is_symlink() or not path.is_file():
                raise RuntimeServiceError("runner lock marker is unsafe")
            raw = path.read_bytes()
        except RuntimeServiceError:
            raise
        except OSError as error:
            raise RuntimeServiceError("runner lock marker is unreadable") from error
        if not raw or not re.fullmatch(rb"[1-9][0-9]{0,9}", raw):
            raise RuntimeServiceError("runner lock PID marker is malformed")
        if cls._pid_alive(int(raw)):
            raise RuntimeServiceError("session runner is still active")
        try:
            path.unlink()
            cls._fsync_directory(path.parent)
        except OSError as error:
            raise RuntimeServiceError("runner lock stale marker could not be reconciled") from error

    class _HomeOwner:
        def __init__(self, service: "HermesRuntimeService", home: Path) -> None:
            self.service, self.home, self.path = service, home, home / ".service-owner.lock"
            self.fd: int | None = None
            self.reconciled = False

        def __enter__(self) -> "HermesRuntimeService._HomeOwner":
            try:
                self.fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError as error:
                self.reconciled = self.service._reconcile_owner_lock(self.path)
                try:
                    self.fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                except FileExistsError as retry_error:
                    raise RuntimeServiceError("session has another runtime owner") from retry_error
                except OSError as retry_error:
                    raise RuntimeServiceError("runtime owner marker could not be acquired") from retry_error
            except OSError as error:
                raise RuntimeServiceError("runtime owner marker could not be acquired") from error
            payload = str(os.getpid()).encode("ascii")
            try:
                if os.write(self.fd, payload) != len(payload):
                    raise OSError("short runtime owner marker write")
                os.fsync(self.fd)
            except OSError as error:
                os.close(self.fd); self.fd = None
                try: self.path.unlink()
                except OSError: pass
                raise RuntimeServiceError("runtime owner marker could not be written") from error
            return self

        def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
            if self.fd is None:
                return
            os.close(self.fd); self.fd = None
            try:
                if self.path.read_bytes() != str(os.getpid()).encode("ascii"):
                    raise RuntimeServiceError("runtime owner marker ownership changed")
                self.path.unlink()
                self.service._fsync_directory(self.path.parent)
            except RuntimeServiceError:
                raise
            except OSError as error:
                raise RuntimeServiceError("runtime owner marker cleanup failed") from error

    def _home_owner(self, home: Path) -> "HermesRuntimeService._HomeOwner":
        return self._HomeOwner(self, home)

    def pause(self, session_id: str) -> dict[str, Any]:
        _, home, _ = self._session(session_id)
        self._write_pause_marker(home)
        lock, state = self._locks[session_id], self._states[session_id]
        if not lock.acquire(blocking=False):
            state["state"] = "pausing"
            return {"session_id": session_id, "state": "draining"}
        try:
            if (home / ".service-owner.lock").exists():
                return {"session_id": session_id, "state": "draining"}
            state["state"] = "paused"
            return {"session_id": session_id, "state": "paused"}
        finally:
            lock.release()

    @staticmethod
    def _recover_durable_effects(workspace: Path, home: Path, source_identity: Mapping[str, str] | None, baseline: set[tuple[str, str, str | None]] | None = None) -> list[dict[str, Any]] | None:
        if source_identity is None: return None
        try:
            raw = HermesWorkspaceTools(workspace, home).effect_receipts()
            effects = [{**effect, "attempt_id": source_identity["attempt_id"]} for effect in raw]
            if len(effects) > 32 or any(validate_public_effect_receipt(effect, source_identity["attempt_id"]) is None for effect in effects): return None
            if baseline is not None:
                effects = [effect for effect in effects if (effect["tool_id"], effect["state"], effect.get("result_sha256")) not in baseline]
            return effects
        except (HermesWorkspaceToolError, OSError, ValueError): return None

    def _persist_prepared_fence(self, attempt: PreparedAssignmentAttempt, fence: Mapping[str, Any]) -> PreparedAssignmentAttempt:
        """Record a validated lease renewal before admitting its turn."""
        updated = replace(attempt, submission_fence=fence)
        path = self._preparation_receipt_path(attempt.attempt_id)
        if path.exists():
            try:
                persisted = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError) as error:
                raise RuntimeServiceError("prepared attempt receipt is invalid") from error
            if (not isinstance(persisted, Mapping)
                    or set(persisted) - {"attempt_id", "assignment_id", "project_id", "revision_id", "immutable_revision", "workspace", "runtime_home", "receipt_id", "state", "session_id", "created_at", "submission_fence", "submission_request_id", "compatibility_preparation", "compatibility_receipt_mac"}
                    or persisted.get("state") != "prepared"
                    or any(persisted.get(key) != getattr(attempt, key) for key in ("attempt_id", "assignment_id", "project_id", "revision_id", "immutable_revision", "workspace", "runtime_home"))):
                raise RuntimeServiceError("prepared attempt receipt conflicts with the assignment")
            if (persisted.get("submission_request_id") != attempt.submission_request_id
                    or not _same_submission_fence(persisted.get("submission_fence"), fence)):
                # The stored fence may be the previous lease, but its
                # non-lease identity must be authenticated before replacement.
                if (not isinstance(persisted, Mapping)
                        or persisted.get("submission_request_id") != attempt.submission_request_id
                        or not _same_submission_fence(persisted.get("submission_fence"), attempt.submission_fence)):
                    raise RuntimeServiceError("prepared attempt receipt conflicts with the assignment")
            if persisted.get("compatibility_preparation") is True and (
                    not isinstance(persisted.get("compatibility_receipt_mac"), str)
                    or not hmac.compare_digest(persisted["compatibility_receipt_mac"], self._compatibility_receipt_mac(persisted))):
                raise RuntimeServiceError("prepared attempt receipt is unauthenticated")
            value = {**persisted, "submission_fence": dict(fence)}
            if value.get("compatibility_preparation") is True:
                value["compatibility_receipt_mac"] = self._compatibility_receipt_mac(value)
            self._write_receipt(path, value)
        self._prepared_attempts[attempt.attempt_id] = updated
        return updated

    def _validate_turn_fence(self, message: str, fence: Mapping[str, Any], *, project_id: str, revision_id: str, attempt: PreparedAssignmentAttempt) -> dict[str, Any]:
        try: normalized = validate_submission_fence(fence)
        except RuntimeClientError as error:
            if str(error) == "runtime submission fence lease is expired":
                raise _TurnFenceExpired(str(error)) from error
            raise RuntimeServiceError(str(error)) from error
        try: project_revision = int(revision_id)
        except (TypeError, ValueError) as error: raise RuntimeServiceError("runtime project revision is invalid") from error
        try: envelope = json.loads(message)
        except (TypeError, ValueError) as error: raise RuntimeServiceError("runtime submission fence envelope is malformed") from error
        if (not isinstance(envelope, Mapping) or envelope.get("frontier_fence") != normalized
                or envelope.get("assignment_id") != normalized["assignment_id"] or envelope.get("attempt_id") != attempt.attempt_id
                or envelope.get("project_id") != project_id or envelope.get("revision") != project_revision
                or envelope.get("immutable_revision") != attempt.immutable_revision
                or attempt.assignment_id != normalized["assignment_id"] or normalized["project_revision"] != project_revision
                or (attempt.submission_fence is not None and not _same_submission_fence(attempt.submission_fence, normalized))):
            raise RuntimeServiceError("runtime submission fence does not match the assignment")
        return normalized

    def _admit_authoritative_frontier(self, fence: Mapping[str, Any]) -> None:
        """Apply the configured current-frontier decision at final admission.

        The callback is an authority boundary, not a caller-provided hint.  A
        malformed or unavailable decision fails closed and a rejected decision
        preserves the exact bounded reason for Management reconciliation.
        """
        if self._frontier_authority is None:
            return
        try:
            decision = self._frontier_authority(_copy_json(fence))
        except Exception as error:
            raise RuntimeServiceError("runtime frontier authority unavailable") from error
        if not isinstance(decision, Mapping) or set(decision) - {"eligible", "reason"} or type(decision.get("eligible")) is not bool:
            raise RuntimeServiceError("runtime frontier authority returned an invalid decision")
        if decision["eligible"]:
            if set(decision) != {"eligible"}:
                raise RuntimeServiceError("runtime frontier authority returned an invalid decision")
            return
        reason = decision.get("reason")
        if not isinstance(reason, str) or not re.fullmatch(r"[a-z][a-z0-9_.-]{0,63}", reason):
            raise RuntimeServiceError("runtime frontier authority returned an invalid decision")
        raise _RuntimeAdmissionBlocked(reason)

    def turn(self, session_id: str, request_id: str, project_id: str, revision_id: str, message: str, *, attempt_id: str | None = None, submission_fence: Mapping[str, Any] | None = None) -> dict[str, Any]:
        item = self._session_item(session_id)
        if not all(isinstance(value, str) and value and len(value) <= 128 for value in (request_id, project_id, revision_id)) or not isinstance(message, str) or len(message.encode("utf-8")) > MAX_BODY:
            raise RuntimeServiceError("message must be a bounded string")
        if project_id not in item.project_ids:
            raise RuntimeServiceError("session is not configured for this project")
        profile = self._execution_profile(item)
        if profile.profile_id == LEGACY_HERMES_PROFILE.profile_id and attempt_id is not None:
            raise RuntimeServiceError("legacy turns cannot claim a prepared attempt")
        if attempt_id is None and submission_fence is not None:
            raise RuntimeServiceError("legacy turns cannot carry a submission fence")
        if profile.profile_id != LEGACY_HERMES_PROFILE.profile_id and (not isinstance(self.runner, SandboxRunner) or self.runner.backend is None):
            raise RuntimeServiceError("non-legacy execution requires an enforcing sandbox runner")
        home, workspace, source_identity = self._attempt_paths(item, session_id, request_id, project_id, revision_id, attempt_id)
        receipt_path = self._receipt_path(home, request_id)
        fingerprint = hashlib.sha256(message.encode()).hexdigest()
        prepared_attempt = self._prepared_attempts.get(attempt_id) if attempt_id is not None else None
        parsed_fence = None
        if attempt_id is not None:
            if submission_fence is None:
                raise RuntimeServiceError("runtime submission fence is required")
            if prepared_attempt is None:
                raise RuntimeServiceError("prepared attempt is not authorized for this turn")
            # This is deliberately a pure probe.  Lease renewal is a durable
            # state transition and is admitted only after all blockers/locks.
            try:
                parsed_fence = self._validate_turn_fence(message, submission_fence, project_id=project_id, revision_id=revision_id, attempt=prepared_attempt)
            except _TurnFenceExpired as error:
                raise _RuntimeAdmissionBlocked("lease_expired") from error
        # Desired state controls new admission; replay is checked under the
        # owner lock so the persisted fence is authoritative.
        if parsed_fence is None and receipt_path.exists():
            receipt = self.operation(session_id, request_id)
            if receipt.get("project_id") != project_id or receipt.get("revision_id") != revision_id or receipt.get("message_sha256") != fingerprint or receipt.get("source_identity") != source_identity or not _exact_submission_fence(receipt.get("frontier_fence"), parsed_fence):
                raise RuntimeServiceError("request_id reuse conflicts")
            if receipt.get("state") == "completed":
                return receipt
        if self.registry is not None and session_id not in self.config.sessions:
            try:
                desired = self.registry.get(session_id, actor_role="controller", caller_projects=frozenset(self.registry.allowed_workspaces))["desired_status"]
            except RuntimeSessionRegistryError as error: raise RuntimeServiceError("unknown session") from error
            if desired != "active": raise RuntimeServiceError("registered session is not desired active")
        lock, state = self._locks[session_id], self._states[session_id]
        if not lock.acquire(blocking=False):
            raise RuntimeServiceError("session is already running")
        try:
            with self._home_owner(home) as owner:
                runner_lock = home / ".turn.lock"
                if owner.reconciled and runner_lock.exists():
                    self._reconcile_runner_lock(runner_lock)
                if self._paused_path(home).exists() or (self._unresolved(home, ignore_path=receipt_path if owner.reconciled else None)) or runner_lock.exists():
                    raise RuntimeServiceError("session admission is paused or requires reconciliation")
                # A stale owner marker only authorizes recovery of the request
                # whose receipt is being retried.  An unrelated request must
                # remain fail-closed while any prior outcome is unresolved.
                # Authenticate the durable preparation before inspecting any
                # operation receipt, replay cache, or runner admission.
                if parsed_fence is not None:
                    try:
                        durable = self._read_authoritative_preparation_receipt(prepared_attempt)
                        prepared_attempt = replace(prepared_attempt, submission_fence=durable["submission_fence"])
                        parsed_fence = self._validate_turn_fence(message, submission_fence, project_id=project_id, revision_id=revision_id, attempt=prepared_attempt)
                    except _TurnFenceExpired as error:
                        raise _RuntimeAdmissionBlocked("lease_expired") from error
                recovery_receipt = None
                if owner.reconciled and receipt_path.exists():
                    recovery_receipt = self.operation(session_id, request_id)
                    if (recovery_receipt.get("request_id") != request_id
                            or recovery_receipt.get("session_id") != session_id
                            or recovery_receipt.get("project_id") != project_id
                            or recovery_receipt.get("revision_id") != revision_id
                            or recovery_receipt.get("message_sha256") != fingerprint
                            or recovery_receipt.get("source_identity") != source_identity
                            or not _exact_submission_fence(recovery_receipt.get("frontier_fence"), parsed_fence)
                            or recovery_receipt.get("state") not in {"accepted", "running", "unknown"}):
                        raise RuntimeServiceError("request_id reuse conflicts")
                recovered_receipt = None
                if receipt_path.exists():
                    receipt = self.operation(session_id, request_id)
                    if (receipt.get("project_id") != project_id or receipt.get("revision_id") != revision_id or receipt.get("message_sha256") != fingerprint or receipt.get("source_identity") != source_identity or not _exact_submission_fence(receipt.get("frontier_fence"), parsed_fence)): raise RuntimeServiceError("request_id reuse conflicts")
                    if receipt.get("state") == "completed" or not owner.reconciled:
                        return receipt
                    recovered_receipt = receipt
                if parsed_fence is not None:
                    if prepared_attempt.submission_fence != parsed_fence:
                        prepared_attempt = self._persist_prepared_fence(prepared_attempt, parsed_fence)
                    # This is the final Runtime-side admission check.  It is
                    # intentionally after durable preparation authentication
                    # and before claiming the request or invoking the runner.
                    self._admit_authoritative_frontier(parsed_fence)
                    try:
                        self._validate_turn_fence(message, submission_fence, project_id=project_id, revision_id=revision_id, attempt=prepared_attempt)
                    except _TurnFenceExpired as error:
                        raise _RuntimeAdmissionBlocked("lease_expired") from error
                receipt = {"request_id": request_id, "session_id": session_id, "project_id": project_id, "revision_id": revision_id, "message_sha256": fingerprint, "source_identity": source_identity, "state": "accepted", "created_at": recovered_receipt.get("created_at", _utc_now()) if recovered_receipt else _utc_now(), **({"frontier_fence": parsed_fence} if parsed_fence is not None else {})}
                if recovered_receipt is not None:
                    self._write_receipt(receipt_path, receipt)
                elif not self._claim_receipt(receipt_path, receipt):
                    existing = self.operation(session_id, request_id)
                    if (existing.get("project_id") != project_id or existing.get("revision_id") != revision_id or existing.get("message_sha256") != fingerprint or existing.get("source_identity") != source_identity or not _exact_submission_fence(existing.get("frontier_fence"), parsed_fence)): raise RuntimeServiceError("request_id reuse conflicts")
                    return existing
                state["state"] = "running"; receipt["state"] = "running"; self._write_receipt(receipt_path, receipt)
                permissions = [_workspace_toolset_name(session_id)] if item.workspace_tools else []
                request = {"session_id": session_id, "identity": dict(item.identity), "permissions": permissions, "binding": dict(item.binding), "message": message, "execution_profile": profile.profile_id, "max_iterations": profile.max_iterations, "max_tokens": profile.max_tokens, "project_id": project_id}
                if source_identity is not None:
                    request["source_identity"] = source_identity
                environment = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HERMES_HOME": str(home), "PYTHONPATH": str(self.config.source_root), "HERMES_MANAGED_API_KEY": self.config.gateway_api_key, APPROVED_EXECUTION_PROFILES_ENV: json.dumps(sorted(self.config.execution_profiles), separators=(",", ":")), "NO_PROXY": "127.0.0.1,::1,localhost", "no_proxy": "127.0.0.1,::1,localhost"}
                if self._skill_library_environment is not None:
                    environment[_SKILL_LIBRARY_ENVIRONMENT] = self._skill_library_environment
                diagnostic: dict[str, Any]
                baseline: set[tuple[str, str, str | None]] | None = None
                if source_identity is not None:
                    prior = self._recover_durable_effects(workspace, home, source_identity, baseline)
                    if prior is not None:
                        baseline = {(item["tool_id"], item["state"], item.get("result_sha256")) for item in prior}
                effect: Any = None
                effects: Any = None
                effect_valid = False
                try:
                    command = [self.config.python, "-m", "agent_runtime.hermes_session_runner", "--home", str(home), "--workspace", str(workspace)]
                    if isinstance(self.runner, SandboxRunner):
                        outcome = self.runner.run(command, profile=profile, workspace=workspace, home=home, source_root=self.config.source_root, input=json.dumps(request), env=environment, drain=lambda: self._write_pause_marker(home))
                        completed = outcome.completed
                    else:
                        # Compatibility seam for existing callers and test
                        # doubles.  A production deployment can pass a
                        # SandboxRunner to enforce its launch specification.
                        completed = self.runner(command, input=json.dumps(request), text=True, capture_output=True, env=environment, timeout=min(self.config.timeout_seconds, profile.timeout_seconds), check=False)
                    response = json.loads(completed.stdout)
                    result = response.get("result") if isinstance(response, Mapping) else None
                    raw_effects = result.get("effect_receipts") if isinstance(result, Mapping) else None
                    if source_identity is None:
                        effects = raw_effects; effect_valid = True
                    elif isinstance(raw_effects, list) and len(raw_effects) <= 32:
                        validated = [validate_public_effect_receipt(item, source_identity["attempt_id"]) for item in raw_effects]
                        effect_valid = all(item is not None for item in validated)
                        effects = [item for item in validated if item is not None] if effect_valid else None
                    else:
                        effects = None; effect_valid = False
                    effect = effects[0] if isinstance(effects, list) and len(effects) == 1 else None
                    valid = completed.returncode == 0 and isinstance(response, Mapping) and response.get("ok") is True and isinstance(result, Mapping) and result.get("completed") is True and result.get("failed") is False and result.get("interrupted") is False and result.get("partial") is False and not result.get("error") and effect_valid
                    protocol = {"ok": response.get("ok") if isinstance(response.get("ok"), bool) else None, "result_keys": sorted(result) if isinstance(result, Mapping) else [], "completed": result.get("completed") if isinstance(result, Mapping) and isinstance(result.get("completed"), bool) else None, "failed": result.get("failed") if isinstance(result, Mapping) and isinstance(result.get("failed"), bool) else None, "interrupted": result.get("interrupted") if isinstance(result, Mapping) and isinstance(result.get("interrupted"), bool) else None, "partial": result.get("partial") if isinstance(result, Mapping) and isinstance(result.get("partial"), bool) else None, "has_error": bool(result.get("error")) if isinstance(result, Mapping) else None}
                    diagnostic = {"category": "invalid_native_result", "exit_code": completed.returncode, "stdout_bytes": len(completed.stdout.encode()), "stdout_sha256": hashlib.sha256(completed.stdout.encode()).hexdigest(), "stderr_bytes": len(completed.stderr.encode()), "stderr_sha256": hashlib.sha256(completed.stderr.encode()).hexdigest(), "protocol": protocol}
                    if isinstance(self.runner, SandboxRunner) and outcome.forced_termination:
                        diagnostic.update({"forced_termination": True, "drained": outcome.drained, "checkpoint_id": outcome.checkpoint_id})
                except Exception as error:
                    valid = False; diagnostic = {"category": "runner_exception", "exception_type": type(error).__name__}
                    effects = self._recover_durable_effects(workspace, home, source_identity, baseline)
                    effect = effects[0] if isinstance(effects, list) and len(effects) == 1 else None
                    effect_valid = isinstance(effects, list)
                if not valid:
                    if source_identity is not None and effects is None:
                        effects = self._recover_durable_effects(workspace, home, source_identity, baseline)
                        effect = effects[0] if isinstance(effects, list) and len(effects) == 1 else None
                        effect_valid = isinstance(effects, list)
                    unknown = {**receipt, "state": "unknown", "finished_at": _utc_now(), "diagnostic": diagnostic, **({"effect_receipts": effects} if isinstance(effects, list) else {})}
                    if effect_valid and isinstance(effect, Mapping): unknown["effect_receipt"] = dict(effect)
                    self._write_receipt(receipt_path, unknown); state["last_outcome"] = "unknown"
                    raise RuntimeServiceError("native turn outcome is unknown")
                receipt.update({"state": "completed", "finished_at": _utc_now(), "result": result, "effect_receipts": effects, **({"effect_receipt": dict(effect)} if isinstance(effect, Mapping) else {})}); self._write_receipt(receipt_path, receipt); state["last_outcome"] = "completed"
                return receipt
        finally:
            state["last_finished_at"] = _utc_now()
            state["state"] = "paused" if state["state"] == "pausing" else "idle"
            if state["state"] == "paused": self._write_pause_marker(home)
            lock.release()

    def compact(self, session_id: str, operation_id: str, expected_context_revision: int, *, guidance: str, compaction_tokens: int | None = None) -> dict[str, Any]:
        """Perform a durable compaction through the owning Hermes runner."""
        item, home, workspace = self._session(session_id)
        if (not isinstance(operation_id, str) or not _SAFE_IDENTIFIER.fullmatch(operation_id)
                or type(expected_context_revision) is not int or expected_context_revision < 0
                or not isinstance(guidance, str) or not guidance.strip() or len(guidance.encode()) > MAX_BODY
                or (compaction_tokens is not None and (type(compaction_tokens) is not int or compaction_tokens < 1))):
            raise RuntimeServiceError("compaction request is invalid")
        profile = self._execution_profile(item)
        configured = compaction_tokens or profile.max_tokens
        operation_path = home / "compactions" / (operation_id + ".json")
        if operation_path.exists():
            prior = self._read_operation(operation_path)
            if (prior.get("expected_context_revision") != expected_context_revision
                    or prior.get("guidance") != guidance
                    or prior.get("compaction_tokens") != configured):
                raise RuntimeServiceError("compaction operation conflicts with its prior request")
            native = prior.get("native")
            previous = native.get("previous_context_revision", native.get("from_revision")) if isinstance(native, Mapping) else None
            new = native.get("new_context_revision", native.get("to_revision")) if isinstance(native, Mapping) else None
            token_proof = (isinstance(native, Mapping) and type(native.get("before_tokens")) is int and native["before_tokens"] >= 0
                           and type(native.get("after_tokens")) is int and native["after_tokens"] >= 0)
            receipt_proof = (isinstance(native, Mapping) and isinstance(native.get("native_receipt_id"), str) and bool(native["native_receipt_id"].strip())
                             and isinstance(native.get("native_state"), str) and native["native_state"] in {"compacted", "completed"})
            token_fields = {"before_tokens", "after_tokens"} & set(native) if isinstance(native, Mapping) else set()
            receipt_fields = {"native_receipt_id", "native_state"} & set(native) if isinstance(native, Mapping) else set()
            if (prior.get("state") != "compacted" or prior.get("session_id") != session_id
                    or prior.get("operation_id") != operation_id
                    or not isinstance(native, Mapping) or native.get("session_id") != session_id
                    or native.get("operation_id") != operation_id
                    or type(previous) is not int or type(new) is not int or previous != expected_context_revision
                    or new != expected_context_revision + 1 or not (token_proof or receipt_proof)
                    or (token_fields and not token_proof) or (receipt_fields and not receipt_proof)):
                raise RuntimeServiceError("stored compaction receipt is invalid")
            return {**prior, "replayed": True}
        lock = self._locks[session_id]
        if not lock.acquire(blocking=False): raise RuntimeServiceError("session is already running")
        try:
            with self._home_owner(home):
                if self._states[session_id].get("state") != "idle" or self._paused_path(home).exists() or self._unresolved(home): raise RuntimeServiceError("compaction requires an idle session")
                request = {"operation": "compact", "operation_id": operation_id, "session_id": session_id, "identity": dict(item.identity), "permissions": [_workspace_toolset_name(session_id)] if item.workspace_tools else [], "binding": dict(item.binding), "guidance": guidance, "compaction_tokens": configured, "expected_context_revision": expected_context_revision, "execution_profile": profile.profile_id, "max_iterations": profile.max_iterations, "max_tokens": profile.max_tokens}
                environment = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HERMES_HOME": str(home), "PYTHONPATH": str(self.config.source_root), "HERMES_MANAGED_API_KEY": self.config.gateway_api_key, APPROVED_EXECUTION_PROFILES_ENV: json.dumps(sorted(self.config.execution_profiles), separators=(",", ":")), "NO_PROXY": "127.0.0.1,::1,localhost", "no_proxy": "127.0.0.1,::1,localhost"}
                try:
                    command = [self.config.python, "-m", "agent_runtime.hermes_session_runner", "--home", str(home), "--workspace", str(workspace)]
                    if isinstance(self.runner, SandboxRunner):
                        outcome = self.runner.run(command, profile=profile, workspace=workspace, home=home, source_root=self.config.source_root, input=json.dumps(request), env=environment, drain=lambda: self._write_pause_marker(home)); completed = outcome.completed
                    else:
                        completed = self.runner(command, input=json.dumps(request), text=True, capture_output=True, env=environment, timeout=min(self.config.timeout_seconds, profile.timeout_seconds), check=False)
                    response = json.loads(completed.stdout); result = response.get("result") if isinstance(response, Mapping) else None
                    if completed.returncode != 0 or not isinstance(response, Mapping) or response.get("ok") is not True or not isinstance(result, Mapping): raise RuntimeServiceError("native compaction is unsupported or ambiguous")
                    previous = result.get("previous_context_revision", result.get("from_revision"))
                    new = result.get("new_context_revision", result.get("to_revision"))
                    token_proof = (type(result.get("before_tokens")) is int and result["before_tokens"] >= 0
                                   and type(result.get("after_tokens")) is int and result["after_tokens"] >= 0)
                    receipt_proof = (isinstance(result.get("native_receipt_id"), str) and bool(result["native_receipt_id"].strip())
                                     and isinstance(result.get("native_state"), str) and result["native_state"] in {"compacted", "completed"})
                    token_fields = {"before_tokens", "after_tokens"} & set(result)
                    receipt_fields = {"native_receipt_id", "native_state"} & set(result)
                    if (result.get("session_id") != session_id or result.get("operation_id") != operation_id
                            or type(result.get("expected_context_revision")) is not int or result.get("expected_context_revision") != expected_context_revision
                            or type(previous) is not int or type(new) is not int
                            or previous != expected_context_revision or new != expected_context_revision + 1
                            or not (token_proof or receipt_proof)
                            or (token_fields and not token_proof) or (receipt_fields and not receipt_proof)
                            or "message" in result):
                        raise RuntimeServiceError("native compaction outcome does not prove context mutation")
                except RuntimeServiceError: raise
                except Exception as error: raise RuntimeServiceError("native compaction is unsupported or ambiguous") from error
                native_receipt = dict(result)
                receipt = {"state": "compacted", "session_id": session_id, "operation_id": operation_id, "expected_context_revision": expected_context_revision, "previous_context_revision": previous, "new_context_revision": new, "before_tokens": result.get("before_tokens"), "after_tokens": result.get("after_tokens"), "native_receipt_id": result.get("native_receipt_id"), "native_state": result.get("native_state"), "guidance": guidance, "compaction_tokens": configured, "native": native_receipt, "replayed": False, "created_at": _utc_now()}
                self._write_receipt(operation_path, receipt)
                return receipt
        finally: lock.release()

    def resume(self, session_id: str) -> dict[str, Any]:
        _, home, _ = self._session(session_id)
        lock, state = self._locks[session_id], self._states[session_id]
        if not lock.acquire(blocking=False): raise RuntimeServiceError("resume requires an idle paused session")
        try:
            with self._home_owner(home):
                marker = self._paused_path(home)
                if not marker.exists() or marker.is_symlink() or self._unresolved(home) or (home / ".turn.lock").exists():
                    raise RuntimeServiceError("resume requires a reconciled paused session")
                marker.unlink(); self._fsync_directory(home); state["state"] = "idle"
                return {"session_id": session_id, "state": "idle"}
        finally: lock.release()

    def _runtime_bundle_scope(self, session_id: str) -> tuple[str, str] | None:
        if self.config.runtime_bundle_client is None:
            return None
        item = self._session_item(session_id)
        scope = self.config.runtime_bundle_bindings.get(session_id)
        if scope is None:
            agent_id = item.identity.get("agent_id") if isinstance(item.identity, Mapping) else None
            if len(item.project_ids) == 1 and isinstance(agent_id, str) and _SAFE_IDENTIFIER.fullmatch(agent_id):
                scope = (next(iter(item.project_ids)), agent_id)
            else:
                raise RuntimeServiceError("runtime bundle scope is unavailable")
        elif scope[0] not in item.project_ids:
            raise RuntimeServiceError("runtime bundle project is not allowed for this session")
        identity_agent = item.identity.get("agent_id") if isinstance(item.identity, Mapping) else None
        if isinstance(identity_agent, str) and _SAFE_IDENTIFIER.fullmatch(identity_agent) and scope[1] != identity_agent:
            raise RuntimeServiceError("runtime bundle agent does not match this session")
        return scope

    @staticmethod
    def _storage_receipt_path(bundle_root: Path) -> Path:
        # Storage's bundle contract reserves .storage.json as its private
        # record; the neutral client excludes it from transport. Reuse that
        # reserved name for local publish state so credentials/metadata never
        # become part of the immutable portable bundle.
        return bundle_root / ".storage.json"

    def _publish_runtime_bundle(self, session_id: str, destination: Path) -> dict[str, Any] | None:
        scope = self._runtime_bundle_scope(session_id)
        client = self.config.runtime_bundle_client
        if scope is None or client is None:
            return None
        project_id, agent_id = scope
        checkpoint_id = destination.name
        receipt_path = self._storage_receipt_path(destination)
        accepted = {"checkpoint_id": checkpoint_id, "project_id": project_id, "agent_id": agent_id, "state": "publishing", "created_at": _utc_now()}
        self._write_receipt(receipt_path, accepted)
        try:
            published = client.publish(destination, project_id, agent_id, checkpoint_id)
        except UnknownRuntimeBundleOutcome as error:
            self._write_receipt(receipt_path, {**accepted, "state": "unknown", "finished_at": _utc_now()})
            raise RuntimeServiceError("runtime bundle publish outcome is unknown; reconcile before retry") from error
        except (RuntimeBundleServiceError, OSError) as error:
            self._write_receipt(receipt_path, {**accepted, "state": "rejected", "finished_at": _utc_now()})
            raise RuntimeServiceError("runtime bundle publish was rejected") from error
        if not isinstance(published, Mapping) or published.get("checkpoint_id", checkpoint_id) != checkpoint_id:
            self._write_receipt(receipt_path, {**accepted, "state": "unknown", "finished_at": _utc_now()})
            raise RuntimeServiceError("runtime bundle publish receipt is invalid")
        result = {"state": "published", "project_id": project_id, "agent_id": agent_id, "checkpoint_id": checkpoint_id}
        self._write_receipt(receipt_path, {**accepted, **result, "storage": dict(published), "finished_at": _utc_now()})
        return result

    def reconcile_checkpoint(self, session_id: str, checkpoint_id: str) -> dict[str, Any]:
        """Reconcile a staged publish without retrying an unknown POST."""
        scope = self._runtime_bundle_scope(session_id)
        client = self.config.runtime_bundle_client
        if scope is None or client is None:
            raise RuntimeServiceError("runtime bundle storage is not configured")
        if not isinstance(checkpoint_id, str) or not _SAFE_IDENTIFIER.fullmatch(checkpoint_id):
            raise RuntimeServiceError("checkpoint ID is invalid")
        project_id, agent_id = scope
        try:
            value = client.reconcile(project_id, agent_id, checkpoint_id)
        except (RuntimeBundleServiceError, OSError) as error:
            raise RuntimeServiceError("runtime bundle reconciliation failed") from error
        if not isinstance(value, Mapping) or value.get("checkpoint_id", checkpoint_id) != checkpoint_id:
            raise RuntimeServiceError("runtime bundle reconciliation receipt is invalid")
        local = self.config.checkpoint_root / checkpoint_id
        if local.is_dir() and not local.is_symlink():
            self._write_receipt(self._storage_receipt_path(local), {"checkpoint_id": checkpoint_id, "project_id": project_id, "agent_id": agent_id, "state": "published", "storage": dict(value), "finished_at": _utc_now()})
        return {"session_id": session_id, "checkpoint_id": checkpoint_id, "state": "published", "storage": dict(value)}

    def checkpoint(self, session_id: str) -> dict[str, Any]:
        item, home, _ = self._session(session_id)
        lock, state = self._locks[session_id], self._states[session_id]
        if not lock.acquire(blocking=False):
            raise RuntimeServiceError("checkpoint requires an idle session")
        try:
            with self._home_owner(home):
                if state["state"] not in {"idle", "paused"} or self._unresolved(home) or (home / ".turn.lock").exists():
                    raise RuntimeServiceError("checkpoint requires a reconciled idle or paused session")
                destination = self.config.checkpoint_root / f"{session_id}-{uuid4().hex}"
                destination.mkdir(mode=0o700)
                if destination.is_symlink(): raise RuntimeServiceError("checkpoint destination is unsafe")
                permissions = [_workspace_toolset_name(session_id)] if item.workspace_tools else []
                profile = self._execution_profile(item)
                driver = HermesSessionDriver(home, session_id, item.identity, permissions, item.binding, execution_profile=profile.profile_id)
                manifest = driver.checkpoint(destination)
                bundle = {"format": "agentstack.hermes.checkpoint.v1", "session_id": session_id,
                          "native": manifest, "pause_state": state["state"],
                          "semantic_handoff": {"last_outcome": state["last_outcome"], "last_finished_at": state["last_finished_at"]},
                          "files": {}}
                for name in ("session-metadata.json",):
                    source = home / name
                    if source.exists() and source.is_file() and not source.is_symlink():
                        target = destination / name
                        shutil.copyfile(source, target)
                        bundle["files"][name] = _file_sha256(target)
                operations = home / "operations"
                if operations.exists() and operations.is_dir() and not operations.is_symlink():
                    target_operations = destination / "operations"
                    target_operations.mkdir()
                    for source in sorted(operations.glob("*.json")):
                        if source.is_symlink() or not source.is_file():
                            raise RuntimeServiceError("operation receipt is unsafe")
                        target = target_operations / source.name
                        shutil.copyfile(source, target)
                        bundle["files"][f"operations/{source.name}"] = _file_sha256(target)
                if self._paused_path(home).exists():
                    (destination / "paused.json").write_text(json.dumps({"state": "paused"}), encoding="utf-8")
                    bundle["files"]["paused.json"] = _file_sha256(destination / "paused.json")
                bundle_path = destination / "bundle.json"
                bundle_path.write_text(json.dumps(bundle, sort_keys=True, separators=(",", ":")), encoding="utf-8")
                bundle["bundle_sha256"] = _file_sha256(bundle_path)
                self._fsync_directory(destination)
                storage = self._publish_runtime_bundle(session_id, destination)
                result = {"session_id": session_id, "checkpoint_id": destination.name, "sha256": manifest["sha256"], "bundle_sha256": bundle["bundle_sha256"]}
                if storage is not None:
                    result["storage_state"] = storage["state"]
                return result
        finally:
            lock.release()

    def materialize_checkpoint(self, session_id: str, checkpoint_id: str, new_home: str | Path) -> dict[str, Any]:
        """Restore a verified portable export into a fresh runtime-root child.

        This compatibility method intentionally does not activate the restored
        directory as the configured session home. Use
        :meth:`restore_into_canonical_home` for that single-writer operation.
        """
        return self._materialize_checkpoint(session_id, checkpoint_id, Path(new_home), activate=False)

    def restore_into_canonical_home(self, session_id: str, checkpoint_id: str) -> dict[str, Any]:
        """Atomically restore and activate an absent configured session home."""
        return self._materialize_checkpoint(
            session_id,
            checkpoint_id,
            self.config.runtime_root / session_id,
            activate=True,
        )

    def _materialize_checkpoint(
        self,
        session_id: str,
        checkpoint_id: str,
        target: Path,
        *,
        activate: bool,
    ) -> dict[str, Any]:
        """Verify before creating a home, then atomically install the bundle."""
        item = self._session_item(session_id)
        if not isinstance(checkpoint_id, str) or not _SAFE_IDENTIFIER.fullmatch(checkpoint_id):
            raise RuntimeServiceError("checkpoint ID is invalid")
        bundle_root = self.config.checkpoint_root / checkpoint_id
        bundle_path = bundle_root / "bundle.json"
        if not bundle_root.exists() and self.config.runtime_bundle_client is not None:
            scope = self._runtime_bundle_scope(session_id)
            if scope is None:
                raise RuntimeServiceError("runtime bundle scope is unavailable")
            try:
                self.config.runtime_bundle_client.materialize(scope[0], scope[1], checkpoint_id, bundle_root)
            except (RuntimeBundleServiceError, OSError) as error:
                raise RuntimeServiceError("durable runtime bundle materialization failed") from error
        if bundle_root.is_symlink() or bundle_path.is_symlink() or not bundle_path.is_file():
            raise RuntimeServiceError("checkpoint bundle is unavailable")
        try:
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise RuntimeServiceError("checkpoint bundle is invalid") from error
        if not isinstance(bundle, Mapping) or bundle.get("format") != "agentstack.hermes.checkpoint.v1" or bundle.get("session_id") != session_id or not isinstance(bundle.get("native"), Mapping) or not isinstance(bundle.get("files"), Mapping):
            raise RuntimeServiceError("checkpoint bundle identity is invalid")
        native = bundle["native"]
        historical_binding = native.get("binding") != item.binding
        compatible_historical = self.registry is not None and session_id not in self.config.sessions and isinstance(native.get("binding"), Mapping) and native.get("binding") in self.config.approved_bindings.values() and native["binding"].get("capabilities", []) == item.binding.get("capabilities", [])
        if native.get("identity") != item.identity or native.get("execution_profile", "legacy-hermes") != item.execution_profile or (historical_binding and not compatible_historical):
            raise RuntimeServiceError("checkpoint session configuration is incompatible")
        expected_permissions = [_workspace_toolset_name(session_id)] if item.workspace_tools else []
        if native.get("permissions") != expected_permissions:
            raise RuntimeServiceError("checkpoint tool identity is incompatible")
        for name, expected in bundle["files"].items():
            if not isinstance(name, str) or Path(name).is_absolute() or ".." in Path(name).parts or not isinstance(expected, str):
                raise RuntimeServiceError("checkpoint bundle file list is unsafe")
            source = bundle_root / name
            if source.is_symlink() or not source.is_file() or _file_sha256(source) != expected:
                raise RuntimeServiceError("checkpoint bundle integrity check failed")
        canonical = self.config.runtime_root / session_id
        if activate and target.absolute() != canonical.absolute():
            raise RuntimeServiceError("restore target must be the canonical session home")
        runtime_root = self.config.runtime_root.resolve()
        try:
            target.parent.resolve().relative_to(runtime_root)
        except ValueError as error:
            raise RuntimeServiceError("restore target must be beneath runtime root") from error
        parent = target.parent
        current = Path(parent.anchor)
        for component in parent.parts[1:]:
            current /= component
            if current.exists() and current.is_symlink():
                raise RuntimeServiceError("restore target has a symlinked ancestor")
        if target.exists() or target.is_symlink() or not parent.is_dir():
            raise RuntimeServiceError("restore target must be an absent local directory")
        lock = self._locks.setdefault(session_id, threading.Lock())
        if not lock.acquire(blocking=False):
            raise RuntimeServiceError("restore requires an inactive session")
        staging = parent / f".restore-{uuid4().hex}"
        try:
            restored = HermesSessionDriver.restore(bundle_root, staging)
            for name in bundle["files"]:
                if name == "session-metadata.json" and not historical_binding:
                    shutil.copyfile(bundle_root / name, staging / name)
                elif name.startswith("operations/"):
                    destination = staging / "operations"; destination.mkdir(exist_ok=True)
                    shutil.copyfile(bundle_root / name, destination / Path(name).name)
                elif name == "paused.json":
                    shutil.copyfile(bundle_root / name, staging / name)
            if historical_binding:
                restored.update_binding(item.binding, list(item.binding.get("capabilities", [])))
            self._fsync_directory(staging)
            os.replace(staging, target)
            self._fsync_directory(parent)
            if activate:
                self._states[session_id] = {
                    "state": bundle.get("pause_state"),
                    "last_finished_at": bundle.get("semantic_handoff", {}).get("last_finished_at"),
                    "last_outcome": bundle.get("semantic_handoff", {}).get("last_outcome"),
                }
        except Exception:
            if staging.exists() and staging.is_dir() and not staging.is_symlink():
                shutil.rmtree(staging)
            raise
        finally:
            lock.release()
        return {"session_id": restored.session_id, "home": str(target), "state": bundle.get("pause_state"),
                "binding_reconciled": historical_binding,
                "reconciliation_required": bool(bundle.get("semantic_handoff", {}).get("last_outcome") == "unknown")}


def make_handler(service: HermesRuntimeService):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _reply(self, status: int, value: Mapping[str, Any]) -> None:
            raw = json.dumps(value, separators=(",", ":"), allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _route(self) -> tuple[str, str] | None:
            pieces = self.path.split("?")[0].strip("/").split("/")
            if len(pieces) == 3 and pieces[0] == "sessions" and pieces[2] in {"turn", "compact", "pause", "resume", "checkpoint", "binding", "attempts", "cleanup"}:
                return pieces[1], pieces[2]
            if len(pieces) == 5 and pieces[0] == "sessions" and pieces[2] == "checkpoints" and pieces[4] == "reconcile":
                return pieces[1], "reconcile:" + pieces[3]
            if len(pieces) == 4 and pieces[0] == "sessions" and pieces[2] == "operations": return pieces[1], "operation:" + pieces[3]
            if len(pieces) == 4 and pieces[0] == "sessions" and pieces[2] == "binding-operations": return pieces[1], "binding-operation:" + pieces[3]
            if len(pieces) == 2 and pieces[0] == "sessions":
                return pieces[1], "status"
            return None

        def do_GET(self) -> None:
            if self.path.split("?", 1)[0] == "/sessions":
                supplied = self.headers.get("Authorization", "")
                projects = {project for token, scopes in service.config.bearer_project_scopes.items() if hmac.compare_digest(supplied[7:] if supplied.startswith("Bearer ") else "", token) for project in scopes}
                if not projects or service.registry is None: self._reply(HTTPStatus.UNAUTHORIZED, {"error":"unauthorized"}); return
                try: self._reply(HTTPStatus.OK, {"sessions": [{key: row[key] for key in ("session_id","project_id","desired_status","revision")} for row in service.registry.list(actor_role="controller", caller_projects=frozenset(projects))]})
                except RuntimeSessionRegistryError as error: self._reply(HTTPStatus.CONFLICT,{"error":str(error)})
                return
            route = self._route()
            if route is None or (route[1] != "status" and not route[1].startswith(("operation:", "binding-operation:"))):
                self._reply(HTTPStatus.NOT_FOUND, {"error": "not_found"}); return
            session_id, _ = route
            if not service._authorize(self.headers.get("Authorization"), session_id):
                self._reply(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"}); return
            try:
                if route[1].startswith("binding-operation:"):
                    if service.registry is None: raise RuntimeServiceError("operation not found")
                    value = service.registry.binding_operation(session_id, route[1].split(":",1)[1], actor_role="controller", caller_projects=frozenset(service.registry.allowed_workspaces))
                else:
                    value = service.operation(session_id, route[1].split(":",1)[1]) if route[1].startswith("operation:") else service.status(session_id)
                if route[1].startswith("binding-operation:"):
                    value = {"session_id": session_id, **value}
                self._reply(HTTPStatus.OK, value)
            except RuntimeServiceError: self._reply(HTTPStatus.NOT_FOUND, {"error": "not_found"})
            except RuntimeSessionRegistryError: self._reply(HTTPStatus.NOT_FOUND, {"error": "not_found"})

        def do_POST(self) -> None:
            if self.path.split("?", 1)[0] == "/sessions":
                try:
                    length=int(self.headers.get("Content-Length","-1"))
                    if not 0 <= length <= MAX_BODY: raise RuntimeServiceError("request too large")
                    body=json.loads(self.rfile.read(length) or b"{}")
                    if not isinstance(body, Mapping) or set(body) != {"session_id","project_id","agent_identity","binding_id","workspace"} or not service._project_authorize(self.headers.get("Authorization"), body.get("project_id")):
                        self._reply(HTTPStatus.UNAUTHORIZED,{"error":"unauthorized"}); return
                    self._reply(HTTPStatus.OK, service.register_session_intent(body["session_id"],body["project_id"],body["agent_identity"],body["binding_id"],body["workspace"],"runtime-project-scope",actor_role="controller",caller_projects=frozenset({body["project_id"]})))
                except (RuntimeServiceError, ValueError, UnicodeError) as error: self._reply(HTTPStatus.CONFLICT,{"error":str(error)})
                return
            route = self._route()
            if route is None or route[1] == "status" or route[1].startswith("operation:"):
                self._reply(HTTPStatus.NOT_FOUND, {"error": "not_found"}); return
            session_id, action = route
            if action == "binding":
                # Binding changes are project-scoped just like dynamic session
                # registration; the runtime has no global management credential.
                if service.registry is None:
                    self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"}); return
                try:
                    length=int(self.headers.get("Content-Length","-1")); body=json.loads(self.rfile.read(length) or b"{}")
                    if length<0 or length>MAX_BODY or not isinstance(body,Mapping) or set(body)!={"binding_id","operation_id","fingerprint","expected_revision"}: raise RuntimeServiceError("binding request is invalid")
                    record=service.registry.get(session_id,actor_role="controller",caller_projects=frozenset(service.registry.allowed_workspaces))
                    if not service._project_authorize(self.headers.get("Authorization"),record["project_id"]): self._reply(HTTPStatus.UNAUTHORIZED,{"error":"unauthorized"}); return
                    self._reply(HTTPStatus.OK,service.update_binding(session_id,body["binding_id"],body["operation_id"],body["fingerprint"],body["expected_revision"],caller_projects=frozenset({record["project_id"]})))
                except (RuntimeServiceError,ValueError,UnicodeError) as error:self._reply(HTTPStatus.CONFLICT,{"error":str(error)})
                return
            if action == "attempts":
                if not service._authorize(self.headers.get("Authorization"), session_id):
                    self._reply(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"}); return
                try:
                    length = int(self.headers.get("Content-Length", "-1"))
                    if length < 0 or length > MAX_BODY: raise RuntimeServiceError("request too large")
                    body = json.loads(self.rfile.read(length) or b"{}")
                    if not isinstance(body, Mapping) or set(body) not in ({"project_id", "revision_id", "immutable_revision", "assignment_id", "submission_fence"}, {"project_id", "revision_id", "immutable_revision", "assignment_id", "submission_fence", "submission_request_id"}):
                        raise RuntimeServiceError("prepared attempt request is invalid")
                    self._reply(HTTPStatus.OK, service.prepare_assignment_attempt(session_id, body["project_id"], body["revision_id"], body["immutable_revision"], body["assignment_id"], body["submission_fence"], body.get("submission_request_id")))
                except (RuntimeServiceError, ValueError, UnicodeError) as error:
                    self._reply(HTTPStatus.CONFLICT, {"error": str(error)})
                return
            if action == "cleanup":
                if not service._authorize(self.headers.get("Authorization"), session_id):
                    self._reply(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"}); return
                try:
                    length = int(self.headers.get("Content-Length", "-1"))
                    if length < 0 or length > MAX_BODY: raise RuntimeServiceError("request too large")
                    body = json.loads(self.rfile.read(length) or b"{}")
                    if (not isinstance(body, Mapping) or set(body) != {"attempt_id"}
                            or not isinstance(body.get("attempt_id"), str)
                            or not _SAFE_IDENTIFIER.fullmatch(body["attempt_id"])):
                        raise RuntimeServiceError("prepared cleanup request is invalid")
                    self._reply(HTTPStatus.OK, service._cleanup_prepared_installation(body["attempt_id"], session_id=session_id))
                except (RuntimeServiceError, ValueError, UnicodeError) as error:
                    self._reply(HTTPStatus.CONFLICT, {"error": str(error)})
                return
            if not service._authorize(self.headers.get("Authorization"), session_id):
                self._reply(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"}); return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 0 or length > MAX_BODY: raise RuntimeServiceError("request too large")
                body = json.loads(self.rfile.read(length) or b"{}")
                if not isinstance(body, Mapping): raise RuntimeServiceError("request must be an object")
                if action == "turn":
                    if set(body) not in ({"request_id", "project_id", "revision_id", "message"}, {"request_id", "project_id", "revision_id", "message", "attempt_id"}, {"request_id", "project_id", "revision_id", "message", "attempt_id", "submission_fence"}): raise RuntimeServiceError("turn has unsupported fields")
                    self._reply(HTTPStatus.OK, service.turn(session_id, body["request_id"], body["project_id"], body["revision_id"], body["message"], attempt_id=body.get("attempt_id"), submission_fence=body.get("submission_fence")))
                elif action == "compact":
                    allowed = {"operation_id", "expected_context_revision", "guidance", "compaction_tokens"}
                    if set(body) - allowed or not {"operation_id", "expected_context_revision", "guidance"}.issubset(body): raise RuntimeServiceError("compaction request is invalid")
                    self._reply(HTTPStatus.OK, service.compact(session_id, body["operation_id"], body["expected_context_revision"], guidance=body["guidance"], compaction_tokens=body.get("compaction_tokens")))
                elif action.startswith("reconcile:"):
                    if body: raise RuntimeServiceError("reconcile takes no body")
                    self._reply(HTTPStatus.OK, service.reconcile_checkpoint(session_id, action.split(":", 1)[1]))
                elif body: raise RuntimeServiceError("operation takes no body")
                elif action == "pause": self._reply(HTTPStatus.ACCEPTED, service.pause(session_id))
                elif action == "resume": self._reply(HTTPStatus.OK, service.resume(session_id))
                else: self._reply(HTTPStatus.OK, service.checkpoint(session_id))
            except _RuntimeAdmissionBlocked as error:
                self._reply(HTTPStatus.CONFLICT, {"error": str(error), "reason": error.reason})
            except _TurnFenceExpired as error:
                self._reply(HTTPStatus.CONFLICT, {"error": str(error), "reason": str(error)})
            except RuntimeServiceError as error:
                self._reply(HTTPStatus.CONFLICT, {"error": str(error)})
            except (ValueError, UnicodeError):
                self._reply(HTTPStatus.BAD_REQUEST, {"error": "invalid_request"})
    return Handler


def serve(service: HermesRuntimeService, address: tuple[str, int] = ("127.0.0.1", 0)) -> ThreadingHTTPServer:
    return ThreadingHTTPServer(address, make_handler(service))


def _copy_json(value: Any) -> Any:
    """Detach configuration allowlists from the JSON object returned by the loader."""
    if isinstance(value, Mapping):
        return {str(key): _copy_json(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_copy_json(item) for item in value]
    return value


def _binding_has_sensitive_or_unsafe_fields(value: Mapping[str, Any]) -> bool:
    """Bindings are a small, credential-free managed routing declaration."""
    allowed = {"model", "provider", "base_url", "capabilities"}
    if not {"model", "provider", "base_url"}.issubset(value) or set(value) - allowed:
        return True
    if any(not isinstance(value[field], str) or not value[field].strip() for field in ("model", "provider", "base_url")):
        return True
    try:
        parsed = urlsplit(value["base_url"])
    except ValueError:
        return True
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment:
        return True
    capabilities = value.get("capabilities", [])
    return (not isinstance(capabilities, list)
            or any(not isinstance(capability, str) or not _SAFE_IDENTIFIER.fullmatch(capability) for capability in capabilities)
            or len(set(capabilities)) != len(capabilities))


def load_configuration(path: str | Path) -> RuntimeServiceConfiguration:
    """Load public configuration plus secret values from separately permissioned files."""
    config_path = Path(path)
    if config_path.is_symlink() or not config_path.is_file(): raise RuntimeServiceError("configuration file is unavailable")
    try: raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error: raise RuntimeServiceError("configuration is invalid") from error
    required = {"runtime_root", "workspace_root", "checkpoint_root", "python", "source_root", "gateway_api_key_file", "bearer_tokens_file", "sessions"}
    dynamic = {"registry_database", "approved_bindings", "project_workspaces", "bearer_project_tokens_file"}
    optional = {"project_workspace_tools", "execution_profiles", "project_execution_profiles", "runtime_bundle", "sandbox_backend", "prepared_attempts", "frontier_authority", "skill_library"}
    if not isinstance(raw, Mapping) or set(raw) - (required | dynamic | optional | {"timeout_seconds"}) or not required.issubset(raw): raise RuntimeServiceError("configuration fields are invalid")
    path_fields = ("runtime_root", "workspace_root", "checkpoint_root", "source_root", "gateway_api_key_file", "bearer_tokens_file")
    if (any(not isinstance(raw[field], str) or not raw[field] for field in path_fields)
            or not isinstance(raw["python"], str) or not raw["python"]
            or ("timeout_seconds" in raw and (type(raw["timeout_seconds"]) is not int or not 1 <= raw["timeout_seconds"] <= 300))):
        raise RuntimeServiceError("configuration field types are invalid")
    key_path, tokens_path = Path(raw["gateway_api_key_file"]), Path(raw["bearer_tokens_file"])
    if key_path.is_symlink() or tokens_path.is_symlink(): raise RuntimeServiceError("credential file is unsafe")
    try:
        key = key_path.read_text(encoding="utf-8").strip()
        tokens_raw = json.loads(tokens_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error: raise RuntimeServiceError("credential file is unavailable") from error
    if not isinstance(tokens_raw, Mapping) or any(not isinstance(token, str) or not token or not isinstance(scopes, list) or any(not isinstance(value, str) for value in scopes) for token, scopes in tokens_raw.items()): raise RuntimeServiceError("bearer scopes are invalid")
    project_scopes = {}
    if any(key in raw for key in dynamic):
        if not dynamic.issubset(raw): raise RuntimeServiceError("dynamic registry configuration is incomplete")
        if not isinstance(raw["registry_database"], str) or not raw["registry_database"] or not isinstance(raw["bearer_project_tokens_file"], str) or not raw["bearer_project_tokens_file"]:
            raise RuntimeServiceError("dynamic registry configuration is invalid")
        project_token_path = Path(raw["bearer_project_tokens_file"])
        if project_token_path.is_symlink():
            raise RuntimeServiceError("project token file is unsafe")
        try: project_tokens = json.loads(project_token_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error: raise RuntimeServiceError("project token file is unavailable") from error
        if not isinstance(project_tokens, Mapping) or any(not isinstance(token,str) or not token or not isinstance(projects,list) or not projects or any(not isinstance(project,str) or not project for project in projects) for token,projects in project_tokens.items()): raise RuntimeServiceError("project token scopes are invalid")
        project_scopes = {token:frozenset(projects) for token,projects in project_tokens.items()}
        if not isinstance(raw["approved_bindings"], Mapping) or not isinstance(raw["project_workspaces"], Mapping) or not isinstance(raw.get("project_workspace_tools", {}), Mapping) or any(not isinstance(key,str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", key) or not isinstance(value, Mapping) or _binding_has_sensitive_or_unsafe_fields(value) for key,value in raw["approved_bindings"].items()) or any(not isinstance(project,str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", project) or not isinstance(workspaces,list) or not workspaces or any(not isinstance(workspace, str) or not workspace for workspace in workspaces) for project,workspaces in raw["project_workspaces"].items()) or any(not isinstance(project,str) or project not in raw["project_workspaces"] or not isinstance(workspaces,list) or not workspaces or any(not isinstance(workspace,str) or workspace not in raw["project_workspaces"][project] for workspace in workspaces) for project,workspaces in raw.get("project_workspace_tools", {}).items()): raise RuntimeServiceError("dynamic allowlists are invalid")
        registry_database = Path(raw["registry_database"])
    else: registry_database = None
    sessions = {}
    if not isinstance(raw["sessions"], Mapping): raise RuntimeServiceError("sessions are invalid")
    profile_values = raw.get("execution_profiles", {LEGACY_HERMES_PROFILE.profile_id: {"max_iterations": LEGACY_HERMES_PROFILE.max_iterations, "max_tokens": LEGACY_HERMES_PROFILE.max_tokens, "timeout_seconds": LEGACY_HERMES_PROFILE.timeout_seconds, "allowed_network_routes": list(LEGACY_HERMES_PROFILE.allowed_network_routes) }})
    if not isinstance(profile_values, Mapping):
        raise RuntimeServiceError("execution profiles are invalid")
    try:
        profiles = {profile_id: ExecutionProfile.from_mapping(profile_id, value) for profile_id, value in profile_values.items()}
    except (ExecutionProfileError, TypeError) as error:
        raise RuntimeServiceError("execution profiles are invalid") from error
    project_profiles = raw.get("project_execution_profiles", {})
    if not isinstance(project_profiles, Mapping) or any(not isinstance(project, str) or not isinstance(profile_id, str) or profile_id not in profiles for project, profile_id in project_profiles.items()):
        raise RuntimeServiceError("project execution profiles are invalid")
    runtime_bundle_client = None
    runtime_bundle_bindings: dict[str, tuple[str, str]] = {}
    runtime_bundle = raw.get("runtime_bundle")
    if runtime_bundle is not None:
        if not isinstance(runtime_bundle, Mapping) or set(runtime_bundle) - {"base_url", "token_file", "ca_file", "bindings"} or not {"base_url", "token_file", "bindings"}.issubset(runtime_bundle) or not isinstance(runtime_bundle["base_url"], str) or not isinstance(runtime_bundle["token_file"], str) or not isinstance(runtime_bundle["bindings"], Mapping):
            raise RuntimeServiceError("runtime bundle configuration is invalid")
        token_path = Path(runtime_bundle["token_file"])
        if token_path.is_symlink() or not token_path.is_file():
            raise RuntimeServiceError("runtime bundle token file is unavailable")
        try:
            token = token_path.read_text(encoding="utf-8").strip()
            runtime_bundle_client = RuntimeBundleHttpClient(runtime_bundle["base_url"], token, ca_file=runtime_bundle.get("ca_file"))
        except (OSError, TypeError, ValueError, RuntimeBundleServiceError) as error:
            raise RuntimeServiceError("runtime bundle client configuration is invalid") from error
        for session_id, value in runtime_bundle["bindings"].items():
            if not isinstance(session_id, str) or not isinstance(value, Mapping) or set(value) != {"project_id", "agent_id"} or not isinstance(value["project_id"], str) or not isinstance(value["agent_id"], str):
                raise RuntimeServiceError("runtime bundle binding is invalid")
            runtime_bundle_bindings[session_id] = (value["project_id"], value["agent_id"])
    sandbox_backend = None
    raw_sandbox = raw.get("sandbox_backend")
    if raw_sandbox is not None:
        if (not isinstance(raw_sandbox, Mapping)
                or set(raw_sandbox) != {"backend", "node", "bridge_path", "package_root", "image"}
                or raw_sandbox["backend"] != "sandcastle-custom-docker"
                or any(not isinstance(raw_sandbox[key], str) or not raw_sandbox[key]
                       for key in ("node", "bridge_path", "package_root", "image"))):
            raise RuntimeServiceError("sandbox backend configuration is invalid")
        try:
            sandbox_backend = SandcastleBridgeConfiguration(
                raw_sandbox["node"], Path(raw_sandbox["bridge_path"]),
                Path(raw_sandbox["package_root"]), raw_sandbox["image"]
            )
            SandcastleBackend(sandbox_backend)
        except (SandboxRunnerError, OSError, ValueError, TypeError) as error:
            raise RuntimeServiceError("sandbox backend configuration is invalid") from error
    skill_library = None
    raw_skill_library = raw.get("skill_library")
    if raw_skill_library is not None:
        required_skill_fields = {"repository_root", "projection_root", "state_path", "runtime_version", "approved_releases", "project_releases"}
        if (not isinstance(raw_skill_library, Mapping)
                or set(raw_skill_library) - (required_skill_fields | {"proposal_root"})
                or not required_skill_fields.issubset(raw_skill_library)
                or any(not isinstance(raw_skill_library[field], str) or not raw_skill_library[field]
                       for field in ("repository_root", "projection_root", "state_path", "runtime_version"))):
            raise RuntimeServiceError("skill library configuration is invalid")
        try:
            skill_library = SkillReleaseLibrary(
                raw_skill_library["repository_root"], raw_skill_library["projection_root"],
                raw_skill_library["state_path"], runtime_version=raw_skill_library["runtime_version"],
                approved_releases=raw_skill_library["approved_releases"],
                project_releases=raw_skill_library["project_releases"],
                proposal_root=raw_skill_library.get("proposal_root"),
            )
        except (SkillReleaseError, OSError, TypeError, ValueError) as error:
            raise RuntimeServiceError("skill library configuration is invalid") from error
    prepared_attempts: dict[str, PreparedAssignmentAttempt] = {}
    raw_attempts = raw.get("prepared_attempts", {})
    if not isinstance(raw_attempts, Mapping):
        raise RuntimeServiceError("prepared attempts are invalid")
    for attempt_id, value in raw_attempts.items():
        if not isinstance(value, Mapping) or set(value) not in ({"session_id", "project_id", "revision_id", "immutable_revision", "workspace", "runtime_home", "assignment_id", "submission_fence"}, {"session_id", "project_id", "revision_id", "immutable_revision", "workspace", "runtime_home", "assignment_id", "submission_fence", "submission_request_id"}):
            raise RuntimeServiceError("prepared attempt is invalid")
        try:
            prepared_attempts[attempt_id] = PreparedAssignmentAttempt(attempt_id, value["session_id"], value["project_id"], value["revision_id"], value["immutable_revision"], value["workspace"], value["runtime_home"], value["assignment_id"], value["submission_fence"], value.get("submission_request_id"))
        except (RuntimeServiceError, TypeError, KeyError) as error:
            raise RuntimeServiceError("prepared attempt is invalid") from error
    frontier_authority = None
    raw_frontier_authority = raw.get("frontier_authority")
    if raw_frontier_authority is not None:
        if (not isinstance(raw_frontier_authority, Mapping)
                or set(raw_frontier_authority) != {"state_file"}
                or not isinstance(raw_frontier_authority["state_file"], str)
                or not raw_frontier_authority["state_file"]):
            raise RuntimeServiceError("runtime frontier authority configuration is invalid")
        frontier_authority = FileRuntimeFrontierAuthority(raw_frontier_authority["state_file"])
    for session_id, value in raw["sessions"].items():
        if not isinstance(value, Mapping) or set(value) - {"identity", "binding", "workspace", "project_ids", "workspace_tools", "execution_profile"} or not {"identity", "binding", "workspace", "project_ids"}.issubset(value) or not isinstance(value["project_ids"], list) or ("workspace_tools" in value and type(value["workspace_tools"]) is not bool) or ("execution_profile" in value and value["execution_profile"] not in profiles): raise RuntimeServiceError("session fields are invalid")
        sessions[session_id] = SessionConfiguration(_copy_json(value["identity"]), _copy_json(value["binding"]), value["workspace"], frozenset(value["project_ids"]), value.get("workspace_tools", False), value.get("execution_profile", LEGACY_HERMES_PROFILE.profile_id))
    return RuntimeServiceConfiguration(Path(raw["runtime_root"]), Path(raw["workspace_root"]), Path(raw["checkpoint_root"]), raw["python"], Path(raw["source_root"]), key, {token: frozenset(scopes) for token, scopes in tokens_raw.items()}, sessions, raw.get("timeout_seconds", 180), {binding_id: _copy_json(binding) for binding_id, binding in raw.get("approved_bindings", {}).items()}, project_scopes, registry_database, {project:frozenset(workspaces) for project,workspaces in raw.get("project_workspaces", {}).items()}, {project:frozenset(workspaces) for project,workspaces in raw.get("project_workspace_tools", {}).items()}, profiles, dict(project_profiles), runtime_bundle_client, runtime_bundle_bindings, sandbox_backend, prepared_attempts, frontier_authority=frontier_authority, frontier_authority_required=True, skill_library=skill_library)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Serve configured local Hermes sessions")
    parser.add_argument("--config", required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18120)
    args = parser.parse_args(argv)
    if args.host != "127.0.0.1" or not 1 <= args.port <= 65535: raise SystemExit("127.0.0.1 and valid port required")
    server = serve(HermesRuntimeService(load_configuration(args.config)), (args.host, args.port))
    try: server.serve_forever()
    finally: server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
