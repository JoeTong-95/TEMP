"""Agent Runtime layer: Hermes sessions, turns, tools, and local hot state."""

__all__ = ("HermesRuntimeService", "RuntimeServiceConfiguration", "RuntimeFrontierAuthority", "FileRuntimeFrontierAuthority", "load_configuration", "ExecutionProfile", "SandboxLaunchSpec", "SandboxRunner", "SandcastleBackend", "SandcastleBridgeConfiguration", "HermesProjectError", "ProjectDescriptor", "OpenProjectResult", "HermesProjectOpener", "open_project", "SkillRelease", "SkillProjection", "SkillReleaseError", "SkillReleaseLibrary")


def __getattr__(name: str):
    if name not in __all__:
        raise AttributeError(name)
    if name in {"ExecutionProfile"}:
        from .execution_profiles import ExecutionProfile
        return ExecutionProfile
    if name in {"SandboxLaunchSpec", "SandboxRunner"}:
        from .sandbox_runner import SandboxLaunchSpec, SandboxRunner
        return {"SandboxLaunchSpec": SandboxLaunchSpec, "SandboxRunner": SandboxRunner}[name]
    if name in {"SandcastleBackend", "SandcastleBridgeConfiguration"}:
        from .sandcastle_backend import SandcastleBackend, SandcastleBridgeConfiguration
        return {"SandcastleBackend": SandcastleBackend, "SandcastleBridgeConfiguration": SandcastleBridgeConfiguration}[name]
    if name in {"HermesProjectError", "ProjectDescriptor", "OpenProjectResult", "HermesProjectOpener", "open_project"}:
        from .hermes_project import HermesProjectError, ProjectDescriptor, OpenProjectResult, HermesProjectOpener, open_project
        return {"HermesProjectError": HermesProjectError, "ProjectDescriptor": ProjectDescriptor, "OpenProjectResult": OpenProjectResult, "HermesProjectOpener": HermesProjectOpener, "open_project": open_project}[name]
    if name in {"SkillRelease", "SkillProjection", "SkillReleaseError", "SkillReleaseLibrary"}:
        from .skill_releases import SkillProjection, SkillRelease, SkillReleaseError, SkillReleaseLibrary
        return {"SkillRelease": SkillRelease, "SkillProjection": SkillProjection, "SkillReleaseError": SkillReleaseError, "SkillReleaseLibrary": SkillReleaseLibrary}[name]
    from . import hermes_runtime_service
    return getattr(hermes_runtime_service, name)
