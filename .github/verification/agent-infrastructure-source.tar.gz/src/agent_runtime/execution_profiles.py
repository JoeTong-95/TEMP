"""Approved execution profiles for managed Hermes coding sessions.

Profiles are deliberately data-only.  They describe the limits and the
boundary a launcher must enforce; this module does not pretend to provision a
container engine or to provide a native Sandcastle integration.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Mapping


class ExecutionProfileError(ValueError):
    """An execution profile is malformed or attempts to broaden isolation."""


_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_DOCKER_INTERNAL_ENDPOINT = re.compile(r"docker-internal-endpoint:[A-Za-z0-9][A-Za-z0-9_.-]{0,62}:[A-Za-z0-9][A-Za-z0-9_.-]{0,62}:(?:[1-9][0-9]{0,4})\Z")


@dataclass(frozen=True)
class ExecutionProfile:
    """An allowlisted set of Hermes and sandbox limits.

    ``allowed_network_routes`` contains route labels understood by the eventual
    sandbox backend (for example ``loopback`` or an approved gateway origin).
    An empty tuple means no network route is approved.  Host mounts, Docker
    control sockets, privilege escalation and Windows interop are always
    opt-in fields and default to disabled.
    """

    profile_id: str
    max_iterations: int = 10
    max_tokens: int = 128
    timeout_seconds: int = 180
    cpu_limit_seconds: int = 300
    memory_limit_mb: int = 1024
    pids_limit: int = 128
    disk_limit_mb: int = 4096
    allowed_network_routes: tuple[str, ...] = ()
    allow_host_mounts: bool = False
    allow_docker_socket: bool = False
    privileged: bool = False
    allow_windows_interop: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.profile_id, str) or not _IDENTIFIER.fullmatch(self.profile_id):
            raise ExecutionProfileError("profile_id is unsafe")
        for name, value, maximum in (
            ("max_iterations", self.max_iterations, 1000),
            ("max_tokens", self.max_tokens, 1_000_000),
            ("timeout_seconds", self.timeout_seconds, 86_400),
            ("cpu_limit_seconds", self.cpu_limit_seconds, 86_400),
            ("memory_limit_mb", self.memory_limit_mb, 1_048_576),
            ("pids_limit", self.pids_limit, 32_768),
            ("disk_limit_mb", self.disk_limit_mb, 1_048_576),
        ):
            if type(value) is not int or not 1 <= value <= maximum:
                raise ExecutionProfileError(f"{name} must be a bounded positive integer")
        if not isinstance(self.allowed_network_routes, tuple):
            raise ExecutionProfileError("allowed_network_routes must be a tuple")
        if len(set(self.allowed_network_routes)) != len(self.allowed_network_routes):
            raise ExecutionProfileError("network routes must be unique")
        # Sandcastle understands only an isolated loopback route or one
        # internal Docker endpoint containing its network, service identity,
        # and TCP port. The bridge starts a private network namespace guard
        # that allows only that resolved endpoint and port.
        if self.allowed_network_routes not in {(), ("loopback",)} and not (len(self.allowed_network_routes) == 1 and isinstance(self.allowed_network_routes[0], str) and _DOCKER_INTERNAL_ENDPOINT.fullmatch(self.allowed_network_routes[0]) and 1 <= int(self.allowed_network_routes[0].rsplit(":", 1)[1]) <= 65535):
            raise ExecutionProfileError("network route is not supported by the sandbox bridge")
        for name in ("allow_host_mounts", "allow_docker_socket", "privileged", "allow_windows_interop"):
            if type(getattr(self, name)) is not bool:
                raise ExecutionProfileError(f"{name} must be boolean")
        if self.allow_host_mounts or self.allow_docker_socket or self.privileged or self.allow_windows_interop:
            raise ExecutionProfileError("unsafe host integration is not approved for Hermes profiles")

    @classmethod
    def from_mapping(cls, profile_id: str, value: Mapping[str, Any]) -> "ExecutionProfile":
        if not isinstance(value, Mapping):
            raise ExecutionProfileError("execution profile must be an object")
        allowed = {
            "max_iterations", "max_tokens", "timeout_seconds", "cpu_limit_seconds",
            "memory_limit_mb", "pids_limit", "disk_limit_mb", "allowed_network_routes",
            "allow_host_mounts", "allow_docker_socket", "privileged", "allow_windows_interop",
        }
        if set(value) - allowed:
            raise ExecutionProfileError("execution profile contains unsupported fields")
        routes = value.get("allowed_network_routes", ())
        if isinstance(routes, list):
            routes = tuple(routes)
        return cls(profile_id=profile_id, **dict(value, allowed_network_routes=routes))


# Compatibility profile for callers that construct RuntimeServiceConfiguration
# directly.  New deployments should name an approved profile explicitly.
LEGACY_HERMES_PROFILE = ExecutionProfile("legacy-hermes", allowed_network_routes=("loopback",))

# The attended add-on runs directly against local, operator-selected roots. It
# is deliberately separate from managed profiles, which must carry a prepared
# authenticated source identity before the runner launches a driver.
STANDALONE_LOCAL_ATTENDED_PROFILE = "attended-hermes"

# Runtime services pass the configured profile identifiers to the subprocess
# through this inherited environment boundary.  The request itself cannot
# declare which profiles the runner should trust.
APPROVED_EXECUTION_PROFILES_ENV = "HERMES_APPROVED_EXECUTION_PROFILES"


def copy_profiles(profiles: Mapping[str, ExecutionProfile] | None) -> dict[str, ExecutionProfile]:
    if profiles is None:
        return {LEGACY_HERMES_PROFILE.profile_id: LEGACY_HERMES_PROFILE}
    result = dict(profiles)
    if not result:
        raise ExecutionProfileError("at least one execution profile is required")
    for profile_id, profile in result.items():
        if profile_id == STANDALONE_LOCAL_ATTENDED_PROFILE:
            raise ExecutionProfileError(
                "execution profile ID 'attended-hermes' is reserved for standalone attended Hermes and cannot be configured as managed"
            )
        if not isinstance(profile_id, str) or not isinstance(profile, ExecutionProfile) or profile.profile_id != profile_id:
            raise ExecutionProfileError("execution profile map is invalid")
    return result
