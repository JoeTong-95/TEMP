from __future__ import annotations

import json
import multiprocessing
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from typing import Any
from unittest.mock import patch

from attended_hermes_adapter import (
    HermesCompatibilityError,
    HermesUnsupportedHookError,
    stage_installation,
    _ProfileProcessLock,
)


def _hold_profile_lock(path: str, ready: Any, release: Any) -> None:
    with _ProfileProcessLock(Path(path), timeout=2):
        ready.set()
        release.wait(3)


class FakeDriver:
    calls: list[dict[str, object]] = []

    def __init__(self, home, session_id, identity, permissions, binding, *, max_iterations, max_tokens, execution_profile):
        self.home = Path(home)
        self.session_id = session_id
        self.identity = identity
        self.permissions = permissions
        self.binding = binding
        self.execution_profile = execution_profile
        type(self).calls.append({
            "home": self.home,
            "session_id": session_id,
            "identity": identity,
            "permissions": permissions,
            "binding": binding,
            "max_iterations": max_iterations,
            "max_tokens": max_tokens,
            "execution_profile": execution_profile,
        })

    def run_turn(self, message):
        return {"session_id": self.session_id, "message": message, "mode": self.identity["mode"]}


class RecordingAddon:
    hooks = ("attended_profile", "local_turn")

    def __init__(self):
        self.profile_calls: list[dict[str, object]] = []
        self.turn_calls: list[dict[str, object]] = []

    def configure_attended_profile(self, profile):
        self.profile_calls.append(dict(profile))

    def before_local_turn(self, profile, message):
        self.turn_calls.append({"profile_id": profile["profile_id"], "message": message})


class TamperingAddon(RecordingAddon):
    def __init__(self, profile_root):
        super().__init__()
        self.profile_root = Path(profile_root)

    def before_local_turn(self, profile, message):
        super().before_local_turn(profile, message)
        persisted = json.loads((self.profile_root / "profile.json").read_text())
        persisted["provider"] = {**persisted["provider"], "model": "tampered"}
        (self.profile_root / "profile.json").write_text(json.dumps(persisted))


class IncompleteAddon:
    hooks = ("attended_profile",)


class FalseyAddon(RecordingAddon):
    def __bool__(self):
        return False


class MixedHookAddon:
    hooks = ("attended_profile", "unknown", 42)


class UnhashableHookAddon:
    hooks = ("attended_profile", ["local_turn"])


class AttendedHermesAdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.stage_root = self.root / "stage"
        self.profile_root = self.root / "profile"
        self.project_root = self.root / "project"
        self.manifest = Path(__file__).with_name("hermes-stage-manifest.json")
        FakeDriver.calls = []

    def tearDown(self):
        self.temp.cleanup()

    def test_stage_declares_versions_and_invokes_supported_addon_hooks_for_local_turn(self):
        installation = stage_installation(self.stage_root, self.manifest)
        addon = RecordingAddon()
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "local-model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            session_id="attended-local",
            addon=addon,
            driver_factory=FakeDriver,
        )

        result = adapter.run_turn("hello local")

        self.assertEqual({"session_id": "attended-local", "message": "hello local", "mode": "attended"}, result)
        self.assertNotIn("source_identity", result)
        self.assertNotIn("effect_receipts", result)
        self.assertEqual("0.19.0", installation.compatibility.upstream_version)
        self.assertEqual("0.1.0", installation.compatibility.addon_version)
        self.assertEqual("attended", addon.profile_calls[0]["mode"])
        self.assertEqual({"profile_id": "attended-local", "message": "hello local"}, addon.turn_calls[0])
        self.assertEqual("attended-hermes", FakeDriver.calls[0]["execution_profile"])
        self.assertEqual(self.project_root.resolve(), Path(FakeDriver.calls[0]["identity"]["project_root"]).resolve())
        staged_manifest = json.loads((self.stage_root / "manifest.json").read_text())
        self.assertEqual("agent-stack.attended-hermes-stage", staged_manifest["schema"])
        self.assertFalse(staged_manifest["compatibility"]["source_patching"])

    def test_status_exposes_validated_auth_mode_without_changing_turn_result(self):
        installation = stage_installation(self.stage_root, self.manifest)
        for auth, expected in (("api_key", "api_key"), ("subscription", "subscription")):
            with self.subTest(auth=auth):
                adapter = installation.create_profile(
                    self.root / ("profile-" + auth),
                    self.root / ("project-" + auth),
                    {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080", "auth_mode": auth},
                    session_id="session-" + auth,
                    driver_factory=FakeDriver,
                )
                self.assertEqual(expected, adapter.status()["auth_mode"])
                self.assertEqual(expected, adapter.auth_mode)
                result = adapter.run_turn("hello")
                self.assertNotIn("auth_mode", result)
                restarted = adapter.restart()
                self.assertEqual(expected, restarted.status()["auth_mode"])

    def test_run_revalidates_persisted_provider_after_construction(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}
        adapter = installation.create_profile(self.profile_root, self.project_root, provider, driver_factory=FakeDriver)
        persisted = json.loads((self.profile_root / "profile.json").read_text())
        persisted["provider"] = {**provider, "model": "tampered"}
        (self.profile_root / "profile.json").write_text(json.dumps(persisted))

        with self.assertRaisesRegex(HermesCompatibilityError, "provider configuration changed"):
            adapter.status()
        with self.assertRaisesRegex(HermesCompatibilityError, "provider configuration changed"):
            adapter.run_turn("must not launch")
        self.assertEqual([], FakeDriver.calls)

    def test_run_rejects_provider_tampered_by_local_turn_hook_before_launch(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            provider,
            addon=TamperingAddon(self.profile_root),
            driver_factory=FakeDriver,
        )

        with self.assertRaisesRegex(HermesCompatibilityError, "provider configuration changed"):
            adapter.run_turn("must not launch")
        self.assertEqual([], FakeDriver.calls)

    def test_restart_reopens_profile_from_persisted_provider(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}
        adapter = installation.create_profile(self.profile_root, self.project_root, provider, driver_factory=FakeDriver)
        # A new adapter instance represents a process restart and must use the
        # durable binding, not an old in-memory object.
        restarted = installation.create_profile(self.profile_root, self.project_root, dict(provider), driver_factory=FakeDriver)
        self.assertEqual("api_key", restarted.status()["auth_mode"])
        self.assertEqual({"session_id": "attended-session", "message": "after restart", "mode": "attended"}, restarted.run_turn("after restart"))

    def test_restart_tampered_provider_cannot_transition_back_to_ready(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}
        adapter = installation.create_profile(self.profile_root, self.project_root, provider, driver_factory=FakeDriver)
        persisted = json.loads((self.profile_root / "profile.json").read_text())
        persisted["provider"] = {**provider, "model": "tampered"}
        (self.profile_root / "profile.json").write_text(json.dumps(persisted))

        with self.assertRaisesRegex(HermesCompatibilityError, "provider configuration changed"):
            adapter.restart()
        self.assertEqual("ready", json.loads((self.profile_root / "startup.json").read_text())["state"])

    def test_recovery_tampered_provider_cannot_transition_back_to_ready(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}
        adapter = installation.create_profile(self.profile_root, self.project_root, provider, driver_factory=FakeDriver)
        (self.profile_root / "startup.json").write_text(json.dumps({"state": "starting", "generation": 2}))
        persisted = json.loads((self.profile_root / "profile.json").read_text())
        persisted["provider"] = {**provider, "model": "tampered"}
        (self.profile_root / "profile.json").write_text(json.dumps(persisted))

        with self.assertRaisesRegex(HermesCompatibilityError, "provider configuration changed"):
            adapter.recover_interrupted_startup()
        self.assertEqual("starting", json.loads((self.profile_root / "startup.json").read_text())["state"])

    def test_optional_local_workspace_toolset_stays_within_namespaced_permission(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "local-model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            workspace_toolset="agentstack_workspace_local",
            driver_factory=FakeDriver,
        )
        with patch("agent_runtime.hermes_session_runner.register_hermes_workspace_toolset"):
            adapter.run_turn("use local workspace")
        self.assertEqual(["agentstack_workspace_local"], FakeDriver.calls[0]["permissions"])
        with self.assertRaises(ValueError):
            installation.create_profile(
                self.root / "bad-profile",
                self.root / "bad-project",
                {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
                workspace_toolset="terminal",
                driver_factory=FakeDriver,
            )

    def test_secret_bearing_nested_capabilities_are_rejected_before_profile_write(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {
            "model": "m",
            "provider": "local",
            "base_url": "http://127.0.0.1:8080",
            "capabilities": [{"api_key": "must-not-persist"}],
        }
        with self.assertRaisesRegex(ValueError, "capabilities"):
            installation.create_profile(
                self.profile_root,
                self.project_root,
                provider,
                driver_factory=FakeDriver,
            )
        self.assertFalse((self.profile_root / "profile.json").exists())

    def test_profile_lifecycle_lock_excludes_another_process(self):
        context = multiprocessing.get_context("spawn")
        ready, release = context.Event(), context.Event()
        worker = context.Process(target=_hold_profile_lock, args=(str(self.profile_root / ".lifecycle.lock"), ready, release))
        worker.start()
        try:
            self.assertTrue(ready.wait(3))
            with self.assertRaisesRegex(HermesCompatibilityError, "lock is busy"):
                with _ProfileProcessLock(self.profile_root / ".lifecycle.lock", timeout=0.1):
                    pass
        finally:
            release.set(); worker.join(3)
            if worker.is_alive():
                worker.terminate(); worker.join(3)
        self.assertEqual(0, worker.exitcode)

    @unittest.skipUnless(hasattr(os, "symlink"), "symlink unavailable")
    def test_profile_authority_symlink_is_rejected(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(self.profile_root, self.project_root, {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}, driver_factory=FakeDriver)
        target = self.root / "outside.json"
        target.write_text((self.profile_root / "profile.json").read_text())
        (self.profile_root / "profile.json").unlink()
        try:
            (self.profile_root / "profile.json").symlink_to(target)
        except OSError as error:
            self.skipTest(f"symlink creation unavailable: {error}")
        with self.assertRaisesRegex(HermesCompatibilityError, "authority"):
            adapter.status()

    def test_profile_authority_nonregular_file_is_rejected(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(self.profile_root, self.project_root, {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}, driver_factory=FakeDriver)
        (self.profile_root / "profile.json").unlink()
        (self.profile_root / "profile.json").mkdir()
        with self.assertRaisesRegex(HermesCompatibilityError, "authority"):
            adapter.status()

    @unittest.skipUnless(hasattr(os, "symlink"), "symlink unavailable")
    def test_preplanted_lifecycle_lock_symlink_is_rejected(self):
        outside = self.root / "outside.lock"
        outside.touch()
        lock = self.profile_root / ".lifecycle.lock"
        try:
            lock.symlink_to(outside)
        except OSError as error:
            self.skipTest(f"symlink creation unavailable: {error}")
        with self.assertRaisesRegex(HermesCompatibilityError, "authority"):
            with _ProfileProcessLock(lock, timeout=0.1):
                pass

    def test_before_local_turn_can_query_nested_status_without_deadlock(self):
        installation = stage_installation(self.stage_root, self.manifest)
        holder: dict[str, Any] = {}

        class StatusAddon(RecordingAddon):
            def before_local_turn(inner, profile, message):
                holder["status"] = holder["adapter"].status()

        holder["adapter"] = installation.create_profile(self.profile_root, self.project_root, {"model": "m", "provider": "p", "base_url": "http://127.0.0.1:8080"}, addon=StatusAddon(), driver_factory=FakeDriver)
        self.assertEqual("attended", holder["adapter"].run_turn("nested")["mode"])
        self.assertEqual("ready", holder["status"]["state"])

    def test_unknown_auth_declarations_are_rejected_at_profile_boundary(self):
        installation = stage_installation(self.stage_root, self.manifest)
        for field in ("auth_mode", "auth_type"):
            with self.assertRaisesRegex(ValueError, "api_key, subscription, or oauth"):
                installation.create_profile(
                    self.root / ("bad-" + field), self.root / ("project-" + field),
                    {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080", field: "mystery"},
                    driver_factory=FakeDriver,
                )

    def test_null_auth_declarations_are_rejected_at_profile_boundary(self):
        installation = stage_installation(self.stage_root, self.manifest)
        for field in ("auth_mode", "auth_type"):
            with self.assertRaisesRegex(ValueError, "auth mode and type must be strings"):
                installation.create_profile(
                    self.root / ("null-" + field), self.root / ("project-null-" + field),
                    {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080", field: None},
                    driver_factory=FakeDriver,
                )

    def test_environment_sensitive_runner_is_serialized_across_profiles(self):
        installation = stage_installation(self.stage_root, self.manifest)
        first = installation.create_profile(
            self.root / "profile-a",
            self.root / "project-a",
            {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            session_id="session-a",
            driver_factory=FakeDriver,
        )
        second = installation.create_profile(
            self.root / "profile-b",
            self.root / "project-b",
            {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            session_id="session-b",
            driver_factory=FakeDriver,
        )
        first_entered = threading.Event()
        release_first = threading.Event()
        second_done = threading.Event()
        observed: dict[str, str | None] = {}
        original_home = os.environ.get("HERMES_HOME")

        def fake_runner(home, workspace, request, *, driver_factory):
            del workspace, driver_factory
            observed[request["session_id"]] = os.environ.get("HERMES_HOME")
            if request["session_id"] == "session-a":
                first_entered.set()
                self.assertTrue(release_first.wait(2))
            else:
                second_done.set()
            return {"session_id": request["session_id"], "home": str(home)}

        def run(adapter, message):
            adapter.run_turn(message)

        with patch("agent_runtime.hermes_session_runner.run_one_turn", side_effect=fake_runner):
            worker_a = threading.Thread(target=run, args=(first, "a"))
            worker_b = threading.Thread(target=run, args=(second, "b"))
            worker_a.start()
            self.assertTrue(first_entered.wait(2))
            worker_b.start()
            time.sleep(0.1)
            self.assertFalse(second_done.is_set())
            release_first.set()
            worker_a.join(2)
            worker_b.join(2)
        self.assertEqual(str(first.profile.profile_root / "session"), observed["session-a"])
        self.assertEqual(str(second.profile.profile_root / "session"), observed["session-b"])
        self.assertEqual(original_home, os.environ.get("HERMES_HOME"))

    def test_restart_waits_for_active_turn_and_cannot_publish_ready_during_it(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(
            self.profile_root, self.project_root,
            {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            driver_factory=FakeDriver,
        )
        entered = threading.Event()
        release = threading.Event()
        restart_done = threading.Event()

        def blocked_runner(*args, **kwargs):
            del args, kwargs
            entered.set()
            self.assertTrue(release.wait(2))
            return {"session_id": "attended-session", "message": "turn", "mode": "attended"}

        with patch("agent_runtime.hermes_session_runner.run_one_turn", side_effect=blocked_runner) as runner:
            turn = threading.Thread(target=adapter.run_turn, args=("turn",))
            turn.start()
            self.assertTrue(entered.wait(2))
            restart = threading.Thread(target=lambda: (adapter.restart(), restart_done.set()))
            restart.start()
            time.sleep(0.05)
            self.assertFalse(restart_done.is_set())
            self.assertEqual("ready", json.loads((self.profile_root / "startup.json").read_text())["state"])
            release.set()
            turn.join(2)
            restart.join(2)
        self.assertTrue(restart_done.is_set())
        self.assertEqual(2, json.loads((self.profile_root / "startup.json").read_text())["generation"])
        self.assertEqual(1, runner.call_count)

    def test_profile_edit_at_final_launch_seam_prevents_driver(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"}
        adapter = installation.create_profile(self.profile_root, self.project_root, provider, driver_factory=FakeDriver)
        original_validate = adapter._validated_persisted_provider
        calls = 0

        def validate_with_final_seam_edit():
            nonlocal calls
            calls += 1
            if calls == 3:
                persisted = json.loads((self.profile_root / "profile.json").read_text())
                persisted["provider"] = {**persisted["provider"], "model": "tampered"}
                (self.profile_root / "profile.json").write_text(json.dumps(persisted))
            return original_validate()

        with patch.object(adapter, "_validated_persisted_provider", side_effect=validate_with_final_seam_edit):
            with self.assertRaisesRegex(HermesCompatibilityError, "provider configuration changed"):
                adapter.run_turn("must not launch")
        self.assertEqual([], FakeDriver.calls)

    def test_restart_mutation_before_ready_write_leaves_starting_and_no_ready(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"}
        adapter = installation.create_profile(self.profile_root, self.project_root, provider, driver_factory=FakeDriver)
        original_validate_profile = installation._validate_profile

        def mutate_after_validation(profile, binding):
            original_validate_profile(profile, binding)
            persisted = json.loads((self.profile_root / "profile.json").read_text())
            persisted["provider"] = {**persisted["provider"], "model": "tampered"}
            (self.profile_root / "profile.json").write_text(json.dumps(persisted))

        with patch.object(installation, "_validate_profile", side_effect=mutate_after_validation):
            with self.assertRaisesRegex(HermesCompatibilityError, "provider configuration changed"):
                adapter.restart()
        self.assertEqual("starting", json.loads((self.profile_root / "startup.json").read_text())["state"])
        self.assertEqual([], FakeDriver.calls)

    def test_profile_isolated_from_managed_roots_and_management_storage_are_optional(self):
        installation = stage_installation(self.stage_root, self.manifest)
        with self.assertRaises(ValueError):
            installation.create_profile(
                self.root / "managed" / "profile",
                self.root / "project",
                {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
                managed_roots=(self.root / "managed",),
                driver_factory=FakeDriver,
            )
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            driver_factory=FakeDriver,
        )
        self.assertEqual("absent", adapter.profile.management_status)
        self.assertEqual("absent", adapter.profile.storage_status)
        self.assertNotEqual(adapter.profile.profile_root.resolve(), adapter.profile.project_root.resolve())

    def test_restart_reopens_local_profile_and_preserves_session_identity(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            session_id="persistent-session",
            driver_factory=FakeDriver,
        )
        adapter.run_turn("first")
        restarted = adapter.restart()
        result = restarted.run_turn("after restart")

        self.assertEqual("persistent-session", result["session_id"])
        self.assertEqual("persistent-session", json.loads((self.profile_root / "profile.json").read_text())["session_id"])
        self.assertEqual("ready", json.loads((self.profile_root / "startup.json").read_text())["state"])

    def test_reopening_interrupted_profile_does_not_clear_recovery_marker(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            driver_factory=FakeDriver,
        )
        (self.profile_root / "startup.json").write_text(json.dumps({"state": "starting", "generation": 2}))
        with self.assertRaisesRegex(ValueError, "interrupted startup"):
            installation.create_profile(
                self.profile_root,
                self.project_root,
                {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
                driver_factory=FakeDriver,
            ).restart()
        self.assertEqual("starting", json.loads((self.profile_root / "startup.json").read_text())["state"])
        self.assertEqual("attended", adapter.recover_interrupted_startup().profile.mode)

    def test_interrupted_restart_requires_explicit_recovery_then_reopens(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            driver_factory=FakeDriver,
        )
        (self.profile_root / "startup.json").write_text(json.dumps({"state": "starting", "generation": 2}))

        with self.assertRaisesRegex(ValueError, "interrupted startup"):
            adapter.restart()
        recovered = adapter.recover_interrupted_startup()
        self.assertEqual("ready", json.loads((self.profile_root / "startup.json").read_text())["state"])
        self.assertEqual("attended", recovered.profile.mode)

    def test_incompatible_pair_is_rejected_before_profile_creation(self):
        with self.assertRaisesRegex(HermesCompatibilityError, "incompatible Hermes/add-on pair"):
            stage_installation(self.stage_root, self.manifest, upstream_version="0.18.0")

    def test_requested_versions_are_validated_before_first_stage_write(self):
        for index, field in enumerate(("upstream_version", "addon_version")):
            with self.subTest(field=field):
                stage_root = self.root / f"invalid-requested-version-stage-{index}"
                with self.assertRaisesRegex(HermesCompatibilityError, "versions must be supported strings"):
                    stage_installation(
                        stage_root,
                        self.manifest,
                        **{field: "1.2.3-alpha..1"},
                    )
                self.assertFalse(stage_root.exists())

    def test_manifest_versions_follow_semver_2_boundary_grammar(self):
        # These examples come from the official SemVer 2.0.0 specification;
        # the final three exercise identifiers that begin with hyphens.
        official_valid_versions = (
            "0.0.0",
            "1.0.0-alpha",
            "1.0.0-alpha.1",
            "1.0.0-0.3.7",
            "1.0.0-x.7.z.92",
            "1.0.0-alpha+001",
            "1.0.0+20130313144700",
            "1.0.0-beta+exp.sha.5114f85",
            "1.0.0+21AF26D3----117B344092BD",
            "1.0.0-0A.is.legal",
            "1.0.0--alpha",
            "1.0.0-x-y-z.--",
            "1.0.0+--",
        )
        official_invalid_versions = (
            "1",
            "1.0",
            "01.2.3",
            "1.02.3",
            "1.2.03",
            "1.2.3.4",
            "1.2.3-01",
            "1.2.3-0123",
            "1.2.3-alpha..1",
            "1.2.3-alpha.",
            "1.2.3-.alpha",
            "1.2.3-",
            "1.2.3+",
            "1.2.3+build..7",
            "1.2.3+build.",
            "1.2.3-alpha+",
            "1.2.3-alpha+build+meta",
            "1.2.3-+build",
            "1.2.3+build.7+meta",
            "1.2.3-01.2",
        )
        valid_versions = official_valid_versions + (
            "1.2.3",
            "1.2.3-alpha",
            "1.2.3-alpha.1",
            "1.2.3-0.3.7",
            "1.2.3-x.7.z.92",
            "1.2.3-alpha+build.7",
            "1.2.3+20130313144700",
            "1.2.3-beta+exp.sha.5114f85",
            "1.2.3-0A.is.legal",
            "1.2.3+-build",
        )
        invalid_versions = official_invalid_versions + (
            "1.2.3-alpha_beta",
            "1.2.3 alpha",
            " 1.2.3",
            "1.2.3 ",
            "1.2.3\n",
            None,
            {},
            [],
            123,
        )
        version_fields = (
            ("upstream", "version"),
            ("addon", "version"),
            ("compatibility", "upstream_version"),
            ("compatibility", "addon_version"),
        )

        for index, version in enumerate(valid_versions):
            with self.subTest(kind="valid", version=version):
                manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
                for owner, key in version_fields:
                    manifest[owner][key] = version
                manifest_path = self.root / f"valid-semver-{index}.json"
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

                installation = stage_installation(self.root / f"valid-semver-stage-{index}", manifest_path)

                self.assertEqual(version, installation.compatibility.upstream_version)
                self.assertEqual(version, installation.compatibility.addon_version)

        for index, version in enumerate(invalid_versions):
            with self.subTest(kind="invalid", version=version):
                manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
                for owner, key in version_fields:
                    manifest[owner][key] = version
                manifest_path = self.root / f"invalid-semver-{index}.json"
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
                stage_root = self.root / f"invalid-semver-stage-{index}"

                with self.assertRaisesRegex(HermesCompatibilityError, "versions must be supported strings"):
                    stage_installation(stage_root, manifest_path)
                self.assertFalse((stage_root / "manifest.json").exists())
                if stage_root.exists():
                    self.assertEqual([], list(stage_root.glob(".pending-*")))

    def test_malformed_manifest_versions_are_rejected_before_first_stage_write(self):
        cases = (
            ("upstream.version", "compatibility.upstream_version", None),
            ("addon.version", "compatibility.addon_version", None),
            ("upstream.version", "compatibility.upstream_version", {}),
            ("addon.version", "compatibility.addon_version", []),
            ("upstream.version", "compatibility.upstream_version", ""),
            ("addon.version", "compatibility.addon_version", "0.1"),
        )
        for index, (version_path, compatibility_path, value) in enumerate(cases):
            with self.subTest(version_path=version_path, value=value):
                manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
                version_owner, version_key = version_path.split(".")
                compatibility_owner, compatibility_key = compatibility_path.split(".")
                manifest[version_owner][version_key] = value
                manifest[compatibility_owner][compatibility_key] = value
                manifest_path = self.root / f"invalid-version-{index}.json"
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
                stage_root = self.root / f"invalid-version-stage-{index}"

                with self.assertRaisesRegex(HermesCompatibilityError, "versions must be supported strings"):
                    stage_installation(stage_root, manifest_path)
                self.assertFalse((stage_root / "manifest.json").exists())
                if stage_root.exists():
                    self.assertEqual([], list(stage_root.glob(".pending-*")))

    def test_malformed_manifest_version_replacement_preserves_valid_stage(self):
        stage_installation(self.stage_root, self.manifest)
        original = (self.stage_root / "manifest.json").read_bytes()
        cases = (
            ("upstream", "version", "compatibility", "upstream_version", None),
            ("addon", "version", "compatibility", "addon_version", {}),
            ("upstream", "version", "compatibility", "upstream_version", []),
            ("addon", "version", "compatibility", "addon_version", " "),
            ("upstream", "version", "compatibility", "upstream_version", "1.2.3-01"),
            ("addon", "version", "compatibility", "addon_version", "1.2.3-alpha..1"),
            ("upstream", "version", "compatibility", "upstream_version", "1.2.3+build..7"),
            ("addon", "version", "compatibility", "addon_version", "1.2.3+build+meta"),
        )
        for index, (owner, key, compatibility_owner, compatibility_key, value) in enumerate(cases):
            with self.subTest(owner=owner, key=key, value=value):
                manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
                manifest[owner][key] = value
                manifest[compatibility_owner][compatibility_key] = value
                manifest_path = self.root / f"invalid-version-replacement-{index}.json"
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

                with self.assertRaisesRegex(HermesCompatibilityError, "versions must be supported strings"):
                    stage_installation(self.stage_root, manifest_path)
                self.assertEqual(original, (self.stage_root / "manifest.json").read_bytes())
                self.assertEqual([], list(self.stage_root.glob(".pending-*")))

    def test_unsupported_hook_fails_clearly_without_source_patching(self):
        installation = stage_installation(self.stage_root, self.manifest)
        with self.assertRaisesRegex(HermesUnsupportedHookError, "unsupported Hermes hook"):
            installation.create_profile(
                self.profile_root,
                self.project_root,
                {"model": "m", "provider": "local", "base_url": "http://127.0.0.1:8080"},
                addon=IncompleteAddon(),
                driver_factory=FakeDriver,
            )

    def test_manifest_declared_unknown_hook_is_rejected_before_addon_invocation(self):
        manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
        manifest["addon"]["supported_extension_points"] = ["unknown"]
        manifest_path = self.root / "unknown-hook-manifest.json"
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

        with self.assertRaisesRegex(HermesUnsupportedHookError, "unsupported Hermes hook 'unknown'"):
            stage_installation(self.stage_root, manifest_path)
        self.assertFalse((self.stage_root / "manifest.json").exists())

    def test_falsey_custom_addon_is_retained_and_invoked(self):
        installation = stage_installation(self.stage_root, self.manifest)
        addon = FalseyAddon()

        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            addon=addon,
            driver_factory=FakeDriver,
        )

        self.assertIs(addon, adapter.addon)
        self.assertEqual("attended", addon.profile_calls[0]["mode"])

    def test_mixed_hook_declaration_is_rejected_as_unsupported_before_profile_write(self):
        installation = stage_installation(self.stage_root, self.manifest)
        with self.assertRaisesRegex(HermesUnsupportedHookError, "hook declaration"):
            installation.create_profile(
                self.profile_root,
                self.project_root,
                {"model": "model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
                addon=MixedHookAddon(),
                driver_factory=FakeDriver,
            )
        self.assertFalse((self.profile_root / "profile.json").exists())

    def test_unhashable_hook_declaration_is_rejected_as_unsupported_before_profile_write(self):
        installation = stage_installation(self.stage_root, self.manifest)
        with self.assertRaisesRegex(HermesUnsupportedHookError, "hook declaration"):
            installation.create_profile(
                self.profile_root,
                self.project_root,
                {"model": "model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
                addon=UnhashableHookAddon(),
                driver_factory=FakeDriver,
            )
        self.assertFalse((self.profile_root / "profile.json").exists())

    def test_partial_manifest_hook_declaration_is_rejected_before_profile_write_or_invocation(self):
        manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
        manifest["addon"]["supported_extension_points"] = ["attended_profile"]
        manifest_path = self.root / "partial-hook-manifest.json"
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

        with self.assertRaisesRegex(HermesUnsupportedHookError, "before_local_turn|local_turn"):
            stage_installation(self.stage_root, manifest_path)
        self.assertFalse((self.stage_root / "manifest.json").exists())
        self.assertFalse(self.profile_root.exists())

    def test_manifest_hook_shape_errors_are_staging_validation_errors(self):
        for hooks in (
            ["attended_profile", ["local_turn"]],
            ["attended_profile", False],
            ["attended_profile", None],
            False,
            None,
            "local_turn",
        ):
            with self.subTest(hooks=hooks):
                manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
                manifest["addon"]["supported_extension_points"] = hooks
                manifest_path = self.root / f"bad-manifest-{len(list(self.root.iterdir()))}.json"
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
                with self.assertRaisesRegex(HermesCompatibilityError, "staged Hermes add-on hooks are invalid"):
                    stage_installation(self.root / f"stage-{len(list(self.root.iterdir()))}", manifest_path)

    def test_available_hook_shape_errors_are_unsupported_hook_errors(self):
        installation = stage_installation(self.stage_root, self.manifest)
        for available_hooks in (
            [["attended_profile"]],
            [False],
            [None],
            False,
            0,
            "attended_profile",
        ):
            with self.subTest(available_hooks=available_hooks):
                with self.assertRaisesRegex(HermesUnsupportedHookError, "available Hermes hooks"):
                    installation.validate_compatibility(available_hooks=available_hooks)
                with self.assertRaisesRegex(HermesUnsupportedHookError, "available Hermes hooks"):
                    stage_installation(self.root / f"bad-available-stage-{len(list(self.root.iterdir()))}", self.manifest, available_hooks=available_hooks)

    def test_stage_rejects_incomplete_or_invalid_hook_contract_before_manifest_write(self):
        cases = (
            ([], HermesUnsupportedHookError),
            (["attended_profile"], HermesUnsupportedHookError),
            (["unknown"], HermesUnsupportedHookError),
            (["attended_profile", "unknown"], HermesUnsupportedHookError),
            (["attended_profile", ["local_turn"]], HermesCompatibilityError),
            (["attended_profile", False], HermesCompatibilityError),
            (["attended_profile", None], HermesCompatibilityError),
            (False, HermesCompatibilityError),
            (None, HermesCompatibilityError),
            ("local_turn", HermesCompatibilityError),
        )
        for index, (hooks, error_type) in enumerate(cases):
            with self.subTest(hooks=hooks):
                manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
                manifest["addon"]["supported_extension_points"] = hooks
                manifest_path = self.root / f"invalid-hooks-{index}.json"
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
                stage_root = self.root / f"invalid-stage-{index}"

                with self.assertRaises(error_type):
                    stage_installation(stage_root, manifest_path)
                self.assertFalse((stage_root / "manifest.json").exists())

    def test_stage_rejects_invalid_hook_replacement_without_clobbering_manifest(self):
        stage_installation(self.stage_root, self.manifest)
        original = (self.stage_root / "manifest.json").read_bytes()
        manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
        manifest["addon"]["supported_extension_points"] = ["attended_profile", "unknown"]
        manifest_path = self.root / "invalid-replacement.json"
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

        with self.assertRaisesRegex(HermesUnsupportedHookError, "unsupported Hermes hook"):
            stage_installation(self.stage_root, manifest_path)

        self.assertEqual(original, (self.stage_root / "manifest.json").read_bytes())
        self.assertEqual([], list(self.stage_root.glob(".pending-*")))

    def test_stage_replaces_manifest_atomically_for_complete_hook_contract(self):
        stage_installation(self.stage_root, self.manifest)
        replacement = json.loads(self.manifest.read_text(encoding="utf-8"))
        replacement["addon"]["version"] = "0.2.0"
        replacement["compatibility"]["addon_version"] = "0.2.0"
        replacement_path = self.root / "replacement.json"
        replacement_path.write_text(json.dumps(replacement), encoding="utf-8")

        installation = stage_installation(self.stage_root, replacement_path)

        staged = json.loads((self.stage_root / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(replacement, staged)
        self.assertEqual("0.2.0", installation.compatibility.addon_version)
        self.assertEqual([], list(self.stage_root.glob(".pending-*")))
        adapter = installation.create_profile(
            self.profile_root,
            self.project_root,
            {"model": "model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            addon=RecordingAddon(),
            driver_factory=FakeDriver,
        )
        self.assertEqual("attended", adapter.profile.mode)

    def test_unc_profile_or_project_roots_are_rejected_before_local_state_write(self):
        installation = stage_installation(self.stage_root, self.manifest)
        provider = {"model": "model", "provider": "local", "base_url": "http://127.0.0.1:8080"}
        with self.assertRaisesRegex(ValueError, "local"):
            installation.create_profile(
                r"\\server\share\profile",
                self.project_root,
                provider,
                driver_factory=FakeDriver,
            )
        with self.assertRaisesRegex(ValueError, "local"):
            installation.create_profile(
                self.profile_root,
                r"\\server\share\project",
                provider,
                driver_factory=FakeDriver,
            )
        self.assertFalse((self.profile_root / "profile.json").exists())

    def test_profile_root_replacement_is_rejected_after_adapter_creation(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(
            self.profile_root, self.project_root,
            {"model": "model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            driver_factory=FakeDriver,
        )
        original = self.root / "profile-original"
        os.rename(self.profile_root, original)
        self.profile_root.mkdir()
        with self.assertRaisesRegex(HermesCompatibilityError, "profile root was replaced"):
            adapter.status()

    def test_profile_root_symlink_replacement_is_rejected_before_lock_or_read(self):
        installation = stage_installation(self.stage_root, self.manifest)
        adapter = installation.create_profile(
            self.profile_root, self.project_root,
            {"model": "model", "provider": "local", "base_url": "http://127.0.0.1:8080"},
            driver_factory=FakeDriver,
        )
        original = self.root / "profile-original"
        os.rename(self.profile_root, original)
        try:
            os.symlink(original, self.profile_root, target_is_directory=True)
        except (OSError, NotImplementedError) as error:
            os.rename(original, self.profile_root)
            self.skipTest(f"symlink creation unavailable: {error}")
        with self.assertRaisesRegex(HermesCompatibilityError, "profile root was replaced"):
            adapter.restart()


if __name__ == "__main__":
    unittest.main()
