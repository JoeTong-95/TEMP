"""Staged attended Hermes release and out-of-tree integration boundary."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import re
import stat
import tempfile
import threading
import contextlib
from contextlib import contextmanager
import time
from typing import Any, Mapping


class HermesCompatibilityError(ValueError):
    pass


class HermesUnsupportedHookError(ValueError):
    pass


_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_SEMVER_CORE_IDENTIFIER = re.compile(r"(?:0|[1-9][0-9]*)")
_SEMVER_IDENTIFIER = re.compile(r"[0-9A-Za-z-]+")
_STAGE_MANIFEST_SCHEMA = "agent-stack.attended-hermes-stage"
_REQUIRED_ADDON_HOOKS = {
    "attended_profile": "configure_attended_profile",
    "local_turn": "before_local_turn",
}
_ENVIRONMENT_LOCK = threading.RLock()
_PROFILE_LOCKS: dict[tuple[str, int], tuple["_ProfileProcessLock", int]] = {}
_PROFILE_LOCKS_GUARD = threading.RLock()
_MAX_AUTHORITY_BYTES = 256 * 1024


def _is_reparse_point(path: Path) -> bool:
    try:
        return bool(getattr(os.lstat(path), "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    except FileNotFoundError:
        return False
    except OSError:
        return True


def _unsafe_path_boundary(path: Path) -> bool:
    return (path.is_symlink() or _is_reparse_point(path)
            or any(parent.is_symlink() or _is_reparse_point(parent)
                   for parent in path.parents))


def _lock_key(path: Path) -> tuple[str, int]:
    return (os.path.normcase(os.path.abspath(os.fspath(path))), threading.get_ident())


def _windows_native_api():
    import ctypes

    kernel32 = ctypes.windll.kernel32
    kernel32.CreateFileW.restype = ctypes.c_void_p
    kernel32.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_void_p]
    kernel32.GetFinalPathNameByHandleW.restype = ctypes.c_uint32
    kernel32.GetFinalPathNameByHandleW.argtypes = [ctypes.c_void_p,
        ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32]
    kernel32.GetFileInformationByHandleEx.restype = ctypes.c_int
    kernel32.GetFileInformationByHandleEx.argtypes = [ctypes.c_void_p,
        ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    return ctypes, kernel32


def _windows_handle_path(handle: int, ctypes: Any, kernel32: Any) -> str:
    size = 256
    while size <= 32768:
        buffer = ctypes.create_unicode_buffer(size)
        length = kernel32.GetFinalPathNameByHandleW(handle, buffer, size, 0)
        if length == 0:
            raise OSError(ctypes.get_last_error(), "GetFinalPathNameByHandleW failed")
        if length < size:
            return os.path.normcase(buffer.value.rstrip("\\"))
        size *= 2
    raise HermesCompatibilityError("attended Hermes authority path is too long")


def _windows_handle_is_reparse(handle: int, ctypes: Any, kernel32: Any) -> bool:
    # FILE_BASIC_INFO (GetFileInformationByHandleEx class 0).
    class _FileBasicInfo(ctypes.Structure):
        _fields_ = [("CreationTime", ctypes.c_int64),
                    ("LastAccessTime", ctypes.c_int64),
                    ("LastWriteTime", ctypes.c_int64),
                    ("ChangeTime", ctypes.c_int64),
                    ("FileAttributes", ctypes.c_uint32)]

    assert ctypes.sizeof(_FileBasicInfo) == 40
    assert _FileBasicInfo.FileAttributes.offset == 32
    basic = _FileBasicInfo()
    if not kernel32.GetFileInformationByHandleEx(
            handle, 0, ctypes.byref(basic), ctypes.sizeof(basic)):
        raise OSError(ctypes.get_last_error(), "GetFileInformationByHandleEx failed")
    return bool(basic.FileAttributes & 0x400)


def _windows_handle_identity(handle: int, ctypes: Any, kernel32: Any) -> tuple[int, int, int]:
    """Return the native volume/file identity for an open Windows handle."""
    class _FileTime(ctypes.Structure):
        _fields_ = [("dwLowDateTime", ctypes.c_uint32),
                    ("dwHighDateTime", ctypes.c_uint32)]

    class _ByHandleFileInformation(ctypes.Structure):
        _fields_ = [
            ("dwFileAttributes", ctypes.c_uint32),
            ("ftCreationTime", _FileTime),
            ("ftLastAccessTime", _FileTime),
            ("ftLastWriteTime", _FileTime),
            ("dwVolumeSerialNumber", ctypes.c_uint32),
            ("nFileSizeHigh", ctypes.c_uint32),
            ("nFileSizeLow", ctypes.c_uint32),
            ("nNumberOfLinks", ctypes.c_uint32),
            ("nFileIndexHigh", ctypes.c_uint32),
            ("nFileIndexLow", ctypes.c_uint32),
        ]
    assert ctypes.sizeof(_ByHandleFileInformation) == 52
    assert _ByHandleFileInformation.dwVolumeSerialNumber.offset == 28
    assert _ByHandleFileInformation.nFileIndexHigh.offset == 44
    assert _ByHandleFileInformation.nFileIndexLow.offset == 48
    info = _ByHandleFileInformation()
    kernel32.GetFileInformationByHandle.restype = ctypes.c_int
    kernel32.GetFileInformationByHandle.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    if not kernel32.GetFileInformationByHandle(handle, ctypes.byref(info)):
        raise OSError(ctypes.get_last_error(), "GetFileInformationByHandle failed")
    return (info.dwVolumeSerialNumber, info.nFileIndexHigh, info.nFileIndexLow)


def _windows_open_parent(path: Path) -> tuple[int, Any, Any, str]:
    """Open every Windows ancestor as a non-reparse handle.

    ``FILE_FLAG_OPEN_REPARSE_POINT`` applies only to the final component.
    Walking the lexical chain and comparing each handle's canonical parent
    makes a junction replacement fail closed before an authority is opened.
    """
    ctypes, kernel32 = _windows_native_api()
    # Directory custody only needs metadata and reparse-point inspection.  Do
    # not request directory READ_DATA: ordinary user-profile ancestors may
    # permit metadata/traversal while denying GENERIC_READ.
    FILE_READ_ATTRIBUTES = 0x00000080
    FILE_SHARE_READ, FILE_SHARE_WRITE, FILE_SHARE_DELETE = 1, 2, 4
    OPEN_EXISTING = 3
    FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
    FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000
    parts = Path(path).parts
    if not parts or not Path(path).is_absolute():
        raise HermesCompatibilityError("attended Hermes authority path must be absolute")
    current = None
    handle = None
    previous_handle = None
    previous_path = None
    try:
        for index, component in enumerate(parts):
            current = Path(component) if index == 0 else current / component
            handle = kernel32.CreateFileW(
                os.fspath(current), FILE_READ_ATTRIBUTES,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, None,
                OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, None)
            invalid = ctypes.c_void_p(-1).value
            if handle in (None, invalid):
                # Some profile roots deny native metadata handles even though
                # their descendants are traversable.  Keep the lexical anchor;
                # the next native handle's canonical parent must still match it,
                # and the final authority parent remains pinned natively.
                if index < len(parts) - 1 and kernel32.GetLastError() == 5:
                    previous_path = os.path.normcase(
                        "\\\\?\\" + os.path.abspath(os.fspath(current)))
                    if previous_handle is not None:
                        kernel32.CloseHandle(previous_handle)
                        previous_handle = None
                    continue
                handle = None
                raise OSError(ctypes.get_last_error(), "CreateFileW directory failed")
            if _windows_handle_is_reparse(handle, ctypes, kernel32):
                raise HermesCompatibilityError("attended Hermes authority contains a reparse component")
            canonical = _windows_handle_path(handle, ctypes, kernel32)
            if previous_handle is not None:
                expected_parent = canonical.rsplit("\\", 1)[0]
                if expected_parent != previous_path:
                    raise HermesCompatibilityError("attended Hermes authority parent was replaced")
                kernel32.CloseHandle(previous_handle)
            previous_handle, previous_path = handle, canonical
            handle = None
        if previous_handle is None:
            raise HermesCompatibilityError("attended Hermes authority parent is unavailable")
        return previous_handle, ctypes, kernel32, previous_path
    except BaseException:
        if handle is not None:
            kernel32.CloseHandle(handle)
        if previous_handle is not None:
            kernel32.CloseHandle(previous_handle)
        raise


def _regular_nofollow_open(path: Path, flags: int) -> int:
    """Open a profile authority without following links, then verify identity."""
    try:
        # lstat is the portable preflight on Windows, where O_NOFOLLOW may be
        # unavailable; fstat below closes the remaining replacement window.
        if path.exists() or path.is_symlink():
            existing = os.lstat(path)
            if not stat.S_ISREG(existing.st_mode):
                raise HermesCompatibilityError("attended Hermes authority is not a regular file")
        nofollow = getattr(os, "O_NOFOLLOW", 0)
        # Open the parent as a directory and resolve the final component
        # relative to that descriptor where supported.  This closes the
        # parent-replacement window for profile authorities and lock files.
        if os.name == "posix" and hasattr(os, "O_DIRECTORY") and hasattr(os, "O_NOFOLLOW"):
            parent_fd = _open_posix_directory_chain(path.parent)
            try:
                fd = os.open(path.name, flags | nofollow, dir_fd=parent_fd)
            finally:
                os.close(parent_fd)
        elif os.name == "nt":
            # O_NOFOLLOW is not implemented by the Windows CRT.  Open the
            # final component with the native reparse-point flag instead; the
            # resulting handle refers to the object selected by this open and
            # cannot be redirected by a junction/symlink swap afterwards.
            import ctypes
            import msvcrt
            parent_handle, ctypes, kernel32, parent_path = _windows_open_parent(path.parent)
            GENERIC_READ, GENERIC_WRITE = 0x80000000, 0x40000000
            FILE_SHARE_READ, FILE_SHARE_WRITE, FILE_SHARE_DELETE = 1, 2, 4
            OPEN_EXISTING, OPEN_ALWAYS = 3, 4
            FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000
            access = GENERIC_READ | (GENERIC_WRITE if flags & (os.O_WRONLY | os.O_RDWR) else 0)
            disposition = OPEN_ALWAYS if flags & os.O_CREAT else OPEN_EXISTING
            child_handle = None
            try:
                parent_identity = _windows_handle_identity(parent_handle, ctypes, kernel32)
                handle = kernel32.CreateFileW(os.fspath(path), access,
                    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, None,
                    disposition, FILE_FLAG_OPEN_REPARSE_POINT, None)
                if handle in (None, ctypes.c_void_p(-1).value):
                    raise OSError(ctypes.get_last_error(), "CreateFileW failed")
                child_handle = handle
                child_path = _windows_handle_path(handle, ctypes, kernel32)
                actual_parent_handle, _, _, _ = _windows_open_parent(Path(child_path).parent)
                try:
                    actual_parent_identity = _windows_handle_identity(actual_parent_handle, ctypes, kernel32)
                finally:
                    kernel32.CloseHandle(actual_parent_handle)
                if (child_path.rsplit("\\", 1)[0] != parent_path
                        or actual_parent_identity != parent_identity):
                    kernel32.CloseHandle(handle)
                    child_handle = None
                    raise HermesCompatibilityError("attended Hermes authority parent was replaced")
            except BaseException:
                if child_handle is not None:
                    kernel32.CloseHandle(child_handle)
                raise
            finally:
                kernel32.CloseHandle(parent_handle)
            try:
                # open_osfhandle's flags describe the CRT descriptor, not the
                # access requested from CreateFileW.  Omitting the access mode
                # makes a GENERIC_READ handle appear writable (and vice versa)
                # to fdopen/locking, which breaks the lifecycle lock and can
                # turn read-only authority opens into invalid descriptors.
                access_mode = flags & getattr(os, "O_ACCMODE", 3)
                if access_mode == os.O_RDWR:
                    crt_flags = os.O_RDWR
                elif access_mode == os.O_WRONLY:
                    crt_flags = os.O_WRONLY
                else:
                    crt_flags = os.O_RDONLY
                fd = msvcrt.open_osfhandle(int(handle), crt_flags | os.O_BINARY)
            except BaseException:
                kernel32.CloseHandle(handle)
                raise
        else:
            raise HermesCompatibilityError("attended Hermes authority requires a reparse-resistant native handle")
    except OSError as error:
        raise HermesCompatibilityError("attended Hermes authority is unreadable") from error
    try:
        file_stat = os.fstat(fd)
        if not stat.S_ISREG(file_stat.st_mode):
            raise HermesCompatibilityError("attended Hermes authority is not a regular file")
        # Windows exposes reparse status through st_file_attributes.
        attrs = getattr(file_stat, "st_file_attributes", 0)
        if attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            raise HermesCompatibilityError("attended Hermes authority is a reparse point")
        try:
            current = os.lstat(path)
        except OSError as error:
            raise HermesCompatibilityError("attended Hermes authority was replaced during open") from error
        if (current.st_dev, current.st_ino) != (file_stat.st_dev, file_stat.st_ino):
            raise HermesCompatibilityError("attended Hermes authority was replaced during open")
        return fd
    except BaseException:
        os.close(fd)
        raise


def _safe_read_bytes(path: Path, *, limit: int = _MAX_AUTHORITY_BYTES) -> bytes:
    fd = _regular_nofollow_open(path, os.O_RDONLY)
    try:
        before = os.fstat(fd)
        chunks: list[bytes] = []
        total = 0
        while True:
            chunk = os.read(fd, min(65536, limit + 1 - total))
            if not chunk:
                break
            chunks.append(chunk); total += len(chunk)
            if total > limit:
                raise HermesCompatibilityError("attended Hermes authority exceeds size limit")
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise HermesCompatibilityError("attended Hermes authority was replaced during read")
        try:
            current = os.lstat(path)
        except OSError as error:
            raise HermesCompatibilityError("attended Hermes authority was replaced during read") from error
        if (current.st_dev, current.st_ino) != (after.st_dev, after.st_ino):
            raise HermesCompatibilityError("attended Hermes authority was replaced during read")
        return b"".join(chunks)
    finally:
        os.close(fd)


def _safe_snapshot(path: Path) -> tuple[bytes, os.stat_result]:
    fd = _regular_nofollow_open(path, os.O_RDONLY)
    try:
        before = os.fstat(fd)
        raw = os.read(fd, _MAX_AUTHORITY_BYTES + 1)
        if len(raw) > _MAX_AUTHORITY_BYTES:
            raise HermesCompatibilityError("attended Hermes authority exceeds size limit")
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise HermesCompatibilityError("attended Hermes authority was replaced during read")
        try:
            current = os.lstat(path)
        except OSError as error:
            raise HermesCompatibilityError("attended Hermes authority was replaced during read") from error
        if (current.st_dev, current.st_ino) != (after.st_dev, after.st_ino):
            raise HermesCompatibilityError("attended Hermes authority was replaced during read")
        return raw, after
    finally:
        os.close(fd)


def _safe_json(path: Path, label: str) -> Any:
    try:
        return json.loads(_safe_read_bytes(path).decode("utf-8"))
    except HermesCompatibilityError:
        raise
    except (OSError, UnicodeError, ValueError, TypeError) as error:
        raise HermesCompatibilityError(f"{label} is unreadable") from error


def _open_posix_directory_chain(path: Path) -> int:
    """Open every ancestor with O_NOFOLLOW, returning a pinned leaf fd."""
    if not path.is_absolute():
        raise HermesCompatibilityError("attended Hermes authority path must be absolute")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    current = os.open(os.sep, flags)
    try:
        for component in path.parts[1:]:
            if not component:
                continue
            try:
                os.mkdir(component, 0o700, dir_fd=current)
            except FileExistsError:
                pass
            next_fd = os.open(component, flags, dir_fd=current)
            os.close(current)
            current = next_fd
        return current
    except BaseException:
        os.close(current)
        raise


class _ProfileProcessLock:
    """Durable, profile-scoped exclusion across lifecycle processes."""

    def __init__(self, path: Path, *, timeout: float = 5.0) -> None:
        self.path, self.timeout = path, timeout
        self._handle = None

    def __enter__(self):
        key = _lock_key(self.path)
        with _PROFILE_LOCKS_GUARD:
            held = _PROFILE_LOCKS.get(key)
            if held is not None:
                owner, count = held
                owner._nested += 1
                _PROFILE_LOCKS[key] = (owner, count + 1)
                self._owner = owner
                return self
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._fd = _regular_nofollow_open(self.path, os.O_RDWR | os.O_CREAT)
        except HermesCompatibilityError as error:
            # A missing lock is created atomically; a preplanted link/non-file
            # is rejected by the no-follow open above.
            raise error
        self._handle = os.fdopen(self._fd, "a+b", closefd=True)
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                if os.name == "nt":
                    import msvcrt
                    self._handle.seek(0)
                    msvcrt.locking(self._handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self._handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._owner = self
                self._nested = 1
                with _PROFILE_LOCKS_GUARD:
                    _PROFILE_LOCKS[key] = (self, 1)
                return self
            except (OSError, BlockingIOError):
                if time.monotonic() >= deadline:
                    self._handle.close(); self._handle = None
                    raise HermesCompatibilityError("attended Hermes lifecycle lock is busy")
                time.sleep(0.01)

    def __exit__(self, *_exc):
        owner = getattr(self, "_owner", self)
        if owner is not self:
            key = _lock_key(self.path)
            with _PROFILE_LOCKS_GUARD:
                owner._nested -= 1
                if owner._nested == 0:
                    _PROFILE_LOCKS.pop(key, None)
            return
        if self._handle is None:
            return
        try:
            if os.name == "nt":
                import msvcrt
                self._handle.seek(0)
                msvcrt.locking(self._handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
        finally:
            self._handle.close(); self._handle = None
            with _PROFILE_LOCKS_GUARD:
                _PROFILE_LOCKS.pop(_lock_key(self.path), None)


def _reject_network_path(value: str | Path, label: str) -> None:
    """Reject UNC or remote-backed roots before any filesystem mutation."""
    raw = os.fspath(value)
    if isinstance(raw, bytes):
        raw = os.fsdecode(raw)
    windows_path = PureWindowsPath(str(raw))
    anchor = windows_path.anchor.lower()
    is_unc = anchor.startswith("\\\\") and not anchor.startswith("\\\\?\\")
    is_extended_unc = anchor.startswith("\\\\?\\unc\\")
    if is_unc or is_extended_unc:
        raise ValueError(f"{label} must be a local path; UNC/network-backed roots are not supported")
    if os.name == "nt" and windows_path.drive and not windows_path.drive.lower().startswith("\\\\?\\"):
        try:
            import ctypes

            drive_type = ctypes.windll.kernel32.GetDriveTypeW(f"{windows_path.drive}\\")
        except (AttributeError, OSError, TypeError):
            drive_type = 0
        if drive_type == 4:  # DRIVE_REMOTE
            raise ValueError(f"{label} must be a local path; UNC/network-backed roots are not supported")


def _local_path(value: str | Path, label: str) -> Path:
    path = Path(value)
    _reject_network_path(path, label)
    try:
        resolved = path.resolve(strict=False)
    except OSError as error:
        raise ValueError(f"{label} must be a local path") from error
    _reject_network_path(resolved, label)
    return path


def _manifest_hook_names(value: Any) -> frozenset[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item for item in value):
        raise HermesCompatibilityError("staged Hermes add-on hooks are invalid")
    return frozenset(value)


def _validate_manifest_hook_contract(value: Any) -> frozenset[str]:
    hook_names = _manifest_hook_names(value)
    supported_hooks = frozenset(_REQUIRED_ADDON_HOOKS)
    unsupported = hook_names - supported_hooks
    if unsupported:
        raise HermesUnsupportedHookError(
            f"unsupported Hermes hook {sorted(unsupported)[0]!r}; source patching is not supported"
        )
    missing = supported_hooks - hook_names
    if missing:
        hook_name = sorted(missing)[0]
        method_name = _REQUIRED_ADDON_HOOKS[hook_name]
        raise HermesUnsupportedHookError(
            f"staged Hermes manifest must declare hook {hook_name!r} ({method_name}); source patching is not supported"
        )
    return hook_names


def _available_hook_names(value: Any) -> frozenset[str]:
    if not isinstance(value, (tuple, list, set, frozenset)):
        raise HermesUnsupportedHookError("available Hermes hooks must be a collection of non-empty names")
    if any(not isinstance(item, str) or not item for item in value):
        raise HermesUnsupportedHookError("available Hermes hooks must be a collection of non-empty names")
    return frozenset(value)


def _valid_semver(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    core_and_prerelease, plus, build = value.partition("+")
    if plus and not _valid_semver_identifiers(build, reject_numeric_leading_zero=False):
        return False
    core, hyphen, prerelease = core_and_prerelease.partition("-")
    if hyphen and not _valid_semver_identifiers(prerelease, reject_numeric_leading_zero=True):
        return False
    core_parts = core.split(".")
    return len(core_parts) == 3 and all(
        _SEMVER_CORE_IDENTIFIER.fullmatch(part) is not None for part in core_parts
    )


def _valid_semver_identifiers(value: str, *, reject_numeric_leading_zero: bool) -> bool:
    identifiers = value.split(".")
    if any(_SEMVER_IDENTIFIER.fullmatch(identifier) is None for identifier in identifiers):
        return False
    if reject_numeric_leading_zero and any(
        identifier.isdigit() and len(identifier) > 1 and identifier.startswith("0")
        for identifier in identifiers
    ):
        return False
    return True


def _supported_version(value: Any, field: str) -> str:
    if not _valid_semver(value):
        raise HermesCompatibilityError(
            f"staged Hermes manifest versions must be supported strings ({field} is invalid)"
        )
    return value


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    # Keep the parent directory descriptor open through create and replace on
    # POSIX.  A pathname-only check is insufficient: an attacker can swap a
    # parent for a symlink/junction between validation and rename.
    if os.name == "posix" and hasattr(os, "O_DIRECTORY") and hasattr(os, "O_NOFOLLOW"):
        parent_fd = _open_posix_directory_chain(path.parent)
        pending = None
        try:
            pending_name = f".{path.name}.{os.urandom(12).hex()}.pending"
            fd = os.open(pending_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=parent_fd)
            pending = pending_name
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(value, handle, sort_keys=True, indent=2)
                handle.write("\n"); handle.flush(); os.fsync(handle.fileno())
            os.replace(pending_name, path.name, src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
            os.fsync(parent_fd)
            pending = None
        finally:
            if pending is not None:
                with contextlib.suppress(OSError): os.unlink(pending, dir_fd=parent_fd)
            os.close(parent_fd)
        return
    # Windows has no dir_fd equivalent.  Keep this path deliberately narrow:
    # ordinary local directories/files are supported, while any observed
    # reparse component fails closed.  The final native read/open checks still
    # bind consumers to the object they opened; the pre/post checks prevent a
    # normal operation from silently accepting a link or junction.
    if os.name == "nt":
        if _unsafe_path_boundary(path.parent) or (path.exists() and _unsafe_path_boundary(path)):
            raise HermesCompatibilityError("attended Hermes authority contains a reparse component")
        path.parent.mkdir(parents=True, exist_ok=True)
        pending = path.with_name(f".{path.name}.{os.urandom(12).hex()}.pending")
        if _unsafe_path_boundary(path.parent):
            raise HermesCompatibilityError("attended Hermes authority contains a reparse component")
        parent_handle, ctypes, kernel32, parent_path = _windows_open_parent(path.parent)
        try:
            parent_identity = _windows_handle_identity(parent_handle, ctypes, kernel32)
            with pending.open("x", encoding="utf-8") as handle:
                json.dump(value, handle, sort_keys=True, indent=2)
                handle.write("\n"); handle.flush(); os.fsync(handle.fileno())
            # The pending create is pathname-based on Windows.  Verify that
            # the object selected by that pathname belongs to the native
            # parent pinned before creation, so an ordinary same-path swap is
            # rejected even when both directories are non-reparse points.
            pending_handle = kernel32.CreateFileW(
                os.fspath(pending), 0x80000000, 1 | 2 | 4, None, 3,
                0x00200000, None)
            invalid = ctypes.c_void_p(-1).value
            if pending_handle in (None, invalid):
                raise HermesCompatibilityError("attended Hermes authority staging file is unavailable")
            try:
                pending_path = Path(_windows_handle_path(pending_handle, ctypes, kernel32))
                actual_parent_handle, _, _, _ = _windows_open_parent(pending_path.parent)
                try:
                    actual_parent_identity = _windows_handle_identity(actual_parent_handle, ctypes, kernel32)
                finally:
                    kernel32.CloseHandle(actual_parent_handle)
            finally:
                kernel32.CloseHandle(pending_handle)
            if (actual_parent_identity != parent_identity
                    or os.path.normcase(os.fspath(pending_path.parent)) != parent_path):
                raise HermesCompatibilityError("attended Hermes authority parent was replaced")
            if _unsafe_path_boundary(path.parent) or _unsafe_path_boundary(pending):
                raise HermesCompatibilityError("attended Hermes authority contains a reparse component")
            _windows_replace_in_parent(path.parent, pending.name, path.name,
                                       expected_parent_identity=parent_identity)
            # Re-open through the native no-follow path to verify the result is
            # a regular, non-reparse authority before returning.
            fd = _regular_nofollow_open(path, os.O_RDONLY)
            os.close(fd)
        finally:
            with contextlib.suppress(OSError): pending.unlink()
            kernel32.CloseHandle(parent_handle)
        return
    raise HermesCompatibilityError("attended Hermes authority requires a reparse-resistant native handle")


def _windows_replace_in_parent(parent: Path, source_name: str, destination_name: str,
                               *, expected_parent_identity: tuple[int, int, int] | None = None) -> None:
    """Replace a file using a pinned Windows parent directory handle.

    A pathname ``os.replace`` can resolve a swapped junction between the
    boundary check and rename.  ``FILE_RENAME_INFO`` with ``RootDirectory``
    binds the rename to the directory handle opened by this operation.
    """
    if os.name != "nt":
        os.replace(parent / source_name, parent / destination_name)
        return
    import ctypes
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateFileW.restype = ctypes.c_void_p
    kernel32.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_void_p]
    # SetFileInformationByHandle advertises FILE_RENAME_INFO.RootDirectory,
    # but the Windows runtime on the supported local filesystem rejects that
    # relative form with ERROR_INVALID_PARAMETER.  NtSetInformationFile is the
    # documented kernel rename semantic for the same FILE_RENAME_INFORMATION
    # record and honors the pinned root handle.
    ntdll = ctypes.WinDLL("ntdll")
    ntdll.NtSetInformationFile.restype = ctypes.c_long
    ntdll.NtSetInformationFile.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    GENERIC_READ, GENERIC_WRITE, DELETE = 0x80000000, 0x40000000, 0x00010000
    FILE_SHARE_READ, FILE_SHARE_WRITE, FILE_SHARE_DELETE = 1, 2, 4
    OPEN_EXISTING = 3
    FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
    FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000
    INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
    parent_handle = kernel32.CreateFileW(
        os.fspath(parent), GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, None,
        OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, None)
    if parent_handle in (None, INVALID_HANDLE_VALUE):
        raise HermesCompatibilityError("attended Hermes authority parent is unavailable")
    source_handle = None
    actual_parent_handle = None
    try:
        parent_identity = _windows_handle_identity(parent_handle, ctypes, kernel32)
        if (expected_parent_identity is not None
                and parent_identity != expected_parent_identity):
            raise HermesCompatibilityError("attended Hermes authority parent was replaced")
        source_handle = kernel32.CreateFileW(
            os.fspath(parent / source_name), DELETE | GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, None,
            OPEN_EXISTING, FILE_FLAG_OPEN_REPARSE_POINT, None)
        if source_handle in (None, INVALID_HANDLE_VALUE):
            raise HermesCompatibilityError("attended Hermes authority staging file is unavailable")
        # The source open is pathname-based, so prove that it selected a file
        # in the same ordinary directory object pinned by parent_handle.  A
        # canonical path comparison is insufficient: an attacker can replace
        # an ordinary directory with another ordinary directory at the same
        # path while preserving the spelling.
        source_path = Path(_windows_handle_path(source_handle, ctypes, kernel32))
        actual_parent_handle, _, _, _ = _windows_open_parent(source_path.parent)
        if _windows_handle_identity(actual_parent_handle, ctypes, kernel32) != parent_identity:
            raise HermesCompatibilityError("attended Hermes authority parent was replaced")
        # FILE_RENAME_INFORMATION (FileRenameInformation class 10) supports a
        # root directory handle.  The trailing WCHAR is required by the NT
        # ABI even though FileNameLength excludes it; retain an aligned record
        # so short names do not produce STATUS_INFO_LENGTH_MISMATCH.
        target = destination_name.encode("utf-16-le")
        # FILE_RENAME_INFO has a flexible WCHAR FileName member.  Model the
        # fixed header explicitly so ctypes supplies the platform-correct
        # RootDirectory alignment and the API receives sizeof(header)+bytes.
        class _FileRenameInfo(ctypes.Structure):
            _fields_ = [
                ("replace_if_exists", ctypes.c_ubyte),
                ("root_directory", ctypes.c_void_p),
                ("file_name_length", ctypes.c_uint32),
                ("file_name", ctypes.c_uint16 * 1),
            ]
        name_offset = _FileRenameInfo.file_name.offset
        name_size = len(target) + ctypes.sizeof(ctypes.c_uint16)
        buffer_size = name_offset + name_size
        buffer = ctypes.create_string_buffer(buffer_size)
        ctypes.c_ubyte.from_buffer(buffer, _FileRenameInfo.replace_if_exists.offset).value = 1
        ctypes.c_void_p.from_buffer(buffer, _FileRenameInfo.root_directory.offset).value = int(parent_handle)
        ctypes.c_uint32.from_buffer(buffer, _FileRenameInfo.file_name_length.offset).value = len(target)
        ctypes.memmove(ctypes.addressof(buffer) + name_offset, target, len(target))
        class _IoStatusBlock(ctypes.Structure):
            _fields_ = [("status", ctypes.c_long), ("information", ctypes.c_size_t)]
        io_status = _IoStatusBlock()
        status = ntdll.NtSetInformationFile(
            source_handle, ctypes.byref(io_status), buffer, ctypes.sizeof(buffer), 10)
        if status != 0:
            # A pathname fallback would lose the pinned parent identity and
            # could follow a same-path ordinary-directory swap.  Fail closed
            # when handle-bound replacement is unavailable.
            raise HermesCompatibilityError(
                f"attended Hermes authority handle-bound replacement unavailable (NTSTATUS 0x{status & 0xffffffff:08x})")
    except OSError as error:
        raise HermesCompatibilityError("attended Hermes authority replacement failed") from error
    finally:
        if source_handle not in (None, INVALID_HANDLE_VALUE):
            kernel32.CloseHandle(source_handle)
        if actual_parent_handle not in (None, INVALID_HANDLE_VALUE):
            kernel32.CloseHandle(actual_parent_handle)
        kernel32.CloseHandle(parent_handle)


def _directory(value: str | Path, label: str, *, create: bool = False) -> Path:
    path = _local_path(value, label)
    if _unsafe_path_boundary(path):
        raise ValueError(f"{label} cannot contain symlink or reparse components")
    if create:
        path.mkdir(parents=True, exist_ok=True)
    if not path.exists() or not path.is_dir():
        raise ValueError(f"{label} must be a directory")
    if _unsafe_path_boundary(path):
        raise ValueError(f"{label} cannot contain symlink or reparse components")
    resolved = path.resolve()
    _reject_network_path(resolved, label)
    return resolved


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _profile_dict(profile: "AttendedProfile") -> dict[str, Any]:
    return {
        "profile_id": profile.profile_id,
        "session_id": profile.session_id,
        "mode": profile.mode,
        "profile_root": str(profile.profile_root),
        "project_root": str(profile.project_root),
        "management_status": profile.management_status,
        "storage_status": profile.storage_status,
        "workspace_toolset": profile.workspace_toolset,
    }


@dataclass(frozen=True)
class HermesCompatibility:
    upstream_version: str
    addon_version: str


@dataclass(frozen=True)
class AttendedProfile:
    profile_root: Path
    project_root: Path
    session_id: str
    profile_id: str
    mode: str = "attended"
    management_status: str = "absent"
    storage_status: str = "absent"
    workspace_toolset: str | None = None


class AttendedHermesAdapter:
    """The supported out-of-tree attended add-on seam.

    The add-on owns profile/bootstrap concerns while HermesSessionRunner owns
    the native loop.  Nothing here imports Management or Storage, so a local
    profile remains usable while those roles are unavailable.
    """

    def __init__(self, installation: "StagedHermesInstallation", profile: AttendedProfile, provider: Mapping[str, Any], *, addon: Any, driver_factory: Any):
        self.installation = installation
        self.profile = profile
        self.provider = dict(provider)
        self.addon = addon
        self.driver_factory = driver_factory
        # Pin the directory and every ancestor that forms its path.  This is
        # deliberately captured after profile creation/configuration: the
        # adapter must never silently follow a later directory replacement.
        self._profile_root_chain = self._capture_profile_root_chain()

    def _capture_profile_root_chain(self) -> tuple[tuple[str, int, int], ...]:
        chain: list[tuple[str, int, int]] = []
        current = self.profile.profile_root
        while True:
            try:
                info = os.lstat(current)
            except OSError as error:
                raise HermesCompatibilityError("attended profile root is unavailable") from error
            if not stat.S_ISDIR(info.st_mode) or _is_reparse_point(current):
                raise HermesCompatibilityError("attended profile root contains unsafe directory components")
            chain.append((os.path.normcase(os.path.abspath(os.fspath(current))), int(info.st_dev), int(info.st_ino)))
            parent = current.parent
            if parent == current:
                break
            current = parent
        return tuple(chain)

    def _assert_profile_root(self) -> None:
        """Revalidate the pinned root/ancestor identities before authority I/O."""
        for name, device, inode in self._profile_root_chain:
            current = Path(name)
            try:
                info = os.lstat(current)
            except OSError as error:
                raise HermesCompatibilityError("attended profile root was replaced") from error
            if (not stat.S_ISDIR(info.st_mode) or _is_reparse_point(current)
                    or (int(info.st_dev), int(info.st_ino)) != (device, inode)):
                raise HermesCompatibilityError("attended profile root was replaced")

    @property
    def _startup_path(self) -> Path:
        return self.profile.profile_root / "startup.json"

    @contextmanager
    def _lifecycle_authority(self):
        self._assert_profile_root()
        with _ProfileProcessLock(self.profile.profile_root / ".lifecycle.lock"):
            self._assert_profile_root()
            yield

    def _startup(self) -> dict[str, Any]:
        try:
            value = _safe_json(self._startup_path, "attended Hermes startup state")
        except HermesCompatibilityError:
            raise
        if not isinstance(value, dict) or value.get("state") not in {"ready", "starting"}:
            raise HermesCompatibilityError("attended Hermes startup state is invalid")
        return value

    def status(self) -> dict[str, Any]:
        """Return the public, non-secret status of this attended profile.

        The provider binding is persisted with the profile and validated again
        before its authentication mode is reported.  This keeps the mode
        observable without changing the historical ``run_turn`` result shape
        or exposing credentials.
        """
        with _ENVIRONMENT_LOCK, self._lifecycle_authority():
            startup = self._startup()
            provider = self._validated_persisted_provider()
            return {
                "state": startup["state"],
                "generation": startup.get("generation", 0),
                "auth_mode": _provider_auth_mode(provider),
            }

    @property
    def auth_mode(self) -> str:
        """The selected authentication mode at the adapter public boundary."""
        return self.status()["auth_mode"]

    def _profile_fingerprint(self) -> tuple[Any, ...]:
        path = self.profile.profile_root / "profile.json"
        try:
            raw, stat = _safe_snapshot(path)
        except HermesCompatibilityError:
            raise
        except OSError as error:
            raise HermesCompatibilityError("attended Hermes profile state is unreadable") from error
        return (getattr(stat, "st_dev", None), getattr(stat, "st_ino", None), hashlib.sha256(raw).hexdigest())

    def _assert_profile_fingerprint(self, expected: tuple[Any, ...]) -> None:
        if self._profile_fingerprint() != expected:
            raise HermesCompatibilityError("attended profile was replaced during lifecycle admission")

    def _validated_persisted_provider(self) -> Mapping[str, Any]:
        """Resolve the durable profile binding used by status and execution.

        The adapter may outlive a process restart or an operator editing its
        profile directory.  Never launch a driver from the constructor's
        snapshot: validate the complete persisted identity and require it to
        remain the same binding that this adapter was created for.
        """
        profile_path = self.profile.profile_root / "profile.json"
        record = _safe_json(profile_path, "attended Hermes profile state")
        if not isinstance(record, Mapping):
            raise HermesCompatibilityError("attended Hermes profile state is invalid")
        provider = record.get("provider")
        try:
            _validate_provider(provider)
        except (TypeError, ValueError) as error:
            raise HermesCompatibilityError("attended profile provider configuration is invalid") from error
        if (
            record.get("profile_id") != self.profile.profile_id
            or record.get("session_id") != self.profile.session_id
            or record.get("mode") != self.profile.mode
            or record.get("project_root") != str(self.profile.project_root)
            or record.get("profile_root") != str(self.profile.profile_root)
            or record.get("management_status") != self.profile.management_status
            or record.get("storage_status") != self.profile.storage_status
            or record.get("workspace_toolset") != self.profile.workspace_toolset
            or dict(provider) != self.provider
        ):
            raise HermesCompatibilityError("attended profile provider configuration changed")
        return provider

    def run_turn(self, message: str) -> Any:
        if not isinstance(message, str) or not message or len(message) > 16_000:
            raise ValueError("message must be non-empty and no more than 16000 characters")
        with _ENVIRONMENT_LOCK, self._lifecycle_authority():
            # Startup state and the persisted binding are one admission
            # boundary.  Holding this lock through the hook and runner also
            # makes restart/recovery unable to publish ready during a turn.
            state = self._startup()
            if state["state"] != "ready":
                raise HermesCompatibilityError("attended Hermes startup is interrupted; recover before starting a turn")
            provider = self._validated_persisted_provider()
            profile_fingerprint = self._profile_fingerprint()
            profile = _profile_dict(self.profile)
            hook = getattr(self.addon, "before_local_turn", None)
            if not callable(hook):
                raise HermesUnsupportedHookError("unsupported Hermes hook 'local_turn'; source patching is not supported")
            from agent_runtime.execution_profiles import STANDALONE_LOCAL_ATTENDED_PROFILE
            hook(profile, message)
            # The hook is extension code and may mutate the profile. Recheck
            # both durable authorities after it and immediately before launch.
            state = self._startup()
            if state["state"] != "ready":
                raise HermesCompatibilityError("attended Hermes startup changed; recover before starting a turn")
            provider = self._validated_persisted_provider()
            self._assert_profile_fingerprint(profile_fingerprint)
            request = {
                "session_id": self.profile.session_id,
                "identity": {
                    "mode": self.profile.mode,
                    "profile_id": self.profile.profile_id,
                    "project_root": str(self.profile.project_root),
                },
                "permissions": [self.profile.workspace_toolset] if self.profile.workspace_toolset else [],
                "binding": dict(provider),
                "message": message,
                "execution_profile": STANDALONE_LOCAL_ATTENDED_PROFILE,
                "max_iterations": 100,
                "max_tokens": 16_000,
            }
            previous = os.environ.get("HERMES_HOME")
            os.environ["HERMES_HOME"] = str(self.profile.profile_root / "session")
            try:
                from agent_runtime.hermes_session_runner import run_one_turn
                runner_kwargs = {} if self.driver_factory is None else {"driver_factory": self.driver_factory}
                # Keep the final authority check adjacent to launch; the
                # import/setup above must not create a window for tampering.
                state = self._startup()
                if state["state"] != "ready":
                    raise HermesCompatibilityError("attended Hermes startup changed; recover before starting a turn")
                provider = self._validated_persisted_provider()
                self._assert_profile_fingerprint(profile_fingerprint)
                request["binding"] = dict(provider)
                result = run_one_turn(
                    self.profile.profile_root / "session",
                    self.profile.project_root,
                    request,
                    **runner_kwargs,
                )
                # The adapter's historical standalone public result is kept
                # stable; auth mode is available through the driver's owned
                # status boundary rather than being leaked into this shape.
                if isinstance(result, Mapping):
                    result = {key: value for key, value in result.items() if key != "auth_mode"}
                return result
            finally:
                if previous is None:
                    os.environ.pop("HERMES_HOME", None)
                else:
                    os.environ["HERMES_HOME"] = previous

    def restart(self) -> "AttendedHermesAdapter":
        with _ENVIRONMENT_LOCK, self._lifecycle_authority():
            state = self._startup()
            if state["state"] == "starting":
                raise HermesCompatibilityError("attended Hermes restart found interrupted startup; recover explicitly")
            self.installation.validate_compatibility()
            self._validated_persisted_provider()
            generation = int(state.get("generation", 0)) + 1
            _atomic_json(self._startup_path, {"state": "starting", "generation": generation})
            # The staged profile has no external service dependency. Validation
            # completes the local restart and makes the ready boundary durable.
            profile_fingerprint = self._profile_fingerprint()
            provider = self._validated_persisted_provider()
            self.installation._validate_profile(self.profile, provider)
            self._validated_persisted_provider()
            self._assert_profile_fingerprint(profile_fingerprint)
            _atomic_json(self._startup_path, {"state": "ready", "generation": generation})
            return self

    def recover_interrupted_startup(self) -> "AttendedHermesAdapter":
        with _ENVIRONMENT_LOCK, self._lifecycle_authority():
            state = self._startup()
            if state["state"] != "starting":
                raise HermesCompatibilityError("attended Hermes startup is not interrupted")
            self.installation.validate_compatibility()
            profile_fingerprint = self._profile_fingerprint()
            provider = self._validated_persisted_provider()
            self.installation._validate_profile(self.profile, provider)
            self._validated_persisted_provider()
            self._assert_profile_fingerprint(profile_fingerprint)
            _atomic_json(self._startup_path, {"state": "ready", "generation": int(state.get("generation", 0))})
            return self


class StagedHermesInstallation:
    def __init__(self, stage_root: str | Path):
        self.stage_root = _directory(stage_root, "stage root")
        manifest_path = self.stage_root / "manifest.json"
        raw = _safe_json(manifest_path, "staged Hermes manifest")
        if not isinstance(raw, dict) or raw.get("schema") != _STAGE_MANIFEST_SCHEMA:
            raise HermesCompatibilityError("staged Hermes manifest schema is unsupported")
        upstream, addon, compatibility = raw.get("upstream"), raw.get("addon"), raw.get("compatibility")
        if not isinstance(upstream, dict) or not isinstance(addon, dict) or not isinstance(compatibility, dict):
            raise HermesCompatibilityError("staged Hermes manifest is incomplete")
        if compatibility.get("source_patching") is not False:
            raise HermesCompatibilityError("upstream source patching is not supported")
        upstream_version = _supported_version(upstream.get("version"), "upstream.version")
        addon_version = _supported_version(addon.get("version"), "addon.version")
        declared_upstream = _supported_version(compatibility.get("upstream_version"), "compatibility.upstream_version")
        declared_addon = _supported_version(compatibility.get("addon_version"), "compatibility.addon_version")
        if declared_upstream != upstream_version or declared_addon != addon_version:
            raise HermesCompatibilityError("staged Hermes manifest compatibility declaration is inconsistent")
        hooks = addon.get("supported_extension_points")
        hook_names = _manifest_hook_names(hooks)
        self.manifest = raw
        self.compatibility = HermesCompatibility(upstream_version, addon_version)
        self._addon_hooks = hook_names

    def validate_compatibility(self, *, upstream_version: str | None = None, addon_version: str | None = None, available_hooks: Any = None) -> None:
        expected_upstream = self.compatibility.upstream_version
        expected_addon = self.compatibility.addon_version
        observed_upstream = (
            _supported_version(upstream_version, "upstream_version")
            if upstream_version is not None
            else None
        )
        observed_addon = (
            _supported_version(addon_version, "addon_version")
            if addon_version is not None
            else None
        )
        if observed_upstream is not None and observed_upstream != expected_upstream:
            raise HermesCompatibilityError(f"incompatible Hermes/add-on pair: Hermes {upstream_version} requires {expected_upstream}")
        if observed_addon is not None and observed_addon != expected_addon:
            raise HermesCompatibilityError(f"incompatible Hermes/add-on pair: add-on {addon_version} requires {expected_addon}")
        if available_hooks is not None:
            missing = self._addon_hooks - _available_hook_names(available_hooks)
            if missing:
                raise HermesUnsupportedHookError(f"unsupported Hermes hook {sorted(missing)[0]!r}; source patching is not supported")

    def _validate_profile(self, profile: AttendedProfile, provider: Mapping[str, Any]) -> None:
        if profile.mode != "attended" or profile.management_status != "absent" or profile.storage_status != "absent":
            raise HermesCompatibilityError("staged profile is not an isolated attended profile")
        _validate_provider(provider)
        saved = _safe_json(profile.profile_root / "profile.json", "attended Hermes profile state")
        if saved.get("session_id") != profile.session_id or saved.get("project_root") != str(profile.project_root) or saved.get("provider") != dict(provider):
            raise HermesCompatibilityError("attended profile identity or project root changed")

    def create_profile(self, profile_root: str | Path, project_root: str | Path, provider: Mapping[str, Any], *, session_id: str = "attended-session", managed_roots: tuple[str | Path, ...] = (), workspace_toolset: str | None = None, addon: Any = None, driver_factory: Any = None) -> AttendedHermesAdapter:
        self.validate_compatibility()
        if not isinstance(session_id, str) or not _IDENTIFIER.fullmatch(session_id):
            raise ValueError("session_id is unsafe")
        if workspace_toolset is not None and (not isinstance(workspace_toolset, str) or not re.fullmatch(r"agentstack_workspace_[A-Za-z0-9_-]{3,63}", workspace_toolset)):
            raise ValueError("workspace_toolset is not an approved local tool namespace")
        addon = _DefaultAddon() if addon is None else addon
        self._validate_addon(addon)
        _validate_provider(provider)
        # Validate both roots before creating either one so a rejected remote
        # project cannot leave a partial local profile behind.
        _local_path(profile_root, "profile root")
        _local_path(project_root, "project root")
        profile_path = _directory(profile_root, "profile root", create=True)
        project_path = _directory(project_root, "project root", create=True)
        if profile_path == project_path or _within(profile_path, project_path) or _within(project_path, profile_path):
            raise ValueError("profile root and project root must be separate")
        for managed in managed_roots:
            managed_path = _directory(managed, "managed root", create=False)
            if _within(profile_path, managed_path) or _within(project_path, managed_path):
                raise ValueError("attended profile and project root must be outside managed roots")
        # The attended identity is the durable session/profile name.  The
        # filesystem directory is deliberately independent so users can move
        # a local profile without changing its identity contract.
        profile = AttendedProfile(profile_path, project_path, session_id, session_id, workspace_toolset=workspace_toolset)
        profile_record = {
            **_profile_dict(profile),
            "upstream_version": self.compatibility.upstream_version,
            "addon_version": self.compatibility.addon_version,
            "provider": dict(provider),
        }
        profile_json = profile_path / "profile.json"
        if profile_json.exists():
            existing = _safe_json(profile_json, "attended Hermes profile state")
            for field in ("profile_id", "session_id", "project_root", "upstream_version", "addon_version", "provider", "workspace_toolset"):
                if existing.get(field) != profile_record[field]:
                    raise HermesCompatibilityError("attended profile identity or compatibility changed")
        else:
            _atomic_json(profile_json, profile_record)
        (profile_path / "session").mkdir(parents=True, exist_ok=True)
        startup_path = profile_path / "startup.json"
        if not startup_path.exists():
            _atomic_json(startup_path, {"state": "ready", "generation": 1})
        hook = getattr(addon, "configure_attended_profile", None)
        hook(_profile_dict(profile))
        return AttendedHermesAdapter(self, profile, provider, addon=addon, driver_factory=driver_factory)

    def _validate_addon(self, addon: Any) -> None:
        hooks = getattr(addon, "hooks", ())
        if not isinstance(hooks, (tuple, list, set, frozenset)):
            raise HermesUnsupportedHookError("unsupported Hermes hook declaration; source patching is not supported")
        if any(not isinstance(hook_name, str) for hook_name in hooks):
            raise HermesUnsupportedHookError(
                "unsupported Hermes hook declaration; hook names must be strings; source patching is not supported"
            )
        declared_hooks = frozenset(hooks)
        supported_hooks = frozenset(_REQUIRED_ADDON_HOOKS)
        unsupported = (self._addon_hooks | declared_hooks) - supported_hooks
        if unsupported:
            raise HermesUnsupportedHookError(f"unsupported Hermes hook {sorted(unsupported)[0]!r}; source patching is not supported")
        missing_manifest = supported_hooks - self._addon_hooks
        if missing_manifest:
            hook_name = sorted(missing_manifest)[0]
            method_name = _REQUIRED_ADDON_HOOKS[hook_name]
            raise HermesUnsupportedHookError(
                f"staged Hermes manifest must declare hook {hook_name!r} ({method_name}); source patching is not supported"
            )
        missing = self._addon_hooks - declared_hooks
        if missing:
            raise HermesUnsupportedHookError(f"unsupported Hermes hook {sorted(missing)[0]!r}; source patching is not supported")
        for hook_name in self._addon_hooks:
            method = _REQUIRED_ADDON_HOOKS.get(hook_name)
            if method and not callable(getattr(addon, method, None)):
                raise HermesUnsupportedHookError(f"unsupported Hermes hook {hook_name!r}; source patching is not supported")


class _DefaultAddon:
    hooks = tuple(_REQUIRED_ADDON_HOOKS)

    def configure_attended_profile(self, _profile: Mapping[str, Any]) -> None:
        return None

    def before_local_turn(self, _profile: Mapping[str, Any], _message: str) -> None:
        return None


def _validate_provider(provider: Mapping[str, Any]) -> None:
    if not isinstance(provider, Mapping) or set(provider) - {"model", "provider", "base_url", "capabilities", "auth_mode", "auth_type"}:
        raise ValueError("provider configuration contains unsupported or secret-bearing fields")
    for field in ("model", "provider", "base_url"):
        if not isinstance(provider.get(field), str) or not provider[field].strip():
            raise ValueError("provider configuration requires model, provider, and base_url")
    for field in ("auth_mode", "auth_type"):
        if field in provider and not isinstance(provider[field], str):
            raise ValueError("provider auth mode and type must be strings")
    declared = []
    for field in ("auth_mode", "auth_type"):
        if field in provider and provider[field] is not None:
            value = "subscription" if provider[field] == "oauth" else provider[field]
            if value not in {"api_key", "subscription"}:
                raise ValueError("provider auth mode must be api_key, subscription, or oauth")
            declared.append(value)
    if len(declared) == 2 and declared[0] != declared[1]:
        raise ValueError("provider auth mode and type conflict")
    if "capabilities" in provider:
        capabilities = provider["capabilities"]
        if (
            not isinstance(capabilities, list)
            or len(capabilities) > 64
            or any(not isinstance(item, str) or not item.strip() or len(item) > 128 for item in capabilities)
        ):
            raise ValueError("provider capabilities must be a bounded list of names")
    from urllib.parse import urlparse
    parsed = urlparse(provider["base_url"])
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("provider base_url must be a credential-free HTTP(S) origin")


def _provider_auth_mode(provider: Mapping[str, Any]) -> str:
    """Return the normalized mode after the provider has passed validation."""
    declared = provider.get("auth_mode", provider.get("auth_type", "api_key"))
    return "subscription" if declared == "oauth" else declared


def stage_installation(stage_root: str | Path, manifest: str | Path, *, upstream_version: str | None = None, addon_version: str | None = None, available_hooks: Any = None) -> StagedHermesInstallation:
    _local_path(stage_root, "stage root")
    source = Path(manifest)
    if _unsafe_path_boundary(source) or source.is_symlink() or not source.is_file():
        raise ValueError("Hermes stage manifest must be a regular file")
    raw = _safe_json(source, "staged Hermes manifest")
    if not isinstance(raw, dict) or raw.get("schema") != _STAGE_MANIFEST_SCHEMA:
        raise HermesCompatibilityError("staged Hermes manifest schema is unsupported")
    compatibility = raw.get("compatibility")
    if not isinstance(compatibility, dict) or compatibility.get("source_patching") is not False:
        raise HermesCompatibilityError("upstream source patching is not supported")
    upstream = raw.get("upstream")
    addon = raw.get("addon")
    if not isinstance(upstream, dict) or not isinstance(addon, dict):
        raise HermesCompatibilityError("staged Hermes manifest is incomplete")
    selected_upstream = _supported_version(upstream.get("version"), "upstream.version")
    selected_addon = _supported_version(addon.get("version"), "addon.version")
    declared_upstream = _supported_version(compatibility.get("upstream_version"), "compatibility.upstream_version")
    declared_addon = _supported_version(compatibility.get("addon_version"), "compatibility.addon_version")
    if declared_upstream != selected_upstream or declared_addon != selected_addon:
        raise HermesCompatibilityError("staged Hermes manifest compatibility declaration is inconsistent")
    requested_upstream = (
        _supported_version(upstream_version, "upstream_version")
        if upstream_version is not None
        else None
    )
    requested_addon = (
        _supported_version(addon_version, "addon_version")
        if addon_version is not None
        else None
    )
    if requested_upstream is not None and requested_upstream != selected_upstream:
        raise HermesCompatibilityError(f"incompatible Hermes/add-on pair: Hermes {upstream_version} requires {selected_upstream}")
    if requested_addon is not None and requested_addon != selected_addon:
        raise HermesCompatibilityError(f"incompatible Hermes/add-on pair: add-on {addon_version} requires {selected_addon}")
    hooks = _validate_manifest_hook_contract(addon.get("supported_extension_points"))
    if available_hooks is not None:
        missing = hooks - _available_hook_names(available_hooks)
        if missing:
            raise HermesUnsupportedHookError(f"unsupported Hermes hook {sorted(missing)[0]!r}; source patching is not supported")
    root = _directory(stage_root, "stage root", create=True)
    _atomic_json(root / "manifest.json", raw)
    return StagedHermesInstallation(root)
