"""Narrow authenticated callback that runs the pinned Hermes MCP-only pilot."""
from __future__ import annotations

import asyncio, hashlib, hmac, json, os, re, signal, subprocess, sys, time, sqlite3
from pathlib import Path
from typing import Literal

import uvicorn
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, ConfigDict, Field, StrictInt

HOME = Path(os.environ["PILOT_HOME"])
PROJECT = os.environ["PILOT_PROJECT"]
WORKDIR = os.environ["PILOT_WORKDIR"]
TOKEN = HOME / "pilot-api.token"
OUTPUT = HOME / "pilot-output"
HERMES = "/srv/agent-stack/cache/memory-runtime/hermes-agent-0.19.0-venv/bin/hermes"
PYTHON = "/srv/agent-stack/cache/memory-runtime/hermes-agent-0.19.0-venv/bin/python"
BOOTSTRAP = """import sys
from hermes_cli.main import main
p=sys.stdin.read(1025)
if not p or len(p)>1024: raise SystemExit(2)
sys.argv=['hermes','--oneshot',p,'--provider','lmstudio','--model','local-tool-calling','--toolsets','platform_memory','--ignore-rules','--usage-file',sys.argv[1]]
raise SystemExit(main())"""
REQUEST_ID = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$")
lock = asyncio.Lock()
DB = HOME / "pilot-receipts.sqlite3"
MAX_HTTP_BYTES = 8192
MAX_NATIVE_BYTES = 65536
NATIVE_TIMEOUT = 180

class NativeFailure(RuntimeError):
    pass

async def stop_owned_child(process) -> None:
    if process.returncode is not None:
        return
    try:
        if os.getpgid(process.pid) != process.pid:
            raise NativeFailure("native process group identity mismatch")
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        await asyncio.wait_for(process.wait(), timeout=3)
    except asyncio.TimeoutError:
        try:
            if os.getpgid(process.pid) != process.pid:
                raise NativeFailure("native process group identity mismatch")
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        await asyncio.wait_for(process.wait(), timeout=3)

async def run_native(args, prompt, *, cwd, env):
    """Bound both pipes while reading, and retain ownership until child exit."""
    process = await asyncio.create_subprocess_exec(
        *args, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE, cwd=cwd, env=env, start_new_session=True)
    async def bounded_read(stream):
        chunks, size = [], 0
        while True:
            chunk = await stream.read(8192)
            if not chunk:
                return b"".join(chunks).decode("utf-8", errors="replace")
            size += len(chunk)
            if size > MAX_NATIVE_BYTES:
                raise NativeFailure("native output limit exceeded")
            chunks.append(chunk)
    async def exchange():
        process.stdin.write(prompt.encode("utf-8"))
        await process.stdin.drain()
        process.stdin.close()
        readers = [asyncio.create_task(bounded_read(process.stdout)),
                   asyncio.create_task(bounded_read(process.stderr))]
        try:
            stdout, stderr = await asyncio.gather(*readers)
            code = await process.wait()
            return subprocess.CompletedProcess(args, code, stdout, stderr)
        finally:
            for task in readers:
                if not task.done(): task.cancel()
            await asyncio.gather(*readers, return_exceptions=True)
    try:
        return await asyncio.wait_for(exchange(), timeout=NATIVE_TIMEOUT)
    except BaseException:
        await stop_owned_child(process)
        raise

class BodyLimit:
    def __init__(self, app): self.app = app
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect": return
            chunk=message.get("body", b"")
            if len(body) + len(chunk) > MAX_HTTP_BYTES:
                await send({"type":"http.response.start", "status":413, "headers":[]})
                await send({"type":"http.response.body", "body":b"bounded request required"})
                return
            body.extend(chunk)
            if not message.get("more_body", False): break
        delivered = False
        async def replay():
            nonlocal delivered
            if not delivered:
                delivered = True
                return {"type":"http.request", "body":bytes(body), "more_body":False}
            return await receive()
        await self.app(scope, replay, send)

def request_hash(payload: "PilotRequest") -> str:
    return hashlib.sha256(json.dumps({"project_id":payload.project_id,"model_ref":payload.model_ref,"memory_ref":payload.memory_ref,"input":payload.input.model_dump()}, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def claim(request_id: str, digest: str, before_claim=None) -> tuple[str, str | None]:
    """Atomically claim once. completed replays; running/unknown are never rerun."""
    con = sqlite3.connect(DB, isolation_level=None)
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("CREATE TABLE IF NOT EXISTS receipt (id TEXT PRIMARY KEY, digest TEXT NOT NULL, state TEXT NOT NULL, result TEXT, created INTEGER NOT NULL)")
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT digest,state,result FROM receipt WHERE id=?", (request_id,)).fetchone()
        if row:
            con.execute("COMMIT")
            if row[0] != digest: return "conflict", None
            return row[1], row[2]
        if before_claim is not None: before_claim()
        con.execute("INSERT INTO receipt VALUES (?,?,?,?,?)", (request_id,digest,"running",None,int(time.time())))
        con.execute("COMMIT")
        return "claimed", None
    finally: con.close()

def finish(request_id: str, state: str, result: dict | None = None) -> None:
    con=sqlite3.connect(DB); con.execute("UPDATE receipt SET state=?,result=? WHERE id=?",(state,json.dumps(result) if result else None,request_id)); con.commit(); con.close()

class PilotInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    value: StrictInt = Field(ge=-1_000_000, le=1_000_000)

class PilotRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schema_: Literal["agent-stack.pilot-agent.v1"] = Field(alias="schema")
    project_id: str
    request_id: str
    model_ref: Literal["qwen4bit-local"]
    memory_ref: Literal["platform-canary"]
    input: PilotInput

def check_auth(value: str | None) -> None:
    if not value or not value.startswith("Bearer ") or not TOKEN.is_file():
        raise HTTPException(401, "authentication required")
    if not hmac.compare_digest(value[7:], TOKEN.read_text().strip()):
        raise HTTPException(401, "authentication required")

def environment() -> dict[str, str]:
    api_key_file = Path(os.environ.get("INFERENCE_API_KEY_FILE", ""))
    if not api_key_file.is_file():
        raise HTTPException(503, "local inference credential is not provisioned")
    key = api_key_file.read_text().strip()
    if not key:
        raise HTTPException(503, "local inference credential is not provisioned")
    return {"HOME":str(HOME),"HERMES_HOME":str(HOME),"PATH":"/usr/local/bin:/usr/bin:/bin","LANG":"C.UTF-8","LC_ALL":"C.UTF-8","LM_BASE_URL":"http://127.0.0.1:18100/v1","LM_API_KEY":key,"NO_PROXY":"127.0.0.1,::1,localhost","no_proxy":"127.0.0.1,::1,localhost"}

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(BodyLimit)

@app.post("/v1/pilot/agent")
async def pilot(payload: PilotRequest, authorization: str | None = Header(default=None)) -> dict:
    check_auth(authorization)
    if payload.project_id != PROJECT:
        raise HTTPException(422, "project is not bound to this pilot")
    if not REQUEST_ID.fullmatch(payload.request_id):
        raise HTTPException(422, "invalid request_id")
    launch_env = None
    def preflight():
        nonlocal launch_env
        if lock.locked(): raise HTTPException(503,"pilot busy; no execution was claimed")
        launch_env = environment()
    digest=request_hash(payload); state, prior=claim(payload.request_id,digest,preflight)
    if state == "completed": return json.loads(prior)
    if state == "conflict": raise HTTPException(409,"request_id payload conflict")
    if state in {"running","unknown"}: raise HTTPException(409,"request receipt is non-retryable")
    prompt = f"Call recent_activity on project platform-canary exactly once, then evaluate the integer {payload.input.value} for the fixed pilot task. Return a short factual result."
    async with lock:
        OUTPUT.mkdir(mode=0o700, exist_ok=True)
        stamp = f"{int(time.time())}-{payload.request_id}"
        usage = OUTPUT / f"{stamp}.usage.json"
        raw = OUTPUT / f"{stamp}.raw.txt"
        native = asyncio.create_task(run_native([PYTHON,"-I","-c",BOOTSTRAP,str(usage)], prompt, cwd=WORKDIR, env=launch_env))
        try:
            # Do not abandon an unknown native execution on client disconnect:
            # the exclusive lock remains held until the bounded child reports.
            result = await asyncio.shield(native)
        except asyncio.TimeoutError:
            finish(payload.request_id,"unknown")
            raise HTTPException(504, "native Hermes pilot timed out")
        except asyncio.CancelledError:
            try:
                await native
            except Exception:
                pass
            finish(payload.request_id,"unknown")
            raise
        except (NativeFailure, OSError):
            finish(payload.request_id,"unknown")
            raise HTTPException(502,"native Hermes execution failed; receipt retained")
        raw.write_text(result.stdout[:16384], encoding="utf-8")
        try:
            if usage.stat().st_size > MAX_NATIVE_BYTES: raise ValueError("usage exceeds bound")
            usage_data = json.loads(usage.read_text())
        except Exception: usage_data = {}
        native_session = usage_data.get("session_id")
        evidence = {"returncode":result.returncode,"stdout_sha256":hashlib.sha256(result.stdout.encode()).hexdigest(),"stderr_sha256":hashlib.sha256(result.stderr.encode()).hexdigest(),"usage_file":usage.name,"native_session_id":native_session}
        (OUTPUT / f"{stamp}.evidence.json").write_text(json.dumps(evidence), encoding="utf-8")
    if result.returncode:
        finish(payload.request_id,"unknown")
        raise HTTPException(502, "native Hermes pilot failed; private evidence retained")
    if (not isinstance(native_session,str) or not REQUEST_ID.fullmatch(native_session)
        or usage_data.get("completed") is not True or usage_data.get("failed") is not False
        or type(usage_data.get("api_calls")) is not int or usage_data["api_calls"] < 1
        or not result.stdout.strip()):
        finish(payload.request_id,"unknown")
        raise HTTPException(502, "native Hermes completion evidence missing")
    receipt={"schema":"agent-stack.pilot-agent-result.v1","summary":result.stdout.strip()[:4000],"runtime_kind":"hermes","native_session_ref":native_session,"evidence_ref":f"private:{stamp}.evidence.json"}
    finish(payload.request_id,"completed",receipt)
    return receipt

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=int(os.environ["PILOT_PORT"]), log_config=None, access_log=False)
