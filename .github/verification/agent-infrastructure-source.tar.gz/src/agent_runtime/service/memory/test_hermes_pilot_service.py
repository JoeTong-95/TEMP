"""Isolated HTTP/receipt tests and real disposable child-process limit tests.

No real Hermes, model, credentials or live receipt database is used here.
"""
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

with patch.dict(os.environ, {"PILOT_HOME":"/nonexistent-test-only", "PILOT_PROJECT":"platform-canary-a", "PILOT_WORKDIR":"/nonexistent-test-only"}):
    spec = importlib.util.spec_from_file_location("pilot_test_module", Path(__file__).with_name("hermes_pilot_service.py"))
    pilot = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = pilot
    spec.loader.exec_module(pilot)


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.patches = []
        for name,value in {"HOME":self.root,"OUTPUT":self.root/"output", "DB":self.root/"receipts.sqlite3", "TOKEN":self.root/"test.token", "WORKDIR":str(self.root), "lock":asyncio.Lock()}.items():
            p=patch.object(pilot,name,value); p.start(); self.patches.append(p)
        pilot.TOKEN.write_text("synthetic-test-capability")
        self.calls = 0
        async def fake_native(args,prompt,**kwargs):
            self.calls += 1
            Path(args[-1]).write_text(json.dumps({"session_id":"synthetic-native-session","completed":True,"failed":False,"api_calls":1}))
            return subprocess.CompletedProcess(args,0,"synthetic native output","")
        for p in (patch.object(pilot,"environment",return_value={}),patch.object(pilot,"run_native",side_effect=fake_native)):
            p.start(); self.patches.append(p)
        self.client=TestClient(pilot.app)
        self.headers={"Authorization":"Bearer synthetic-test-capability"}

    def tearDown(self):
        self.client.close()
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()

    def body(self,**changes):
        body={"schema":"agent-stack.pilot-agent.v1","project_id":"platform-canary-a","request_id":"isolated-1","model_ref":"qwen4bit-local","memory_ref":"platform-canary","input":{"value":7}}
        body.update(changes); return body

    def post(self,**changes):
        return self.client.post("/v1/pilot/agent",json=self.body(**changes),headers=self.headers)

    def test_completed_replay_changed_input_conflict(self):
        first=self.post(); self.assertEqual(first.status_code,200)
        self.assertEqual(self.post().json(), first.json())
        self.assertEqual(self.post(input={"value":8}).status_code,409)
        self.assertEqual(self.calls,1)

    def test_replay_does_not_require_current_provider(self):
        first=self.post()
        with patch.object(pilot,"environment",side_effect=pilot.HTTPException(503,"unavailable")):
            self.assertEqual(self.post().json(),first.json())
        self.assertEqual(self.calls,1)

    def test_preflight_rejection_does_not_poison_receipt(self):
        with patch.object(pilot,"environment",side_effect=pilot.HTTPException(503,"unavailable")):
            self.assertEqual(self.post().status_code,503)
        self.assertEqual(self.post().status_code,200)
        self.assertEqual(self.calls,1)

    def test_durable_unknown_is_never_reexecuted(self):
        payload=pilot.PilotRequest.model_validate(self.body())
        pilot.claim(payload.request_id,pilot.request_hash(payload))
        pilot.finish(payload.request_id,"unknown")
        self.assertEqual(self.post().status_code,409)
        self.assertEqual(self.calls,0)

    def test_concurrent_claim_has_exactly_one_winner(self):
        from concurrent.futures import ThreadPoolExecutor
        # Initialize SQLite before simultaneous independent connections.
        pilot.claim("init","init")
        with ThreadPoolExecutor(max_workers=8) as pool:
            states=list(pool.map(lambda _:pilot.claim("race","same")[0],range(8)))
        self.assertEqual(states.count("claimed"),1)
        self.assertEqual(states.count("running"),7)

    def test_unknown_persists_after_native_timeout(self):
        with patch.object(pilot,"run_native",side_effect=asyncio.TimeoutError):
            self.assertEqual(self.post().status_code,504)
        self.assertEqual(self.post().status_code,409)
        self.assertEqual(self.calls,0)

    def test_busy_rejects_without_claim_or_queue(self):
        with patch.object(pilot.lock,"locked",return_value=True):
            self.assertEqual(self.post().status_code,503)
        self.assertEqual(self.post().status_code,200)
        self.assertEqual(self.calls,1)

    def test_scope_auth_strict_integer_and_body_limits(self):
        self.assertEqual(self.client.post("/v1/pilot/agent",json=self.body()).status_code,401)
        self.assertEqual(self.post(project_id="platform-canary-b").status_code,422)
        for value in (True,7.0,"7"):
            self.assertEqual(self.post(input={"value":value}).status_code,422)
        response=self.client.post("/v1/pilot/agent",content=b"x"*(pilot.MAX_HTTP_BYTES+1),headers=self.headers)
        self.assertEqual(response.status_code,413)
        self.assertEqual(self.calls,0)

    def test_missing_native_session_is_unknown_not_success(self):
        async def missing(args,prompt,**kwargs):
            return subprocess.CompletedProcess(args,0,"not proof","")
        with patch.object(pilot,"run_native",side_effect=missing):
            self.assertEqual(self.post().status_code,502)
        self.assertEqual(self.post().status_code,409)

    def test_exit_zero_with_incomplete_native_usage_is_not_success(self):
        async def incomplete(args,prompt,**kwargs):
            Path(args[-1]).write_text(json.dumps({"session_id":"synthetic-native-session","completed":False,"failed":False,"api_calls":1}))
            return subprocess.CompletedProcess(args,0,"partial is not complete","")
        with patch.object(pilot,"run_native",side_effect=incomplete):
            self.assertEqual(self.post().status_code,502)
        self.assertEqual(self.post().status_code,409)


class NativeChildTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_child_output_cap_and_cleanup(self):
        handles=[]
        create=asyncio.create_subprocess_exec
        async def capture(*args,**kwargs):
            process=await create(*args,**kwargs); handles.append(process); return process
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(pilot.asyncio,"create_subprocess_exec",side_effect=capture):
                with self.assertRaises(pilot.NativeFailure):
                    await pilot.run_native([sys.executable,"-c","import sys,time;sys.stdout.write('x'*200000);sys.stdout.flush();time.sleep(10)"],"synthetic",cwd=directory,env={"PATH":"/usr/bin:/bin"})
        self.assertIsNotNone(handles[0].returncode)

    async def test_real_child_timeout_and_cleanup(self):
        handles=[]
        create=asyncio.create_subprocess_exec
        async def capture(*args,**kwargs):
            process=await create(*args,**kwargs); handles.append(process); return process
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(pilot.asyncio,"create_subprocess_exec",side_effect=capture),patch.object(pilot,"NATIVE_TIMEOUT",0.1):
                with self.assertRaises(asyncio.TimeoutError):
                    await pilot.run_native([sys.executable,"-c","import time;time.sleep(10)"],"synthetic",cwd=directory,env={"PATH":"/usr/bin:/bin"})
        self.assertIsNotNone(handles[0].returncode)


class NativeBootstrapTests(unittest.TestCase):
    """Guard the isolated entrypoint used by the MCP-only pilot.

    The separate loopback canary exercises the installed CLI against an
    ephemeral fake OpenAI endpoint and inspects its child argv.  These checks
    pin the pilot-specific seam: it must import Hermes' supported ``main``
    function (rather than executing the console-script wrapper as a file) and
    the synthetic prompt must remain stdin-only.
    """

    def test_pinned_cli_main_is_importable_under_isolated_mode(self):
        probe = "import sys; from hermes_cli.main import main; sys.argv=['hermes','--version']; raise SystemExit(main())"
        with tempfile.TemporaryDirectory() as home:
            env = {"HOME": home, "HERMES_HOME": home, "PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8"}
            completed = subprocess.run(
                [pilot.PYTHON, "-I", "-c", probe], env=env,
                text=True, capture_output=True, timeout=20, check=False,
            )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("0.19.0", completed.stdout)

    def test_pilot_bootstrap_uses_main_and_prompt_is_not_an_os_argument(self):
        prompt = "synthetic-bootstrap-prompt-must-not-appear-in-proc"
        argv = [pilot.PYTHON, "-I", "-c", pilot.BOOTSTRAP, "/tmp/usage.json"]
        self.assertIn("from hermes_cli.main import main", pilot.BOOTSTRAP)
        self.assertNotIn("runpy", pilot.BOOTSTRAP)
        self.assertNotIn(prompt, argv)


if __name__ == "__main__": unittest.main(verbosity=2)
