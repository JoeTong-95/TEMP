from __future__ import annotations

from pathlib import Path
import contextlib
import io
import json
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import hermes_adapter
from hermes_adapter import HermesTurn, hermes_argv, hermes_environment, invoke
from run_hermes_turn import main


class HermesAdapterTests(unittest.TestCase):
    def turn(self, **changes: object) -> HermesTurn:
        values: dict[str, object] = {
            "identity": "stack-agent-a",
            "model": "canary-local-model",
            "endpoint": "http://127.0.0.1:18100/v1",
            "prompt": "Return the word ready.",
            "workdir": Path("/srv/agent-stack/workspaces/platform-canary-a/t21"),
            "usage_file": Path("/srv/agent-stack/state/hermes-a/usage/t21.json"),
        }
        values.update(changes)
        return HermesTurn(**values)  # type: ignore[arg-type]

    def test_argv_is_supported_hermes_oneshot_with_restricted_toolset(self) -> None:
        argv = hermes_argv(self.turn(), "/cache/hermes")
        self.assertEqual("/cache/python", argv[0])
        self.assertIn("/cache/hermes", argv)
        self.assertIn("--oneshot", argv[argv.index("-c") + 1])
        self.assertNotIn(self.turn().prompt, " ".join(argv))
        self.assertEqual("todo", argv[argv.index("--toolsets") + 1])
        for forbidden in ("terminal", "process", "browser", "web", "computer_use", "memory", "mcp"):
            self.assertNotIn(forbidden, argv)

    def test_environment_is_allowlisted_and_loopback_only(self) -> None:
        env = hermes_environment(self.turn())
        self.assertEqual("/srv/agent-stack/state/hermes-a", env["HERMES_HOME"])
        self.assertEqual("http://127.0.0.1:18100/v1", env["LM_BASE_URL"])
        self.assertNotIn("OPENAI_API_KEY", env)
        self.assertNotIn("HTTP_PROXY", env)
        self.assertEqual("127.0.0.1,::1,localhost", env["NO_PROXY"])

    def test_non_loopback_and_bad_state_are_refused_before_subprocess(self) -> None:
        for changes in (
            {"endpoint": "https://example.test/v1"},
            {"endpoint": "http://192.168.8.8:18100/v1"},
            {"identity": "agentbuild"},
            {"usage_file": Path("/tmp/usage.json")},
            {"workdir": Path("/home/agentbuild")},
            {"usage_file": Path("/srv/agent-stack/state/hermes-a/../hermes-b/usage/t21.json")},
            {"workdir": Path("/srv/agent-stack/workspaces/platform-canary-a/../platform-canary-b/t21")},
        ):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                hermes_argv(self.turn(**changes), "/cache/hermes")

    def test_fake_transport_receives_no_inherited_environment(self) -> None:
        seen: dict[str, object] = {}

        def fake(args: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
            seen["args"] = args
            seen.update(kwargs)
            return subprocess.CompletedProcess(args, 0, "ready\n", "")

        result = invoke(self.turn(), runner=fake, uid_getter=lambda: hermes_adapter.pwd.getpwnam("stack-agent-a").pw_uid)
        self.assertEqual(0, result.returncode)
        self.assertEqual(180, seen["timeout"])
        self.assertTrue(seen["capture_output"])
        self.assertEqual(self.turn().prompt, seen["input"])
        self.assertNotIn(self.turn().prompt, " ".join(seen["args"]))
        args = seen["args"]  # type: ignore[assignment]
        self.assertEqual("todo", args[args.index("--toolsets") + 1])

    def test_invoke_rejects_false_identity_and_non_pinned_executable(self) -> None:
        with self.assertRaises(PermissionError):
            invoke(self.turn(), runner=lambda *_args, **_kwargs: None, uid_getter=lambda: 1000)  # type: ignore[arg-type]
        with self.assertRaises(ValueError):
            invoke(self.turn(), executable="/bin/true", runner=lambda *_args, **_kwargs: None, uid_getter=lambda: hermes_adapter.pwd.getpwnam("stack-agent-a").pw_uid)  # type: ignore[arg-type]

    def test_symlink_escape_is_refused_after_resolution(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            state, workspace, outside = root / "state", root / "workspace", root / "outside"
            for directory in (state, workspace, outside):
                directory.mkdir()
            (workspace / "escape").symlink_to(outside, target_is_directory=True)
            original = hermes_adapter._ALLOWED_IDENTITIES["stack-agent-a"]
            hermes_adapter._ALLOWED_IDENTITIES["stack-agent-a"] = (state, workspace)
            try:
                with self.assertRaises(ValueError):
                    hermes_argv(
                        HermesTurn(
                            "stack-agent-a", "canary", "http://127.0.0.1:18100/v1", "ready",
                            workspace / "escape", state / "usage.json",
                        )
                    )
            finally:
                hermes_adapter._ALLOWED_IDENTITIES["stack-agent-a"] = original

    def test_cli_refuses_unapproved_non_loopback_endpoint(self) -> None:
        with patch("sys.stdin", io.StringIO("ready")):
            code = main([
                "--identity", "stack-agent-a", "--model", "canary", "--endpoint", "http://10.0.0.1:18100/v1",
                "--prompt-stdin", "--workdir", "/srv/agent-stack/workspaces/platform-canary-a/t21",
                "--usage-file", "/srv/agent-stack/state/hermes-a/usage/t21.json",
            ])
        self.assertEqual(2, code)

    def test_cli_never_prints_raw_runtime_output(self) -> None:
        output = io.StringIO()
        sentinel = "SYNTHETIC_PRIVATE_SENTINEL"
        result = subprocess.CompletedProcess([], 0, sentinel, sentinel)
        with patch("sys.stdin", io.StringIO(sentinel)), patch("run_hermes_turn.invoke", return_value=result), contextlib.redirect_stdout(output):
            code = main([
                "--identity", "stack-agent-a", "--model", "canary", "--endpoint", "http://127.0.0.1:18100/v1",
                "--prompt-stdin", "--workdir", "/srv/agent-stack/workspaces/platform-canary-a/t21",
                "--usage-file", "/srv/agent-stack/state/hermes-a/usage/t21.json",
            ])
        self.assertEqual(0, code)
        self.assertNotIn(sentinel, output.getvalue())
        self.assertEqual(len(sentinel), json.loads(output.getvalue())["stdout_bytes"])


if __name__ == "__main__":
    unittest.main()
