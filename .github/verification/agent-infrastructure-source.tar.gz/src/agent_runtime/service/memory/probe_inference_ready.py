"""Read-only protected inference readiness probe; never emits a token or body."""
from __future__ import annotations
import sys
from pathlib import Path
import httpx

def main() -> int:
    token_path=Path(sys.argv[1])
    try: token=token_path.read_text().strip()
    except OSError: print("token_unavailable"); return 2
    try: response=httpx.get("http://127.0.0.1:18100/v1/models",headers={"Authorization":"Bearer "+token},timeout=5)
    except httpx.RemoteProtocolError: print("tunnel_no_gateway"); return 3
    except httpx.HTTPError: print("tunnel_unreachable"); return 3
    if response.status_code==200:
        try: models=response.json().get("data",[])
        except ValueError: print("models_invalid"); return 4
        print("model_ready" if any(x.get("id")=="local-tool-calling" for x in models if isinstance(x,dict)) else "model_missing")
        return 0
    if response.status_code==401: print("auth_rejected")
    elif response.status_code==503: print("profile_unmeasured")
    else: print("gateway_status_"+str(response.status_code))
    return 4
if __name__=="__main__": raise SystemExit(main())
