"""Ephemeral proof that the pinned Hermes CLI calls only the supplied LM_BASE_URL.

Run this file as ``stack-agent-a``.  It starts no persistent service and makes
no cloud request: the fake OpenAI-compatible server binds a kernel-selected
127.0.0.1 port and is shut down in ``finally``.
"""

from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import threading
import unittest

from hermes_adapter import PINNED_HERMES, HermesTurn, invoke


class _Handler(BaseHTTPRequestHandler):
    paths: list[str] = []
    requests: list[dict[str, object]] = []
    private_argv_observations: list[bool] = []

    def do_POST(self) -> None:  # noqa: N802 - HTTP server API name
        type(self).paths.append(self.path)
        size = int(self.headers.get("Content-Length", "0"))
        request = json.loads(self.rfile.read(size))
        type(self).requests.append(request)
        # Inspect only this test's direct children while the real Hermes process
        # is making its request. Never collect arbitrary host command lines.
        children = Path(f"/proc/{os.getpid()}/task/{os.getpid()}/children").read_text().split()
        observed = False
        for pid in children:
            try:
                cmdline = Path(f"/proc/{pid}/cmdline").read_bytes()
            except FileNotFoundError:
                continue
            if PINNED_HERMES.encode() in cmdline:
                observed = True
                type(self).private_argv_observations.append(b"Reply exactly LOCAL_CANARY_OK." not in cmdline)
        if not observed:
            type(self).private_argv_observations.append(False)
        chunks = [
            {"id": "local-canary", "object": "chat.completion.chunk", "model": "canary-local-model",
             "choices": [{"index": 0, "delta": {"role": "assistant", "content": "LOCAL_CANARY_OK"}, "finish_reason": None}]},
            {"id": "local-canary", "object": "chat.completion.chunk", "model": "canary-local-model",
             "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]},
        ]
        body = "".join(f"data: {json.dumps(chunk)}\n\n" for chunk in chunks) + "data: [DONE]\n\n"
        body = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, _format: str, *_args: object) -> None:
        pass


class HermesLoopbackIntegration(unittest.TestCase):
    def test_pinned_hermes_honors_local_base_url(self) -> None:
        self.assertEqual(os.geteuid(), __import__("pwd").getpwnam("stack-agent-a").pw_uid)
        server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            endpoint = f"http://127.0.0.1:{server.server_port}/v1"
            turn = HermesTurn(
                identity="stack-agent-a", model="canary-local-model", endpoint=endpoint,
                prompt="Reply exactly LOCAL_CANARY_OK.",
                workdir=Path("/srv/agent-stack/workspaces/platform-canary-a/hermes-loopback"),
                usage_file=Path("/srv/agent-stack/state/hermes-a/usage/hermes-loopback.json"),
            )
            turn.workdir.mkdir(parents=True, exist_ok=True)
            result = invoke(turn, executable=PINNED_HERMES)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn("LOCAL_CANARY_OK", result.stdout)
        self.assertIn("/v1/chat/completions", _Handler.paths)
        completion = _Handler.requests[_Handler.paths.index("/v1/chat/completions")]
        self.assertTrue(completion["stream"])
        self.assertTrue(_Handler.private_argv_observations)
        self.assertTrue(all(_Handler.private_argv_observations))


if __name__ == "__main__":
    unittest.main()
