"""Thin, local-only launcher for an official Hermes Agent canary turn.

This module deliberately invokes the upstream ``hermes`` executable.  It does
not implement an agent, a model client, memory, MCP, or a tool protocol.
"""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import pwd
import subprocess
from typing import Callable, Protocol
from urllib.parse import urlparse


_ALLOWED_IDENTITIES = {
    "stack-agent-a": (Path("/srv/agent-stack/state/hermes-a"), Path("/srv/agent-stack/workspaces/platform-canary-a")),
    "stack-agent-b": (Path("/srv/agent-stack/state/hermes-b"), Path("/srv/agent-stack/workspaces/platform-canary-b")),
}
_SAFE_PATH = "/usr/local/bin:/usr/bin:/bin"
PINNED_HERMES = "/srv/agent-stack/cache/memory-runtime/hermes-agent-0.19.0-venv/bin/hermes"
# Invoke the installed entrypoint unchanged, but construct its argument vector
# inside the child. Linux /proc/<pid>/cmdline must never contain the prompt.
_STDIN_ENTRYPOINT = """import runpy, sys
entry, *args = sys.argv[1:]
prompt = sys.stdin.read(16001)
if not prompt or len(prompt) > 16000:
    raise SystemExit('bounded prompt input required')
sys.argv = [entry, *args, '--oneshot', prompt]
runpy.run_path(entry, run_name='__main__')
"""


class Runner(Protocol):
    def __call__(self, args: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]: ...


@dataclass(frozen=True)
class HermesTurn:
    identity: str
    model: str
    endpoint: str
    prompt: str
    workdir: Path
    usage_file: Path

    def validate(self) -> None:
        if self.identity not in _ALLOWED_IDENTITIES:
            raise ValueError("identity is not a dedicated Hermes runtime identity")
        if not self.model or len(self.model) > 160 or any(ch.isspace() for ch in self.model):
            raise ValueError("model must be a bounded non-whitespace identifier")
        if not self.prompt or len(self.prompt) > 16_000:
            raise ValueError("prompt must be non-empty and no more than 16000 characters")
        parsed = urlparse(self.endpoint)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "::1"} or not parsed.port:
            raise ValueError("inference endpoint must be an explicit loopback HTTP URL with a port")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("inference endpoint cannot contain credentials, a query, or a fragment")
        if not self.endpoint.rstrip("/").endswith("/v1"):
            raise ValueError("inference endpoint must end in /v1")
        state, workspace = _ALLOWED_IDENTITIES[self.identity]
        usage_file = self.usage_file.resolve(strict=False)
        workdir = self.workdir.resolve(strict=False)
        if not usage_file.is_relative_to(state.resolve(strict=False)):
            raise ValueError("usage output must remain within the matching dedicated Hermes home")
        if not workdir.is_relative_to(workspace.resolve(strict=False)):
            raise ValueError("workdir must remain in the matching platform-canary workspace")


def hermes_environment(turn: HermesTurn) -> dict[str, str]:
    """Return an allowlisted environment; no operator environment is inherited."""
    turn.validate()
    state, _ = _ALLOWED_IDENTITIES[turn.identity]
    return {
        "HOME": str(state),
        "HERMES_HOME": str(state),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "PATH": _SAFE_PATH,
        "LM_BASE_URL": turn.endpoint.rstrip("/"),
        "HERMES_INFERENCE_MODEL": turn.model,
        "NO_PROXY": "127.0.0.1,::1,localhost",
        "no_proxy": "127.0.0.1,::1,localhost",
    }


def hermes_argv(turn: HermesTurn, executable: str = PINNED_HERMES) -> list[str]:
    """Use the supported one-shot CLI with the only allowed built-in toolset.

    ``todo`` is local Hermes task state; it excludes terminal, process, file,
    browser, web, computer-use, memory and every MCP server.  The memory tool
    remains absent until a separately approved, scope-enforcing MCP route is
    configured.
    """
    turn.validate()
    return [
        str(Path(executable).parent / "python"), "-I", "-c", _STDIN_ENTRYPOINT, executable,
        "--safe-mode",
        "--provider", "lmstudio",
        "--model", turn.model,
        "--toolsets", "todo",
        "--usage-file", str(turn.usage_file),
    ]


def invoke(
    turn: HermesTurn,
    *,
    executable: str = PINNED_HERMES,
    runner: Runner = subprocess.run,
    uid_getter: Callable[[], int] = os.geteuid,
) -> subprocess.CompletedProcess[str]:
    """Run one bounded upstream Hermes turn; caller owns model-readiness gating."""
    expected_uid = pwd.getpwnam(turn.identity).pw_uid
    if uid_getter() != expected_uid:
        raise PermissionError("Hermes turn must execute under its mapped service identity")
    executable_path = Path(executable).resolve(strict=False)
    pinned_path = Path(PINNED_HERMES).resolve(strict=False)
    if executable_path != pinned_path or not executable_path.is_file() or not os.access(executable_path, os.X_OK):
        raise ValueError("Hermes executable must be the installed pinned runtime")
    args = hermes_argv(turn, executable)
    return runner(
        args,
        cwd=turn.workdir,
        env=hermes_environment(turn),
        input=turn.prompt,
        text=True,
        capture_output=True,
        timeout=180,
        check=False,
    )
