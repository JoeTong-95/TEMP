"""Run one approved local Hermes canary turn through :mod:`hermes_adapter`."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import subprocess

from hermes_adapter import HermesTurn, invoke


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a bounded local Hermes canary turn")
    parser.add_argument("--identity", choices=("stack-agent-a", "stack-agent-b"), required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--endpoint", required=True, help="approved loopback OpenAI-compatible /v1 endpoint")
    parser.add_argument("--prompt-stdin", action="store_true", required=True,
                        help="read the bounded prompt from stdin, never process arguments")
    parser.add_argument("--workdir", required=True)
    parser.add_argument("--usage-file", required=True)
    parser.add_argument(
        "--hermes",
        default="/srv/agent-stack/cache/memory-runtime/hermes-agent-0.19.0-venv/bin/hermes",
    )
    args = parser.parse_args(argv)
    try:
        turn = HermesTurn(
            identity=args.identity,
            model=args.model,
            endpoint=args.endpoint,
            prompt=sys.stdin.read(16_001),
            workdir=Path(args.workdir),
            usage_file=Path(args.usage_file),
        )
        result = invoke(turn, executable=args.hermes)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(json.dumps({"error": type(error).__name__, "message": "Hermes turn rejected; inspect the private runtime state."}), file=sys.stderr)
        return 2
    # Runtime-native session state remains the output authority. CLI diagnostics
    # contain only status, sizes and digests, not prompts or model/tool output.
    print(json.dumps({"returncode": result.returncode,
        "stdout_bytes": len(result.stdout.encode("utf-8")),
        "stderr_bytes": len(result.stderr.encode("utf-8")),
        "stdout_sha256": hashlib.sha256(result.stdout.encode("utf-8")).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr.encode("utf-8")).hexdigest()}))
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
