"""Portable attended-Hermes project opening at an explicit revision.

This module owns the small runtime seam between a local Project Descriptor and
the already-bound checkout/frontier services.  It deliberately accepts those
services as callbacks: Management remains the authority for their data and
the runtime never grows a second project or issue tracker.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import copy
import math
import re
from typing import Any, Callable, Mapping, Protocol
from urllib.parse import urlsplit

from .skill_releases import SkillReleaseError, SkillReleaseLibrary


_SAFE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_STATES = frozenset({"enrolled", "imported", "cached"})
_PRIVATE = re.compile(r"(?:secret|token|password|credential|private|api[_-]?key)", re.I)
_CHECKOUT_KEYS = frozenset({"project_id", "revision", "checkout_path", "path", "status",
                            "publication_state", "dirty", "stale", "freshness", "local_commits",
                            "changed_files", "files", "state"})
_FRONTIER_KEYS = frozenset({"schema", "project_id", "repository", "project_revision",
                            "parent_issue_number", "status", "freshness"})
_ISSUE_KEYS = frozenset({"number", "title", "state", "labels", "parent_number",
                         "sub_issue_numbers", "blocked_by", "ancestry", "url", "html_url",
                         "active_claim_owner", "assignees", "blockers", "reasons", "status", "body"})
_FRONTIER_SCHEMA = "agent-stack.github-frontier"
_FRESHNESS_KEYS = frozenset({"state", "observed_at", "attempted_at", "age_seconds", "reason"})
_SCHEDULING_KEYS = frozenset({"actionable", "blocked", "parent_context", "dependencies",
                              "issues", "all_issues", "leaves", "claims", "generated_at"})
_LOCAL_WORK_KEYS = frozenset({"state", "files", "local_commits"})


class HermesProjectError(ValueError):
    """A descriptor or bound project operation cannot be trusted."""


class CheckoutOpener(Protocol):
    def __call__(self, descriptor: Mapping[str, Any]) -> Mapping[str, Any]: ...


class FrontierLoader(Protocol):
    def __call__(self, descriptor: Mapping[str, Any]) -> Mapping[str, Any]: ...


@dataclass(frozen=True)
class ProjectDescriptor:
    """The non-secret, portable inputs needed to open a project."""

    project_id: str
    repository_url: str
    revision: str
    default_branch: str
    issue_tracker: Mapping[str, Any]
    bootstrap_documents: tuple[str, ...]
    checkout_policy: Mapping[str, Any]
    state: str = "cached"
    skill_releases: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.state, str) or self.state not in _STATES:
            raise HermesProjectError("project descriptor state is invalid")
        for name in ("project_id", "revision", "default_branch"):
            value = getattr(self, name)
            if not isinstance(value, str) or _SAFE.fullmatch(value) is None:
                raise HermesProjectError(f"project descriptor {name} is invalid")
        if not isinstance(self.repository_url, str) or not self.repository_url.strip():
            raise HermesProjectError("project descriptor repository is invalid")
        if _repo_identity(self.repository_url) is None:
            raise HermesProjectError("project descriptor repository identity is invalid")
        if not isinstance(self.issue_tracker, Mapping) or not self.issue_tracker or _contains_private(self.issue_tracker):
            raise HermesProjectError("project descriptor tracker is invalid")
        if self.issue_tracker.get("provider") not in (None, "github"):
            raise HermesProjectError("project descriptor tracker is invalid")
        parent = self.issue_tracker.get("parent_issue", self.issue_tracker.get("parent_issue_number"))
        if type(parent) is not int or parent < 1:
            raise HermesProjectError("project descriptor tracker is invalid")
        if (not isinstance(self.bootstrap_documents, tuple) or
                any(not isinstance(v, str) or not v or v.startswith("/") or ".." in v.split("/")
                    for v in self.bootstrap_documents)):
            raise HermesProjectError("project descriptor documents are invalid")
        if not isinstance(self.checkout_policy, Mapping) or _contains_private(self.checkout_policy):
            raise HermesProjectError("project descriptor checkout policy is invalid")
        if (not isinstance(self.skill_releases, Mapping)
                or _contains_private(self.skill_releases)
                or any(not isinstance(skill, str) or _SAFE.fullmatch(skill) is None
                       or not isinstance(version, str) or not version.strip()
                       for skill, version in self.skill_releases.items())):
            raise HermesProjectError("project descriptor skill releases are invalid")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "ProjectDescriptor":
        if not isinstance(value, Mapping):
            raise HermesProjectError("project descriptor is invalid")
        docs = value.get("bootstrap_documents", value.get("bootstrap_document_paths", ()))
        if isinstance(docs, list):
            docs = tuple(docs)
        skills = value.get("skill_releases", value.get("skills", {}))
        if isinstance(skills, (list, tuple)):
            try:
                skills = {item.get("name", item.get("skill_id")): item.get("version", item.get("release"))
                          for item in skills if isinstance(item, Mapping)}
            except AttributeError:
                skills = None
        return cls(value.get("project_id"), value.get("repository_url", value.get("repository")),
                    value.get("revision"), value.get("default_branch", "main"),
                    value.get("issue_tracker", value.get("tracker")), docs,
                    value.get("checkout_policy", value.get("temporary_checkout_policy", {})),
                    value.get("state", "cached"), skills)


@dataclass(frozen=True)
class OpenProjectResult:
    descriptor: ProjectDescriptor
    checkout: Mapping[str, Any]
    frontier: Mapping[str, Any]
    context: Mapping[str, Any]


class HermesProjectOpener:
    """Open one descriptor without copying a transcript or broad issue dump."""

    def __init__(self, checkout: CheckoutOpener, frontier: FrontierLoader,
                 *, dirty_probe: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
                 skill_library: SkillReleaseLibrary | None = None) -> None:
        if not callable(checkout) or not callable(frontier):
            raise HermesProjectError("project checkout and frontier services are required")
        if skill_library is not None and not isinstance(skill_library, SkillReleaseLibrary):
            raise HermesProjectError("skill library is invalid")
        self.checkout, self.frontier, self.dirty_probe, self.skill_library = checkout, frontier, dirty_probe, skill_library

    def open(self, descriptor: ProjectDescriptor | Mapping[str, Any]) -> OpenProjectResult:
        value = descriptor if isinstance(descriptor, ProjectDescriptor) else ProjectDescriptor.from_mapping(descriptor)
        if value.skill_releases and self.skill_library is None:
            raise HermesProjectError("declared skill releases require a skill library")
        raw = {"project_id": value.project_id, "repository_url": value.repository_url,
               "revision": value.revision, "default_branch": value.default_branch,
               "issue_tracker": copy.deepcopy(dict(value.issue_tracker)),
               "bootstrap_documents": list(value.bootstrap_documents),
               "checkout_policy": copy.deepcopy(dict(value.checkout_policy)), "state": value.state}
        if value.skill_releases:
            raw["skill_releases"] = dict(value.skill_releases)
        checkout = self.checkout(copy.deepcopy(raw))
        if not isinstance(checkout, Mapping):
            raise HermesProjectError("isolated project checkout is unavailable")
        if checkout.get("project_id", value.project_id) != value.project_id or checkout.get("revision") not in (None, value.revision):
            raise HermesProjectError("isolated checkout does not match descriptor")
        path = checkout.get("checkout_path", checkout.get("path"))
        if not isinstance(path, str) or not path:
            raise HermesProjectError("isolated checkout path is unavailable")
        checkout = _safe_checkout(checkout, value)
        frontier = self.frontier(copy.deepcopy(raw))
        if not isinstance(frontier, Mapping):
            raise HermesProjectError("project frontier is unavailable")
        if _repo_identity(frontier.get("repository")) != _repo_identity(value.repository_url):
            raise HermesProjectError("project frontier does not match descriptor")
        if frontier.get("project_revision") != value.revision:
            raise HermesProjectError("project frontier revision does not match descriptor")
        frontier = _safe_frontier(frontier, value)
        active = frontier.get("active_task")
        relevant = list(frontier.get("active_context", ()))
        context = {"project_id": value.project_id, "revision": value.revision,
                   "repository_url": value.repository_url,
                   "documents": list(value.bootstrap_documents),
                   "checkout": dict(checkout), "active_issue": _copy_record(active),
                   "relevant_dependencies": [_copy_record(item) for item in relevant],
                   "frontier_status": frontier.get("status", "unavailable")}
        if self.skill_library is not None:
            try:
                if value.skill_releases:
                    for skill_id, version in sorted(value.skill_releases.items()):
                        self.skill_library.install(skill_id, version, project_id=value.project_id, requested=False)
                else:
                    self.skill_library.install_declared(value.project_id)
                context["skills"] = list(self.skill_library.invocation_for_project(value.project_id))
            except SkillReleaseError as error:
                raise HermesProjectError("project skill releases are unavailable") from error
        if self.dirty_probe is not None:
            dirty = self.dirty_probe(checkout)
            if not isinstance(dirty, Mapping):
                raise HermesProjectError("checkout dirty state is unavailable")
            context["local_work"] = _safe_status(dirty)
        return OpenProjectResult(value, dict(checkout), dict(frontier), context)


def open_project(descriptor: ProjectDescriptor | Mapping[str, Any], checkout: CheckoutOpener,
                 frontier: FrontierLoader, *, skill_library: SkillReleaseLibrary | None = None) -> OpenProjectResult:
    """Convenience public boundary for the attended open-project action."""
    return HermesProjectOpener(checkout, frontier, skill_library=skill_library).open(descriptor)


def _contains_private(value: Any, depth: int = 0) -> bool:
    if depth > 12:
        return True
    if isinstance(value, Mapping):
        return any(_PRIVATE.search(str(key)) or _contains_private(item, depth + 1)
                   for key, item in value.items())
    if isinstance(value, (list, tuple)):
        return any(_contains_private(item, depth + 1) for item in value)
    return False


def _json_value(value: Any, depth: int = 0) -> Any:
    if depth > 8:
        raise HermesProjectError("project frontier value is too deep")
    if value is None or type(value) in {bool, int, float, str}:
        if type(value) is float and not math.isfinite(value):
            raise HermesProjectError("project frontier value is not JSON")
        if isinstance(value, str) and len(value.encode()) > 65536:
            raise HermesProjectError("project frontier text is oversized")
        return copy.deepcopy(value)
    if isinstance(value, Mapping):
        if len(value) > 32:
            raise HermesProjectError("project frontier record is oversized")
        if any(not isinstance(key, str) for key in value):
            raise HermesProjectError("project frontier record has invalid keys")
        return {key: _json_value(item, depth + 1) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        if len(value) > 100:
            raise HermesProjectError("project frontier list is oversized")
        return [_json_value(item, depth + 1) for item in value]
    raise HermesProjectError("project frontier value is not JSON")


def _copy_record(value: Any, *, retain_body: bool = True) -> Any:
    if value is None:
        return None
    if not isinstance(value, Mapping) or _contains_private(value):
        raise HermesProjectError("project frontier record is invalid")
    unknown = set(value) - _ISSUE_KEYS
    if unknown:
        raise HermesProjectError("project frontier record is not approved")
    result = {}
    for key in value:
        if key == "body" and not retain_body:
            continue
        result[key] = _json_value(value[key])
    return result


def _repo_identity(value: Any) -> tuple[str, str] | None:
    if not isinstance(value, str):
        return None
    # Keep the identity deliberately narrower than what urllib accepts.  A
    # repository binding is a canonical public GitHub endpoint, not an
    # arbitrary URL that happens to resolve to the same host/path.
    if not value or value != value.strip() or any(char in value for char in "?#\x00"):
        return None
    try:
        parsed = urlsplit(value)
        hostname = parsed.hostname
        port = parsed.port
    except ValueError:
        # urlsplit defers malformed and out-of-range port validation until
        # .port (and malformed bracket validation until .hostname).
        return None
    if (parsed.scheme not in {"https", "ssh"} or hostname != "github.com" or
            parsed.username or parsed.password or port is not None or ":" in parsed.netloc):
        return None
    path = parsed.path
    if not path.startswith("/") or path.endswith("/") or path.startswith("//"):
        return None
    bits = path[1:].split("/")
    if len(bits) != 2 or any(part in {"", ".", ".."} for part in bits):
        return None
    owner, repository = bits
    if repository.endswith(".git"):
        repository = repository[:-4]
    if (not owner or not repository or _SAFE.fullmatch(owner) is None or
            _SAFE.fullmatch(repository) is None):
        return None
    return owner.lower(), repository.lower()


def _safe_freshness(value: Any, status: Any = None) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) - _FRESHNESS_KEYS:
        raise HermesProjectError("project frontier freshness is invalid")
    state = value.get("state")
    if state not in {"fresh", "stale", "unavailable"}:
        raise HermesProjectError("project frontier freshness state is invalid")
    result = {"state": state}
    for key in ("observed_at", "attempted_at", "reason"):
        if key in value:
            if value[key] is not None and not isinstance(value[key], str):
                raise HermesProjectError("project frontier freshness is invalid")
            if isinstance(value[key], str) and len(value[key].encode()) > 512:
                raise HermesProjectError("project frontier freshness is oversized")
            result[key] = value[key]
    if "age_seconds" in value:
        age = value["age_seconds"]
        if isinstance(age, bool) or not isinstance(age, (int, float)) or age < 0:
            raise HermesProjectError("project frontier freshness is invalid")
        result["age_seconds"] = age
    normalized = {"fresh": "available", "stale": "stale", "unavailable": "unavailable"}[state]
    if status is not None and status != normalized:
        raise HermesProjectError("project frontier status and freshness disagree")
    return result


def _safe_frontier(value: Mapping[str, Any], descriptor: ProjectDescriptor) -> dict[str, Any]:
    if _contains_private(value):
        raise HermesProjectError("project frontier metadata is private")
    unknown = set(value) - _FRONTIER_KEYS - {"active_task", "active_context"} - _SCHEDULING_KEYS
    if unknown:
        raise HermesProjectError("project frontier metadata is not approved")
    if value.get("schema") != _FRONTIER_SCHEMA:
        raise HermesProjectError("project frontier schema is invalid")
    if value.get("project_id") != descriptor.project_id:
        raise HermesProjectError("project frontier project does not match descriptor")
    if _repo_identity(value.get("repository")) != _repo_identity(descriptor.repository_url):
        raise HermesProjectError("project frontier repository does not match descriptor")
    if value.get("project_revision") != descriptor.revision:
        raise HermesProjectError("project frontier revision does not match descriptor")
    parent = descriptor.issue_tracker.get("parent_issue", descriptor.issue_tracker.get("parent_issue_number"))
    if value.get("parent_issue_number") != parent:
        raise HermesProjectError("project frontier tracker parent does not match descriptor")
    freshness = _safe_freshness(value.get("freshness"), value.get("status"))
    result = {"schema": _FRONTIER_SCHEMA, "project_id": descriptor.project_id,
              "repository": copy.deepcopy(value["repository"]), "project_revision": descriptor.revision,
              "parent_issue_number": parent, "status": {"fresh": "available", "stale": "stale", "unavailable": "unavailable"}[freshness["state"]],
              "freshness": freshness}
    if "active_task" in value and value["active_task"] is not None:
        result["active_task"] = _copy_record(value["active_task"])
    if "active_context" in value:
        if not isinstance(value["active_context"], (list, tuple)):
            raise HermesProjectError("project frontier records are invalid")
        result["active_context"] = [_copy_record(item, retain_body=False) for item in value["active_context"]]
    if result.get("repository") is None or result.get("project_revision") != descriptor.revision:
        raise HermesProjectError("project frontier binding is invalid")
    return result


def _safe_checkout(value: Mapping[str, Any], descriptor: ProjectDescriptor) -> dict[str, Any]:
    if _contains_private(value):
        raise HermesProjectError("isolated checkout metadata is private")
    unknown = set(value) - _CHECKOUT_KEYS
    if unknown:
        raise HermesProjectError("isolated checkout metadata is not approved")
    result = {key: copy.deepcopy(value[key]) for key in _CHECKOUT_KEYS if key in value}
    if set(value) & {"path"} or "checkout_path" not in value:
        raise HermesProjectError("isolated checkout must provide canonical checkout_path")
    if value.get("project_id") != descriptor.project_id or value.get("revision") != descriptor.revision:
        raise HermesProjectError("isolated checkout does not match descriptor")
    result["project_id"] = descriptor.project_id
    result["revision"] = descriptor.revision
    path = result.get("checkout_path")
    if not isinstance(path, str) or not path or "\x00" in path:
        raise HermesProjectError("isolated checkout path is unavailable")
    result["checkout_path"] = path
    return result


def _safe_status(value: Mapping[str, Any]) -> dict[str, Any]:
    if _contains_private(value) or set(value) - _LOCAL_WORK_KEYS:
        raise HermesProjectError("checkout status is not approved")
    state = value.get("state")
    if not isinstance(state, str) or state not in {"clean", "dirty", "stale", "unavailable"}:
        raise HermesProjectError("checkout status state is invalid")
    result = {"state": state}
    for key in ("files", "local_commits"):
        if key in value:
            items = value[key]
            if not isinstance(items, (list, tuple)) or len(items) > 100 or any(not isinstance(x, str) or len(x.encode()) > 512 for x in items):
                raise HermesProjectError("checkout status list is invalid")
            result[key] = list(items)
    return result
