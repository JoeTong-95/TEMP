"""Same-origin, cookie-authenticated boundary for the attended chat browser."""
from __future__ import annotations
from dataclasses import dataclass
import hmac, json, mimetypes, os, re, secrets, sqlite3, time
import subprocess
import stat
from copy import deepcopy
try: import fcntl
except ImportError: fcntl=None
if fcntl is None:
 import msvcrt
from contextlib import contextmanager
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Mapping
from uuid import uuid4
from .attended_chat import AttendedChat, AttendedChatError, AttendedSession
from shared.contracts.agent_runtime import RuntimeOutcomeUnknown

_SAFE=re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z"); _MAX=64*1024
def _safe_identifier(value: Any) -> bool:
 return isinstance(value,str) and _SAFE.fullmatch(value) is not None
class AttendedChatApiError(ValueError): pass

class _FreshSessionCreationLock:
 def __init__(self,path:Path): self.path=Path(path)
 def __enter__(self):
  self.handle=self.path.open("a+")
  if fcntl is not None: fcntl.flock(self.handle.fileno(),fcntl.LOCK_EX)
  else:
   self.handle.seek(0); msvcrt.locking(self.handle.fileno(),msvcrt.LK_LOCK,1)
  return self
 def __exit__(self,*args):
  if fcntl is not None: fcntl.flock(self.handle.fileno(),fcntl.LOCK_UN)
  else:
   self.handle.seek(0); msvcrt.locking(self.handle.fileno(),msvcrt.LK_UNLCK,1)
  self.handle.close()

@dataclass(frozen=True)
class AttendedBrowserSession:
 token: str
 csrf: str
 sessions: frozenset[str]

@dataclass(frozen=True)
class WindowsAclEntry:
 """One normalized Windows ACL entry supplied by the custody adapter."""
 principal: str
 rights: str
 inherited: bool = False

WINDOWS_SYSTEM_SID = "S-1-5-18"
WINDOWS_ADMINISTRATORS_SID = "S-1-5-32-544"

def validate_windows_authorization_custody(entries: Any, *, service_identity: str, required_principals: frozenset[str] | None = None) -> None:
 """Reject every effective ACL entry outside the attended service allowlist.

 The adapter returns normalized entries, making this policy independent of
 ``icacls`` formatting and safe to exercise with fixtures.  Unknown/unresolved
 identities are never accepted, and all allowlisted principals need read/write
 (represented by ``F``, ``M`` or ``W`` in fixture rights).
 """
 required = frozenset({WINDOWS_SYSTEM_SID, WINDOWS_ADMINISTRATORS_SID})
 if required_principals is not None and frozenset(_windows_principal_sid(value) for value in required_principals) != required:
  raise AttendedChatApiError("attended authorization store is unsafe")
 service_identity = _windows_principal_sid(service_identity)
 required = frozenset(_windows_principal_sid(value) for value in required)
 if service_identity in required:
  raise AttendedChatApiError("attended authorization store is unsafe")
 allowed = frozenset({service_identity, *required})
 if not service_identity or any(not isinstance(value, str) or not value for value in allowed):
  raise AttendedChatApiError("attended authorization store custody is unavailable")
 try:
  normalized = tuple(entry if isinstance(entry, WindowsAclEntry) else WindowsAclEntry(str(entry["principal"]), str(entry["rights"]), bool(entry.get("inherited", False))) for entry in entries)
 except (TypeError, KeyError, ValueError):
  raise AttendedChatApiError("attended authorization store custody is unavailable")
 # ACL display names are localized and are not an identity boundary.  Resolve
 # every non-SID principal through the Windows account database before policy
 # comparison; unresolved names fail closed.
 normalized = tuple(WindowsAclEntry(_windows_principal_sid(entry.principal), entry.rights, entry.inherited) for entry in normalized)
 if not normalized or any(not entry.principal or entry.principal not in allowed for entry in normalized):
  raise AttendedChatApiError("attended authorization store is unsafe")
 if frozenset(entry.principal for entry in normalized) != allowed:
  raise AttendedChatApiError("attended authorization store is unsafe")
 # The ACL is deliberately protected and deterministic.  An inherited ACE is
 # not accepted even when its principal is allowlisted: inheritance can change
 # when a parent directory is modified and would make custody non-repeatable.
 if any(entry.inherited for entry in normalized):
  raise AttendedChatApiError("attended authorization store is unsafe")
 # A deny ACE is never effective custody, even when its rights text also
 # contains F or M.  Reject it before looking for the allow rights markers so
 # contradictory or deny-only descriptors cannot satisfy the allowlist.
 if any("DENY" in entry.rights.upper() for entry in normalized):
  raise AttendedChatApiError("attended authorization store is unsafe")
 # F (full control) and M (modify) provide durable read/write access. W is
 # write-only and R/RX are read-only, so neither is sufficient for custody.
 if any(not entry.rights or not any(marker in entry.rights.upper() for marker in ("F", "M")) for entry in normalized):
  raise AttendedChatApiError("attended authorization store is unsafe")

def _windows_owner_sid(path: Path) -> str:
 """Return the actual owner SID from the file security descriptor."""
 try:
  import ctypes
  from ctypes import wintypes
  security_info_owner = 1
  owner = ctypes.c_void_p()
  descriptor = ctypes.c_void_p()
  result = ctypes.windll.advapi32.GetNamedSecurityInfoW(
   str(path), 1, security_info_owner, ctypes.byref(owner), None, None, None,
   ctypes.byref(descriptor))
  if result:
   raise OSError(result, "GetNamedSecurityInfoW")
  sid_text = ctypes.c_wchar_p()
  if not ctypes.windll.advapi32.ConvertSidToStringSidW(owner, ctypes.byref(sid_text)):
   raise OSError(ctypes.GetLastError(), "ConvertSidToStringSidW")
  try: return sid_text.value
  finally: ctypes.windll.kernel32.LocalFree(sid_text)
 except (AttributeError, OSError, TypeError, ValueError) as error:
  raise AttendedChatApiError("attended authorization store custody is unavailable") from error

def _current_process_sid() -> str:
 try:
  return subprocess.run(["whoami", "/user", "/fo", "csv", "/nh"], capture_output=True, text=True, check=True).stdout.strip().split(",")[-1].strip('"')
 except (OSError, subprocess.SubprocessError, IndexError):
  raise AttendedChatApiError("attended authorization store custody is unavailable")

def _validated_process_sid(provider: Callable[[], str] | None = None) -> str:
 """Resolve the process/token SID used as the sole identity trust anchor."""
 try:
  value = (provider or _current_process_sid)()
 except AttendedChatApiError:
  raise
 except Exception as error:
  raise AttendedChatApiError("attended authorization store custody is unavailable") from error
 return _windows_principal_sid(value)

def _windows_principal_sid(principal: str) -> str:
 """Canonicalize an ACL principal to a SID, independent of localization."""
 if re.fullmatch(r"S-\d+(?:-\d+)+", principal or "", re.IGNORECASE):
  if os.name != "nt":
   return principal.upper()
  try:
   import ctypes
   from ctypes import wintypes
   sid = principal.upper()
   convert = ctypes.windll.advapi32.ConvertStringSidToSidW
   convert.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_void_p)]
   convert.restype = wintypes.BOOL
   pointer = ctypes.c_void_p()
   if not convert(sid, ctypes.byref(pointer)):
    raise OSError(ctypes.get_last_error(), "ConvertStringSidToSidW")
   try:
    if not ctypes.windll.advapi32.IsValidSid(pointer):
     raise OSError("IsValidSid")
    return sid
   finally:
    ctypes.windll.kernel32.LocalFree(pointer)
  except (AttributeError, OSError, TypeError, ValueError, OverflowError) as error:
   raise AttendedChatApiError("attended authorization store custody is unavailable") from error
 if principal and principal.upper().startswith("S-"):
  raise AttendedChatApiError("attended authorization store custody is unavailable")
 if os.name != "nt":
  # Deterministic adapters/tests may already provide a stable non-SID token.
  return principal
 try:
  import ctypes
  from ctypes import wintypes
  advapi = ctypes.windll.advapi32
  lookup = advapi.LookupAccountNameW
  sid_size, domain_size = wintypes.DWORD(0), wintypes.DWORD(0)
  lookup(None, principal, None, ctypes.byref(sid_size), None, ctypes.byref(domain_size), ctypes.byref(wintypes.DWORD()))
  sid = (ctypes.c_byte * sid_size.value)()
  domain = ctypes.create_unicode_buffer(domain_size.value or 1)
  use = wintypes.DWORD()
  if not lookup(None, principal, ctypes.byref(sid), ctypes.byref(sid_size), domain, ctypes.byref(domain_size), ctypes.byref(use)):
   raise OSError(ctypes.get_last_error(), "LookupAccountNameW")
  text_sid = ctypes.c_wchar_p()
  if not advapi.ConvertSidToStringSidW(ctypes.byref(sid), ctypes.byref(text_sid)):
   raise OSError(ctypes.get_last_error(), "ConvertSidToStringSidW")
  try: return text_sid.value.upper()
  finally: ctypes.windll.kernel32.LocalFree(text_sid)
 except (AttributeError, OSError, TypeError, ValueError, OverflowError) as error:
  raise AttendedChatApiError("attended authorization store custody is unavailable") from error

def _default_windows_acl_query(path: Path) -> tuple[tuple[WindowsAclEntry, ...], str]:
 """Query and normalize the ACL for one file; never changes host ACL state."""
 try:
  output = subprocess.run(["icacls", str(path)], capture_output=True, text=True, check=True).stdout
  owner = _windows_owner_sid(path)
  username = subprocess.run(["whoami"], capture_output=True, text=True, check=True).stdout.strip()
 except (OSError, subprocess.SubprocessError, IndexError):
  raise AttendedChatApiError("attended authorization store custody is unavailable")
 entries: list[WindowsAclEntry] = []
 ace_pattern = re.compile(r"(?<!\S)(?P<principal>(?:(?:NT AUTHORITY|BUILTIN)\\[^\s:]+|[^\s:]+\\[^\s:]+|S-\d+(?:-\d+)+|[^\s:]+)):(?P<rights>(?:\([^)]*\))+)")
 for line in output.splitlines():
  # The first ACE may share the path line.  Requiring an ACE principal to
  # start at whitespace prevents a drive/path prefix (including spaces) from
  # becoming part of the principal.
  matches = tuple(ace_pattern.finditer(line))
  if not matches:
   continue
  match = matches[-1]
  principal, rights = match.group("principal"), match.group("rights")
  # icacls names are stable enough for the built-in principals; unresolved
  # identities remain visible as their literal name and fail the allowlist.
  principal_name = principal.strip()
  principal = {"nt authority\\system": WINDOWS_SYSTEM_SID, "builtin\\administrators": WINDOWS_ADMINISTRATORS_SID, username.lower(): owner}.get(principal_name.lower(), principal_name)
  entries.append(WindowsAclEntry(principal, rights.strip(), "(I)" in rights))
 if not owner:
  raise AttendedChatApiError("attended authorization store custody is unavailable")
 return tuple(entries), owner

def _default_windows_acl_create(path: Path, service_identity: str) -> None:
 """Create a file with a protected allowlist in its initial security descriptor."""
 descriptor = None
 try:
  import ctypes
  from ctypes import wintypes
  advapi = ctypes.windll.advapi32
  kernel32 = ctypes.windll.kernel32
  convert = advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW
  convert.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.ULONG)]
  convert.restype = wintypes.BOOL
  create_file = kernel32.CreateFileW
  create_file.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
  create_file.restype = wintypes.HANDLE
  close_handle = kernel32.CloseHandle
  close_handle.argtypes = [wintypes.HANDLE]
  close_handle.restype = wintypes.BOOL
  local_free = kernel32.LocalFree
  local_free.argtypes = [wintypes.HLOCAL]
  local_free.restype = wintypes.HLOCAL
  descriptor = ctypes.c_void_p()
  # Protected DACL; no inherited/default ACE exists during construction.
  sddl = f"D:P(A;;FA;;;{service_identity})(A;;FA;;;{WINDOWS_SYSTEM_SID})(A;;FA;;;{WINDOWS_ADMINISTRATORS_SID})"
  if not convert(sddl, 1, ctypes.byref(descriptor), None):
   raise OSError(ctypes.GetLastError(), "ConvertStringSecurityDescriptorToSecurityDescriptorW")
  class SecurityAttributes(ctypes.Structure):
   _fields_ = [("nLength", wintypes.DWORD), ("lpSecurityDescriptor", wintypes.LPVOID), ("bInheritHandle", wintypes.BOOL)]
  attributes = SecurityAttributes(ctypes.sizeof(SecurityAttributes), descriptor, False)
  handle = wintypes.HANDLE()
  try:
   handle = create_file(str(path), 0xC0000000, 0, ctypes.byref(attributes), 1, 0x80, None)
   # ctypes HANDLE results vary by Python/Windows ABI (int, HANDLE, or
   # c_void_p).  Compare the pointer value, not the wrapper object.
   raw_handle = getattr(handle, "value", handle)
   if raw_handle is not None:
    raw_handle = int(raw_handle)
   invalid_handle = ctypes.c_void_p(-1).value
   if raw_handle in (None, 0, -1, invalid_handle):
    error = ctypes.get_last_error() or ctypes.WinError().winerror
    if error in (80, 183):
     raise FileExistsError(error, "CreateFileW", str(path))
    raise OSError(error, "CreateFileW")
  finally:
   raw_handle = getattr(handle, "value", handle)
   if raw_handle not in (None, 0, -1, ctypes.c_void_p(-1).value):
    close_handle(handle)
 except FileExistsError:
  raise
 except (AttributeError, OSError, TypeError, ValueError) as error:
  raise AttendedChatApiError("attended authorization store cannot be created") from error
 finally:
  if descriptor:
   local_free(descriptor)

def _default_windows_acl_harden(path: Path, service_identity: str) -> None:
 try:
  subprocess.run(["icacls", str(path), "/inheritance:r", "/grant:r", f"*{service_identity}:F", f"*{WINDOWS_SYSTEM_SID}:F", f"*{WINDOWS_ADMINISTRATORS_SID}:F"], capture_output=True, text=True, check=True)
  # Some localized Windows builds report a successful multi-grant while
  # dropping the built-in Administrators ACE; add that required ACE directly.
  subprocess.run(["icacls", str(path), "/grant", f"*{WINDOWS_ADMINISTRATORS_SID}:F"], capture_output=True, text=True, check=True)
 except (OSError, subprocess.SubprocessError) as error:
  raise AttendedChatApiError("attended authorization store custody is unavailable") from error

def _is_reparse_point(path: Path) -> bool:
 """Detect symlinks, junctions, and other Windows reparse points without following them."""
 try:
  if path.is_symlink(): return True
  attributes = getattr(path.lstat(), "st_file_attributes", 0)
  return bool(attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
 except FileNotFoundError:
  return False
 except OSError:
  return True

class AttendedAuthorizationStore:
 """Durable server-owned grants for fresh attended sessions."""
 def __init__(self, database: Path, grants: Mapping[str, Any], *, windows_acl_query: Callable[[Path], Any] | None = None, windows_acl_harden: Callable[[Path, str], None] | None = None, windows_acl_create: Callable[[Path, str], None] | None = None, windows_service_identity: str | None = None, windows_required_principals: frozenset[str] | None = None, windows_process_sid_provider: Callable[[], str] | None = None):
  self.database=Path(database)
  if not self.database.is_absolute() or _is_reparse_point(self.database) or not self.database.parent.is_dir() or any(_is_reparse_point(parent) for parent in self.database.parents): raise AttendedChatApiError("attended authorization store is unsafe")
  created=False
  process_identity = _validated_process_sid(windows_process_sid_provider) if os.name == "nt" else None
  if os.name == "nt" and windows_service_identity is not None and _windows_principal_sid(windows_service_identity) != process_identity:
   raise AttendedChatApiError("attended authorization store custody identity mismatch")
  identity = _windows_principal_sid(windows_service_identity) if windows_service_identity is not None else process_identity
  if not self.database.exists():
   try:
    if os.name == "nt":
     creator = windows_acl_create or _default_windows_acl_create
     if not identity:
      # Creation requires the intended service SID in the initial descriptor;
      # the default adapter cannot safely guess it from the process identity.
      raise AttendedChatApiError("attended authorization store custody is unavailable")
     creator(self.database, identity)
     if not self.database.exists():
      raise AttendedChatApiError("attended authorization store cannot be created")
    else:
     fd=os.open(self.database,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600); os.close(fd)
    created=True
   except FileExistsError: pass
   except AttendedChatApiError:
    raise
   except OSError as error:
    if getattr(error, "winerror", None) in (80, 183):
     pass
    else:
     raise AttendedChatApiError("attended authorization store cannot be created") from error
   except Exception:
    raise
  if _is_reparse_point(self.database): raise AttendedChatApiError("attended authorization store is unsafe")
  if os.name == "posix" and created: self.database.chmod(0o600)
  if self.database.exists() and os.name == "posix" and self.database.stat().st_mode & 0o077: raise AttendedChatApiError("attended authorization store is unsafe")
  if os.name == "nt":
   query = windows_acl_query or _default_windows_acl_query
   harden = windows_acl_harden or _default_windows_acl_harden
   try:
    def checked_query() -> Any:
     result = query(self.database)
     if not isinstance(result, tuple) or len(result) != 2 or not isinstance(result[1], str) or not result[1]:
      raise AttendedChatApiError("attended authorization store owner evidence is unavailable")
     result_entries, queried_owner = result
     if _windows_principal_sid(queried_owner) != _windows_principal_sid(identity):
      raise AttendedChatApiError("attended authorization store owner is unsafe")
     return result_entries
    entries = checked_query() if not created else ()
    if created:
     # The Win32 creator already installed the protected descriptor atomically.
     # Legacy/custom creators may still request a post-create hardening pass.
     if windows_acl_create is None:
      harden(self.database, identity)
    entries = checked_query()
    validate_windows_authorization_custody(entries, service_identity=identity, required_principals=windows_required_principals)
   except Exception:
    raise
  with self._connection() as db:
   db.execute("CREATE TABLE IF NOT EXISTS attended_grants(grant_id TEXT PRIMARY KEY,principal TEXT NOT NULL,operation TEXT NOT NULL,project_id TEXT NOT NULL,expires_at TEXT,revoked INTEGER NOT NULL DEFAULT 0,revision INTEGER NOT NULL DEFAULT 1,session_id TEXT)")
   columns={row[1] for row in db.execute("PRAGMA table_info(attended_grants)")}
   if "revocation_source" not in columns:
    db.execute("ALTER TABLE attended_grants ADD COLUMN revocation_source TEXT NOT NULL DEFAULT 'operator'")
   configured_ids=set()
   for values in grants.values():
    configured_ids.update(grant["grant_id"] for grant in values)
   # Configuration is the authority.  A grant removed from configuration must
   # not remain usable merely because it was present in an older process.
   if configured_ids:
    db.execute("UPDATE attended_grants SET revoked=1,revision=revision+1,revocation_source='configuration' WHERE revoked=0 AND grant_id NOT IN (%s)" % ",".join("?" for _ in configured_ids), tuple(configured_ids))
   else:
    db.execute("UPDATE attended_grants SET revoked=1,revision=revision+1,revocation_source='configuration' WHERE revoked=0")
   for principal, values in grants.items():
    for grant in values:
     revoked=int(grant.get("revoked",False)); source="configuration"
     db.execute("INSERT INTO attended_grants(grant_id,principal,operation,project_id,expires_at,revoked,revision,revocation_source) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(grant_id) DO UPDATE SET principal=excluded.principal,operation=excluded.operation,project_id=excluded.project_id,expires_at=excluded.expires_at,revoked=CASE WHEN attended_grants.revoked=1 AND attended_grants.revocation_source='operator' THEN 1 ELSE excluded.revoked END,revision=CASE WHEN attended_grants.revoked=1 AND attended_grants.revocation_source='operator' THEN attended_grants.revision ELSE excluded.revision END,revocation_source=CASE WHEN attended_grants.revoked=1 AND attended_grants.revocation_source='operator' THEN 'operator' ELSE excluded.revocation_source END", (grant["grant_id"],principal,grant["operation"],grant["project_id"],grant.get("expires_at"),revoked,grant.get("revision",1),source))
 def authorize(self, principal: str, grant_id: str, operation: str, project_id: str) -> dict[str, Any]:
  with self._connection() as db:
   db.row_factory=sqlite3.Row
   row=db.execute("SELECT * FROM attended_grants WHERE grant_id=? AND principal=? AND operation=? AND project_id=?",(grant_id,principal,operation,project_id)).fetchone()
  if row is None or row["revoked"]:
   raise AttendedChatApiError("fresh-session grant is not authorized")
  if row["expires_at"] is not None:
   try:
    expiry=datetime.fromisoformat(row["expires_at"].replace("Z","+00:00"))
    expired=expiry.tzinfo is None or expiry <= datetime.now(timezone.utc)
   except (TypeError,ValueError): expired=True
   if expired: raise AttendedChatApiError("fresh-session grant is expired")
  return dict(row)
 def authorize_session(self, principal: str, session_id: str) -> bool:
  with self._connection() as db:
   db.row_factory=sqlite3.Row
   rows=db.execute("SELECT * FROM attended_grants WHERE principal=? AND session_id=?",(principal,session_id)).fetchall()
  if not rows:return False
  for row in rows:
   try:
    if not row["revoked"] and (row["expires_at"] is None or (datetime.fromisoformat(row["expires_at"].replace("Z","+00:00")).tzinfo is not None and datetime.fromisoformat(row["expires_at"].replace("Z","+00:00")) > datetime.now(timezone.utc))): return True
   except (TypeError,ValueError): pass
  return False
 def reserve(self, principal: str, grant_id: str, operation: str, project_id: str, session_id: str) -> dict[str,Any]:
  with self._connection() as db:
   db.row_factory=sqlite3.Row; db.execute("BEGIN IMMEDIATE")
   row=db.execute("SELECT * FROM attended_grants WHERE grant_id=? AND principal=? AND operation=? AND project_id=?",(grant_id,principal,operation,project_id)).fetchone()
   if row is None or row["revoked"]: raise AttendedChatApiError("fresh-session grant is not authorized")
   if row["expires_at"] is not None:
    try:
     expiry=datetime.fromisoformat(row["expires_at"].replace("Z","+00:00"))
     if expiry.tzinfo is None or expiry <= datetime.now(timezone.utc): raise AttendedChatApiError("fresh-session grant is expired")
    except (TypeError,ValueError): raise AttendedChatApiError("fresh-session grant expiry is invalid")
   if row["session_id"] is None: db.execute("UPDATE attended_grants SET session_id=? WHERE grant_id=?",(session_id,grant_id)); return {**dict(row),"session_id":session_id}
   return dict(row)
 def attach(self, grant_id: str, session_id: str) -> None:
  with self._connection() as db: db.execute("UPDATE attended_grants SET session_id=? WHERE grant_id=?",(session_id,grant_id))
 def release(self, grant_id: str, session_id: str) -> None:
  with self._connection() as db: db.execute("UPDATE attended_grants SET session_id=NULL WHERE grant_id=? AND session_id=?",(grant_id,session_id))
 def revoke(self, grant_id: str) -> None:
  with self._connection() as db: db.execute("UPDATE attended_grants SET revoked=1,revision=revision+1,revocation_source='operator' WHERE grant_id=?",(grant_id,))
 def sessions(self, principal: str) -> frozenset[str]:
  with self._connection() as db: return frozenset(row[0] for row in db.execute("SELECT session_id FROM attended_grants WHERE principal=? AND session_id IS NOT NULL",(principal,)))
 def reservations(self, principal: str) -> list[dict[str, Any]]:
  with self._connection() as db:
   db.row_factory=sqlite3.Row
   return [dict(row) for row in db.execute("SELECT * FROM attended_grants WHERE principal=? AND session_id IS NOT NULL", (principal,)).fetchall()]
 def all_reservations(self) -> list[dict[str, Any]]:
  with self._connection() as db:
   db.row_factory=sqlite3.Row
   return [dict(row) for row in db.execute("SELECT * FROM attended_grants WHERE session_id IS NOT NULL ORDER BY grant_id").fetchall()]
 @contextmanager
 def _connection(self):
  db=sqlite3.connect(self.database)
  try:
   yield db
   db.commit()
  finally: db.close()

class AttendedChatHttpService:
 """A deliberately narrow local host; browser code never sees runtime tokens."""
 def __init__(self,chat:AttendedChat,token_file:Path,*,memory_context:Callable[[str],Mapping[str,str]|None]|None=None,secure_cookie:bool=False,static_root:Path|None=None,authorization_database:Path|None=None,windows_acl_query:Callable[[Path],Any]|None=None,windows_acl_harden:Callable[[Path,str],None]|None=None,windows_acl_create:Callable[[Path,str],None]|None=None,windows_service_identity:str|None=None,windows_required_principals:frozenset[str]|None=None,windows_process_sid_provider:Callable[[],str]|None=None):
  self.chat=chat;self.token_file=Path(token_file);self.memory_context=memory_context
  if not self.token_file.is_absolute() or self.token_file.is_symlink() or not self.token_file.is_file() or any(parent.is_symlink() for parent in self.token_file.parents):raise AttendedChatApiError("attended browser token file is unsafe")
  if os.name=="posix" and self.token_file.stat().st_mode&0o077:raise AttendedChatApiError("attended browser token file is unsafe")
  try: raw=json.loads(self.token_file.read_text(encoding="utf-8"))
  except (OSError,ValueError) as e:raise AttendedChatApiError("attended browser tokens are unavailable") from e
  if not isinstance(raw,Mapping):raise AttendedChatApiError("attended browser tokens are invalid")
  root=Path(static_root) if static_root is not None else Path(__file__).resolve().parents[2]/"ui"/"workflow-studio"/"dist"
  if not root.is_absolute() or root.is_symlink() or not root.is_dir() or any(parent.is_symlink() for parent in root.parents):raise AttendedChatApiError("attended UI static root is unsafe")
  self.static_root=root.resolve();self.sessions=[];self.live_sessions={};self.secure_cookie=secure_cookie;self.authorization=None;self.configured_session_ids=set()
  configured_grants={}
  for token,value in raw.items():
   if not isinstance(token,str) or not isinstance(value,Mapping) or not {"csrf","sessions"}.issubset(value) or set(value)-{"csrf","sessions","grants"} or not isinstance(value["csrf"],str) or not _SAFE.fullmatch(value["csrf"]) or not isinstance(value["sessions"],list) or not value["sessions"] or any(not isinstance(key,str) or key not in chat.config.sessions for key in value["sessions"]):raise AttendedChatApiError("attended browser tokens are invalid")
   raw_grants=value.get("grants",[])
   if not isinstance(raw_grants,list): raise AttendedChatApiError("attended browser grants are invalid")
   parsed=[]
   for grant in raw_grants:
    if not isinstance(grant,Mapping) or set(grant)-{"grant_id","operation","project_id","expires_at","revoked","revision"} or not all(isinstance(grant.get(k),str) and _SAFE.fullmatch(grant[k]) for k in ("grant_id","operation","project_id")) or (grant.get("expires_at") is not None and not isinstance(grant["expires_at"],str)) or type(grant.get("revoked",False)) is not bool or type(grant.get("revision",1)) is not int or grant.get("revision",1)<1: raise AttendedChatApiError("attended browser grants are invalid")
    parsed.append(dict(grant))
   configured_grants[token]=parsed
   self.sessions.append(AttendedBrowserSession(token,value["csrf"],frozenset(value["sessions"])))
   self.configured_session_ids.update(value["sessions"])
  def validate_registry_session(session_id, session, *, expected_project=None, require_browser_owner=False):
   """Fail closed if a loaded attended session is absent or inconsistent."""
   if session is None or getattr(session, "session_id", None) != session_id:
    raise AttendedChatApiError("attended session registry recovery is incomplete")
   try:
    record=chat.registry.get(session_id,actor_role="controller",caller_projects=frozenset({session.project_id}))
    identity=record.get("agent_identity")
    valid=(record.get("session_id") == session_id and record.get("native_home_id") == session_id and
           record.get("project_id") == session.project_id and
           (expected_project is None or record.get("project_id") == expected_project) and
           record.get("binding_id") == session.runtime_binding_id and record.get("workspace") == "attended" and
           isinstance(record.get("owner_id"),str) and bool(record.get("owner_id")) and isinstance(identity,Mapping) and
           (not require_browser_owner or (identity.get("agent_id") == session_id and identity.get("kind") == "attended")) and
           record.get("desired_status") in {"active","paused"})
   except Exception as error:
    raise AttendedChatApiError("attended session registry recovery is incomplete") from error
   if not valid:
    raise AttendedChatApiError("attended session registry recovery is incomplete")

  # Every configured or descriptor-preloaded session must have a valid
  # registry row before the HTTP boundary becomes available.  Reservation
  # recovery below additionally handles rows whose descriptor was not loaded.
  for session in chat.sessions.values():
   validate_registry_session(session.session_id,session)
  if authorization_database is not None:
   self.authorization=AttendedAuthorizationStore(authorization_database,configured_grants,windows_acl_query=windows_acl_query,windows_acl_harden=windows_acl_harden,windows_acl_create=windows_acl_create,windows_service_identity=windows_service_identity,windows_required_principals=windows_required_principals,windows_process_sid_provider=windows_process_sid_provider)
   self.creation_lock=_FreshSessionCreationLock(Path(authorization_database).with_suffix(".creation.lock"))
   # Reclaim reservations left behind by a crash between registry registration
   # and descriptor persistence.  A durable descriptor is the commit point.
   with self.creation_lock:
    for reservation in self.authorization.all_reservations():
     session_id=reservation["session_id"]
     descriptor=self.chat.persisted_descriptor_status(session_id)
     # A committed descriptor (and even a configured/static session) is not
     # trusted merely because it was loaded into memory.  Validate its
     # registry row on every startup; this also permits replay when the
     # runtime binding is temporarily unavailable.
     if descriptor=="valid" or any(session.session_id == session_id for session in self.chat.sessions.values()):
      session=self.chat.persisted_descriptor(session_id) or self.chat.sessions.get(session_id)
      validate_registry_session(session_id,session,expected_project=reservation["project_id"],require_browser_owner=True)
      continue
     if descriptor=="invalid": self.chat.remove_persisted_descriptor(session_id)
     try:
      # Registry removal is the first commit point.  If it cannot be completed,
      # retain the reservation and fail startup so retry remains observable.
      self.chat.registry.remove(session_id, actor_role="controller", caller_projects=frozenset({reservation["project_id"]}))
     except Exception as error:
      raise AttendedChatApiError("abandoned fresh-session registry recovery is incomplete") from error
     self.authorization.release(reservation["grant_id"], session_id)
 def authenticate(self,cookie_header:str|None,session_id:str,csrf:str|None=None)->AttendedBrowserSession:
  try: cookie=SimpleCookie(cookie_header or ""); token=cookie.get("attended_session").value if cookie.get("attended_session") else ""
  except Exception:token=""
  found=self.live_sessions.get(token)
  if found is None or session_id not in found.sessions:raise AttendedChatApiError("local human session is required")
  if self.authorization is not None and session_id not in self.configured_session_ids and not self.authorization.authorize_session(found.token,session_id): raise AttendedChatApiError("attended session authorization is no longer valid")
  if csrf is not None and not hmac.compare_digest(csrf,found.csrf):raise AttendedChatApiError("CSRF validation failed")
  return found
 def login(self,secret:str):
  found=next((value for value in self.sessions if hmac.compare_digest(secret,value.token)),None)
  if found is None:raise AttendedChatApiError("local human session is required")
  sessions=found.sessions if self.authorization is None else found.sessions|self.authorization.sessions(found.token)
  token=secrets.token_urlsafe(32);self.live_sessions[token]=AttendedBrowserSession(found.token,found.csrf,sessions);return token,self.live_sessions[token]
 def logout(self,token:str):self.live_sessions.pop(token,None)
 def grant(self,token:str,session_id:str,*,grant_id:str|None=None)->None:
  found=self.live_sessions.get(token)
  if found is None or session_id not in self.chat.sessions: raise AttendedChatApiError("local human session is required")
  self.live_sessions[token]=AttendedBrowserSession(found.token,found.csrf,frozenset((*found.sessions,session_id)))
  if self.authorization is not None and grant_id is not None:self.authorization.attach(grant_id,session_id)

 def authorize_fresh(self, token: str, project_id: str, grant_id: str|None, operation: str|None) -> dict[str,Any]|None:
  if self.authorization is None: raise AttendedChatApiError("fresh-session authorization is required")
  found=self.live_sessions.get(token)
  if found is None or not isinstance(grant_id,str) or not isinstance(operation,str): raise AttendedChatApiError("fresh-session authorization is required")
  return self.authorization.authorize(found.token,grant_id,operation,project_id)

def make_handler(service:AttendedChatHttpService):
 class Handler(BaseHTTPRequestHandler):
  server_version="AttendedChat/1"; sys_version=""
  def log_message(self,*args:Any)->None: return
  def _reply(self,status:HTTPStatus,value:Mapping[str,Any])->None:
   raw=json.dumps(value,separators=(",",":"),allow_nan=False).encode();self.send_response(status);self.send_header("Content-Type","application/json");self.send_header("Cache-Control","no-store");self.send_header("X-Content-Type-Options","nosniff");self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
  def _static(self):
   raw_path=self.path.split("?",1)[0]
   if not raw_path.startswith("/") or "\\" in raw_path or "%" in raw_path:self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"});return
   relative=raw_path.lstrip("/") or "index.html"
   if any((service.static_root/Path(*relative.split("/")[:index])).is_symlink() for index in range(1,len(relative.split("/"))+1)):self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"});return
   candidate=(service.static_root/relative).resolve()
   try:candidate.relative_to(service.static_root)
   except ValueError:self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"});return
   # SPA routes are deliberately only the extensionless paths; missing assets
   # fail rather than silently becoming HTML.
   if not candidate.is_file() and "." not in Path(relative).name:candidate=service.static_root/"index.html"
   if not candidate.is_file() or candidate.is_symlink():self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"});return
   try: raw=candidate.read_bytes()
   except OSError:self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"});return
   content=mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
   self.send_response(HTTPStatus.OK);self.send_header("Content-Type",content);self.send_header("Content-Length",str(len(raw)));self.send_header("Cache-Control","no-store");self.send_header("X-Content-Type-Options","nosniff");self.send_header("Content-Security-Policy","default-src 'self'; base-uri 'none'; frame-ancestors 'none'; object-src 'none'");self.end_headers();self.wfile.write(raw)
  def _route(self):
   pieces=self.path.split("?",1)[0].strip("/").split("/")
   if len(pieces)>=3 and pieces[:2]==["chat","sessions"] and _SAFE.fullmatch(pieces[2]):return pieces[2],pieces[3:]
   return None
  def _body(self):
   length=int(self.headers.get("Content-Length","-1"))
   if not 0<=length<=_MAX:raise AttendedChatApiError("request is too large")
   value=json.loads(self.rfile.read(length) or b"{}")
   if not isinstance(value,Mapping):raise AttendedChatApiError("request must be an object")
   return value
  def do_GET(self):
   route=self._route()
   if route is None:self._static();return
   if route[1] not in ([],["context"]):self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"});return
   try:
    browser=service.authenticate(self.headers.get("Cookie"),route[0]);value=service.chat.inspect_context(route[0]) if route[1]==["context"] else {**service.chat.status(route[0]),"csrf":browser.csrf};self._reply(HTTPStatus.OK,value)
   except AttendedChatApiError as e:self._reply(HTTPStatus.UNAUTHORIZED,{"error":str(e)})
   except AttendedChatError as e:self._reply(HTTPStatus.CONFLICT,{"error":str(e)})
  def do_POST(self):
   if self.path.split("?",1)[0]=="/chat/login":
    try:
     body=self._body()
     if set(body)!={"bootstrap_secret"} or not isinstance(body["bootstrap_secret"],str):raise AttendedChatApiError("login request is invalid")
     token,browser=service.login(body["bootstrap_secret"]);raw=json.dumps({"csrf":browser.csrf,"sessions":sorted(browser.sessions)},separators=(",",":")) .encode();self.send_response(HTTPStatus.OK);self.send_header("Content-Type","application/json");self.send_header("Cache-Control","no-store");self.send_header("Set-Cookie",f"attended_session={token}; HttpOnly; SameSite=Strict; Path=/"+("; Secure" if service.secure_cookie else ""));self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
    except (AttendedChatApiError,ValueError,UnicodeError) as e:self._reply(HTTPStatus.BAD_REQUEST,{"error":str(e)})
    return
   if self.path.split("?",1)[0]=="/chat/logout":
    cookie=SimpleCookie(self.headers.get("Cookie", ""));service.logout(cookie.get("attended_session").value if cookie.get("attended_session") else "");self.send_response(HTTPStatus.NO_CONTENT);self.send_header("Set-Cookie","attended_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"+("; Secure" if service.secure_cookie else ""));self.end_headers();return
   route=self._route()
   if route is None or len(route[1])!=1 or route[1][0] not in {"messages","pause","reconcile","binding","fresh","blank","compact"}:self._reply(HTTPStatus.NOT_FOUND,{"error":"not_found"});return
   session_id,action=route[0],route[1][0]
   try:
    body=self._body()
    if self.headers.get("X-CSRF-Token") is None:raise AttendedChatApiError("CSRF validation failed")
    if action=="fresh":
     if set(body)-{"project_id","revision_id","context_id","context_sources","context_fields","context_token_limit","context_guidance","grant_id","operation"} or not {"project_id","revision_id","context_id"}.issubset(body):raise AttendedChatApiError("fresh project request is invalid")
     if not all(_safe_identifier(body.get(field)) for field in ("project_id","revision_id","context_id")):
      raise AttendedChatApiError("fresh project request is invalid")
     if any(field in body and not _safe_identifier(body[field]) for field in ("grant_id","operation")):
      raise AttendedChatApiError("fresh project request is invalid")
     # Authenticate before consulting the project resolver.  Missing, stale,
     # and resolvable projects are intentionally indistinguishable to callers
     # without a valid browser session and CSRF token.
     try:
      service.authenticate(self.headers.get("Cookie"),session_id,self.headers.get("X-CSRF-Token"))
     except AttendedChatApiError as error:
      self._reply(HTTPStatus.UNAUTHORIZED,{"error":str(error)});return
     cookie=SimpleCookie(self.headers.get("Cookie", ""));cookie_token=cookie.get("attended_session").value if cookie.get("attended_session") else ""
    if action != "fresh":
     service.authenticate(self.headers.get("Cookie"),session_id,self.headers.get("X-CSRF-Token"))
    if action=="fresh":
     with service.creation_lock:
      grant=service.authorize_fresh(cookie_token,body["project_id"],body.get("grant_id"),body.get("operation"))
      reserved=False
      if grant is not None and grant.get("session_id") is None:
       grant=service.authorization.reserve(service.live_sessions[cookie_token].token,body["grant_id"],body["operation"],body["project_id"],f"{body['project_id']}.{uuid4().hex[:12]}")
       reserved=True
      if grant is not None and grant.get("session_id") and not reserved:
       for _ in range(100):
        if grant["session_id"] in service.chat.sessions: break
        time.sleep(.01)
       if grant["session_id"] not in service.chat.sessions: raise AttendedChatApiError("fresh-session grant points to an unknown session")
       persisted=service.chat.persisted_descriptor(grant["session_id"])
       if persisted is None:
        raise AttendedChatApiError("fresh-session replay does not match persisted session: descriptor")
       # Compare the complete effective descriptor.  Optional request fields
       # use the same defaults as creation, so an omitted field still replays
       # safely while a changed field cannot reuse the durable grant.
       try:
        candidate=AttendedSession(persisted.session_id,body["project_id"],body["revision_id"],persisted.runtime_binding_id,persisted.model_id,persisted.model_revision,body["context_id"],persisted.memory_scope,body.get("context_sources") if body.get("context_sources") is not None else persisted.context_sources,body.get("context_fields") if body.get("context_fields") is not None else persisted.context_fields,body.get("context_token_limit") if body.get("context_token_limit") is not None else persisted.context_token_limit,body.get("context_guidance") if body.get("context_guidance") is not None else persisted.context_guidance)
       except (AttendedChatError, TypeError, ValueError) as error:
        raise AttendedChatApiError("fresh-session replay does not match persisted session: descriptor") from error
       expected={
        "project_id":candidate.project_id,"revision_id":candidate.revision_id,"context_id":candidate.compatible_context,
        "context_sources":list(candidate.context_sources),"context_fields":candidate.context_fields,
        "context_token_limit":candidate.context_token_limit,"context_guidance":candidate.context_guidance,
       }
       actual={
        "project_id":persisted.project_id,"revision_id":persisted.revision_id,"context_id":persisted.compatible_context,
        "context_sources":list(persisted.context_sources),"context_fields":persisted.context_fields,
        "context_token_limit":persisted.context_token_limit,"context_guidance":persisted.context_guidance,
       }
       mismatches=[key for key in expected if expected[key] != actual[key]]
       if mismatches:
        raise AttendedChatApiError("fresh-session replay does not match persisted session: " + ", ".join(mismatches))
       self._reply(HTTPStatus.OK,{"old_session_id":session_id,"new_session_id":persisted.session_id,"project_id":persisted.project_id,"revision_id":persisted.revision_id,"context_id":persisted.compatible_context,"context_sources":list(persisted.context_sources),"context_fields":deepcopy(dict(persisted.context_fields)),"context_token_limit":persisted.context_token_limit,"context_guidance":persisted.context_guidance,"state":"idle","replayed":True});return
      # The reservation is now the durable authorization commit point.  Pass
      # raw caller hints to core; it performs the single authoritative
      # resolution while this process-wide creation lock excludes duplicates.
      try:
       value=service.chat.fresh_with_project(session_id,body["project_id"],body["revision_id"],body["context_id"],context_sources=body.get("context_sources"),context_fields=body.get("context_fields"),context_token_limit=body.get("context_token_limit"),context_guidance=body.get("context_guidance"),new_session_id=grant.get("session_id") if grant is not None else None)
      except Exception:
       # A reservation is released only after both durable recovery records
       # are gone.  If either cleanup step failed, startup can retry it.
       if grant is not None and reserved:
        descriptor_state=service.chat.persisted_descriptor_status(grant["session_id"])
        registry_present=service.chat.registry.has_session(grant["session_id"])
        if descriptor_state=="absent" and not registry_present:
         service.authorization.release(body["grant_id"],grant["session_id"])
       raise
      service.grant(cookie_token,value["new_session_id"],grant_id=body.get("grant_id"))
      self._reply(HTTPStatus.CREATED,value);return
    if action=="blank":
     if set(body)!={"grant_id","operation"} or not _safe_identifier(body.get("grant_id")) or not _safe_identifier(body.get("operation")):
      raise AttendedChatApiError("blank session request is invalid")
     old=service.chat._session(session_id)
     cookie=SimpleCookie(self.headers.get("Cookie", "")); cookie_token=cookie.get("attended_session").value if cookie.get("attended_session") else ""
     with service.creation_lock:
      grant=service.authorize_fresh(cookie_token,old.project_id,body["grant_id"],body["operation"])
      reserved=False
      if grant.get("session_id") is None:
       grant=service.authorization.reserve(service.live_sessions[cookie_token].token,body["grant_id"],body["operation"],old.project_id,f"blank.{uuid4().hex[:12]}"); reserved=True
      if grant.get("session_id") in service.chat.sessions:
       persisted=service.chat.persisted_descriptor(grant["session_id"])
       if persisted is None or persisted.compatible_context!="blank" or persisted.project_id!=old.project_id or persisted.context_sources or persisted.context_fields or persisted.memory_scope is not None:
        raise AttendedChatApiError("blank-session replay does not match persisted session")
       self._reply(HTTPStatus.OK,{"old_session_id":session_id,"new_session_id":persisted.session_id,"project_id":persisted.project_id,"revision_id":persisted.revision_id,"context_id":"blank","state":"idle","replayed":True}); return
      try: value=service.chat.blank_session(session_id,new_session_id=grant.get("session_id"))
      except Exception:
       if reserved and service.chat.persisted_descriptor_status(grant["session_id"])=="absent" and not service.chat.registry.has_session(grant["session_id"]): service.authorization.release(body["grant_id"],grant["session_id"])
       raise
      service.grant(cookie_token,value["new_session_id"],grant_id=body["grant_id"])
      self._reply(HTTPStatus.CREATED,value); return
    if action=="compact":
     if set(body)!={"operation_id","expected_context_revision"} or not _safe_identifier(body.get("operation_id")) or type(body.get("expected_context_revision")) is not int or body["expected_context_revision"] < 0:
      raise AttendedChatApiError("compaction request is invalid")
     self._reply(HTTPStatus.OK,service.chat.compact(session_id,body["operation_id"],body["expected_context_revision"]));return
    if action=="messages":
     if set(body)!={"message","request_id"}:raise AttendedChatApiError("message request is invalid")
     # Memory input is intentionally neither accepted nor rendered by the browser.
     injection=service.memory_context(session_id) if service.memory_context else None
     try:value=service.chat.send(session_id,body["message"],body["request_id"],memory_injection=injection)
     except RuntimeOutcomeUnknown:self._reply(HTTPStatus.ACCEPTED,{"state":"unknown","request_id":body["request_id"]});return
     self._reply(HTTPStatus.OK,value);return
    if action=="pause":
     if body:raise AttendedChatApiError("pause request is invalid")
     self._reply(HTTPStatus.ACCEPTED,service.chat.pause(session_id));return
    if action=="reconcile":
     if set(body)!={"request_id"}:raise AttendedChatApiError("reconciliation request is invalid")
     self._reply(HTTPStatus.OK,service.chat.reconcile(session_id,body["request_id"]));return
    if set(body)!={"model_id","revision","context","operation_id","expected_revision"}:raise AttendedChatApiError("binding request is invalid")
    self._reply(HTTPStatus.OK,service.chat.switch_model(session_id,body["model_id"],body["revision"],body["context"],body["operation_id"],body["expected_revision"]))
   except AttendedChatApiError as e:self._reply(HTTPStatus.BAD_REQUEST,{"error":str(e)})
   except AttendedChatError as e:self._reply(HTTPStatus.CONFLICT,{"error":str(e)})
   except (ValueError,UnicodeError):self._reply(HTTPStatus.BAD_REQUEST,{"error":"invalid_request"})
 return Handler

def serve(service:AttendedChatHttpService,address:tuple[str,int]=("127.0.0.1",0))->ThreadingHTTPServer:return ThreadingHTTPServer(address,make_handler(service))
