"""Process boundary for a per-assignment Hermes sandbox.

The runner owns the policy hand-off to a future Sandcastle (or other) backend.
It intentionally has no Docker/host integration and does not claim to create a
container itself.  A local subprocess fallback is retained for compatibility
and tests; production callers should supply a backend that enforces the
returned :class:`SandboxLaunchSpec`.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import signal
import subprocess
from typing import Any, Callable, Mapping, Sequence

from .execution_profiles import ExecutionProfile, ExecutionProfileError


class SandboxRunnerError(ValueError):
    """The launch request cannot be admitted by the sandbox boundary."""


@dataclass(frozen=True)
class SandboxLaunchSpec:
    """Backend-neutral sandbox request.

    ``workspace`` is the only writable mount.  ``home`` is a separate private
    state mount, and ``source_root`` is read-only package input.  The backend is
    expected to reject any extra mounts or privilege requests.
    """

    profile_id: str
    workspace: Path
    home: Path
    source_root: Path
    allowed_network_routes: tuple[str, ...]
    memory_limit_mb: int
    cpu_limit_seconds: int
    pids_limit: int
    disk_limit_mb: int
    writable_mounts: tuple[Path, ...]
    read_only_mounts: tuple[Path, ...]
    host_mounts: tuple[Path, ...] = ()
    docker_socket: bool = False
    privileged: bool = False
    windows_interop: bool = False

    def __post_init__(self) -> None:
        if self.host_mounts or self.docker_socket or self.privileged or self.windows_interop:
            raise SandboxRunnerError("host mounts, Docker socket, privilege, and Windows interop are disabled")
        for path in (self.workspace, self.home, self.source_root):
            if not path.is_absolute() or path.is_symlink() or not path.is_dir():
                raise SandboxRunnerError("sandbox paths must be existing absolute non-symlink directories")
        if self.workspace == self.home or self.workspace in self.home.parents or self.home in self.workspace.parents:
            raise SandboxRunnerError("workspace and session home must be separate")
        if self.source_root in self.workspace.parents or self.source_root in self.home.parents or self.workspace in self.source_root.parents or self.home in self.source_root.parents:
            raise SandboxRunnerError("sandbox mounts must not overlap")
        if self.writable_mounts != (self.workspace, self.home):
            raise SandboxRunnerError("sandbox writable mounts must be workspace and private session home")
        if self.read_only_mounts != (self.source_root,):
            raise SandboxRunnerError("sandbox source mount must be read-only")


@dataclass(frozen=True)
class SandboxRunOutcome:
    completed: subprocess.CompletedProcess[str]
    drained: bool = False
    checkpoint_id: str | None = None
    forced_termination: bool = False


class SandboxRunner:
    """Launch a process subject to a validated profile and drain protocol."""

    def __init__(self, *, termination_grace_seconds: float = 5.0, backend: Callable[..., subprocess.Popen[str]] | None = None, popen: Callable[..., subprocess.Popen[str]] = subprocess.Popen, allow_unisolated_local: bool = False) -> None:
        if termination_grace_seconds <= 0:
            raise SandboxRunnerError("termination grace must be positive")
        self.termination_grace_seconds = termination_grace_seconds
        self.backend = backend
        self._popen = popen
        self.allow_unisolated_local = allow_unisolated_local

    @staticmethod
    def launch_spec(profile: ExecutionProfile, *, workspace: str | Path, home: str | Path, source_root: str | Path) -> SandboxLaunchSpec:
        if not isinstance(profile, ExecutionProfile):
            raise SandboxRunnerError("an approved execution profile is required")
        raw_paths = (Path(workspace), Path(home), Path(source_root))
        if any(not path.is_absolute() or path.is_symlink() or not path.is_dir() for path in raw_paths):
            raise SandboxRunnerError("sandbox paths must be existing absolute non-symlink directories")
        workspace_path, home_path, source_path = (path.resolve() for path in raw_paths)
        return SandboxLaunchSpec(
            profile_id=profile.profile_id,
            workspace=workspace_path,
            home=home_path,
            source_root=source_path,
            allowed_network_routes=profile.allowed_network_routes,
            memory_limit_mb=profile.memory_limit_mb,
            cpu_limit_seconds=profile.cpu_limit_seconds,
            pids_limit=profile.pids_limit,
            disk_limit_mb=profile.disk_limit_mb,
            writable_mounts=(workspace_path, home_path),
            read_only_mounts=(source_path,),
        )

    def run(
        self,
        command: Sequence[str],
        *,
        profile: ExecutionProfile,
        workspace: str | Path,
        home: str | Path,
        source_root: str | Path,
        input: str,
        env: Mapping[str, str],
        drain: Callable[[], Any] | None = None,
        checkpoint: Callable[[], str | None] | None = None,
    ) -> SandboxRunOutcome:
        """Run one turn and preserve the checkpoint-before-kill ordering.

        A timeout first asks the runtime to drain, then checkpoints if possible,
        and only then terminates the child.  The resulting receipt remains
        non-successful because a forced termination is never a completed turn.
        """
        spec = self.launch_spec(profile, workspace=workspace, home=home, source_root=source_root)
        if self.backend is None and profile.profile_id != "legacy-hermes" and not self.allow_unisolated_local:
            raise SandboxRunnerError("an enforcing sandbox backend is required for non-legacy execution profiles")
        launch = self.backend or self._popen
        process_input = input
        if self.backend is not None:
            launched = launch(spec, list(command), input=input, env=dict(env))
            if isinstance(launched, tuple) and len(launched) == 2:
                process, process_input = launched
            else:
                process = launched
        else:
            # Compatibility-only local launch.  It does not enforce resource,
            # network, or mount limits and must never be used for coding
            # profiles in a production deployment.
            process = launch(
                list(command), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, cwd=str(spec.workspace), env=dict(env), start_new_session=(os.name != "nt"),
            )
        try:
            stdout, stderr = process.communicate(input=process_input, timeout=profile.timeout_seconds)
            return SandboxRunOutcome(subprocess.CompletedProcess(list(command), process.returncode, stdout, stderr))
        except subprocess.TimeoutExpired as error:
            drained = False
            checkpoint_id: str | None = None
            if drain is not None:
                try:
                    drain()
                    drained = True
                except Exception:
                    drained = False
            if checkpoint is not None and drained:
                try:
                    checkpoint_id = checkpoint()
                except Exception:
                    checkpoint_id = None
            forced = True
            try:
                if os.name == "nt":
                    process.terminate()
                else:
                    os.killpg(process.pid, signal.SIGTERM)
                stdout, stderr = process.communicate(timeout=self.termination_grace_seconds)
            except subprocess.TimeoutExpired:
                if os.name == "nt":
                    process.kill()
                else:
                    os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate()
            except OSError:
                process.kill()
                stdout, stderr = process.communicate()
            # Preserve any partial output for private diagnostics, but callers
            # must classify this as unknown/failed rather than successful.
            if isinstance(error.stdout, str) and not stdout:
                stdout = error.stdout
            if isinstance(error.stderr, str) and not stderr:
                stderr = error.stderr
            return SandboxRunOutcome(
                subprocess.CompletedProcess(list(command), process.returncode, stdout or "", stderr or ""),
                drained=drained, checkpoint_id=checkpoint_id, forced_termination=forced,
            )
